<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-01-16 11:15:37 --> Config Class Initialized
INFO - 2019-01-16 11:15:37 --> Hooks Class Initialized
DEBUG - 2019-01-16 11:15:37 --> UTF-8 Support Enabled
INFO - 2019-01-16 11:15:37 --> Utf8 Class Initialized
INFO - 2019-01-16 11:15:37 --> URI Class Initialized
INFO - 2019-01-16 11:15:37 --> Router Class Initialized
INFO - 2019-01-16 11:15:37 --> Output Class Initialized
INFO - 2019-01-16 11:15:37 --> Security Class Initialized
DEBUG - 2019-01-16 11:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-16 11:15:37 --> Input Class Initialized
INFO - 2019-01-16 11:15:37 --> Language Class Initialized
INFO - 2019-01-16 11:15:37 --> Loader Class Initialized
INFO - 2019-01-16 11:15:37 --> Helper loaded: url_helper
INFO - 2019-01-16 11:15:37 --> Helper loaded: html_helper
INFO - 2019-01-16 11:15:37 --> Helper loaded: form_helper
INFO - 2019-01-16 11:15:37 --> Helper loaded: cookie_helper
INFO - 2019-01-16 11:15:37 --> Helper loaded: date_helper
INFO - 2019-01-16 11:15:37 --> Form Validation Class Initialized
INFO - 2019-01-16 11:15:37 --> Email Class Initialized
DEBUG - 2019-01-16 11:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-16 11:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-16 11:15:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-16 11:15:37 --> Pagination Class Initialized
INFO - 2019-01-16 11:15:37 --> Database Driver Class Initialized
INFO - 2019-01-16 11:15:37 --> Database Driver Class Initialized
INFO - 2019-01-16 11:15:37 --> Controller Class Initialized
DEBUG - 2019-01-16 11:15:37 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2019-01-16 11:15:37 --> Helper loaded: inflector_helper
INFO - 2019-01-16 11:15:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-01-16 11:15:37 --> Final output sent to browser
DEBUG - 2019-01-16 11:15:37 --> Total execution time: 0.2706
