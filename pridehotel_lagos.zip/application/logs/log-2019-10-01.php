<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-10-01 06:20:12 --> Config Class Initialized
INFO - 2019-10-01 06:20:12 --> Hooks Class Initialized
DEBUG - 2019-10-01 06:20:12 --> UTF-8 Support Enabled
INFO - 2019-10-01 06:20:12 --> Utf8 Class Initialized
INFO - 2019-10-01 06:20:12 --> URI Class Initialized
INFO - 2019-10-01 06:20:12 --> Router Class Initialized
INFO - 2019-10-01 06:20:12 --> Output Class Initialized
INFO - 2019-10-01 06:20:12 --> Security Class Initialized
DEBUG - 2019-10-01 06:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-01 06:20:12 --> Input Class Initialized
INFO - 2019-10-01 06:20:12 --> Language Class Initialized
INFO - 2019-10-01 06:20:12 --> Loader Class Initialized
INFO - 2019-10-01 06:20:12 --> Helper loaded: url_helper
INFO - 2019-10-01 06:20:12 --> Helper loaded: html_helper
INFO - 2019-10-01 06:20:13 --> Helper loaded: form_helper
INFO - 2019-10-01 06:20:13 --> Helper loaded: cookie_helper
INFO - 2019-10-01 06:20:13 --> Helper loaded: date_helper
INFO - 2019-10-01 06:20:13 --> Form Validation Class Initialized
INFO - 2019-10-01 06:20:13 --> Email Class Initialized
DEBUG - 2019-10-01 06:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-01 06:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-01 06:20:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-01 06:20:13 --> Pagination Class Initialized
INFO - 2019-10-01 06:20:13 --> Database Driver Class Initialized
INFO - 2019-10-01 06:20:13 --> Database Driver Class Initialized
INFO - 2019-10-01 06:20:13 --> Controller Class Initialized
DEBUG - 2019-10-01 06:20:13 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-10-01 06:20:13 --> Helper loaded: inflector_helper
INFO - 2019-10-01 06:20:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-10-01 06:20:13 --> Final output sent to browser
DEBUG - 2019-10-01 06:20:13 --> Total execution time: 1.3263
INFO - 2019-10-01 12:51:39 --> Config Class Initialized
INFO - 2019-10-01 12:51:39 --> Hooks Class Initialized
DEBUG - 2019-10-01 12:51:39 --> UTF-8 Support Enabled
INFO - 2019-10-01 12:51:39 --> Utf8 Class Initialized
INFO - 2019-10-01 12:51:39 --> URI Class Initialized
INFO - 2019-10-01 12:51:39 --> Router Class Initialized
INFO - 2019-10-01 12:51:39 --> Output Class Initialized
INFO - 2019-10-01 12:51:39 --> Security Class Initialized
DEBUG - 2019-10-01 12:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-01 12:51:39 --> Input Class Initialized
INFO - 2019-10-01 12:51:39 --> Language Class Initialized
INFO - 2019-10-01 12:51:39 --> Loader Class Initialized
INFO - 2019-10-01 12:51:39 --> Helper loaded: url_helper
INFO - 2019-10-01 12:51:39 --> Helper loaded: html_helper
INFO - 2019-10-01 12:51:39 --> Helper loaded: form_helper
INFO - 2019-10-01 12:51:39 --> Helper loaded: cookie_helper
INFO - 2019-10-01 12:51:39 --> Helper loaded: date_helper
INFO - 2019-10-01 12:51:39 --> Form Validation Class Initialized
INFO - 2019-10-01 12:51:39 --> Email Class Initialized
DEBUG - 2019-10-01 12:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-01 12:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-01 12:51:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-01 12:51:39 --> Pagination Class Initialized
INFO - 2019-10-01 12:51:40 --> Database Driver Class Initialized
INFO - 2019-10-01 12:51:40 --> Database Driver Class Initialized
INFO - 2019-10-01 12:51:40 --> Controller Class Initialized
DEBUG - 2019-10-01 12:51:40 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-10-01 12:51:40 --> Helper loaded: inflector_helper
INFO - 2019-10-01 12:51:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-10-01 12:51:40 --> Final output sent to browser
DEBUG - 2019-10-01 12:51:40 --> Total execution time: 1.4600
INFO - 2019-10-01 16:58:21 --> Config Class Initialized
INFO - 2019-10-01 16:58:21 --> Hooks Class Initialized
DEBUG - 2019-10-01 16:58:21 --> UTF-8 Support Enabled
INFO - 2019-10-01 16:58:21 --> Utf8 Class Initialized
INFO - 2019-10-01 16:58:21 --> URI Class Initialized
INFO - 2019-10-01 16:58:21 --> Router Class Initialized
INFO - 2019-10-01 16:58:21 --> Output Class Initialized
INFO - 2019-10-01 16:58:21 --> Security Class Initialized
DEBUG - 2019-10-01 16:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-01 16:58:21 --> Input Class Initialized
INFO - 2019-10-01 16:58:21 --> Language Class Initialized
INFO - 2019-10-01 16:58:22 --> Loader Class Initialized
INFO - 2019-10-01 16:58:22 --> Helper loaded: url_helper
INFO - 2019-10-01 16:58:22 --> Helper loaded: html_helper
INFO - 2019-10-01 16:58:22 --> Helper loaded: form_helper
INFO - 2019-10-01 16:58:22 --> Helper loaded: cookie_helper
INFO - 2019-10-01 16:58:22 --> Helper loaded: date_helper
INFO - 2019-10-01 16:58:22 --> Form Validation Class Initialized
INFO - 2019-10-01 16:58:22 --> Email Class Initialized
DEBUG - 2019-10-01 16:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-01 16:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-01 16:58:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-01 16:58:23 --> Pagination Class Initialized
INFO - 2019-10-01 16:58:23 --> Database Driver Class Initialized
INFO - 2019-10-01 16:58:23 --> Database Driver Class Initialized
INFO - 2019-10-01 16:58:24 --> Controller Class Initialized
INFO - 2019-10-01 16:58:24 --> Config Class Initialized
INFO - 2019-10-01 16:58:24 --> Hooks Class Initialized
DEBUG - 2019-10-01 16:58:24 --> UTF-8 Support Enabled
INFO - 2019-10-01 16:58:24 --> Utf8 Class Initialized
INFO - 2019-10-01 16:58:24 --> URI Class Initialized
INFO - 2019-10-01 16:58:24 --> Router Class Initialized
INFO - 2019-10-01 16:58:24 --> Output Class Initialized
INFO - 2019-10-01 16:58:24 --> Security Class Initialized
DEBUG - 2019-10-01 16:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-01 16:58:24 --> Input Class Initialized
INFO - 2019-10-01 16:58:24 --> Language Class Initialized
INFO - 2019-10-01 16:58:24 --> Loader Class Initialized
INFO - 2019-10-01 16:58:24 --> Helper loaded: url_helper
INFO - 2019-10-01 16:58:24 --> Helper loaded: html_helper
INFO - 2019-10-01 16:58:24 --> Helper loaded: form_helper
INFO - 2019-10-01 16:58:24 --> Helper loaded: cookie_helper
INFO - 2019-10-01 16:58:24 --> Helper loaded: date_helper
INFO - 2019-10-01 16:58:24 --> Form Validation Class Initialized
INFO - 2019-10-01 16:58:24 --> Email Class Initialized
DEBUG - 2019-10-01 16:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-01 16:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-01 16:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-01 16:58:24 --> Pagination Class Initialized
INFO - 2019-10-01 16:58:24 --> Database Driver Class Initialized
INFO - 2019-10-01 16:58:24 --> Database Driver Class Initialized
INFO - 2019-10-01 16:58:24 --> Controller Class Initialized
INFO - 2019-10-01 16:58:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-10-01 16:58:25 --> Final output sent to browser
DEBUG - 2019-10-01 16:58:25 --> Total execution time: 0.2262
INFO - 2019-10-01 16:58:30 --> Config Class Initialized
INFO - 2019-10-01 16:58:30 --> Hooks Class Initialized
DEBUG - 2019-10-01 16:58:30 --> UTF-8 Support Enabled
INFO - 2019-10-01 16:58:30 --> Utf8 Class Initialized
INFO - 2019-10-01 16:58:30 --> URI Class Initialized
INFO - 2019-10-01 16:58:30 --> Router Class Initialized
INFO - 2019-10-01 16:58:30 --> Output Class Initialized
INFO - 2019-10-01 16:58:30 --> Security Class Initialized
DEBUG - 2019-10-01 16:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-01 16:58:30 --> Input Class Initialized
INFO - 2019-10-01 16:58:30 --> Language Class Initialized
INFO - 2019-10-01 16:58:30 --> Loader Class Initialized
INFO - 2019-10-01 16:58:30 --> Helper loaded: url_helper
INFO - 2019-10-01 16:58:30 --> Helper loaded: html_helper
INFO - 2019-10-01 16:58:30 --> Helper loaded: form_helper
INFO - 2019-10-01 16:58:30 --> Helper loaded: cookie_helper
INFO - 2019-10-01 16:58:30 --> Helper loaded: date_helper
INFO - 2019-10-01 16:58:30 --> Form Validation Class Initialized
INFO - 2019-10-01 16:58:30 --> Email Class Initialized
DEBUG - 2019-10-01 16:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-01 16:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-01 16:58:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-01 16:58:30 --> Pagination Class Initialized
INFO - 2019-10-01 16:58:30 --> Database Driver Class Initialized
INFO - 2019-10-01 16:58:30 --> Database Driver Class Initialized
INFO - 2019-10-01 16:58:30 --> Controller Class Initialized
INFO - 2019-10-01 16:58:30 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-10-01 16:58:30 --> Final output sent to browser
DEBUG - 2019-10-01 16:58:30 --> Total execution time: 0.4588
