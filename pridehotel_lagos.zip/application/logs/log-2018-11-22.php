<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-22 04:40:39 --> Config Class Initialized
INFO - 2018-11-22 04:40:39 --> Hooks Class Initialized
DEBUG - 2018-11-22 04:40:40 --> UTF-8 Support Enabled
INFO - 2018-11-22 04:40:40 --> Utf8 Class Initialized
INFO - 2018-11-22 04:40:40 --> URI Class Initialized
INFO - 2018-11-22 04:40:41 --> Router Class Initialized
INFO - 2018-11-22 04:40:41 --> Output Class Initialized
INFO - 2018-11-22 04:40:41 --> Security Class Initialized
DEBUG - 2018-11-22 04:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-22 04:40:41 --> Input Class Initialized
INFO - 2018-11-22 04:40:41 --> Language Class Initialized
INFO - 2018-11-22 04:40:41 --> Loader Class Initialized
INFO - 2018-11-22 04:40:42 --> Helper loaded: url_helper
INFO - 2018-11-22 04:40:42 --> Helper loaded: html_helper
INFO - 2018-11-22 04:40:42 --> Helper loaded: form_helper
INFO - 2018-11-22 04:40:42 --> Helper loaded: cookie_helper
INFO - 2018-11-22 04:40:42 --> Helper loaded: date_helper
INFO - 2018-11-22 04:40:42 --> Form Validation Class Initialized
INFO - 2018-11-22 04:40:42 --> Email Class Initialized
DEBUG - 2018-11-22 04:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-22 04:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-22 04:40:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-22 04:40:42 --> Pagination Class Initialized
INFO - 2018-11-22 04:40:43 --> Database Driver Class Initialized
INFO - 2018-11-22 04:40:43 --> Database Driver Class Initialized
INFO - 2018-11-22 04:40:43 --> Controller Class Initialized
INFO - 2018-11-22 04:40:50 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-22 04:40:50 --> Final output sent to browser
DEBUG - 2018-11-22 04:40:50 --> Total execution time: 10.9869
