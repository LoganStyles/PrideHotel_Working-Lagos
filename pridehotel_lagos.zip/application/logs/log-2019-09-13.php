<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-13 21:24:47 --> Config Class Initialized
INFO - 2019-09-13 21:24:47 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:24:47 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:24:47 --> Utf8 Class Initialized
INFO - 2019-09-13 21:24:47 --> URI Class Initialized
INFO - 2019-09-13 21:24:47 --> Router Class Initialized
INFO - 2019-09-13 21:24:47 --> Output Class Initialized
INFO - 2019-09-13 21:24:47 --> Security Class Initialized
DEBUG - 2019-09-13 21:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:24:47 --> Input Class Initialized
INFO - 2019-09-13 21:24:47 --> Language Class Initialized
INFO - 2019-09-13 21:24:47 --> Loader Class Initialized
INFO - 2019-09-13 21:24:47 --> Helper loaded: url_helper
INFO - 2019-09-13 21:24:47 --> Helper loaded: html_helper
INFO - 2019-09-13 21:24:47 --> Helper loaded: form_helper
INFO - 2019-09-13 21:24:47 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:24:47 --> Helper loaded: date_helper
INFO - 2019-09-13 21:24:47 --> Form Validation Class Initialized
INFO - 2019-09-13 21:24:47 --> Email Class Initialized
DEBUG - 2019-09-13 21:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:24:47 --> Pagination Class Initialized
INFO - 2019-09-13 21:24:48 --> Database Driver Class Initialized
INFO - 2019-09-13 21:24:48 --> Database Driver Class Initialized
INFO - 2019-09-13 21:24:48 --> Controller Class Initialized
INFO - 2019-09-13 21:24:48 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-13 21:24:48 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-13 21:24:48 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-13 21:24:48 --> Final output sent to browser
DEBUG - 2019-09-13 21:24:48 --> Total execution time: 1.8531
INFO - 2019-09-13 21:24:49 --> Config Class Initialized
INFO - 2019-09-13 21:24:49 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:24:49 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:24:49 --> Utf8 Class Initialized
INFO - 2019-09-13 21:24:49 --> URI Class Initialized
INFO - 2019-09-13 21:24:49 --> Router Class Initialized
INFO - 2019-09-13 21:24:49 --> Output Class Initialized
INFO - 2019-09-13 21:24:49 --> Security Class Initialized
DEBUG - 2019-09-13 21:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:24:49 --> Input Class Initialized
INFO - 2019-09-13 21:24:49 --> Language Class Initialized
INFO - 2019-09-13 21:24:49 --> Loader Class Initialized
INFO - 2019-09-13 21:24:49 --> Helper loaded: url_helper
INFO - 2019-09-13 21:24:49 --> Helper loaded: html_helper
INFO - 2019-09-13 21:24:49 --> Helper loaded: form_helper
INFO - 2019-09-13 21:24:49 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:24:49 --> Helper loaded: date_helper
INFO - 2019-09-13 21:24:49 --> Form Validation Class Initialized
INFO - 2019-09-13 21:24:49 --> Email Class Initialized
DEBUG - 2019-09-13 21:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:24:49 --> Pagination Class Initialized
INFO - 2019-09-13 21:24:49 --> Database Driver Class Initialized
INFO - 2019-09-13 21:24:49 --> Database Driver Class Initialized
INFO - 2019-09-13 21:24:49 --> Controller Class Initialized
INFO - 2019-09-13 21:24:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 21:24:49 --> Final output sent to browser
DEBUG - 2019-09-13 21:24:49 --> Total execution time: 0.0845
INFO - 2019-09-13 21:24:49 --> Config Class Initialized
INFO - 2019-09-13 21:24:49 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:24:49 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:24:49 --> Utf8 Class Initialized
INFO - 2019-09-13 21:24:49 --> URI Class Initialized
INFO - 2019-09-13 21:24:49 --> Router Class Initialized
INFO - 2019-09-13 21:24:49 --> Output Class Initialized
INFO - 2019-09-13 21:24:49 --> Security Class Initialized
DEBUG - 2019-09-13 21:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:24:49 --> Input Class Initialized
INFO - 2019-09-13 21:24:49 --> Language Class Initialized
INFO - 2019-09-13 21:24:49 --> Loader Class Initialized
INFO - 2019-09-13 21:24:49 --> Helper loaded: url_helper
INFO - 2019-09-13 21:24:49 --> Helper loaded: html_helper
INFO - 2019-09-13 21:24:49 --> Helper loaded: form_helper
INFO - 2019-09-13 21:24:49 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:24:49 --> Helper loaded: date_helper
INFO - 2019-09-13 21:24:49 --> Form Validation Class Initialized
INFO - 2019-09-13 21:24:49 --> Email Class Initialized
DEBUG - 2019-09-13 21:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:24:49 --> Pagination Class Initialized
INFO - 2019-09-13 21:24:49 --> Database Driver Class Initialized
INFO - 2019-09-13 21:24:49 --> Database Driver Class Initialized
INFO - 2019-09-13 21:24:49 --> Controller Class Initialized
INFO - 2019-09-13 21:24:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 21:24:49 --> Final output sent to browser
DEBUG - 2019-09-13 21:24:49 --> Total execution time: 0.1703
INFO - 2019-09-13 21:27:07 --> Config Class Initialized
INFO - 2019-09-13 21:27:07 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:07 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:07 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:07 --> URI Class Initialized
INFO - 2019-09-13 21:27:07 --> Router Class Initialized
INFO - 2019-09-13 21:27:07 --> Output Class Initialized
INFO - 2019-09-13 21:27:07 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:07 --> Input Class Initialized
INFO - 2019-09-13 21:27:07 --> Language Class Initialized
INFO - 2019-09-13 21:27:07 --> Loader Class Initialized
INFO - 2019-09-13 21:27:07 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:07 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:07 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:07 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:07 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:07 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:07 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:07 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:07 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:07 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:07 --> Controller Class Initialized
INFO - 2019-09-13 21:27:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-13 21:27:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-13 21:27:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-13 21:27:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-13 21:27:07 --> Final output sent to browser
DEBUG - 2019-09-13 21:27:07 --> Total execution time: 0.1696
INFO - 2019-09-13 21:27:07 --> Config Class Initialized
INFO - 2019-09-13 21:27:07 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:07 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:07 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:07 --> URI Class Initialized
INFO - 2019-09-13 21:27:07 --> Router Class Initialized
INFO - 2019-09-13 21:27:07 --> Output Class Initialized
INFO - 2019-09-13 21:27:07 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:07 --> Input Class Initialized
INFO - 2019-09-13 21:27:07 --> Language Class Initialized
INFO - 2019-09-13 21:27:07 --> Loader Class Initialized
INFO - 2019-09-13 21:27:07 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:07 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:07 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:07 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:07 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:07 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:07 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:07 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:07 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:07 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:07 --> Controller Class Initialized
INFO - 2019-09-13 21:27:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 21:27:07 --> Final output sent to browser
DEBUG - 2019-09-13 21:27:07 --> Total execution time: 0.0626
INFO - 2019-09-13 21:27:07 --> Config Class Initialized
INFO - 2019-09-13 21:27:07 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:07 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:07 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:07 --> URI Class Initialized
INFO - 2019-09-13 21:27:07 --> Router Class Initialized
INFO - 2019-09-13 21:27:07 --> Output Class Initialized
INFO - 2019-09-13 21:27:07 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:07 --> Input Class Initialized
INFO - 2019-09-13 21:27:07 --> Language Class Initialized
INFO - 2019-09-13 21:27:07 --> Loader Class Initialized
INFO - 2019-09-13 21:27:07 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:07 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:07 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:07 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:07 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:07 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:07 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:07 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:07 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:07 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:07 --> Controller Class Initialized
INFO - 2019-09-13 21:27:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 21:27:07 --> Final output sent to browser
DEBUG - 2019-09-13 21:27:07 --> Total execution time: 0.0662
INFO - 2019-09-13 21:27:11 --> Config Class Initialized
INFO - 2019-09-13 21:27:11 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:11 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:11 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:11 --> URI Class Initialized
INFO - 2019-09-13 21:27:11 --> Router Class Initialized
INFO - 2019-09-13 21:27:11 --> Output Class Initialized
INFO - 2019-09-13 21:27:11 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:11 --> Input Class Initialized
INFO - 2019-09-13 21:27:11 --> Language Class Initialized
INFO - 2019-09-13 21:27:11 --> Loader Class Initialized
INFO - 2019-09-13 21:27:11 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:11 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:11 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:11 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:11 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:11 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:11 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:11 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:11 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:11 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:11 --> Controller Class Initialized
ERROR - 2019-09-13 21:27:11 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-13 21:27:11 --> Config Class Initialized
INFO - 2019-09-13 21:27:11 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:11 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:11 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:11 --> URI Class Initialized
INFO - 2019-09-13 21:27:11 --> Router Class Initialized
INFO - 2019-09-13 21:27:11 --> Output Class Initialized
INFO - 2019-09-13 21:27:11 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:11 --> Input Class Initialized
INFO - 2019-09-13 21:27:11 --> Language Class Initialized
INFO - 2019-09-13 21:27:11 --> Loader Class Initialized
INFO - 2019-09-13 21:27:11 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:11 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:11 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:11 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:11 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:11 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:11 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:11 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:11 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:11 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:11 --> Controller Class Initialized
ERROR - 2019-09-13 21:27:11 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-13 21:27:12 --> Config Class Initialized
INFO - 2019-09-13 21:27:12 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:12 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:12 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:12 --> URI Class Initialized
INFO - 2019-09-13 21:27:12 --> Router Class Initialized
INFO - 2019-09-13 21:27:12 --> Output Class Initialized
INFO - 2019-09-13 21:27:12 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:12 --> Input Class Initialized
INFO - 2019-09-13 21:27:12 --> Language Class Initialized
INFO - 2019-09-13 21:27:12 --> Loader Class Initialized
INFO - 2019-09-13 21:27:12 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:12 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:12 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:12 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:12 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:12 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:12 --> Controller Class Initialized
ERROR - 2019-09-13 21:27:12 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-13 21:27:12 --> Config Class Initialized
INFO - 2019-09-13 21:27:12 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:12 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:12 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:12 --> URI Class Initialized
INFO - 2019-09-13 21:27:12 --> Router Class Initialized
INFO - 2019-09-13 21:27:12 --> Output Class Initialized
INFO - 2019-09-13 21:27:12 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:12 --> Input Class Initialized
INFO - 2019-09-13 21:27:12 --> Language Class Initialized
INFO - 2019-09-13 21:27:12 --> Loader Class Initialized
INFO - 2019-09-13 21:27:12 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:12 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:12 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:12 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:12 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:12 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:12 --> Controller Class Initialized
ERROR - 2019-09-13 21:27:12 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-13 21:27:12 --> Config Class Initialized
INFO - 2019-09-13 21:27:12 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:12 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:12 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:12 --> URI Class Initialized
INFO - 2019-09-13 21:27:12 --> Router Class Initialized
INFO - 2019-09-13 21:27:12 --> Output Class Initialized
INFO - 2019-09-13 21:27:12 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:12 --> Input Class Initialized
INFO - 2019-09-13 21:27:12 --> Language Class Initialized
INFO - 2019-09-13 21:27:12 --> Loader Class Initialized
INFO - 2019-09-13 21:27:12 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:12 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:12 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:12 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:12 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:12 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:12 --> Controller Class Initialized
ERROR - 2019-09-13 21:27:12 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-13 21:27:12 --> Config Class Initialized
INFO - 2019-09-13 21:27:12 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:12 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:12 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:12 --> URI Class Initialized
INFO - 2019-09-13 21:27:12 --> Router Class Initialized
INFO - 2019-09-13 21:27:12 --> Output Class Initialized
INFO - 2019-09-13 21:27:12 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:12 --> Input Class Initialized
INFO - 2019-09-13 21:27:12 --> Language Class Initialized
INFO - 2019-09-13 21:27:12 --> Loader Class Initialized
INFO - 2019-09-13 21:27:12 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:12 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:12 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:12 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:12 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:12 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:12 --> Controller Class Initialized
ERROR - 2019-09-13 21:27:12 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-13 21:27:12 --> Config Class Initialized
INFO - 2019-09-13 21:27:12 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:12 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:12 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:12 --> URI Class Initialized
INFO - 2019-09-13 21:27:12 --> Router Class Initialized
INFO - 2019-09-13 21:27:12 --> Output Class Initialized
INFO - 2019-09-13 21:27:12 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:12 --> Input Class Initialized
INFO - 2019-09-13 21:27:12 --> Language Class Initialized
INFO - 2019-09-13 21:27:12 --> Loader Class Initialized
INFO - 2019-09-13 21:27:12 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:12 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:12 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:12 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:12 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:12 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:12 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:12 --> Controller Class Initialized
ERROR - 2019-09-13 21:27:12 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-13 21:27:13 --> Config Class Initialized
INFO - 2019-09-13 21:27:13 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:13 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:13 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:13 --> URI Class Initialized
INFO - 2019-09-13 21:27:13 --> Router Class Initialized
INFO - 2019-09-13 21:27:13 --> Output Class Initialized
INFO - 2019-09-13 21:27:13 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:13 --> Input Class Initialized
INFO - 2019-09-13 21:27:13 --> Language Class Initialized
INFO - 2019-09-13 21:27:13 --> Loader Class Initialized
INFO - 2019-09-13 21:27:13 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:13 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:13 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:13 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:13 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:13 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:13 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:13 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:13 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:13 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:13 --> Controller Class Initialized
ERROR - 2019-09-13 21:27:13 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-13 21:27:13 --> Config Class Initialized
INFO - 2019-09-13 21:27:13 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:13 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:13 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:13 --> URI Class Initialized
INFO - 2019-09-13 21:27:13 --> Router Class Initialized
INFO - 2019-09-13 21:27:13 --> Output Class Initialized
INFO - 2019-09-13 21:27:13 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:13 --> Input Class Initialized
INFO - 2019-09-13 21:27:13 --> Language Class Initialized
INFO - 2019-09-13 21:27:13 --> Loader Class Initialized
INFO - 2019-09-13 21:27:13 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:13 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:13 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:13 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:13 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:13 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:13 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:13 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:13 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:13 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:13 --> Controller Class Initialized
ERROR - 2019-09-13 21:27:13 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-13 21:27:13 --> Config Class Initialized
INFO - 2019-09-13 21:27:13 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:13 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:13 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:13 --> URI Class Initialized
INFO - 2019-09-13 21:27:13 --> Router Class Initialized
INFO - 2019-09-13 21:27:13 --> Output Class Initialized
INFO - 2019-09-13 21:27:13 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:13 --> Input Class Initialized
INFO - 2019-09-13 21:27:13 --> Language Class Initialized
INFO - 2019-09-13 21:27:13 --> Loader Class Initialized
INFO - 2019-09-13 21:27:13 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:13 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:13 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:13 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:13 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:13 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:13 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:13 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:13 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:13 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:13 --> Controller Class Initialized
ERROR - 2019-09-13 21:27:13 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-13 21:27:13 --> Config Class Initialized
INFO - 2019-09-13 21:27:13 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:13 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:13 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:13 --> URI Class Initialized
INFO - 2019-09-13 21:27:13 --> Router Class Initialized
INFO - 2019-09-13 21:27:13 --> Output Class Initialized
INFO - 2019-09-13 21:27:13 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:13 --> Input Class Initialized
INFO - 2019-09-13 21:27:13 --> Language Class Initialized
INFO - 2019-09-13 21:27:13 --> Loader Class Initialized
INFO - 2019-09-13 21:27:13 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:13 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:13 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:13 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:13 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:13 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:13 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:13 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:13 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:13 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:13 --> Controller Class Initialized
ERROR - 2019-09-13 21:27:13 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-13 21:27:14 --> Config Class Initialized
INFO - 2019-09-13 21:27:14 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:14 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:14 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:14 --> URI Class Initialized
INFO - 2019-09-13 21:27:14 --> Router Class Initialized
INFO - 2019-09-13 21:27:14 --> Output Class Initialized
INFO - 2019-09-13 21:27:14 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:14 --> Input Class Initialized
INFO - 2019-09-13 21:27:14 --> Language Class Initialized
INFO - 2019-09-13 21:27:14 --> Loader Class Initialized
INFO - 2019-09-13 21:27:14 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:14 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:14 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:14 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:14 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:14 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:14 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:14 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:14 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:14 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:14 --> Controller Class Initialized
ERROR - 2019-09-13 21:27:14 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-13 21:27:16 --> Config Class Initialized
INFO - 2019-09-13 21:27:16 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:16 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:16 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:16 --> URI Class Initialized
INFO - 2019-09-13 21:27:16 --> Router Class Initialized
INFO - 2019-09-13 21:27:16 --> Output Class Initialized
INFO - 2019-09-13 21:27:16 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:16 --> Input Class Initialized
INFO - 2019-09-13 21:27:16 --> Language Class Initialized
INFO - 2019-09-13 21:27:16 --> Loader Class Initialized
INFO - 2019-09-13 21:27:16 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:16 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:16 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:16 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:16 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:16 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:16 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:16 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:16 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:16 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:16 --> Controller Class Initialized
INFO - 2019-09-13 21:27:16 --> Final output sent to browser
DEBUG - 2019-09-13 21:27:16 --> Total execution time: 0.0788
INFO - 2019-09-13 21:27:20 --> Config Class Initialized
INFO - 2019-09-13 21:27:20 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:20 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:20 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:20 --> URI Class Initialized
INFO - 2019-09-13 21:27:20 --> Router Class Initialized
INFO - 2019-09-13 21:27:20 --> Output Class Initialized
INFO - 2019-09-13 21:27:20 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:20 --> Input Class Initialized
INFO - 2019-09-13 21:27:20 --> Language Class Initialized
INFO - 2019-09-13 21:27:20 --> Loader Class Initialized
INFO - 2019-09-13 21:27:20 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:20 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:20 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:20 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:20 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:20 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:20 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:20 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:20 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:20 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:20 --> Controller Class Initialized
INFO - 2019-09-13 21:27:20 --> Final output sent to browser
DEBUG - 2019-09-13 21:27:20 --> Total execution time: 0.0860
INFO - 2019-09-13 21:27:23 --> Config Class Initialized
INFO - 2019-09-13 21:27:23 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:23 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:23 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:23 --> URI Class Initialized
INFO - 2019-09-13 21:27:23 --> Router Class Initialized
INFO - 2019-09-13 21:27:23 --> Output Class Initialized
INFO - 2019-09-13 21:27:23 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:23 --> Input Class Initialized
INFO - 2019-09-13 21:27:23 --> Language Class Initialized
INFO - 2019-09-13 21:27:23 --> Loader Class Initialized
INFO - 2019-09-13 21:27:23 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:23 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:23 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:23 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:23 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:23 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:23 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:23 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:23 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:23 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:23 --> Controller Class Initialized
INFO - 2019-09-13 21:27:23 --> Final output sent to browser
DEBUG - 2019-09-13 21:27:23 --> Total execution time: 0.0484
INFO - 2019-09-13 21:27:34 --> Config Class Initialized
INFO - 2019-09-13 21:27:34 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:34 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:34 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:34 --> URI Class Initialized
INFO - 2019-09-13 21:27:34 --> Router Class Initialized
INFO - 2019-09-13 21:27:34 --> Output Class Initialized
INFO - 2019-09-13 21:27:34 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:34 --> Input Class Initialized
INFO - 2019-09-13 21:27:34 --> Language Class Initialized
INFO - 2019-09-13 21:27:34 --> Loader Class Initialized
INFO - 2019-09-13 21:27:34 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:34 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:34 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:34 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:34 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:34 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:34 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:34 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:34 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:34 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:34 --> Controller Class Initialized
INFO - 2019-09-13 21:27:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-13 21:27:35 --> Config Class Initialized
INFO - 2019-09-13 21:27:35 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:35 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:35 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:35 --> URI Class Initialized
INFO - 2019-09-13 21:27:35 --> Router Class Initialized
INFO - 2019-09-13 21:27:35 --> Output Class Initialized
INFO - 2019-09-13 21:27:35 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:35 --> Input Class Initialized
INFO - 2019-09-13 21:27:35 --> Language Class Initialized
INFO - 2019-09-13 21:27:35 --> Loader Class Initialized
INFO - 2019-09-13 21:27:35 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:35 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:35 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:35 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:35 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:35 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:35 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:35 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:35 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:35 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:35 --> Controller Class Initialized
INFO - 2019-09-13 21:27:35 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-13 21:27:35 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-13 21:27:35 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/checkin.php
INFO - 2019-09-13 21:27:35 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-13 21:27:35 --> Final output sent to browser
DEBUG - 2019-09-13 21:27:35 --> Total execution time: 0.1281
INFO - 2019-09-13 21:27:35 --> Config Class Initialized
INFO - 2019-09-13 21:27:35 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:35 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:35 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:35 --> URI Class Initialized
INFO - 2019-09-13 21:27:35 --> Router Class Initialized
INFO - 2019-09-13 21:27:35 --> Output Class Initialized
INFO - 2019-09-13 21:27:35 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:35 --> Input Class Initialized
INFO - 2019-09-13 21:27:35 --> Language Class Initialized
INFO - 2019-09-13 21:27:35 --> Loader Class Initialized
INFO - 2019-09-13 21:27:35 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:35 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:35 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:35 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:35 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:35 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:35 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:35 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:35 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:35 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:35 --> Controller Class Initialized
INFO - 2019-09-13 21:27:35 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 21:27:35 --> Final output sent to browser
DEBUG - 2019-09-13 21:27:35 --> Total execution time: 0.0693
INFO - 2019-09-13 21:27:35 --> Config Class Initialized
INFO - 2019-09-13 21:27:35 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:35 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:35 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:35 --> URI Class Initialized
INFO - 2019-09-13 21:27:35 --> Router Class Initialized
INFO - 2019-09-13 21:27:35 --> Output Class Initialized
INFO - 2019-09-13 21:27:35 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:35 --> Input Class Initialized
INFO - 2019-09-13 21:27:35 --> Language Class Initialized
INFO - 2019-09-13 21:27:35 --> Loader Class Initialized
INFO - 2019-09-13 21:27:35 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:35 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:35 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:35 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:35 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:35 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:35 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:35 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:35 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:35 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:35 --> Controller Class Initialized
INFO - 2019-09-13 21:27:35 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 21:27:35 --> Final output sent to browser
DEBUG - 2019-09-13 21:27:35 --> Total execution time: 0.0715
INFO - 2019-09-13 21:27:40 --> Config Class Initialized
INFO - 2019-09-13 21:27:40 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:40 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:40 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:40 --> URI Class Initialized
INFO - 2019-09-13 21:27:40 --> Router Class Initialized
INFO - 2019-09-13 21:27:40 --> Output Class Initialized
INFO - 2019-09-13 21:27:40 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:40 --> Input Class Initialized
INFO - 2019-09-13 21:27:40 --> Language Class Initialized
INFO - 2019-09-13 21:27:40 --> Loader Class Initialized
INFO - 2019-09-13 21:27:40 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:40 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:40 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:40 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:40 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:40 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:40 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:40 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:40 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:40 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:40 --> Controller Class Initialized
INFO - 2019-09-13 21:27:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-13 21:27:40 --> Config Class Initialized
INFO - 2019-09-13 21:27:40 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:40 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:40 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:40 --> URI Class Initialized
INFO - 2019-09-13 21:27:40 --> Router Class Initialized
INFO - 2019-09-13 21:27:40 --> Output Class Initialized
INFO - 2019-09-13 21:27:40 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:40 --> Input Class Initialized
INFO - 2019-09-13 21:27:40 --> Language Class Initialized
INFO - 2019-09-13 21:27:40 --> Loader Class Initialized
INFO - 2019-09-13 21:27:40 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:40 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:40 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:40 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:40 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:40 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:40 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:40 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:40 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:40 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:40 --> Controller Class Initialized
INFO - 2019-09-13 21:27:40 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-13 21:27:40 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-13 21:27:40 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/checkin.php
INFO - 2019-09-13 21:27:40 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-13 21:27:40 --> Final output sent to browser
DEBUG - 2019-09-13 21:27:40 --> Total execution time: 0.0596
INFO - 2019-09-13 21:27:40 --> Config Class Initialized
INFO - 2019-09-13 21:27:40 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:40 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:40 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:40 --> URI Class Initialized
INFO - 2019-09-13 21:27:40 --> Router Class Initialized
INFO - 2019-09-13 21:27:40 --> Output Class Initialized
INFO - 2019-09-13 21:27:40 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:40 --> Input Class Initialized
INFO - 2019-09-13 21:27:40 --> Language Class Initialized
INFO - 2019-09-13 21:27:40 --> Loader Class Initialized
INFO - 2019-09-13 21:27:40 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:40 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:40 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:40 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:40 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:40 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:40 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:40 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:40 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:40 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:40 --> Controller Class Initialized
INFO - 2019-09-13 21:27:40 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 21:27:40 --> Final output sent to browser
DEBUG - 2019-09-13 21:27:40 --> Total execution time: 0.2199
INFO - 2019-09-13 21:27:40 --> Config Class Initialized
INFO - 2019-09-13 21:27:40 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:27:40 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:27:40 --> Utf8 Class Initialized
INFO - 2019-09-13 21:27:40 --> URI Class Initialized
INFO - 2019-09-13 21:27:40 --> Router Class Initialized
INFO - 2019-09-13 21:27:40 --> Output Class Initialized
INFO - 2019-09-13 21:27:40 --> Security Class Initialized
DEBUG - 2019-09-13 21:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:27:40 --> Input Class Initialized
INFO - 2019-09-13 21:27:40 --> Language Class Initialized
INFO - 2019-09-13 21:27:40 --> Loader Class Initialized
INFO - 2019-09-13 21:27:40 --> Helper loaded: url_helper
INFO - 2019-09-13 21:27:40 --> Helper loaded: html_helper
INFO - 2019-09-13 21:27:40 --> Helper loaded: form_helper
INFO - 2019-09-13 21:27:40 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:27:40 --> Helper loaded: date_helper
INFO - 2019-09-13 21:27:40 --> Form Validation Class Initialized
INFO - 2019-09-13 21:27:40 --> Email Class Initialized
DEBUG - 2019-09-13 21:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:27:40 --> Pagination Class Initialized
INFO - 2019-09-13 21:27:40 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:40 --> Database Driver Class Initialized
INFO - 2019-09-13 21:27:40 --> Controller Class Initialized
INFO - 2019-09-13 21:27:40 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 21:27:40 --> Final output sent to browser
DEBUG - 2019-09-13 21:27:40 --> Total execution time: 0.0667
INFO - 2019-09-13 21:39:29 --> Config Class Initialized
INFO - 2019-09-13 21:39:29 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:39:29 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:39:29 --> Utf8 Class Initialized
INFO - 2019-09-13 21:39:29 --> URI Class Initialized
INFO - 2019-09-13 21:39:29 --> Router Class Initialized
INFO - 2019-09-13 21:39:29 --> Output Class Initialized
INFO - 2019-09-13 21:39:29 --> Security Class Initialized
DEBUG - 2019-09-13 21:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:39:29 --> Input Class Initialized
INFO - 2019-09-13 21:39:29 --> Language Class Initialized
INFO - 2019-09-13 21:39:29 --> Loader Class Initialized
INFO - 2019-09-13 21:39:29 --> Helper loaded: url_helper
INFO - 2019-09-13 21:39:29 --> Helper loaded: html_helper
INFO - 2019-09-13 21:39:29 --> Helper loaded: form_helper
INFO - 2019-09-13 21:39:29 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:39:29 --> Helper loaded: date_helper
INFO - 2019-09-13 21:39:29 --> Form Validation Class Initialized
INFO - 2019-09-13 21:39:29 --> Email Class Initialized
DEBUG - 2019-09-13 21:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:39:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:39:29 --> Pagination Class Initialized
INFO - 2019-09-13 21:39:29 --> Database Driver Class Initialized
INFO - 2019-09-13 21:39:29 --> Database Driver Class Initialized
INFO - 2019-09-13 21:39:29 --> Controller Class Initialized
INFO - 2019-09-13 21:39:29 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 21:39:29 --> Final output sent to browser
DEBUG - 2019-09-13 21:39:29 --> Total execution time: 0.0815
INFO - 2019-09-13 21:59:12 --> Config Class Initialized
INFO - 2019-09-13 21:59:12 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:59:12 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:59:12 --> Utf8 Class Initialized
INFO - 2019-09-13 21:59:12 --> URI Class Initialized
INFO - 2019-09-13 21:59:12 --> Router Class Initialized
INFO - 2019-09-13 21:59:12 --> Output Class Initialized
INFO - 2019-09-13 21:59:12 --> Security Class Initialized
DEBUG - 2019-09-13 21:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:59:12 --> Input Class Initialized
INFO - 2019-09-13 21:59:12 --> Language Class Initialized
INFO - 2019-09-13 21:59:12 --> Loader Class Initialized
INFO - 2019-09-13 21:59:12 --> Helper loaded: url_helper
INFO - 2019-09-13 21:59:12 --> Helper loaded: html_helper
INFO - 2019-09-13 21:59:12 --> Helper loaded: form_helper
INFO - 2019-09-13 21:59:12 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:59:12 --> Helper loaded: date_helper
INFO - 2019-09-13 21:59:12 --> Form Validation Class Initialized
INFO - 2019-09-13 21:59:12 --> Email Class Initialized
DEBUG - 2019-09-13 21:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:59:12 --> Pagination Class Initialized
INFO - 2019-09-13 21:59:12 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:12 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:12 --> Controller Class Initialized
INFO - 2019-09-13 21:59:12 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-13 21:59:12 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-13 21:59:12 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-13 21:59:12 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-13 21:59:12 --> Final output sent to browser
DEBUG - 2019-09-13 21:59:12 --> Total execution time: 0.1491
INFO - 2019-09-13 21:59:12 --> Config Class Initialized
INFO - 2019-09-13 21:59:12 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:59:12 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:59:12 --> Utf8 Class Initialized
INFO - 2019-09-13 21:59:12 --> URI Class Initialized
INFO - 2019-09-13 21:59:12 --> Router Class Initialized
INFO - 2019-09-13 21:59:12 --> Output Class Initialized
INFO - 2019-09-13 21:59:12 --> Security Class Initialized
DEBUG - 2019-09-13 21:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:59:12 --> Input Class Initialized
INFO - 2019-09-13 21:59:12 --> Language Class Initialized
INFO - 2019-09-13 21:59:12 --> Loader Class Initialized
INFO - 2019-09-13 21:59:12 --> Helper loaded: url_helper
INFO - 2019-09-13 21:59:12 --> Helper loaded: html_helper
INFO - 2019-09-13 21:59:12 --> Helper loaded: form_helper
INFO - 2019-09-13 21:59:12 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:59:12 --> Helper loaded: date_helper
INFO - 2019-09-13 21:59:12 --> Form Validation Class Initialized
INFO - 2019-09-13 21:59:12 --> Email Class Initialized
DEBUG - 2019-09-13 21:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:59:12 --> Pagination Class Initialized
INFO - 2019-09-13 21:59:12 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:12 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:12 --> Controller Class Initialized
INFO - 2019-09-13 21:59:12 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 21:59:12 --> Final output sent to browser
DEBUG - 2019-09-13 21:59:12 --> Total execution time: 0.0571
INFO - 2019-09-13 21:59:12 --> Config Class Initialized
INFO - 2019-09-13 21:59:12 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:59:12 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:59:12 --> Utf8 Class Initialized
INFO - 2019-09-13 21:59:12 --> URI Class Initialized
INFO - 2019-09-13 21:59:12 --> Router Class Initialized
INFO - 2019-09-13 21:59:12 --> Output Class Initialized
INFO - 2019-09-13 21:59:12 --> Security Class Initialized
DEBUG - 2019-09-13 21:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:59:12 --> Input Class Initialized
INFO - 2019-09-13 21:59:12 --> Language Class Initialized
INFO - 2019-09-13 21:59:12 --> Loader Class Initialized
INFO - 2019-09-13 21:59:12 --> Helper loaded: url_helper
INFO - 2019-09-13 21:59:12 --> Helper loaded: html_helper
INFO - 2019-09-13 21:59:12 --> Helper loaded: form_helper
INFO - 2019-09-13 21:59:12 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:59:12 --> Helper loaded: date_helper
INFO - 2019-09-13 21:59:12 --> Form Validation Class Initialized
INFO - 2019-09-13 21:59:12 --> Email Class Initialized
DEBUG - 2019-09-13 21:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:59:12 --> Pagination Class Initialized
INFO - 2019-09-13 21:59:12 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:12 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:12 --> Controller Class Initialized
INFO - 2019-09-13 21:59:12 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 21:59:12 --> Final output sent to browser
DEBUG - 2019-09-13 21:59:12 --> Total execution time: 0.0751
INFO - 2019-09-13 21:59:15 --> Config Class Initialized
INFO - 2019-09-13 21:59:15 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:59:15 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:59:15 --> Utf8 Class Initialized
INFO - 2019-09-13 21:59:15 --> URI Class Initialized
INFO - 2019-09-13 21:59:15 --> Router Class Initialized
INFO - 2019-09-13 21:59:15 --> Output Class Initialized
INFO - 2019-09-13 21:59:15 --> Security Class Initialized
DEBUG - 2019-09-13 21:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:59:15 --> Input Class Initialized
INFO - 2019-09-13 21:59:15 --> Language Class Initialized
INFO - 2019-09-13 21:59:15 --> Loader Class Initialized
INFO - 2019-09-13 21:59:15 --> Helper loaded: url_helper
INFO - 2019-09-13 21:59:15 --> Helper loaded: html_helper
INFO - 2019-09-13 21:59:15 --> Helper loaded: form_helper
INFO - 2019-09-13 21:59:15 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:59:15 --> Helper loaded: date_helper
INFO - 2019-09-13 21:59:15 --> Form Validation Class Initialized
INFO - 2019-09-13 21:59:15 --> Email Class Initialized
DEBUG - 2019-09-13 21:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:59:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:59:15 --> Pagination Class Initialized
INFO - 2019-09-13 21:59:15 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:15 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:15 --> Controller Class Initialized
INFO - 2019-09-13 21:59:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-13 21:59:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-13 21:59:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-13 21:59:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-13 21:59:15 --> Final output sent to browser
DEBUG - 2019-09-13 21:59:15 --> Total execution time: 0.0598
INFO - 2019-09-13 21:59:15 --> Config Class Initialized
INFO - 2019-09-13 21:59:15 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:59:15 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:59:15 --> Utf8 Class Initialized
INFO - 2019-09-13 21:59:15 --> URI Class Initialized
INFO - 2019-09-13 21:59:15 --> Router Class Initialized
INFO - 2019-09-13 21:59:15 --> Output Class Initialized
INFO - 2019-09-13 21:59:15 --> Security Class Initialized
DEBUG - 2019-09-13 21:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:59:15 --> Input Class Initialized
INFO - 2019-09-13 21:59:15 --> Language Class Initialized
INFO - 2019-09-13 21:59:15 --> Loader Class Initialized
INFO - 2019-09-13 21:59:15 --> Helper loaded: url_helper
INFO - 2019-09-13 21:59:15 --> Helper loaded: html_helper
INFO - 2019-09-13 21:59:15 --> Helper loaded: form_helper
INFO - 2019-09-13 21:59:15 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:59:15 --> Helper loaded: date_helper
INFO - 2019-09-13 21:59:15 --> Form Validation Class Initialized
INFO - 2019-09-13 21:59:15 --> Email Class Initialized
DEBUG - 2019-09-13 21:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:59:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:59:15 --> Pagination Class Initialized
INFO - 2019-09-13 21:59:15 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:15 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:15 --> Controller Class Initialized
INFO - 2019-09-13 21:59:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 21:59:15 --> Final output sent to browser
DEBUG - 2019-09-13 21:59:15 --> Total execution time: 0.0612
INFO - 2019-09-13 21:59:15 --> Config Class Initialized
INFO - 2019-09-13 21:59:15 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:59:16 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:59:16 --> Utf8 Class Initialized
INFO - 2019-09-13 21:59:16 --> URI Class Initialized
INFO - 2019-09-13 21:59:16 --> Router Class Initialized
INFO - 2019-09-13 21:59:16 --> Output Class Initialized
INFO - 2019-09-13 21:59:16 --> Security Class Initialized
DEBUG - 2019-09-13 21:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:59:16 --> Input Class Initialized
INFO - 2019-09-13 21:59:16 --> Language Class Initialized
INFO - 2019-09-13 21:59:16 --> Loader Class Initialized
INFO - 2019-09-13 21:59:16 --> Helper loaded: url_helper
INFO - 2019-09-13 21:59:16 --> Helper loaded: html_helper
INFO - 2019-09-13 21:59:16 --> Helper loaded: form_helper
INFO - 2019-09-13 21:59:16 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:59:16 --> Helper loaded: date_helper
INFO - 2019-09-13 21:59:16 --> Form Validation Class Initialized
INFO - 2019-09-13 21:59:16 --> Email Class Initialized
DEBUG - 2019-09-13 21:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:59:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:59:16 --> Pagination Class Initialized
INFO - 2019-09-13 21:59:16 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:16 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:16 --> Controller Class Initialized
INFO - 2019-09-13 21:59:16 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 21:59:16 --> Final output sent to browser
DEBUG - 2019-09-13 21:59:16 --> Total execution time: 0.0622
INFO - 2019-09-13 21:59:29 --> Config Class Initialized
INFO - 2019-09-13 21:59:29 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:59:29 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:59:29 --> Utf8 Class Initialized
INFO - 2019-09-13 21:59:29 --> URI Class Initialized
INFO - 2019-09-13 21:59:29 --> Router Class Initialized
INFO - 2019-09-13 21:59:29 --> Output Class Initialized
INFO - 2019-09-13 21:59:29 --> Security Class Initialized
DEBUG - 2019-09-13 21:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:59:29 --> Input Class Initialized
INFO - 2019-09-13 21:59:29 --> Language Class Initialized
INFO - 2019-09-13 21:59:29 --> Loader Class Initialized
INFO - 2019-09-13 21:59:29 --> Helper loaded: url_helper
INFO - 2019-09-13 21:59:29 --> Helper loaded: html_helper
INFO - 2019-09-13 21:59:29 --> Helper loaded: form_helper
INFO - 2019-09-13 21:59:29 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:59:29 --> Helper loaded: date_helper
INFO - 2019-09-13 21:59:29 --> Form Validation Class Initialized
INFO - 2019-09-13 21:59:29 --> Email Class Initialized
DEBUG - 2019-09-13 21:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:59:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:59:29 --> Pagination Class Initialized
INFO - 2019-09-13 21:59:29 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:29 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:29 --> Controller Class Initialized
INFO - 2019-09-13 21:59:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-13 21:59:39 --> Config Class Initialized
INFO - 2019-09-13 21:59:39 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:59:39 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:59:39 --> Utf8 Class Initialized
INFO - 2019-09-13 21:59:39 --> URI Class Initialized
INFO - 2019-09-13 21:59:39 --> Router Class Initialized
INFO - 2019-09-13 21:59:39 --> Output Class Initialized
INFO - 2019-09-13 21:59:39 --> Security Class Initialized
DEBUG - 2019-09-13 21:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:59:39 --> Input Class Initialized
INFO - 2019-09-13 21:59:39 --> Language Class Initialized
INFO - 2019-09-13 21:59:39 --> Loader Class Initialized
INFO - 2019-09-13 21:59:39 --> Helper loaded: url_helper
INFO - 2019-09-13 21:59:39 --> Helper loaded: html_helper
INFO - 2019-09-13 21:59:39 --> Helper loaded: form_helper
INFO - 2019-09-13 21:59:39 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:59:39 --> Helper loaded: date_helper
INFO - 2019-09-13 21:59:39 --> Form Validation Class Initialized
INFO - 2019-09-13 21:59:39 --> Email Class Initialized
DEBUG - 2019-09-13 21:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:59:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:59:39 --> Pagination Class Initialized
INFO - 2019-09-13 21:59:39 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:39 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:39 --> Controller Class Initialized
INFO - 2019-09-13 21:59:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-13 21:59:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-13 21:59:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-13 21:59:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-13 21:59:39 --> Final output sent to browser
DEBUG - 2019-09-13 21:59:39 --> Total execution time: 0.0721
INFO - 2019-09-13 21:59:39 --> Config Class Initialized
INFO - 2019-09-13 21:59:39 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:59:39 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:59:39 --> Utf8 Class Initialized
INFO - 2019-09-13 21:59:39 --> URI Class Initialized
INFO - 2019-09-13 21:59:39 --> Router Class Initialized
INFO - 2019-09-13 21:59:39 --> Output Class Initialized
INFO - 2019-09-13 21:59:39 --> Security Class Initialized
DEBUG - 2019-09-13 21:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:59:39 --> Input Class Initialized
INFO - 2019-09-13 21:59:39 --> Language Class Initialized
INFO - 2019-09-13 21:59:39 --> Loader Class Initialized
INFO - 2019-09-13 21:59:39 --> Helper loaded: url_helper
INFO - 2019-09-13 21:59:39 --> Helper loaded: html_helper
INFO - 2019-09-13 21:59:39 --> Helper loaded: form_helper
INFO - 2019-09-13 21:59:39 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:59:39 --> Helper loaded: date_helper
INFO - 2019-09-13 21:59:39 --> Form Validation Class Initialized
INFO - 2019-09-13 21:59:39 --> Email Class Initialized
DEBUG - 2019-09-13 21:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:59:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:59:39 --> Pagination Class Initialized
INFO - 2019-09-13 21:59:39 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:39 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:39 --> Controller Class Initialized
INFO - 2019-09-13 21:59:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 21:59:39 --> Final output sent to browser
DEBUG - 2019-09-13 21:59:39 --> Total execution time: 0.0692
INFO - 2019-09-13 21:59:39 --> Config Class Initialized
INFO - 2019-09-13 21:59:39 --> Hooks Class Initialized
DEBUG - 2019-09-13 21:59:39 --> UTF-8 Support Enabled
INFO - 2019-09-13 21:59:39 --> Utf8 Class Initialized
INFO - 2019-09-13 21:59:39 --> URI Class Initialized
INFO - 2019-09-13 21:59:39 --> Router Class Initialized
INFO - 2019-09-13 21:59:39 --> Output Class Initialized
INFO - 2019-09-13 21:59:39 --> Security Class Initialized
DEBUG - 2019-09-13 21:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 21:59:39 --> Input Class Initialized
INFO - 2019-09-13 21:59:39 --> Language Class Initialized
INFO - 2019-09-13 21:59:39 --> Loader Class Initialized
INFO - 2019-09-13 21:59:39 --> Helper loaded: url_helper
INFO - 2019-09-13 21:59:39 --> Helper loaded: html_helper
INFO - 2019-09-13 21:59:39 --> Helper loaded: form_helper
INFO - 2019-09-13 21:59:39 --> Helper loaded: cookie_helper
INFO - 2019-09-13 21:59:39 --> Helper loaded: date_helper
INFO - 2019-09-13 21:59:39 --> Form Validation Class Initialized
INFO - 2019-09-13 21:59:39 --> Email Class Initialized
DEBUG - 2019-09-13 21:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 21:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 21:59:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 21:59:39 --> Pagination Class Initialized
INFO - 2019-09-13 21:59:40 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:40 --> Database Driver Class Initialized
INFO - 2019-09-13 21:59:40 --> Controller Class Initialized
INFO - 2019-09-13 21:59:40 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 21:59:40 --> Final output sent to browser
DEBUG - 2019-09-13 21:59:40 --> Total execution time: 0.0798
INFO - 2019-09-13 22:08:00 --> Config Class Initialized
INFO - 2019-09-13 22:08:00 --> Hooks Class Initialized
DEBUG - 2019-09-13 22:08:00 --> UTF-8 Support Enabled
INFO - 2019-09-13 22:08:00 --> Utf8 Class Initialized
INFO - 2019-09-13 22:08:00 --> URI Class Initialized
INFO - 2019-09-13 22:08:00 --> Router Class Initialized
INFO - 2019-09-13 22:08:00 --> Output Class Initialized
INFO - 2019-09-13 22:08:00 --> Security Class Initialized
DEBUG - 2019-09-13 22:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 22:08:00 --> Input Class Initialized
INFO - 2019-09-13 22:08:00 --> Language Class Initialized
INFO - 2019-09-13 22:08:00 --> Loader Class Initialized
INFO - 2019-09-13 22:08:00 --> Helper loaded: url_helper
INFO - 2019-09-13 22:08:00 --> Helper loaded: html_helper
INFO - 2019-09-13 22:08:00 --> Helper loaded: form_helper
INFO - 2019-09-13 22:08:00 --> Helper loaded: cookie_helper
INFO - 2019-09-13 22:08:00 --> Helper loaded: date_helper
INFO - 2019-09-13 22:08:00 --> Form Validation Class Initialized
INFO - 2019-09-13 22:08:00 --> Email Class Initialized
DEBUG - 2019-09-13 22:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 22:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 22:08:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 22:08:00 --> Pagination Class Initialized
INFO - 2019-09-13 22:08:00 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:00 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:00 --> Controller Class Initialized
INFO - 2019-09-13 22:08:00 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-13 22:08:00 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-13 22:08:00 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-13 22:08:00 --> Final output sent to browser
DEBUG - 2019-09-13 22:08:00 --> Total execution time: 0.1072
INFO - 2019-09-13 22:08:00 --> Config Class Initialized
INFO - 2019-09-13 22:08:00 --> Hooks Class Initialized
DEBUG - 2019-09-13 22:08:00 --> UTF-8 Support Enabled
INFO - 2019-09-13 22:08:00 --> Utf8 Class Initialized
INFO - 2019-09-13 22:08:00 --> URI Class Initialized
INFO - 2019-09-13 22:08:00 --> Router Class Initialized
INFO - 2019-09-13 22:08:00 --> Output Class Initialized
INFO - 2019-09-13 22:08:00 --> Security Class Initialized
DEBUG - 2019-09-13 22:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 22:08:00 --> Input Class Initialized
INFO - 2019-09-13 22:08:00 --> Language Class Initialized
INFO - 2019-09-13 22:08:00 --> Loader Class Initialized
INFO - 2019-09-13 22:08:00 --> Helper loaded: url_helper
INFO - 2019-09-13 22:08:00 --> Helper loaded: html_helper
INFO - 2019-09-13 22:08:00 --> Helper loaded: form_helper
INFO - 2019-09-13 22:08:00 --> Helper loaded: cookie_helper
INFO - 2019-09-13 22:08:00 --> Helper loaded: date_helper
INFO - 2019-09-13 22:08:00 --> Form Validation Class Initialized
INFO - 2019-09-13 22:08:00 --> Email Class Initialized
DEBUG - 2019-09-13 22:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 22:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 22:08:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 22:08:00 --> Pagination Class Initialized
INFO - 2019-09-13 22:08:00 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:00 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:00 --> Controller Class Initialized
INFO - 2019-09-13 22:08:00 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 22:08:00 --> Final output sent to browser
DEBUG - 2019-09-13 22:08:00 --> Total execution time: 0.0610
INFO - 2019-09-13 22:08:00 --> Config Class Initialized
INFO - 2019-09-13 22:08:00 --> Hooks Class Initialized
DEBUG - 2019-09-13 22:08:00 --> UTF-8 Support Enabled
INFO - 2019-09-13 22:08:00 --> Utf8 Class Initialized
INFO - 2019-09-13 22:08:00 --> URI Class Initialized
INFO - 2019-09-13 22:08:00 --> Router Class Initialized
INFO - 2019-09-13 22:08:00 --> Output Class Initialized
INFO - 2019-09-13 22:08:00 --> Security Class Initialized
DEBUG - 2019-09-13 22:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 22:08:00 --> Input Class Initialized
INFO - 2019-09-13 22:08:00 --> Language Class Initialized
INFO - 2019-09-13 22:08:00 --> Loader Class Initialized
INFO - 2019-09-13 22:08:00 --> Helper loaded: url_helper
INFO - 2019-09-13 22:08:00 --> Helper loaded: html_helper
INFO - 2019-09-13 22:08:00 --> Helper loaded: form_helper
INFO - 2019-09-13 22:08:00 --> Helper loaded: cookie_helper
INFO - 2019-09-13 22:08:00 --> Helper loaded: date_helper
INFO - 2019-09-13 22:08:00 --> Form Validation Class Initialized
INFO - 2019-09-13 22:08:00 --> Email Class Initialized
DEBUG - 2019-09-13 22:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 22:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 22:08:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 22:08:00 --> Pagination Class Initialized
INFO - 2019-09-13 22:08:00 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:00 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:00 --> Controller Class Initialized
INFO - 2019-09-13 22:08:00 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 22:08:00 --> Final output sent to browser
DEBUG - 2019-09-13 22:08:00 --> Total execution time: 0.0631
INFO - 2019-09-13 22:08:02 --> Config Class Initialized
INFO - 2019-09-13 22:08:02 --> Hooks Class Initialized
DEBUG - 2019-09-13 22:08:02 --> UTF-8 Support Enabled
INFO - 2019-09-13 22:08:02 --> Utf8 Class Initialized
INFO - 2019-09-13 22:08:02 --> URI Class Initialized
INFO - 2019-09-13 22:08:02 --> Router Class Initialized
INFO - 2019-09-13 22:08:02 --> Output Class Initialized
INFO - 2019-09-13 22:08:02 --> Security Class Initialized
DEBUG - 2019-09-13 22:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 22:08:02 --> Input Class Initialized
INFO - 2019-09-13 22:08:02 --> Language Class Initialized
INFO - 2019-09-13 22:08:02 --> Loader Class Initialized
INFO - 2019-09-13 22:08:02 --> Helper loaded: url_helper
INFO - 2019-09-13 22:08:02 --> Helper loaded: html_helper
INFO - 2019-09-13 22:08:02 --> Helper loaded: form_helper
INFO - 2019-09-13 22:08:02 --> Helper loaded: cookie_helper
INFO - 2019-09-13 22:08:02 --> Helper loaded: date_helper
INFO - 2019-09-13 22:08:02 --> Form Validation Class Initialized
INFO - 2019-09-13 22:08:02 --> Email Class Initialized
DEBUG - 2019-09-13 22:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 22:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 22:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 22:08:02 --> Pagination Class Initialized
INFO - 2019-09-13 22:08:02 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:02 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:02 --> Controller Class Initialized
INFO - 2019-09-13 22:08:02 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-13 22:08:02 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-13 22:08:02 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-13 22:08:02 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-13 22:08:02 --> Final output sent to browser
DEBUG - 2019-09-13 22:08:02 --> Total execution time: 0.0642
INFO - 2019-09-13 22:08:02 --> Config Class Initialized
INFO - 2019-09-13 22:08:02 --> Hooks Class Initialized
DEBUG - 2019-09-13 22:08:02 --> UTF-8 Support Enabled
INFO - 2019-09-13 22:08:02 --> Utf8 Class Initialized
INFO - 2019-09-13 22:08:02 --> URI Class Initialized
INFO - 2019-09-13 22:08:02 --> Router Class Initialized
INFO - 2019-09-13 22:08:02 --> Output Class Initialized
INFO - 2019-09-13 22:08:02 --> Security Class Initialized
DEBUG - 2019-09-13 22:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 22:08:02 --> Input Class Initialized
INFO - 2019-09-13 22:08:02 --> Language Class Initialized
INFO - 2019-09-13 22:08:02 --> Loader Class Initialized
INFO - 2019-09-13 22:08:02 --> Helper loaded: url_helper
INFO - 2019-09-13 22:08:02 --> Helper loaded: html_helper
INFO - 2019-09-13 22:08:02 --> Helper loaded: form_helper
INFO - 2019-09-13 22:08:02 --> Helper loaded: cookie_helper
INFO - 2019-09-13 22:08:02 --> Helper loaded: date_helper
INFO - 2019-09-13 22:08:02 --> Form Validation Class Initialized
INFO - 2019-09-13 22:08:02 --> Email Class Initialized
DEBUG - 2019-09-13 22:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 22:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 22:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 22:08:02 --> Pagination Class Initialized
INFO - 2019-09-13 22:08:02 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:02 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:02 --> Controller Class Initialized
INFO - 2019-09-13 22:08:02 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 22:08:02 --> Final output sent to browser
DEBUG - 2019-09-13 22:08:02 --> Total execution time: 0.0612
INFO - 2019-09-13 22:08:02 --> Config Class Initialized
INFO - 2019-09-13 22:08:02 --> Hooks Class Initialized
DEBUG - 2019-09-13 22:08:02 --> UTF-8 Support Enabled
INFO - 2019-09-13 22:08:02 --> Utf8 Class Initialized
INFO - 2019-09-13 22:08:02 --> URI Class Initialized
INFO - 2019-09-13 22:08:02 --> Router Class Initialized
INFO - 2019-09-13 22:08:02 --> Output Class Initialized
INFO - 2019-09-13 22:08:02 --> Security Class Initialized
DEBUG - 2019-09-13 22:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 22:08:02 --> Input Class Initialized
INFO - 2019-09-13 22:08:02 --> Language Class Initialized
INFO - 2019-09-13 22:08:02 --> Loader Class Initialized
INFO - 2019-09-13 22:08:02 --> Helper loaded: url_helper
INFO - 2019-09-13 22:08:02 --> Helper loaded: html_helper
INFO - 2019-09-13 22:08:02 --> Helper loaded: form_helper
INFO - 2019-09-13 22:08:02 --> Helper loaded: cookie_helper
INFO - 2019-09-13 22:08:02 --> Helper loaded: date_helper
INFO - 2019-09-13 22:08:02 --> Form Validation Class Initialized
INFO - 2019-09-13 22:08:02 --> Email Class Initialized
DEBUG - 2019-09-13 22:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 22:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 22:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 22:08:02 --> Pagination Class Initialized
INFO - 2019-09-13 22:08:02 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:02 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:02 --> Controller Class Initialized
INFO - 2019-09-13 22:08:02 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 22:08:02 --> Final output sent to browser
DEBUG - 2019-09-13 22:08:02 --> Total execution time: 0.0687
INFO - 2019-09-13 22:08:03 --> Config Class Initialized
INFO - 2019-09-13 22:08:03 --> Hooks Class Initialized
DEBUG - 2019-09-13 22:08:03 --> UTF-8 Support Enabled
INFO - 2019-09-13 22:08:03 --> Utf8 Class Initialized
INFO - 2019-09-13 22:08:03 --> URI Class Initialized
INFO - 2019-09-13 22:08:03 --> Router Class Initialized
INFO - 2019-09-13 22:08:03 --> Output Class Initialized
INFO - 2019-09-13 22:08:03 --> Security Class Initialized
DEBUG - 2019-09-13 22:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 22:08:03 --> Input Class Initialized
INFO - 2019-09-13 22:08:03 --> Language Class Initialized
INFO - 2019-09-13 22:08:03 --> Loader Class Initialized
INFO - 2019-09-13 22:08:03 --> Helper loaded: url_helper
INFO - 2019-09-13 22:08:03 --> Helper loaded: html_helper
INFO - 2019-09-13 22:08:03 --> Helper loaded: form_helper
INFO - 2019-09-13 22:08:03 --> Helper loaded: cookie_helper
INFO - 2019-09-13 22:08:03 --> Helper loaded: date_helper
INFO - 2019-09-13 22:08:03 --> Form Validation Class Initialized
INFO - 2019-09-13 22:08:03 --> Email Class Initialized
DEBUG - 2019-09-13 22:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 22:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 22:08:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 22:08:03 --> Pagination Class Initialized
INFO - 2019-09-13 22:08:03 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:03 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:03 --> Controller Class Initialized
INFO - 2019-09-13 22:08:03 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-13 22:08:03 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-13 22:08:03 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-13 22:08:03 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-13 22:08:03 --> Final output sent to browser
DEBUG - 2019-09-13 22:08:03 --> Total execution time: 0.0635
INFO - 2019-09-13 22:08:03 --> Config Class Initialized
INFO - 2019-09-13 22:08:03 --> Hooks Class Initialized
DEBUG - 2019-09-13 22:08:03 --> UTF-8 Support Enabled
INFO - 2019-09-13 22:08:03 --> Utf8 Class Initialized
INFO - 2019-09-13 22:08:03 --> URI Class Initialized
INFO - 2019-09-13 22:08:03 --> Router Class Initialized
INFO - 2019-09-13 22:08:03 --> Output Class Initialized
INFO - 2019-09-13 22:08:03 --> Security Class Initialized
DEBUG - 2019-09-13 22:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 22:08:03 --> Input Class Initialized
INFO - 2019-09-13 22:08:03 --> Language Class Initialized
INFO - 2019-09-13 22:08:03 --> Loader Class Initialized
INFO - 2019-09-13 22:08:03 --> Helper loaded: url_helper
INFO - 2019-09-13 22:08:03 --> Helper loaded: html_helper
INFO - 2019-09-13 22:08:03 --> Helper loaded: form_helper
INFO - 2019-09-13 22:08:03 --> Helper loaded: cookie_helper
INFO - 2019-09-13 22:08:03 --> Helper loaded: date_helper
INFO - 2019-09-13 22:08:03 --> Form Validation Class Initialized
INFO - 2019-09-13 22:08:04 --> Email Class Initialized
DEBUG - 2019-09-13 22:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 22:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 22:08:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 22:08:04 --> Pagination Class Initialized
INFO - 2019-09-13 22:08:04 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:04 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:04 --> Controller Class Initialized
INFO - 2019-09-13 22:08:04 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 22:08:04 --> Final output sent to browser
DEBUG - 2019-09-13 22:08:04 --> Total execution time: 0.0562
INFO - 2019-09-13 22:08:04 --> Config Class Initialized
INFO - 2019-09-13 22:08:04 --> Hooks Class Initialized
DEBUG - 2019-09-13 22:08:04 --> UTF-8 Support Enabled
INFO - 2019-09-13 22:08:04 --> Utf8 Class Initialized
INFO - 2019-09-13 22:08:04 --> URI Class Initialized
INFO - 2019-09-13 22:08:04 --> Router Class Initialized
INFO - 2019-09-13 22:08:04 --> Output Class Initialized
INFO - 2019-09-13 22:08:04 --> Security Class Initialized
DEBUG - 2019-09-13 22:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 22:08:04 --> Input Class Initialized
INFO - 2019-09-13 22:08:04 --> Language Class Initialized
INFO - 2019-09-13 22:08:04 --> Loader Class Initialized
INFO - 2019-09-13 22:08:04 --> Helper loaded: url_helper
INFO - 2019-09-13 22:08:04 --> Helper loaded: html_helper
INFO - 2019-09-13 22:08:04 --> Helper loaded: form_helper
INFO - 2019-09-13 22:08:04 --> Helper loaded: cookie_helper
INFO - 2019-09-13 22:08:04 --> Helper loaded: date_helper
INFO - 2019-09-13 22:08:04 --> Form Validation Class Initialized
INFO - 2019-09-13 22:08:04 --> Email Class Initialized
DEBUG - 2019-09-13 22:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 22:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 22:08:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 22:08:04 --> Pagination Class Initialized
INFO - 2019-09-13 22:08:04 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:04 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:04 --> Controller Class Initialized
INFO - 2019-09-13 22:08:04 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 22:08:04 --> Final output sent to browser
DEBUG - 2019-09-13 22:08:04 --> Total execution time: 0.0666
INFO - 2019-09-13 22:08:06 --> Config Class Initialized
INFO - 2019-09-13 22:08:06 --> Hooks Class Initialized
DEBUG - 2019-09-13 22:08:06 --> UTF-8 Support Enabled
INFO - 2019-09-13 22:08:06 --> Utf8 Class Initialized
INFO - 2019-09-13 22:08:06 --> URI Class Initialized
INFO - 2019-09-13 22:08:06 --> Router Class Initialized
INFO - 2019-09-13 22:08:06 --> Output Class Initialized
INFO - 2019-09-13 22:08:06 --> Security Class Initialized
DEBUG - 2019-09-13 22:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 22:08:06 --> Input Class Initialized
INFO - 2019-09-13 22:08:06 --> Language Class Initialized
INFO - 2019-09-13 22:08:06 --> Loader Class Initialized
INFO - 2019-09-13 22:08:06 --> Helper loaded: url_helper
INFO - 2019-09-13 22:08:06 --> Helper loaded: html_helper
INFO - 2019-09-13 22:08:06 --> Helper loaded: form_helper
INFO - 2019-09-13 22:08:06 --> Helper loaded: cookie_helper
INFO - 2019-09-13 22:08:06 --> Helper loaded: date_helper
INFO - 2019-09-13 22:08:06 --> Form Validation Class Initialized
INFO - 2019-09-13 22:08:06 --> Email Class Initialized
DEBUG - 2019-09-13 22:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 22:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 22:08:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 22:08:06 --> Pagination Class Initialized
INFO - 2019-09-13 22:08:06 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:06 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:06 --> Controller Class Initialized
INFO - 2019-09-13 22:08:06 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-13 22:08:06 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-13 22:08:06 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-13 22:08:06 --> Final output sent to browser
DEBUG - 2019-09-13 22:08:06 --> Total execution time: 0.0646
INFO - 2019-09-13 22:08:06 --> Config Class Initialized
INFO - 2019-09-13 22:08:06 --> Hooks Class Initialized
DEBUG - 2019-09-13 22:08:06 --> UTF-8 Support Enabled
INFO - 2019-09-13 22:08:06 --> Utf8 Class Initialized
INFO - 2019-09-13 22:08:06 --> URI Class Initialized
INFO - 2019-09-13 22:08:06 --> Router Class Initialized
INFO - 2019-09-13 22:08:06 --> Output Class Initialized
INFO - 2019-09-13 22:08:06 --> Security Class Initialized
DEBUG - 2019-09-13 22:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 22:08:06 --> Input Class Initialized
INFO - 2019-09-13 22:08:06 --> Language Class Initialized
INFO - 2019-09-13 22:08:06 --> Loader Class Initialized
INFO - 2019-09-13 22:08:06 --> Helper loaded: url_helper
INFO - 2019-09-13 22:08:06 --> Helper loaded: html_helper
INFO - 2019-09-13 22:08:06 --> Helper loaded: form_helper
INFO - 2019-09-13 22:08:06 --> Helper loaded: cookie_helper
INFO - 2019-09-13 22:08:06 --> Helper loaded: date_helper
INFO - 2019-09-13 22:08:06 --> Form Validation Class Initialized
INFO - 2019-09-13 22:08:06 --> Email Class Initialized
DEBUG - 2019-09-13 22:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 22:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 22:08:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 22:08:06 --> Pagination Class Initialized
INFO - 2019-09-13 22:08:06 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:06 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:06 --> Controller Class Initialized
INFO - 2019-09-13 22:08:06 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 22:08:06 --> Final output sent to browser
DEBUG - 2019-09-13 22:08:06 --> Total execution time: 0.0647
INFO - 2019-09-13 22:08:06 --> Config Class Initialized
INFO - 2019-09-13 22:08:06 --> Hooks Class Initialized
DEBUG - 2019-09-13 22:08:06 --> UTF-8 Support Enabled
INFO - 2019-09-13 22:08:06 --> Utf8 Class Initialized
INFO - 2019-09-13 22:08:06 --> URI Class Initialized
INFO - 2019-09-13 22:08:06 --> Router Class Initialized
INFO - 2019-09-13 22:08:06 --> Output Class Initialized
INFO - 2019-09-13 22:08:06 --> Security Class Initialized
DEBUG - 2019-09-13 22:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 22:08:06 --> Input Class Initialized
INFO - 2019-09-13 22:08:06 --> Language Class Initialized
INFO - 2019-09-13 22:08:06 --> Loader Class Initialized
INFO - 2019-09-13 22:08:06 --> Helper loaded: url_helper
INFO - 2019-09-13 22:08:06 --> Helper loaded: html_helper
INFO - 2019-09-13 22:08:06 --> Helper loaded: form_helper
INFO - 2019-09-13 22:08:06 --> Helper loaded: cookie_helper
INFO - 2019-09-13 22:08:06 --> Helper loaded: date_helper
INFO - 2019-09-13 22:08:06 --> Form Validation Class Initialized
INFO - 2019-09-13 22:08:06 --> Email Class Initialized
DEBUG - 2019-09-13 22:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 22:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 22:08:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 22:08:06 --> Pagination Class Initialized
INFO - 2019-09-13 22:08:06 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:06 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:06 --> Controller Class Initialized
INFO - 2019-09-13 22:08:06 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 22:08:06 --> Final output sent to browser
DEBUG - 2019-09-13 22:08:06 --> Total execution time: 0.0776
INFO - 2019-09-13 22:08:48 --> Config Class Initialized
INFO - 2019-09-13 22:08:48 --> Hooks Class Initialized
DEBUG - 2019-09-13 22:08:48 --> UTF-8 Support Enabled
INFO - 2019-09-13 22:08:48 --> Utf8 Class Initialized
INFO - 2019-09-13 22:08:48 --> URI Class Initialized
INFO - 2019-09-13 22:08:48 --> Router Class Initialized
INFO - 2019-09-13 22:08:48 --> Output Class Initialized
INFO - 2019-09-13 22:08:48 --> Security Class Initialized
DEBUG - 2019-09-13 22:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 22:08:48 --> Input Class Initialized
INFO - 2019-09-13 22:08:48 --> Language Class Initialized
INFO - 2019-09-13 22:08:48 --> Loader Class Initialized
INFO - 2019-09-13 22:08:48 --> Helper loaded: url_helper
INFO - 2019-09-13 22:08:48 --> Helper loaded: html_helper
INFO - 2019-09-13 22:08:48 --> Helper loaded: form_helper
INFO - 2019-09-13 22:08:48 --> Helper loaded: cookie_helper
INFO - 2019-09-13 22:08:48 --> Helper loaded: date_helper
INFO - 2019-09-13 22:08:48 --> Form Validation Class Initialized
INFO - 2019-09-13 22:08:48 --> Email Class Initialized
DEBUG - 2019-09-13 22:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 22:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 22:08:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 22:08:48 --> Pagination Class Initialized
INFO - 2019-09-13 22:08:48 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:48 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:48 --> Controller Class Initialized
INFO - 2019-09-13 22:08:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-13 22:08:49 --> Config Class Initialized
INFO - 2019-09-13 22:08:49 --> Hooks Class Initialized
DEBUG - 2019-09-13 22:08:49 --> UTF-8 Support Enabled
INFO - 2019-09-13 22:08:49 --> Utf8 Class Initialized
INFO - 2019-09-13 22:08:49 --> URI Class Initialized
INFO - 2019-09-13 22:08:49 --> Router Class Initialized
INFO - 2019-09-13 22:08:49 --> Output Class Initialized
INFO - 2019-09-13 22:08:49 --> Security Class Initialized
DEBUG - 2019-09-13 22:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 22:08:49 --> Input Class Initialized
INFO - 2019-09-13 22:08:49 --> Language Class Initialized
INFO - 2019-09-13 22:08:49 --> Loader Class Initialized
INFO - 2019-09-13 22:08:49 --> Helper loaded: url_helper
INFO - 2019-09-13 22:08:49 --> Helper loaded: html_helper
INFO - 2019-09-13 22:08:49 --> Helper loaded: form_helper
INFO - 2019-09-13 22:08:49 --> Helper loaded: cookie_helper
INFO - 2019-09-13 22:08:49 --> Helper loaded: date_helper
INFO - 2019-09-13 22:08:49 --> Form Validation Class Initialized
INFO - 2019-09-13 22:08:49 --> Email Class Initialized
DEBUG - 2019-09-13 22:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 22:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 22:08:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 22:08:49 --> Pagination Class Initialized
INFO - 2019-09-13 22:08:49 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:49 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:49 --> Controller Class Initialized
INFO - 2019-09-13 22:08:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-13 22:08:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-13 22:08:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-13 22:08:49 --> Final output sent to browser
DEBUG - 2019-09-13 22:08:49 --> Total execution time: 0.0649
INFO - 2019-09-13 22:08:49 --> Config Class Initialized
INFO - 2019-09-13 22:08:49 --> Hooks Class Initialized
DEBUG - 2019-09-13 22:08:49 --> UTF-8 Support Enabled
INFO - 2019-09-13 22:08:49 --> Utf8 Class Initialized
INFO - 2019-09-13 22:08:49 --> URI Class Initialized
INFO - 2019-09-13 22:08:49 --> Router Class Initialized
INFO - 2019-09-13 22:08:49 --> Output Class Initialized
INFO - 2019-09-13 22:08:50 --> Security Class Initialized
DEBUG - 2019-09-13 22:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 22:08:50 --> Input Class Initialized
INFO - 2019-09-13 22:08:50 --> Language Class Initialized
INFO - 2019-09-13 22:08:50 --> Loader Class Initialized
INFO - 2019-09-13 22:08:50 --> Helper loaded: url_helper
INFO - 2019-09-13 22:08:50 --> Helper loaded: html_helper
INFO - 2019-09-13 22:08:50 --> Helper loaded: form_helper
INFO - 2019-09-13 22:08:50 --> Helper loaded: cookie_helper
INFO - 2019-09-13 22:08:50 --> Helper loaded: date_helper
INFO - 2019-09-13 22:08:50 --> Form Validation Class Initialized
INFO - 2019-09-13 22:08:50 --> Email Class Initialized
DEBUG - 2019-09-13 22:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 22:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 22:08:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 22:08:50 --> Pagination Class Initialized
INFO - 2019-09-13 22:08:50 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:50 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:50 --> Controller Class Initialized
INFO - 2019-09-13 22:08:50 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 22:08:50 --> Final output sent to browser
DEBUG - 2019-09-13 22:08:50 --> Total execution time: 0.2457
INFO - 2019-09-13 22:08:50 --> Config Class Initialized
INFO - 2019-09-13 22:08:50 --> Hooks Class Initialized
DEBUG - 2019-09-13 22:08:50 --> UTF-8 Support Enabled
INFO - 2019-09-13 22:08:50 --> Utf8 Class Initialized
INFO - 2019-09-13 22:08:50 --> URI Class Initialized
INFO - 2019-09-13 22:08:50 --> Router Class Initialized
INFO - 2019-09-13 22:08:50 --> Output Class Initialized
INFO - 2019-09-13 22:08:50 --> Security Class Initialized
DEBUG - 2019-09-13 22:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-13 22:08:50 --> Input Class Initialized
INFO - 2019-09-13 22:08:50 --> Language Class Initialized
INFO - 2019-09-13 22:08:50 --> Loader Class Initialized
INFO - 2019-09-13 22:08:50 --> Helper loaded: url_helper
INFO - 2019-09-13 22:08:50 --> Helper loaded: html_helper
INFO - 2019-09-13 22:08:50 --> Helper loaded: form_helper
INFO - 2019-09-13 22:08:50 --> Helper loaded: cookie_helper
INFO - 2019-09-13 22:08:50 --> Helper loaded: date_helper
INFO - 2019-09-13 22:08:50 --> Form Validation Class Initialized
INFO - 2019-09-13 22:08:50 --> Email Class Initialized
DEBUG - 2019-09-13 22:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-13 22:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-13 22:08:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-13 22:08:50 --> Pagination Class Initialized
INFO - 2019-09-13 22:08:50 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:50 --> Database Driver Class Initialized
INFO - 2019-09-13 22:08:50 --> Controller Class Initialized
INFO - 2019-09-13 22:08:50 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-13 22:08:50 --> Final output sent to browser
DEBUG - 2019-09-13 22:08:50 --> Total execution time: 0.0609
