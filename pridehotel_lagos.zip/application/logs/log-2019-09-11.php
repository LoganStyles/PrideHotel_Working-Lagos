<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-11 05:26:49 --> Config Class Initialized
INFO - 2019-09-11 05:26:49 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:26:49 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:26:49 --> Utf8 Class Initialized
INFO - 2019-09-11 05:26:49 --> URI Class Initialized
INFO - 2019-09-11 05:26:49 --> Router Class Initialized
INFO - 2019-09-11 05:26:49 --> Output Class Initialized
INFO - 2019-09-11 05:26:49 --> Security Class Initialized
DEBUG - 2019-09-11 05:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:26:49 --> Input Class Initialized
INFO - 2019-09-11 05:26:49 --> Language Class Initialized
INFO - 2019-09-11 05:26:49 --> Loader Class Initialized
INFO - 2019-09-11 05:26:49 --> Helper loaded: url_helper
INFO - 2019-09-11 05:26:49 --> Helper loaded: html_helper
INFO - 2019-09-11 05:26:49 --> Helper loaded: form_helper
INFO - 2019-09-11 05:26:49 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:26:49 --> Helper loaded: date_helper
INFO - 2019-09-11 05:26:49 --> Form Validation Class Initialized
INFO - 2019-09-11 05:26:49 --> Email Class Initialized
DEBUG - 2019-09-11 05:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:26:49 --> Pagination Class Initialized
INFO - 2019-09-11 05:26:49 --> Database Driver Class Initialized
INFO - 2019-09-11 05:26:49 --> Database Driver Class Initialized
INFO - 2019-09-11 05:26:49 --> Controller Class Initialized
INFO - 2019-09-11 05:26:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-11 05:26:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-11 05:26:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-11 05:26:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-11 05:26:49 --> Final output sent to browser
DEBUG - 2019-09-11 05:26:49 --> Total execution time: 0.3793
INFO - 2019-09-11 05:26:50 --> Config Class Initialized
INFO - 2019-09-11 05:26:50 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:26:50 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:26:50 --> Utf8 Class Initialized
INFO - 2019-09-11 05:26:50 --> URI Class Initialized
INFO - 2019-09-11 05:26:50 --> Router Class Initialized
INFO - 2019-09-11 05:26:50 --> Output Class Initialized
INFO - 2019-09-11 05:26:50 --> Security Class Initialized
DEBUG - 2019-09-11 05:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:26:50 --> Input Class Initialized
INFO - 2019-09-11 05:26:50 --> Language Class Initialized
INFO - 2019-09-11 05:26:50 --> Loader Class Initialized
INFO - 2019-09-11 05:26:50 --> Helper loaded: url_helper
INFO - 2019-09-11 05:26:50 --> Helper loaded: html_helper
INFO - 2019-09-11 05:26:50 --> Helper loaded: form_helper
INFO - 2019-09-11 05:26:50 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:26:50 --> Helper loaded: date_helper
INFO - 2019-09-11 05:26:50 --> Form Validation Class Initialized
INFO - 2019-09-11 05:26:50 --> Email Class Initialized
DEBUG - 2019-09-11 05:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:26:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:26:50 --> Pagination Class Initialized
INFO - 2019-09-11 05:26:50 --> Database Driver Class Initialized
INFO - 2019-09-11 05:26:50 --> Database Driver Class Initialized
INFO - 2019-09-11 05:26:50 --> Controller Class Initialized
INFO - 2019-09-11 05:26:50 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 05:26:50 --> Final output sent to browser
DEBUG - 2019-09-11 05:26:50 --> Total execution time: 0.0626
INFO - 2019-09-11 05:26:50 --> Config Class Initialized
INFO - 2019-09-11 05:26:50 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:26:50 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:26:50 --> Utf8 Class Initialized
INFO - 2019-09-11 05:26:50 --> URI Class Initialized
INFO - 2019-09-11 05:26:50 --> Router Class Initialized
INFO - 2019-09-11 05:26:50 --> Output Class Initialized
INFO - 2019-09-11 05:26:50 --> Security Class Initialized
DEBUG - 2019-09-11 05:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:26:50 --> Input Class Initialized
INFO - 2019-09-11 05:26:50 --> Language Class Initialized
INFO - 2019-09-11 05:26:50 --> Loader Class Initialized
INFO - 2019-09-11 05:26:50 --> Helper loaded: url_helper
INFO - 2019-09-11 05:26:50 --> Helper loaded: html_helper
INFO - 2019-09-11 05:26:50 --> Helper loaded: form_helper
INFO - 2019-09-11 05:26:50 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:26:50 --> Helper loaded: date_helper
INFO - 2019-09-11 05:26:50 --> Form Validation Class Initialized
INFO - 2019-09-11 05:26:50 --> Email Class Initialized
DEBUG - 2019-09-11 05:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:26:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:26:50 --> Pagination Class Initialized
INFO - 2019-09-11 05:26:50 --> Database Driver Class Initialized
INFO - 2019-09-11 05:26:50 --> Database Driver Class Initialized
INFO - 2019-09-11 05:26:50 --> Controller Class Initialized
INFO - 2019-09-11 05:26:50 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 05:26:50 --> Final output sent to browser
DEBUG - 2019-09-11 05:26:50 --> Total execution time: 0.0647
INFO - 2019-09-11 05:26:51 --> Config Class Initialized
INFO - 2019-09-11 05:26:51 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:26:51 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:26:51 --> Utf8 Class Initialized
INFO - 2019-09-11 05:26:51 --> URI Class Initialized
INFO - 2019-09-11 05:26:51 --> Router Class Initialized
INFO - 2019-09-11 05:26:51 --> Output Class Initialized
INFO - 2019-09-11 05:26:51 --> Security Class Initialized
DEBUG - 2019-09-11 05:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:26:51 --> Input Class Initialized
INFO - 2019-09-11 05:26:51 --> Language Class Initialized
INFO - 2019-09-11 05:26:51 --> Loader Class Initialized
INFO - 2019-09-11 05:26:51 --> Helper loaded: url_helper
INFO - 2019-09-11 05:26:51 --> Helper loaded: html_helper
INFO - 2019-09-11 05:26:51 --> Helper loaded: form_helper
INFO - 2019-09-11 05:26:51 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:26:51 --> Helper loaded: date_helper
INFO - 2019-09-11 05:26:51 --> Form Validation Class Initialized
INFO - 2019-09-11 05:26:51 --> Email Class Initialized
DEBUG - 2019-09-11 05:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:26:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:26:51 --> Pagination Class Initialized
INFO - 2019-09-11 05:26:51 --> Database Driver Class Initialized
INFO - 2019-09-11 05:26:51 --> Database Driver Class Initialized
INFO - 2019-09-11 05:26:51 --> Controller Class Initialized
INFO - 2019-09-11 05:26:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 05:26:51 --> Final output sent to browser
DEBUG - 2019-09-11 05:26:51 --> Total execution time: 0.0601
INFO - 2019-09-11 05:26:54 --> Config Class Initialized
INFO - 2019-09-11 05:26:54 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:26:54 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:26:54 --> Utf8 Class Initialized
INFO - 2019-09-11 05:26:54 --> URI Class Initialized
INFO - 2019-09-11 05:26:54 --> Router Class Initialized
INFO - 2019-09-11 05:26:54 --> Output Class Initialized
INFO - 2019-09-11 05:26:54 --> Security Class Initialized
DEBUG - 2019-09-11 05:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:26:54 --> Input Class Initialized
INFO - 2019-09-11 05:26:54 --> Language Class Initialized
INFO - 2019-09-11 05:26:54 --> Loader Class Initialized
INFO - 2019-09-11 05:26:54 --> Helper loaded: url_helper
INFO - 2019-09-11 05:26:54 --> Helper loaded: html_helper
INFO - 2019-09-11 05:26:54 --> Helper loaded: form_helper
INFO - 2019-09-11 05:26:54 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:26:54 --> Helper loaded: date_helper
INFO - 2019-09-11 05:26:54 --> Form Validation Class Initialized
INFO - 2019-09-11 05:26:54 --> Email Class Initialized
DEBUG - 2019-09-11 05:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:26:54 --> Pagination Class Initialized
INFO - 2019-09-11 05:26:54 --> Database Driver Class Initialized
INFO - 2019-09-11 05:26:54 --> Database Driver Class Initialized
INFO - 2019-09-11 05:26:54 --> Controller Class Initialized
INFO - 2019-09-11 05:26:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-11 05:26:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-11 05:26:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-11 05:26:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-11 05:26:54 --> Final output sent to browser
DEBUG - 2019-09-11 05:26:54 --> Total execution time: 0.0653
INFO - 2019-09-11 05:26:54 --> Config Class Initialized
INFO - 2019-09-11 05:26:54 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:26:54 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:26:54 --> Utf8 Class Initialized
INFO - 2019-09-11 05:26:54 --> URI Class Initialized
INFO - 2019-09-11 05:26:54 --> Router Class Initialized
INFO - 2019-09-11 05:26:54 --> Output Class Initialized
INFO - 2019-09-11 05:26:54 --> Security Class Initialized
DEBUG - 2019-09-11 05:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:26:54 --> Input Class Initialized
INFO - 2019-09-11 05:26:54 --> Language Class Initialized
INFO - 2019-09-11 05:26:54 --> Loader Class Initialized
INFO - 2019-09-11 05:26:54 --> Helper loaded: url_helper
INFO - 2019-09-11 05:26:54 --> Helper loaded: html_helper
INFO - 2019-09-11 05:26:54 --> Helper loaded: form_helper
INFO - 2019-09-11 05:26:54 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:26:54 --> Helper loaded: date_helper
INFO - 2019-09-11 05:26:54 --> Form Validation Class Initialized
INFO - 2019-09-11 05:26:54 --> Email Class Initialized
DEBUG - 2019-09-11 05:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:26:54 --> Pagination Class Initialized
INFO - 2019-09-11 05:26:54 --> Database Driver Class Initialized
INFO - 2019-09-11 05:26:54 --> Database Driver Class Initialized
INFO - 2019-09-11 05:26:54 --> Controller Class Initialized
INFO - 2019-09-11 05:26:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 05:26:54 --> Final output sent to browser
DEBUG - 2019-09-11 05:26:54 --> Total execution time: 0.0633
INFO - 2019-09-11 05:26:54 --> Config Class Initialized
INFO - 2019-09-11 05:26:54 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:26:54 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:26:54 --> Utf8 Class Initialized
INFO - 2019-09-11 05:26:54 --> URI Class Initialized
INFO - 2019-09-11 05:26:54 --> Router Class Initialized
INFO - 2019-09-11 05:26:54 --> Output Class Initialized
INFO - 2019-09-11 05:26:54 --> Security Class Initialized
DEBUG - 2019-09-11 05:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:26:54 --> Input Class Initialized
INFO - 2019-09-11 05:26:54 --> Language Class Initialized
INFO - 2019-09-11 05:26:54 --> Loader Class Initialized
INFO - 2019-09-11 05:26:54 --> Helper loaded: url_helper
INFO - 2019-09-11 05:26:54 --> Helper loaded: html_helper
INFO - 2019-09-11 05:26:54 --> Helper loaded: form_helper
INFO - 2019-09-11 05:26:54 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:26:54 --> Helper loaded: date_helper
INFO - 2019-09-11 05:26:54 --> Form Validation Class Initialized
INFO - 2019-09-11 05:26:54 --> Email Class Initialized
DEBUG - 2019-09-11 05:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:26:54 --> Pagination Class Initialized
INFO - 2019-09-11 05:26:54 --> Database Driver Class Initialized
INFO - 2019-09-11 05:26:54 --> Database Driver Class Initialized
INFO - 2019-09-11 05:26:54 --> Controller Class Initialized
INFO - 2019-09-11 05:26:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 05:26:54 --> Final output sent to browser
DEBUG - 2019-09-11 05:26:54 --> Total execution time: 0.0693
INFO - 2019-09-11 05:27:00 --> Config Class Initialized
INFO - 2019-09-11 05:27:00 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:27:00 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:27:00 --> Utf8 Class Initialized
INFO - 2019-09-11 05:27:00 --> URI Class Initialized
INFO - 2019-09-11 05:27:00 --> Router Class Initialized
INFO - 2019-09-11 05:27:00 --> Output Class Initialized
INFO - 2019-09-11 05:27:00 --> Security Class Initialized
DEBUG - 2019-09-11 05:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:27:00 --> Input Class Initialized
INFO - 2019-09-11 05:27:00 --> Language Class Initialized
INFO - 2019-09-11 05:27:00 --> Loader Class Initialized
INFO - 2019-09-11 05:27:00 --> Helper loaded: url_helper
INFO - 2019-09-11 05:27:00 --> Helper loaded: html_helper
INFO - 2019-09-11 05:27:00 --> Helper loaded: form_helper
INFO - 2019-09-11 05:27:00 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:27:00 --> Helper loaded: date_helper
INFO - 2019-09-11 05:27:00 --> Form Validation Class Initialized
INFO - 2019-09-11 05:27:00 --> Email Class Initialized
DEBUG - 2019-09-11 05:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:27:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:27:00 --> Pagination Class Initialized
INFO - 2019-09-11 05:27:00 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:00 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:00 --> Controller Class Initialized
ERROR - 2019-09-11 05:27:00 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-11 05:27:00 --> Config Class Initialized
INFO - 2019-09-11 05:27:00 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:27:00 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:27:00 --> Utf8 Class Initialized
INFO - 2019-09-11 05:27:00 --> URI Class Initialized
INFO - 2019-09-11 05:27:00 --> Router Class Initialized
INFO - 2019-09-11 05:27:00 --> Output Class Initialized
INFO - 2019-09-11 05:27:00 --> Security Class Initialized
DEBUG - 2019-09-11 05:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:27:00 --> Input Class Initialized
INFO - 2019-09-11 05:27:00 --> Language Class Initialized
INFO - 2019-09-11 05:27:00 --> Loader Class Initialized
INFO - 2019-09-11 05:27:00 --> Helper loaded: url_helper
INFO - 2019-09-11 05:27:00 --> Helper loaded: html_helper
INFO - 2019-09-11 05:27:00 --> Helper loaded: form_helper
INFO - 2019-09-11 05:27:00 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:27:00 --> Helper loaded: date_helper
INFO - 2019-09-11 05:27:00 --> Form Validation Class Initialized
INFO - 2019-09-11 05:27:00 --> Email Class Initialized
DEBUG - 2019-09-11 05:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:27:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:27:00 --> Pagination Class Initialized
INFO - 2019-09-11 05:27:00 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:00 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:00 --> Controller Class Initialized
ERROR - 2019-09-11 05:27:00 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-11 05:27:00 --> Config Class Initialized
INFO - 2019-09-11 05:27:00 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:27:00 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:27:00 --> Utf8 Class Initialized
INFO - 2019-09-11 05:27:00 --> URI Class Initialized
INFO - 2019-09-11 05:27:00 --> Router Class Initialized
INFO - 2019-09-11 05:27:00 --> Output Class Initialized
INFO - 2019-09-11 05:27:00 --> Security Class Initialized
DEBUG - 2019-09-11 05:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:27:00 --> Input Class Initialized
INFO - 2019-09-11 05:27:00 --> Language Class Initialized
INFO - 2019-09-11 05:27:00 --> Loader Class Initialized
INFO - 2019-09-11 05:27:00 --> Helper loaded: url_helper
INFO - 2019-09-11 05:27:00 --> Helper loaded: html_helper
INFO - 2019-09-11 05:27:00 --> Helper loaded: form_helper
INFO - 2019-09-11 05:27:00 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:27:00 --> Helper loaded: date_helper
INFO - 2019-09-11 05:27:00 --> Form Validation Class Initialized
INFO - 2019-09-11 05:27:00 --> Email Class Initialized
DEBUG - 2019-09-11 05:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:27:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:27:00 --> Pagination Class Initialized
INFO - 2019-09-11 05:27:00 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:00 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:00 --> Controller Class Initialized
ERROR - 2019-09-11 05:27:00 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-11 05:27:00 --> Config Class Initialized
INFO - 2019-09-11 05:27:00 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:27:00 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:27:00 --> Utf8 Class Initialized
INFO - 2019-09-11 05:27:00 --> URI Class Initialized
INFO - 2019-09-11 05:27:00 --> Router Class Initialized
INFO - 2019-09-11 05:27:00 --> Output Class Initialized
INFO - 2019-09-11 05:27:01 --> Security Class Initialized
DEBUG - 2019-09-11 05:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:27:01 --> Input Class Initialized
INFO - 2019-09-11 05:27:01 --> Language Class Initialized
INFO - 2019-09-11 05:27:01 --> Loader Class Initialized
INFO - 2019-09-11 05:27:01 --> Helper loaded: url_helper
INFO - 2019-09-11 05:27:01 --> Helper loaded: html_helper
INFO - 2019-09-11 05:27:01 --> Helper loaded: form_helper
INFO - 2019-09-11 05:27:01 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:27:01 --> Helper loaded: date_helper
INFO - 2019-09-11 05:27:01 --> Form Validation Class Initialized
INFO - 2019-09-11 05:27:01 --> Email Class Initialized
DEBUG - 2019-09-11 05:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:27:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:27:01 --> Pagination Class Initialized
INFO - 2019-09-11 05:27:01 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:01 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:01 --> Controller Class Initialized
ERROR - 2019-09-11 05:27:01 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-11 05:27:01 --> Config Class Initialized
INFO - 2019-09-11 05:27:01 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:27:01 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:27:01 --> Utf8 Class Initialized
INFO - 2019-09-11 05:27:01 --> URI Class Initialized
INFO - 2019-09-11 05:27:01 --> Router Class Initialized
INFO - 2019-09-11 05:27:01 --> Output Class Initialized
INFO - 2019-09-11 05:27:01 --> Security Class Initialized
DEBUG - 2019-09-11 05:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:27:01 --> Input Class Initialized
INFO - 2019-09-11 05:27:01 --> Language Class Initialized
INFO - 2019-09-11 05:27:01 --> Loader Class Initialized
INFO - 2019-09-11 05:27:01 --> Helper loaded: url_helper
INFO - 2019-09-11 05:27:01 --> Helper loaded: html_helper
INFO - 2019-09-11 05:27:01 --> Helper loaded: form_helper
INFO - 2019-09-11 05:27:01 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:27:01 --> Helper loaded: date_helper
INFO - 2019-09-11 05:27:01 --> Form Validation Class Initialized
INFO - 2019-09-11 05:27:01 --> Email Class Initialized
DEBUG - 2019-09-11 05:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:27:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:27:01 --> Pagination Class Initialized
INFO - 2019-09-11 05:27:01 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:01 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:01 --> Controller Class Initialized
ERROR - 2019-09-11 05:27:01 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-11 05:27:01 --> Config Class Initialized
INFO - 2019-09-11 05:27:01 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:27:01 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:27:01 --> Utf8 Class Initialized
INFO - 2019-09-11 05:27:01 --> URI Class Initialized
INFO - 2019-09-11 05:27:01 --> Router Class Initialized
INFO - 2019-09-11 05:27:01 --> Output Class Initialized
INFO - 2019-09-11 05:27:01 --> Security Class Initialized
DEBUG - 2019-09-11 05:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:27:01 --> Input Class Initialized
INFO - 2019-09-11 05:27:01 --> Language Class Initialized
INFO - 2019-09-11 05:27:01 --> Loader Class Initialized
INFO - 2019-09-11 05:27:01 --> Helper loaded: url_helper
INFO - 2019-09-11 05:27:01 --> Helper loaded: html_helper
INFO - 2019-09-11 05:27:01 --> Helper loaded: form_helper
INFO - 2019-09-11 05:27:01 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:27:01 --> Helper loaded: date_helper
INFO - 2019-09-11 05:27:01 --> Form Validation Class Initialized
INFO - 2019-09-11 05:27:01 --> Email Class Initialized
DEBUG - 2019-09-11 05:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:27:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:27:01 --> Pagination Class Initialized
INFO - 2019-09-11 05:27:01 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:01 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:01 --> Controller Class Initialized
ERROR - 2019-09-11 05:27:01 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-11 05:27:06 --> Config Class Initialized
INFO - 2019-09-11 05:27:06 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:27:06 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:27:06 --> Utf8 Class Initialized
INFO - 2019-09-11 05:27:06 --> URI Class Initialized
INFO - 2019-09-11 05:27:06 --> Router Class Initialized
INFO - 2019-09-11 05:27:06 --> Output Class Initialized
INFO - 2019-09-11 05:27:06 --> Security Class Initialized
DEBUG - 2019-09-11 05:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:27:06 --> Input Class Initialized
INFO - 2019-09-11 05:27:06 --> Language Class Initialized
INFO - 2019-09-11 05:27:06 --> Loader Class Initialized
INFO - 2019-09-11 05:27:06 --> Helper loaded: url_helper
INFO - 2019-09-11 05:27:06 --> Helper loaded: html_helper
INFO - 2019-09-11 05:27:06 --> Helper loaded: form_helper
INFO - 2019-09-11 05:27:06 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:27:06 --> Helper loaded: date_helper
INFO - 2019-09-11 05:27:06 --> Form Validation Class Initialized
INFO - 2019-09-11 05:27:06 --> Email Class Initialized
DEBUG - 2019-09-11 05:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:27:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:27:06 --> Pagination Class Initialized
INFO - 2019-09-11 05:27:06 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:06 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:06 --> Controller Class Initialized
INFO - 2019-09-11 05:27:06 --> Final output sent to browser
DEBUG - 2019-09-11 05:27:06 --> Total execution time: 0.1226
INFO - 2019-09-11 05:27:09 --> Config Class Initialized
INFO - 2019-09-11 05:27:09 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:27:09 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:27:09 --> Utf8 Class Initialized
INFO - 2019-09-11 05:27:09 --> URI Class Initialized
INFO - 2019-09-11 05:27:09 --> Router Class Initialized
INFO - 2019-09-11 05:27:09 --> Output Class Initialized
INFO - 2019-09-11 05:27:09 --> Security Class Initialized
DEBUG - 2019-09-11 05:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:27:09 --> Input Class Initialized
INFO - 2019-09-11 05:27:09 --> Language Class Initialized
INFO - 2019-09-11 05:27:09 --> Loader Class Initialized
INFO - 2019-09-11 05:27:09 --> Helper loaded: url_helper
INFO - 2019-09-11 05:27:09 --> Helper loaded: html_helper
INFO - 2019-09-11 05:27:09 --> Helper loaded: form_helper
INFO - 2019-09-11 05:27:09 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:27:09 --> Helper loaded: date_helper
INFO - 2019-09-11 05:27:09 --> Form Validation Class Initialized
INFO - 2019-09-11 05:27:09 --> Email Class Initialized
DEBUG - 2019-09-11 05:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:27:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:27:09 --> Pagination Class Initialized
INFO - 2019-09-11 05:27:09 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:09 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:09 --> Controller Class Initialized
INFO - 2019-09-11 05:27:09 --> Final output sent to browser
DEBUG - 2019-09-11 05:27:09 --> Total execution time: 0.1081
INFO - 2019-09-11 05:27:14 --> Config Class Initialized
INFO - 2019-09-11 05:27:14 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:27:14 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:27:14 --> Utf8 Class Initialized
INFO - 2019-09-11 05:27:14 --> URI Class Initialized
INFO - 2019-09-11 05:27:14 --> Router Class Initialized
INFO - 2019-09-11 05:27:14 --> Output Class Initialized
INFO - 2019-09-11 05:27:14 --> Security Class Initialized
DEBUG - 2019-09-11 05:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:27:14 --> Input Class Initialized
INFO - 2019-09-11 05:27:14 --> Language Class Initialized
INFO - 2019-09-11 05:27:14 --> Loader Class Initialized
INFO - 2019-09-11 05:27:14 --> Helper loaded: url_helper
INFO - 2019-09-11 05:27:14 --> Helper loaded: html_helper
INFO - 2019-09-11 05:27:14 --> Helper loaded: form_helper
INFO - 2019-09-11 05:27:14 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:27:14 --> Helper loaded: date_helper
INFO - 2019-09-11 05:27:14 --> Form Validation Class Initialized
INFO - 2019-09-11 05:27:14 --> Email Class Initialized
DEBUG - 2019-09-11 05:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:27:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:27:14 --> Pagination Class Initialized
INFO - 2019-09-11 05:27:14 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:14 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:14 --> Controller Class Initialized
INFO - 2019-09-11 05:27:14 --> Final output sent to browser
DEBUG - 2019-09-11 05:27:14 --> Total execution time: 0.0548
INFO - 2019-09-11 05:27:25 --> Config Class Initialized
INFO - 2019-09-11 05:27:25 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:27:25 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:27:25 --> Utf8 Class Initialized
INFO - 2019-09-11 05:27:25 --> URI Class Initialized
INFO - 2019-09-11 05:27:25 --> Router Class Initialized
INFO - 2019-09-11 05:27:25 --> Output Class Initialized
INFO - 2019-09-11 05:27:25 --> Security Class Initialized
DEBUG - 2019-09-11 05:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:27:25 --> Input Class Initialized
INFO - 2019-09-11 05:27:25 --> Language Class Initialized
INFO - 2019-09-11 05:27:25 --> Loader Class Initialized
INFO - 2019-09-11 05:27:25 --> Helper loaded: url_helper
INFO - 2019-09-11 05:27:25 --> Helper loaded: html_helper
INFO - 2019-09-11 05:27:25 --> Helper loaded: form_helper
INFO - 2019-09-11 05:27:25 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:27:25 --> Helper loaded: date_helper
INFO - 2019-09-11 05:27:25 --> Form Validation Class Initialized
INFO - 2019-09-11 05:27:25 --> Email Class Initialized
DEBUG - 2019-09-11 05:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:27:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:27:25 --> Pagination Class Initialized
INFO - 2019-09-11 05:27:25 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:25 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:25 --> Controller Class Initialized
INFO - 2019-09-11 05:27:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-11 05:27:25 --> Config Class Initialized
INFO - 2019-09-11 05:27:25 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:27:25 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:27:25 --> Utf8 Class Initialized
INFO - 2019-09-11 05:27:25 --> URI Class Initialized
INFO - 2019-09-11 05:27:25 --> Router Class Initialized
INFO - 2019-09-11 05:27:25 --> Output Class Initialized
INFO - 2019-09-11 05:27:25 --> Security Class Initialized
DEBUG - 2019-09-11 05:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:27:25 --> Input Class Initialized
INFO - 2019-09-11 05:27:25 --> Language Class Initialized
INFO - 2019-09-11 05:27:25 --> Loader Class Initialized
INFO - 2019-09-11 05:27:25 --> Helper loaded: url_helper
INFO - 2019-09-11 05:27:25 --> Helper loaded: html_helper
INFO - 2019-09-11 05:27:25 --> Helper loaded: form_helper
INFO - 2019-09-11 05:27:25 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:27:25 --> Helper loaded: date_helper
INFO - 2019-09-11 05:27:25 --> Form Validation Class Initialized
INFO - 2019-09-11 05:27:25 --> Email Class Initialized
DEBUG - 2019-09-11 05:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:27:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:27:25 --> Pagination Class Initialized
INFO - 2019-09-11 05:27:25 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:25 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:25 --> Controller Class Initialized
INFO - 2019-09-11 05:27:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-11 05:27:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-11 05:27:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/checkin.php
INFO - 2019-09-11 05:27:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-11 05:27:25 --> Final output sent to browser
DEBUG - 2019-09-11 05:27:25 --> Total execution time: 0.0554
INFO - 2019-09-11 05:27:25 --> Config Class Initialized
INFO - 2019-09-11 05:27:25 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:27:25 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:27:25 --> Utf8 Class Initialized
INFO - 2019-09-11 05:27:25 --> URI Class Initialized
INFO - 2019-09-11 05:27:25 --> Router Class Initialized
INFO - 2019-09-11 05:27:25 --> Output Class Initialized
INFO - 2019-09-11 05:27:25 --> Security Class Initialized
DEBUG - 2019-09-11 05:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:27:25 --> Input Class Initialized
INFO - 2019-09-11 05:27:25 --> Language Class Initialized
INFO - 2019-09-11 05:27:25 --> Loader Class Initialized
INFO - 2019-09-11 05:27:25 --> Helper loaded: url_helper
INFO - 2019-09-11 05:27:25 --> Helper loaded: html_helper
INFO - 2019-09-11 05:27:25 --> Helper loaded: form_helper
INFO - 2019-09-11 05:27:25 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:27:25 --> Helper loaded: date_helper
INFO - 2019-09-11 05:27:25 --> Form Validation Class Initialized
INFO - 2019-09-11 05:27:25 --> Email Class Initialized
DEBUG - 2019-09-11 05:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:27:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:27:25 --> Pagination Class Initialized
INFO - 2019-09-11 05:27:25 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:25 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:25 --> Controller Class Initialized
INFO - 2019-09-11 05:27:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 05:27:25 --> Final output sent to browser
DEBUG - 2019-09-11 05:27:25 --> Total execution time: 0.0523
INFO - 2019-09-11 05:27:25 --> Config Class Initialized
INFO - 2019-09-11 05:27:25 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:27:25 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:27:25 --> Utf8 Class Initialized
INFO - 2019-09-11 05:27:25 --> URI Class Initialized
INFO - 2019-09-11 05:27:25 --> Router Class Initialized
INFO - 2019-09-11 05:27:25 --> Output Class Initialized
INFO - 2019-09-11 05:27:25 --> Security Class Initialized
DEBUG - 2019-09-11 05:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:27:25 --> Input Class Initialized
INFO - 2019-09-11 05:27:25 --> Language Class Initialized
INFO - 2019-09-11 05:27:25 --> Loader Class Initialized
INFO - 2019-09-11 05:27:25 --> Helper loaded: url_helper
INFO - 2019-09-11 05:27:25 --> Helper loaded: html_helper
INFO - 2019-09-11 05:27:25 --> Helper loaded: form_helper
INFO - 2019-09-11 05:27:25 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:27:25 --> Helper loaded: date_helper
INFO - 2019-09-11 05:27:25 --> Form Validation Class Initialized
INFO - 2019-09-11 05:27:25 --> Email Class Initialized
DEBUG - 2019-09-11 05:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:27:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:27:25 --> Pagination Class Initialized
INFO - 2019-09-11 05:27:25 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:25 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:25 --> Controller Class Initialized
INFO - 2019-09-11 05:27:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 05:27:25 --> Final output sent to browser
DEBUG - 2019-09-11 05:27:25 --> Total execution time: 0.0520
INFO - 2019-09-11 05:27:28 --> Config Class Initialized
INFO - 2019-09-11 05:27:28 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:27:28 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:27:28 --> Utf8 Class Initialized
INFO - 2019-09-11 05:27:28 --> URI Class Initialized
INFO - 2019-09-11 05:27:28 --> Router Class Initialized
INFO - 2019-09-11 05:27:28 --> Output Class Initialized
INFO - 2019-09-11 05:27:28 --> Security Class Initialized
DEBUG - 2019-09-11 05:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:27:28 --> Input Class Initialized
INFO - 2019-09-11 05:27:28 --> Language Class Initialized
INFO - 2019-09-11 05:27:28 --> Loader Class Initialized
INFO - 2019-09-11 05:27:28 --> Helper loaded: url_helper
INFO - 2019-09-11 05:27:28 --> Helper loaded: html_helper
INFO - 2019-09-11 05:27:28 --> Helper loaded: form_helper
INFO - 2019-09-11 05:27:28 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:27:28 --> Helper loaded: date_helper
INFO - 2019-09-11 05:27:28 --> Form Validation Class Initialized
INFO - 2019-09-11 05:27:28 --> Email Class Initialized
DEBUG - 2019-09-11 05:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:27:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:27:28 --> Pagination Class Initialized
INFO - 2019-09-11 05:27:28 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:28 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:28 --> Controller Class Initialized
INFO - 2019-09-11 05:27:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-11 05:27:28 --> Config Class Initialized
INFO - 2019-09-11 05:27:28 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:27:28 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:27:28 --> Utf8 Class Initialized
INFO - 2019-09-11 05:27:28 --> URI Class Initialized
INFO - 2019-09-11 05:27:28 --> Router Class Initialized
INFO - 2019-09-11 05:27:28 --> Output Class Initialized
INFO - 2019-09-11 05:27:28 --> Security Class Initialized
DEBUG - 2019-09-11 05:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:27:28 --> Input Class Initialized
INFO - 2019-09-11 05:27:28 --> Language Class Initialized
INFO - 2019-09-11 05:27:28 --> Loader Class Initialized
INFO - 2019-09-11 05:27:28 --> Helper loaded: url_helper
INFO - 2019-09-11 05:27:28 --> Helper loaded: html_helper
INFO - 2019-09-11 05:27:28 --> Helper loaded: form_helper
INFO - 2019-09-11 05:27:28 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:27:28 --> Helper loaded: date_helper
INFO - 2019-09-11 05:27:28 --> Form Validation Class Initialized
INFO - 2019-09-11 05:27:28 --> Email Class Initialized
DEBUG - 2019-09-11 05:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:27:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:27:28 --> Pagination Class Initialized
INFO - 2019-09-11 05:27:28 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:28 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:28 --> Controller Class Initialized
INFO - 2019-09-11 05:27:28 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-11 05:27:28 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-11 05:27:28 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/checkin.php
INFO - 2019-09-11 05:27:28 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-11 05:27:28 --> Final output sent to browser
DEBUG - 2019-09-11 05:27:28 --> Total execution time: 0.0548
INFO - 2019-09-11 05:27:28 --> Config Class Initialized
INFO - 2019-09-11 05:27:28 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:27:28 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:27:28 --> Utf8 Class Initialized
INFO - 2019-09-11 05:27:28 --> URI Class Initialized
INFO - 2019-09-11 05:27:28 --> Router Class Initialized
INFO - 2019-09-11 05:27:28 --> Output Class Initialized
INFO - 2019-09-11 05:27:28 --> Security Class Initialized
DEBUG - 2019-09-11 05:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:27:28 --> Input Class Initialized
INFO - 2019-09-11 05:27:28 --> Language Class Initialized
INFO - 2019-09-11 05:27:28 --> Loader Class Initialized
INFO - 2019-09-11 05:27:28 --> Helper loaded: url_helper
INFO - 2019-09-11 05:27:28 --> Helper loaded: html_helper
INFO - 2019-09-11 05:27:28 --> Helper loaded: form_helper
INFO - 2019-09-11 05:27:28 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:27:28 --> Helper loaded: date_helper
INFO - 2019-09-11 05:27:28 --> Form Validation Class Initialized
INFO - 2019-09-11 05:27:28 --> Email Class Initialized
DEBUG - 2019-09-11 05:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:27:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:27:28 --> Pagination Class Initialized
INFO - 2019-09-11 05:27:28 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:28 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:28 --> Controller Class Initialized
INFO - 2019-09-11 05:27:28 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 05:27:28 --> Final output sent to browser
DEBUG - 2019-09-11 05:27:28 --> Total execution time: 0.0563
INFO - 2019-09-11 05:27:28 --> Config Class Initialized
INFO - 2019-09-11 05:27:28 --> Hooks Class Initialized
DEBUG - 2019-09-11 05:27:28 --> UTF-8 Support Enabled
INFO - 2019-09-11 05:27:28 --> Utf8 Class Initialized
INFO - 2019-09-11 05:27:28 --> URI Class Initialized
INFO - 2019-09-11 05:27:28 --> Router Class Initialized
INFO - 2019-09-11 05:27:28 --> Output Class Initialized
INFO - 2019-09-11 05:27:28 --> Security Class Initialized
DEBUG - 2019-09-11 05:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 05:27:28 --> Input Class Initialized
INFO - 2019-09-11 05:27:28 --> Language Class Initialized
INFO - 2019-09-11 05:27:28 --> Loader Class Initialized
INFO - 2019-09-11 05:27:28 --> Helper loaded: url_helper
INFO - 2019-09-11 05:27:28 --> Helper loaded: html_helper
INFO - 2019-09-11 05:27:28 --> Helper loaded: form_helper
INFO - 2019-09-11 05:27:28 --> Helper loaded: cookie_helper
INFO - 2019-09-11 05:27:28 --> Helper loaded: date_helper
INFO - 2019-09-11 05:27:28 --> Form Validation Class Initialized
INFO - 2019-09-11 05:27:28 --> Email Class Initialized
DEBUG - 2019-09-11 05:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 05:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 05:27:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 05:27:28 --> Pagination Class Initialized
INFO - 2019-09-11 05:27:28 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:28 --> Database Driver Class Initialized
INFO - 2019-09-11 05:27:28 --> Controller Class Initialized
INFO - 2019-09-11 05:27:28 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 05:27:28 --> Final output sent to browser
DEBUG - 2019-09-11 05:27:28 --> Total execution time: 0.0631
INFO - 2019-09-11 08:38:19 --> Config Class Initialized
INFO - 2019-09-11 08:38:19 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:38:19 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:38:19 --> Utf8 Class Initialized
INFO - 2019-09-11 08:38:19 --> URI Class Initialized
INFO - 2019-09-11 08:38:19 --> Router Class Initialized
INFO - 2019-09-11 08:38:19 --> Output Class Initialized
INFO - 2019-09-11 08:38:19 --> Security Class Initialized
DEBUG - 2019-09-11 08:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:38:19 --> Input Class Initialized
INFO - 2019-09-11 08:38:19 --> Language Class Initialized
INFO - 2019-09-11 08:38:19 --> Loader Class Initialized
INFO - 2019-09-11 08:38:19 --> Helper loaded: url_helper
INFO - 2019-09-11 08:38:19 --> Helper loaded: html_helper
INFO - 2019-09-11 08:38:19 --> Helper loaded: form_helper
INFO - 2019-09-11 08:38:19 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:38:19 --> Helper loaded: date_helper
INFO - 2019-09-11 08:38:19 --> Form Validation Class Initialized
INFO - 2019-09-11 08:38:19 --> Email Class Initialized
DEBUG - 2019-09-11 08:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:38:19 --> Pagination Class Initialized
INFO - 2019-09-11 08:38:19 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:19 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:19 --> Controller Class Initialized
INFO - 2019-09-11 08:38:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-11 08:38:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-11 08:38:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/checkin.php
INFO - 2019-09-11 08:38:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-11 08:38:19 --> Final output sent to browser
DEBUG - 2019-09-11 08:38:19 --> Total execution time: 0.2081
INFO - 2019-09-11 08:38:19 --> Config Class Initialized
INFO - 2019-09-11 08:38:19 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:38:19 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:38:19 --> Utf8 Class Initialized
INFO - 2019-09-11 08:38:19 --> URI Class Initialized
INFO - 2019-09-11 08:38:19 --> Router Class Initialized
INFO - 2019-09-11 08:38:19 --> Output Class Initialized
INFO - 2019-09-11 08:38:19 --> Security Class Initialized
DEBUG - 2019-09-11 08:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:38:19 --> Input Class Initialized
INFO - 2019-09-11 08:38:19 --> Language Class Initialized
INFO - 2019-09-11 08:38:19 --> Loader Class Initialized
INFO - 2019-09-11 08:38:19 --> Helper loaded: url_helper
INFO - 2019-09-11 08:38:19 --> Helper loaded: html_helper
INFO - 2019-09-11 08:38:19 --> Helper loaded: form_helper
INFO - 2019-09-11 08:38:19 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:38:19 --> Helper loaded: date_helper
INFO - 2019-09-11 08:38:19 --> Form Validation Class Initialized
INFO - 2019-09-11 08:38:19 --> Email Class Initialized
DEBUG - 2019-09-11 08:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:38:19 --> Pagination Class Initialized
INFO - 2019-09-11 08:38:19 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:19 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:19 --> Controller Class Initialized
INFO - 2019-09-11 08:38:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 08:38:19 --> Final output sent to browser
DEBUG - 2019-09-11 08:38:19 --> Total execution time: 0.1369
INFO - 2019-09-11 08:38:19 --> Config Class Initialized
INFO - 2019-09-11 08:38:19 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:38:19 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:38:19 --> Utf8 Class Initialized
INFO - 2019-09-11 08:38:19 --> URI Class Initialized
INFO - 2019-09-11 08:38:19 --> Router Class Initialized
INFO - 2019-09-11 08:38:19 --> Output Class Initialized
INFO - 2019-09-11 08:38:19 --> Security Class Initialized
DEBUG - 2019-09-11 08:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:38:19 --> Input Class Initialized
INFO - 2019-09-11 08:38:19 --> Language Class Initialized
INFO - 2019-09-11 08:38:19 --> Loader Class Initialized
INFO - 2019-09-11 08:38:19 --> Helper loaded: url_helper
INFO - 2019-09-11 08:38:19 --> Helper loaded: html_helper
INFO - 2019-09-11 08:38:19 --> Helper loaded: form_helper
INFO - 2019-09-11 08:38:19 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:38:19 --> Helper loaded: date_helper
INFO - 2019-09-11 08:38:19 --> Form Validation Class Initialized
INFO - 2019-09-11 08:38:19 --> Email Class Initialized
DEBUG - 2019-09-11 08:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:38:19 --> Pagination Class Initialized
INFO - 2019-09-11 08:38:19 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:19 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:19 --> Controller Class Initialized
INFO - 2019-09-11 08:38:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 08:38:19 --> Final output sent to browser
DEBUG - 2019-09-11 08:38:19 --> Total execution time: 0.0599
INFO - 2019-09-11 08:38:22 --> Config Class Initialized
INFO - 2019-09-11 08:38:22 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:38:22 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:38:22 --> Utf8 Class Initialized
INFO - 2019-09-11 08:38:22 --> URI Class Initialized
INFO - 2019-09-11 08:38:22 --> Router Class Initialized
INFO - 2019-09-11 08:38:22 --> Output Class Initialized
INFO - 2019-09-11 08:38:22 --> Security Class Initialized
DEBUG - 2019-09-11 08:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:38:22 --> Input Class Initialized
INFO - 2019-09-11 08:38:22 --> Language Class Initialized
INFO - 2019-09-11 08:38:22 --> Loader Class Initialized
INFO - 2019-09-11 08:38:22 --> Helper loaded: url_helper
INFO - 2019-09-11 08:38:22 --> Helper loaded: html_helper
INFO - 2019-09-11 08:38:22 --> Helper loaded: form_helper
INFO - 2019-09-11 08:38:22 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:38:22 --> Helper loaded: date_helper
INFO - 2019-09-11 08:38:22 --> Form Validation Class Initialized
INFO - 2019-09-11 08:38:22 --> Email Class Initialized
DEBUG - 2019-09-11 08:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:38:22 --> Pagination Class Initialized
INFO - 2019-09-11 08:38:22 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:22 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:22 --> Controller Class Initialized
INFO - 2019-09-11 08:38:22 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 08:38:22 --> Final output sent to browser
DEBUG - 2019-09-11 08:38:22 --> Total execution time: 0.0554
INFO - 2019-09-11 08:38:24 --> Config Class Initialized
INFO - 2019-09-11 08:38:24 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:38:24 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:38:24 --> Utf8 Class Initialized
INFO - 2019-09-11 08:38:24 --> URI Class Initialized
INFO - 2019-09-11 08:38:24 --> Router Class Initialized
INFO - 2019-09-11 08:38:24 --> Output Class Initialized
INFO - 2019-09-11 08:38:24 --> Security Class Initialized
DEBUG - 2019-09-11 08:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:38:24 --> Input Class Initialized
INFO - 2019-09-11 08:38:24 --> Language Class Initialized
INFO - 2019-09-11 08:38:24 --> Loader Class Initialized
INFO - 2019-09-11 08:38:24 --> Helper loaded: url_helper
INFO - 2019-09-11 08:38:24 --> Helper loaded: html_helper
INFO - 2019-09-11 08:38:24 --> Helper loaded: form_helper
INFO - 2019-09-11 08:38:24 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:38:24 --> Helper loaded: date_helper
INFO - 2019-09-11 08:38:24 --> Form Validation Class Initialized
INFO - 2019-09-11 08:38:24 --> Email Class Initialized
DEBUG - 2019-09-11 08:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:38:24 --> Pagination Class Initialized
INFO - 2019-09-11 08:38:24 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:24 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:24 --> Controller Class Initialized
INFO - 2019-09-11 08:38:24 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-11 08:38:24 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-11 08:38:24 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-11 08:38:24 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-11 08:38:24 --> Final output sent to browser
DEBUG - 2019-09-11 08:38:24 --> Total execution time: 0.1324
INFO - 2019-09-11 08:38:24 --> Config Class Initialized
INFO - 2019-09-11 08:38:24 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:38:24 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:38:24 --> Utf8 Class Initialized
INFO - 2019-09-11 08:38:24 --> URI Class Initialized
INFO - 2019-09-11 08:38:24 --> Router Class Initialized
INFO - 2019-09-11 08:38:24 --> Output Class Initialized
INFO - 2019-09-11 08:38:24 --> Security Class Initialized
DEBUG - 2019-09-11 08:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:38:24 --> Input Class Initialized
INFO - 2019-09-11 08:38:24 --> Language Class Initialized
INFO - 2019-09-11 08:38:24 --> Loader Class Initialized
INFO - 2019-09-11 08:38:24 --> Helper loaded: url_helper
INFO - 2019-09-11 08:38:24 --> Helper loaded: html_helper
INFO - 2019-09-11 08:38:24 --> Helper loaded: form_helper
INFO - 2019-09-11 08:38:24 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:38:24 --> Helper loaded: date_helper
INFO - 2019-09-11 08:38:24 --> Form Validation Class Initialized
INFO - 2019-09-11 08:38:24 --> Email Class Initialized
DEBUG - 2019-09-11 08:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:38:24 --> Pagination Class Initialized
INFO - 2019-09-11 08:38:24 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:24 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:24 --> Controller Class Initialized
INFO - 2019-09-11 08:38:24 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 08:38:24 --> Final output sent to browser
DEBUG - 2019-09-11 08:38:24 --> Total execution time: 0.0555
INFO - 2019-09-11 08:38:24 --> Config Class Initialized
INFO - 2019-09-11 08:38:24 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:38:24 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:38:24 --> Utf8 Class Initialized
INFO - 2019-09-11 08:38:24 --> URI Class Initialized
INFO - 2019-09-11 08:38:24 --> Router Class Initialized
INFO - 2019-09-11 08:38:24 --> Output Class Initialized
INFO - 2019-09-11 08:38:24 --> Security Class Initialized
DEBUG - 2019-09-11 08:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:38:24 --> Input Class Initialized
INFO - 2019-09-11 08:38:24 --> Language Class Initialized
INFO - 2019-09-11 08:38:24 --> Loader Class Initialized
INFO - 2019-09-11 08:38:24 --> Helper loaded: url_helper
INFO - 2019-09-11 08:38:24 --> Helper loaded: html_helper
INFO - 2019-09-11 08:38:24 --> Helper loaded: form_helper
INFO - 2019-09-11 08:38:24 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:38:24 --> Helper loaded: date_helper
INFO - 2019-09-11 08:38:24 --> Form Validation Class Initialized
INFO - 2019-09-11 08:38:24 --> Email Class Initialized
DEBUG - 2019-09-11 08:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:38:24 --> Pagination Class Initialized
INFO - 2019-09-11 08:38:24 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:24 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:24 --> Controller Class Initialized
INFO - 2019-09-11 08:38:24 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 08:38:24 --> Final output sent to browser
DEBUG - 2019-09-11 08:38:24 --> Total execution time: 0.0612
INFO - 2019-09-11 08:38:31 --> Config Class Initialized
INFO - 2019-09-11 08:38:31 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:38:31 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:38:31 --> Utf8 Class Initialized
INFO - 2019-09-11 08:38:31 --> URI Class Initialized
INFO - 2019-09-11 08:38:31 --> Router Class Initialized
INFO - 2019-09-11 08:38:31 --> Output Class Initialized
INFO - 2019-09-11 08:38:31 --> Security Class Initialized
DEBUG - 2019-09-11 08:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:38:31 --> Input Class Initialized
INFO - 2019-09-11 08:38:31 --> Language Class Initialized
INFO - 2019-09-11 08:38:31 --> Loader Class Initialized
INFO - 2019-09-11 08:38:31 --> Helper loaded: url_helper
INFO - 2019-09-11 08:38:31 --> Helper loaded: html_helper
INFO - 2019-09-11 08:38:31 --> Helper loaded: form_helper
INFO - 2019-09-11 08:38:31 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:38:31 --> Helper loaded: date_helper
INFO - 2019-09-11 08:38:31 --> Form Validation Class Initialized
INFO - 2019-09-11 08:38:31 --> Email Class Initialized
DEBUG - 2019-09-11 08:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:38:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:38:31 --> Pagination Class Initialized
INFO - 2019-09-11 08:38:31 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:31 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:31 --> Controller Class Initialized
INFO - 2019-09-11 08:38:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-11 08:38:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-11 08:38:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-11 08:38:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-11 08:38:31 --> Final output sent to browser
DEBUG - 2019-09-11 08:38:31 --> Total execution time: 0.0638
INFO - 2019-09-11 08:38:31 --> Config Class Initialized
INFO - 2019-09-11 08:38:31 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:38:31 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:38:31 --> Utf8 Class Initialized
INFO - 2019-09-11 08:38:31 --> URI Class Initialized
INFO - 2019-09-11 08:38:31 --> Router Class Initialized
INFO - 2019-09-11 08:38:31 --> Output Class Initialized
INFO - 2019-09-11 08:38:31 --> Security Class Initialized
DEBUG - 2019-09-11 08:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:38:31 --> Input Class Initialized
INFO - 2019-09-11 08:38:31 --> Language Class Initialized
INFO - 2019-09-11 08:38:31 --> Loader Class Initialized
INFO - 2019-09-11 08:38:31 --> Helper loaded: url_helper
INFO - 2019-09-11 08:38:31 --> Helper loaded: html_helper
INFO - 2019-09-11 08:38:31 --> Helper loaded: form_helper
INFO - 2019-09-11 08:38:31 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:38:31 --> Helper loaded: date_helper
INFO - 2019-09-11 08:38:31 --> Form Validation Class Initialized
INFO - 2019-09-11 08:38:31 --> Email Class Initialized
DEBUG - 2019-09-11 08:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:38:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:38:31 --> Pagination Class Initialized
INFO - 2019-09-11 08:38:31 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:31 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:31 --> Controller Class Initialized
INFO - 2019-09-11 08:38:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 08:38:31 --> Final output sent to browser
DEBUG - 2019-09-11 08:38:31 --> Total execution time: 0.0563
INFO - 2019-09-11 08:38:31 --> Config Class Initialized
INFO - 2019-09-11 08:38:31 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:38:31 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:38:31 --> Utf8 Class Initialized
INFO - 2019-09-11 08:38:31 --> URI Class Initialized
INFO - 2019-09-11 08:38:31 --> Router Class Initialized
INFO - 2019-09-11 08:38:31 --> Output Class Initialized
INFO - 2019-09-11 08:38:31 --> Security Class Initialized
DEBUG - 2019-09-11 08:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:38:31 --> Input Class Initialized
INFO - 2019-09-11 08:38:31 --> Language Class Initialized
INFO - 2019-09-11 08:38:31 --> Loader Class Initialized
INFO - 2019-09-11 08:38:31 --> Helper loaded: url_helper
INFO - 2019-09-11 08:38:31 --> Helper loaded: html_helper
INFO - 2019-09-11 08:38:31 --> Helper loaded: form_helper
INFO - 2019-09-11 08:38:31 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:38:31 --> Helper loaded: date_helper
INFO - 2019-09-11 08:38:32 --> Form Validation Class Initialized
INFO - 2019-09-11 08:38:32 --> Email Class Initialized
DEBUG - 2019-09-11 08:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:38:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:38:32 --> Pagination Class Initialized
INFO - 2019-09-11 08:38:32 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:32 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:32 --> Controller Class Initialized
INFO - 2019-09-11 08:38:32 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 08:38:32 --> Final output sent to browser
DEBUG - 2019-09-11 08:38:32 --> Total execution time: 0.0649
INFO - 2019-09-11 08:38:43 --> Config Class Initialized
INFO - 2019-09-11 08:38:43 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:38:43 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:38:43 --> Utf8 Class Initialized
INFO - 2019-09-11 08:38:43 --> URI Class Initialized
INFO - 2019-09-11 08:38:43 --> Router Class Initialized
INFO - 2019-09-11 08:38:43 --> Output Class Initialized
INFO - 2019-09-11 08:38:43 --> Security Class Initialized
DEBUG - 2019-09-11 08:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:38:43 --> Input Class Initialized
INFO - 2019-09-11 08:38:43 --> Language Class Initialized
INFO - 2019-09-11 08:38:43 --> Loader Class Initialized
INFO - 2019-09-11 08:38:43 --> Helper loaded: url_helper
INFO - 2019-09-11 08:38:43 --> Helper loaded: html_helper
INFO - 2019-09-11 08:38:43 --> Helper loaded: form_helper
INFO - 2019-09-11 08:38:43 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:38:43 --> Helper loaded: date_helper
INFO - 2019-09-11 08:38:43 --> Form Validation Class Initialized
INFO - 2019-09-11 08:38:43 --> Email Class Initialized
DEBUG - 2019-09-11 08:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:38:43 --> Pagination Class Initialized
INFO - 2019-09-11 08:38:43 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:43 --> Database Driver Class Initialized
INFO - 2019-09-11 08:38:43 --> Controller Class Initialized
INFO - 2019-09-11 08:38:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-11 08:40:26 --> Config Class Initialized
INFO - 2019-09-11 08:40:26 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:40:26 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:40:26 --> Utf8 Class Initialized
INFO - 2019-09-11 08:40:26 --> URI Class Initialized
INFO - 2019-09-11 08:40:26 --> Router Class Initialized
INFO - 2019-09-11 08:40:26 --> Output Class Initialized
INFO - 2019-09-11 08:40:26 --> Security Class Initialized
DEBUG - 2019-09-11 08:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:40:26 --> Input Class Initialized
INFO - 2019-09-11 08:40:26 --> Language Class Initialized
INFO - 2019-09-11 08:40:26 --> Loader Class Initialized
INFO - 2019-09-11 08:40:26 --> Helper loaded: url_helper
INFO - 2019-09-11 08:40:26 --> Helper loaded: html_helper
INFO - 2019-09-11 08:40:26 --> Helper loaded: form_helper
INFO - 2019-09-11 08:40:26 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:40:26 --> Helper loaded: date_helper
INFO - 2019-09-11 08:40:26 --> Form Validation Class Initialized
INFO - 2019-09-11 08:40:26 --> Email Class Initialized
DEBUG - 2019-09-11 08:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:40:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:40:26 --> Pagination Class Initialized
INFO - 2019-09-11 08:40:26 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:26 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:26 --> Controller Class Initialized
INFO - 2019-09-11 08:40:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-11 08:40:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-11 08:40:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-11 08:40:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-11 08:40:26 --> Final output sent to browser
DEBUG - 2019-09-11 08:40:26 --> Total execution time: 0.0660
INFO - 2019-09-11 08:40:26 --> Config Class Initialized
INFO - 2019-09-11 08:40:26 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:40:26 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:40:26 --> Utf8 Class Initialized
INFO - 2019-09-11 08:40:26 --> URI Class Initialized
INFO - 2019-09-11 08:40:26 --> Router Class Initialized
INFO - 2019-09-11 08:40:26 --> Output Class Initialized
INFO - 2019-09-11 08:40:26 --> Security Class Initialized
DEBUG - 2019-09-11 08:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:40:26 --> Input Class Initialized
INFO - 2019-09-11 08:40:26 --> Language Class Initialized
INFO - 2019-09-11 08:40:26 --> Loader Class Initialized
INFO - 2019-09-11 08:40:26 --> Helper loaded: url_helper
INFO - 2019-09-11 08:40:26 --> Helper loaded: html_helper
INFO - 2019-09-11 08:40:26 --> Helper loaded: form_helper
INFO - 2019-09-11 08:40:26 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:40:26 --> Helper loaded: date_helper
INFO - 2019-09-11 08:40:26 --> Form Validation Class Initialized
INFO - 2019-09-11 08:40:26 --> Email Class Initialized
DEBUG - 2019-09-11 08:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:40:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:40:26 --> Pagination Class Initialized
INFO - 2019-09-11 08:40:26 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:26 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:26 --> Controller Class Initialized
INFO - 2019-09-11 08:40:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 08:40:26 --> Final output sent to browser
DEBUG - 2019-09-11 08:40:26 --> Total execution time: 0.0595
INFO - 2019-09-11 08:40:26 --> Config Class Initialized
INFO - 2019-09-11 08:40:26 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:40:26 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:40:26 --> Utf8 Class Initialized
INFO - 2019-09-11 08:40:26 --> URI Class Initialized
INFO - 2019-09-11 08:40:26 --> Router Class Initialized
INFO - 2019-09-11 08:40:26 --> Output Class Initialized
INFO - 2019-09-11 08:40:26 --> Security Class Initialized
DEBUG - 2019-09-11 08:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:40:26 --> Input Class Initialized
INFO - 2019-09-11 08:40:26 --> Language Class Initialized
INFO - 2019-09-11 08:40:26 --> Loader Class Initialized
INFO - 2019-09-11 08:40:26 --> Helper loaded: url_helper
INFO - 2019-09-11 08:40:26 --> Helper loaded: html_helper
INFO - 2019-09-11 08:40:26 --> Helper loaded: form_helper
INFO - 2019-09-11 08:40:26 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:40:26 --> Helper loaded: date_helper
INFO - 2019-09-11 08:40:26 --> Form Validation Class Initialized
INFO - 2019-09-11 08:40:26 --> Email Class Initialized
DEBUG - 2019-09-11 08:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:40:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:40:26 --> Pagination Class Initialized
INFO - 2019-09-11 08:40:26 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:26 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:26 --> Controller Class Initialized
INFO - 2019-09-11 08:40:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 08:40:26 --> Final output sent to browser
DEBUG - 2019-09-11 08:40:26 --> Total execution time: 0.0670
INFO - 2019-09-11 08:40:27 --> Config Class Initialized
INFO - 2019-09-11 08:40:27 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:40:27 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:40:27 --> Utf8 Class Initialized
INFO - 2019-09-11 08:40:27 --> URI Class Initialized
INFO - 2019-09-11 08:40:27 --> Router Class Initialized
INFO - 2019-09-11 08:40:27 --> Output Class Initialized
INFO - 2019-09-11 08:40:27 --> Security Class Initialized
DEBUG - 2019-09-11 08:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:40:27 --> Input Class Initialized
INFO - 2019-09-11 08:40:27 --> Language Class Initialized
INFO - 2019-09-11 08:40:27 --> Loader Class Initialized
INFO - 2019-09-11 08:40:27 --> Helper loaded: url_helper
INFO - 2019-09-11 08:40:27 --> Helper loaded: html_helper
INFO - 2019-09-11 08:40:27 --> Helper loaded: form_helper
INFO - 2019-09-11 08:40:27 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:40:27 --> Helper loaded: date_helper
INFO - 2019-09-11 08:40:27 --> Form Validation Class Initialized
INFO - 2019-09-11 08:40:27 --> Email Class Initialized
DEBUG - 2019-09-11 08:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:40:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:40:27 --> Pagination Class Initialized
INFO - 2019-09-11 08:40:27 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:27 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:27 --> Controller Class Initialized
INFO - 2019-09-11 08:40:27 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-11 08:40:27 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-11 08:40:27 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-11 08:40:27 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-11 08:40:27 --> Final output sent to browser
DEBUG - 2019-09-11 08:40:27 --> Total execution time: 0.0628
INFO - 2019-09-11 08:40:28 --> Config Class Initialized
INFO - 2019-09-11 08:40:28 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:40:28 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:40:28 --> Utf8 Class Initialized
INFO - 2019-09-11 08:40:28 --> URI Class Initialized
INFO - 2019-09-11 08:40:28 --> Router Class Initialized
INFO - 2019-09-11 08:40:28 --> Output Class Initialized
INFO - 2019-09-11 08:40:28 --> Security Class Initialized
DEBUG - 2019-09-11 08:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:40:28 --> Input Class Initialized
INFO - 2019-09-11 08:40:28 --> Language Class Initialized
INFO - 2019-09-11 08:40:28 --> Loader Class Initialized
INFO - 2019-09-11 08:40:28 --> Helper loaded: url_helper
INFO - 2019-09-11 08:40:28 --> Helper loaded: html_helper
INFO - 2019-09-11 08:40:28 --> Helper loaded: form_helper
INFO - 2019-09-11 08:40:28 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:40:28 --> Helper loaded: date_helper
INFO - 2019-09-11 08:40:28 --> Form Validation Class Initialized
INFO - 2019-09-11 08:40:28 --> Email Class Initialized
DEBUG - 2019-09-11 08:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:40:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:40:28 --> Pagination Class Initialized
INFO - 2019-09-11 08:40:28 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:28 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:28 --> Controller Class Initialized
INFO - 2019-09-11 08:40:28 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 08:40:28 --> Final output sent to browser
DEBUG - 2019-09-11 08:40:28 --> Total execution time: 0.0647
INFO - 2019-09-11 08:40:28 --> Config Class Initialized
INFO - 2019-09-11 08:40:28 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:40:28 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:40:28 --> Utf8 Class Initialized
INFO - 2019-09-11 08:40:28 --> URI Class Initialized
INFO - 2019-09-11 08:40:28 --> Router Class Initialized
INFO - 2019-09-11 08:40:28 --> Output Class Initialized
INFO - 2019-09-11 08:40:28 --> Security Class Initialized
DEBUG - 2019-09-11 08:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:40:28 --> Input Class Initialized
INFO - 2019-09-11 08:40:28 --> Language Class Initialized
INFO - 2019-09-11 08:40:28 --> Loader Class Initialized
INFO - 2019-09-11 08:40:28 --> Helper loaded: url_helper
INFO - 2019-09-11 08:40:28 --> Helper loaded: html_helper
INFO - 2019-09-11 08:40:28 --> Helper loaded: form_helper
INFO - 2019-09-11 08:40:28 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:40:28 --> Helper loaded: date_helper
INFO - 2019-09-11 08:40:28 --> Form Validation Class Initialized
INFO - 2019-09-11 08:40:28 --> Email Class Initialized
DEBUG - 2019-09-11 08:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:40:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:40:28 --> Pagination Class Initialized
INFO - 2019-09-11 08:40:28 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:28 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:28 --> Controller Class Initialized
INFO - 2019-09-11 08:40:28 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 08:40:28 --> Final output sent to browser
DEBUG - 2019-09-11 08:40:28 --> Total execution time: 0.0711
INFO - 2019-09-11 08:40:35 --> Config Class Initialized
INFO - 2019-09-11 08:40:35 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:40:35 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:40:35 --> Utf8 Class Initialized
INFO - 2019-09-11 08:40:35 --> URI Class Initialized
INFO - 2019-09-11 08:40:35 --> Router Class Initialized
INFO - 2019-09-11 08:40:35 --> Output Class Initialized
INFO - 2019-09-11 08:40:35 --> Security Class Initialized
DEBUG - 2019-09-11 08:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:40:35 --> Input Class Initialized
INFO - 2019-09-11 08:40:35 --> Language Class Initialized
INFO - 2019-09-11 08:40:35 --> Loader Class Initialized
INFO - 2019-09-11 08:40:35 --> Helper loaded: url_helper
INFO - 2019-09-11 08:40:35 --> Helper loaded: html_helper
INFO - 2019-09-11 08:40:35 --> Helper loaded: form_helper
INFO - 2019-09-11 08:40:35 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:40:35 --> Helper loaded: date_helper
INFO - 2019-09-11 08:40:35 --> Form Validation Class Initialized
INFO - 2019-09-11 08:40:35 --> Email Class Initialized
DEBUG - 2019-09-11 08:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:40:35 --> Pagination Class Initialized
INFO - 2019-09-11 08:40:35 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:35 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:35 --> Controller Class Initialized
INFO - 2019-09-11 08:40:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-11 08:40:35 --> Config Class Initialized
INFO - 2019-09-11 08:40:35 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:40:35 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:40:35 --> Utf8 Class Initialized
INFO - 2019-09-11 08:40:35 --> URI Class Initialized
INFO - 2019-09-11 08:40:35 --> Router Class Initialized
INFO - 2019-09-11 08:40:35 --> Output Class Initialized
INFO - 2019-09-11 08:40:35 --> Security Class Initialized
DEBUG - 2019-09-11 08:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:40:35 --> Input Class Initialized
INFO - 2019-09-11 08:40:35 --> Language Class Initialized
INFO - 2019-09-11 08:40:35 --> Loader Class Initialized
INFO - 2019-09-11 08:40:35 --> Helper loaded: url_helper
INFO - 2019-09-11 08:40:35 --> Helper loaded: html_helper
INFO - 2019-09-11 08:40:35 --> Helper loaded: form_helper
INFO - 2019-09-11 08:40:35 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:40:35 --> Helper loaded: date_helper
INFO - 2019-09-11 08:40:35 --> Form Validation Class Initialized
INFO - 2019-09-11 08:40:35 --> Email Class Initialized
DEBUG - 2019-09-11 08:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:40:35 --> Pagination Class Initialized
INFO - 2019-09-11 08:40:35 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:35 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:35 --> Controller Class Initialized
INFO - 2019-09-11 08:40:35 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-11 08:40:35 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-11 08:40:35 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-11 08:40:35 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-11 08:40:35 --> Final output sent to browser
DEBUG - 2019-09-11 08:40:35 --> Total execution time: 0.0549
INFO - 2019-09-11 08:40:35 --> Config Class Initialized
INFO - 2019-09-11 08:40:35 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:40:35 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:40:35 --> Utf8 Class Initialized
INFO - 2019-09-11 08:40:35 --> URI Class Initialized
INFO - 2019-09-11 08:40:35 --> Router Class Initialized
INFO - 2019-09-11 08:40:35 --> Output Class Initialized
INFO - 2019-09-11 08:40:35 --> Security Class Initialized
DEBUG - 2019-09-11 08:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:40:35 --> Input Class Initialized
INFO - 2019-09-11 08:40:35 --> Language Class Initialized
INFO - 2019-09-11 08:40:35 --> Loader Class Initialized
INFO - 2019-09-11 08:40:35 --> Helper loaded: url_helper
INFO - 2019-09-11 08:40:35 --> Helper loaded: html_helper
INFO - 2019-09-11 08:40:35 --> Helper loaded: form_helper
INFO - 2019-09-11 08:40:35 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:40:35 --> Helper loaded: date_helper
INFO - 2019-09-11 08:40:35 --> Form Validation Class Initialized
INFO - 2019-09-11 08:40:35 --> Email Class Initialized
DEBUG - 2019-09-11 08:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:40:35 --> Pagination Class Initialized
INFO - 2019-09-11 08:40:35 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:35 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:35 --> Controller Class Initialized
INFO - 2019-09-11 08:40:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 08:40:36 --> Final output sent to browser
DEBUG - 2019-09-11 08:40:36 --> Total execution time: 0.0602
INFO - 2019-09-11 08:40:36 --> Config Class Initialized
INFO - 2019-09-11 08:40:36 --> Hooks Class Initialized
DEBUG - 2019-09-11 08:40:36 --> UTF-8 Support Enabled
INFO - 2019-09-11 08:40:36 --> Utf8 Class Initialized
INFO - 2019-09-11 08:40:36 --> URI Class Initialized
INFO - 2019-09-11 08:40:36 --> Router Class Initialized
INFO - 2019-09-11 08:40:36 --> Output Class Initialized
INFO - 2019-09-11 08:40:36 --> Security Class Initialized
DEBUG - 2019-09-11 08:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 08:40:36 --> Input Class Initialized
INFO - 2019-09-11 08:40:36 --> Language Class Initialized
INFO - 2019-09-11 08:40:36 --> Loader Class Initialized
INFO - 2019-09-11 08:40:36 --> Helper loaded: url_helper
INFO - 2019-09-11 08:40:36 --> Helper loaded: html_helper
INFO - 2019-09-11 08:40:36 --> Helper loaded: form_helper
INFO - 2019-09-11 08:40:36 --> Helper loaded: cookie_helper
INFO - 2019-09-11 08:40:36 --> Helper loaded: date_helper
INFO - 2019-09-11 08:40:36 --> Form Validation Class Initialized
INFO - 2019-09-11 08:40:36 --> Email Class Initialized
DEBUG - 2019-09-11 08:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 08:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 08:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 08:40:36 --> Pagination Class Initialized
INFO - 2019-09-11 08:40:36 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:36 --> Database Driver Class Initialized
INFO - 2019-09-11 08:40:36 --> Controller Class Initialized
INFO - 2019-09-11 08:40:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 08:40:36 --> Final output sent to browser
DEBUG - 2019-09-11 08:40:36 --> Total execution time: 0.0681
INFO - 2019-09-11 11:56:09 --> Config Class Initialized
INFO - 2019-09-11 11:56:09 --> Hooks Class Initialized
DEBUG - 2019-09-11 11:56:09 --> UTF-8 Support Enabled
INFO - 2019-09-11 11:56:09 --> Utf8 Class Initialized
INFO - 2019-09-11 11:56:09 --> URI Class Initialized
INFO - 2019-09-11 11:56:09 --> Router Class Initialized
INFO - 2019-09-11 11:56:09 --> Output Class Initialized
INFO - 2019-09-11 11:56:09 --> Security Class Initialized
DEBUG - 2019-09-11 11:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 11:56:09 --> Input Class Initialized
INFO - 2019-09-11 11:56:09 --> Language Class Initialized
INFO - 2019-09-11 11:56:09 --> Loader Class Initialized
INFO - 2019-09-11 11:56:09 --> Helper loaded: url_helper
INFO - 2019-09-11 11:56:09 --> Helper loaded: html_helper
INFO - 2019-09-11 11:56:09 --> Helper loaded: form_helper
INFO - 2019-09-11 11:56:09 --> Helper loaded: cookie_helper
INFO - 2019-09-11 11:56:09 --> Helper loaded: date_helper
INFO - 2019-09-11 11:56:09 --> Form Validation Class Initialized
INFO - 2019-09-11 11:56:09 --> Email Class Initialized
DEBUG - 2019-09-11 11:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 11:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 11:56:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 11:56:09 --> Pagination Class Initialized
INFO - 2019-09-11 11:56:09 --> Database Driver Class Initialized
INFO - 2019-09-11 11:56:09 --> Database Driver Class Initialized
INFO - 2019-09-11 11:56:09 --> Controller Class Initialized
INFO - 2019-09-11 11:56:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-11 11:56:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-11 11:56:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-11 11:56:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-11 11:56:09 --> Final output sent to browser
DEBUG - 2019-09-11 11:56:09 --> Total execution time: 0.1502
INFO - 2019-09-11 11:56:09 --> Config Class Initialized
INFO - 2019-09-11 11:56:09 --> Hooks Class Initialized
DEBUG - 2019-09-11 11:56:09 --> UTF-8 Support Enabled
INFO - 2019-09-11 11:56:09 --> Utf8 Class Initialized
INFO - 2019-09-11 11:56:09 --> URI Class Initialized
INFO - 2019-09-11 11:56:09 --> Router Class Initialized
INFO - 2019-09-11 11:56:09 --> Output Class Initialized
INFO - 2019-09-11 11:56:09 --> Security Class Initialized
DEBUG - 2019-09-11 11:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 11:56:09 --> Input Class Initialized
INFO - 2019-09-11 11:56:09 --> Language Class Initialized
INFO - 2019-09-11 11:56:09 --> Loader Class Initialized
INFO - 2019-09-11 11:56:09 --> Helper loaded: url_helper
INFO - 2019-09-11 11:56:09 --> Helper loaded: html_helper
INFO - 2019-09-11 11:56:09 --> Helper loaded: form_helper
INFO - 2019-09-11 11:56:09 --> Helper loaded: cookie_helper
INFO - 2019-09-11 11:56:09 --> Helper loaded: date_helper
INFO - 2019-09-11 11:56:09 --> Form Validation Class Initialized
INFO - 2019-09-11 11:56:09 --> Email Class Initialized
DEBUG - 2019-09-11 11:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 11:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 11:56:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 11:56:09 --> Pagination Class Initialized
INFO - 2019-09-11 11:56:09 --> Database Driver Class Initialized
INFO - 2019-09-11 11:56:09 --> Database Driver Class Initialized
INFO - 2019-09-11 11:56:09 --> Controller Class Initialized
INFO - 2019-09-11 11:56:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 11:56:09 --> Final output sent to browser
DEBUG - 2019-09-11 11:56:09 --> Total execution time: 0.0616
INFO - 2019-09-11 11:56:09 --> Config Class Initialized
INFO - 2019-09-11 11:56:09 --> Hooks Class Initialized
DEBUG - 2019-09-11 11:56:09 --> UTF-8 Support Enabled
INFO - 2019-09-11 11:56:09 --> Utf8 Class Initialized
INFO - 2019-09-11 11:56:09 --> URI Class Initialized
INFO - 2019-09-11 11:56:09 --> Router Class Initialized
INFO - 2019-09-11 11:56:09 --> Output Class Initialized
INFO - 2019-09-11 11:56:09 --> Security Class Initialized
DEBUG - 2019-09-11 11:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-11 11:56:09 --> Input Class Initialized
INFO - 2019-09-11 11:56:09 --> Language Class Initialized
INFO - 2019-09-11 11:56:09 --> Loader Class Initialized
INFO - 2019-09-11 11:56:09 --> Helper loaded: url_helper
INFO - 2019-09-11 11:56:09 --> Helper loaded: html_helper
INFO - 2019-09-11 11:56:09 --> Helper loaded: form_helper
INFO - 2019-09-11 11:56:09 --> Helper loaded: cookie_helper
INFO - 2019-09-11 11:56:09 --> Helper loaded: date_helper
INFO - 2019-09-11 11:56:09 --> Form Validation Class Initialized
INFO - 2019-09-11 11:56:09 --> Email Class Initialized
DEBUG - 2019-09-11 11:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-11 11:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-11 11:56:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-11 11:56:09 --> Pagination Class Initialized
INFO - 2019-09-11 11:56:09 --> Database Driver Class Initialized
INFO - 2019-09-11 11:56:09 --> Database Driver Class Initialized
INFO - 2019-09-11 11:56:09 --> Controller Class Initialized
INFO - 2019-09-11 11:56:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-11 11:56:09 --> Final output sent to browser
DEBUG - 2019-09-11 11:56:09 --> Total execution time: 0.0697
