<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-12 01:40:34 --> Config Class Initialized
INFO - 2019-09-12 01:40:34 --> Hooks Class Initialized
DEBUG - 2019-09-12 01:40:34 --> UTF-8 Support Enabled
INFO - 2019-09-12 01:40:34 --> Utf8 Class Initialized
INFO - 2019-09-12 01:40:34 --> URI Class Initialized
INFO - 2019-09-12 01:40:34 --> Router Class Initialized
INFO - 2019-09-12 01:40:34 --> Output Class Initialized
INFO - 2019-09-12 01:40:34 --> Security Class Initialized
DEBUG - 2019-09-12 01:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 01:40:34 --> Input Class Initialized
INFO - 2019-09-12 01:40:34 --> Language Class Initialized
INFO - 2019-09-12 01:40:34 --> Loader Class Initialized
INFO - 2019-09-12 01:40:34 --> Helper loaded: url_helper
INFO - 2019-09-12 01:40:34 --> Helper loaded: html_helper
INFO - 2019-09-12 01:40:34 --> Helper loaded: form_helper
INFO - 2019-09-12 01:40:34 --> Helper loaded: cookie_helper
INFO - 2019-09-12 01:40:34 --> Helper loaded: date_helper
INFO - 2019-09-12 01:40:35 --> Form Validation Class Initialized
INFO - 2019-09-12 01:40:35 --> Email Class Initialized
DEBUG - 2019-09-12 01:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 01:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 01:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 01:40:35 --> Pagination Class Initialized
INFO - 2019-09-12 01:40:35 --> Database Driver Class Initialized
INFO - 2019-09-12 01:40:35 --> Database Driver Class Initialized
INFO - 2019-09-12 01:40:35 --> Controller Class Initialized
INFO - 2019-09-12 01:40:35 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 01:40:35 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-12 01:40:35 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-12 01:40:35 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 01:40:35 --> Final output sent to browser
DEBUG - 2019-09-12 01:40:35 --> Total execution time: 0.0731
INFO - 2019-09-12 01:40:35 --> Config Class Initialized
INFO - 2019-09-12 01:40:35 --> Hooks Class Initialized
DEBUG - 2019-09-12 01:40:35 --> UTF-8 Support Enabled
INFO - 2019-09-12 01:40:35 --> Utf8 Class Initialized
INFO - 2019-09-12 01:40:35 --> URI Class Initialized
INFO - 2019-09-12 01:40:35 --> Router Class Initialized
INFO - 2019-09-12 01:40:35 --> Output Class Initialized
INFO - 2019-09-12 01:40:35 --> Security Class Initialized
DEBUG - 2019-09-12 01:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 01:40:35 --> Input Class Initialized
INFO - 2019-09-12 01:40:35 --> Language Class Initialized
INFO - 2019-09-12 01:40:35 --> Loader Class Initialized
INFO - 2019-09-12 01:40:35 --> Helper loaded: url_helper
INFO - 2019-09-12 01:40:35 --> Helper loaded: html_helper
INFO - 2019-09-12 01:40:35 --> Helper loaded: form_helper
INFO - 2019-09-12 01:40:35 --> Helper loaded: cookie_helper
INFO - 2019-09-12 01:40:35 --> Helper loaded: date_helper
INFO - 2019-09-12 01:40:35 --> Form Validation Class Initialized
INFO - 2019-09-12 01:40:35 --> Email Class Initialized
DEBUG - 2019-09-12 01:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 01:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 01:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 01:40:35 --> Pagination Class Initialized
INFO - 2019-09-12 01:40:35 --> Database Driver Class Initialized
INFO - 2019-09-12 01:40:35 --> Database Driver Class Initialized
INFO - 2019-09-12 01:40:35 --> Controller Class Initialized
INFO - 2019-09-12 01:40:35 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 01:40:35 --> Final output sent to browser
DEBUG - 2019-09-12 01:40:35 --> Total execution time: 0.0640
INFO - 2019-09-12 01:40:35 --> Config Class Initialized
INFO - 2019-09-12 01:40:35 --> Hooks Class Initialized
DEBUG - 2019-09-12 01:40:35 --> UTF-8 Support Enabled
INFO - 2019-09-12 01:40:35 --> Utf8 Class Initialized
INFO - 2019-09-12 01:40:35 --> URI Class Initialized
INFO - 2019-09-12 01:40:35 --> Router Class Initialized
INFO - 2019-09-12 01:40:35 --> Output Class Initialized
INFO - 2019-09-12 01:40:35 --> Security Class Initialized
DEBUG - 2019-09-12 01:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 01:40:35 --> Input Class Initialized
INFO - 2019-09-12 01:40:35 --> Language Class Initialized
INFO - 2019-09-12 01:40:35 --> Loader Class Initialized
INFO - 2019-09-12 01:40:35 --> Helper loaded: url_helper
INFO - 2019-09-12 01:40:35 --> Helper loaded: html_helper
INFO - 2019-09-12 01:40:35 --> Helper loaded: form_helper
INFO - 2019-09-12 01:40:35 --> Helper loaded: cookie_helper
INFO - 2019-09-12 01:40:35 --> Helper loaded: date_helper
INFO - 2019-09-12 01:40:35 --> Form Validation Class Initialized
INFO - 2019-09-12 01:40:35 --> Email Class Initialized
DEBUG - 2019-09-12 01:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 01:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 01:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 01:40:35 --> Pagination Class Initialized
INFO - 2019-09-12 01:40:35 --> Database Driver Class Initialized
INFO - 2019-09-12 01:40:35 --> Database Driver Class Initialized
INFO - 2019-09-12 01:40:35 --> Controller Class Initialized
INFO - 2019-09-12 01:40:35 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 01:40:35 --> Final output sent to browser
DEBUG - 2019-09-12 01:40:35 --> Total execution time: 0.0717
INFO - 2019-09-12 01:40:36 --> Config Class Initialized
INFO - 2019-09-12 01:40:36 --> Hooks Class Initialized
DEBUG - 2019-09-12 01:40:36 --> UTF-8 Support Enabled
INFO - 2019-09-12 01:40:36 --> Utf8 Class Initialized
INFO - 2019-09-12 01:40:36 --> URI Class Initialized
INFO - 2019-09-12 01:40:36 --> Router Class Initialized
INFO - 2019-09-12 01:40:36 --> Output Class Initialized
INFO - 2019-09-12 01:40:36 --> Security Class Initialized
DEBUG - 2019-09-12 01:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 01:40:36 --> Input Class Initialized
INFO - 2019-09-12 01:40:36 --> Language Class Initialized
INFO - 2019-09-12 01:40:36 --> Loader Class Initialized
INFO - 2019-09-12 01:40:36 --> Helper loaded: url_helper
INFO - 2019-09-12 01:40:36 --> Helper loaded: html_helper
INFO - 2019-09-12 01:40:36 --> Helper loaded: form_helper
INFO - 2019-09-12 01:40:36 --> Helper loaded: cookie_helper
INFO - 2019-09-12 01:40:36 --> Helper loaded: date_helper
INFO - 2019-09-12 01:40:36 --> Form Validation Class Initialized
INFO - 2019-09-12 01:40:36 --> Email Class Initialized
DEBUG - 2019-09-12 01:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 01:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 01:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 01:40:36 --> Pagination Class Initialized
INFO - 2019-09-12 01:40:36 --> Database Driver Class Initialized
INFO - 2019-09-12 01:40:36 --> Database Driver Class Initialized
INFO - 2019-09-12 01:40:36 --> Controller Class Initialized
INFO - 2019-09-12 01:40:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 01:40:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-12 01:40:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-12 01:40:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 01:40:36 --> Final output sent to browser
DEBUG - 2019-09-12 01:40:36 --> Total execution time: 0.0638
INFO - 2019-09-12 01:40:36 --> Config Class Initialized
INFO - 2019-09-12 01:40:36 --> Hooks Class Initialized
DEBUG - 2019-09-12 01:40:37 --> UTF-8 Support Enabled
INFO - 2019-09-12 01:40:37 --> Utf8 Class Initialized
INFO - 2019-09-12 01:40:37 --> URI Class Initialized
INFO - 2019-09-12 01:40:37 --> Router Class Initialized
INFO - 2019-09-12 01:40:37 --> Output Class Initialized
INFO - 2019-09-12 01:40:37 --> Security Class Initialized
DEBUG - 2019-09-12 01:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 01:40:37 --> Input Class Initialized
INFO - 2019-09-12 01:40:37 --> Language Class Initialized
INFO - 2019-09-12 01:40:37 --> Loader Class Initialized
INFO - 2019-09-12 01:40:37 --> Helper loaded: url_helper
INFO - 2019-09-12 01:40:37 --> Helper loaded: html_helper
INFO - 2019-09-12 01:40:37 --> Helper loaded: form_helper
INFO - 2019-09-12 01:40:37 --> Helper loaded: cookie_helper
INFO - 2019-09-12 01:40:37 --> Helper loaded: date_helper
INFO - 2019-09-12 01:40:37 --> Form Validation Class Initialized
INFO - 2019-09-12 01:40:37 --> Email Class Initialized
DEBUG - 2019-09-12 01:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 01:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 01:40:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 01:40:37 --> Pagination Class Initialized
INFO - 2019-09-12 01:40:37 --> Database Driver Class Initialized
INFO - 2019-09-12 01:40:37 --> Database Driver Class Initialized
INFO - 2019-09-12 01:40:37 --> Controller Class Initialized
INFO - 2019-09-12 01:40:37 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 01:40:37 --> Final output sent to browser
DEBUG - 2019-09-12 01:40:37 --> Total execution time: 0.0652
INFO - 2019-09-12 01:40:37 --> Config Class Initialized
INFO - 2019-09-12 01:40:37 --> Hooks Class Initialized
DEBUG - 2019-09-12 01:40:37 --> UTF-8 Support Enabled
INFO - 2019-09-12 01:40:37 --> Utf8 Class Initialized
INFO - 2019-09-12 01:40:37 --> URI Class Initialized
INFO - 2019-09-12 01:40:37 --> Router Class Initialized
INFO - 2019-09-12 01:40:37 --> Output Class Initialized
INFO - 2019-09-12 01:40:37 --> Security Class Initialized
DEBUG - 2019-09-12 01:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 01:40:37 --> Input Class Initialized
INFO - 2019-09-12 01:40:37 --> Language Class Initialized
INFO - 2019-09-12 01:40:37 --> Loader Class Initialized
INFO - 2019-09-12 01:40:37 --> Helper loaded: url_helper
INFO - 2019-09-12 01:40:37 --> Helper loaded: html_helper
INFO - 2019-09-12 01:40:37 --> Helper loaded: form_helper
INFO - 2019-09-12 01:40:37 --> Helper loaded: cookie_helper
INFO - 2019-09-12 01:40:37 --> Helper loaded: date_helper
INFO - 2019-09-12 01:40:37 --> Form Validation Class Initialized
INFO - 2019-09-12 01:40:37 --> Email Class Initialized
DEBUG - 2019-09-12 01:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 01:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 01:40:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 01:40:37 --> Pagination Class Initialized
INFO - 2019-09-12 01:40:37 --> Database Driver Class Initialized
INFO - 2019-09-12 01:40:37 --> Database Driver Class Initialized
INFO - 2019-09-12 01:40:37 --> Controller Class Initialized
INFO - 2019-09-12 01:40:37 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 01:40:37 --> Final output sent to browser
DEBUG - 2019-09-12 01:40:37 --> Total execution time: 0.0790
INFO - 2019-09-12 01:40:39 --> Config Class Initialized
INFO - 2019-09-12 01:40:39 --> Hooks Class Initialized
DEBUG - 2019-09-12 01:40:39 --> UTF-8 Support Enabled
INFO - 2019-09-12 01:40:39 --> Utf8 Class Initialized
INFO - 2019-09-12 01:40:39 --> URI Class Initialized
INFO - 2019-09-12 01:40:39 --> Router Class Initialized
INFO - 2019-09-12 01:40:39 --> Output Class Initialized
INFO - 2019-09-12 01:40:39 --> Security Class Initialized
DEBUG - 2019-09-12 01:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 01:40:39 --> Input Class Initialized
INFO - 2019-09-12 01:40:39 --> Language Class Initialized
INFO - 2019-09-12 01:40:40 --> Loader Class Initialized
INFO - 2019-09-12 01:40:40 --> Helper loaded: url_helper
INFO - 2019-09-12 01:40:40 --> Helper loaded: html_helper
INFO - 2019-09-12 01:40:40 --> Helper loaded: form_helper
INFO - 2019-09-12 01:40:40 --> Helper loaded: cookie_helper
INFO - 2019-09-12 01:40:40 --> Helper loaded: date_helper
INFO - 2019-09-12 01:40:40 --> Form Validation Class Initialized
INFO - 2019-09-12 01:40:40 --> Email Class Initialized
DEBUG - 2019-09-12 01:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 01:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 01:40:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 01:40:40 --> Pagination Class Initialized
INFO - 2019-09-12 01:40:40 --> Database Driver Class Initialized
INFO - 2019-09-12 01:40:40 --> Database Driver Class Initialized
INFO - 2019-09-12 01:40:40 --> Controller Class Initialized
INFO - 2019-09-12 01:40:40 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 01:40:40 --> Final output sent to browser
DEBUG - 2019-09-12 01:40:40 --> Total execution time: 0.0575
INFO - 2019-09-12 01:41:26 --> Config Class Initialized
INFO - 2019-09-12 01:41:26 --> Hooks Class Initialized
DEBUG - 2019-09-12 01:41:26 --> UTF-8 Support Enabled
INFO - 2019-09-12 01:41:26 --> Utf8 Class Initialized
INFO - 2019-09-12 01:41:26 --> URI Class Initialized
INFO - 2019-09-12 01:41:26 --> Router Class Initialized
INFO - 2019-09-12 01:41:26 --> Output Class Initialized
INFO - 2019-09-12 01:41:26 --> Security Class Initialized
DEBUG - 2019-09-12 01:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 01:41:26 --> Input Class Initialized
INFO - 2019-09-12 01:41:26 --> Language Class Initialized
INFO - 2019-09-12 01:41:26 --> Loader Class Initialized
INFO - 2019-09-12 01:41:26 --> Helper loaded: url_helper
INFO - 2019-09-12 01:41:26 --> Helper loaded: html_helper
INFO - 2019-09-12 01:41:26 --> Helper loaded: form_helper
INFO - 2019-09-12 01:41:26 --> Helper loaded: cookie_helper
INFO - 2019-09-12 01:41:26 --> Helper loaded: date_helper
INFO - 2019-09-12 01:41:26 --> Form Validation Class Initialized
INFO - 2019-09-12 01:41:26 --> Email Class Initialized
DEBUG - 2019-09-12 01:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 01:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 01:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 01:41:26 --> Pagination Class Initialized
INFO - 2019-09-12 01:41:26 --> Database Driver Class Initialized
INFO - 2019-09-12 01:41:26 --> Database Driver Class Initialized
INFO - 2019-09-12 01:41:26 --> Controller Class Initialized
INFO - 2019-09-12 01:41:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 01:41:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-12 01:41:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-12 01:41:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 01:41:26 --> Final output sent to browser
DEBUG - 2019-09-12 01:41:26 --> Total execution time: 0.0630
INFO - 2019-09-12 01:41:26 --> Config Class Initialized
INFO - 2019-09-12 01:41:26 --> Hooks Class Initialized
DEBUG - 2019-09-12 01:41:26 --> UTF-8 Support Enabled
INFO - 2019-09-12 01:41:26 --> Utf8 Class Initialized
INFO - 2019-09-12 01:41:26 --> URI Class Initialized
INFO - 2019-09-12 01:41:26 --> Router Class Initialized
INFO - 2019-09-12 01:41:26 --> Output Class Initialized
INFO - 2019-09-12 01:41:26 --> Security Class Initialized
DEBUG - 2019-09-12 01:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 01:41:26 --> Input Class Initialized
INFO - 2019-09-12 01:41:26 --> Language Class Initialized
INFO - 2019-09-12 01:41:26 --> Loader Class Initialized
INFO - 2019-09-12 01:41:26 --> Helper loaded: url_helper
INFO - 2019-09-12 01:41:26 --> Helper loaded: html_helper
INFO - 2019-09-12 01:41:26 --> Helper loaded: form_helper
INFO - 2019-09-12 01:41:26 --> Helper loaded: cookie_helper
INFO - 2019-09-12 01:41:26 --> Helper loaded: date_helper
INFO - 2019-09-12 01:41:26 --> Form Validation Class Initialized
INFO - 2019-09-12 01:41:26 --> Email Class Initialized
DEBUG - 2019-09-12 01:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 01:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 01:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 01:41:26 --> Pagination Class Initialized
INFO - 2019-09-12 01:41:26 --> Database Driver Class Initialized
INFO - 2019-09-12 01:41:26 --> Database Driver Class Initialized
INFO - 2019-09-12 01:41:26 --> Controller Class Initialized
INFO - 2019-09-12 01:41:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 01:41:26 --> Final output sent to browser
DEBUG - 2019-09-12 01:41:26 --> Total execution time: 0.0520
INFO - 2019-09-12 01:41:26 --> Config Class Initialized
INFO - 2019-09-12 01:41:26 --> Hooks Class Initialized
DEBUG - 2019-09-12 01:41:26 --> UTF-8 Support Enabled
INFO - 2019-09-12 01:41:26 --> Utf8 Class Initialized
INFO - 2019-09-12 01:41:26 --> URI Class Initialized
INFO - 2019-09-12 01:41:26 --> Router Class Initialized
INFO - 2019-09-12 01:41:26 --> Output Class Initialized
INFO - 2019-09-12 01:41:26 --> Security Class Initialized
DEBUG - 2019-09-12 01:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 01:41:26 --> Input Class Initialized
INFO - 2019-09-12 01:41:26 --> Language Class Initialized
INFO - 2019-09-12 01:41:26 --> Loader Class Initialized
INFO - 2019-09-12 01:41:26 --> Helper loaded: url_helper
INFO - 2019-09-12 01:41:26 --> Helper loaded: html_helper
INFO - 2019-09-12 01:41:26 --> Helper loaded: form_helper
INFO - 2019-09-12 01:41:26 --> Helper loaded: cookie_helper
INFO - 2019-09-12 01:41:26 --> Helper loaded: date_helper
INFO - 2019-09-12 01:41:26 --> Form Validation Class Initialized
INFO - 2019-09-12 01:41:26 --> Email Class Initialized
DEBUG - 2019-09-12 01:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 01:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 01:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 01:41:26 --> Pagination Class Initialized
INFO - 2019-09-12 01:41:26 --> Database Driver Class Initialized
INFO - 2019-09-12 01:41:26 --> Database Driver Class Initialized
INFO - 2019-09-12 01:41:26 --> Controller Class Initialized
INFO - 2019-09-12 01:41:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 01:41:26 --> Final output sent to browser
DEBUG - 2019-09-12 01:41:26 --> Total execution time: 0.0686
INFO - 2019-09-12 01:41:28 --> Config Class Initialized
INFO - 2019-09-12 01:41:28 --> Hooks Class Initialized
DEBUG - 2019-09-12 01:41:28 --> UTF-8 Support Enabled
INFO - 2019-09-12 01:41:28 --> Utf8 Class Initialized
INFO - 2019-09-12 01:41:28 --> URI Class Initialized
INFO - 2019-09-12 01:41:28 --> Router Class Initialized
INFO - 2019-09-12 01:41:28 --> Output Class Initialized
INFO - 2019-09-12 01:41:28 --> Security Class Initialized
DEBUG - 2019-09-12 01:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 01:41:28 --> Input Class Initialized
INFO - 2019-09-12 01:41:28 --> Language Class Initialized
INFO - 2019-09-12 01:41:28 --> Loader Class Initialized
INFO - 2019-09-12 01:41:28 --> Helper loaded: url_helper
INFO - 2019-09-12 01:41:28 --> Helper loaded: html_helper
INFO - 2019-09-12 01:41:28 --> Helper loaded: form_helper
INFO - 2019-09-12 01:41:28 --> Helper loaded: cookie_helper
INFO - 2019-09-12 01:41:28 --> Helper loaded: date_helper
INFO - 2019-09-12 01:41:28 --> Form Validation Class Initialized
INFO - 2019-09-12 01:41:28 --> Email Class Initialized
DEBUG - 2019-09-12 01:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 01:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 01:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 01:41:28 --> Pagination Class Initialized
INFO - 2019-09-12 01:41:28 --> Database Driver Class Initialized
INFO - 2019-09-12 01:41:28 --> Database Driver Class Initialized
INFO - 2019-09-12 01:41:28 --> Controller Class Initialized
INFO - 2019-09-12 01:41:28 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 01:41:28 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-12 01:41:28 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-12 01:41:28 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 01:41:28 --> Final output sent to browser
DEBUG - 2019-09-12 01:41:28 --> Total execution time: 0.0671
INFO - 2019-09-12 01:41:28 --> Config Class Initialized
INFO - 2019-09-12 01:41:28 --> Hooks Class Initialized
DEBUG - 2019-09-12 01:41:28 --> UTF-8 Support Enabled
INFO - 2019-09-12 01:41:28 --> Utf8 Class Initialized
INFO - 2019-09-12 01:41:28 --> URI Class Initialized
INFO - 2019-09-12 01:41:28 --> Router Class Initialized
INFO - 2019-09-12 01:41:28 --> Output Class Initialized
INFO - 2019-09-12 01:41:28 --> Security Class Initialized
DEBUG - 2019-09-12 01:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 01:41:28 --> Input Class Initialized
INFO - 2019-09-12 01:41:28 --> Language Class Initialized
INFO - 2019-09-12 01:41:28 --> Loader Class Initialized
INFO - 2019-09-12 01:41:28 --> Helper loaded: url_helper
INFO - 2019-09-12 01:41:28 --> Helper loaded: html_helper
INFO - 2019-09-12 01:41:28 --> Helper loaded: form_helper
INFO - 2019-09-12 01:41:28 --> Helper loaded: cookie_helper
INFO - 2019-09-12 01:41:28 --> Helper loaded: date_helper
INFO - 2019-09-12 01:41:28 --> Form Validation Class Initialized
INFO - 2019-09-12 01:41:28 --> Email Class Initialized
DEBUG - 2019-09-12 01:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 01:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 01:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 01:41:28 --> Pagination Class Initialized
INFO - 2019-09-12 01:41:28 --> Database Driver Class Initialized
INFO - 2019-09-12 01:41:28 --> Database Driver Class Initialized
INFO - 2019-09-12 01:41:28 --> Controller Class Initialized
INFO - 2019-09-12 01:41:28 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 01:41:28 --> Final output sent to browser
DEBUG - 2019-09-12 01:41:28 --> Total execution time: 0.0540
INFO - 2019-09-12 01:41:28 --> Config Class Initialized
INFO - 2019-09-12 01:41:28 --> Hooks Class Initialized
DEBUG - 2019-09-12 01:41:28 --> UTF-8 Support Enabled
INFO - 2019-09-12 01:41:28 --> Utf8 Class Initialized
INFO - 2019-09-12 01:41:28 --> URI Class Initialized
INFO - 2019-09-12 01:41:28 --> Router Class Initialized
INFO - 2019-09-12 01:41:28 --> Output Class Initialized
INFO - 2019-09-12 01:41:28 --> Security Class Initialized
DEBUG - 2019-09-12 01:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 01:41:28 --> Input Class Initialized
INFO - 2019-09-12 01:41:28 --> Language Class Initialized
INFO - 2019-09-12 01:41:28 --> Loader Class Initialized
INFO - 2019-09-12 01:41:28 --> Helper loaded: url_helper
INFO - 2019-09-12 01:41:28 --> Helper loaded: html_helper
INFO - 2019-09-12 01:41:28 --> Helper loaded: form_helper
INFO - 2019-09-12 01:41:28 --> Helper loaded: cookie_helper
INFO - 2019-09-12 01:41:28 --> Helper loaded: date_helper
INFO - 2019-09-12 01:41:28 --> Form Validation Class Initialized
INFO - 2019-09-12 01:41:28 --> Email Class Initialized
DEBUG - 2019-09-12 01:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 01:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 01:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 01:41:28 --> Pagination Class Initialized
INFO - 2019-09-12 01:41:28 --> Database Driver Class Initialized
INFO - 2019-09-12 01:41:28 --> Database Driver Class Initialized
INFO - 2019-09-12 01:41:28 --> Controller Class Initialized
INFO - 2019-09-12 01:41:28 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 01:41:28 --> Final output sent to browser
DEBUG - 2019-09-12 01:41:28 --> Total execution time: 0.0668
INFO - 2019-09-12 01:42:52 --> Config Class Initialized
INFO - 2019-09-12 01:42:52 --> Hooks Class Initialized
DEBUG - 2019-09-12 01:42:52 --> UTF-8 Support Enabled
INFO - 2019-09-12 01:42:52 --> Utf8 Class Initialized
INFO - 2019-09-12 01:42:52 --> URI Class Initialized
INFO - 2019-09-12 01:42:52 --> Router Class Initialized
INFO - 2019-09-12 01:42:52 --> Output Class Initialized
INFO - 2019-09-12 01:42:52 --> Security Class Initialized
DEBUG - 2019-09-12 01:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 01:42:52 --> Input Class Initialized
INFO - 2019-09-12 01:42:52 --> Language Class Initialized
INFO - 2019-09-12 01:42:52 --> Loader Class Initialized
INFO - 2019-09-12 01:42:52 --> Helper loaded: url_helper
INFO - 2019-09-12 01:42:52 --> Helper loaded: html_helper
INFO - 2019-09-12 01:42:52 --> Helper loaded: form_helper
INFO - 2019-09-12 01:42:52 --> Helper loaded: cookie_helper
INFO - 2019-09-12 01:42:52 --> Helper loaded: date_helper
INFO - 2019-09-12 01:42:52 --> Form Validation Class Initialized
INFO - 2019-09-12 01:42:52 --> Email Class Initialized
DEBUG - 2019-09-12 01:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 01:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 01:42:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 01:42:52 --> Pagination Class Initialized
INFO - 2019-09-12 01:42:52 --> Database Driver Class Initialized
INFO - 2019-09-12 01:42:52 --> Database Driver Class Initialized
INFO - 2019-09-12 01:42:52 --> Controller Class Initialized
INFO - 2019-09-12 01:42:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-12 01:42:55 --> Config Class Initialized
INFO - 2019-09-12 01:42:55 --> Hooks Class Initialized
DEBUG - 2019-09-12 01:42:55 --> UTF-8 Support Enabled
INFO - 2019-09-12 01:42:55 --> Utf8 Class Initialized
INFO - 2019-09-12 01:42:55 --> URI Class Initialized
INFO - 2019-09-12 01:42:55 --> Router Class Initialized
INFO - 2019-09-12 01:42:55 --> Output Class Initialized
INFO - 2019-09-12 01:42:55 --> Security Class Initialized
DEBUG - 2019-09-12 01:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 01:42:55 --> Input Class Initialized
INFO - 2019-09-12 01:42:55 --> Language Class Initialized
INFO - 2019-09-12 01:42:55 --> Loader Class Initialized
INFO - 2019-09-12 01:42:55 --> Helper loaded: url_helper
INFO - 2019-09-12 01:42:55 --> Helper loaded: html_helper
INFO - 2019-09-12 01:42:55 --> Helper loaded: form_helper
INFO - 2019-09-12 01:42:55 --> Helper loaded: cookie_helper
INFO - 2019-09-12 01:42:55 --> Helper loaded: date_helper
INFO - 2019-09-12 01:42:55 --> Form Validation Class Initialized
INFO - 2019-09-12 01:42:55 --> Email Class Initialized
DEBUG - 2019-09-12 01:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 01:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 01:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 01:42:55 --> Pagination Class Initialized
INFO - 2019-09-12 01:42:55 --> Database Driver Class Initialized
INFO - 2019-09-12 01:42:55 --> Database Driver Class Initialized
INFO - 2019-09-12 01:42:55 --> Controller Class Initialized
INFO - 2019-09-12 01:42:55 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 01:42:55 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-12 01:42:55 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-12 01:42:55 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 01:42:55 --> Final output sent to browser
DEBUG - 2019-09-12 01:42:55 --> Total execution time: 0.0590
INFO - 2019-09-12 01:42:55 --> Config Class Initialized
INFO - 2019-09-12 01:42:55 --> Hooks Class Initialized
DEBUG - 2019-09-12 01:42:55 --> UTF-8 Support Enabled
INFO - 2019-09-12 01:42:55 --> Utf8 Class Initialized
INFO - 2019-09-12 01:42:55 --> URI Class Initialized
INFO - 2019-09-12 01:42:55 --> Router Class Initialized
INFO - 2019-09-12 01:42:55 --> Output Class Initialized
INFO - 2019-09-12 01:42:55 --> Security Class Initialized
DEBUG - 2019-09-12 01:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 01:42:55 --> Input Class Initialized
INFO - 2019-09-12 01:42:55 --> Language Class Initialized
INFO - 2019-09-12 01:42:55 --> Loader Class Initialized
INFO - 2019-09-12 01:42:55 --> Helper loaded: url_helper
INFO - 2019-09-12 01:42:55 --> Helper loaded: html_helper
INFO - 2019-09-12 01:42:55 --> Helper loaded: form_helper
INFO - 2019-09-12 01:42:55 --> Helper loaded: cookie_helper
INFO - 2019-09-12 01:42:55 --> Helper loaded: date_helper
INFO - 2019-09-12 01:42:55 --> Form Validation Class Initialized
INFO - 2019-09-12 01:42:55 --> Email Class Initialized
DEBUG - 2019-09-12 01:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 01:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 01:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 01:42:55 --> Pagination Class Initialized
INFO - 2019-09-12 01:42:55 --> Database Driver Class Initialized
INFO - 2019-09-12 01:42:55 --> Database Driver Class Initialized
INFO - 2019-09-12 01:42:55 --> Controller Class Initialized
INFO - 2019-09-12 01:42:55 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 01:42:55 --> Final output sent to browser
DEBUG - 2019-09-12 01:42:55 --> Total execution time: 0.0515
INFO - 2019-09-12 01:42:55 --> Config Class Initialized
INFO - 2019-09-12 01:42:55 --> Hooks Class Initialized
DEBUG - 2019-09-12 01:42:55 --> UTF-8 Support Enabled
INFO - 2019-09-12 01:42:55 --> Utf8 Class Initialized
INFO - 2019-09-12 01:42:55 --> URI Class Initialized
INFO - 2019-09-12 01:42:55 --> Router Class Initialized
INFO - 2019-09-12 01:42:55 --> Output Class Initialized
INFO - 2019-09-12 01:42:55 --> Security Class Initialized
DEBUG - 2019-09-12 01:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 01:42:55 --> Input Class Initialized
INFO - 2019-09-12 01:42:55 --> Language Class Initialized
INFO - 2019-09-12 01:42:55 --> Loader Class Initialized
INFO - 2019-09-12 01:42:55 --> Helper loaded: url_helper
INFO - 2019-09-12 01:42:55 --> Helper loaded: html_helper
INFO - 2019-09-12 01:42:55 --> Helper loaded: form_helper
INFO - 2019-09-12 01:42:55 --> Helper loaded: cookie_helper
INFO - 2019-09-12 01:42:55 --> Helper loaded: date_helper
INFO - 2019-09-12 01:42:55 --> Form Validation Class Initialized
INFO - 2019-09-12 01:42:55 --> Email Class Initialized
DEBUG - 2019-09-12 01:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 01:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 01:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 01:42:55 --> Pagination Class Initialized
INFO - 2019-09-12 01:42:55 --> Database Driver Class Initialized
INFO - 2019-09-12 01:42:55 --> Database Driver Class Initialized
INFO - 2019-09-12 01:42:55 --> Controller Class Initialized
INFO - 2019-09-12 01:42:55 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 01:42:55 --> Final output sent to browser
DEBUG - 2019-09-12 01:42:55 --> Total execution time: 0.0511
INFO - 2019-09-12 07:35:46 --> Config Class Initialized
INFO - 2019-09-12 07:35:46 --> Hooks Class Initialized
DEBUG - 2019-09-12 07:35:47 --> UTF-8 Support Enabled
INFO - 2019-09-12 07:35:47 --> Utf8 Class Initialized
INFO - 2019-09-12 07:35:47 --> URI Class Initialized
INFO - 2019-09-12 07:35:47 --> Router Class Initialized
INFO - 2019-09-12 07:35:47 --> Output Class Initialized
INFO - 2019-09-12 07:35:47 --> Security Class Initialized
DEBUG - 2019-09-12 07:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 07:35:47 --> Input Class Initialized
INFO - 2019-09-12 07:35:47 --> Language Class Initialized
INFO - 2019-09-12 07:35:47 --> Loader Class Initialized
INFO - 2019-09-12 07:35:47 --> Helper loaded: url_helper
INFO - 2019-09-12 07:35:48 --> Helper loaded: html_helper
INFO - 2019-09-12 07:35:48 --> Helper loaded: form_helper
INFO - 2019-09-12 07:35:48 --> Helper loaded: cookie_helper
INFO - 2019-09-12 07:35:48 --> Helper loaded: date_helper
INFO - 2019-09-12 07:35:48 --> Form Validation Class Initialized
INFO - 2019-09-12 07:35:48 --> Email Class Initialized
DEBUG - 2019-09-12 07:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 07:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 07:35:48 --> Config Class Initialized
INFO - 2019-09-12 07:35:48 --> Hooks Class Initialized
DEBUG - 2019-09-12 07:35:48 --> UTF-8 Support Enabled
INFO - 2019-09-12 07:35:48 --> Utf8 Class Initialized
INFO - 2019-09-12 07:35:48 --> URI Class Initialized
INFO - 2019-09-12 07:35:48 --> Router Class Initialized
INFO - 2019-09-12 07:35:48 --> Output Class Initialized
INFO - 2019-09-12 07:35:48 --> Security Class Initialized
DEBUG - 2019-09-12 07:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 07:35:48 --> Input Class Initialized
INFO - 2019-09-12 07:35:48 --> Language Class Initialized
INFO - 2019-09-12 07:35:48 --> Loader Class Initialized
INFO - 2019-09-12 07:35:48 --> Helper loaded: url_helper
INFO - 2019-09-12 07:35:48 --> Helper loaded: html_helper
INFO - 2019-09-12 07:35:48 --> Helper loaded: form_helper
INFO - 2019-09-12 07:35:48 --> Helper loaded: cookie_helper
INFO - 2019-09-12 07:35:48 --> Helper loaded: date_helper
INFO - 2019-09-12 07:35:48 --> Form Validation Class Initialized
INFO - 2019-09-12 07:35:48 --> Email Class Initialized
DEBUG - 2019-09-12 07:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 07:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 07:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 07:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 07:35:48 --> Pagination Class Initialized
INFO - 2019-09-12 07:35:48 --> Pagination Class Initialized
INFO - 2019-09-12 07:35:48 --> Database Driver Class Initialized
INFO - 2019-09-12 07:35:48 --> Database Driver Class Initialized
INFO - 2019-09-12 07:35:49 --> Database Driver Class Initialized
INFO - 2019-09-12 07:35:49 --> Database Driver Class Initialized
INFO - 2019-09-12 07:35:49 --> Controller Class Initialized
INFO - 2019-09-12 07:35:49 --> Controller Class Initialized
INFO - 2019-09-12 07:35:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 07:35:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 07:35:49 --> Final output sent to browser
INFO - 2019-09-12 07:35:49 --> Final output sent to browser
DEBUG - 2019-09-12 07:35:49 --> Total execution time: 1.2927
DEBUG - 2019-09-12 07:35:49 --> Total execution time: 2.6599
INFO - 2019-09-12 11:57:29 --> Config Class Initialized
INFO - 2019-09-12 11:57:29 --> Hooks Class Initialized
DEBUG - 2019-09-12 11:57:29 --> UTF-8 Support Enabled
INFO - 2019-09-12 11:57:29 --> Utf8 Class Initialized
INFO - 2019-09-12 11:57:29 --> URI Class Initialized
INFO - 2019-09-12 11:57:29 --> Router Class Initialized
INFO - 2019-09-12 11:57:29 --> Output Class Initialized
INFO - 2019-09-12 11:57:29 --> Security Class Initialized
DEBUG - 2019-09-12 11:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 11:57:29 --> Input Class Initialized
INFO - 2019-09-12 11:57:29 --> Language Class Initialized
INFO - 2019-09-12 11:57:29 --> Loader Class Initialized
INFO - 2019-09-12 11:57:29 --> Helper loaded: url_helper
INFO - 2019-09-12 11:57:29 --> Helper loaded: html_helper
INFO - 2019-09-12 11:57:29 --> Helper loaded: form_helper
INFO - 2019-09-12 11:57:29 --> Helper loaded: cookie_helper
INFO - 2019-09-12 11:57:29 --> Helper loaded: date_helper
INFO - 2019-09-12 11:57:29 --> Form Validation Class Initialized
INFO - 2019-09-12 11:57:29 --> Email Class Initialized
DEBUG - 2019-09-12 11:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 11:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 11:57:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 11:57:29 --> Pagination Class Initialized
INFO - 2019-09-12 11:57:29 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:29 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:29 --> Controller Class Initialized
INFO - 2019-09-12 11:57:30 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 11:57:30 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-12 11:57:30 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-12 11:57:30 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 11:57:30 --> Final output sent to browser
DEBUG - 2019-09-12 11:57:30 --> Total execution time: 1.2971
INFO - 2019-09-12 11:57:31 --> Config Class Initialized
INFO - 2019-09-12 11:57:31 --> Hooks Class Initialized
DEBUG - 2019-09-12 11:57:31 --> UTF-8 Support Enabled
INFO - 2019-09-12 11:57:31 --> Utf8 Class Initialized
INFO - 2019-09-12 11:57:31 --> URI Class Initialized
INFO - 2019-09-12 11:57:31 --> Router Class Initialized
INFO - 2019-09-12 11:57:31 --> Output Class Initialized
INFO - 2019-09-12 11:57:31 --> Security Class Initialized
DEBUG - 2019-09-12 11:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 11:57:31 --> Input Class Initialized
INFO - 2019-09-12 11:57:31 --> Language Class Initialized
INFO - 2019-09-12 11:57:31 --> Loader Class Initialized
INFO - 2019-09-12 11:57:31 --> Helper loaded: url_helper
INFO - 2019-09-12 11:57:31 --> Helper loaded: html_helper
INFO - 2019-09-12 11:57:31 --> Helper loaded: form_helper
INFO - 2019-09-12 11:57:31 --> Helper loaded: cookie_helper
INFO - 2019-09-12 11:57:31 --> Helper loaded: date_helper
INFO - 2019-09-12 11:57:31 --> Form Validation Class Initialized
INFO - 2019-09-12 11:57:31 --> Email Class Initialized
DEBUG - 2019-09-12 11:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 11:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 11:57:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 11:57:31 --> Pagination Class Initialized
INFO - 2019-09-12 11:57:31 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:31 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:31 --> Controller Class Initialized
INFO - 2019-09-12 11:57:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 11:57:31 --> Final output sent to browser
DEBUG - 2019-09-12 11:57:31 --> Total execution time: 0.1317
INFO - 2019-09-12 11:57:31 --> Config Class Initialized
INFO - 2019-09-12 11:57:31 --> Hooks Class Initialized
DEBUG - 2019-09-12 11:57:31 --> UTF-8 Support Enabled
INFO - 2019-09-12 11:57:31 --> Utf8 Class Initialized
INFO - 2019-09-12 11:57:31 --> URI Class Initialized
INFO - 2019-09-12 11:57:31 --> Router Class Initialized
INFO - 2019-09-12 11:57:31 --> Output Class Initialized
INFO - 2019-09-12 11:57:31 --> Security Class Initialized
DEBUG - 2019-09-12 11:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 11:57:31 --> Input Class Initialized
INFO - 2019-09-12 11:57:31 --> Language Class Initialized
INFO - 2019-09-12 11:57:31 --> Loader Class Initialized
INFO - 2019-09-12 11:57:31 --> Helper loaded: url_helper
INFO - 2019-09-12 11:57:31 --> Helper loaded: html_helper
INFO - 2019-09-12 11:57:31 --> Helper loaded: form_helper
INFO - 2019-09-12 11:57:31 --> Helper loaded: cookie_helper
INFO - 2019-09-12 11:57:31 --> Helper loaded: date_helper
INFO - 2019-09-12 11:57:31 --> Form Validation Class Initialized
INFO - 2019-09-12 11:57:31 --> Email Class Initialized
DEBUG - 2019-09-12 11:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 11:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 11:57:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 11:57:31 --> Pagination Class Initialized
INFO - 2019-09-12 11:57:31 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:31 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:31 --> Controller Class Initialized
INFO - 2019-09-12 11:57:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 11:57:31 --> Final output sent to browser
DEBUG - 2019-09-12 11:57:31 --> Total execution time: 0.2256
INFO - 2019-09-12 11:57:35 --> Config Class Initialized
INFO - 2019-09-12 11:57:35 --> Hooks Class Initialized
DEBUG - 2019-09-12 11:57:35 --> UTF-8 Support Enabled
INFO - 2019-09-12 11:57:35 --> Utf8 Class Initialized
INFO - 2019-09-12 11:57:35 --> URI Class Initialized
INFO - 2019-09-12 11:57:35 --> Router Class Initialized
INFO - 2019-09-12 11:57:35 --> Output Class Initialized
INFO - 2019-09-12 11:57:35 --> Security Class Initialized
DEBUG - 2019-09-12 11:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 11:57:35 --> Input Class Initialized
INFO - 2019-09-12 11:57:35 --> Language Class Initialized
INFO - 2019-09-12 11:57:35 --> Loader Class Initialized
INFO - 2019-09-12 11:57:35 --> Helper loaded: url_helper
INFO - 2019-09-12 11:57:35 --> Helper loaded: html_helper
INFO - 2019-09-12 11:57:35 --> Helper loaded: form_helper
INFO - 2019-09-12 11:57:35 --> Helper loaded: cookie_helper
INFO - 2019-09-12 11:57:35 --> Helper loaded: date_helper
INFO - 2019-09-12 11:57:35 --> Form Validation Class Initialized
INFO - 2019-09-12 11:57:35 --> Email Class Initialized
DEBUG - 2019-09-12 11:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 11:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 11:57:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 11:57:35 --> Pagination Class Initialized
INFO - 2019-09-12 11:57:35 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:35 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:36 --> Controller Class Initialized
INFO - 2019-09-12 11:57:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 11:57:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-12 11:57:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-12 11:57:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 11:57:36 --> Final output sent to browser
DEBUG - 2019-09-12 11:57:36 --> Total execution time: 0.3126
INFO - 2019-09-12 11:57:36 --> Config Class Initialized
INFO - 2019-09-12 11:57:36 --> Hooks Class Initialized
DEBUG - 2019-09-12 11:57:36 --> UTF-8 Support Enabled
INFO - 2019-09-12 11:57:36 --> Utf8 Class Initialized
INFO - 2019-09-12 11:57:36 --> URI Class Initialized
INFO - 2019-09-12 11:57:36 --> Router Class Initialized
INFO - 2019-09-12 11:57:36 --> Output Class Initialized
INFO - 2019-09-12 11:57:36 --> Security Class Initialized
DEBUG - 2019-09-12 11:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 11:57:36 --> Input Class Initialized
INFO - 2019-09-12 11:57:36 --> Language Class Initialized
INFO - 2019-09-12 11:57:36 --> Loader Class Initialized
INFO - 2019-09-12 11:57:36 --> Helper loaded: url_helper
INFO - 2019-09-12 11:57:36 --> Helper loaded: html_helper
INFO - 2019-09-12 11:57:36 --> Helper loaded: form_helper
INFO - 2019-09-12 11:57:36 --> Helper loaded: cookie_helper
INFO - 2019-09-12 11:57:36 --> Helper loaded: date_helper
INFO - 2019-09-12 11:57:36 --> Form Validation Class Initialized
INFO - 2019-09-12 11:57:36 --> Email Class Initialized
DEBUG - 2019-09-12 11:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 11:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 11:57:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 11:57:36 --> Pagination Class Initialized
INFO - 2019-09-12 11:57:36 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:36 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:36 --> Controller Class Initialized
INFO - 2019-09-12 11:57:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 11:57:36 --> Final output sent to browser
DEBUG - 2019-09-12 11:57:36 --> Total execution time: 0.0680
INFO - 2019-09-12 11:57:36 --> Config Class Initialized
INFO - 2019-09-12 11:57:36 --> Hooks Class Initialized
DEBUG - 2019-09-12 11:57:36 --> UTF-8 Support Enabled
INFO - 2019-09-12 11:57:36 --> Utf8 Class Initialized
INFO - 2019-09-12 11:57:36 --> URI Class Initialized
INFO - 2019-09-12 11:57:36 --> Router Class Initialized
INFO - 2019-09-12 11:57:36 --> Output Class Initialized
INFO - 2019-09-12 11:57:36 --> Security Class Initialized
DEBUG - 2019-09-12 11:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 11:57:36 --> Input Class Initialized
INFO - 2019-09-12 11:57:36 --> Language Class Initialized
INFO - 2019-09-12 11:57:36 --> Loader Class Initialized
INFO - 2019-09-12 11:57:36 --> Helper loaded: url_helper
INFO - 2019-09-12 11:57:36 --> Helper loaded: html_helper
INFO - 2019-09-12 11:57:36 --> Helper loaded: form_helper
INFO - 2019-09-12 11:57:36 --> Helper loaded: cookie_helper
INFO - 2019-09-12 11:57:36 --> Helper loaded: date_helper
INFO - 2019-09-12 11:57:36 --> Form Validation Class Initialized
INFO - 2019-09-12 11:57:36 --> Email Class Initialized
DEBUG - 2019-09-12 11:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 11:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 11:57:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 11:57:36 --> Pagination Class Initialized
INFO - 2019-09-12 11:57:36 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:36 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:36 --> Controller Class Initialized
INFO - 2019-09-12 11:57:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 11:57:36 --> Final output sent to browser
DEBUG - 2019-09-12 11:57:36 --> Total execution time: 0.0804
INFO - 2019-09-12 11:57:38 --> Config Class Initialized
INFO - 2019-09-12 11:57:38 --> Hooks Class Initialized
DEBUG - 2019-09-12 11:57:38 --> UTF-8 Support Enabled
INFO - 2019-09-12 11:57:38 --> Utf8 Class Initialized
INFO - 2019-09-12 11:57:38 --> URI Class Initialized
INFO - 2019-09-12 11:57:38 --> Router Class Initialized
INFO - 2019-09-12 11:57:38 --> Output Class Initialized
INFO - 2019-09-12 11:57:38 --> Security Class Initialized
DEBUG - 2019-09-12 11:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 11:57:38 --> Input Class Initialized
INFO - 2019-09-12 11:57:38 --> Language Class Initialized
INFO - 2019-09-12 11:57:38 --> Loader Class Initialized
INFO - 2019-09-12 11:57:38 --> Helper loaded: url_helper
INFO - 2019-09-12 11:57:38 --> Helper loaded: html_helper
INFO - 2019-09-12 11:57:38 --> Helper loaded: form_helper
INFO - 2019-09-12 11:57:38 --> Helper loaded: cookie_helper
INFO - 2019-09-12 11:57:38 --> Helper loaded: date_helper
INFO - 2019-09-12 11:57:38 --> Form Validation Class Initialized
INFO - 2019-09-12 11:57:38 --> Email Class Initialized
DEBUG - 2019-09-12 11:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 11:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 11:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 11:57:38 --> Pagination Class Initialized
INFO - 2019-09-12 11:57:38 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:38 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:38 --> Controller Class Initialized
INFO - 2019-09-12 11:57:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 11:57:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-12 11:57:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 11:57:38 --> Final output sent to browser
DEBUG - 2019-09-12 11:57:38 --> Total execution time: 0.1191
INFO - 2019-09-12 11:57:38 --> Config Class Initialized
INFO - 2019-09-12 11:57:38 --> Hooks Class Initialized
DEBUG - 2019-09-12 11:57:38 --> UTF-8 Support Enabled
INFO - 2019-09-12 11:57:38 --> Utf8 Class Initialized
INFO - 2019-09-12 11:57:38 --> URI Class Initialized
INFO - 2019-09-12 11:57:38 --> Router Class Initialized
INFO - 2019-09-12 11:57:38 --> Output Class Initialized
INFO - 2019-09-12 11:57:38 --> Security Class Initialized
DEBUG - 2019-09-12 11:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 11:57:38 --> Input Class Initialized
INFO - 2019-09-12 11:57:38 --> Language Class Initialized
INFO - 2019-09-12 11:57:38 --> Loader Class Initialized
INFO - 2019-09-12 11:57:38 --> Helper loaded: url_helper
INFO - 2019-09-12 11:57:38 --> Helper loaded: html_helper
INFO - 2019-09-12 11:57:38 --> Helper loaded: form_helper
INFO - 2019-09-12 11:57:38 --> Helper loaded: cookie_helper
INFO - 2019-09-12 11:57:38 --> Helper loaded: date_helper
INFO - 2019-09-12 11:57:38 --> Form Validation Class Initialized
INFO - 2019-09-12 11:57:38 --> Email Class Initialized
DEBUG - 2019-09-12 11:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 11:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 11:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 11:57:38 --> Pagination Class Initialized
INFO - 2019-09-12 11:57:38 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:38 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:38 --> Controller Class Initialized
INFO - 2019-09-12 11:57:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 11:57:38 --> Final output sent to browser
DEBUG - 2019-09-12 11:57:38 --> Total execution time: 0.0637
INFO - 2019-09-12 11:57:38 --> Config Class Initialized
INFO - 2019-09-12 11:57:38 --> Hooks Class Initialized
DEBUG - 2019-09-12 11:57:38 --> UTF-8 Support Enabled
INFO - 2019-09-12 11:57:38 --> Utf8 Class Initialized
INFO - 2019-09-12 11:57:38 --> URI Class Initialized
INFO - 2019-09-12 11:57:38 --> Router Class Initialized
INFO - 2019-09-12 11:57:38 --> Output Class Initialized
INFO - 2019-09-12 11:57:38 --> Security Class Initialized
DEBUG - 2019-09-12 11:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 11:57:38 --> Input Class Initialized
INFO - 2019-09-12 11:57:38 --> Language Class Initialized
INFO - 2019-09-12 11:57:38 --> Loader Class Initialized
INFO - 2019-09-12 11:57:38 --> Helper loaded: url_helper
INFO - 2019-09-12 11:57:38 --> Helper loaded: html_helper
INFO - 2019-09-12 11:57:38 --> Helper loaded: form_helper
INFO - 2019-09-12 11:57:38 --> Helper loaded: cookie_helper
INFO - 2019-09-12 11:57:38 --> Helper loaded: date_helper
INFO - 2019-09-12 11:57:38 --> Form Validation Class Initialized
INFO - 2019-09-12 11:57:38 --> Email Class Initialized
DEBUG - 2019-09-12 11:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 11:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 11:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 11:57:38 --> Pagination Class Initialized
INFO - 2019-09-12 11:57:38 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:38 --> Database Driver Class Initialized
INFO - 2019-09-12 11:57:38 --> Controller Class Initialized
INFO - 2019-09-12 11:57:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 11:57:38 --> Final output sent to browser
DEBUG - 2019-09-12 11:57:38 --> Total execution time: 0.0580
INFO - 2019-09-12 11:58:18 --> Config Class Initialized
INFO - 2019-09-12 11:58:18 --> Hooks Class Initialized
DEBUG - 2019-09-12 11:58:18 --> UTF-8 Support Enabled
INFO - 2019-09-12 11:58:18 --> Utf8 Class Initialized
INFO - 2019-09-12 11:58:19 --> URI Class Initialized
INFO - 2019-09-12 11:58:19 --> Router Class Initialized
INFO - 2019-09-12 11:58:19 --> Output Class Initialized
INFO - 2019-09-12 11:58:19 --> Security Class Initialized
DEBUG - 2019-09-12 11:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 11:58:19 --> Input Class Initialized
INFO - 2019-09-12 11:58:19 --> Language Class Initialized
INFO - 2019-09-12 11:58:19 --> Loader Class Initialized
INFO - 2019-09-12 11:58:19 --> Helper loaded: url_helper
INFO - 2019-09-12 11:58:19 --> Helper loaded: html_helper
INFO - 2019-09-12 11:58:19 --> Helper loaded: form_helper
INFO - 2019-09-12 11:58:19 --> Helper loaded: cookie_helper
INFO - 2019-09-12 11:58:19 --> Helper loaded: date_helper
INFO - 2019-09-12 11:58:19 --> Form Validation Class Initialized
INFO - 2019-09-12 11:58:19 --> Email Class Initialized
DEBUG - 2019-09-12 11:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 11:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 11:58:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 11:58:19 --> Pagination Class Initialized
INFO - 2019-09-12 11:58:19 --> Database Driver Class Initialized
INFO - 2019-09-12 11:58:19 --> Database Driver Class Initialized
INFO - 2019-09-12 11:58:19 --> Controller Class Initialized
INFO - 2019-09-12 11:58:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-12 11:58:36 --> Config Class Initialized
INFO - 2019-09-12 11:58:36 --> Hooks Class Initialized
DEBUG - 2019-09-12 11:58:36 --> UTF-8 Support Enabled
INFO - 2019-09-12 11:58:36 --> Utf8 Class Initialized
INFO - 2019-09-12 11:58:36 --> URI Class Initialized
INFO - 2019-09-12 11:58:36 --> Router Class Initialized
INFO - 2019-09-12 11:58:36 --> Output Class Initialized
INFO - 2019-09-12 11:58:36 --> Security Class Initialized
DEBUG - 2019-09-12 11:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 11:58:36 --> Input Class Initialized
INFO - 2019-09-12 11:58:36 --> Language Class Initialized
INFO - 2019-09-12 11:58:36 --> Loader Class Initialized
INFO - 2019-09-12 11:58:36 --> Helper loaded: url_helper
INFO - 2019-09-12 11:58:36 --> Helper loaded: html_helper
INFO - 2019-09-12 11:58:36 --> Helper loaded: form_helper
INFO - 2019-09-12 11:58:36 --> Helper loaded: cookie_helper
INFO - 2019-09-12 11:58:36 --> Helper loaded: date_helper
INFO - 2019-09-12 11:58:36 --> Form Validation Class Initialized
INFO - 2019-09-12 11:58:36 --> Email Class Initialized
DEBUG - 2019-09-12 11:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 11:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 11:58:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 11:58:36 --> Pagination Class Initialized
INFO - 2019-09-12 11:58:36 --> Database Driver Class Initialized
INFO - 2019-09-12 11:58:36 --> Database Driver Class Initialized
INFO - 2019-09-12 11:58:36 --> Controller Class Initialized
INFO - 2019-09-12 11:58:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-12 11:58:38 --> Config Class Initialized
INFO - 2019-09-12 11:58:38 --> Hooks Class Initialized
DEBUG - 2019-09-12 11:58:38 --> UTF-8 Support Enabled
INFO - 2019-09-12 11:58:38 --> Utf8 Class Initialized
INFO - 2019-09-12 11:58:38 --> URI Class Initialized
INFO - 2019-09-12 11:58:38 --> Router Class Initialized
INFO - 2019-09-12 11:58:38 --> Output Class Initialized
INFO - 2019-09-12 11:58:38 --> Security Class Initialized
DEBUG - 2019-09-12 11:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 11:58:38 --> Input Class Initialized
INFO - 2019-09-12 11:58:38 --> Language Class Initialized
INFO - 2019-09-12 11:58:38 --> Loader Class Initialized
INFO - 2019-09-12 11:58:38 --> Helper loaded: url_helper
INFO - 2019-09-12 11:58:38 --> Helper loaded: html_helper
INFO - 2019-09-12 11:58:38 --> Helper loaded: form_helper
INFO - 2019-09-12 11:58:38 --> Helper loaded: cookie_helper
INFO - 2019-09-12 11:58:38 --> Helper loaded: date_helper
INFO - 2019-09-12 11:58:38 --> Form Validation Class Initialized
INFO - 2019-09-12 11:58:38 --> Email Class Initialized
DEBUG - 2019-09-12 11:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 11:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 11:58:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 11:58:38 --> Pagination Class Initialized
INFO - 2019-09-12 11:58:38 --> Database Driver Class Initialized
INFO - 2019-09-12 11:58:38 --> Database Driver Class Initialized
INFO - 2019-09-12 11:58:38 --> Controller Class Initialized
INFO - 2019-09-12 11:58:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 11:58:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-12 11:58:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 11:58:38 --> Final output sent to browser
DEBUG - 2019-09-12 11:58:38 --> Total execution time: 0.3782
INFO - 2019-09-12 11:58:38 --> Config Class Initialized
INFO - 2019-09-12 11:58:38 --> Hooks Class Initialized
DEBUG - 2019-09-12 11:58:38 --> UTF-8 Support Enabled
INFO - 2019-09-12 11:58:38 --> Utf8 Class Initialized
INFO - 2019-09-12 11:58:38 --> URI Class Initialized
INFO - 2019-09-12 11:58:38 --> Router Class Initialized
INFO - 2019-09-12 11:58:38 --> Output Class Initialized
INFO - 2019-09-12 11:58:38 --> Security Class Initialized
DEBUG - 2019-09-12 11:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 11:58:38 --> Input Class Initialized
INFO - 2019-09-12 11:58:38 --> Language Class Initialized
INFO - 2019-09-12 11:58:38 --> Loader Class Initialized
INFO - 2019-09-12 11:58:38 --> Helper loaded: url_helper
INFO - 2019-09-12 11:58:38 --> Helper loaded: html_helper
INFO - 2019-09-12 11:58:38 --> Helper loaded: form_helper
INFO - 2019-09-12 11:58:38 --> Helper loaded: cookie_helper
INFO - 2019-09-12 11:58:38 --> Helper loaded: date_helper
INFO - 2019-09-12 11:58:38 --> Form Validation Class Initialized
INFO - 2019-09-12 11:58:38 --> Email Class Initialized
DEBUG - 2019-09-12 11:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 11:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 11:58:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 11:58:38 --> Pagination Class Initialized
INFO - 2019-09-12 11:58:38 --> Database Driver Class Initialized
INFO - 2019-09-12 11:58:38 --> Database Driver Class Initialized
INFO - 2019-09-12 11:58:38 --> Controller Class Initialized
INFO - 2019-09-12 11:58:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 11:58:38 --> Final output sent to browser
DEBUG - 2019-09-12 11:58:38 --> Total execution time: 0.1468
INFO - 2019-09-12 11:58:38 --> Config Class Initialized
INFO - 2019-09-12 11:58:38 --> Hooks Class Initialized
DEBUG - 2019-09-12 11:58:38 --> UTF-8 Support Enabled
INFO - 2019-09-12 11:58:38 --> Utf8 Class Initialized
INFO - 2019-09-12 11:58:38 --> URI Class Initialized
INFO - 2019-09-12 11:58:38 --> Router Class Initialized
INFO - 2019-09-12 11:58:38 --> Output Class Initialized
INFO - 2019-09-12 11:58:38 --> Security Class Initialized
DEBUG - 2019-09-12 11:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 11:58:38 --> Input Class Initialized
INFO - 2019-09-12 11:58:38 --> Language Class Initialized
INFO - 2019-09-12 11:58:38 --> Loader Class Initialized
INFO - 2019-09-12 11:58:38 --> Helper loaded: url_helper
INFO - 2019-09-12 11:58:38 --> Helper loaded: html_helper
INFO - 2019-09-12 11:58:38 --> Helper loaded: form_helper
INFO - 2019-09-12 11:58:38 --> Helper loaded: cookie_helper
INFO - 2019-09-12 11:58:38 --> Helper loaded: date_helper
INFO - 2019-09-12 11:58:38 --> Form Validation Class Initialized
INFO - 2019-09-12 11:58:38 --> Email Class Initialized
DEBUG - 2019-09-12 11:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 11:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 11:58:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 11:58:38 --> Pagination Class Initialized
INFO - 2019-09-12 11:58:38 --> Database Driver Class Initialized
INFO - 2019-09-12 11:58:38 --> Database Driver Class Initialized
INFO - 2019-09-12 11:58:38 --> Controller Class Initialized
INFO - 2019-09-12 11:58:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 11:58:38 --> Final output sent to browser
DEBUG - 2019-09-12 11:58:38 --> Total execution time: 0.1922
INFO - 2019-09-12 14:19:02 --> Config Class Initialized
INFO - 2019-09-12 14:19:02 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:19:02 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:19:02 --> Utf8 Class Initialized
INFO - 2019-09-12 14:19:02 --> URI Class Initialized
INFO - 2019-09-12 14:19:02 --> Router Class Initialized
INFO - 2019-09-12 14:19:02 --> Output Class Initialized
INFO - 2019-09-12 14:19:02 --> Security Class Initialized
DEBUG - 2019-09-12 14:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:19:02 --> Input Class Initialized
INFO - 2019-09-12 14:19:02 --> Language Class Initialized
INFO - 2019-09-12 14:19:02 --> Loader Class Initialized
INFO - 2019-09-12 14:19:02 --> Helper loaded: url_helper
INFO - 2019-09-12 14:19:02 --> Helper loaded: html_helper
INFO - 2019-09-12 14:19:02 --> Helper loaded: form_helper
INFO - 2019-09-12 14:19:02 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:19:02 --> Helper loaded: date_helper
INFO - 2019-09-12 14:19:02 --> Form Validation Class Initialized
INFO - 2019-09-12 14:19:02 --> Email Class Initialized
DEBUG - 2019-09-12 14:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:19:02 --> Pagination Class Initialized
INFO - 2019-09-12 14:19:02 --> Database Driver Class Initialized
INFO - 2019-09-12 14:19:02 --> Database Driver Class Initialized
INFO - 2019-09-12 14:19:02 --> Controller Class Initialized
INFO - 2019-09-12 14:19:02 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 14:19:02 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-12 14:19:02 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-12 14:19:02 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 14:19:02 --> Final output sent to browser
DEBUG - 2019-09-12 14:19:02 --> Total execution time: 0.0793
INFO - 2019-09-12 14:19:02 --> Config Class Initialized
INFO - 2019-09-12 14:19:02 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:19:02 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:19:02 --> Utf8 Class Initialized
INFO - 2019-09-12 14:19:02 --> URI Class Initialized
INFO - 2019-09-12 14:19:02 --> Router Class Initialized
INFO - 2019-09-12 14:19:02 --> Output Class Initialized
INFO - 2019-09-12 14:19:02 --> Security Class Initialized
DEBUG - 2019-09-12 14:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:19:02 --> Input Class Initialized
INFO - 2019-09-12 14:19:02 --> Language Class Initialized
INFO - 2019-09-12 14:19:02 --> Loader Class Initialized
INFO - 2019-09-12 14:19:02 --> Helper loaded: url_helper
INFO - 2019-09-12 14:19:02 --> Helper loaded: html_helper
INFO - 2019-09-12 14:19:02 --> Helper loaded: form_helper
INFO - 2019-09-12 14:19:02 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:19:02 --> Helper loaded: date_helper
INFO - 2019-09-12 14:19:02 --> Form Validation Class Initialized
INFO - 2019-09-12 14:19:02 --> Email Class Initialized
DEBUG - 2019-09-12 14:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:19:02 --> Pagination Class Initialized
INFO - 2019-09-12 14:19:02 --> Database Driver Class Initialized
INFO - 2019-09-12 14:19:02 --> Database Driver Class Initialized
INFO - 2019-09-12 14:19:02 --> Controller Class Initialized
INFO - 2019-09-12 14:19:02 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:19:02 --> Final output sent to browser
DEBUG - 2019-09-12 14:19:02 --> Total execution time: 0.0619
INFO - 2019-09-12 14:19:02 --> Config Class Initialized
INFO - 2019-09-12 14:19:02 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:19:02 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:19:02 --> Utf8 Class Initialized
INFO - 2019-09-12 14:19:02 --> URI Class Initialized
INFO - 2019-09-12 14:19:02 --> Router Class Initialized
INFO - 2019-09-12 14:19:02 --> Output Class Initialized
INFO - 2019-09-12 14:19:02 --> Security Class Initialized
DEBUG - 2019-09-12 14:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:19:02 --> Input Class Initialized
INFO - 2019-09-12 14:19:02 --> Language Class Initialized
INFO - 2019-09-12 14:19:02 --> Loader Class Initialized
INFO - 2019-09-12 14:19:02 --> Helper loaded: url_helper
INFO - 2019-09-12 14:19:02 --> Helper loaded: html_helper
INFO - 2019-09-12 14:19:02 --> Helper loaded: form_helper
INFO - 2019-09-12 14:19:02 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:19:02 --> Helper loaded: date_helper
INFO - 2019-09-12 14:19:02 --> Form Validation Class Initialized
INFO - 2019-09-12 14:19:02 --> Email Class Initialized
DEBUG - 2019-09-12 14:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:19:02 --> Pagination Class Initialized
INFO - 2019-09-12 14:19:02 --> Database Driver Class Initialized
INFO - 2019-09-12 14:19:02 --> Database Driver Class Initialized
INFO - 2019-09-12 14:19:02 --> Controller Class Initialized
INFO - 2019-09-12 14:19:02 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:19:02 --> Final output sent to browser
DEBUG - 2019-09-12 14:19:02 --> Total execution time: 0.0829
INFO - 2019-09-12 14:19:04 --> Config Class Initialized
INFO - 2019-09-12 14:19:04 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:19:04 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:19:04 --> Utf8 Class Initialized
INFO - 2019-09-12 14:19:04 --> URI Class Initialized
INFO - 2019-09-12 14:19:04 --> Router Class Initialized
INFO - 2019-09-12 14:19:04 --> Output Class Initialized
INFO - 2019-09-12 14:19:04 --> Security Class Initialized
DEBUG - 2019-09-12 14:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:19:04 --> Input Class Initialized
INFO - 2019-09-12 14:19:04 --> Language Class Initialized
INFO - 2019-09-12 14:19:04 --> Loader Class Initialized
INFO - 2019-09-12 14:19:04 --> Helper loaded: url_helper
INFO - 2019-09-12 14:19:04 --> Helper loaded: html_helper
INFO - 2019-09-12 14:19:04 --> Helper loaded: form_helper
INFO - 2019-09-12 14:19:04 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:19:04 --> Helper loaded: date_helper
INFO - 2019-09-12 14:19:04 --> Form Validation Class Initialized
INFO - 2019-09-12 14:19:04 --> Email Class Initialized
DEBUG - 2019-09-12 14:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:19:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:19:04 --> Pagination Class Initialized
INFO - 2019-09-12 14:19:04 --> Database Driver Class Initialized
INFO - 2019-09-12 14:19:04 --> Database Driver Class Initialized
INFO - 2019-09-12 14:19:04 --> Controller Class Initialized
INFO - 2019-09-12 14:19:04 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 14:19:04 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-12 14:19:04 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-12 14:19:04 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 14:19:04 --> Final output sent to browser
DEBUG - 2019-09-12 14:19:04 --> Total execution time: 0.0655
INFO - 2019-09-12 14:19:04 --> Config Class Initialized
INFO - 2019-09-12 14:19:04 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:19:04 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:19:04 --> Utf8 Class Initialized
INFO - 2019-09-12 14:19:04 --> URI Class Initialized
INFO - 2019-09-12 14:19:04 --> Router Class Initialized
INFO - 2019-09-12 14:19:04 --> Output Class Initialized
INFO - 2019-09-12 14:19:04 --> Security Class Initialized
DEBUG - 2019-09-12 14:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:19:04 --> Input Class Initialized
INFO - 2019-09-12 14:19:04 --> Language Class Initialized
INFO - 2019-09-12 14:19:04 --> Loader Class Initialized
INFO - 2019-09-12 14:19:04 --> Helper loaded: url_helper
INFO - 2019-09-12 14:19:04 --> Helper loaded: html_helper
INFO - 2019-09-12 14:19:04 --> Helper loaded: form_helper
INFO - 2019-09-12 14:19:04 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:19:04 --> Helper loaded: date_helper
INFO - 2019-09-12 14:19:04 --> Form Validation Class Initialized
INFO - 2019-09-12 14:19:04 --> Email Class Initialized
DEBUG - 2019-09-12 14:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:19:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:19:04 --> Pagination Class Initialized
INFO - 2019-09-12 14:19:04 --> Database Driver Class Initialized
INFO - 2019-09-12 14:19:04 --> Database Driver Class Initialized
INFO - 2019-09-12 14:19:04 --> Controller Class Initialized
INFO - 2019-09-12 14:19:04 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:19:04 --> Final output sent to browser
DEBUG - 2019-09-12 14:19:04 --> Total execution time: 0.0646
INFO - 2019-09-12 14:19:05 --> Config Class Initialized
INFO - 2019-09-12 14:19:05 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:19:05 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:19:05 --> Utf8 Class Initialized
INFO - 2019-09-12 14:19:05 --> URI Class Initialized
INFO - 2019-09-12 14:19:05 --> Router Class Initialized
INFO - 2019-09-12 14:19:05 --> Output Class Initialized
INFO - 2019-09-12 14:19:05 --> Security Class Initialized
DEBUG - 2019-09-12 14:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:19:05 --> Input Class Initialized
INFO - 2019-09-12 14:19:05 --> Language Class Initialized
INFO - 2019-09-12 14:19:05 --> Loader Class Initialized
INFO - 2019-09-12 14:19:05 --> Helper loaded: url_helper
INFO - 2019-09-12 14:19:05 --> Helper loaded: html_helper
INFO - 2019-09-12 14:19:05 --> Helper loaded: form_helper
INFO - 2019-09-12 14:19:05 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:19:05 --> Helper loaded: date_helper
INFO - 2019-09-12 14:19:05 --> Form Validation Class Initialized
INFO - 2019-09-12 14:19:05 --> Email Class Initialized
DEBUG - 2019-09-12 14:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:19:05 --> Pagination Class Initialized
INFO - 2019-09-12 14:19:05 --> Database Driver Class Initialized
INFO - 2019-09-12 14:19:05 --> Database Driver Class Initialized
INFO - 2019-09-12 14:19:05 --> Controller Class Initialized
INFO - 2019-09-12 14:19:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:19:05 --> Final output sent to browser
DEBUG - 2019-09-12 14:19:05 --> Total execution time: 0.0763
INFO - 2019-09-12 14:20:39 --> Config Class Initialized
INFO - 2019-09-12 14:20:39 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:20:39 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:20:39 --> Utf8 Class Initialized
INFO - 2019-09-12 14:20:39 --> URI Class Initialized
INFO - 2019-09-12 14:20:39 --> Router Class Initialized
INFO - 2019-09-12 14:20:39 --> Output Class Initialized
INFO - 2019-09-12 14:20:39 --> Security Class Initialized
DEBUG - 2019-09-12 14:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:20:39 --> Input Class Initialized
INFO - 2019-09-12 14:20:39 --> Language Class Initialized
INFO - 2019-09-12 14:20:39 --> Loader Class Initialized
INFO - 2019-09-12 14:20:39 --> Helper loaded: url_helper
INFO - 2019-09-12 14:20:39 --> Helper loaded: html_helper
INFO - 2019-09-12 14:20:39 --> Helper loaded: form_helper
INFO - 2019-09-12 14:20:39 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:20:39 --> Helper loaded: date_helper
INFO - 2019-09-12 14:20:39 --> Form Validation Class Initialized
INFO - 2019-09-12 14:20:39 --> Email Class Initialized
DEBUG - 2019-09-12 14:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:20:39 --> Pagination Class Initialized
INFO - 2019-09-12 14:20:39 --> Database Driver Class Initialized
INFO - 2019-09-12 14:20:39 --> Database Driver Class Initialized
INFO - 2019-09-12 14:20:39 --> Controller Class Initialized
INFO - 2019-09-12 14:20:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 14:20:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-12 14:20:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-12 14:20:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 14:20:39 --> Final output sent to browser
DEBUG - 2019-09-12 14:20:39 --> Total execution time: 0.1011
INFO - 2019-09-12 14:20:39 --> Config Class Initialized
INFO - 2019-09-12 14:20:39 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:20:39 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:20:39 --> Utf8 Class Initialized
INFO - 2019-09-12 14:20:39 --> URI Class Initialized
INFO - 2019-09-12 14:20:39 --> Router Class Initialized
INFO - 2019-09-12 14:20:39 --> Output Class Initialized
INFO - 2019-09-12 14:20:39 --> Security Class Initialized
DEBUG - 2019-09-12 14:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:20:39 --> Input Class Initialized
INFO - 2019-09-12 14:20:39 --> Language Class Initialized
INFO - 2019-09-12 14:20:39 --> Loader Class Initialized
INFO - 2019-09-12 14:20:39 --> Helper loaded: url_helper
INFO - 2019-09-12 14:20:39 --> Helper loaded: html_helper
INFO - 2019-09-12 14:20:39 --> Helper loaded: form_helper
INFO - 2019-09-12 14:20:39 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:20:39 --> Helper loaded: date_helper
INFO - 2019-09-12 14:20:39 --> Form Validation Class Initialized
INFO - 2019-09-12 14:20:39 --> Email Class Initialized
DEBUG - 2019-09-12 14:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:20:39 --> Pagination Class Initialized
INFO - 2019-09-12 14:20:39 --> Database Driver Class Initialized
INFO - 2019-09-12 14:20:39 --> Database Driver Class Initialized
INFO - 2019-09-12 14:20:39 --> Controller Class Initialized
INFO - 2019-09-12 14:20:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:20:39 --> Final output sent to browser
DEBUG - 2019-09-12 14:20:39 --> Total execution time: 0.0723
INFO - 2019-09-12 14:20:39 --> Config Class Initialized
INFO - 2019-09-12 14:20:39 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:20:39 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:20:39 --> Utf8 Class Initialized
INFO - 2019-09-12 14:20:39 --> URI Class Initialized
INFO - 2019-09-12 14:20:39 --> Router Class Initialized
INFO - 2019-09-12 14:20:39 --> Output Class Initialized
INFO - 2019-09-12 14:20:39 --> Security Class Initialized
DEBUG - 2019-09-12 14:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:20:39 --> Input Class Initialized
INFO - 2019-09-12 14:20:39 --> Language Class Initialized
INFO - 2019-09-12 14:20:39 --> Loader Class Initialized
INFO - 2019-09-12 14:20:39 --> Helper loaded: url_helper
INFO - 2019-09-12 14:20:39 --> Helper loaded: html_helper
INFO - 2019-09-12 14:20:39 --> Helper loaded: form_helper
INFO - 2019-09-12 14:20:39 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:20:39 --> Helper loaded: date_helper
INFO - 2019-09-12 14:20:39 --> Form Validation Class Initialized
INFO - 2019-09-12 14:20:39 --> Email Class Initialized
DEBUG - 2019-09-12 14:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:20:39 --> Pagination Class Initialized
INFO - 2019-09-12 14:20:39 --> Database Driver Class Initialized
INFO - 2019-09-12 14:20:39 --> Database Driver Class Initialized
INFO - 2019-09-12 14:20:39 --> Controller Class Initialized
INFO - 2019-09-12 14:20:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:20:39 --> Final output sent to browser
DEBUG - 2019-09-12 14:20:39 --> Total execution time: 0.0510
INFO - 2019-09-12 14:20:45 --> Config Class Initialized
INFO - 2019-09-12 14:20:45 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:20:45 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:20:45 --> Utf8 Class Initialized
INFO - 2019-09-12 14:20:45 --> URI Class Initialized
INFO - 2019-09-12 14:20:45 --> Router Class Initialized
INFO - 2019-09-12 14:20:45 --> Output Class Initialized
INFO - 2019-09-12 14:20:45 --> Security Class Initialized
DEBUG - 2019-09-12 14:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:20:45 --> Input Class Initialized
INFO - 2019-09-12 14:20:45 --> Language Class Initialized
INFO - 2019-09-12 14:20:45 --> Loader Class Initialized
INFO - 2019-09-12 14:20:45 --> Helper loaded: url_helper
INFO - 2019-09-12 14:20:45 --> Helper loaded: html_helper
INFO - 2019-09-12 14:20:45 --> Helper loaded: form_helper
INFO - 2019-09-12 14:20:45 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:20:45 --> Helper loaded: date_helper
INFO - 2019-09-12 14:20:45 --> Form Validation Class Initialized
INFO - 2019-09-12 14:20:45 --> Email Class Initialized
DEBUG - 2019-09-12 14:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:20:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:20:45 --> Pagination Class Initialized
INFO - 2019-09-12 14:20:45 --> Database Driver Class Initialized
INFO - 2019-09-12 14:20:45 --> Database Driver Class Initialized
INFO - 2019-09-12 14:20:45 --> Controller Class Initialized
INFO - 2019-09-12 14:20:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:20:45 --> Final output sent to browser
DEBUG - 2019-09-12 14:20:45 --> Total execution time: 0.0567
INFO - 2019-09-12 14:20:46 --> Config Class Initialized
INFO - 2019-09-12 14:20:46 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:20:46 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:20:46 --> Utf8 Class Initialized
INFO - 2019-09-12 14:20:46 --> URI Class Initialized
INFO - 2019-09-12 14:20:46 --> Router Class Initialized
INFO - 2019-09-12 14:20:46 --> Output Class Initialized
INFO - 2019-09-12 14:20:46 --> Security Class Initialized
DEBUG - 2019-09-12 14:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:20:46 --> Input Class Initialized
INFO - 2019-09-12 14:20:46 --> Language Class Initialized
INFO - 2019-09-12 14:20:46 --> Loader Class Initialized
INFO - 2019-09-12 14:20:46 --> Helper loaded: url_helper
INFO - 2019-09-12 14:20:46 --> Helper loaded: html_helper
INFO - 2019-09-12 14:20:46 --> Helper loaded: form_helper
INFO - 2019-09-12 14:20:46 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:20:46 --> Helper loaded: date_helper
INFO - 2019-09-12 14:20:46 --> Form Validation Class Initialized
INFO - 2019-09-12 14:20:46 --> Email Class Initialized
DEBUG - 2019-09-12 14:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:20:46 --> Pagination Class Initialized
INFO - 2019-09-12 14:20:46 --> Database Driver Class Initialized
INFO - 2019-09-12 14:20:46 --> Database Driver Class Initialized
INFO - 2019-09-12 14:20:46 --> Controller Class Initialized
INFO - 2019-09-12 14:20:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 14:20:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-12 14:20:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-12 14:20:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 14:20:46 --> Final output sent to browser
DEBUG - 2019-09-12 14:20:46 --> Total execution time: 0.0792
INFO - 2019-09-12 14:20:46 --> Config Class Initialized
INFO - 2019-09-12 14:20:46 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:20:46 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:20:46 --> Utf8 Class Initialized
INFO - 2019-09-12 14:20:46 --> URI Class Initialized
INFO - 2019-09-12 14:20:46 --> Router Class Initialized
INFO - 2019-09-12 14:20:46 --> Output Class Initialized
INFO - 2019-09-12 14:20:46 --> Security Class Initialized
DEBUG - 2019-09-12 14:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:20:46 --> Input Class Initialized
INFO - 2019-09-12 14:20:46 --> Language Class Initialized
INFO - 2019-09-12 14:20:46 --> Loader Class Initialized
INFO - 2019-09-12 14:20:46 --> Helper loaded: url_helper
INFO - 2019-09-12 14:20:46 --> Helper loaded: html_helper
INFO - 2019-09-12 14:20:46 --> Helper loaded: form_helper
INFO - 2019-09-12 14:20:46 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:20:46 --> Helper loaded: date_helper
INFO - 2019-09-12 14:20:46 --> Form Validation Class Initialized
INFO - 2019-09-12 14:20:46 --> Email Class Initialized
DEBUG - 2019-09-12 14:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:20:46 --> Pagination Class Initialized
INFO - 2019-09-12 14:20:46 --> Database Driver Class Initialized
INFO - 2019-09-12 14:20:46 --> Database Driver Class Initialized
INFO - 2019-09-12 14:20:46 --> Controller Class Initialized
INFO - 2019-09-12 14:20:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:20:46 --> Final output sent to browser
DEBUG - 2019-09-12 14:20:46 --> Total execution time: 0.0595
INFO - 2019-09-12 14:20:46 --> Config Class Initialized
INFO - 2019-09-12 14:20:46 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:20:46 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:20:46 --> Utf8 Class Initialized
INFO - 2019-09-12 14:20:46 --> URI Class Initialized
INFO - 2019-09-12 14:20:46 --> Router Class Initialized
INFO - 2019-09-12 14:20:46 --> Output Class Initialized
INFO - 2019-09-12 14:20:46 --> Security Class Initialized
DEBUG - 2019-09-12 14:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:20:46 --> Input Class Initialized
INFO - 2019-09-12 14:20:46 --> Language Class Initialized
INFO - 2019-09-12 14:20:46 --> Loader Class Initialized
INFO - 2019-09-12 14:20:46 --> Helper loaded: url_helper
INFO - 2019-09-12 14:20:46 --> Helper loaded: html_helper
INFO - 2019-09-12 14:20:46 --> Helper loaded: form_helper
INFO - 2019-09-12 14:20:46 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:20:46 --> Helper loaded: date_helper
INFO - 2019-09-12 14:20:46 --> Form Validation Class Initialized
INFO - 2019-09-12 14:20:46 --> Email Class Initialized
DEBUG - 2019-09-12 14:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:20:46 --> Pagination Class Initialized
INFO - 2019-09-12 14:20:46 --> Database Driver Class Initialized
INFO - 2019-09-12 14:20:46 --> Database Driver Class Initialized
INFO - 2019-09-12 14:20:46 --> Controller Class Initialized
INFO - 2019-09-12 14:20:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:20:46 --> Final output sent to browser
DEBUG - 2019-09-12 14:20:46 --> Total execution time: 0.0730
INFO - 2019-09-12 14:21:07 --> Config Class Initialized
INFO - 2019-09-12 14:21:07 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:21:07 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:21:07 --> Utf8 Class Initialized
INFO - 2019-09-12 14:21:07 --> URI Class Initialized
INFO - 2019-09-12 14:21:07 --> Router Class Initialized
INFO - 2019-09-12 14:21:07 --> Output Class Initialized
INFO - 2019-09-12 14:21:07 --> Security Class Initialized
DEBUG - 2019-09-12 14:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:21:07 --> Input Class Initialized
INFO - 2019-09-12 14:21:07 --> Language Class Initialized
INFO - 2019-09-12 14:21:07 --> Loader Class Initialized
INFO - 2019-09-12 14:21:07 --> Helper loaded: url_helper
INFO - 2019-09-12 14:21:07 --> Helper loaded: html_helper
INFO - 2019-09-12 14:21:07 --> Helper loaded: form_helper
INFO - 2019-09-12 14:21:07 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:21:07 --> Helper loaded: date_helper
INFO - 2019-09-12 14:21:07 --> Form Validation Class Initialized
INFO - 2019-09-12 14:21:07 --> Email Class Initialized
DEBUG - 2019-09-12 14:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:21:07 --> Pagination Class Initialized
INFO - 2019-09-12 14:21:07 --> Database Driver Class Initialized
INFO - 2019-09-12 14:21:07 --> Database Driver Class Initialized
INFO - 2019-09-12 14:21:07 --> Controller Class Initialized
INFO - 2019-09-12 14:21:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-12 14:21:08 --> Config Class Initialized
INFO - 2019-09-12 14:21:08 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:21:08 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:21:08 --> Utf8 Class Initialized
INFO - 2019-09-12 14:21:08 --> URI Class Initialized
INFO - 2019-09-12 14:21:08 --> Router Class Initialized
INFO - 2019-09-12 14:21:08 --> Output Class Initialized
INFO - 2019-09-12 14:21:08 --> Security Class Initialized
DEBUG - 2019-09-12 14:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:21:08 --> Input Class Initialized
INFO - 2019-09-12 14:21:08 --> Language Class Initialized
INFO - 2019-09-12 14:21:08 --> Loader Class Initialized
INFO - 2019-09-12 14:21:08 --> Helper loaded: url_helper
INFO - 2019-09-12 14:21:08 --> Helper loaded: html_helper
INFO - 2019-09-12 14:21:08 --> Helper loaded: form_helper
INFO - 2019-09-12 14:21:08 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:21:08 --> Helper loaded: date_helper
INFO - 2019-09-12 14:21:08 --> Form Validation Class Initialized
INFO - 2019-09-12 14:21:08 --> Email Class Initialized
DEBUG - 2019-09-12 14:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:21:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:21:08 --> Pagination Class Initialized
INFO - 2019-09-12 14:21:08 --> Database Driver Class Initialized
INFO - 2019-09-12 14:21:08 --> Database Driver Class Initialized
INFO - 2019-09-12 14:21:08 --> Controller Class Initialized
INFO - 2019-09-12 14:21:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 14:21:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-12 14:21:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-12 14:21:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 14:21:08 --> Final output sent to browser
DEBUG - 2019-09-12 14:21:08 --> Total execution time: 0.0693
INFO - 2019-09-12 14:21:08 --> Config Class Initialized
INFO - 2019-09-12 14:21:08 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:21:08 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:21:08 --> Utf8 Class Initialized
INFO - 2019-09-12 14:21:08 --> URI Class Initialized
INFO - 2019-09-12 14:21:08 --> Router Class Initialized
INFO - 2019-09-12 14:21:08 --> Output Class Initialized
INFO - 2019-09-12 14:21:08 --> Security Class Initialized
DEBUG - 2019-09-12 14:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:21:08 --> Input Class Initialized
INFO - 2019-09-12 14:21:08 --> Language Class Initialized
INFO - 2019-09-12 14:21:08 --> Loader Class Initialized
INFO - 2019-09-12 14:21:08 --> Helper loaded: url_helper
INFO - 2019-09-12 14:21:08 --> Helper loaded: html_helper
INFO - 2019-09-12 14:21:08 --> Helper loaded: form_helper
INFO - 2019-09-12 14:21:08 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:21:08 --> Helper loaded: date_helper
INFO - 2019-09-12 14:21:08 --> Form Validation Class Initialized
INFO - 2019-09-12 14:21:08 --> Email Class Initialized
DEBUG - 2019-09-12 14:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:21:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:21:08 --> Pagination Class Initialized
INFO - 2019-09-12 14:21:08 --> Database Driver Class Initialized
INFO - 2019-09-12 14:21:08 --> Database Driver Class Initialized
INFO - 2019-09-12 14:21:08 --> Controller Class Initialized
INFO - 2019-09-12 14:21:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:21:08 --> Final output sent to browser
DEBUG - 2019-09-12 14:21:08 --> Total execution time: 0.0613
INFO - 2019-09-12 14:21:08 --> Config Class Initialized
INFO - 2019-09-12 14:21:08 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:21:08 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:21:08 --> Utf8 Class Initialized
INFO - 2019-09-12 14:21:08 --> URI Class Initialized
INFO - 2019-09-12 14:21:08 --> Router Class Initialized
INFO - 2019-09-12 14:21:08 --> Output Class Initialized
INFO - 2019-09-12 14:21:08 --> Security Class Initialized
DEBUG - 2019-09-12 14:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:21:08 --> Input Class Initialized
INFO - 2019-09-12 14:21:08 --> Language Class Initialized
INFO - 2019-09-12 14:21:08 --> Loader Class Initialized
INFO - 2019-09-12 14:21:08 --> Helper loaded: url_helper
INFO - 2019-09-12 14:21:08 --> Helper loaded: html_helper
INFO - 2019-09-12 14:21:08 --> Helper loaded: form_helper
INFO - 2019-09-12 14:21:08 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:21:08 --> Helper loaded: date_helper
INFO - 2019-09-12 14:21:08 --> Form Validation Class Initialized
INFO - 2019-09-12 14:21:08 --> Email Class Initialized
DEBUG - 2019-09-12 14:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:21:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:21:08 --> Pagination Class Initialized
INFO - 2019-09-12 14:21:08 --> Database Driver Class Initialized
INFO - 2019-09-12 14:21:08 --> Database Driver Class Initialized
INFO - 2019-09-12 14:21:08 --> Controller Class Initialized
INFO - 2019-09-12 14:21:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:21:08 --> Final output sent to browser
DEBUG - 2019-09-12 14:21:08 --> Total execution time: 0.0672
INFO - 2019-09-12 14:22:09 --> Config Class Initialized
INFO - 2019-09-12 14:22:09 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:22:09 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:22:09 --> Utf8 Class Initialized
INFO - 2019-09-12 14:22:09 --> URI Class Initialized
INFO - 2019-09-12 14:22:09 --> Router Class Initialized
INFO - 2019-09-12 14:22:09 --> Output Class Initialized
INFO - 2019-09-12 14:22:09 --> Security Class Initialized
DEBUG - 2019-09-12 14:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:22:09 --> Input Class Initialized
INFO - 2019-09-12 14:22:09 --> Language Class Initialized
INFO - 2019-09-12 14:22:09 --> Loader Class Initialized
INFO - 2019-09-12 14:22:09 --> Helper loaded: url_helper
INFO - 2019-09-12 14:22:09 --> Helper loaded: html_helper
INFO - 2019-09-12 14:22:09 --> Helper loaded: form_helper
INFO - 2019-09-12 14:22:09 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:22:09 --> Helper loaded: date_helper
INFO - 2019-09-12 14:22:09 --> Form Validation Class Initialized
INFO - 2019-09-12 14:22:09 --> Email Class Initialized
DEBUG - 2019-09-12 14:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:22:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:22:09 --> Pagination Class Initialized
INFO - 2019-09-12 14:22:09 --> Database Driver Class Initialized
INFO - 2019-09-12 14:22:09 --> Database Driver Class Initialized
INFO - 2019-09-12 14:22:09 --> Controller Class Initialized
INFO - 2019-09-12 14:22:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 14:22:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-12 14:22:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 14:22:09 --> Final output sent to browser
DEBUG - 2019-09-12 14:22:09 --> Total execution time: 0.0673
INFO - 2019-09-12 14:22:09 --> Config Class Initialized
INFO - 2019-09-12 14:22:09 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:22:09 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:22:09 --> Utf8 Class Initialized
INFO - 2019-09-12 14:22:09 --> URI Class Initialized
INFO - 2019-09-12 14:22:09 --> Router Class Initialized
INFO - 2019-09-12 14:22:09 --> Output Class Initialized
INFO - 2019-09-12 14:22:09 --> Security Class Initialized
DEBUG - 2019-09-12 14:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:22:09 --> Input Class Initialized
INFO - 2019-09-12 14:22:09 --> Language Class Initialized
INFO - 2019-09-12 14:22:09 --> Loader Class Initialized
INFO - 2019-09-12 14:22:09 --> Helper loaded: url_helper
INFO - 2019-09-12 14:22:09 --> Helper loaded: html_helper
INFO - 2019-09-12 14:22:09 --> Helper loaded: form_helper
INFO - 2019-09-12 14:22:09 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:22:09 --> Helper loaded: date_helper
INFO - 2019-09-12 14:22:09 --> Form Validation Class Initialized
INFO - 2019-09-12 14:22:09 --> Email Class Initialized
DEBUG - 2019-09-12 14:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:22:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:22:09 --> Pagination Class Initialized
INFO - 2019-09-12 14:22:09 --> Database Driver Class Initialized
INFO - 2019-09-12 14:22:09 --> Database Driver Class Initialized
INFO - 2019-09-12 14:22:09 --> Controller Class Initialized
INFO - 2019-09-12 14:22:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:22:09 --> Final output sent to browser
DEBUG - 2019-09-12 14:22:09 --> Total execution time: 0.0609
INFO - 2019-09-12 14:22:09 --> Config Class Initialized
INFO - 2019-09-12 14:22:09 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:22:09 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:22:09 --> Utf8 Class Initialized
INFO - 2019-09-12 14:22:09 --> URI Class Initialized
INFO - 2019-09-12 14:22:09 --> Router Class Initialized
INFO - 2019-09-12 14:22:09 --> Output Class Initialized
INFO - 2019-09-12 14:22:09 --> Security Class Initialized
DEBUG - 2019-09-12 14:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:22:09 --> Input Class Initialized
INFO - 2019-09-12 14:22:09 --> Language Class Initialized
INFO - 2019-09-12 14:22:09 --> Loader Class Initialized
INFO - 2019-09-12 14:22:09 --> Helper loaded: url_helper
INFO - 2019-09-12 14:22:09 --> Helper loaded: html_helper
INFO - 2019-09-12 14:22:09 --> Helper loaded: form_helper
INFO - 2019-09-12 14:22:09 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:22:09 --> Helper loaded: date_helper
INFO - 2019-09-12 14:22:09 --> Form Validation Class Initialized
INFO - 2019-09-12 14:22:09 --> Email Class Initialized
DEBUG - 2019-09-12 14:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:22:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:22:09 --> Pagination Class Initialized
INFO - 2019-09-12 14:22:09 --> Database Driver Class Initialized
INFO - 2019-09-12 14:22:09 --> Database Driver Class Initialized
INFO - 2019-09-12 14:22:09 --> Controller Class Initialized
INFO - 2019-09-12 14:22:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:22:09 --> Final output sent to browser
DEBUG - 2019-09-12 14:22:09 --> Total execution time: 0.0685
INFO - 2019-09-12 14:22:14 --> Config Class Initialized
INFO - 2019-09-12 14:22:14 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:22:14 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:22:14 --> Utf8 Class Initialized
INFO - 2019-09-12 14:22:14 --> URI Class Initialized
INFO - 2019-09-12 14:22:14 --> Router Class Initialized
INFO - 2019-09-12 14:22:14 --> Output Class Initialized
INFO - 2019-09-12 14:22:14 --> Security Class Initialized
DEBUG - 2019-09-12 14:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:22:14 --> Input Class Initialized
INFO - 2019-09-12 14:22:14 --> Language Class Initialized
INFO - 2019-09-12 14:22:14 --> Loader Class Initialized
INFO - 2019-09-12 14:22:14 --> Helper loaded: url_helper
INFO - 2019-09-12 14:22:14 --> Helper loaded: html_helper
INFO - 2019-09-12 14:22:14 --> Helper loaded: form_helper
INFO - 2019-09-12 14:22:14 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:22:14 --> Helper loaded: date_helper
INFO - 2019-09-12 14:22:14 --> Form Validation Class Initialized
INFO - 2019-09-12 14:22:14 --> Email Class Initialized
DEBUG - 2019-09-12 14:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:22:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:22:14 --> Pagination Class Initialized
INFO - 2019-09-12 14:22:14 --> Database Driver Class Initialized
INFO - 2019-09-12 14:22:14 --> Database Driver Class Initialized
INFO - 2019-09-12 14:22:14 --> Controller Class Initialized
INFO - 2019-09-12 14:22:14 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 14:22:14 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-12 14:22:14 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-12 14:22:14 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 14:22:14 --> Final output sent to browser
DEBUG - 2019-09-12 14:22:14 --> Total execution time: 0.1204
INFO - 2019-09-12 14:22:14 --> Config Class Initialized
INFO - 2019-09-12 14:22:14 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:22:14 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:22:14 --> Utf8 Class Initialized
INFO - 2019-09-12 14:22:14 --> URI Class Initialized
INFO - 2019-09-12 14:22:14 --> Router Class Initialized
INFO - 2019-09-12 14:22:14 --> Output Class Initialized
INFO - 2019-09-12 14:22:14 --> Security Class Initialized
DEBUG - 2019-09-12 14:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:22:14 --> Input Class Initialized
INFO - 2019-09-12 14:22:14 --> Language Class Initialized
INFO - 2019-09-12 14:22:14 --> Loader Class Initialized
INFO - 2019-09-12 14:22:14 --> Helper loaded: url_helper
INFO - 2019-09-12 14:22:14 --> Helper loaded: html_helper
INFO - 2019-09-12 14:22:14 --> Helper loaded: form_helper
INFO - 2019-09-12 14:22:14 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:22:14 --> Helper loaded: date_helper
INFO - 2019-09-12 14:22:14 --> Form Validation Class Initialized
INFO - 2019-09-12 14:22:14 --> Email Class Initialized
DEBUG - 2019-09-12 14:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:22:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:22:14 --> Pagination Class Initialized
INFO - 2019-09-12 14:22:14 --> Database Driver Class Initialized
INFO - 2019-09-12 14:22:14 --> Database Driver Class Initialized
INFO - 2019-09-12 14:22:14 --> Controller Class Initialized
INFO - 2019-09-12 14:22:14 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:22:14 --> Final output sent to browser
DEBUG - 2019-09-12 14:22:14 --> Total execution time: 0.0591
INFO - 2019-09-12 14:22:14 --> Config Class Initialized
INFO - 2019-09-12 14:22:14 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:22:14 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:22:14 --> Utf8 Class Initialized
INFO - 2019-09-12 14:22:14 --> URI Class Initialized
INFO - 2019-09-12 14:22:14 --> Router Class Initialized
INFO - 2019-09-12 14:22:14 --> Output Class Initialized
INFO - 2019-09-12 14:22:14 --> Security Class Initialized
DEBUG - 2019-09-12 14:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:22:14 --> Input Class Initialized
INFO - 2019-09-12 14:22:14 --> Language Class Initialized
INFO - 2019-09-12 14:22:14 --> Loader Class Initialized
INFO - 2019-09-12 14:22:14 --> Helper loaded: url_helper
INFO - 2019-09-12 14:22:14 --> Helper loaded: html_helper
INFO - 2019-09-12 14:22:14 --> Helper loaded: form_helper
INFO - 2019-09-12 14:22:14 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:22:14 --> Helper loaded: date_helper
INFO - 2019-09-12 14:22:14 --> Form Validation Class Initialized
INFO - 2019-09-12 14:22:14 --> Email Class Initialized
DEBUG - 2019-09-12 14:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:22:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:22:14 --> Pagination Class Initialized
INFO - 2019-09-12 14:22:14 --> Database Driver Class Initialized
INFO - 2019-09-12 14:22:14 --> Database Driver Class Initialized
INFO - 2019-09-12 14:22:14 --> Controller Class Initialized
INFO - 2019-09-12 14:22:14 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:22:14 --> Final output sent to browser
DEBUG - 2019-09-12 14:22:14 --> Total execution time: 0.0651
INFO - 2019-09-12 14:23:36 --> Config Class Initialized
INFO - 2019-09-12 14:23:36 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:23:36 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:23:36 --> Utf8 Class Initialized
INFO - 2019-09-12 14:23:36 --> URI Class Initialized
INFO - 2019-09-12 14:23:36 --> Router Class Initialized
INFO - 2019-09-12 14:23:36 --> Output Class Initialized
INFO - 2019-09-12 14:23:36 --> Security Class Initialized
DEBUG - 2019-09-12 14:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:23:36 --> Input Class Initialized
INFO - 2019-09-12 14:23:36 --> Language Class Initialized
INFO - 2019-09-12 14:23:36 --> Loader Class Initialized
INFO - 2019-09-12 14:23:36 --> Helper loaded: url_helper
INFO - 2019-09-12 14:23:36 --> Helper loaded: html_helper
INFO - 2019-09-12 14:23:36 --> Helper loaded: form_helper
INFO - 2019-09-12 14:23:36 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:23:36 --> Helper loaded: date_helper
INFO - 2019-09-12 14:23:36 --> Form Validation Class Initialized
INFO - 2019-09-12 14:23:36 --> Email Class Initialized
DEBUG - 2019-09-12 14:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:23:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:23:36 --> Pagination Class Initialized
INFO - 2019-09-12 14:23:36 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:36 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:36 --> Controller Class Initialized
INFO - 2019-09-12 14:23:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 14:23:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-12 14:23:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-12 14:23:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 14:23:36 --> Final output sent to browser
DEBUG - 2019-09-12 14:23:36 --> Total execution time: 0.0633
INFO - 2019-09-12 14:23:36 --> Config Class Initialized
INFO - 2019-09-12 14:23:36 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:23:36 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:23:36 --> Utf8 Class Initialized
INFO - 2019-09-12 14:23:36 --> URI Class Initialized
INFO - 2019-09-12 14:23:36 --> Router Class Initialized
INFO - 2019-09-12 14:23:36 --> Output Class Initialized
INFO - 2019-09-12 14:23:36 --> Security Class Initialized
DEBUG - 2019-09-12 14:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:23:36 --> Input Class Initialized
INFO - 2019-09-12 14:23:36 --> Language Class Initialized
INFO - 2019-09-12 14:23:36 --> Loader Class Initialized
INFO - 2019-09-12 14:23:36 --> Helper loaded: url_helper
INFO - 2019-09-12 14:23:36 --> Helper loaded: html_helper
INFO - 2019-09-12 14:23:36 --> Helper loaded: form_helper
INFO - 2019-09-12 14:23:36 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:23:36 --> Helper loaded: date_helper
INFO - 2019-09-12 14:23:36 --> Form Validation Class Initialized
INFO - 2019-09-12 14:23:36 --> Email Class Initialized
DEBUG - 2019-09-12 14:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:23:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:23:36 --> Pagination Class Initialized
INFO - 2019-09-12 14:23:36 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:36 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:36 --> Controller Class Initialized
INFO - 2019-09-12 14:23:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:23:36 --> Final output sent to browser
DEBUG - 2019-09-12 14:23:36 --> Total execution time: 0.0564
INFO - 2019-09-12 14:23:36 --> Config Class Initialized
INFO - 2019-09-12 14:23:36 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:23:36 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:23:36 --> Utf8 Class Initialized
INFO - 2019-09-12 14:23:36 --> URI Class Initialized
INFO - 2019-09-12 14:23:36 --> Router Class Initialized
INFO - 2019-09-12 14:23:36 --> Output Class Initialized
INFO - 2019-09-12 14:23:36 --> Security Class Initialized
DEBUG - 2019-09-12 14:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:23:36 --> Input Class Initialized
INFO - 2019-09-12 14:23:36 --> Language Class Initialized
INFO - 2019-09-12 14:23:36 --> Loader Class Initialized
INFO - 2019-09-12 14:23:36 --> Helper loaded: url_helper
INFO - 2019-09-12 14:23:36 --> Helper loaded: html_helper
INFO - 2019-09-12 14:23:36 --> Helper loaded: form_helper
INFO - 2019-09-12 14:23:36 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:23:36 --> Helper loaded: date_helper
INFO - 2019-09-12 14:23:36 --> Form Validation Class Initialized
INFO - 2019-09-12 14:23:36 --> Email Class Initialized
DEBUG - 2019-09-12 14:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:23:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:23:36 --> Pagination Class Initialized
INFO - 2019-09-12 14:23:36 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:36 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:36 --> Controller Class Initialized
INFO - 2019-09-12 14:23:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:23:36 --> Final output sent to browser
DEBUG - 2019-09-12 14:23:36 --> Total execution time: 0.0797
INFO - 2019-09-12 14:23:38 --> Config Class Initialized
INFO - 2019-09-12 14:23:38 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:23:38 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:23:38 --> Utf8 Class Initialized
INFO - 2019-09-12 14:23:38 --> URI Class Initialized
INFO - 2019-09-12 14:23:38 --> Router Class Initialized
INFO - 2019-09-12 14:23:38 --> Output Class Initialized
INFO - 2019-09-12 14:23:38 --> Security Class Initialized
DEBUG - 2019-09-12 14:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:23:38 --> Input Class Initialized
INFO - 2019-09-12 14:23:38 --> Language Class Initialized
INFO - 2019-09-12 14:23:38 --> Loader Class Initialized
INFO - 2019-09-12 14:23:38 --> Helper loaded: url_helper
INFO - 2019-09-12 14:23:38 --> Helper loaded: html_helper
INFO - 2019-09-12 14:23:38 --> Helper loaded: form_helper
INFO - 2019-09-12 14:23:38 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:23:38 --> Helper loaded: date_helper
INFO - 2019-09-12 14:23:38 --> Form Validation Class Initialized
INFO - 2019-09-12 14:23:38 --> Email Class Initialized
DEBUG - 2019-09-12 14:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:23:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:23:38 --> Pagination Class Initialized
INFO - 2019-09-12 14:23:38 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:38 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:38 --> Controller Class Initialized
INFO - 2019-09-12 14:23:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 14:23:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-12 14:23:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 14:23:38 --> Final output sent to browser
DEBUG - 2019-09-12 14:23:38 --> Total execution time: 0.0715
INFO - 2019-09-12 14:23:38 --> Config Class Initialized
INFO - 2019-09-12 14:23:38 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:23:38 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:23:38 --> Utf8 Class Initialized
INFO - 2019-09-12 14:23:38 --> URI Class Initialized
INFO - 2019-09-12 14:23:38 --> Router Class Initialized
INFO - 2019-09-12 14:23:38 --> Output Class Initialized
INFO - 2019-09-12 14:23:38 --> Security Class Initialized
DEBUG - 2019-09-12 14:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:23:38 --> Input Class Initialized
INFO - 2019-09-12 14:23:38 --> Language Class Initialized
INFO - 2019-09-12 14:23:38 --> Loader Class Initialized
INFO - 2019-09-12 14:23:38 --> Helper loaded: url_helper
INFO - 2019-09-12 14:23:38 --> Helper loaded: html_helper
INFO - 2019-09-12 14:23:38 --> Helper loaded: form_helper
INFO - 2019-09-12 14:23:38 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:23:38 --> Helper loaded: date_helper
INFO - 2019-09-12 14:23:38 --> Form Validation Class Initialized
INFO - 2019-09-12 14:23:38 --> Email Class Initialized
DEBUG - 2019-09-12 14:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:23:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:23:38 --> Pagination Class Initialized
INFO - 2019-09-12 14:23:39 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:39 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:39 --> Controller Class Initialized
INFO - 2019-09-12 14:23:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:23:39 --> Final output sent to browser
DEBUG - 2019-09-12 14:23:39 --> Total execution time: 0.0615
INFO - 2019-09-12 14:23:39 --> Config Class Initialized
INFO - 2019-09-12 14:23:39 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:23:39 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:23:39 --> Utf8 Class Initialized
INFO - 2019-09-12 14:23:39 --> URI Class Initialized
INFO - 2019-09-12 14:23:39 --> Router Class Initialized
INFO - 2019-09-12 14:23:39 --> Output Class Initialized
INFO - 2019-09-12 14:23:39 --> Security Class Initialized
DEBUG - 2019-09-12 14:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:23:39 --> Input Class Initialized
INFO - 2019-09-12 14:23:39 --> Language Class Initialized
INFO - 2019-09-12 14:23:39 --> Loader Class Initialized
INFO - 2019-09-12 14:23:39 --> Helper loaded: url_helper
INFO - 2019-09-12 14:23:39 --> Helper loaded: html_helper
INFO - 2019-09-12 14:23:39 --> Helper loaded: form_helper
INFO - 2019-09-12 14:23:39 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:23:39 --> Helper loaded: date_helper
INFO - 2019-09-12 14:23:39 --> Form Validation Class Initialized
INFO - 2019-09-12 14:23:39 --> Email Class Initialized
DEBUG - 2019-09-12 14:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:23:39 --> Pagination Class Initialized
INFO - 2019-09-12 14:23:39 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:39 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:39 --> Controller Class Initialized
INFO - 2019-09-12 14:23:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:23:39 --> Final output sent to browser
DEBUG - 2019-09-12 14:23:39 --> Total execution time: 0.0627
INFO - 2019-09-12 14:23:50 --> Config Class Initialized
INFO - 2019-09-12 14:23:50 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:23:50 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:23:50 --> Utf8 Class Initialized
INFO - 2019-09-12 14:23:50 --> URI Class Initialized
INFO - 2019-09-12 14:23:50 --> Router Class Initialized
INFO - 2019-09-12 14:23:50 --> Output Class Initialized
INFO - 2019-09-12 14:23:50 --> Security Class Initialized
DEBUG - 2019-09-12 14:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:23:50 --> Input Class Initialized
INFO - 2019-09-12 14:23:50 --> Language Class Initialized
INFO - 2019-09-12 14:23:50 --> Loader Class Initialized
INFO - 2019-09-12 14:23:50 --> Helper loaded: url_helper
INFO - 2019-09-12 14:23:50 --> Helper loaded: html_helper
INFO - 2019-09-12 14:23:50 --> Helper loaded: form_helper
INFO - 2019-09-12 14:23:50 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:23:50 --> Helper loaded: date_helper
INFO - 2019-09-12 14:23:50 --> Form Validation Class Initialized
INFO - 2019-09-12 14:23:50 --> Email Class Initialized
DEBUG - 2019-09-12 14:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:23:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:23:50 --> Pagination Class Initialized
INFO - 2019-09-12 14:23:50 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:50 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:50 --> Controller Class Initialized
INFO - 2019-09-12 14:23:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-12 14:23:51 --> Config Class Initialized
INFO - 2019-09-12 14:23:51 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:23:51 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:23:51 --> Utf8 Class Initialized
INFO - 2019-09-12 14:23:51 --> URI Class Initialized
INFO - 2019-09-12 14:23:51 --> Router Class Initialized
INFO - 2019-09-12 14:23:51 --> Output Class Initialized
INFO - 2019-09-12 14:23:51 --> Security Class Initialized
DEBUG - 2019-09-12 14:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:23:51 --> Input Class Initialized
INFO - 2019-09-12 14:23:51 --> Language Class Initialized
INFO - 2019-09-12 14:23:51 --> Loader Class Initialized
INFO - 2019-09-12 14:23:51 --> Helper loaded: url_helper
INFO - 2019-09-12 14:23:51 --> Helper loaded: html_helper
INFO - 2019-09-12 14:23:51 --> Helper loaded: form_helper
INFO - 2019-09-12 14:23:51 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:23:51 --> Helper loaded: date_helper
INFO - 2019-09-12 14:23:51 --> Form Validation Class Initialized
INFO - 2019-09-12 14:23:51 --> Email Class Initialized
DEBUG - 2019-09-12 14:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:23:51 --> Pagination Class Initialized
INFO - 2019-09-12 14:23:51 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:51 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:51 --> Controller Class Initialized
INFO - 2019-09-12 14:23:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 14:23:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-12 14:23:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 14:23:51 --> Final output sent to browser
DEBUG - 2019-09-12 14:23:51 --> Total execution time: 0.0631
INFO - 2019-09-12 14:23:51 --> Config Class Initialized
INFO - 2019-09-12 14:23:51 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:23:51 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:23:51 --> Utf8 Class Initialized
INFO - 2019-09-12 14:23:51 --> URI Class Initialized
INFO - 2019-09-12 14:23:51 --> Router Class Initialized
INFO - 2019-09-12 14:23:51 --> Output Class Initialized
INFO - 2019-09-12 14:23:51 --> Security Class Initialized
DEBUG - 2019-09-12 14:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:23:51 --> Input Class Initialized
INFO - 2019-09-12 14:23:51 --> Language Class Initialized
INFO - 2019-09-12 14:23:51 --> Loader Class Initialized
INFO - 2019-09-12 14:23:51 --> Helper loaded: url_helper
INFO - 2019-09-12 14:23:51 --> Helper loaded: html_helper
INFO - 2019-09-12 14:23:51 --> Helper loaded: form_helper
INFO - 2019-09-12 14:23:51 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:23:51 --> Helper loaded: date_helper
INFO - 2019-09-12 14:23:51 --> Form Validation Class Initialized
INFO - 2019-09-12 14:23:51 --> Email Class Initialized
DEBUG - 2019-09-12 14:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:23:51 --> Pagination Class Initialized
INFO - 2019-09-12 14:23:51 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:51 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:51 --> Controller Class Initialized
INFO - 2019-09-12 14:23:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:23:51 --> Final output sent to browser
DEBUG - 2019-09-12 14:23:51 --> Total execution time: 0.0541
INFO - 2019-09-12 14:23:51 --> Config Class Initialized
INFO - 2019-09-12 14:23:51 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:23:51 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:23:51 --> Utf8 Class Initialized
INFO - 2019-09-12 14:23:51 --> URI Class Initialized
INFO - 2019-09-12 14:23:51 --> Router Class Initialized
INFO - 2019-09-12 14:23:51 --> Output Class Initialized
INFO - 2019-09-12 14:23:51 --> Security Class Initialized
DEBUG - 2019-09-12 14:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:23:51 --> Input Class Initialized
INFO - 2019-09-12 14:23:51 --> Language Class Initialized
INFO - 2019-09-12 14:23:51 --> Loader Class Initialized
INFO - 2019-09-12 14:23:51 --> Helper loaded: url_helper
INFO - 2019-09-12 14:23:51 --> Helper loaded: html_helper
INFO - 2019-09-12 14:23:51 --> Helper loaded: form_helper
INFO - 2019-09-12 14:23:51 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:23:51 --> Helper loaded: date_helper
INFO - 2019-09-12 14:23:51 --> Form Validation Class Initialized
INFO - 2019-09-12 14:23:51 --> Email Class Initialized
DEBUG - 2019-09-12 14:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:23:51 --> Pagination Class Initialized
INFO - 2019-09-12 14:23:51 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:51 --> Database Driver Class Initialized
INFO - 2019-09-12 14:23:51 --> Controller Class Initialized
INFO - 2019-09-12 14:23:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:23:51 --> Final output sent to browser
DEBUG - 2019-09-12 14:23:51 --> Total execution time: 0.0688
INFO - 2019-09-12 14:24:42 --> Config Class Initialized
INFO - 2019-09-12 14:24:42 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:24:42 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:24:42 --> Utf8 Class Initialized
INFO - 2019-09-12 14:24:42 --> URI Class Initialized
INFO - 2019-09-12 14:24:42 --> Router Class Initialized
INFO - 2019-09-12 14:24:42 --> Output Class Initialized
INFO - 2019-09-12 14:24:42 --> Security Class Initialized
DEBUG - 2019-09-12 14:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:24:42 --> Input Class Initialized
INFO - 2019-09-12 14:24:42 --> Language Class Initialized
INFO - 2019-09-12 14:24:42 --> Loader Class Initialized
INFO - 2019-09-12 14:24:42 --> Helper loaded: url_helper
INFO - 2019-09-12 14:24:42 --> Helper loaded: html_helper
INFO - 2019-09-12 14:24:42 --> Helper loaded: form_helper
INFO - 2019-09-12 14:24:42 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:24:42 --> Helper loaded: date_helper
INFO - 2019-09-12 14:24:42 --> Form Validation Class Initialized
INFO - 2019-09-12 14:24:42 --> Email Class Initialized
DEBUG - 2019-09-12 14:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:24:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:24:42 --> Pagination Class Initialized
INFO - 2019-09-12 14:24:42 --> Database Driver Class Initialized
INFO - 2019-09-12 14:24:42 --> Database Driver Class Initialized
INFO - 2019-09-12 14:24:42 --> Controller Class Initialized
INFO - 2019-09-12 14:24:42 --> Final output sent to browser
DEBUG - 2019-09-12 14:24:42 --> Total execution time: 0.0702
INFO - 2019-09-12 14:24:47 --> Config Class Initialized
INFO - 2019-09-12 14:24:47 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:24:47 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:24:47 --> Utf8 Class Initialized
INFO - 2019-09-12 14:24:47 --> URI Class Initialized
INFO - 2019-09-12 14:24:47 --> Router Class Initialized
INFO - 2019-09-12 14:24:47 --> Output Class Initialized
INFO - 2019-09-12 14:24:47 --> Security Class Initialized
DEBUG - 2019-09-12 14:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:24:47 --> Input Class Initialized
INFO - 2019-09-12 14:24:47 --> Language Class Initialized
INFO - 2019-09-12 14:24:47 --> Loader Class Initialized
INFO - 2019-09-12 14:24:47 --> Helper loaded: url_helper
INFO - 2019-09-12 14:24:47 --> Helper loaded: html_helper
INFO - 2019-09-12 14:24:47 --> Helper loaded: form_helper
INFO - 2019-09-12 14:24:47 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:24:47 --> Helper loaded: date_helper
INFO - 2019-09-12 14:24:47 --> Form Validation Class Initialized
INFO - 2019-09-12 14:24:47 --> Email Class Initialized
DEBUG - 2019-09-12 14:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:24:47 --> Pagination Class Initialized
INFO - 2019-09-12 14:24:47 --> Database Driver Class Initialized
INFO - 2019-09-12 14:24:47 --> Database Driver Class Initialized
INFO - 2019-09-12 14:24:47 --> Controller Class Initialized
INFO - 2019-09-12 14:24:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-12 14:24:47 --> Config Class Initialized
INFO - 2019-09-12 14:24:47 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:24:47 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:24:47 --> Utf8 Class Initialized
INFO - 2019-09-12 14:24:47 --> URI Class Initialized
INFO - 2019-09-12 14:24:47 --> Router Class Initialized
INFO - 2019-09-12 14:24:47 --> Output Class Initialized
INFO - 2019-09-12 14:24:47 --> Security Class Initialized
DEBUG - 2019-09-12 14:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:24:47 --> Input Class Initialized
INFO - 2019-09-12 14:24:47 --> Language Class Initialized
INFO - 2019-09-12 14:24:47 --> Loader Class Initialized
INFO - 2019-09-12 14:24:47 --> Helper loaded: url_helper
INFO - 2019-09-12 14:24:47 --> Helper loaded: html_helper
INFO - 2019-09-12 14:24:47 --> Helper loaded: form_helper
INFO - 2019-09-12 14:24:47 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:24:47 --> Helper loaded: date_helper
INFO - 2019-09-12 14:24:47 --> Form Validation Class Initialized
INFO - 2019-09-12 14:24:47 --> Email Class Initialized
DEBUG - 2019-09-12 14:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:24:47 --> Pagination Class Initialized
INFO - 2019-09-12 14:24:47 --> Database Driver Class Initialized
INFO - 2019-09-12 14:24:47 --> Database Driver Class Initialized
INFO - 2019-09-12 14:24:47 --> Controller Class Initialized
INFO - 2019-09-12 14:24:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 14:24:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-12 14:24:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 14:24:47 --> Final output sent to browser
DEBUG - 2019-09-12 14:24:47 --> Total execution time: 0.0589
INFO - 2019-09-12 14:24:47 --> Config Class Initialized
INFO - 2019-09-12 14:24:47 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:24:47 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:24:47 --> Utf8 Class Initialized
INFO - 2019-09-12 14:24:47 --> URI Class Initialized
INFO - 2019-09-12 14:24:47 --> Router Class Initialized
INFO - 2019-09-12 14:24:47 --> Output Class Initialized
INFO - 2019-09-12 14:24:47 --> Security Class Initialized
DEBUG - 2019-09-12 14:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:24:47 --> Input Class Initialized
INFO - 2019-09-12 14:24:47 --> Language Class Initialized
INFO - 2019-09-12 14:24:47 --> Loader Class Initialized
INFO - 2019-09-12 14:24:47 --> Helper loaded: url_helper
INFO - 2019-09-12 14:24:47 --> Helper loaded: html_helper
INFO - 2019-09-12 14:24:47 --> Helper loaded: form_helper
INFO - 2019-09-12 14:24:47 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:24:47 --> Helper loaded: date_helper
INFO - 2019-09-12 14:24:47 --> Form Validation Class Initialized
INFO - 2019-09-12 14:24:47 --> Email Class Initialized
DEBUG - 2019-09-12 14:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:24:47 --> Pagination Class Initialized
INFO - 2019-09-12 14:24:47 --> Database Driver Class Initialized
INFO - 2019-09-12 14:24:47 --> Database Driver Class Initialized
INFO - 2019-09-12 14:24:47 --> Controller Class Initialized
INFO - 2019-09-12 14:24:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:24:47 --> Final output sent to browser
DEBUG - 2019-09-12 14:24:47 --> Total execution time: 0.0614
INFO - 2019-09-12 14:24:47 --> Config Class Initialized
INFO - 2019-09-12 14:24:47 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:24:47 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:24:47 --> Utf8 Class Initialized
INFO - 2019-09-12 14:24:47 --> URI Class Initialized
INFO - 2019-09-12 14:24:47 --> Router Class Initialized
INFO - 2019-09-12 14:24:47 --> Output Class Initialized
INFO - 2019-09-12 14:24:47 --> Security Class Initialized
DEBUG - 2019-09-12 14:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:24:47 --> Input Class Initialized
INFO - 2019-09-12 14:24:47 --> Language Class Initialized
INFO - 2019-09-12 14:24:47 --> Loader Class Initialized
INFO - 2019-09-12 14:24:47 --> Helper loaded: url_helper
INFO - 2019-09-12 14:24:47 --> Helper loaded: html_helper
INFO - 2019-09-12 14:24:47 --> Helper loaded: form_helper
INFO - 2019-09-12 14:24:47 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:24:47 --> Helper loaded: date_helper
INFO - 2019-09-12 14:24:47 --> Form Validation Class Initialized
INFO - 2019-09-12 14:24:47 --> Email Class Initialized
DEBUG - 2019-09-12 14:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:24:47 --> Pagination Class Initialized
INFO - 2019-09-12 14:24:47 --> Database Driver Class Initialized
INFO - 2019-09-12 14:24:47 --> Database Driver Class Initialized
INFO - 2019-09-12 14:24:47 --> Controller Class Initialized
INFO - 2019-09-12 14:24:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:24:47 --> Final output sent to browser
DEBUG - 2019-09-12 14:24:47 --> Total execution time: 0.0717
INFO - 2019-09-12 14:24:53 --> Config Class Initialized
INFO - 2019-09-12 14:24:53 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:24:53 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:24:53 --> Utf8 Class Initialized
INFO - 2019-09-12 14:24:53 --> URI Class Initialized
INFO - 2019-09-12 14:24:53 --> Router Class Initialized
INFO - 2019-09-12 14:24:53 --> Output Class Initialized
INFO - 2019-09-12 14:24:53 --> Security Class Initialized
DEBUG - 2019-09-12 14:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:24:53 --> Input Class Initialized
INFO - 2019-09-12 14:24:53 --> Language Class Initialized
INFO - 2019-09-12 14:24:53 --> Loader Class Initialized
INFO - 2019-09-12 14:24:53 --> Helper loaded: url_helper
INFO - 2019-09-12 14:24:53 --> Helper loaded: html_helper
INFO - 2019-09-12 14:24:53 --> Helper loaded: form_helper
INFO - 2019-09-12 14:24:53 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:24:53 --> Helper loaded: date_helper
INFO - 2019-09-12 14:24:53 --> Form Validation Class Initialized
INFO - 2019-09-12 14:24:53 --> Email Class Initialized
DEBUG - 2019-09-12 14:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:24:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:24:53 --> Pagination Class Initialized
INFO - 2019-09-12 14:24:53 --> Database Driver Class Initialized
INFO - 2019-09-12 14:24:53 --> Database Driver Class Initialized
INFO - 2019-09-12 14:24:53 --> Controller Class Initialized
INFO - 2019-09-12 14:24:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 14:24:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-12 14:24:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 14:24:53 --> Final output sent to browser
DEBUG - 2019-09-12 14:24:53 --> Total execution time: 0.0824
INFO - 2019-09-12 14:24:53 --> Config Class Initialized
INFO - 2019-09-12 14:24:53 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:24:53 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:24:53 --> Utf8 Class Initialized
INFO - 2019-09-12 14:24:53 --> URI Class Initialized
INFO - 2019-09-12 14:24:53 --> Router Class Initialized
INFO - 2019-09-12 14:24:53 --> Output Class Initialized
INFO - 2019-09-12 14:24:53 --> Security Class Initialized
DEBUG - 2019-09-12 14:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:24:53 --> Input Class Initialized
INFO - 2019-09-12 14:24:53 --> Language Class Initialized
INFO - 2019-09-12 14:24:53 --> Loader Class Initialized
INFO - 2019-09-12 14:24:53 --> Helper loaded: url_helper
INFO - 2019-09-12 14:24:53 --> Helper loaded: html_helper
INFO - 2019-09-12 14:24:53 --> Helper loaded: form_helper
INFO - 2019-09-12 14:24:53 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:24:53 --> Helper loaded: date_helper
INFO - 2019-09-12 14:24:53 --> Form Validation Class Initialized
INFO - 2019-09-12 14:24:53 --> Email Class Initialized
DEBUG - 2019-09-12 14:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:24:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:24:53 --> Pagination Class Initialized
INFO - 2019-09-12 14:24:53 --> Database Driver Class Initialized
INFO - 2019-09-12 14:24:53 --> Database Driver Class Initialized
INFO - 2019-09-12 14:24:53 --> Controller Class Initialized
INFO - 2019-09-12 14:24:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:24:53 --> Final output sent to browser
DEBUG - 2019-09-12 14:24:53 --> Total execution time: 0.0612
INFO - 2019-09-12 14:24:53 --> Config Class Initialized
INFO - 2019-09-12 14:24:53 --> Hooks Class Initialized
DEBUG - 2019-09-12 14:24:53 --> UTF-8 Support Enabled
INFO - 2019-09-12 14:24:53 --> Utf8 Class Initialized
INFO - 2019-09-12 14:24:53 --> URI Class Initialized
INFO - 2019-09-12 14:24:53 --> Router Class Initialized
INFO - 2019-09-12 14:24:53 --> Output Class Initialized
INFO - 2019-09-12 14:24:53 --> Security Class Initialized
DEBUG - 2019-09-12 14:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 14:24:53 --> Input Class Initialized
INFO - 2019-09-12 14:24:53 --> Language Class Initialized
INFO - 2019-09-12 14:24:53 --> Loader Class Initialized
INFO - 2019-09-12 14:24:53 --> Helper loaded: url_helper
INFO - 2019-09-12 14:24:53 --> Helper loaded: html_helper
INFO - 2019-09-12 14:24:53 --> Helper loaded: form_helper
INFO - 2019-09-12 14:24:53 --> Helper loaded: cookie_helper
INFO - 2019-09-12 14:24:53 --> Helper loaded: date_helper
INFO - 2019-09-12 14:24:53 --> Form Validation Class Initialized
INFO - 2019-09-12 14:24:53 --> Email Class Initialized
DEBUG - 2019-09-12 14:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 14:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 14:24:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 14:24:53 --> Pagination Class Initialized
INFO - 2019-09-12 14:24:53 --> Database Driver Class Initialized
INFO - 2019-09-12 14:24:53 --> Database Driver Class Initialized
INFO - 2019-09-12 14:24:53 --> Controller Class Initialized
INFO - 2019-09-12 14:24:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 14:24:53 --> Final output sent to browser
DEBUG - 2019-09-12 14:24:53 --> Total execution time: 0.0698
INFO - 2019-09-12 16:14:33 --> Config Class Initialized
INFO - 2019-09-12 16:14:33 --> Hooks Class Initialized
DEBUG - 2019-09-12 16:14:33 --> UTF-8 Support Enabled
INFO - 2019-09-12 16:14:33 --> Utf8 Class Initialized
INFO - 2019-09-12 16:14:33 --> URI Class Initialized
INFO - 2019-09-12 16:14:33 --> Router Class Initialized
INFO - 2019-09-12 16:14:33 --> Output Class Initialized
INFO - 2019-09-12 16:14:33 --> Security Class Initialized
DEBUG - 2019-09-12 16:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 16:14:33 --> Input Class Initialized
INFO - 2019-09-12 16:14:33 --> Language Class Initialized
INFO - 2019-09-12 16:14:33 --> Loader Class Initialized
INFO - 2019-09-12 16:14:33 --> Helper loaded: url_helper
INFO - 2019-09-12 16:14:33 --> Helper loaded: html_helper
INFO - 2019-09-12 16:14:33 --> Helper loaded: form_helper
INFO - 2019-09-12 16:14:33 --> Helper loaded: cookie_helper
INFO - 2019-09-12 16:14:33 --> Helper loaded: date_helper
INFO - 2019-09-12 16:14:33 --> Form Validation Class Initialized
INFO - 2019-09-12 16:14:33 --> Email Class Initialized
DEBUG - 2019-09-12 16:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 16:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 16:14:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 16:14:33 --> Pagination Class Initialized
INFO - 2019-09-12 16:14:33 --> Database Driver Class Initialized
INFO - 2019-09-12 16:14:33 --> Database Driver Class Initialized
INFO - 2019-09-12 16:14:34 --> Controller Class Initialized
DEBUG - 2019-09-12 16:14:34 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-12 16:14:34 --> Helper loaded: inflector_helper
INFO - 2019-09-12 16:14:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-12 16:14:34 --> Final output sent to browser
DEBUG - 2019-09-12 16:14:34 --> Total execution time: 0.8857
INFO - 2019-09-12 16:16:43 --> Config Class Initialized
INFO - 2019-09-12 16:16:43 --> Hooks Class Initialized
DEBUG - 2019-09-12 16:16:43 --> UTF-8 Support Enabled
INFO - 2019-09-12 16:16:43 --> Utf8 Class Initialized
INFO - 2019-09-12 16:16:43 --> URI Class Initialized
INFO - 2019-09-12 16:16:43 --> Router Class Initialized
INFO - 2019-09-12 16:16:43 --> Output Class Initialized
INFO - 2019-09-12 16:16:43 --> Security Class Initialized
DEBUG - 2019-09-12 16:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 16:16:43 --> Input Class Initialized
INFO - 2019-09-12 16:16:43 --> Language Class Initialized
INFO - 2019-09-12 16:16:43 --> Loader Class Initialized
INFO - 2019-09-12 16:16:43 --> Helper loaded: url_helper
INFO - 2019-09-12 16:16:43 --> Helper loaded: html_helper
INFO - 2019-09-12 16:16:43 --> Helper loaded: form_helper
INFO - 2019-09-12 16:16:43 --> Helper loaded: cookie_helper
INFO - 2019-09-12 16:16:43 --> Helper loaded: date_helper
INFO - 2019-09-12 16:16:43 --> Form Validation Class Initialized
INFO - 2019-09-12 16:16:43 --> Email Class Initialized
DEBUG - 2019-09-12 16:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 16:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 16:16:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 16:16:43 --> Pagination Class Initialized
INFO - 2019-09-12 16:16:43 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:43 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:43 --> Controller Class Initialized
INFO - 2019-09-12 16:16:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 16:16:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-12 16:16:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 16:16:44 --> Final output sent to browser
DEBUG - 2019-09-12 16:16:44 --> Total execution time: 1.2774
INFO - 2019-09-12 16:16:46 --> Config Class Initialized
INFO - 2019-09-12 16:16:46 --> Hooks Class Initialized
DEBUG - 2019-09-12 16:16:46 --> UTF-8 Support Enabled
INFO - 2019-09-12 16:16:46 --> Utf8 Class Initialized
INFO - 2019-09-12 16:16:46 --> URI Class Initialized
INFO - 2019-09-12 16:16:46 --> Router Class Initialized
INFO - 2019-09-12 16:16:46 --> Output Class Initialized
INFO - 2019-09-12 16:16:46 --> Security Class Initialized
DEBUG - 2019-09-12 16:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 16:16:46 --> Input Class Initialized
INFO - 2019-09-12 16:16:46 --> Language Class Initialized
INFO - 2019-09-12 16:16:46 --> Loader Class Initialized
INFO - 2019-09-12 16:16:46 --> Helper loaded: url_helper
INFO - 2019-09-12 16:16:46 --> Helper loaded: html_helper
INFO - 2019-09-12 16:16:46 --> Helper loaded: form_helper
INFO - 2019-09-12 16:16:46 --> Helper loaded: cookie_helper
INFO - 2019-09-12 16:16:46 --> Helper loaded: date_helper
INFO - 2019-09-12 16:16:46 --> Form Validation Class Initialized
INFO - 2019-09-12 16:16:46 --> Email Class Initialized
DEBUG - 2019-09-12 16:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 16:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 16:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 16:16:46 --> Pagination Class Initialized
INFO - 2019-09-12 16:16:46 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:46 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:46 --> Controller Class Initialized
INFO - 2019-09-12 16:16:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 16:16:46 --> Final output sent to browser
DEBUG - 2019-09-12 16:16:46 --> Total execution time: 0.0790
INFO - 2019-09-12 16:16:46 --> Config Class Initialized
INFO - 2019-09-12 16:16:46 --> Hooks Class Initialized
DEBUG - 2019-09-12 16:16:46 --> UTF-8 Support Enabled
INFO - 2019-09-12 16:16:46 --> Utf8 Class Initialized
INFO - 2019-09-12 16:16:46 --> URI Class Initialized
INFO - 2019-09-12 16:16:46 --> Router Class Initialized
INFO - 2019-09-12 16:16:46 --> Output Class Initialized
INFO - 2019-09-12 16:16:46 --> Security Class Initialized
DEBUG - 2019-09-12 16:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 16:16:46 --> Input Class Initialized
INFO - 2019-09-12 16:16:46 --> Language Class Initialized
INFO - 2019-09-12 16:16:46 --> Loader Class Initialized
INFO - 2019-09-12 16:16:46 --> Helper loaded: url_helper
INFO - 2019-09-12 16:16:46 --> Helper loaded: html_helper
INFO - 2019-09-12 16:16:46 --> Helper loaded: form_helper
INFO - 2019-09-12 16:16:46 --> Helper loaded: cookie_helper
INFO - 2019-09-12 16:16:46 --> Helper loaded: date_helper
INFO - 2019-09-12 16:16:46 --> Form Validation Class Initialized
INFO - 2019-09-12 16:16:46 --> Email Class Initialized
DEBUG - 2019-09-12 16:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 16:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 16:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 16:16:46 --> Pagination Class Initialized
INFO - 2019-09-12 16:16:46 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:46 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:46 --> Controller Class Initialized
INFO - 2019-09-12 16:16:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 16:16:46 --> Final output sent to browser
DEBUG - 2019-09-12 16:16:46 --> Total execution time: 0.0587
INFO - 2019-09-12 16:16:53 --> Config Class Initialized
INFO - 2019-09-12 16:16:53 --> Hooks Class Initialized
DEBUG - 2019-09-12 16:16:53 --> UTF-8 Support Enabled
INFO - 2019-09-12 16:16:53 --> Utf8 Class Initialized
INFO - 2019-09-12 16:16:53 --> URI Class Initialized
INFO - 2019-09-12 16:16:53 --> Router Class Initialized
INFO - 2019-09-12 16:16:53 --> Output Class Initialized
INFO - 2019-09-12 16:16:53 --> Security Class Initialized
DEBUG - 2019-09-12 16:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 16:16:53 --> Input Class Initialized
INFO - 2019-09-12 16:16:53 --> Language Class Initialized
INFO - 2019-09-12 16:16:53 --> Loader Class Initialized
INFO - 2019-09-12 16:16:53 --> Helper loaded: url_helper
INFO - 2019-09-12 16:16:53 --> Helper loaded: html_helper
INFO - 2019-09-12 16:16:53 --> Helper loaded: form_helper
INFO - 2019-09-12 16:16:53 --> Helper loaded: cookie_helper
INFO - 2019-09-12 16:16:53 --> Helper loaded: date_helper
INFO - 2019-09-12 16:16:53 --> Form Validation Class Initialized
INFO - 2019-09-12 16:16:53 --> Email Class Initialized
DEBUG - 2019-09-12 16:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 16:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 16:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 16:16:53 --> Pagination Class Initialized
INFO - 2019-09-12 16:16:53 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:53 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:53 --> Controller Class Initialized
INFO - 2019-09-12 16:16:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 16:16:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-12 16:16:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-12 16:16:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 16:16:53 --> Final output sent to browser
DEBUG - 2019-09-12 16:16:53 --> Total execution time: 0.1553
INFO - 2019-09-12 16:16:54 --> Config Class Initialized
INFO - 2019-09-12 16:16:54 --> Hooks Class Initialized
DEBUG - 2019-09-12 16:16:54 --> UTF-8 Support Enabled
INFO - 2019-09-12 16:16:54 --> Utf8 Class Initialized
INFO - 2019-09-12 16:16:54 --> URI Class Initialized
INFO - 2019-09-12 16:16:54 --> Router Class Initialized
INFO - 2019-09-12 16:16:54 --> Output Class Initialized
INFO - 2019-09-12 16:16:54 --> Security Class Initialized
DEBUG - 2019-09-12 16:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 16:16:54 --> Input Class Initialized
INFO - 2019-09-12 16:16:54 --> Language Class Initialized
INFO - 2019-09-12 16:16:54 --> Loader Class Initialized
INFO - 2019-09-12 16:16:54 --> Helper loaded: url_helper
INFO - 2019-09-12 16:16:54 --> Helper loaded: html_helper
INFO - 2019-09-12 16:16:54 --> Helper loaded: form_helper
INFO - 2019-09-12 16:16:54 --> Helper loaded: cookie_helper
INFO - 2019-09-12 16:16:54 --> Helper loaded: date_helper
INFO - 2019-09-12 16:16:54 --> Form Validation Class Initialized
INFO - 2019-09-12 16:16:54 --> Email Class Initialized
DEBUG - 2019-09-12 16:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 16:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 16:16:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 16:16:54 --> Pagination Class Initialized
INFO - 2019-09-12 16:16:54 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:54 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:54 --> Controller Class Initialized
INFO - 2019-09-12 16:16:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 16:16:54 --> Final output sent to browser
DEBUG - 2019-09-12 16:16:54 --> Total execution time: 0.0649
INFO - 2019-09-12 16:16:54 --> Config Class Initialized
INFO - 2019-09-12 16:16:54 --> Hooks Class Initialized
DEBUG - 2019-09-12 16:16:54 --> UTF-8 Support Enabled
INFO - 2019-09-12 16:16:54 --> Utf8 Class Initialized
INFO - 2019-09-12 16:16:54 --> URI Class Initialized
INFO - 2019-09-12 16:16:54 --> Router Class Initialized
INFO - 2019-09-12 16:16:54 --> Output Class Initialized
INFO - 2019-09-12 16:16:54 --> Security Class Initialized
DEBUG - 2019-09-12 16:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 16:16:54 --> Input Class Initialized
INFO - 2019-09-12 16:16:54 --> Language Class Initialized
INFO - 2019-09-12 16:16:54 --> Loader Class Initialized
INFO - 2019-09-12 16:16:54 --> Helper loaded: url_helper
INFO - 2019-09-12 16:16:54 --> Helper loaded: html_helper
INFO - 2019-09-12 16:16:54 --> Helper loaded: form_helper
INFO - 2019-09-12 16:16:54 --> Helper loaded: cookie_helper
INFO - 2019-09-12 16:16:54 --> Helper loaded: date_helper
INFO - 2019-09-12 16:16:54 --> Form Validation Class Initialized
INFO - 2019-09-12 16:16:54 --> Email Class Initialized
DEBUG - 2019-09-12 16:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 16:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 16:16:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 16:16:54 --> Pagination Class Initialized
INFO - 2019-09-12 16:16:54 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:54 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:54 --> Controller Class Initialized
INFO - 2019-09-12 16:16:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 16:16:54 --> Final output sent to browser
DEBUG - 2019-09-12 16:16:54 --> Total execution time: 0.0613
INFO - 2019-09-12 16:16:56 --> Config Class Initialized
INFO - 2019-09-12 16:16:56 --> Hooks Class Initialized
DEBUG - 2019-09-12 16:16:56 --> UTF-8 Support Enabled
INFO - 2019-09-12 16:16:56 --> Utf8 Class Initialized
INFO - 2019-09-12 16:16:56 --> URI Class Initialized
INFO - 2019-09-12 16:16:56 --> Router Class Initialized
INFO - 2019-09-12 16:16:56 --> Output Class Initialized
INFO - 2019-09-12 16:16:56 --> Security Class Initialized
DEBUG - 2019-09-12 16:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 16:16:56 --> Input Class Initialized
INFO - 2019-09-12 16:16:56 --> Language Class Initialized
INFO - 2019-09-12 16:16:56 --> Loader Class Initialized
INFO - 2019-09-12 16:16:56 --> Helper loaded: url_helper
INFO - 2019-09-12 16:16:56 --> Helper loaded: html_helper
INFO - 2019-09-12 16:16:56 --> Helper loaded: form_helper
INFO - 2019-09-12 16:16:56 --> Helper loaded: cookie_helper
INFO - 2019-09-12 16:16:56 --> Helper loaded: date_helper
INFO - 2019-09-12 16:16:56 --> Form Validation Class Initialized
INFO - 2019-09-12 16:16:56 --> Email Class Initialized
DEBUG - 2019-09-12 16:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 16:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 16:16:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 16:16:56 --> Pagination Class Initialized
INFO - 2019-09-12 16:16:56 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:56 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:56 --> Controller Class Initialized
INFO - 2019-09-12 16:16:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 16:16:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-12 16:16:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-12 16:16:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 16:16:56 --> Final output sent to browser
DEBUG - 2019-09-12 16:16:56 --> Total execution time: 0.0676
INFO - 2019-09-12 16:16:56 --> Config Class Initialized
INFO - 2019-09-12 16:16:56 --> Hooks Class Initialized
DEBUG - 2019-09-12 16:16:56 --> UTF-8 Support Enabled
INFO - 2019-09-12 16:16:56 --> Utf8 Class Initialized
INFO - 2019-09-12 16:16:56 --> URI Class Initialized
INFO - 2019-09-12 16:16:56 --> Router Class Initialized
INFO - 2019-09-12 16:16:56 --> Output Class Initialized
INFO - 2019-09-12 16:16:56 --> Security Class Initialized
DEBUG - 2019-09-12 16:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 16:16:56 --> Input Class Initialized
INFO - 2019-09-12 16:16:56 --> Language Class Initialized
INFO - 2019-09-12 16:16:56 --> Loader Class Initialized
INFO - 2019-09-12 16:16:56 --> Helper loaded: url_helper
INFO - 2019-09-12 16:16:56 --> Helper loaded: html_helper
INFO - 2019-09-12 16:16:56 --> Helper loaded: form_helper
INFO - 2019-09-12 16:16:56 --> Helper loaded: cookie_helper
INFO - 2019-09-12 16:16:56 --> Helper loaded: date_helper
INFO - 2019-09-12 16:16:56 --> Form Validation Class Initialized
INFO - 2019-09-12 16:16:56 --> Email Class Initialized
DEBUG - 2019-09-12 16:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 16:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 16:16:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 16:16:56 --> Pagination Class Initialized
INFO - 2019-09-12 16:16:56 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:56 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:56 --> Controller Class Initialized
INFO - 2019-09-12 16:16:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 16:16:56 --> Final output sent to browser
DEBUG - 2019-09-12 16:16:56 --> Total execution time: 0.0690
INFO - 2019-09-12 16:16:56 --> Config Class Initialized
INFO - 2019-09-12 16:16:56 --> Hooks Class Initialized
DEBUG - 2019-09-12 16:16:56 --> UTF-8 Support Enabled
INFO - 2019-09-12 16:16:56 --> Utf8 Class Initialized
INFO - 2019-09-12 16:16:56 --> URI Class Initialized
INFO - 2019-09-12 16:16:56 --> Router Class Initialized
INFO - 2019-09-12 16:16:56 --> Output Class Initialized
INFO - 2019-09-12 16:16:56 --> Security Class Initialized
DEBUG - 2019-09-12 16:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 16:16:56 --> Input Class Initialized
INFO - 2019-09-12 16:16:56 --> Language Class Initialized
INFO - 2019-09-12 16:16:56 --> Loader Class Initialized
INFO - 2019-09-12 16:16:56 --> Helper loaded: url_helper
INFO - 2019-09-12 16:16:56 --> Helper loaded: html_helper
INFO - 2019-09-12 16:16:56 --> Helper loaded: form_helper
INFO - 2019-09-12 16:16:56 --> Helper loaded: cookie_helper
INFO - 2019-09-12 16:16:56 --> Helper loaded: date_helper
INFO - 2019-09-12 16:16:56 --> Form Validation Class Initialized
INFO - 2019-09-12 16:16:56 --> Email Class Initialized
DEBUG - 2019-09-12 16:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 16:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 16:16:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 16:16:56 --> Pagination Class Initialized
INFO - 2019-09-12 16:16:56 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:56 --> Database Driver Class Initialized
INFO - 2019-09-12 16:16:56 --> Controller Class Initialized
INFO - 2019-09-12 16:16:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 16:16:56 --> Final output sent to browser
DEBUG - 2019-09-12 16:16:56 --> Total execution time: 0.1410
INFO - 2019-09-12 16:17:02 --> Config Class Initialized
INFO - 2019-09-12 16:17:02 --> Hooks Class Initialized
DEBUG - 2019-09-12 16:17:02 --> UTF-8 Support Enabled
INFO - 2019-09-12 16:17:02 --> Utf8 Class Initialized
INFO - 2019-09-12 16:17:02 --> URI Class Initialized
INFO - 2019-09-12 16:17:02 --> Router Class Initialized
INFO - 2019-09-12 16:17:02 --> Output Class Initialized
INFO - 2019-09-12 16:17:02 --> Security Class Initialized
DEBUG - 2019-09-12 16:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 16:17:02 --> Input Class Initialized
INFO - 2019-09-12 16:17:02 --> Language Class Initialized
INFO - 2019-09-12 16:17:02 --> Loader Class Initialized
INFO - 2019-09-12 16:17:02 --> Helper loaded: url_helper
INFO - 2019-09-12 16:17:02 --> Helper loaded: html_helper
INFO - 2019-09-12 16:17:02 --> Helper loaded: form_helper
INFO - 2019-09-12 16:17:02 --> Helper loaded: cookie_helper
INFO - 2019-09-12 16:17:02 --> Helper loaded: date_helper
INFO - 2019-09-12 16:17:02 --> Form Validation Class Initialized
INFO - 2019-09-12 16:17:02 --> Email Class Initialized
DEBUG - 2019-09-12 16:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 16:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 16:17:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 16:17:02 --> Pagination Class Initialized
INFO - 2019-09-12 16:17:02 --> Database Driver Class Initialized
INFO - 2019-09-12 16:17:02 --> Database Driver Class Initialized
INFO - 2019-09-12 16:17:02 --> Controller Class Initialized
INFO - 2019-09-12 16:17:02 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 16:17:02 --> Final output sent to browser
DEBUG - 2019-09-12 16:17:02 --> Total execution time: 0.0514
INFO - 2019-09-12 16:17:03 --> Config Class Initialized
INFO - 2019-09-12 16:17:03 --> Hooks Class Initialized
DEBUG - 2019-09-12 16:17:03 --> UTF-8 Support Enabled
INFO - 2019-09-12 16:17:03 --> Utf8 Class Initialized
INFO - 2019-09-12 16:17:03 --> URI Class Initialized
INFO - 2019-09-12 16:17:03 --> Router Class Initialized
INFO - 2019-09-12 16:17:03 --> Output Class Initialized
INFO - 2019-09-12 16:17:03 --> Security Class Initialized
DEBUG - 2019-09-12 16:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 16:17:03 --> Input Class Initialized
INFO - 2019-09-12 16:17:03 --> Language Class Initialized
INFO - 2019-09-12 16:17:03 --> Loader Class Initialized
INFO - 2019-09-12 16:17:03 --> Helper loaded: url_helper
INFO - 2019-09-12 16:17:03 --> Helper loaded: html_helper
INFO - 2019-09-12 16:17:03 --> Helper loaded: form_helper
INFO - 2019-09-12 16:17:03 --> Helper loaded: cookie_helper
INFO - 2019-09-12 16:17:03 --> Helper loaded: date_helper
INFO - 2019-09-12 16:17:03 --> Form Validation Class Initialized
INFO - 2019-09-12 16:17:03 --> Email Class Initialized
DEBUG - 2019-09-12 16:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 16:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 16:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 16:17:03 --> Pagination Class Initialized
INFO - 2019-09-12 16:17:03 --> Database Driver Class Initialized
INFO - 2019-09-12 16:17:03 --> Database Driver Class Initialized
INFO - 2019-09-12 16:17:03 --> Controller Class Initialized
INFO - 2019-09-12 16:17:03 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 16:17:03 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-12 16:17:03 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 16:17:03 --> Final output sent to browser
DEBUG - 2019-09-12 16:17:03 --> Total execution time: 0.0914
INFO - 2019-09-12 16:17:03 --> Config Class Initialized
INFO - 2019-09-12 16:17:03 --> Hooks Class Initialized
DEBUG - 2019-09-12 16:17:03 --> UTF-8 Support Enabled
INFO - 2019-09-12 16:17:03 --> Utf8 Class Initialized
INFO - 2019-09-12 16:17:03 --> URI Class Initialized
INFO - 2019-09-12 16:17:03 --> Router Class Initialized
INFO - 2019-09-12 16:17:03 --> Output Class Initialized
INFO - 2019-09-12 16:17:03 --> Security Class Initialized
DEBUG - 2019-09-12 16:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 16:17:03 --> Input Class Initialized
INFO - 2019-09-12 16:17:03 --> Language Class Initialized
INFO - 2019-09-12 16:17:03 --> Loader Class Initialized
INFO - 2019-09-12 16:17:03 --> Helper loaded: url_helper
INFO - 2019-09-12 16:17:03 --> Helper loaded: html_helper
INFO - 2019-09-12 16:17:03 --> Helper loaded: form_helper
INFO - 2019-09-12 16:17:03 --> Helper loaded: cookie_helper
INFO - 2019-09-12 16:17:03 --> Helper loaded: date_helper
INFO - 2019-09-12 16:17:03 --> Form Validation Class Initialized
INFO - 2019-09-12 16:17:03 --> Email Class Initialized
DEBUG - 2019-09-12 16:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 16:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 16:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 16:17:03 --> Pagination Class Initialized
INFO - 2019-09-12 16:17:03 --> Database Driver Class Initialized
INFO - 2019-09-12 16:17:03 --> Database Driver Class Initialized
INFO - 2019-09-12 16:17:03 --> Controller Class Initialized
INFO - 2019-09-12 16:17:03 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 16:17:03 --> Final output sent to browser
DEBUG - 2019-09-12 16:17:03 --> Total execution time: 0.0591
INFO - 2019-09-12 16:17:10 --> Config Class Initialized
INFO - 2019-09-12 16:17:10 --> Hooks Class Initialized
DEBUG - 2019-09-12 16:17:10 --> UTF-8 Support Enabled
INFO - 2019-09-12 16:17:10 --> Utf8 Class Initialized
INFO - 2019-09-12 16:17:10 --> URI Class Initialized
INFO - 2019-09-12 16:17:10 --> Router Class Initialized
INFO - 2019-09-12 16:17:10 --> Output Class Initialized
INFO - 2019-09-12 16:17:10 --> Security Class Initialized
DEBUG - 2019-09-12 16:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 16:17:10 --> Input Class Initialized
INFO - 2019-09-12 16:17:10 --> Language Class Initialized
INFO - 2019-09-12 16:17:10 --> Loader Class Initialized
INFO - 2019-09-12 16:17:10 --> Helper loaded: url_helper
INFO - 2019-09-12 16:17:10 --> Helper loaded: html_helper
INFO - 2019-09-12 16:17:10 --> Helper loaded: form_helper
INFO - 2019-09-12 16:17:10 --> Helper loaded: cookie_helper
INFO - 2019-09-12 16:17:10 --> Helper loaded: date_helper
INFO - 2019-09-12 16:17:10 --> Form Validation Class Initialized
INFO - 2019-09-12 16:17:10 --> Email Class Initialized
DEBUG - 2019-09-12 16:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 16:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 16:17:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 16:17:11 --> Pagination Class Initialized
INFO - 2019-09-12 16:17:11 --> Database Driver Class Initialized
INFO - 2019-09-12 16:17:11 --> Database Driver Class Initialized
INFO - 2019-09-12 16:17:11 --> Controller Class Initialized
INFO - 2019-09-12 16:17:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-12 16:17:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report.php
INFO - 2019-09-12 16:17:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 16:17:11 --> Final output sent to browser
DEBUG - 2019-09-12 16:17:11 --> Total execution time: 0.1231
INFO - 2019-09-12 16:54:48 --> Config Class Initialized
INFO - 2019-09-12 16:54:48 --> Hooks Class Initialized
DEBUG - 2019-09-12 16:54:48 --> UTF-8 Support Enabled
INFO - 2019-09-12 16:54:48 --> Utf8 Class Initialized
INFO - 2019-09-12 16:54:48 --> URI Class Initialized
INFO - 2019-09-12 16:54:48 --> Router Class Initialized
INFO - 2019-09-12 16:54:48 --> Output Class Initialized
INFO - 2019-09-12 16:54:48 --> Security Class Initialized
DEBUG - 2019-09-12 16:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 16:54:48 --> Input Class Initialized
INFO - 2019-09-12 16:54:48 --> Language Class Initialized
INFO - 2019-09-12 16:54:48 --> Loader Class Initialized
INFO - 2019-09-12 16:54:48 --> Helper loaded: url_helper
INFO - 2019-09-12 16:54:48 --> Helper loaded: html_helper
INFO - 2019-09-12 16:54:48 --> Helper loaded: form_helper
INFO - 2019-09-12 16:54:48 --> Helper loaded: cookie_helper
INFO - 2019-09-12 16:54:48 --> Helper loaded: date_helper
INFO - 2019-09-12 16:54:48 --> Form Validation Class Initialized
INFO - 2019-09-12 16:54:48 --> Email Class Initialized
DEBUG - 2019-09-12 16:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 16:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 16:54:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 16:54:48 --> Pagination Class Initialized
INFO - 2019-09-12 16:54:48 --> Database Driver Class Initialized
INFO - 2019-09-12 16:54:48 --> Database Driver Class Initialized
INFO - 2019-09-12 16:54:48 --> Controller Class Initialized
INFO - 2019-09-12 16:54:48 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-12 16:54:48 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-12 16:54:48 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-12 16:54:48 --> Final output sent to browser
DEBUG - 2019-09-12 16:54:48 --> Total execution time: 0.0850
INFO - 2019-09-12 16:54:48 --> Config Class Initialized
INFO - 2019-09-12 16:54:48 --> Hooks Class Initialized
DEBUG - 2019-09-12 16:54:48 --> UTF-8 Support Enabled
INFO - 2019-09-12 16:54:48 --> Utf8 Class Initialized
INFO - 2019-09-12 16:54:48 --> URI Class Initialized
INFO - 2019-09-12 16:54:48 --> Router Class Initialized
INFO - 2019-09-12 16:54:48 --> Output Class Initialized
INFO - 2019-09-12 16:54:48 --> Security Class Initialized
DEBUG - 2019-09-12 16:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 16:54:48 --> Input Class Initialized
INFO - 2019-09-12 16:54:48 --> Language Class Initialized
INFO - 2019-09-12 16:54:48 --> Loader Class Initialized
INFO - 2019-09-12 16:54:48 --> Helper loaded: url_helper
INFO - 2019-09-12 16:54:48 --> Helper loaded: html_helper
INFO - 2019-09-12 16:54:48 --> Helper loaded: form_helper
INFO - 2019-09-12 16:54:48 --> Helper loaded: cookie_helper
INFO - 2019-09-12 16:54:48 --> Helper loaded: date_helper
INFO - 2019-09-12 16:54:48 --> Form Validation Class Initialized
INFO - 2019-09-12 16:54:48 --> Email Class Initialized
DEBUG - 2019-09-12 16:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 16:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 16:54:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 16:54:48 --> Pagination Class Initialized
INFO - 2019-09-12 16:54:49 --> Database Driver Class Initialized
INFO - 2019-09-12 16:54:49 --> Database Driver Class Initialized
INFO - 2019-09-12 16:54:49 --> Controller Class Initialized
INFO - 2019-09-12 16:54:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-12 16:54:49 --> Final output sent to browser
DEBUG - 2019-09-12 16:54:49 --> Total execution time: 0.0625
INFO - 2019-09-12 17:03:22 --> Config Class Initialized
INFO - 2019-09-12 17:03:22 --> Hooks Class Initialized
DEBUG - 2019-09-12 17:03:22 --> UTF-8 Support Enabled
INFO - 2019-09-12 17:03:22 --> Utf8 Class Initialized
INFO - 2019-09-12 17:03:22 --> URI Class Initialized
INFO - 2019-09-12 17:03:22 --> Router Class Initialized
INFO - 2019-09-12 17:03:22 --> Output Class Initialized
INFO - 2019-09-12 17:03:22 --> Security Class Initialized
DEBUG - 2019-09-12 17:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 17:03:22 --> Input Class Initialized
INFO - 2019-09-12 17:03:22 --> Language Class Initialized
INFO - 2019-09-12 17:03:22 --> Loader Class Initialized
INFO - 2019-09-12 17:03:22 --> Helper loaded: url_helper
INFO - 2019-09-12 17:03:22 --> Helper loaded: html_helper
INFO - 2019-09-12 17:03:22 --> Helper loaded: form_helper
INFO - 2019-09-12 17:03:22 --> Helper loaded: cookie_helper
INFO - 2019-09-12 17:03:22 --> Helper loaded: date_helper
INFO - 2019-09-12 17:03:22 --> Form Validation Class Initialized
INFO - 2019-09-12 17:03:22 --> Email Class Initialized
DEBUG - 2019-09-12 17:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 17:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 17:03:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 17:03:22 --> Pagination Class Initialized
INFO - 2019-09-12 17:03:22 --> Database Driver Class Initialized
INFO - 2019-09-12 17:03:22 --> Database Driver Class Initialized
INFO - 2019-09-12 17:03:22 --> Controller Class Initialized
INFO - 2019-09-12 17:07:36 --> Config Class Initialized
INFO - 2019-09-12 17:07:36 --> Hooks Class Initialized
DEBUG - 2019-09-12 17:07:36 --> UTF-8 Support Enabled
INFO - 2019-09-12 17:07:36 --> Utf8 Class Initialized
INFO - 2019-09-12 17:07:36 --> URI Class Initialized
INFO - 2019-09-12 17:07:36 --> Router Class Initialized
INFO - 2019-09-12 17:07:36 --> Output Class Initialized
INFO - 2019-09-12 17:07:36 --> Security Class Initialized
DEBUG - 2019-09-12 17:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 17:07:36 --> Input Class Initialized
INFO - 2019-09-12 17:07:36 --> Language Class Initialized
INFO - 2019-09-12 17:07:36 --> Loader Class Initialized
INFO - 2019-09-12 17:07:36 --> Helper loaded: url_helper
INFO - 2019-09-12 17:07:36 --> Helper loaded: html_helper
INFO - 2019-09-12 17:07:36 --> Helper loaded: form_helper
INFO - 2019-09-12 17:07:36 --> Helper loaded: cookie_helper
INFO - 2019-09-12 17:07:36 --> Helper loaded: date_helper
INFO - 2019-09-12 17:07:36 --> Form Validation Class Initialized
INFO - 2019-09-12 17:07:36 --> Email Class Initialized
DEBUG - 2019-09-12 17:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 17:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 17:07:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 17:07:36 --> Pagination Class Initialized
INFO - 2019-09-12 17:07:37 --> Database Driver Class Initialized
INFO - 2019-09-12 17:07:37 --> Database Driver Class Initialized
INFO - 2019-09-12 17:07:37 --> Controller Class Initialized
DEBUG - 2019-09-12 17:07:37 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-12 17:07:37 --> Helper loaded: inflector_helper
INFO - 2019-09-12 17:07:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-12 17:07:37 --> Final output sent to browser
DEBUG - 2019-09-12 17:07:37 --> Total execution time: 0.0593
INFO - 2019-09-12 17:08:01 --> Config Class Initialized
INFO - 2019-09-12 17:08:01 --> Hooks Class Initialized
DEBUG - 2019-09-12 17:08:01 --> UTF-8 Support Enabled
INFO - 2019-09-12 17:08:01 --> Utf8 Class Initialized
INFO - 2019-09-12 17:08:01 --> URI Class Initialized
INFO - 2019-09-12 17:08:01 --> Router Class Initialized
INFO - 2019-09-12 17:08:01 --> Output Class Initialized
INFO - 2019-09-12 17:08:01 --> Security Class Initialized
DEBUG - 2019-09-12 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 17:08:01 --> Input Class Initialized
INFO - 2019-09-12 17:08:01 --> Language Class Initialized
INFO - 2019-09-12 17:08:01 --> Loader Class Initialized
INFO - 2019-09-12 17:08:01 --> Helper loaded: url_helper
INFO - 2019-09-12 17:08:01 --> Helper loaded: html_helper
INFO - 2019-09-12 17:08:01 --> Helper loaded: form_helper
INFO - 2019-09-12 17:08:01 --> Helper loaded: cookie_helper
INFO - 2019-09-12 17:08:01 --> Helper loaded: date_helper
INFO - 2019-09-12 17:08:01 --> Form Validation Class Initialized
INFO - 2019-09-12 17:08:01 --> Email Class Initialized
DEBUG - 2019-09-12 17:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 17:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 17:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 17:08:01 --> Pagination Class Initialized
INFO - 2019-09-12 17:08:01 --> Database Driver Class Initialized
INFO - 2019-09-12 17:08:01 --> Database Driver Class Initialized
INFO - 2019-09-12 17:08:01 --> Controller Class Initialized
DEBUG - 2019-09-12 17:08:01 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-12 17:08:01 --> Helper loaded: inflector_helper
INFO - 2019-09-12 17:08:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-12 17:08:01 --> Final output sent to browser
DEBUG - 2019-09-12 17:08:01 --> Total execution time: 0.0582
INFO - 2019-09-12 17:09:13 --> Config Class Initialized
INFO - 2019-09-12 17:09:13 --> Hooks Class Initialized
DEBUG - 2019-09-12 17:09:13 --> UTF-8 Support Enabled
INFO - 2019-09-12 17:09:13 --> Utf8 Class Initialized
INFO - 2019-09-12 17:09:13 --> URI Class Initialized
INFO - 2019-09-12 17:09:13 --> Router Class Initialized
INFO - 2019-09-12 17:09:13 --> Output Class Initialized
INFO - 2019-09-12 17:09:13 --> Security Class Initialized
DEBUG - 2019-09-12 17:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 17:09:13 --> Input Class Initialized
INFO - 2019-09-12 17:09:13 --> Language Class Initialized
INFO - 2019-09-12 17:09:13 --> Loader Class Initialized
INFO - 2019-09-12 17:09:13 --> Helper loaded: url_helper
INFO - 2019-09-12 17:09:13 --> Helper loaded: html_helper
INFO - 2019-09-12 17:09:13 --> Helper loaded: form_helper
INFO - 2019-09-12 17:09:13 --> Helper loaded: cookie_helper
INFO - 2019-09-12 17:09:13 --> Helper loaded: date_helper
INFO - 2019-09-12 17:09:13 --> Form Validation Class Initialized
INFO - 2019-09-12 17:09:13 --> Email Class Initialized
DEBUG - 2019-09-12 17:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 17:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 17:09:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 17:09:13 --> Pagination Class Initialized
INFO - 2019-09-12 17:09:13 --> Database Driver Class Initialized
INFO - 2019-09-12 17:09:13 --> Database Driver Class Initialized
INFO - 2019-09-12 17:09:13 --> Controller Class Initialized
DEBUG - 2019-09-12 17:09:13 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-12 17:09:13 --> Helper loaded: inflector_helper
INFO - 2019-09-12 17:09:13 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-12 17:09:13 --> Severity: Notice --> Undefined variable: report_user C:\wamp64\www\pridehotel_lagos\application\models\Resv_model.php 2514
ERROR - 2019-09-12 17:09:13 --> Severity: Notice --> Undefined variable: and_user C:\wamp64\www\pridehotel_lagos\application\models\Resv_model.php 2536
INFO - 2019-09-12 17:09:13 --> Final output sent to browser
DEBUG - 2019-09-12 17:09:13 --> Total execution time: 0.1158
INFO - 2019-09-12 17:10:19 --> Config Class Initialized
INFO - 2019-09-12 17:10:19 --> Hooks Class Initialized
DEBUG - 2019-09-12 17:10:19 --> UTF-8 Support Enabled
INFO - 2019-09-12 17:10:19 --> Utf8 Class Initialized
INFO - 2019-09-12 17:10:19 --> URI Class Initialized
INFO - 2019-09-12 17:10:19 --> Router Class Initialized
INFO - 2019-09-12 17:10:19 --> Output Class Initialized
INFO - 2019-09-12 17:10:19 --> Security Class Initialized
DEBUG - 2019-09-12 17:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 17:10:19 --> Input Class Initialized
INFO - 2019-09-12 17:10:19 --> Language Class Initialized
INFO - 2019-09-12 17:10:19 --> Loader Class Initialized
INFO - 2019-09-12 17:10:19 --> Helper loaded: url_helper
INFO - 2019-09-12 17:10:19 --> Helper loaded: html_helper
INFO - 2019-09-12 17:10:19 --> Helper loaded: form_helper
INFO - 2019-09-12 17:10:19 --> Helper loaded: cookie_helper
INFO - 2019-09-12 17:10:19 --> Helper loaded: date_helper
INFO - 2019-09-12 17:10:19 --> Form Validation Class Initialized
INFO - 2019-09-12 17:10:19 --> Email Class Initialized
DEBUG - 2019-09-12 17:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 17:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 17:10:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 17:10:19 --> Pagination Class Initialized
INFO - 2019-09-12 17:10:19 --> Database Driver Class Initialized
INFO - 2019-09-12 17:10:19 --> Database Driver Class Initialized
INFO - 2019-09-12 17:10:19 --> Controller Class Initialized
DEBUG - 2019-09-12 17:10:19 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-12 17:10:19 --> Helper loaded: inflector_helper
INFO - 2019-09-12 17:10:19 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-12 17:10:19 --> Severity: Notice --> Undefined variable: report_user C:\wamp64\www\pridehotel_lagos\application\models\Resv_model.php 2514
ERROR - 2019-09-12 17:10:19 --> Severity: Notice --> Undefined variable: and_user C:\wamp64\www\pridehotel_lagos\application\models\Resv_model.php 2536
INFO - 2019-09-12 17:10:19 --> Final output sent to browser
DEBUG - 2019-09-12 17:10:19 --> Total execution time: 0.0537
INFO - 2019-09-12 17:11:22 --> Config Class Initialized
INFO - 2019-09-12 17:11:22 --> Hooks Class Initialized
DEBUG - 2019-09-12 17:11:22 --> UTF-8 Support Enabled
INFO - 2019-09-12 17:11:22 --> Utf8 Class Initialized
INFO - 2019-09-12 17:11:22 --> URI Class Initialized
INFO - 2019-09-12 17:11:22 --> Router Class Initialized
INFO - 2019-09-12 17:11:22 --> Output Class Initialized
INFO - 2019-09-12 17:11:22 --> Security Class Initialized
DEBUG - 2019-09-12 17:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 17:11:22 --> Input Class Initialized
INFO - 2019-09-12 17:11:22 --> Language Class Initialized
INFO - 2019-09-12 17:11:22 --> Loader Class Initialized
INFO - 2019-09-12 17:11:22 --> Helper loaded: url_helper
INFO - 2019-09-12 17:11:22 --> Helper loaded: html_helper
INFO - 2019-09-12 17:11:22 --> Helper loaded: form_helper
INFO - 2019-09-12 17:11:22 --> Helper loaded: cookie_helper
INFO - 2019-09-12 17:11:22 --> Helper loaded: date_helper
INFO - 2019-09-12 17:11:22 --> Form Validation Class Initialized
INFO - 2019-09-12 17:11:22 --> Email Class Initialized
DEBUG - 2019-09-12 17:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 17:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 17:11:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 17:11:22 --> Pagination Class Initialized
INFO - 2019-09-12 17:11:22 --> Database Driver Class Initialized
INFO - 2019-09-12 17:11:22 --> Database Driver Class Initialized
INFO - 2019-09-12 17:11:22 --> Controller Class Initialized
DEBUG - 2019-09-12 17:11:22 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-12 17:11:22 --> Helper loaded: inflector_helper
INFO - 2019-09-12 17:11:22 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-12 17:11:22 --> Severity: Notice --> Undefined variable: report_user C:\wamp64\www\pridehotel_lagos\application\models\Resv_model.php 2514
INFO - 2019-09-12 17:11:22 --> Final output sent to browser
DEBUG - 2019-09-12 17:11:22 --> Total execution time: 0.0505
INFO - 2019-09-12 17:11:24 --> Config Class Initialized
INFO - 2019-09-12 17:11:24 --> Hooks Class Initialized
DEBUG - 2019-09-12 17:11:24 --> UTF-8 Support Enabled
INFO - 2019-09-12 17:11:24 --> Utf8 Class Initialized
INFO - 2019-09-12 17:11:24 --> URI Class Initialized
INFO - 2019-09-12 17:11:24 --> Router Class Initialized
INFO - 2019-09-12 17:11:24 --> Output Class Initialized
INFO - 2019-09-12 17:11:24 --> Security Class Initialized
DEBUG - 2019-09-12 17:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 17:11:24 --> Input Class Initialized
INFO - 2019-09-12 17:11:24 --> Language Class Initialized
INFO - 2019-09-12 17:11:24 --> Loader Class Initialized
INFO - 2019-09-12 17:11:24 --> Helper loaded: url_helper
INFO - 2019-09-12 17:11:24 --> Helper loaded: html_helper
INFO - 2019-09-12 17:11:24 --> Helper loaded: form_helper
INFO - 2019-09-12 17:11:24 --> Helper loaded: cookie_helper
INFO - 2019-09-12 17:11:24 --> Helper loaded: date_helper
INFO - 2019-09-12 17:11:24 --> Form Validation Class Initialized
INFO - 2019-09-12 17:11:24 --> Email Class Initialized
DEBUG - 2019-09-12 17:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 17:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 17:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 17:11:24 --> Pagination Class Initialized
INFO - 2019-09-12 17:11:24 --> Database Driver Class Initialized
INFO - 2019-09-12 17:11:24 --> Database Driver Class Initialized
INFO - 2019-09-12 17:11:24 --> Controller Class Initialized
DEBUG - 2019-09-12 17:11:24 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-12 17:11:24 --> Helper loaded: inflector_helper
INFO - 2019-09-12 17:11:24 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-12 17:11:24 --> Severity: Notice --> Undefined variable: report_user C:\wamp64\www\pridehotel_lagos\application\models\Resv_model.php 2514
INFO - 2019-09-12 17:11:24 --> Final output sent to browser
DEBUG - 2019-09-12 17:11:24 --> Total execution time: 0.0470
INFO - 2019-09-12 17:11:54 --> Config Class Initialized
INFO - 2019-09-12 17:11:54 --> Hooks Class Initialized
DEBUG - 2019-09-12 17:11:54 --> UTF-8 Support Enabled
INFO - 2019-09-12 17:11:54 --> Utf8 Class Initialized
INFO - 2019-09-12 17:11:54 --> URI Class Initialized
INFO - 2019-09-12 17:11:54 --> Router Class Initialized
INFO - 2019-09-12 17:11:54 --> Output Class Initialized
INFO - 2019-09-12 17:11:54 --> Security Class Initialized
DEBUG - 2019-09-12 17:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 17:11:54 --> Input Class Initialized
INFO - 2019-09-12 17:11:54 --> Language Class Initialized
INFO - 2019-09-12 17:11:54 --> Loader Class Initialized
INFO - 2019-09-12 17:11:54 --> Helper loaded: url_helper
INFO - 2019-09-12 17:11:54 --> Helper loaded: html_helper
INFO - 2019-09-12 17:11:54 --> Helper loaded: form_helper
INFO - 2019-09-12 17:11:54 --> Helper loaded: cookie_helper
INFO - 2019-09-12 17:11:54 --> Helper loaded: date_helper
INFO - 2019-09-12 17:11:54 --> Form Validation Class Initialized
INFO - 2019-09-12 17:11:54 --> Email Class Initialized
DEBUG - 2019-09-12 17:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 17:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 17:11:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 17:11:54 --> Pagination Class Initialized
INFO - 2019-09-12 17:11:54 --> Database Driver Class Initialized
INFO - 2019-09-12 17:11:54 --> Database Driver Class Initialized
INFO - 2019-09-12 17:11:54 --> Controller Class Initialized
DEBUG - 2019-09-12 17:11:54 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-12 17:11:54 --> Helper loaded: inflector_helper
INFO - 2019-09-12 17:11:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-12 17:11:54 --> Final output sent to browser
DEBUG - 2019-09-12 17:11:54 --> Total execution time: 0.0483
INFO - 2019-09-12 17:12:01 --> Config Class Initialized
INFO - 2019-09-12 17:12:01 --> Hooks Class Initialized
DEBUG - 2019-09-12 17:12:01 --> UTF-8 Support Enabled
INFO - 2019-09-12 17:12:01 --> Utf8 Class Initialized
INFO - 2019-09-12 17:12:01 --> URI Class Initialized
INFO - 2019-09-12 17:12:01 --> Router Class Initialized
INFO - 2019-09-12 17:12:01 --> Output Class Initialized
INFO - 2019-09-12 17:12:01 --> Security Class Initialized
DEBUG - 2019-09-12 17:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 17:12:01 --> Input Class Initialized
INFO - 2019-09-12 17:12:01 --> Language Class Initialized
INFO - 2019-09-12 17:12:01 --> Loader Class Initialized
INFO - 2019-09-12 17:12:01 --> Helper loaded: url_helper
INFO - 2019-09-12 17:12:01 --> Helper loaded: html_helper
INFO - 2019-09-12 17:12:01 --> Helper loaded: form_helper
INFO - 2019-09-12 17:12:01 --> Helper loaded: cookie_helper
INFO - 2019-09-12 17:12:01 --> Helper loaded: date_helper
INFO - 2019-09-12 17:12:01 --> Form Validation Class Initialized
INFO - 2019-09-12 17:12:01 --> Email Class Initialized
DEBUG - 2019-09-12 17:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 17:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 17:12:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 17:12:01 --> Pagination Class Initialized
INFO - 2019-09-12 17:12:01 --> Database Driver Class Initialized
INFO - 2019-09-12 17:12:01 --> Database Driver Class Initialized
INFO - 2019-09-12 17:12:01 --> Controller Class Initialized
DEBUG - 2019-09-12 17:12:01 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-12 17:12:01 --> Helper loaded: inflector_helper
INFO - 2019-09-12 17:12:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-12 17:12:01 --> Final output sent to browser
DEBUG - 2019-09-12 17:12:01 --> Total execution time: 0.0560
INFO - 2019-09-12 17:12:24 --> Config Class Initialized
INFO - 2019-09-12 17:12:24 --> Hooks Class Initialized
DEBUG - 2019-09-12 17:12:24 --> UTF-8 Support Enabled
INFO - 2019-09-12 17:12:24 --> Utf8 Class Initialized
INFO - 2019-09-12 17:12:24 --> URI Class Initialized
INFO - 2019-09-12 17:12:24 --> Router Class Initialized
INFO - 2019-09-12 17:12:24 --> Output Class Initialized
INFO - 2019-09-12 17:12:24 --> Security Class Initialized
DEBUG - 2019-09-12 17:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-12 17:12:24 --> Input Class Initialized
INFO - 2019-09-12 17:12:24 --> Language Class Initialized
INFO - 2019-09-12 17:12:24 --> Loader Class Initialized
INFO - 2019-09-12 17:12:24 --> Helper loaded: url_helper
INFO - 2019-09-12 17:12:24 --> Helper loaded: html_helper
INFO - 2019-09-12 17:12:24 --> Helper loaded: form_helper
INFO - 2019-09-12 17:12:24 --> Helper loaded: cookie_helper
INFO - 2019-09-12 17:12:24 --> Helper loaded: date_helper
INFO - 2019-09-12 17:12:24 --> Form Validation Class Initialized
INFO - 2019-09-12 17:12:24 --> Email Class Initialized
DEBUG - 2019-09-12 17:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-12 17:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-12 17:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-12 17:12:24 --> Pagination Class Initialized
INFO - 2019-09-12 17:12:24 --> Database Driver Class Initialized
INFO - 2019-09-12 17:12:24 --> Database Driver Class Initialized
INFO - 2019-09-12 17:12:24 --> Controller Class Initialized
DEBUG - 2019-09-12 17:12:24 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-12 17:12:24 --> Helper loaded: inflector_helper
INFO - 2019-09-12 17:12:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-12 17:12:24 --> Final output sent to browser
DEBUG - 2019-09-12 17:12:24 --> Total execution time: 0.0528
