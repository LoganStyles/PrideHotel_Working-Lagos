<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-25 06:41:00 --> Config Class Initialized
INFO - 2018-11-25 06:41:00 --> Hooks Class Initialized
DEBUG - 2018-11-25 06:41:00 --> UTF-8 Support Enabled
INFO - 2018-11-25 06:41:00 --> Utf8 Class Initialized
INFO - 2018-11-25 06:41:00 --> URI Class Initialized
INFO - 2018-11-25 06:41:00 --> Router Class Initialized
INFO - 2018-11-25 06:41:00 --> Output Class Initialized
INFO - 2018-11-25 06:41:00 --> Security Class Initialized
DEBUG - 2018-11-25 06:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 06:41:00 --> Input Class Initialized
INFO - 2018-11-25 06:41:00 --> Language Class Initialized
INFO - 2018-11-25 06:41:00 --> Loader Class Initialized
INFO - 2018-11-25 06:41:00 --> Helper loaded: url_helper
INFO - 2018-11-25 06:41:00 --> Helper loaded: html_helper
INFO - 2018-11-25 06:41:00 --> Helper loaded: form_helper
INFO - 2018-11-25 06:41:00 --> Helper loaded: cookie_helper
INFO - 2018-11-25 06:41:00 --> Helper loaded: date_helper
INFO - 2018-11-25 06:41:00 --> Form Validation Class Initialized
INFO - 2018-11-25 06:41:00 --> Email Class Initialized
DEBUG - 2018-11-25 06:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 06:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 06:41:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 06:41:00 --> Pagination Class Initialized
INFO - 2018-11-25 06:41:00 --> Database Driver Class Initialized
INFO - 2018-11-25 06:41:00 --> Database Driver Class Initialized
INFO - 2018-11-25 06:41:00 --> Controller Class Initialized
INFO - 2018-11-25 06:41:00 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-25 06:41:00 --> Final output sent to browser
DEBUG - 2018-11-25 06:41:00 --> Total execution time: 0.2527
INFO - 2018-11-25 10:56:10 --> Config Class Initialized
INFO - 2018-11-25 10:56:10 --> Hooks Class Initialized
DEBUG - 2018-11-25 10:56:10 --> UTF-8 Support Enabled
INFO - 2018-11-25 10:56:10 --> Utf8 Class Initialized
INFO - 2018-11-25 10:56:10 --> URI Class Initialized
INFO - 2018-11-25 10:56:10 --> Router Class Initialized
INFO - 2018-11-25 10:56:10 --> Output Class Initialized
INFO - 2018-11-25 10:56:10 --> Security Class Initialized
DEBUG - 2018-11-25 10:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 10:56:10 --> Input Class Initialized
INFO - 2018-11-25 10:56:10 --> Language Class Initialized
INFO - 2018-11-25 10:56:10 --> Loader Class Initialized
INFO - 2018-11-25 10:56:10 --> Helper loaded: url_helper
INFO - 2018-11-25 10:56:10 --> Helper loaded: html_helper
INFO - 2018-11-25 10:56:10 --> Helper loaded: form_helper
INFO - 2018-11-25 10:56:10 --> Helper loaded: cookie_helper
INFO - 2018-11-25 10:56:10 --> Helper loaded: date_helper
INFO - 2018-11-25 10:56:10 --> Form Validation Class Initialized
INFO - 2018-11-25 10:56:10 --> Email Class Initialized
DEBUG - 2018-11-25 10:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 10:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 10:56:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 10:56:10 --> Pagination Class Initialized
INFO - 2018-11-25 10:56:10 --> Database Driver Class Initialized
INFO - 2018-11-25 10:56:10 --> Database Driver Class Initialized
INFO - 2018-11-25 10:56:10 --> Controller Class Initialized
DEBUG - 2018-11-25 10:56:10 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 10:56:10 --> Helper loaded: inflector_helper
INFO - 2018-11-25 10:56:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 10:56:10 --> Final output sent to browser
DEBUG - 2018-11-25 10:56:10 --> Total execution time: 0.2162
INFO - 2018-11-25 10:56:57 --> Config Class Initialized
INFO - 2018-11-25 10:56:57 --> Hooks Class Initialized
DEBUG - 2018-11-25 10:56:57 --> UTF-8 Support Enabled
INFO - 2018-11-25 10:56:57 --> Utf8 Class Initialized
INFO - 2018-11-25 10:56:57 --> URI Class Initialized
INFO - 2018-11-25 10:56:57 --> Router Class Initialized
INFO - 2018-11-25 10:56:57 --> Output Class Initialized
INFO - 2018-11-25 10:56:57 --> Security Class Initialized
DEBUG - 2018-11-25 10:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 10:56:57 --> Input Class Initialized
INFO - 2018-11-25 10:56:57 --> Language Class Initialized
INFO - 2018-11-25 10:56:57 --> Loader Class Initialized
INFO - 2018-11-25 10:56:57 --> Helper loaded: url_helper
INFO - 2018-11-25 10:56:57 --> Helper loaded: html_helper
INFO - 2018-11-25 10:56:57 --> Helper loaded: form_helper
INFO - 2018-11-25 10:56:57 --> Helper loaded: cookie_helper
INFO - 2018-11-25 10:56:57 --> Helper loaded: date_helper
INFO - 2018-11-25 10:56:57 --> Form Validation Class Initialized
INFO - 2018-11-25 10:56:57 --> Email Class Initialized
DEBUG - 2018-11-25 10:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 10:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 10:56:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 10:56:57 --> Pagination Class Initialized
INFO - 2018-11-25 10:56:57 --> Database Driver Class Initialized
INFO - 2018-11-25 10:56:57 --> Database Driver Class Initialized
INFO - 2018-11-25 10:56:57 --> Controller Class Initialized
DEBUG - 2018-11-25 10:56:57 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 10:56:57 --> Helper loaded: inflector_helper
INFO - 2018-11-25 10:56:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 10:56:57 --> Final output sent to browser
DEBUG - 2018-11-25 10:56:57 --> Total execution time: 0.1932
INFO - 2018-11-25 10:57:41 --> Config Class Initialized
INFO - 2018-11-25 10:57:41 --> Hooks Class Initialized
DEBUG - 2018-11-25 10:57:41 --> UTF-8 Support Enabled
INFO - 2018-11-25 10:57:41 --> Utf8 Class Initialized
INFO - 2018-11-25 10:57:41 --> URI Class Initialized
INFO - 2018-11-25 10:57:41 --> Router Class Initialized
INFO - 2018-11-25 10:57:41 --> Output Class Initialized
INFO - 2018-11-25 10:57:41 --> Security Class Initialized
DEBUG - 2018-11-25 10:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 10:57:41 --> Input Class Initialized
INFO - 2018-11-25 10:57:41 --> Language Class Initialized
INFO - 2018-11-25 10:57:41 --> Loader Class Initialized
INFO - 2018-11-25 10:57:41 --> Helper loaded: url_helper
INFO - 2018-11-25 10:57:41 --> Helper loaded: html_helper
INFO - 2018-11-25 10:57:41 --> Helper loaded: form_helper
INFO - 2018-11-25 10:57:41 --> Helper loaded: cookie_helper
INFO - 2018-11-25 10:57:41 --> Helper loaded: date_helper
INFO - 2018-11-25 10:57:41 --> Form Validation Class Initialized
INFO - 2018-11-25 10:57:41 --> Email Class Initialized
DEBUG - 2018-11-25 10:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 10:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 10:57:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 10:57:41 --> Pagination Class Initialized
INFO - 2018-11-25 10:57:41 --> Database Driver Class Initialized
INFO - 2018-11-25 10:57:41 --> Database Driver Class Initialized
INFO - 2018-11-25 10:57:41 --> Controller Class Initialized
DEBUG - 2018-11-25 10:57:41 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 10:57:41 --> Helper loaded: inflector_helper
INFO - 2018-11-25 10:57:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 10:57:41 --> Final output sent to browser
DEBUG - 2018-11-25 10:57:41 --> Total execution time: 0.1884
INFO - 2018-11-25 10:58:42 --> Config Class Initialized
INFO - 2018-11-25 10:58:42 --> Hooks Class Initialized
DEBUG - 2018-11-25 10:58:42 --> UTF-8 Support Enabled
INFO - 2018-11-25 10:58:42 --> Utf8 Class Initialized
INFO - 2018-11-25 10:58:42 --> URI Class Initialized
INFO - 2018-11-25 10:58:42 --> Router Class Initialized
INFO - 2018-11-25 10:58:42 --> Output Class Initialized
INFO - 2018-11-25 10:58:42 --> Security Class Initialized
DEBUG - 2018-11-25 10:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 10:58:42 --> Input Class Initialized
INFO - 2018-11-25 10:58:42 --> Language Class Initialized
INFO - 2018-11-25 10:58:42 --> Loader Class Initialized
INFO - 2018-11-25 10:58:42 --> Helper loaded: url_helper
INFO - 2018-11-25 10:58:42 --> Helper loaded: html_helper
INFO - 2018-11-25 10:58:42 --> Helper loaded: form_helper
INFO - 2018-11-25 10:58:42 --> Helper loaded: cookie_helper
INFO - 2018-11-25 10:58:42 --> Helper loaded: date_helper
INFO - 2018-11-25 10:58:42 --> Form Validation Class Initialized
INFO - 2018-11-25 10:58:42 --> Email Class Initialized
DEBUG - 2018-11-25 10:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 10:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 10:58:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 10:58:42 --> Pagination Class Initialized
INFO - 2018-11-25 10:58:42 --> Database Driver Class Initialized
INFO - 2018-11-25 10:58:42 --> Database Driver Class Initialized
INFO - 2018-11-25 10:58:42 --> Controller Class Initialized
DEBUG - 2018-11-25 10:58:42 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 10:58:42 --> Helper loaded: inflector_helper
INFO - 2018-11-25 10:58:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 10:58:42 --> Final output sent to browser
DEBUG - 2018-11-25 10:58:42 --> Total execution time: 0.1589
INFO - 2018-11-25 10:59:37 --> Config Class Initialized
INFO - 2018-11-25 10:59:37 --> Hooks Class Initialized
DEBUG - 2018-11-25 10:59:37 --> UTF-8 Support Enabled
INFO - 2018-11-25 10:59:37 --> Utf8 Class Initialized
INFO - 2018-11-25 10:59:37 --> URI Class Initialized
INFO - 2018-11-25 10:59:37 --> Router Class Initialized
INFO - 2018-11-25 10:59:37 --> Output Class Initialized
INFO - 2018-11-25 10:59:37 --> Security Class Initialized
DEBUG - 2018-11-25 10:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 10:59:37 --> Input Class Initialized
INFO - 2018-11-25 10:59:37 --> Language Class Initialized
INFO - 2018-11-25 10:59:37 --> Loader Class Initialized
INFO - 2018-11-25 10:59:37 --> Helper loaded: url_helper
INFO - 2018-11-25 10:59:37 --> Helper loaded: html_helper
INFO - 2018-11-25 10:59:37 --> Helper loaded: form_helper
INFO - 2018-11-25 10:59:37 --> Helper loaded: cookie_helper
INFO - 2018-11-25 10:59:37 --> Helper loaded: date_helper
INFO - 2018-11-25 10:59:37 --> Form Validation Class Initialized
INFO - 2018-11-25 10:59:37 --> Email Class Initialized
DEBUG - 2018-11-25 10:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 10:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 10:59:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 10:59:37 --> Pagination Class Initialized
INFO - 2018-11-25 10:59:37 --> Database Driver Class Initialized
INFO - 2018-11-25 10:59:37 --> Database Driver Class Initialized
INFO - 2018-11-25 10:59:37 --> Controller Class Initialized
DEBUG - 2018-11-25 10:59:37 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 10:59:37 --> Helper loaded: inflector_helper
INFO - 2018-11-25 10:59:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 10:59:37 --> Final output sent to browser
DEBUG - 2018-11-25 10:59:37 --> Total execution time: 0.1817
INFO - 2018-11-25 11:02:40 --> Config Class Initialized
INFO - 2018-11-25 11:02:40 --> Hooks Class Initialized
DEBUG - 2018-11-25 11:02:40 --> UTF-8 Support Enabled
INFO - 2018-11-25 11:02:40 --> Utf8 Class Initialized
INFO - 2018-11-25 11:02:40 --> URI Class Initialized
INFO - 2018-11-25 11:02:40 --> Router Class Initialized
INFO - 2018-11-25 11:02:40 --> Output Class Initialized
INFO - 2018-11-25 11:02:40 --> Security Class Initialized
DEBUG - 2018-11-25 11:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 11:02:40 --> Input Class Initialized
INFO - 2018-11-25 11:02:40 --> Language Class Initialized
INFO - 2018-11-25 11:02:40 --> Loader Class Initialized
INFO - 2018-11-25 11:02:40 --> Helper loaded: url_helper
INFO - 2018-11-25 11:02:40 --> Helper loaded: html_helper
INFO - 2018-11-25 11:02:40 --> Helper loaded: form_helper
INFO - 2018-11-25 11:02:40 --> Helper loaded: cookie_helper
INFO - 2018-11-25 11:02:40 --> Helper loaded: date_helper
INFO - 2018-11-25 11:02:40 --> Form Validation Class Initialized
INFO - 2018-11-25 11:02:40 --> Email Class Initialized
DEBUG - 2018-11-25 11:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 11:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 11:02:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 11:02:40 --> Pagination Class Initialized
INFO - 2018-11-25 11:02:40 --> Database Driver Class Initialized
INFO - 2018-11-25 11:02:40 --> Database Driver Class Initialized
INFO - 2018-11-25 11:02:40 --> Controller Class Initialized
DEBUG - 2018-11-25 11:02:40 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 11:02:40 --> Helper loaded: inflector_helper
INFO - 2018-11-25 11:02:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 11:02:40 --> Final output sent to browser
DEBUG - 2018-11-25 11:02:40 --> Total execution time: 0.1762
INFO - 2018-11-25 11:09:14 --> Config Class Initialized
INFO - 2018-11-25 11:09:14 --> Hooks Class Initialized
DEBUG - 2018-11-25 11:09:14 --> UTF-8 Support Enabled
INFO - 2018-11-25 11:09:14 --> Utf8 Class Initialized
INFO - 2018-11-25 11:09:14 --> URI Class Initialized
INFO - 2018-11-25 11:09:14 --> Router Class Initialized
INFO - 2018-11-25 11:09:14 --> Output Class Initialized
INFO - 2018-11-25 11:09:14 --> Security Class Initialized
DEBUG - 2018-11-25 11:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 11:09:14 --> Input Class Initialized
INFO - 2018-11-25 11:09:14 --> Language Class Initialized
INFO - 2018-11-25 11:09:14 --> Loader Class Initialized
INFO - 2018-11-25 11:09:14 --> Helper loaded: url_helper
INFO - 2018-11-25 11:09:14 --> Helper loaded: html_helper
INFO - 2018-11-25 11:09:14 --> Helper loaded: form_helper
INFO - 2018-11-25 11:09:14 --> Helper loaded: cookie_helper
INFO - 2018-11-25 11:09:14 --> Helper loaded: date_helper
INFO - 2018-11-25 11:09:14 --> Form Validation Class Initialized
INFO - 2018-11-25 11:09:14 --> Email Class Initialized
DEBUG - 2018-11-25 11:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 11:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 11:09:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 11:09:14 --> Pagination Class Initialized
INFO - 2018-11-25 11:09:14 --> Database Driver Class Initialized
INFO - 2018-11-25 11:09:14 --> Database Driver Class Initialized
INFO - 2018-11-25 11:09:14 --> Controller Class Initialized
DEBUG - 2018-11-25 11:09:14 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 11:09:14 --> Helper loaded: inflector_helper
INFO - 2018-11-25 11:09:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 11:09:14 --> Final output sent to browser
DEBUG - 2018-11-25 11:09:14 --> Total execution time: 0.1668
INFO - 2018-11-25 11:11:34 --> Config Class Initialized
INFO - 2018-11-25 11:11:34 --> Hooks Class Initialized
DEBUG - 2018-11-25 11:11:34 --> UTF-8 Support Enabled
INFO - 2018-11-25 11:11:34 --> Utf8 Class Initialized
INFO - 2018-11-25 11:11:34 --> URI Class Initialized
INFO - 2018-11-25 11:11:34 --> Router Class Initialized
INFO - 2018-11-25 11:11:34 --> Output Class Initialized
INFO - 2018-11-25 11:11:34 --> Security Class Initialized
DEBUG - 2018-11-25 11:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 11:11:34 --> Input Class Initialized
INFO - 2018-11-25 11:11:34 --> Language Class Initialized
INFO - 2018-11-25 11:11:34 --> Loader Class Initialized
INFO - 2018-11-25 11:11:34 --> Helper loaded: url_helper
INFO - 2018-11-25 11:11:34 --> Helper loaded: html_helper
INFO - 2018-11-25 11:11:34 --> Helper loaded: form_helper
INFO - 2018-11-25 11:11:34 --> Helper loaded: cookie_helper
INFO - 2018-11-25 11:11:34 --> Helper loaded: date_helper
INFO - 2018-11-25 11:11:34 --> Form Validation Class Initialized
INFO - 2018-11-25 11:11:34 --> Email Class Initialized
DEBUG - 2018-11-25 11:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 11:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 11:11:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 11:11:34 --> Pagination Class Initialized
INFO - 2018-11-25 11:11:34 --> Database Driver Class Initialized
INFO - 2018-11-25 11:11:34 --> Database Driver Class Initialized
INFO - 2018-11-25 11:11:34 --> Controller Class Initialized
DEBUG - 2018-11-25 11:11:34 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 11:11:34 --> Helper loaded: inflector_helper
INFO - 2018-11-25 11:11:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 11:11:34 --> Final output sent to browser
DEBUG - 2018-11-25 11:11:34 --> Total execution time: 0.1683
INFO - 2018-11-25 11:13:12 --> Config Class Initialized
INFO - 2018-11-25 11:13:12 --> Hooks Class Initialized
DEBUG - 2018-11-25 11:13:12 --> UTF-8 Support Enabled
INFO - 2018-11-25 11:13:12 --> Utf8 Class Initialized
INFO - 2018-11-25 11:13:12 --> URI Class Initialized
INFO - 2018-11-25 11:13:12 --> Router Class Initialized
INFO - 2018-11-25 11:13:12 --> Output Class Initialized
INFO - 2018-11-25 11:13:12 --> Security Class Initialized
DEBUG - 2018-11-25 11:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 11:13:12 --> Input Class Initialized
INFO - 2018-11-25 11:13:12 --> Language Class Initialized
INFO - 2018-11-25 11:13:12 --> Loader Class Initialized
INFO - 2018-11-25 11:13:12 --> Helper loaded: url_helper
INFO - 2018-11-25 11:13:12 --> Helper loaded: html_helper
INFO - 2018-11-25 11:13:12 --> Helper loaded: form_helper
INFO - 2018-11-25 11:13:12 --> Helper loaded: cookie_helper
INFO - 2018-11-25 11:13:12 --> Helper loaded: date_helper
INFO - 2018-11-25 11:13:12 --> Form Validation Class Initialized
INFO - 2018-11-25 11:13:12 --> Email Class Initialized
DEBUG - 2018-11-25 11:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 11:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 11:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 11:13:12 --> Pagination Class Initialized
INFO - 2018-11-25 11:13:12 --> Database Driver Class Initialized
INFO - 2018-11-25 11:13:12 --> Database Driver Class Initialized
INFO - 2018-11-25 11:13:12 --> Controller Class Initialized
DEBUG - 2018-11-25 11:13:12 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 11:13:12 --> Helper loaded: inflector_helper
INFO - 2018-11-25 11:13:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 11:13:12 --> Final output sent to browser
DEBUG - 2018-11-25 11:13:12 --> Total execution time: 0.3602
INFO - 2018-11-25 11:15:08 --> Config Class Initialized
INFO - 2018-11-25 11:15:08 --> Hooks Class Initialized
DEBUG - 2018-11-25 11:15:08 --> UTF-8 Support Enabled
INFO - 2018-11-25 11:15:08 --> Utf8 Class Initialized
INFO - 2018-11-25 11:15:08 --> URI Class Initialized
INFO - 2018-11-25 11:15:09 --> Router Class Initialized
INFO - 2018-11-25 11:15:09 --> Output Class Initialized
INFO - 2018-11-25 11:15:09 --> Security Class Initialized
DEBUG - 2018-11-25 11:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 11:15:09 --> Input Class Initialized
INFO - 2018-11-25 11:15:09 --> Language Class Initialized
INFO - 2018-11-25 11:15:09 --> Loader Class Initialized
INFO - 2018-11-25 11:15:09 --> Helper loaded: url_helper
INFO - 2018-11-25 11:15:09 --> Helper loaded: html_helper
INFO - 2018-11-25 11:15:09 --> Helper loaded: form_helper
INFO - 2018-11-25 11:15:09 --> Helper loaded: cookie_helper
INFO - 2018-11-25 11:15:09 --> Helper loaded: date_helper
INFO - 2018-11-25 11:15:09 --> Form Validation Class Initialized
INFO - 2018-11-25 11:15:09 --> Email Class Initialized
DEBUG - 2018-11-25 11:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 11:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 11:15:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 11:15:09 --> Pagination Class Initialized
INFO - 2018-11-25 11:15:09 --> Database Driver Class Initialized
INFO - 2018-11-25 11:15:09 --> Database Driver Class Initialized
INFO - 2018-11-25 11:15:09 --> Controller Class Initialized
DEBUG - 2018-11-25 11:15:09 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 11:15:09 --> Helper loaded: inflector_helper
INFO - 2018-11-25 11:15:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 11:15:09 --> Final output sent to browser
DEBUG - 2018-11-25 11:15:09 --> Total execution time: 0.1703
INFO - 2018-11-25 11:24:58 --> Config Class Initialized
INFO - 2018-11-25 11:24:58 --> Hooks Class Initialized
DEBUG - 2018-11-25 11:24:58 --> UTF-8 Support Enabled
INFO - 2018-11-25 11:24:58 --> Utf8 Class Initialized
INFO - 2018-11-25 11:24:58 --> URI Class Initialized
INFO - 2018-11-25 11:24:58 --> Router Class Initialized
INFO - 2018-11-25 11:24:58 --> Output Class Initialized
INFO - 2018-11-25 11:24:58 --> Security Class Initialized
DEBUG - 2018-11-25 11:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 11:24:58 --> Input Class Initialized
INFO - 2018-11-25 11:24:58 --> Language Class Initialized
INFO - 2018-11-25 11:24:58 --> Loader Class Initialized
INFO - 2018-11-25 11:24:58 --> Helper loaded: url_helper
INFO - 2018-11-25 11:24:58 --> Helper loaded: html_helper
INFO - 2018-11-25 11:24:58 --> Helper loaded: form_helper
INFO - 2018-11-25 11:24:58 --> Helper loaded: cookie_helper
INFO - 2018-11-25 11:24:58 --> Helper loaded: date_helper
INFO - 2018-11-25 11:24:58 --> Form Validation Class Initialized
INFO - 2018-11-25 11:24:58 --> Email Class Initialized
DEBUG - 2018-11-25 11:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 11:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 11:24:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 11:24:58 --> Pagination Class Initialized
INFO - 2018-11-25 11:24:58 --> Database Driver Class Initialized
INFO - 2018-11-25 11:24:58 --> Database Driver Class Initialized
INFO - 2018-11-25 11:24:58 --> Controller Class Initialized
DEBUG - 2018-11-25 11:24:58 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 11:24:58 --> Helper loaded: inflector_helper
INFO - 2018-11-25 11:24:58 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2018-11-25 11:24:58 --> Severity: Error --> Call to undefined method App_model::formatItem() C:\wamp64\www\pridehotel\application\models\App_model.php 72
INFO - 2018-11-25 11:27:33 --> Config Class Initialized
INFO - 2018-11-25 11:27:33 --> Hooks Class Initialized
DEBUG - 2018-11-25 11:27:33 --> UTF-8 Support Enabled
INFO - 2018-11-25 11:27:33 --> Utf8 Class Initialized
INFO - 2018-11-25 11:27:33 --> URI Class Initialized
INFO - 2018-11-25 11:27:33 --> Router Class Initialized
INFO - 2018-11-25 11:27:33 --> Output Class Initialized
INFO - 2018-11-25 11:27:33 --> Security Class Initialized
DEBUG - 2018-11-25 11:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 11:27:33 --> Input Class Initialized
INFO - 2018-11-25 11:27:33 --> Language Class Initialized
INFO - 2018-11-25 11:27:33 --> Loader Class Initialized
INFO - 2018-11-25 11:27:33 --> Helper loaded: url_helper
INFO - 2018-11-25 11:27:33 --> Helper loaded: html_helper
INFO - 2018-11-25 11:27:33 --> Helper loaded: form_helper
INFO - 2018-11-25 11:27:33 --> Helper loaded: cookie_helper
INFO - 2018-11-25 11:27:33 --> Helper loaded: date_helper
INFO - 2018-11-25 11:27:33 --> Form Validation Class Initialized
INFO - 2018-11-25 11:27:33 --> Email Class Initialized
DEBUG - 2018-11-25 11:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 11:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 11:27:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 11:27:33 --> Pagination Class Initialized
INFO - 2018-11-25 11:27:33 --> Database Driver Class Initialized
INFO - 2018-11-25 11:27:33 --> Database Driver Class Initialized
INFO - 2018-11-25 11:27:33 --> Controller Class Initialized
DEBUG - 2018-11-25 11:27:33 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 11:27:33 --> Helper loaded: inflector_helper
INFO - 2018-11-25 11:27:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 11:27:33 --> Final output sent to browser
DEBUG - 2018-11-25 11:27:34 --> Total execution time: 0.1597
INFO - 2018-11-25 11:30:16 --> Config Class Initialized
INFO - 2018-11-25 11:30:16 --> Hooks Class Initialized
DEBUG - 2018-11-25 11:30:16 --> UTF-8 Support Enabled
INFO - 2018-11-25 11:30:16 --> Utf8 Class Initialized
INFO - 2018-11-25 11:30:16 --> URI Class Initialized
INFO - 2018-11-25 11:30:16 --> Router Class Initialized
INFO - 2018-11-25 11:30:16 --> Output Class Initialized
INFO - 2018-11-25 11:30:16 --> Security Class Initialized
DEBUG - 2018-11-25 11:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 11:30:16 --> Input Class Initialized
INFO - 2018-11-25 11:30:16 --> Language Class Initialized
INFO - 2018-11-25 11:30:16 --> Loader Class Initialized
INFO - 2018-11-25 11:30:16 --> Helper loaded: url_helper
INFO - 2018-11-25 11:30:16 --> Helper loaded: html_helper
INFO - 2018-11-25 11:30:16 --> Helper loaded: form_helper
INFO - 2018-11-25 11:30:16 --> Helper loaded: cookie_helper
INFO - 2018-11-25 11:30:16 --> Helper loaded: date_helper
INFO - 2018-11-25 11:30:16 --> Form Validation Class Initialized
INFO - 2018-11-25 11:30:16 --> Email Class Initialized
DEBUG - 2018-11-25 11:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 11:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 11:30:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 11:30:17 --> Pagination Class Initialized
INFO - 2018-11-25 11:30:17 --> Database Driver Class Initialized
INFO - 2018-11-25 11:30:17 --> Database Driver Class Initialized
INFO - 2018-11-25 11:30:17 --> Controller Class Initialized
DEBUG - 2018-11-25 11:30:17 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 11:30:17 --> Helper loaded: inflector_helper
INFO - 2018-11-25 11:30:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 11:30:17 --> Final output sent to browser
DEBUG - 2018-11-25 11:30:17 --> Total execution time: 0.1774
INFO - 2018-11-25 11:31:46 --> Config Class Initialized
INFO - 2018-11-25 11:31:46 --> Hooks Class Initialized
DEBUG - 2018-11-25 11:31:46 --> UTF-8 Support Enabled
INFO - 2018-11-25 11:31:46 --> Utf8 Class Initialized
INFO - 2018-11-25 11:31:46 --> URI Class Initialized
INFO - 2018-11-25 11:31:46 --> Router Class Initialized
INFO - 2018-11-25 11:31:46 --> Output Class Initialized
INFO - 2018-11-25 11:31:46 --> Security Class Initialized
DEBUG - 2018-11-25 11:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 11:31:46 --> Input Class Initialized
INFO - 2018-11-25 11:31:46 --> Language Class Initialized
INFO - 2018-11-25 11:31:46 --> Loader Class Initialized
INFO - 2018-11-25 11:31:46 --> Helper loaded: url_helper
INFO - 2018-11-25 11:31:46 --> Helper loaded: html_helper
INFO - 2018-11-25 11:31:46 --> Helper loaded: form_helper
INFO - 2018-11-25 11:31:46 --> Helper loaded: cookie_helper
INFO - 2018-11-25 11:31:46 --> Helper loaded: date_helper
INFO - 2018-11-25 11:31:46 --> Form Validation Class Initialized
INFO - 2018-11-25 11:31:46 --> Email Class Initialized
DEBUG - 2018-11-25 11:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 11:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 11:31:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 11:31:46 --> Pagination Class Initialized
INFO - 2018-11-25 11:31:46 --> Database Driver Class Initialized
INFO - 2018-11-25 11:31:46 --> Database Driver Class Initialized
INFO - 2018-11-25 11:31:47 --> Controller Class Initialized
DEBUG - 2018-11-25 11:31:47 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 11:31:47 --> Helper loaded: inflector_helper
INFO - 2018-11-25 11:31:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 11:31:47 --> Final output sent to browser
DEBUG - 2018-11-25 11:31:47 --> Total execution time: 0.1742
INFO - 2018-11-25 11:37:24 --> Config Class Initialized
INFO - 2018-11-25 11:37:24 --> Hooks Class Initialized
DEBUG - 2018-11-25 11:37:24 --> UTF-8 Support Enabled
INFO - 2018-11-25 11:37:24 --> Utf8 Class Initialized
INFO - 2018-11-25 11:37:24 --> URI Class Initialized
INFO - 2018-11-25 11:37:24 --> Router Class Initialized
INFO - 2018-11-25 11:37:24 --> Output Class Initialized
INFO - 2018-11-25 11:37:24 --> Security Class Initialized
DEBUG - 2018-11-25 11:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 11:37:24 --> Input Class Initialized
INFO - 2018-11-25 11:37:24 --> Language Class Initialized
INFO - 2018-11-25 11:37:24 --> Loader Class Initialized
INFO - 2018-11-25 11:37:24 --> Helper loaded: url_helper
INFO - 2018-11-25 11:37:24 --> Helper loaded: html_helper
INFO - 2018-11-25 11:37:24 --> Helper loaded: form_helper
INFO - 2018-11-25 11:37:24 --> Helper loaded: cookie_helper
INFO - 2018-11-25 11:37:24 --> Helper loaded: date_helper
INFO - 2018-11-25 11:37:24 --> Form Validation Class Initialized
INFO - 2018-11-25 11:37:24 --> Email Class Initialized
DEBUG - 2018-11-25 11:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 11:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 11:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 11:37:24 --> Pagination Class Initialized
INFO - 2018-11-25 11:37:24 --> Database Driver Class Initialized
INFO - 2018-11-25 11:37:24 --> Database Driver Class Initialized
INFO - 2018-11-25 11:37:24 --> Controller Class Initialized
DEBUG - 2018-11-25 11:37:24 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 11:37:24 --> Helper loaded: inflector_helper
INFO - 2018-11-25 11:37:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 11:37:24 --> Final output sent to browser
DEBUG - 2018-11-25 11:37:24 --> Total execution time: 0.1926
INFO - 2018-11-25 11:52:44 --> Config Class Initialized
INFO - 2018-11-25 11:52:44 --> Hooks Class Initialized
DEBUG - 2018-11-25 11:52:44 --> UTF-8 Support Enabled
INFO - 2018-11-25 11:52:44 --> Utf8 Class Initialized
INFO - 2018-11-25 11:52:44 --> URI Class Initialized
INFO - 2018-11-25 11:52:44 --> Router Class Initialized
INFO - 2018-11-25 11:52:44 --> Output Class Initialized
INFO - 2018-11-25 11:52:44 --> Security Class Initialized
DEBUG - 2018-11-25 11:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 11:52:44 --> Input Class Initialized
INFO - 2018-11-25 11:52:44 --> Language Class Initialized
INFO - 2018-11-25 11:52:44 --> Loader Class Initialized
INFO - 2018-11-25 11:52:44 --> Helper loaded: url_helper
INFO - 2018-11-25 11:52:44 --> Helper loaded: html_helper
INFO - 2018-11-25 11:52:44 --> Helper loaded: form_helper
INFO - 2018-11-25 11:52:44 --> Helper loaded: cookie_helper
INFO - 2018-11-25 11:52:44 --> Helper loaded: date_helper
INFO - 2018-11-25 11:52:44 --> Form Validation Class Initialized
INFO - 2018-11-25 11:52:44 --> Email Class Initialized
DEBUG - 2018-11-25 11:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 11:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 11:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 11:52:44 --> Pagination Class Initialized
INFO - 2018-11-25 11:52:44 --> Database Driver Class Initialized
INFO - 2018-11-25 11:52:44 --> Database Driver Class Initialized
INFO - 2018-11-25 11:52:44 --> Controller Class Initialized
DEBUG - 2018-11-25 11:52:44 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 11:52:44 --> Helper loaded: inflector_helper
INFO - 2018-11-25 11:52:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 11:52:44 --> Final output sent to browser
DEBUG - 2018-11-25 11:52:44 --> Total execution time: 0.1598
INFO - 2018-11-25 12:06:27 --> Config Class Initialized
INFO - 2018-11-25 12:06:27 --> Hooks Class Initialized
DEBUG - 2018-11-25 12:06:27 --> UTF-8 Support Enabled
INFO - 2018-11-25 12:06:27 --> Utf8 Class Initialized
INFO - 2018-11-25 12:06:27 --> URI Class Initialized
INFO - 2018-11-25 12:06:27 --> Router Class Initialized
INFO - 2018-11-25 12:06:27 --> Output Class Initialized
INFO - 2018-11-25 12:06:27 --> Security Class Initialized
DEBUG - 2018-11-25 12:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 12:06:27 --> Input Class Initialized
INFO - 2018-11-25 12:06:27 --> Language Class Initialized
INFO - 2018-11-25 12:06:27 --> Loader Class Initialized
INFO - 2018-11-25 12:06:27 --> Helper loaded: url_helper
INFO - 2018-11-25 12:06:27 --> Helper loaded: html_helper
INFO - 2018-11-25 12:06:27 --> Helper loaded: form_helper
INFO - 2018-11-25 12:06:27 --> Helper loaded: cookie_helper
INFO - 2018-11-25 12:06:27 --> Helper loaded: date_helper
INFO - 2018-11-25 12:06:27 --> Form Validation Class Initialized
INFO - 2018-11-25 12:06:27 --> Email Class Initialized
DEBUG - 2018-11-25 12:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 12:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 12:06:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 12:06:27 --> Pagination Class Initialized
INFO - 2018-11-25 12:06:27 --> Database Driver Class Initialized
INFO - 2018-11-25 12:06:27 --> Database Driver Class Initialized
INFO - 2018-11-25 12:06:27 --> Controller Class Initialized
DEBUG - 2018-11-25 12:06:27 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 12:06:27 --> Helper loaded: inflector_helper
INFO - 2018-11-25 12:06:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 12:06:27 --> Final output sent to browser
DEBUG - 2018-11-25 12:06:27 --> Total execution time: 0.1856
INFO - 2018-11-25 12:11:56 --> Config Class Initialized
INFO - 2018-11-25 12:11:56 --> Hooks Class Initialized
DEBUG - 2018-11-25 12:11:56 --> UTF-8 Support Enabled
INFO - 2018-11-25 12:11:56 --> Utf8 Class Initialized
INFO - 2018-11-25 12:11:56 --> URI Class Initialized
INFO - 2018-11-25 12:11:56 --> Router Class Initialized
INFO - 2018-11-25 12:11:56 --> Output Class Initialized
INFO - 2018-11-25 12:11:56 --> Security Class Initialized
DEBUG - 2018-11-25 12:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 12:11:57 --> Input Class Initialized
INFO - 2018-11-25 12:11:57 --> Language Class Initialized
INFO - 2018-11-25 12:11:57 --> Loader Class Initialized
INFO - 2018-11-25 12:11:57 --> Helper loaded: url_helper
INFO - 2018-11-25 12:11:57 --> Helper loaded: html_helper
INFO - 2018-11-25 12:11:57 --> Helper loaded: form_helper
INFO - 2018-11-25 12:11:57 --> Helper loaded: cookie_helper
INFO - 2018-11-25 12:11:57 --> Helper loaded: date_helper
INFO - 2018-11-25 12:11:57 --> Form Validation Class Initialized
INFO - 2018-11-25 12:11:57 --> Email Class Initialized
DEBUG - 2018-11-25 12:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 12:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 12:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 12:11:57 --> Pagination Class Initialized
INFO - 2018-11-25 12:11:57 --> Database Driver Class Initialized
INFO - 2018-11-25 12:11:57 --> Database Driver Class Initialized
INFO - 2018-11-25 12:11:57 --> Controller Class Initialized
DEBUG - 2018-11-25 12:11:57 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 12:11:57 --> Helper loaded: inflector_helper
INFO - 2018-11-25 12:11:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 12:11:57 --> Final output sent to browser
DEBUG - 2018-11-25 12:11:57 --> Total execution time: 0.1893
INFO - 2018-11-25 13:09:16 --> Config Class Initialized
INFO - 2018-11-25 13:09:16 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:09:16 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:09:16 --> Utf8 Class Initialized
INFO - 2018-11-25 13:09:16 --> URI Class Initialized
INFO - 2018-11-25 13:09:16 --> Router Class Initialized
INFO - 2018-11-25 13:09:16 --> Output Class Initialized
INFO - 2018-11-25 13:09:16 --> Security Class Initialized
DEBUG - 2018-11-25 13:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:09:16 --> Input Class Initialized
INFO - 2018-11-25 13:09:16 --> Language Class Initialized
INFO - 2018-11-25 13:09:16 --> Loader Class Initialized
INFO - 2018-11-25 13:09:16 --> Helper loaded: url_helper
INFO - 2018-11-25 13:09:16 --> Helper loaded: html_helper
INFO - 2018-11-25 13:09:16 --> Helper loaded: form_helper
INFO - 2018-11-25 13:09:16 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:09:16 --> Helper loaded: date_helper
INFO - 2018-11-25 13:09:16 --> Form Validation Class Initialized
INFO - 2018-11-25 13:09:16 --> Email Class Initialized
DEBUG - 2018-11-25 13:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:09:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:09:16 --> Pagination Class Initialized
INFO - 2018-11-25 13:09:16 --> Database Driver Class Initialized
INFO - 2018-11-25 13:09:16 --> Database Driver Class Initialized
INFO - 2018-11-25 13:09:16 --> Controller Class Initialized
DEBUG - 2018-11-25 13:09:16 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:09:16 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:09:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:09:16 --> Final output sent to browser
DEBUG - 2018-11-25 13:09:16 --> Total execution time: 0.1724
INFO - 2018-11-25 13:09:34 --> Config Class Initialized
INFO - 2018-11-25 13:09:34 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:09:34 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:09:34 --> Utf8 Class Initialized
INFO - 2018-11-25 13:09:34 --> URI Class Initialized
INFO - 2018-11-25 13:09:34 --> Router Class Initialized
INFO - 2018-11-25 13:09:34 --> Output Class Initialized
INFO - 2018-11-25 13:09:34 --> Security Class Initialized
DEBUG - 2018-11-25 13:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:09:34 --> Input Class Initialized
INFO - 2018-11-25 13:09:34 --> Language Class Initialized
INFO - 2018-11-25 13:09:34 --> Loader Class Initialized
INFO - 2018-11-25 13:09:34 --> Helper loaded: url_helper
INFO - 2018-11-25 13:09:34 --> Helper loaded: html_helper
INFO - 2018-11-25 13:09:34 --> Helper loaded: form_helper
INFO - 2018-11-25 13:09:34 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:09:34 --> Helper loaded: date_helper
INFO - 2018-11-25 13:09:34 --> Form Validation Class Initialized
INFO - 2018-11-25 13:09:34 --> Email Class Initialized
DEBUG - 2018-11-25 13:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:09:34 --> Pagination Class Initialized
INFO - 2018-11-25 13:09:34 --> Database Driver Class Initialized
INFO - 2018-11-25 13:09:34 --> Database Driver Class Initialized
INFO - 2018-11-25 13:09:34 --> Controller Class Initialized
DEBUG - 2018-11-25 13:09:34 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:09:34 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:09:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:09:34 --> Final output sent to browser
DEBUG - 2018-11-25 13:09:34 --> Total execution time: 0.1409
INFO - 2018-11-25 13:09:36 --> Config Class Initialized
INFO - 2018-11-25 13:09:36 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:09:36 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:09:36 --> Utf8 Class Initialized
INFO - 2018-11-25 13:09:36 --> URI Class Initialized
INFO - 2018-11-25 13:09:36 --> Router Class Initialized
INFO - 2018-11-25 13:09:36 --> Output Class Initialized
INFO - 2018-11-25 13:09:36 --> Security Class Initialized
DEBUG - 2018-11-25 13:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:09:36 --> Input Class Initialized
INFO - 2018-11-25 13:09:36 --> Language Class Initialized
INFO - 2018-11-25 13:09:36 --> Loader Class Initialized
INFO - 2018-11-25 13:09:36 --> Helper loaded: url_helper
INFO - 2018-11-25 13:09:36 --> Helper loaded: html_helper
INFO - 2018-11-25 13:09:36 --> Helper loaded: form_helper
INFO - 2018-11-25 13:09:36 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:09:36 --> Helper loaded: date_helper
INFO - 2018-11-25 13:09:36 --> Form Validation Class Initialized
INFO - 2018-11-25 13:09:36 --> Email Class Initialized
DEBUG - 2018-11-25 13:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:09:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:09:36 --> Pagination Class Initialized
INFO - 2018-11-25 13:09:36 --> Database Driver Class Initialized
INFO - 2018-11-25 13:09:36 --> Database Driver Class Initialized
INFO - 2018-11-25 13:09:36 --> Controller Class Initialized
DEBUG - 2018-11-25 13:09:36 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:09:36 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:09:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:09:36 --> Final output sent to browser
DEBUG - 2018-11-25 13:09:36 --> Total execution time: 0.1601
INFO - 2018-11-25 13:09:36 --> Config Class Initialized
INFO - 2018-11-25 13:09:36 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:09:36 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:09:36 --> Utf8 Class Initialized
INFO - 2018-11-25 13:09:36 --> URI Class Initialized
INFO - 2018-11-25 13:09:36 --> Router Class Initialized
INFO - 2018-11-25 13:09:36 --> Output Class Initialized
INFO - 2018-11-25 13:09:36 --> Security Class Initialized
DEBUG - 2018-11-25 13:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:09:36 --> Input Class Initialized
INFO - 2018-11-25 13:09:36 --> Language Class Initialized
INFO - 2018-11-25 13:09:36 --> Loader Class Initialized
INFO - 2018-11-25 13:09:36 --> Helper loaded: url_helper
INFO - 2018-11-25 13:09:36 --> Helper loaded: html_helper
INFO - 2018-11-25 13:09:36 --> Helper loaded: form_helper
INFO - 2018-11-25 13:09:36 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:09:36 --> Helper loaded: date_helper
INFO - 2018-11-25 13:09:36 --> Form Validation Class Initialized
INFO - 2018-11-25 13:09:36 --> Email Class Initialized
DEBUG - 2018-11-25 13:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:09:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:09:36 --> Pagination Class Initialized
INFO - 2018-11-25 13:09:36 --> Database Driver Class Initialized
INFO - 2018-11-25 13:09:36 --> Database Driver Class Initialized
INFO - 2018-11-25 13:09:36 --> Controller Class Initialized
DEBUG - 2018-11-25 13:09:36 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:09:36 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:09:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:09:36 --> Final output sent to browser
DEBUG - 2018-11-25 13:09:36 --> Total execution time: 0.1167
INFO - 2018-11-25 13:09:37 --> Config Class Initialized
INFO - 2018-11-25 13:09:37 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:09:37 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:09:37 --> Utf8 Class Initialized
INFO - 2018-11-25 13:09:37 --> URI Class Initialized
INFO - 2018-11-25 13:09:37 --> Router Class Initialized
INFO - 2018-11-25 13:09:37 --> Output Class Initialized
INFO - 2018-11-25 13:09:37 --> Security Class Initialized
DEBUG - 2018-11-25 13:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:09:37 --> Input Class Initialized
INFO - 2018-11-25 13:09:37 --> Language Class Initialized
INFO - 2018-11-25 13:09:37 --> Loader Class Initialized
INFO - 2018-11-25 13:09:37 --> Helper loaded: url_helper
INFO - 2018-11-25 13:09:37 --> Helper loaded: html_helper
INFO - 2018-11-25 13:09:37 --> Helper loaded: form_helper
INFO - 2018-11-25 13:09:37 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:09:37 --> Helper loaded: date_helper
INFO - 2018-11-25 13:09:37 --> Form Validation Class Initialized
INFO - 2018-11-25 13:09:37 --> Email Class Initialized
DEBUG - 2018-11-25 13:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:09:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:09:37 --> Pagination Class Initialized
INFO - 2018-11-25 13:09:37 --> Database Driver Class Initialized
INFO - 2018-11-25 13:09:37 --> Database Driver Class Initialized
INFO - 2018-11-25 13:09:37 --> Controller Class Initialized
DEBUG - 2018-11-25 13:09:37 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:09:37 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:09:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:09:37 --> Final output sent to browser
DEBUG - 2018-11-25 13:09:37 --> Total execution time: 0.1471
INFO - 2018-11-25 13:10:57 --> Config Class Initialized
INFO - 2018-11-25 13:10:57 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:10:57 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:10:57 --> Utf8 Class Initialized
INFO - 2018-11-25 13:10:57 --> URI Class Initialized
INFO - 2018-11-25 13:10:57 --> Router Class Initialized
INFO - 2018-11-25 13:10:57 --> Output Class Initialized
INFO - 2018-11-25 13:10:57 --> Security Class Initialized
DEBUG - 2018-11-25 13:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:10:57 --> Input Class Initialized
INFO - 2018-11-25 13:10:57 --> Language Class Initialized
INFO - 2018-11-25 13:10:57 --> Loader Class Initialized
INFO - 2018-11-25 13:10:57 --> Helper loaded: url_helper
INFO - 2018-11-25 13:10:57 --> Helper loaded: html_helper
INFO - 2018-11-25 13:10:57 --> Helper loaded: form_helper
INFO - 2018-11-25 13:10:57 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:10:57 --> Helper loaded: date_helper
INFO - 2018-11-25 13:10:57 --> Form Validation Class Initialized
INFO - 2018-11-25 13:10:57 --> Email Class Initialized
DEBUG - 2018-11-25 13:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:10:57 --> Pagination Class Initialized
INFO - 2018-11-25 13:10:57 --> Database Driver Class Initialized
INFO - 2018-11-25 13:10:57 --> Database Driver Class Initialized
INFO - 2018-11-25 13:10:57 --> Controller Class Initialized
DEBUG - 2018-11-25 13:10:57 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:10:57 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:10:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:10:57 --> Final output sent to browser
DEBUG - 2018-11-25 13:10:57 --> Total execution time: 0.1825
INFO - 2018-11-25 13:11:17 --> Config Class Initialized
INFO - 2018-11-25 13:11:17 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:11:17 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:11:17 --> Utf8 Class Initialized
INFO - 2018-11-25 13:11:17 --> URI Class Initialized
INFO - 2018-11-25 13:11:17 --> Router Class Initialized
INFO - 2018-11-25 13:11:17 --> Output Class Initialized
INFO - 2018-11-25 13:11:17 --> Security Class Initialized
DEBUG - 2018-11-25 13:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:11:17 --> Input Class Initialized
INFO - 2018-11-25 13:11:17 --> Language Class Initialized
INFO - 2018-11-25 13:11:17 --> Loader Class Initialized
INFO - 2018-11-25 13:11:17 --> Helper loaded: url_helper
INFO - 2018-11-25 13:11:17 --> Helper loaded: html_helper
INFO - 2018-11-25 13:11:17 --> Helper loaded: form_helper
INFO - 2018-11-25 13:11:17 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:11:17 --> Helper loaded: date_helper
INFO - 2018-11-25 13:11:17 --> Form Validation Class Initialized
INFO - 2018-11-25 13:11:17 --> Email Class Initialized
DEBUG - 2018-11-25 13:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:11:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:11:17 --> Pagination Class Initialized
INFO - 2018-11-25 13:11:17 --> Database Driver Class Initialized
INFO - 2018-11-25 13:11:17 --> Database Driver Class Initialized
INFO - 2018-11-25 13:11:17 --> Controller Class Initialized
DEBUG - 2018-11-25 13:11:17 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:11:17 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:11:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:11:17 --> Final output sent to browser
DEBUG - 2018-11-25 13:11:17 --> Total execution time: 0.1048
INFO - 2018-11-25 13:11:24 --> Config Class Initialized
INFO - 2018-11-25 13:11:24 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:11:24 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:11:24 --> Utf8 Class Initialized
INFO - 2018-11-25 13:11:24 --> URI Class Initialized
INFO - 2018-11-25 13:11:24 --> Router Class Initialized
INFO - 2018-11-25 13:11:24 --> Output Class Initialized
INFO - 2018-11-25 13:11:24 --> Security Class Initialized
DEBUG - 2018-11-25 13:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:11:24 --> Input Class Initialized
INFO - 2018-11-25 13:11:24 --> Language Class Initialized
INFO - 2018-11-25 13:11:24 --> Loader Class Initialized
INFO - 2018-11-25 13:11:24 --> Helper loaded: url_helper
INFO - 2018-11-25 13:11:24 --> Helper loaded: html_helper
INFO - 2018-11-25 13:11:24 --> Helper loaded: form_helper
INFO - 2018-11-25 13:11:24 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:11:24 --> Helper loaded: date_helper
INFO - 2018-11-25 13:11:24 --> Form Validation Class Initialized
INFO - 2018-11-25 13:11:24 --> Email Class Initialized
DEBUG - 2018-11-25 13:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:11:24 --> Pagination Class Initialized
INFO - 2018-11-25 13:11:24 --> Database Driver Class Initialized
INFO - 2018-11-25 13:11:24 --> Database Driver Class Initialized
INFO - 2018-11-25 13:11:24 --> Controller Class Initialized
DEBUG - 2018-11-25 13:11:24 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:11:24 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:11:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:11:24 --> Final output sent to browser
DEBUG - 2018-11-25 13:11:24 --> Total execution time: 0.1585
INFO - 2018-11-25 13:21:39 --> Config Class Initialized
INFO - 2018-11-25 13:21:39 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:21:39 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:21:39 --> Utf8 Class Initialized
INFO - 2018-11-25 13:21:39 --> URI Class Initialized
INFO - 2018-11-25 13:21:39 --> Router Class Initialized
INFO - 2018-11-25 13:21:39 --> Output Class Initialized
INFO - 2018-11-25 13:21:39 --> Security Class Initialized
DEBUG - 2018-11-25 13:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:21:39 --> Input Class Initialized
INFO - 2018-11-25 13:21:39 --> Language Class Initialized
INFO - 2018-11-25 13:21:39 --> Loader Class Initialized
INFO - 2018-11-25 13:21:39 --> Helper loaded: url_helper
INFO - 2018-11-25 13:21:39 --> Helper loaded: html_helper
INFO - 2018-11-25 13:21:39 --> Helper loaded: form_helper
INFO - 2018-11-25 13:21:39 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:21:39 --> Helper loaded: date_helper
INFO - 2018-11-25 13:21:39 --> Form Validation Class Initialized
INFO - 2018-11-25 13:21:39 --> Email Class Initialized
DEBUG - 2018-11-25 13:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:21:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:21:39 --> Pagination Class Initialized
INFO - 2018-11-25 13:21:39 --> Database Driver Class Initialized
INFO - 2018-11-25 13:21:39 --> Database Driver Class Initialized
INFO - 2018-11-25 13:21:39 --> Controller Class Initialized
DEBUG - 2018-11-25 13:21:39 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:21:39 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:21:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:21:39 --> Final output sent to browser
DEBUG - 2018-11-25 13:21:39 --> Total execution time: 0.1642
INFO - 2018-11-25 13:31:45 --> Config Class Initialized
INFO - 2018-11-25 13:31:45 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:31:45 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:31:45 --> Utf8 Class Initialized
INFO - 2018-11-25 13:31:45 --> URI Class Initialized
INFO - 2018-11-25 13:31:45 --> Router Class Initialized
INFO - 2018-11-25 13:31:45 --> Output Class Initialized
INFO - 2018-11-25 13:31:45 --> Security Class Initialized
DEBUG - 2018-11-25 13:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:31:45 --> Input Class Initialized
INFO - 2018-11-25 13:31:45 --> Language Class Initialized
INFO - 2018-11-25 13:31:45 --> Loader Class Initialized
INFO - 2018-11-25 13:31:45 --> Helper loaded: url_helper
INFO - 2018-11-25 13:31:45 --> Helper loaded: html_helper
INFO - 2018-11-25 13:31:45 --> Helper loaded: form_helper
INFO - 2018-11-25 13:31:45 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:31:45 --> Helper loaded: date_helper
INFO - 2018-11-25 13:31:45 --> Form Validation Class Initialized
INFO - 2018-11-25 13:31:45 --> Email Class Initialized
DEBUG - 2018-11-25 13:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:31:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:31:45 --> Pagination Class Initialized
INFO - 2018-11-25 13:31:45 --> Database Driver Class Initialized
INFO - 2018-11-25 13:31:45 --> Database Driver Class Initialized
INFO - 2018-11-25 13:31:45 --> Controller Class Initialized
DEBUG - 2018-11-25 13:31:45 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:31:45 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:31:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:31:45 --> Final output sent to browser
DEBUG - 2018-11-25 13:31:45 --> Total execution time: 0.1725
INFO - 2018-11-25 13:35:11 --> Config Class Initialized
INFO - 2018-11-25 13:35:11 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:35:11 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:35:11 --> Utf8 Class Initialized
INFO - 2018-11-25 13:35:11 --> URI Class Initialized
INFO - 2018-11-25 13:35:11 --> Router Class Initialized
INFO - 2018-11-25 13:35:11 --> Output Class Initialized
INFO - 2018-11-25 13:35:11 --> Security Class Initialized
DEBUG - 2018-11-25 13:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:35:11 --> Input Class Initialized
INFO - 2018-11-25 13:35:11 --> Language Class Initialized
INFO - 2018-11-25 13:35:11 --> Loader Class Initialized
INFO - 2018-11-25 13:35:11 --> Helper loaded: url_helper
INFO - 2018-11-25 13:35:11 --> Helper loaded: html_helper
INFO - 2018-11-25 13:35:11 --> Helper loaded: form_helper
INFO - 2018-11-25 13:35:11 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:35:11 --> Helper loaded: date_helper
INFO - 2018-11-25 13:35:11 --> Form Validation Class Initialized
INFO - 2018-11-25 13:35:11 --> Email Class Initialized
DEBUG - 2018-11-25 13:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:35:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:35:11 --> Pagination Class Initialized
INFO - 2018-11-25 13:35:11 --> Database Driver Class Initialized
INFO - 2018-11-25 13:35:11 --> Database Driver Class Initialized
INFO - 2018-11-25 13:35:11 --> Controller Class Initialized
DEBUG - 2018-11-25 13:35:11 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:35:11 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:35:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:35:11 --> Final output sent to browser
DEBUG - 2018-11-25 13:35:11 --> Total execution time: 0.1161
INFO - 2018-11-25 13:37:47 --> Config Class Initialized
INFO - 2018-11-25 13:37:47 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:37:47 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:37:47 --> Utf8 Class Initialized
INFO - 2018-11-25 13:37:47 --> URI Class Initialized
INFO - 2018-11-25 13:37:47 --> Router Class Initialized
INFO - 2018-11-25 13:37:47 --> Output Class Initialized
INFO - 2018-11-25 13:37:47 --> Security Class Initialized
DEBUG - 2018-11-25 13:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:37:47 --> Input Class Initialized
INFO - 2018-11-25 13:37:47 --> Language Class Initialized
INFO - 2018-11-25 13:37:47 --> Loader Class Initialized
INFO - 2018-11-25 13:37:47 --> Helper loaded: url_helper
INFO - 2018-11-25 13:37:47 --> Helper loaded: html_helper
INFO - 2018-11-25 13:37:47 --> Helper loaded: form_helper
INFO - 2018-11-25 13:37:47 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:37:47 --> Helper loaded: date_helper
INFO - 2018-11-25 13:37:47 --> Form Validation Class Initialized
INFO - 2018-11-25 13:37:47 --> Email Class Initialized
DEBUG - 2018-11-25 13:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:37:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:37:48 --> Pagination Class Initialized
INFO - 2018-11-25 13:37:48 --> Database Driver Class Initialized
INFO - 2018-11-25 13:37:48 --> Database Driver Class Initialized
INFO - 2018-11-25 13:37:48 --> Controller Class Initialized
DEBUG - 2018-11-25 13:37:48 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:37:48 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:37:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:37:48 --> Final output sent to browser
DEBUG - 2018-11-25 13:37:48 --> Total execution time: 0.4172
INFO - 2018-11-25 13:41:05 --> Config Class Initialized
INFO - 2018-11-25 13:41:05 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:41:05 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:41:05 --> Utf8 Class Initialized
INFO - 2018-11-25 13:41:05 --> URI Class Initialized
INFO - 2018-11-25 13:41:05 --> Router Class Initialized
INFO - 2018-11-25 13:41:05 --> Output Class Initialized
INFO - 2018-11-25 13:41:05 --> Security Class Initialized
DEBUG - 2018-11-25 13:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:41:05 --> Input Class Initialized
INFO - 2018-11-25 13:41:05 --> Language Class Initialized
INFO - 2018-11-25 13:41:05 --> Loader Class Initialized
INFO - 2018-11-25 13:41:05 --> Helper loaded: url_helper
INFO - 2018-11-25 13:41:05 --> Helper loaded: html_helper
INFO - 2018-11-25 13:41:05 --> Helper loaded: form_helper
INFO - 2018-11-25 13:41:05 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:41:05 --> Helper loaded: date_helper
INFO - 2018-11-25 13:41:05 --> Form Validation Class Initialized
INFO - 2018-11-25 13:41:05 --> Email Class Initialized
DEBUG - 2018-11-25 13:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:41:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:41:05 --> Pagination Class Initialized
INFO - 2018-11-25 13:41:05 --> Database Driver Class Initialized
INFO - 2018-11-25 13:41:05 --> Database Driver Class Initialized
INFO - 2018-11-25 13:41:05 --> Controller Class Initialized
DEBUG - 2018-11-25 13:41:05 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:41:05 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:41:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:41:05 --> Final output sent to browser
DEBUG - 2018-11-25 13:41:05 --> Total execution time: 0.1745
INFO - 2018-11-25 13:42:43 --> Config Class Initialized
INFO - 2018-11-25 13:42:43 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:42:43 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:42:43 --> Utf8 Class Initialized
INFO - 2018-11-25 13:42:43 --> URI Class Initialized
INFO - 2018-11-25 13:42:43 --> Router Class Initialized
INFO - 2018-11-25 13:42:43 --> Output Class Initialized
INFO - 2018-11-25 13:42:43 --> Security Class Initialized
DEBUG - 2018-11-25 13:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:42:43 --> Input Class Initialized
INFO - 2018-11-25 13:42:43 --> Language Class Initialized
INFO - 2018-11-25 13:42:43 --> Loader Class Initialized
INFO - 2018-11-25 13:42:43 --> Helper loaded: url_helper
INFO - 2018-11-25 13:42:43 --> Helper loaded: html_helper
INFO - 2018-11-25 13:42:43 --> Helper loaded: form_helper
INFO - 2018-11-25 13:42:43 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:42:43 --> Helper loaded: date_helper
INFO - 2018-11-25 13:42:43 --> Form Validation Class Initialized
INFO - 2018-11-25 13:42:43 --> Email Class Initialized
DEBUG - 2018-11-25 13:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:42:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:42:43 --> Pagination Class Initialized
INFO - 2018-11-25 13:42:43 --> Database Driver Class Initialized
INFO - 2018-11-25 13:42:43 --> Database Driver Class Initialized
INFO - 2018-11-25 13:42:43 --> Controller Class Initialized
DEBUG - 2018-11-25 13:42:43 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:42:43 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:42:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:42:43 --> Final output sent to browser
DEBUG - 2018-11-25 13:42:43 --> Total execution time: 0.1787
INFO - 2018-11-25 13:42:58 --> Config Class Initialized
INFO - 2018-11-25 13:42:58 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:42:58 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:42:58 --> Utf8 Class Initialized
INFO - 2018-11-25 13:42:58 --> URI Class Initialized
INFO - 2018-11-25 13:42:58 --> Router Class Initialized
INFO - 2018-11-25 13:42:58 --> Output Class Initialized
INFO - 2018-11-25 13:42:58 --> Security Class Initialized
DEBUG - 2018-11-25 13:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:42:58 --> Input Class Initialized
INFO - 2018-11-25 13:42:58 --> Language Class Initialized
INFO - 2018-11-25 13:42:58 --> Loader Class Initialized
INFO - 2018-11-25 13:42:58 --> Helper loaded: url_helper
INFO - 2018-11-25 13:42:58 --> Helper loaded: html_helper
INFO - 2018-11-25 13:42:58 --> Helper loaded: form_helper
INFO - 2018-11-25 13:42:58 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:42:58 --> Helper loaded: date_helper
INFO - 2018-11-25 13:42:58 --> Form Validation Class Initialized
INFO - 2018-11-25 13:42:58 --> Email Class Initialized
DEBUG - 2018-11-25 13:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:42:58 --> Pagination Class Initialized
INFO - 2018-11-25 13:42:58 --> Database Driver Class Initialized
INFO - 2018-11-25 13:42:58 --> Database Driver Class Initialized
INFO - 2018-11-25 13:42:58 --> Controller Class Initialized
DEBUG - 2018-11-25 13:42:58 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:42:58 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:42:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:42:58 --> Final output sent to browser
DEBUG - 2018-11-25 13:42:58 --> Total execution time: 0.1327
INFO - 2018-11-25 13:43:07 --> Config Class Initialized
INFO - 2018-11-25 13:43:07 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:43:07 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:43:07 --> Utf8 Class Initialized
INFO - 2018-11-25 13:43:07 --> URI Class Initialized
INFO - 2018-11-25 13:43:07 --> Router Class Initialized
INFO - 2018-11-25 13:43:07 --> Output Class Initialized
INFO - 2018-11-25 13:43:07 --> Security Class Initialized
DEBUG - 2018-11-25 13:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:43:07 --> Input Class Initialized
INFO - 2018-11-25 13:43:07 --> Language Class Initialized
INFO - 2018-11-25 13:43:07 --> Loader Class Initialized
INFO - 2018-11-25 13:43:07 --> Helper loaded: url_helper
INFO - 2018-11-25 13:43:07 --> Helper loaded: html_helper
INFO - 2018-11-25 13:43:07 --> Helper loaded: form_helper
INFO - 2018-11-25 13:43:07 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:43:07 --> Helper loaded: date_helper
INFO - 2018-11-25 13:43:07 --> Form Validation Class Initialized
INFO - 2018-11-25 13:43:07 --> Email Class Initialized
DEBUG - 2018-11-25 13:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:43:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:43:07 --> Pagination Class Initialized
INFO - 2018-11-25 13:43:07 --> Database Driver Class Initialized
INFO - 2018-11-25 13:43:07 --> Database Driver Class Initialized
INFO - 2018-11-25 13:43:07 --> Controller Class Initialized
DEBUG - 2018-11-25 13:43:07 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:43:07 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:43:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:43:07 --> Final output sent to browser
DEBUG - 2018-11-25 13:43:07 --> Total execution time: 0.1116
INFO - 2018-11-25 13:43:09 --> Config Class Initialized
INFO - 2018-11-25 13:43:09 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:43:09 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:43:09 --> Utf8 Class Initialized
INFO - 2018-11-25 13:43:09 --> URI Class Initialized
INFO - 2018-11-25 13:43:09 --> Router Class Initialized
INFO - 2018-11-25 13:43:09 --> Output Class Initialized
INFO - 2018-11-25 13:43:09 --> Security Class Initialized
DEBUG - 2018-11-25 13:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:43:09 --> Input Class Initialized
INFO - 2018-11-25 13:43:09 --> Language Class Initialized
INFO - 2018-11-25 13:43:09 --> Loader Class Initialized
INFO - 2018-11-25 13:43:09 --> Helper loaded: url_helper
INFO - 2018-11-25 13:43:09 --> Helper loaded: html_helper
INFO - 2018-11-25 13:43:09 --> Helper loaded: form_helper
INFO - 2018-11-25 13:43:09 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:43:09 --> Helper loaded: date_helper
INFO - 2018-11-25 13:43:09 --> Form Validation Class Initialized
INFO - 2018-11-25 13:43:09 --> Email Class Initialized
DEBUG - 2018-11-25 13:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:43:09 --> Pagination Class Initialized
INFO - 2018-11-25 13:43:09 --> Database Driver Class Initialized
INFO - 2018-11-25 13:43:09 --> Database Driver Class Initialized
INFO - 2018-11-25 13:43:09 --> Controller Class Initialized
DEBUG - 2018-11-25 13:43:09 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:43:10 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:43:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:43:10 --> Final output sent to browser
DEBUG - 2018-11-25 13:43:10 --> Total execution time: 0.1504
INFO - 2018-11-25 13:43:21 --> Config Class Initialized
INFO - 2018-11-25 13:43:21 --> Hooks Class Initialized
DEBUG - 2018-11-25 13:43:21 --> UTF-8 Support Enabled
INFO - 2018-11-25 13:43:21 --> Utf8 Class Initialized
INFO - 2018-11-25 13:43:21 --> URI Class Initialized
INFO - 2018-11-25 13:43:21 --> Router Class Initialized
INFO - 2018-11-25 13:43:21 --> Output Class Initialized
INFO - 2018-11-25 13:43:21 --> Security Class Initialized
DEBUG - 2018-11-25 13:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-25 13:43:21 --> Input Class Initialized
INFO - 2018-11-25 13:43:21 --> Language Class Initialized
INFO - 2018-11-25 13:43:21 --> Loader Class Initialized
INFO - 2018-11-25 13:43:21 --> Helper loaded: url_helper
INFO - 2018-11-25 13:43:21 --> Helper loaded: html_helper
INFO - 2018-11-25 13:43:21 --> Helper loaded: form_helper
INFO - 2018-11-25 13:43:21 --> Helper loaded: cookie_helper
INFO - 2018-11-25 13:43:21 --> Helper loaded: date_helper
INFO - 2018-11-25 13:43:21 --> Form Validation Class Initialized
INFO - 2018-11-25 13:43:21 --> Email Class Initialized
DEBUG - 2018-11-25 13:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-25 13:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-25 13:43:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-25 13:43:21 --> Pagination Class Initialized
INFO - 2018-11-25 13:43:21 --> Database Driver Class Initialized
INFO - 2018-11-25 13:43:21 --> Database Driver Class Initialized
INFO - 2018-11-25 13:43:21 --> Controller Class Initialized
DEBUG - 2018-11-25 13:43:21 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-25 13:43:21 --> Helper loaded: inflector_helper
INFO - 2018-11-25 13:43:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-25 13:43:21 --> Final output sent to browser
DEBUG - 2018-11-25 13:43:21 --> Total execution time: 0.1320
