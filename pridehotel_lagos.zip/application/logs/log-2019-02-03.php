<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-02-03 15:32:52 --> Config Class Initialized
INFO - 2019-02-03 15:32:52 --> Hooks Class Initialized
DEBUG - 2019-02-03 15:32:52 --> UTF-8 Support Enabled
INFO - 2019-02-03 15:32:52 --> Utf8 Class Initialized
INFO - 2019-02-03 15:32:53 --> URI Class Initialized
DEBUG - 2019-02-03 15:32:53 --> No URI present. Default controller set.
INFO - 2019-02-03 15:32:53 --> Router Class Initialized
INFO - 2019-02-03 15:32:53 --> Output Class Initialized
INFO - 2019-02-03 15:32:53 --> Security Class Initialized
DEBUG - 2019-02-03 15:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-02-03 15:32:53 --> Input Class Initialized
INFO - 2019-02-03 15:32:53 --> Language Class Initialized
INFO - 2019-02-03 15:32:53 --> Loader Class Initialized
INFO - 2019-02-03 15:32:53 --> Helper loaded: url_helper
INFO - 2019-02-03 15:32:53 --> Helper loaded: html_helper
INFO - 2019-02-03 15:32:53 --> Helper loaded: form_helper
INFO - 2019-02-03 15:32:53 --> Helper loaded: cookie_helper
INFO - 2019-02-03 15:32:54 --> Helper loaded: date_helper
INFO - 2019-02-03 15:32:54 --> Form Validation Class Initialized
INFO - 2019-02-03 15:32:54 --> Email Class Initialized
DEBUG - 2019-02-03 15:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-02-03 15:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-02-03 15:32:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-02-03 15:32:54 --> Pagination Class Initialized
INFO - 2019-02-03 15:32:55 --> Database Driver Class Initialized
INFO - 2019-02-03 15:32:55 --> Database Driver Class Initialized
INFO - 2019-02-03 15:32:55 --> Controller Class Initialized
INFO - 2019-02-03 15:32:55 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-02-03 15:32:55 --> Final output sent to browser
DEBUG - 2019-02-03 15:32:55 --> Total execution time: 3.4620
INFO - 2019-02-03 15:33:04 --> Config Class Initialized
INFO - 2019-02-03 15:33:04 --> Hooks Class Initialized
DEBUG - 2019-02-03 15:33:04 --> UTF-8 Support Enabled
INFO - 2019-02-03 15:33:04 --> Utf8 Class Initialized
INFO - 2019-02-03 15:33:04 --> URI Class Initialized
DEBUG - 2019-02-03 15:33:04 --> No URI present. Default controller set.
INFO - 2019-02-03 15:33:04 --> Router Class Initialized
INFO - 2019-02-03 15:33:04 --> Output Class Initialized
INFO - 2019-02-03 15:33:04 --> Security Class Initialized
DEBUG - 2019-02-03 15:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-02-03 15:33:04 --> Input Class Initialized
INFO - 2019-02-03 15:33:04 --> Language Class Initialized
INFO - 2019-02-03 15:33:04 --> Loader Class Initialized
INFO - 2019-02-03 15:33:04 --> Helper loaded: url_helper
INFO - 2019-02-03 15:33:04 --> Helper loaded: html_helper
INFO - 2019-02-03 15:33:04 --> Helper loaded: form_helper
INFO - 2019-02-03 15:33:04 --> Helper loaded: cookie_helper
INFO - 2019-02-03 15:33:04 --> Helper loaded: date_helper
INFO - 2019-02-03 15:33:04 --> Form Validation Class Initialized
INFO - 2019-02-03 15:33:04 --> Email Class Initialized
DEBUG - 2019-02-03 15:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-02-03 15:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-02-03 15:33:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-02-03 15:33:04 --> Pagination Class Initialized
INFO - 2019-02-03 15:33:04 --> Database Driver Class Initialized
INFO - 2019-02-03 15:33:04 --> Database Driver Class Initialized
INFO - 2019-02-03 15:33:04 --> Controller Class Initialized
INFO - 2019-02-03 15:33:04 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-02-03 15:33:04 --> Final output sent to browser
DEBUG - 2019-02-03 15:33:04 --> Total execution time: 0.4980
INFO - 2019-02-03 15:33:17 --> Config Class Initialized
INFO - 2019-02-03 15:33:17 --> Hooks Class Initialized
DEBUG - 2019-02-03 15:33:17 --> UTF-8 Support Enabled
INFO - 2019-02-03 15:33:17 --> Utf8 Class Initialized
INFO - 2019-02-03 15:33:17 --> URI Class Initialized
INFO - 2019-02-03 15:33:17 --> Router Class Initialized
INFO - 2019-02-03 15:33:17 --> Output Class Initialized
INFO - 2019-02-03 15:33:17 --> Security Class Initialized
DEBUG - 2019-02-03 15:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-02-03 15:33:17 --> Input Class Initialized
INFO - 2019-02-03 15:33:17 --> Language Class Initialized
INFO - 2019-02-03 15:33:17 --> Loader Class Initialized
INFO - 2019-02-03 15:33:17 --> Helper loaded: url_helper
INFO - 2019-02-03 15:33:17 --> Helper loaded: html_helper
INFO - 2019-02-03 15:33:17 --> Helper loaded: form_helper
INFO - 2019-02-03 15:33:17 --> Helper loaded: cookie_helper
INFO - 2019-02-03 15:33:17 --> Helper loaded: date_helper
INFO - 2019-02-03 15:33:17 --> Form Validation Class Initialized
INFO - 2019-02-03 15:33:17 --> Email Class Initialized
DEBUG - 2019-02-03 15:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-02-03 15:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-02-03 15:33:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-02-03 15:33:17 --> Pagination Class Initialized
INFO - 2019-02-03 15:33:17 --> Database Driver Class Initialized
INFO - 2019-02-03 15:33:17 --> Database Driver Class Initialized
INFO - 2019-02-03 15:33:17 --> Controller Class Initialized
INFO - 2019-02-03 15:33:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-02-03 15:33:17 --> Config Class Initialized
INFO - 2019-02-03 15:33:17 --> Hooks Class Initialized
DEBUG - 2019-02-03 15:33:17 --> UTF-8 Support Enabled
INFO - 2019-02-03 15:33:17 --> Utf8 Class Initialized
INFO - 2019-02-03 15:33:17 --> URI Class Initialized
INFO - 2019-02-03 15:33:17 --> Router Class Initialized
INFO - 2019-02-03 15:33:17 --> Output Class Initialized
INFO - 2019-02-03 15:33:17 --> Security Class Initialized
DEBUG - 2019-02-03 15:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-02-03 15:33:18 --> Input Class Initialized
INFO - 2019-02-03 15:33:18 --> Language Class Initialized
INFO - 2019-02-03 15:33:18 --> Loader Class Initialized
INFO - 2019-02-03 15:33:18 --> Helper loaded: url_helper
INFO - 2019-02-03 15:33:18 --> Helper loaded: html_helper
INFO - 2019-02-03 15:33:18 --> Helper loaded: form_helper
INFO - 2019-02-03 15:33:18 --> Helper loaded: cookie_helper
INFO - 2019-02-03 15:33:18 --> Helper loaded: date_helper
INFO - 2019-02-03 15:33:18 --> Form Validation Class Initialized
INFO - 2019-02-03 15:33:18 --> Email Class Initialized
DEBUG - 2019-02-03 15:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-02-03 15:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-02-03 15:33:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-02-03 15:33:18 --> Pagination Class Initialized
INFO - 2019-02-03 15:33:18 --> Database Driver Class Initialized
INFO - 2019-02-03 15:33:18 --> Database Driver Class Initialized
INFO - 2019-02-03 15:33:18 --> Controller Class Initialized
INFO - 2019-02-03 15:33:18 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-02-03 15:33:18 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-02-03 15:33:18 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-02-03 15:33:19 --> Final output sent to browser
DEBUG - 2019-02-03 15:33:19 --> Total execution time: 1.1722
INFO - 2019-02-03 15:33:19 --> Config Class Initialized
INFO - 2019-02-03 15:33:19 --> Hooks Class Initialized
DEBUG - 2019-02-03 15:33:19 --> UTF-8 Support Enabled
INFO - 2019-02-03 15:33:19 --> Utf8 Class Initialized
INFO - 2019-02-03 15:33:19 --> URI Class Initialized
INFO - 2019-02-03 15:33:19 --> Router Class Initialized
INFO - 2019-02-03 15:33:19 --> Config Class Initialized
INFO - 2019-02-03 15:33:19 --> Output Class Initialized
INFO - 2019-02-03 15:33:19 --> Hooks Class Initialized
INFO - 2019-02-03 15:33:19 --> Security Class Initialized
DEBUG - 2019-02-03 15:33:19 --> UTF-8 Support Enabled
DEBUG - 2019-02-03 15:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-02-03 15:33:19 --> Utf8 Class Initialized
INFO - 2019-02-03 15:33:19 --> Input Class Initialized
INFO - 2019-02-03 15:33:19 --> URI Class Initialized
INFO - 2019-02-03 15:33:19 --> Router Class Initialized
INFO - 2019-02-03 15:33:20 --> Output Class Initialized
INFO - 2019-02-03 15:33:20 --> Security Class Initialized
DEBUG - 2019-02-03 15:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-02-03 15:33:20 --> Input Class Initialized
INFO - 2019-02-03 15:33:20 --> Language Class Initialized
INFO - 2019-02-03 15:33:20 --> Language Class Initialized
INFO - 2019-02-03 15:33:20 --> Loader Class Initialized
INFO - 2019-02-03 15:33:20 --> Helper loaded: url_helper
INFO - 2019-02-03 15:33:20 --> Helper loaded: html_helper
INFO - 2019-02-03 15:33:20 --> Helper loaded: form_helper
INFO - 2019-02-03 15:33:20 --> Loader Class Initialized
INFO - 2019-02-03 15:33:20 --> Helper loaded: url_helper
INFO - 2019-02-03 15:33:20 --> Helper loaded: html_helper
INFO - 2019-02-03 15:33:20 --> Helper loaded: cookie_helper
INFO - 2019-02-03 15:33:20 --> Helper loaded: form_helper
INFO - 2019-02-03 15:33:20 --> Helper loaded: date_helper
INFO - 2019-02-03 15:33:20 --> Helper loaded: cookie_helper
INFO - 2019-02-03 15:33:20 --> Form Validation Class Initialized
INFO - 2019-02-03 15:33:20 --> Helper loaded: date_helper
INFO - 2019-02-03 15:33:20 --> Email Class Initialized
INFO - 2019-02-03 15:33:20 --> Form Validation Class Initialized
DEBUG - 2019-02-03 15:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-02-03 15:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-02-03 15:33:20 --> Email Class Initialized
INFO - 2019-02-03 15:33:20 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2019-02-03 15:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-02-03 15:33:20 --> Pagination Class Initialized
INFO - 2019-02-03 15:33:21 --> Database Driver Class Initialized
INFO - 2019-02-03 15:33:21 --> Database Driver Class Initialized
INFO - 2019-02-03 15:33:21 --> Controller Class Initialized
INFO - 2019-02-03 15:33:21 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-02-03 15:33:21 --> Final output sent to browser
DEBUG - 2019-02-03 15:33:21 --> Total execution time: 1.7180
INFO - 2019-02-03 15:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-02-03 15:33:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-02-03 15:33:21 --> Pagination Class Initialized
INFO - 2019-02-03 15:33:21 --> Database Driver Class Initialized
INFO - 2019-02-03 15:33:21 --> Database Driver Class Initialized
INFO - 2019-02-03 15:33:21 --> Controller Class Initialized
INFO - 2019-02-03 15:33:21 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-02-03 15:33:21 --> Final output sent to browser
DEBUG - 2019-02-03 15:33:21 --> Total execution time: 1.8409
INFO - 2019-02-03 15:33:28 --> Config Class Initialized
INFO - 2019-02-03 15:33:28 --> Hooks Class Initialized
DEBUG - 2019-02-03 15:33:28 --> UTF-8 Support Enabled
INFO - 2019-02-03 15:33:28 --> Utf8 Class Initialized
INFO - 2019-02-03 15:33:28 --> URI Class Initialized
INFO - 2019-02-03 15:33:28 --> Router Class Initialized
INFO - 2019-02-03 15:33:28 --> Output Class Initialized
INFO - 2019-02-03 15:33:28 --> Security Class Initialized
DEBUG - 2019-02-03 15:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-02-03 15:33:28 --> Input Class Initialized
INFO - 2019-02-03 15:33:28 --> Language Class Initialized
INFO - 2019-02-03 15:33:28 --> Loader Class Initialized
INFO - 2019-02-03 15:33:28 --> Helper loaded: url_helper
INFO - 2019-02-03 15:33:28 --> Helper loaded: html_helper
INFO - 2019-02-03 15:33:28 --> Helper loaded: form_helper
INFO - 2019-02-03 15:33:28 --> Helper loaded: cookie_helper
INFO - 2019-02-03 15:33:28 --> Helper loaded: date_helper
INFO - 2019-02-03 15:33:29 --> Form Validation Class Initialized
INFO - 2019-02-03 15:33:29 --> Email Class Initialized
DEBUG - 2019-02-03 15:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-02-03 15:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-02-03 15:33:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-02-03 15:33:29 --> Pagination Class Initialized
INFO - 2019-02-03 15:33:29 --> Database Driver Class Initialized
INFO - 2019-02-03 15:33:29 --> Database Driver Class Initialized
INFO - 2019-02-03 15:33:29 --> Controller Class Initialized
INFO - 2019-02-03 15:33:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-02-03 15:33:29 --> Final output sent to browser
DEBUG - 2019-02-03 15:33:29 --> Total execution time: 0.5724
INFO - 2019-02-03 15:35:42 --> Config Class Initialized
INFO - 2019-02-03 15:35:42 --> Hooks Class Initialized
DEBUG - 2019-02-03 15:35:42 --> UTF-8 Support Enabled
INFO - 2019-02-03 15:35:42 --> Utf8 Class Initialized
INFO - 2019-02-03 15:35:42 --> URI Class Initialized
INFO - 2019-02-03 15:35:42 --> Router Class Initialized
INFO - 2019-02-03 15:35:42 --> Output Class Initialized
INFO - 2019-02-03 15:35:42 --> Security Class Initialized
DEBUG - 2019-02-03 15:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-02-03 15:35:42 --> Input Class Initialized
INFO - 2019-02-03 15:35:42 --> Language Class Initialized
INFO - 2019-02-03 15:35:42 --> Loader Class Initialized
INFO - 2019-02-03 15:35:42 --> Helper loaded: url_helper
INFO - 2019-02-03 15:35:42 --> Helper loaded: html_helper
INFO - 2019-02-03 15:35:42 --> Helper loaded: form_helper
INFO - 2019-02-03 15:35:42 --> Helper loaded: cookie_helper
INFO - 2019-02-03 15:35:42 --> Helper loaded: date_helper
INFO - 2019-02-03 15:35:42 --> Form Validation Class Initialized
INFO - 2019-02-03 15:35:42 --> Email Class Initialized
DEBUG - 2019-02-03 15:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-02-03 15:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-02-03 15:35:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-02-03 15:35:42 --> Pagination Class Initialized
INFO - 2019-02-03 15:35:42 --> Database Driver Class Initialized
INFO - 2019-02-03 15:35:42 --> Database Driver Class Initialized
INFO - 2019-02-03 15:35:42 --> Controller Class Initialized
INFO - 2019-02-03 15:35:42 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-02-03 15:35:42 --> Final output sent to browser
DEBUG - 2019-02-03 15:35:42 --> Total execution time: 0.5592
INFO - 2019-02-03 15:56:35 --> Config Class Initialized
INFO - 2019-02-03 15:56:35 --> Hooks Class Initialized
DEBUG - 2019-02-03 15:56:35 --> UTF-8 Support Enabled
INFO - 2019-02-03 15:56:35 --> Utf8 Class Initialized
INFO - 2019-02-03 15:56:35 --> URI Class Initialized
INFO - 2019-02-03 15:56:35 --> Router Class Initialized
INFO - 2019-02-03 15:56:35 --> Output Class Initialized
INFO - 2019-02-03 15:56:35 --> Security Class Initialized
DEBUG - 2019-02-03 15:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-02-03 15:56:35 --> Input Class Initialized
INFO - 2019-02-03 15:56:35 --> Language Class Initialized
INFO - 2019-02-03 15:56:35 --> Loader Class Initialized
INFO - 2019-02-03 15:56:36 --> Helper loaded: url_helper
INFO - 2019-02-03 15:56:36 --> Helper loaded: html_helper
INFO - 2019-02-03 15:56:36 --> Helper loaded: form_helper
INFO - 2019-02-03 15:56:36 --> Helper loaded: cookie_helper
INFO - 2019-02-03 15:56:36 --> Helper loaded: date_helper
INFO - 2019-02-03 15:56:36 --> Form Validation Class Initialized
INFO - 2019-02-03 15:56:36 --> Email Class Initialized
DEBUG - 2019-02-03 15:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-02-03 15:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-02-03 15:56:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-02-03 15:56:36 --> Pagination Class Initialized
INFO - 2019-02-03 15:56:36 --> Database Driver Class Initialized
INFO - 2019-02-03 15:56:36 --> Database Driver Class Initialized
INFO - 2019-02-03 15:56:36 --> Controller Class Initialized
INFO - 2019-02-03 15:56:36 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-02-03 15:56:36 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/report.php
INFO - 2019-02-03 15:56:36 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-02-03 15:56:36 --> Final output sent to browser
DEBUG - 2019-02-03 15:56:36 --> Total execution time: 0.8208
INFO - 2019-02-03 15:56:36 --> Config Class Initialized
INFO - 2019-02-03 15:56:36 --> Hooks Class Initialized
DEBUG - 2019-02-03 15:56:36 --> UTF-8 Support Enabled
INFO - 2019-02-03 15:56:36 --> Utf8 Class Initialized
INFO - 2019-02-03 15:56:36 --> URI Class Initialized
INFO - 2019-02-03 15:56:36 --> Router Class Initialized
INFO - 2019-02-03 15:56:36 --> Output Class Initialized
INFO - 2019-02-03 15:56:36 --> Security Class Initialized
DEBUG - 2019-02-03 15:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-02-03 15:56:36 --> Input Class Initialized
INFO - 2019-02-03 15:56:36 --> Language Class Initialized
INFO - 2019-02-03 15:56:36 --> Loader Class Initialized
INFO - 2019-02-03 15:56:36 --> Helper loaded: url_helper
INFO - 2019-02-03 15:56:36 --> Helper loaded: html_helper
INFO - 2019-02-03 15:56:37 --> Helper loaded: form_helper
INFO - 2019-02-03 15:56:37 --> Helper loaded: cookie_helper
INFO - 2019-02-03 15:56:37 --> Helper loaded: date_helper
INFO - 2019-02-03 15:56:37 --> Form Validation Class Initialized
INFO - 2019-02-03 15:56:37 --> Email Class Initialized
DEBUG - 2019-02-03 15:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-02-03 15:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-02-03 15:56:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-02-03 15:56:37 --> Pagination Class Initialized
INFO - 2019-02-03 15:56:37 --> Database Driver Class Initialized
INFO - 2019-02-03 15:56:37 --> Database Driver Class Initialized
INFO - 2019-02-03 15:56:37 --> Controller Class Initialized
INFO - 2019-02-03 15:56:37 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-02-03 15:56:37 --> Final output sent to browser
DEBUG - 2019-02-03 15:56:37 --> Total execution time: 0.6641
INFO - 2019-02-03 16:08:34 --> Config Class Initialized
INFO - 2019-02-03 16:08:34 --> Hooks Class Initialized
DEBUG - 2019-02-03 16:08:34 --> UTF-8 Support Enabled
INFO - 2019-02-03 16:08:34 --> Utf8 Class Initialized
INFO - 2019-02-03 16:08:34 --> URI Class Initialized
INFO - 2019-02-03 16:08:34 --> Router Class Initialized
INFO - 2019-02-03 16:08:34 --> Output Class Initialized
INFO - 2019-02-03 16:08:34 --> Security Class Initialized
DEBUG - 2019-02-03 16:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-02-03 16:08:34 --> Input Class Initialized
INFO - 2019-02-03 16:08:34 --> Language Class Initialized
INFO - 2019-02-03 16:08:34 --> Loader Class Initialized
INFO - 2019-02-03 16:08:34 --> Helper loaded: url_helper
INFO - 2019-02-03 16:08:34 --> Helper loaded: html_helper
INFO - 2019-02-03 16:08:34 --> Helper loaded: form_helper
INFO - 2019-02-03 16:08:34 --> Helper loaded: cookie_helper
INFO - 2019-02-03 16:08:34 --> Helper loaded: date_helper
INFO - 2019-02-03 16:08:34 --> Form Validation Class Initialized
INFO - 2019-02-03 16:08:34 --> Email Class Initialized
DEBUG - 2019-02-03 16:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-02-03 16:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-02-03 16:08:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-02-03 16:08:34 --> Pagination Class Initialized
INFO - 2019-02-03 16:08:34 --> Database Driver Class Initialized
INFO - 2019-02-03 16:08:34 --> Database Driver Class Initialized
INFO - 2019-02-03 16:08:34 --> Controller Class Initialized
INFO - 2019-02-03 16:08:35 --> Config Class Initialized
INFO - 2019-02-03 16:08:35 --> Hooks Class Initialized
DEBUG - 2019-02-03 16:08:35 --> UTF-8 Support Enabled
INFO - 2019-02-03 16:08:35 --> Utf8 Class Initialized
INFO - 2019-02-03 16:08:35 --> URI Class Initialized
INFO - 2019-02-03 16:08:35 --> Router Class Initialized
INFO - 2019-02-03 16:08:35 --> Output Class Initialized
INFO - 2019-02-03 16:08:35 --> Security Class Initialized
DEBUG - 2019-02-03 16:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-02-03 16:08:35 --> Input Class Initialized
INFO - 2019-02-03 16:08:35 --> Language Class Initialized
INFO - 2019-02-03 16:08:35 --> Loader Class Initialized
INFO - 2019-02-03 16:08:35 --> Helper loaded: url_helper
INFO - 2019-02-03 16:08:35 --> Helper loaded: html_helper
INFO - 2019-02-03 16:08:35 --> Helper loaded: form_helper
INFO - 2019-02-03 16:08:35 --> Helper loaded: cookie_helper
INFO - 2019-02-03 16:08:35 --> Helper loaded: date_helper
INFO - 2019-02-03 16:08:35 --> Form Validation Class Initialized
INFO - 2019-02-03 16:08:35 --> Email Class Initialized
DEBUG - 2019-02-03 16:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-02-03 16:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-02-03 16:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-02-03 16:08:35 --> Pagination Class Initialized
INFO - 2019-02-03 16:08:35 --> Database Driver Class Initialized
INFO - 2019-02-03 16:08:35 --> Database Driver Class Initialized
INFO - 2019-02-03 16:08:35 --> Controller Class Initialized
INFO - 2019-02-03 16:08:35 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-02-03 16:08:35 --> Final output sent to browser
DEBUG - 2019-02-03 16:08:35 --> Total execution time: 0.5142
INFO - 2019-02-03 16:12:25 --> Config Class Initialized
INFO - 2019-02-03 16:12:25 --> Hooks Class Initialized
DEBUG - 2019-02-03 16:12:26 --> UTF-8 Support Enabled
INFO - 2019-02-03 16:12:26 --> Utf8 Class Initialized
INFO - 2019-02-03 16:12:26 --> URI Class Initialized
INFO - 2019-02-03 16:12:26 --> Router Class Initialized
INFO - 2019-02-03 16:12:26 --> Output Class Initialized
INFO - 2019-02-03 16:12:26 --> Security Class Initialized
DEBUG - 2019-02-03 16:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-02-03 16:12:26 --> Input Class Initialized
INFO - 2019-02-03 16:12:26 --> Language Class Initialized
INFO - 2019-02-03 16:12:26 --> Loader Class Initialized
INFO - 2019-02-03 16:12:26 --> Helper loaded: url_helper
INFO - 2019-02-03 16:12:26 --> Helper loaded: html_helper
INFO - 2019-02-03 16:12:26 --> Helper loaded: form_helper
INFO - 2019-02-03 16:12:26 --> Helper loaded: cookie_helper
INFO - 2019-02-03 16:12:26 --> Helper loaded: date_helper
INFO - 2019-02-03 16:12:26 --> Form Validation Class Initialized
INFO - 2019-02-03 16:12:26 --> Email Class Initialized
DEBUG - 2019-02-03 16:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-02-03 16:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-02-03 16:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-02-03 16:12:26 --> Pagination Class Initialized
INFO - 2019-02-03 16:12:26 --> Database Driver Class Initialized
INFO - 2019-02-03 16:12:26 --> Database Driver Class Initialized
INFO - 2019-02-03 16:12:26 --> Controller Class Initialized
DEBUG - 2019-02-03 16:12:26 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2019-02-03 16:12:26 --> Helper loaded: inflector_helper
INFO - 2019-02-03 16:12:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-02-03 16:12:26 --> Final output sent to browser
DEBUG - 2019-02-03 16:12:26 --> Total execution time: 0.9983
