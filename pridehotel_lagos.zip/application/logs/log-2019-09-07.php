<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-07 15:13:23 --> Config Class Initialized
INFO - 2019-09-07 15:13:23 --> Hooks Class Initialized
DEBUG - 2019-09-07 15:13:23 --> UTF-8 Support Enabled
INFO - 2019-09-07 15:13:23 --> Utf8 Class Initialized
INFO - 2019-09-07 15:13:23 --> URI Class Initialized
INFO - 2019-09-07 15:13:23 --> Router Class Initialized
INFO - 2019-09-07 15:13:23 --> Output Class Initialized
INFO - 2019-09-07 15:13:23 --> Security Class Initialized
DEBUG - 2019-09-07 15:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 15:13:23 --> Input Class Initialized
INFO - 2019-09-07 15:13:23 --> Language Class Initialized
INFO - 2019-09-07 15:13:23 --> Loader Class Initialized
INFO - 2019-09-07 15:13:23 --> Helper loaded: url_helper
INFO - 2019-09-07 15:13:23 --> Helper loaded: html_helper
INFO - 2019-09-07 15:13:23 --> Helper loaded: form_helper
INFO - 2019-09-07 15:13:23 --> Helper loaded: cookie_helper
INFO - 2019-09-07 15:13:23 --> Helper loaded: date_helper
INFO - 2019-09-07 15:13:23 --> Form Validation Class Initialized
INFO - 2019-09-07 15:13:23 --> Email Class Initialized
DEBUG - 2019-09-07 15:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 15:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 15:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 15:13:24 --> Pagination Class Initialized
INFO - 2019-09-07 15:13:24 --> Database Driver Class Initialized
INFO - 2019-09-07 15:13:24 --> Database Driver Class Initialized
INFO - 2019-09-07 15:13:24 --> Controller Class Initialized
INFO - 2019-09-07 15:13:24 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-07 15:13:24 --> Final output sent to browser
DEBUG - 2019-09-07 15:13:24 --> Total execution time: 1.3259
INFO - 2019-09-07 15:13:38 --> Config Class Initialized
INFO - 2019-09-07 15:13:38 --> Hooks Class Initialized
DEBUG - 2019-09-07 15:13:38 --> UTF-8 Support Enabled
INFO - 2019-09-07 15:13:38 --> Utf8 Class Initialized
INFO - 2019-09-07 15:13:38 --> URI Class Initialized
INFO - 2019-09-07 15:13:38 --> Router Class Initialized
INFO - 2019-09-07 15:13:38 --> Output Class Initialized
INFO - 2019-09-07 15:13:38 --> Security Class Initialized
DEBUG - 2019-09-07 15:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 15:13:38 --> Input Class Initialized
INFO - 2019-09-07 15:13:38 --> Language Class Initialized
INFO - 2019-09-07 15:13:38 --> Loader Class Initialized
INFO - 2019-09-07 15:13:38 --> Helper loaded: url_helper
INFO - 2019-09-07 15:13:38 --> Helper loaded: html_helper
INFO - 2019-09-07 15:13:38 --> Helper loaded: form_helper
INFO - 2019-09-07 15:13:38 --> Helper loaded: cookie_helper
INFO - 2019-09-07 15:13:38 --> Helper loaded: date_helper
INFO - 2019-09-07 15:13:38 --> Form Validation Class Initialized
INFO - 2019-09-07 15:13:38 --> Email Class Initialized
DEBUG - 2019-09-07 15:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 15:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 15:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 15:13:38 --> Pagination Class Initialized
INFO - 2019-09-07 15:13:38 --> Database Driver Class Initialized
INFO - 2019-09-07 15:13:38 --> Database Driver Class Initialized
INFO - 2019-09-07 15:13:38 --> Controller Class Initialized
INFO - 2019-09-07 15:13:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-07 15:13:38 --> Config Class Initialized
INFO - 2019-09-07 15:13:38 --> Hooks Class Initialized
DEBUG - 2019-09-07 15:13:38 --> UTF-8 Support Enabled
INFO - 2019-09-07 15:13:38 --> Utf8 Class Initialized
INFO - 2019-09-07 15:13:38 --> URI Class Initialized
INFO - 2019-09-07 15:13:38 --> Router Class Initialized
INFO - 2019-09-07 15:13:38 --> Output Class Initialized
INFO - 2019-09-07 15:13:38 --> Security Class Initialized
DEBUG - 2019-09-07 15:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 15:13:38 --> Input Class Initialized
INFO - 2019-09-07 15:13:38 --> Language Class Initialized
INFO - 2019-09-07 15:13:38 --> Loader Class Initialized
INFO - 2019-09-07 15:13:38 --> Helper loaded: url_helper
INFO - 2019-09-07 15:13:38 --> Helper loaded: html_helper
INFO - 2019-09-07 15:13:38 --> Helper loaded: form_helper
INFO - 2019-09-07 15:13:38 --> Helper loaded: cookie_helper
INFO - 2019-09-07 15:13:38 --> Helper loaded: date_helper
INFO - 2019-09-07 15:13:38 --> Form Validation Class Initialized
INFO - 2019-09-07 15:13:38 --> Email Class Initialized
DEBUG - 2019-09-07 15:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 15:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 15:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 15:13:38 --> Pagination Class Initialized
INFO - 2019-09-07 15:13:38 --> Database Driver Class Initialized
INFO - 2019-09-07 15:13:38 --> Database Driver Class Initialized
INFO - 2019-09-07 15:13:38 --> Controller Class Initialized
INFO - 2019-09-07 15:13:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-07 15:13:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-07 15:13:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-07 15:13:38 --> Final output sent to browser
DEBUG - 2019-09-07 15:13:38 --> Total execution time: 0.1805
INFO - 2019-09-07 15:13:39 --> Config Class Initialized
INFO - 2019-09-07 15:13:39 --> Hooks Class Initialized
INFO - 2019-09-07 15:13:39 --> Config Class Initialized
INFO - 2019-09-07 15:13:39 --> Hooks Class Initialized
DEBUG - 2019-09-07 15:13:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-07 15:13:39 --> UTF-8 Support Enabled
INFO - 2019-09-07 15:13:39 --> Utf8 Class Initialized
INFO - 2019-09-07 15:13:39 --> Utf8 Class Initialized
INFO - 2019-09-07 15:13:39 --> URI Class Initialized
INFO - 2019-09-07 15:13:39 --> URI Class Initialized
INFO - 2019-09-07 15:13:39 --> Router Class Initialized
INFO - 2019-09-07 15:13:39 --> Router Class Initialized
INFO - 2019-09-07 15:13:39 --> Output Class Initialized
INFO - 2019-09-07 15:13:39 --> Output Class Initialized
INFO - 2019-09-07 15:13:39 --> Security Class Initialized
INFO - 2019-09-07 15:13:39 --> Security Class Initialized
DEBUG - 2019-09-07 15:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 15:13:39 --> Input Class Initialized
DEBUG - 2019-09-07 15:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 15:13:39 --> Input Class Initialized
INFO - 2019-09-07 15:13:39 --> Language Class Initialized
INFO - 2019-09-07 15:13:39 --> Language Class Initialized
INFO - 2019-09-07 15:13:39 --> Loader Class Initialized
INFO - 2019-09-07 15:13:39 --> Loader Class Initialized
INFO - 2019-09-07 15:13:39 --> Helper loaded: url_helper
INFO - 2019-09-07 15:13:39 --> Helper loaded: url_helper
INFO - 2019-09-07 15:13:39 --> Helper loaded: html_helper
INFO - 2019-09-07 15:13:39 --> Helper loaded: html_helper
INFO - 2019-09-07 15:13:39 --> Helper loaded: form_helper
INFO - 2019-09-07 15:13:39 --> Helper loaded: form_helper
INFO - 2019-09-07 15:13:39 --> Helper loaded: cookie_helper
INFO - 2019-09-07 15:13:39 --> Helper loaded: cookie_helper
INFO - 2019-09-07 15:13:39 --> Helper loaded: date_helper
INFO - 2019-09-07 15:13:39 --> Helper loaded: date_helper
INFO - 2019-09-07 15:13:39 --> Form Validation Class Initialized
INFO - 2019-09-07 15:13:39 --> Form Validation Class Initialized
INFO - 2019-09-07 15:13:39 --> Email Class Initialized
INFO - 2019-09-07 15:13:39 --> Email Class Initialized
DEBUG - 2019-09-07 15:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-07 15:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 15:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 15:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 15:13:39 --> Pagination Class Initialized
INFO - 2019-09-07 15:13:39 --> Database Driver Class Initialized
INFO - 2019-09-07 15:13:39 --> Database Driver Class Initialized
INFO - 2019-09-07 15:13:39 --> Controller Class Initialized
INFO - 2019-09-07 15:13:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-07 15:13:39 --> Final output sent to browser
DEBUG - 2019-09-07 15:13:39 --> Total execution time: 0.1486
INFO - 2019-09-07 15:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 15:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 15:13:39 --> Pagination Class Initialized
INFO - 2019-09-07 15:13:39 --> Database Driver Class Initialized
INFO - 2019-09-07 15:13:39 --> Database Driver Class Initialized
INFO - 2019-09-07 15:13:39 --> Controller Class Initialized
INFO - 2019-09-07 15:13:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-07 15:13:39 --> Final output sent to browser
DEBUG - 2019-09-07 15:13:39 --> Total execution time: 0.1781
INFO - 2019-09-07 15:13:40 --> Config Class Initialized
INFO - 2019-09-07 15:13:40 --> Hooks Class Initialized
DEBUG - 2019-09-07 15:13:40 --> UTF-8 Support Enabled
INFO - 2019-09-07 15:13:40 --> Utf8 Class Initialized
INFO - 2019-09-07 15:13:40 --> URI Class Initialized
INFO - 2019-09-07 15:13:40 --> Router Class Initialized
INFO - 2019-09-07 15:13:40 --> Output Class Initialized
INFO - 2019-09-07 15:13:40 --> Security Class Initialized
DEBUG - 2019-09-07 15:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 15:13:40 --> Input Class Initialized
INFO - 2019-09-07 15:13:40 --> Language Class Initialized
INFO - 2019-09-07 15:13:40 --> Loader Class Initialized
INFO - 2019-09-07 15:13:40 --> Helper loaded: url_helper
INFO - 2019-09-07 15:13:40 --> Helper loaded: html_helper
INFO - 2019-09-07 15:13:40 --> Helper loaded: form_helper
INFO - 2019-09-07 15:13:40 --> Helper loaded: cookie_helper
INFO - 2019-09-07 15:13:40 --> Helper loaded: date_helper
INFO - 2019-09-07 15:13:40 --> Form Validation Class Initialized
INFO - 2019-09-07 15:13:40 --> Email Class Initialized
DEBUG - 2019-09-07 15:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 15:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 15:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 15:13:40 --> Pagination Class Initialized
INFO - 2019-09-07 15:13:40 --> Database Driver Class Initialized
INFO - 2019-09-07 15:13:40 --> Database Driver Class Initialized
INFO - 2019-09-07 15:13:40 --> Controller Class Initialized
INFO - 2019-09-07 15:13:40 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-07 15:13:40 --> Final output sent to browser
DEBUG - 2019-09-07 15:13:40 --> Total execution time: 0.0653
INFO - 2019-09-07 15:13:41 --> Config Class Initialized
INFO - 2019-09-07 15:13:41 --> Hooks Class Initialized
DEBUG - 2019-09-07 15:13:41 --> UTF-8 Support Enabled
INFO - 2019-09-07 15:13:41 --> Utf8 Class Initialized
INFO - 2019-09-07 15:13:41 --> URI Class Initialized
INFO - 2019-09-07 15:13:41 --> Router Class Initialized
INFO - 2019-09-07 15:13:41 --> Output Class Initialized
INFO - 2019-09-07 15:13:41 --> Security Class Initialized
DEBUG - 2019-09-07 15:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 15:13:41 --> Input Class Initialized
INFO - 2019-09-07 15:13:41 --> Language Class Initialized
INFO - 2019-09-07 15:13:41 --> Loader Class Initialized
INFO - 2019-09-07 15:13:41 --> Helper loaded: url_helper
INFO - 2019-09-07 15:13:41 --> Helper loaded: html_helper
INFO - 2019-09-07 15:13:41 --> Helper loaded: form_helper
INFO - 2019-09-07 15:13:41 --> Helper loaded: cookie_helper
INFO - 2019-09-07 15:13:41 --> Helper loaded: date_helper
INFO - 2019-09-07 15:13:41 --> Form Validation Class Initialized
INFO - 2019-09-07 15:13:41 --> Email Class Initialized
DEBUG - 2019-09-07 15:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 15:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 15:13:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 15:13:41 --> Pagination Class Initialized
INFO - 2019-09-07 15:13:41 --> Database Driver Class Initialized
INFO - 2019-09-07 15:13:41 --> Database Driver Class Initialized
INFO - 2019-09-07 15:13:41 --> Controller Class Initialized
INFO - 2019-09-07 15:13:41 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-07 15:13:41 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-07 15:13:41 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-07 15:13:41 --> Final output sent to browser
DEBUG - 2019-09-07 15:13:41 --> Total execution time: 0.2104
INFO - 2019-09-07 15:13:41 --> Config Class Initialized
INFO - 2019-09-07 15:13:41 --> Hooks Class Initialized
DEBUG - 2019-09-07 15:13:41 --> UTF-8 Support Enabled
INFO - 2019-09-07 15:13:41 --> Utf8 Class Initialized
INFO - 2019-09-07 15:13:41 --> URI Class Initialized
INFO - 2019-09-07 15:13:41 --> Router Class Initialized
INFO - 2019-09-07 15:13:41 --> Output Class Initialized
INFO - 2019-09-07 15:13:41 --> Security Class Initialized
DEBUG - 2019-09-07 15:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 15:13:41 --> Input Class Initialized
INFO - 2019-09-07 15:13:41 --> Language Class Initialized
INFO - 2019-09-07 15:13:41 --> Loader Class Initialized
INFO - 2019-09-07 15:13:41 --> Helper loaded: url_helper
INFO - 2019-09-07 15:13:41 --> Helper loaded: html_helper
INFO - 2019-09-07 15:13:41 --> Helper loaded: form_helper
INFO - 2019-09-07 15:13:41 --> Helper loaded: cookie_helper
INFO - 2019-09-07 15:13:41 --> Helper loaded: date_helper
INFO - 2019-09-07 15:13:41 --> Form Validation Class Initialized
INFO - 2019-09-07 15:13:41 --> Email Class Initialized
DEBUG - 2019-09-07 15:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 15:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 15:13:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 15:13:41 --> Pagination Class Initialized
INFO - 2019-09-07 15:13:41 --> Database Driver Class Initialized
INFO - 2019-09-07 15:13:41 --> Database Driver Class Initialized
INFO - 2019-09-07 15:13:41 --> Controller Class Initialized
INFO - 2019-09-07 15:13:41 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-07 15:13:41 --> Final output sent to browser
DEBUG - 2019-09-07 15:13:41 --> Total execution time: 0.0691
INFO - 2019-09-07 16:04:07 --> Config Class Initialized
INFO - 2019-09-07 16:04:07 --> Hooks Class Initialized
DEBUG - 2019-09-07 16:04:07 --> UTF-8 Support Enabled
INFO - 2019-09-07 16:04:07 --> Utf8 Class Initialized
INFO - 2019-09-07 16:04:07 --> URI Class Initialized
INFO - 2019-09-07 16:04:07 --> Router Class Initialized
INFO - 2019-09-07 16:04:07 --> Output Class Initialized
INFO - 2019-09-07 16:04:07 --> Security Class Initialized
DEBUG - 2019-09-07 16:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 16:04:07 --> Input Class Initialized
INFO - 2019-09-07 16:04:07 --> Language Class Initialized
INFO - 2019-09-07 16:04:07 --> Loader Class Initialized
INFO - 2019-09-07 16:04:07 --> Helper loaded: url_helper
INFO - 2019-09-07 16:04:07 --> Helper loaded: html_helper
INFO - 2019-09-07 16:04:07 --> Helper loaded: form_helper
INFO - 2019-09-07 16:04:07 --> Helper loaded: cookie_helper
INFO - 2019-09-07 16:04:07 --> Helper loaded: date_helper
INFO - 2019-09-07 16:04:07 --> Form Validation Class Initialized
INFO - 2019-09-07 16:04:07 --> Email Class Initialized
DEBUG - 2019-09-07 16:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 16:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 16:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 16:04:07 --> Pagination Class Initialized
INFO - 2019-09-07 16:04:07 --> Database Driver Class Initialized
INFO - 2019-09-07 16:04:07 --> Database Driver Class Initialized
INFO - 2019-09-07 16:04:07 --> Controller Class Initialized
INFO - 2019-09-07 16:04:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-07 16:04:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-07 16:04:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-07 16:04:08 --> Final output sent to browser
DEBUG - 2019-09-07 16:04:08 --> Total execution time: 0.0741
INFO - 2019-09-07 16:04:08 --> Config Class Initialized
INFO - 2019-09-07 16:04:08 --> Hooks Class Initialized
DEBUG - 2019-09-07 16:04:08 --> UTF-8 Support Enabled
INFO - 2019-09-07 16:04:08 --> Utf8 Class Initialized
INFO - 2019-09-07 16:04:08 --> URI Class Initialized
INFO - 2019-09-07 16:04:08 --> Router Class Initialized
INFO - 2019-09-07 16:04:08 --> Output Class Initialized
INFO - 2019-09-07 16:04:08 --> Security Class Initialized
DEBUG - 2019-09-07 16:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 16:04:08 --> Input Class Initialized
INFO - 2019-09-07 16:04:08 --> Language Class Initialized
INFO - 2019-09-07 16:04:08 --> Loader Class Initialized
INFO - 2019-09-07 16:04:08 --> Helper loaded: url_helper
INFO - 2019-09-07 16:04:08 --> Helper loaded: html_helper
INFO - 2019-09-07 16:04:08 --> Helper loaded: form_helper
INFO - 2019-09-07 16:04:08 --> Helper loaded: cookie_helper
INFO - 2019-09-07 16:04:08 --> Helper loaded: date_helper
INFO - 2019-09-07 16:04:08 --> Form Validation Class Initialized
INFO - 2019-09-07 16:04:08 --> Email Class Initialized
DEBUG - 2019-09-07 16:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 16:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 16:04:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 16:04:08 --> Pagination Class Initialized
INFO - 2019-09-07 16:04:08 --> Database Driver Class Initialized
INFO - 2019-09-07 16:04:08 --> Database Driver Class Initialized
INFO - 2019-09-07 16:04:08 --> Controller Class Initialized
INFO - 2019-09-07 16:04:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-07 16:04:08 --> Final output sent to browser
DEBUG - 2019-09-07 16:04:08 --> Total execution time: 0.0686
INFO - 2019-09-07 16:04:16 --> Config Class Initialized
INFO - 2019-09-07 16:04:16 --> Hooks Class Initialized
DEBUG - 2019-09-07 16:04:16 --> UTF-8 Support Enabled
INFO - 2019-09-07 16:04:16 --> Utf8 Class Initialized
INFO - 2019-09-07 16:04:16 --> URI Class Initialized
INFO - 2019-09-07 16:04:16 --> Router Class Initialized
INFO - 2019-09-07 16:04:16 --> Output Class Initialized
INFO - 2019-09-07 16:04:16 --> Security Class Initialized
DEBUG - 2019-09-07 16:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 16:04:16 --> Input Class Initialized
INFO - 2019-09-07 16:04:16 --> Language Class Initialized
INFO - 2019-09-07 16:04:16 --> Loader Class Initialized
INFO - 2019-09-07 16:04:16 --> Helper loaded: url_helper
INFO - 2019-09-07 16:04:16 --> Helper loaded: html_helper
INFO - 2019-09-07 16:04:16 --> Helper loaded: form_helper
INFO - 2019-09-07 16:04:16 --> Helper loaded: cookie_helper
INFO - 2019-09-07 16:04:16 --> Helper loaded: date_helper
INFO - 2019-09-07 16:04:16 --> Form Validation Class Initialized
INFO - 2019-09-07 16:04:16 --> Email Class Initialized
DEBUG - 2019-09-07 16:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 16:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 16:04:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 16:04:16 --> Pagination Class Initialized
INFO - 2019-09-07 16:04:16 --> Database Driver Class Initialized
INFO - 2019-09-07 16:04:16 --> Database Driver Class Initialized
INFO - 2019-09-07 16:04:16 --> Controller Class Initialized
INFO - 2019-09-07 19:05:20 --> Config Class Initialized
INFO - 2019-09-07 19:05:20 --> Hooks Class Initialized
DEBUG - 2019-09-07 19:05:20 --> UTF-8 Support Enabled
INFO - 2019-09-07 19:05:20 --> Utf8 Class Initialized
INFO - 2019-09-07 19:05:20 --> URI Class Initialized
INFO - 2019-09-07 19:05:20 --> Router Class Initialized
INFO - 2019-09-07 19:05:20 --> Output Class Initialized
INFO - 2019-09-07 19:05:20 --> Security Class Initialized
DEBUG - 2019-09-07 19:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 19:05:20 --> Input Class Initialized
INFO - 2019-09-07 19:05:20 --> Language Class Initialized
INFO - 2019-09-07 19:05:20 --> Loader Class Initialized
INFO - 2019-09-07 19:05:20 --> Helper loaded: url_helper
INFO - 2019-09-07 19:05:20 --> Helper loaded: html_helper
INFO - 2019-09-07 19:05:20 --> Helper loaded: form_helper
INFO - 2019-09-07 19:05:20 --> Helper loaded: cookie_helper
INFO - 2019-09-07 19:05:20 --> Helper loaded: date_helper
INFO - 2019-09-07 19:05:20 --> Form Validation Class Initialized
INFO - 2019-09-07 19:05:20 --> Email Class Initialized
DEBUG - 2019-09-07 19:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 19:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 19:05:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 19:05:21 --> Pagination Class Initialized
INFO - 2019-09-07 19:05:21 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:21 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:21 --> Controller Class Initialized
INFO - 2019-09-07 19:05:21 --> Config Class Initialized
INFO - 2019-09-07 19:05:21 --> Hooks Class Initialized
DEBUG - 2019-09-07 19:05:21 --> UTF-8 Support Enabled
INFO - 2019-09-07 19:05:21 --> Utf8 Class Initialized
INFO - 2019-09-07 19:05:21 --> URI Class Initialized
INFO - 2019-09-07 19:05:21 --> Router Class Initialized
INFO - 2019-09-07 19:05:21 --> Output Class Initialized
INFO - 2019-09-07 19:05:21 --> Security Class Initialized
DEBUG - 2019-09-07 19:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 19:05:21 --> Input Class Initialized
INFO - 2019-09-07 19:05:21 --> Language Class Initialized
INFO - 2019-09-07 19:05:21 --> Loader Class Initialized
INFO - 2019-09-07 19:05:21 --> Helper loaded: url_helper
INFO - 2019-09-07 19:05:21 --> Helper loaded: html_helper
INFO - 2019-09-07 19:05:21 --> Helper loaded: form_helper
INFO - 2019-09-07 19:05:21 --> Helper loaded: cookie_helper
INFO - 2019-09-07 19:05:21 --> Helper loaded: date_helper
INFO - 2019-09-07 19:05:21 --> Form Validation Class Initialized
INFO - 2019-09-07 19:05:21 --> Email Class Initialized
DEBUG - 2019-09-07 19:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 19:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 19:05:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 19:05:21 --> Pagination Class Initialized
INFO - 2019-09-07 19:05:21 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:21 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:21 --> Controller Class Initialized
INFO - 2019-09-07 19:05:21 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-07 19:05:21 --> Final output sent to browser
DEBUG - 2019-09-07 19:05:21 --> Total execution time: 0.1654
INFO - 2019-09-07 19:05:36 --> Config Class Initialized
INFO - 2019-09-07 19:05:36 --> Hooks Class Initialized
DEBUG - 2019-09-07 19:05:36 --> UTF-8 Support Enabled
INFO - 2019-09-07 19:05:36 --> Utf8 Class Initialized
INFO - 2019-09-07 19:05:36 --> URI Class Initialized
INFO - 2019-09-07 19:05:36 --> Router Class Initialized
INFO - 2019-09-07 19:05:36 --> Output Class Initialized
INFO - 2019-09-07 19:05:36 --> Security Class Initialized
DEBUG - 2019-09-07 19:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 19:05:36 --> Input Class Initialized
INFO - 2019-09-07 19:05:36 --> Language Class Initialized
INFO - 2019-09-07 19:05:36 --> Loader Class Initialized
INFO - 2019-09-07 19:05:36 --> Helper loaded: url_helper
INFO - 2019-09-07 19:05:36 --> Helper loaded: html_helper
INFO - 2019-09-07 19:05:36 --> Helper loaded: form_helper
INFO - 2019-09-07 19:05:36 --> Helper loaded: cookie_helper
INFO - 2019-09-07 19:05:36 --> Helper loaded: date_helper
INFO - 2019-09-07 19:05:36 --> Form Validation Class Initialized
INFO - 2019-09-07 19:05:36 --> Email Class Initialized
DEBUG - 2019-09-07 19:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 19:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 19:05:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 19:05:36 --> Pagination Class Initialized
INFO - 2019-09-07 19:05:36 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:36 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:36 --> Controller Class Initialized
INFO - 2019-09-07 19:05:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-07 19:05:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-07 19:05:36 --> Final output sent to browser
DEBUG - 2019-09-07 19:05:36 --> Total execution time: 0.1541
INFO - 2019-09-07 19:05:46 --> Config Class Initialized
INFO - 2019-09-07 19:05:46 --> Hooks Class Initialized
DEBUG - 2019-09-07 19:05:46 --> UTF-8 Support Enabled
INFO - 2019-09-07 19:05:46 --> Utf8 Class Initialized
INFO - 2019-09-07 19:05:46 --> URI Class Initialized
INFO - 2019-09-07 19:05:46 --> Router Class Initialized
INFO - 2019-09-07 19:05:46 --> Output Class Initialized
INFO - 2019-09-07 19:05:46 --> Security Class Initialized
DEBUG - 2019-09-07 19:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 19:05:46 --> Input Class Initialized
INFO - 2019-09-07 19:05:46 --> Language Class Initialized
INFO - 2019-09-07 19:05:46 --> Loader Class Initialized
INFO - 2019-09-07 19:05:46 --> Helper loaded: url_helper
INFO - 2019-09-07 19:05:46 --> Helper loaded: html_helper
INFO - 2019-09-07 19:05:46 --> Helper loaded: form_helper
INFO - 2019-09-07 19:05:46 --> Helper loaded: cookie_helper
INFO - 2019-09-07 19:05:46 --> Helper loaded: date_helper
INFO - 2019-09-07 19:05:46 --> Form Validation Class Initialized
INFO - 2019-09-07 19:05:46 --> Email Class Initialized
DEBUG - 2019-09-07 19:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 19:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 19:05:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 19:05:46 --> Pagination Class Initialized
INFO - 2019-09-07 19:05:46 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:46 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:46 --> Controller Class Initialized
INFO - 2019-09-07 19:05:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-07 19:05:47 --> Config Class Initialized
INFO - 2019-09-07 19:05:47 --> Hooks Class Initialized
DEBUG - 2019-09-07 19:05:47 --> UTF-8 Support Enabled
INFO - 2019-09-07 19:05:47 --> Utf8 Class Initialized
INFO - 2019-09-07 19:05:47 --> URI Class Initialized
INFO - 2019-09-07 19:05:47 --> Router Class Initialized
INFO - 2019-09-07 19:05:47 --> Output Class Initialized
INFO - 2019-09-07 19:05:47 --> Security Class Initialized
DEBUG - 2019-09-07 19:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 19:05:47 --> Input Class Initialized
INFO - 2019-09-07 19:05:47 --> Language Class Initialized
INFO - 2019-09-07 19:05:47 --> Loader Class Initialized
INFO - 2019-09-07 19:05:47 --> Helper loaded: url_helper
INFO - 2019-09-07 19:05:47 --> Helper loaded: html_helper
INFO - 2019-09-07 19:05:47 --> Helper loaded: form_helper
INFO - 2019-09-07 19:05:47 --> Helper loaded: cookie_helper
INFO - 2019-09-07 19:05:47 --> Helper loaded: date_helper
INFO - 2019-09-07 19:05:47 --> Form Validation Class Initialized
INFO - 2019-09-07 19:05:47 --> Email Class Initialized
DEBUG - 2019-09-07 19:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 19:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 19:05:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 19:05:47 --> Pagination Class Initialized
INFO - 2019-09-07 19:05:47 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:47 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:47 --> Controller Class Initialized
INFO - 2019-09-07 19:05:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-07 19:05:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-07 19:05:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-07 19:05:47 --> Final output sent to browser
DEBUG - 2019-09-07 19:05:47 --> Total execution time: 0.2119
INFO - 2019-09-07 19:05:47 --> Config Class Initialized
INFO - 2019-09-07 19:05:47 --> Hooks Class Initialized
INFO - 2019-09-07 19:05:47 --> Config Class Initialized
DEBUG - 2019-09-07 19:05:47 --> UTF-8 Support Enabled
INFO - 2019-09-07 19:05:47 --> Hooks Class Initialized
INFO - 2019-09-07 19:05:47 --> Utf8 Class Initialized
INFO - 2019-09-07 19:05:47 --> URI Class Initialized
DEBUG - 2019-09-07 19:05:47 --> UTF-8 Support Enabled
INFO - 2019-09-07 19:05:47 --> Utf8 Class Initialized
INFO - 2019-09-07 19:05:47 --> Router Class Initialized
INFO - 2019-09-07 19:05:47 --> URI Class Initialized
INFO - 2019-09-07 19:05:47 --> Output Class Initialized
INFO - 2019-09-07 19:05:47 --> Router Class Initialized
INFO - 2019-09-07 19:05:47 --> Security Class Initialized
DEBUG - 2019-09-07 19:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 19:05:47 --> Output Class Initialized
INFO - 2019-09-07 19:05:47 --> Input Class Initialized
INFO - 2019-09-07 19:05:47 --> Language Class Initialized
INFO - 2019-09-07 19:05:47 --> Security Class Initialized
DEBUG - 2019-09-07 19:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 19:05:47 --> Input Class Initialized
INFO - 2019-09-07 19:05:47 --> Language Class Initialized
INFO - 2019-09-07 19:05:47 --> Loader Class Initialized
INFO - 2019-09-07 19:05:48 --> Loader Class Initialized
INFO - 2019-09-07 19:05:48 --> Helper loaded: url_helper
INFO - 2019-09-07 19:05:48 --> Helper loaded: html_helper
INFO - 2019-09-07 19:05:48 --> Helper loaded: form_helper
INFO - 2019-09-07 19:05:48 --> Helper loaded: cookie_helper
INFO - 2019-09-07 19:05:48 --> Helper loaded: url_helper
INFO - 2019-09-07 19:05:48 --> Helper loaded: date_helper
INFO - 2019-09-07 19:05:48 --> Helper loaded: html_helper
INFO - 2019-09-07 19:05:48 --> Form Validation Class Initialized
INFO - 2019-09-07 19:05:48 --> Helper loaded: form_helper
INFO - 2019-09-07 19:05:48 --> Helper loaded: cookie_helper
INFO - 2019-09-07 19:05:48 --> Helper loaded: date_helper
INFO - 2019-09-07 19:05:48 --> Email Class Initialized
INFO - 2019-09-07 19:05:48 --> Form Validation Class Initialized
DEBUG - 2019-09-07 19:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 19:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 19:05:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 19:05:48 --> Pagination Class Initialized
INFO - 2019-09-07 19:05:48 --> Email Class Initialized
DEBUG - 2019-09-07 19:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 19:05:48 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:48 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:48 --> Controller Class Initialized
INFO - 2019-09-07 19:05:48 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-07 19:05:48 --> Final output sent to browser
DEBUG - 2019-09-07 19:05:48 --> Total execution time: 0.2513
INFO - 2019-09-07 19:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 19:05:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 19:05:48 --> Pagination Class Initialized
INFO - 2019-09-07 19:05:48 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:48 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:48 --> Controller Class Initialized
INFO - 2019-09-07 19:05:48 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-07 19:05:48 --> Final output sent to browser
DEBUG - 2019-09-07 19:05:48 --> Total execution time: 0.3610
INFO - 2019-09-07 19:05:49 --> Config Class Initialized
INFO - 2019-09-07 19:05:49 --> Hooks Class Initialized
INFO - 2019-09-07 19:05:49 --> Config Class Initialized
INFO - 2019-09-07 19:05:49 --> Hooks Class Initialized
DEBUG - 2019-09-07 19:05:49 --> UTF-8 Support Enabled
INFO - 2019-09-07 19:05:49 --> Utf8 Class Initialized
DEBUG - 2019-09-07 19:05:49 --> UTF-8 Support Enabled
INFO - 2019-09-07 19:05:49 --> Utf8 Class Initialized
INFO - 2019-09-07 19:05:49 --> URI Class Initialized
INFO - 2019-09-07 19:05:49 --> URI Class Initialized
INFO - 2019-09-07 19:05:49 --> Router Class Initialized
INFO - 2019-09-07 19:05:49 --> Router Class Initialized
INFO - 2019-09-07 19:05:49 --> Output Class Initialized
INFO - 2019-09-07 19:05:49 --> Output Class Initialized
INFO - 2019-09-07 19:05:49 --> Security Class Initialized
INFO - 2019-09-07 19:05:49 --> Security Class Initialized
DEBUG - 2019-09-07 19:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-07 19:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 19:05:49 --> Input Class Initialized
INFO - 2019-09-07 19:05:49 --> Input Class Initialized
INFO - 2019-09-07 19:05:49 --> Language Class Initialized
INFO - 2019-09-07 19:05:49 --> Language Class Initialized
INFO - 2019-09-07 19:05:49 --> Loader Class Initialized
INFO - 2019-09-07 19:05:49 --> Loader Class Initialized
INFO - 2019-09-07 19:05:49 --> Helper loaded: url_helper
INFO - 2019-09-07 19:05:49 --> Helper loaded: url_helper
INFO - 2019-09-07 19:05:49 --> Helper loaded: html_helper
INFO - 2019-09-07 19:05:49 --> Helper loaded: html_helper
INFO - 2019-09-07 19:05:49 --> Helper loaded: form_helper
INFO - 2019-09-07 19:05:49 --> Helper loaded: form_helper
INFO - 2019-09-07 19:05:49 --> Helper loaded: cookie_helper
INFO - 2019-09-07 19:05:49 --> Helper loaded: cookie_helper
INFO - 2019-09-07 19:05:49 --> Helper loaded: date_helper
INFO - 2019-09-07 19:05:49 --> Helper loaded: date_helper
INFO - 2019-09-07 19:05:49 --> Form Validation Class Initialized
INFO - 2019-09-07 19:05:49 --> Form Validation Class Initialized
INFO - 2019-09-07 19:05:49 --> Email Class Initialized
INFO - 2019-09-07 19:05:49 --> Email Class Initialized
DEBUG - 2019-09-07 19:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 19:05:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-09-07 19:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 19:05:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 19:05:49 --> Pagination Class Initialized
INFO - 2019-09-07 19:05:49 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:49 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:49 --> Controller Class Initialized
INFO - 2019-09-07 19:05:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-07 19:05:49 --> Final output sent to browser
DEBUG - 2019-09-07 19:05:49 --> Total execution time: 0.2089
INFO - 2019-09-07 19:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 19:05:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 19:05:49 --> Pagination Class Initialized
INFO - 2019-09-07 19:05:49 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:49 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:49 --> Controller Class Initialized
INFO - 2019-09-07 19:05:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-07 19:05:49 --> Final output sent to browser
DEBUG - 2019-09-07 19:05:49 --> Total execution time: 0.2811
INFO - 2019-09-07 19:05:50 --> Config Class Initialized
INFO - 2019-09-07 19:05:50 --> Hooks Class Initialized
DEBUG - 2019-09-07 19:05:50 --> UTF-8 Support Enabled
INFO - 2019-09-07 19:05:50 --> Utf8 Class Initialized
INFO - 2019-09-07 19:05:50 --> URI Class Initialized
INFO - 2019-09-07 19:05:50 --> Router Class Initialized
INFO - 2019-09-07 19:05:50 --> Output Class Initialized
INFO - 2019-09-07 19:05:50 --> Security Class Initialized
DEBUG - 2019-09-07 19:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 19:05:50 --> Input Class Initialized
INFO - 2019-09-07 19:05:50 --> Language Class Initialized
INFO - 2019-09-07 19:05:50 --> Loader Class Initialized
INFO - 2019-09-07 19:05:50 --> Helper loaded: url_helper
INFO - 2019-09-07 19:05:50 --> Helper loaded: html_helper
INFO - 2019-09-07 19:05:50 --> Helper loaded: form_helper
INFO - 2019-09-07 19:05:50 --> Helper loaded: cookie_helper
INFO - 2019-09-07 19:05:50 --> Helper loaded: date_helper
INFO - 2019-09-07 19:05:50 --> Form Validation Class Initialized
INFO - 2019-09-07 19:05:50 --> Email Class Initialized
DEBUG - 2019-09-07 19:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 19:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 19:05:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 19:05:50 --> Pagination Class Initialized
INFO - 2019-09-07 19:05:50 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:50 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:50 --> Controller Class Initialized
INFO - 2019-09-07 19:05:50 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-07 19:05:50 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-07 19:05:50 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-07 19:05:50 --> Final output sent to browser
DEBUG - 2019-09-07 19:05:50 --> Total execution time: 0.3227
INFO - 2019-09-07 19:05:50 --> Config Class Initialized
INFO - 2019-09-07 19:05:50 --> Hooks Class Initialized
DEBUG - 2019-09-07 19:05:50 --> UTF-8 Support Enabled
INFO - 2019-09-07 19:05:50 --> Utf8 Class Initialized
INFO - 2019-09-07 19:05:50 --> URI Class Initialized
INFO - 2019-09-07 19:05:50 --> Router Class Initialized
INFO - 2019-09-07 19:05:50 --> Output Class Initialized
INFO - 2019-09-07 19:05:50 --> Security Class Initialized
DEBUG - 2019-09-07 19:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 19:05:50 --> Input Class Initialized
INFO - 2019-09-07 19:05:50 --> Language Class Initialized
INFO - 2019-09-07 19:05:50 --> Loader Class Initialized
INFO - 2019-09-07 19:05:50 --> Helper loaded: url_helper
INFO - 2019-09-07 19:05:50 --> Helper loaded: html_helper
INFO - 2019-09-07 19:05:50 --> Helper loaded: form_helper
INFO - 2019-09-07 19:05:50 --> Helper loaded: cookie_helper
INFO - 2019-09-07 19:05:50 --> Helper loaded: date_helper
INFO - 2019-09-07 19:05:50 --> Form Validation Class Initialized
INFO - 2019-09-07 19:05:50 --> Email Class Initialized
DEBUG - 2019-09-07 19:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 19:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 19:05:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 19:05:50 --> Pagination Class Initialized
INFO - 2019-09-07 19:05:50 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:50 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:50 --> Controller Class Initialized
INFO - 2019-09-07 19:05:50 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-07 19:05:50 --> Final output sent to browser
DEBUG - 2019-09-07 19:05:50 --> Total execution time: 0.1793
INFO - 2019-09-07 19:05:56 --> Config Class Initialized
INFO - 2019-09-07 19:05:56 --> Hooks Class Initialized
DEBUG - 2019-09-07 19:05:56 --> UTF-8 Support Enabled
INFO - 2019-09-07 19:05:56 --> Utf8 Class Initialized
INFO - 2019-09-07 19:05:56 --> URI Class Initialized
INFO - 2019-09-07 19:05:56 --> Router Class Initialized
INFO - 2019-09-07 19:05:56 --> Output Class Initialized
INFO - 2019-09-07 19:05:56 --> Security Class Initialized
DEBUG - 2019-09-07 19:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 19:05:56 --> Input Class Initialized
INFO - 2019-09-07 19:05:56 --> Language Class Initialized
INFO - 2019-09-07 19:05:57 --> Loader Class Initialized
INFO - 2019-09-07 19:05:57 --> Helper loaded: url_helper
INFO - 2019-09-07 19:05:57 --> Helper loaded: html_helper
INFO - 2019-09-07 19:05:57 --> Helper loaded: form_helper
INFO - 2019-09-07 19:05:57 --> Helper loaded: cookie_helper
INFO - 2019-09-07 19:05:57 --> Helper loaded: date_helper
INFO - 2019-09-07 19:05:57 --> Form Validation Class Initialized
INFO - 2019-09-07 19:05:57 --> Email Class Initialized
DEBUG - 2019-09-07 19:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 19:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 19:05:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 19:05:57 --> Pagination Class Initialized
INFO - 2019-09-07 19:05:57 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:57 --> Database Driver Class Initialized
INFO - 2019-09-07 19:05:57 --> Controller Class Initialized
INFO - 2019-09-07 19:08:43 --> Config Class Initialized
INFO - 2019-09-07 19:08:43 --> Hooks Class Initialized
DEBUG - 2019-09-07 19:08:43 --> UTF-8 Support Enabled
INFO - 2019-09-07 19:08:43 --> Utf8 Class Initialized
INFO - 2019-09-07 19:08:43 --> URI Class Initialized
INFO - 2019-09-07 19:08:43 --> Router Class Initialized
INFO - 2019-09-07 19:08:43 --> Output Class Initialized
INFO - 2019-09-07 19:08:43 --> Security Class Initialized
DEBUG - 2019-09-07 19:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 19:08:43 --> Input Class Initialized
INFO - 2019-09-07 19:08:43 --> Language Class Initialized
INFO - 2019-09-07 19:08:43 --> Loader Class Initialized
INFO - 2019-09-07 19:08:43 --> Helper loaded: url_helper
INFO - 2019-09-07 19:08:43 --> Helper loaded: html_helper
INFO - 2019-09-07 19:08:43 --> Helper loaded: form_helper
INFO - 2019-09-07 19:08:43 --> Helper loaded: cookie_helper
INFO - 2019-09-07 19:08:43 --> Helper loaded: date_helper
INFO - 2019-09-07 19:08:43 --> Form Validation Class Initialized
INFO - 2019-09-07 19:08:43 --> Email Class Initialized
DEBUG - 2019-09-07 19:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 19:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 19:08:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 19:08:43 --> Pagination Class Initialized
INFO - 2019-09-07 19:08:43 --> Database Driver Class Initialized
INFO - 2019-09-07 19:08:43 --> Database Driver Class Initialized
INFO - 2019-09-07 19:08:43 --> Controller Class Initialized
INFO - 2019-09-07 19:08:43 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-07 19:08:43 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report.php
INFO - 2019-09-07 19:08:43 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-07 19:08:44 --> Final output sent to browser
DEBUG - 2019-09-07 19:08:44 --> Total execution time: 0.1884
INFO - 2019-09-07 19:59:05 --> Config Class Initialized
INFO - 2019-09-07 19:59:05 --> Hooks Class Initialized
DEBUG - 2019-09-07 19:59:06 --> UTF-8 Support Enabled
INFO - 2019-09-07 19:59:06 --> Utf8 Class Initialized
INFO - 2019-09-07 19:59:06 --> URI Class Initialized
INFO - 2019-09-07 19:59:06 --> Router Class Initialized
INFO - 2019-09-07 19:59:06 --> Output Class Initialized
INFO - 2019-09-07 19:59:06 --> Security Class Initialized
DEBUG - 2019-09-07 19:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 19:59:06 --> Input Class Initialized
INFO - 2019-09-07 19:59:06 --> Language Class Initialized
INFO - 2019-09-07 19:59:06 --> Loader Class Initialized
INFO - 2019-09-07 19:59:06 --> Helper loaded: url_helper
INFO - 2019-09-07 19:59:06 --> Helper loaded: html_helper
INFO - 2019-09-07 19:59:06 --> Helper loaded: form_helper
INFO - 2019-09-07 19:59:06 --> Helper loaded: cookie_helper
INFO - 2019-09-07 19:59:06 --> Helper loaded: date_helper
INFO - 2019-09-07 19:59:06 --> Form Validation Class Initialized
INFO - 2019-09-07 19:59:06 --> Email Class Initialized
DEBUG - 2019-09-07 19:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 19:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 19:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 19:59:06 --> Pagination Class Initialized
INFO - 2019-09-07 19:59:06 --> Database Driver Class Initialized
INFO - 2019-09-07 19:59:06 --> Database Driver Class Initialized
INFO - 2019-09-07 19:59:06 --> Controller Class Initialized
INFO - 2019-09-07 19:59:06 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-07 19:59:06 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-07 19:59:06 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-07 19:59:06 --> Final output sent to browser
DEBUG - 2019-09-07 19:59:06 --> Total execution time: 1.0441
INFO - 2019-09-07 19:59:07 --> Config Class Initialized
INFO - 2019-09-07 19:59:07 --> Hooks Class Initialized
DEBUG - 2019-09-07 19:59:07 --> UTF-8 Support Enabled
INFO - 2019-09-07 19:59:07 --> Utf8 Class Initialized
INFO - 2019-09-07 19:59:07 --> URI Class Initialized
INFO - 2019-09-07 19:59:07 --> Router Class Initialized
INFO - 2019-09-07 19:59:07 --> Output Class Initialized
INFO - 2019-09-07 19:59:07 --> Security Class Initialized
DEBUG - 2019-09-07 19:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 19:59:07 --> Input Class Initialized
INFO - 2019-09-07 19:59:07 --> Language Class Initialized
INFO - 2019-09-07 19:59:07 --> Loader Class Initialized
INFO - 2019-09-07 19:59:07 --> Helper loaded: url_helper
INFO - 2019-09-07 19:59:07 --> Helper loaded: html_helper
INFO - 2019-09-07 19:59:07 --> Helper loaded: form_helper
INFO - 2019-09-07 19:59:07 --> Helper loaded: cookie_helper
INFO - 2019-09-07 19:59:07 --> Helper loaded: date_helper
INFO - 2019-09-07 19:59:07 --> Form Validation Class Initialized
INFO - 2019-09-07 19:59:07 --> Email Class Initialized
DEBUG - 2019-09-07 19:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 19:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 19:59:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 19:59:07 --> Pagination Class Initialized
INFO - 2019-09-07 19:59:07 --> Database Driver Class Initialized
INFO - 2019-09-07 19:59:07 --> Database Driver Class Initialized
INFO - 2019-09-07 19:59:07 --> Controller Class Initialized
INFO - 2019-09-07 19:59:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-07 19:59:07 --> Final output sent to browser
DEBUG - 2019-09-07 19:59:07 --> Total execution time: 0.2884
INFO - 2019-09-07 19:59:25 --> Config Class Initialized
INFO - 2019-09-07 19:59:25 --> Hooks Class Initialized
DEBUG - 2019-09-07 19:59:25 --> UTF-8 Support Enabled
INFO - 2019-09-07 19:59:25 --> Utf8 Class Initialized
INFO - 2019-09-07 19:59:25 --> URI Class Initialized
INFO - 2019-09-07 19:59:25 --> Router Class Initialized
INFO - 2019-09-07 19:59:25 --> Output Class Initialized
INFO - 2019-09-07 19:59:25 --> Security Class Initialized
DEBUG - 2019-09-07 19:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 19:59:25 --> Input Class Initialized
INFO - 2019-09-07 19:59:25 --> Language Class Initialized
INFO - 2019-09-07 19:59:25 --> Loader Class Initialized
INFO - 2019-09-07 19:59:25 --> Helper loaded: url_helper
INFO - 2019-09-07 19:59:25 --> Helper loaded: html_helper
INFO - 2019-09-07 19:59:25 --> Helper loaded: form_helper
INFO - 2019-09-07 19:59:25 --> Helper loaded: cookie_helper
INFO - 2019-09-07 19:59:25 --> Helper loaded: date_helper
INFO - 2019-09-07 19:59:25 --> Form Validation Class Initialized
INFO - 2019-09-07 19:59:25 --> Email Class Initialized
DEBUG - 2019-09-07 19:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 19:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 19:59:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 19:59:25 --> Pagination Class Initialized
INFO - 2019-09-07 19:59:25 --> Database Driver Class Initialized
INFO - 2019-09-07 19:59:25 --> Database Driver Class Initialized
INFO - 2019-09-07 19:59:25 --> Controller Class Initialized
INFO - 2019-09-07 20:15:11 --> Config Class Initialized
INFO - 2019-09-07 20:15:11 --> Hooks Class Initialized
DEBUG - 2019-09-07 20:15:11 --> UTF-8 Support Enabled
INFO - 2019-09-07 20:15:11 --> Utf8 Class Initialized
INFO - 2019-09-07 20:15:11 --> URI Class Initialized
INFO - 2019-09-07 20:15:11 --> Router Class Initialized
INFO - 2019-09-07 20:15:11 --> Output Class Initialized
INFO - 2019-09-07 20:15:11 --> Security Class Initialized
DEBUG - 2019-09-07 20:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 20:15:11 --> Input Class Initialized
INFO - 2019-09-07 20:15:11 --> Language Class Initialized
INFO - 2019-09-07 20:15:11 --> Loader Class Initialized
INFO - 2019-09-07 20:15:11 --> Helper loaded: url_helper
INFO - 2019-09-07 20:15:11 --> Helper loaded: html_helper
INFO - 2019-09-07 20:15:11 --> Helper loaded: form_helper
INFO - 2019-09-07 20:15:11 --> Helper loaded: cookie_helper
INFO - 2019-09-07 20:15:11 --> Helper loaded: date_helper
INFO - 2019-09-07 20:15:11 --> Form Validation Class Initialized
INFO - 2019-09-07 20:15:11 --> Email Class Initialized
DEBUG - 2019-09-07 20:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 20:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 20:15:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 20:15:11 --> Pagination Class Initialized
INFO - 2019-09-07 20:15:11 --> Database Driver Class Initialized
INFO - 2019-09-07 20:15:11 --> Database Driver Class Initialized
INFO - 2019-09-07 20:15:11 --> Controller Class Initialized
INFO - 2019-09-07 20:15:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-07 20:15:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-07 20:15:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-07 20:15:11 --> Final output sent to browser
DEBUG - 2019-09-07 20:15:11 --> Total execution time: 0.1128
INFO - 2019-09-07 20:15:12 --> Config Class Initialized
INFO - 2019-09-07 20:15:12 --> Hooks Class Initialized
DEBUG - 2019-09-07 20:15:12 --> UTF-8 Support Enabled
INFO - 2019-09-07 20:15:12 --> Utf8 Class Initialized
INFO - 2019-09-07 20:15:12 --> URI Class Initialized
INFO - 2019-09-07 20:15:12 --> Router Class Initialized
INFO - 2019-09-07 20:15:12 --> Output Class Initialized
INFO - 2019-09-07 20:15:12 --> Security Class Initialized
DEBUG - 2019-09-07 20:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 20:15:12 --> Input Class Initialized
INFO - 2019-09-07 20:15:12 --> Language Class Initialized
INFO - 2019-09-07 20:15:12 --> Loader Class Initialized
INFO - 2019-09-07 20:15:12 --> Helper loaded: url_helper
INFO - 2019-09-07 20:15:12 --> Helper loaded: html_helper
INFO - 2019-09-07 20:15:12 --> Helper loaded: form_helper
INFO - 2019-09-07 20:15:12 --> Helper loaded: cookie_helper
INFO - 2019-09-07 20:15:12 --> Helper loaded: date_helper
INFO - 2019-09-07 20:15:12 --> Form Validation Class Initialized
INFO - 2019-09-07 20:15:12 --> Email Class Initialized
DEBUG - 2019-09-07 20:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 20:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 20:15:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 20:15:12 --> Pagination Class Initialized
INFO - 2019-09-07 20:15:12 --> Config Class Initialized
INFO - 2019-09-07 20:15:12 --> Hooks Class Initialized
INFO - 2019-09-07 20:15:12 --> Database Driver Class Initialized
INFO - 2019-09-07 20:15:12 --> Database Driver Class Initialized
DEBUG - 2019-09-07 20:15:12 --> UTF-8 Support Enabled
INFO - 2019-09-07 20:15:12 --> Utf8 Class Initialized
INFO - 2019-09-07 20:15:12 --> URI Class Initialized
INFO - 2019-09-07 20:15:12 --> Router Class Initialized
INFO - 2019-09-07 20:15:12 --> Output Class Initialized
INFO - 2019-09-07 20:15:12 --> Controller Class Initialized
INFO - 2019-09-07 20:15:12 --> Security Class Initialized
DEBUG - 2019-09-07 20:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 20:15:12 --> Input Class Initialized
INFO - 2019-09-07 20:15:12 --> Language Class Initialized
INFO - 2019-09-07 20:15:12 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-07 20:15:12 --> Loader Class Initialized
INFO - 2019-09-07 20:15:12 --> Final output sent to browser
DEBUG - 2019-09-07 20:15:12 --> Total execution time: 0.0887
INFO - 2019-09-07 20:15:12 --> Helper loaded: url_helper
INFO - 2019-09-07 20:15:12 --> Helper loaded: html_helper
INFO - 2019-09-07 20:15:12 --> Helper loaded: form_helper
INFO - 2019-09-07 20:15:12 --> Helper loaded: cookie_helper
INFO - 2019-09-07 20:15:12 --> Helper loaded: date_helper
INFO - 2019-09-07 20:15:12 --> Form Validation Class Initialized
INFO - 2019-09-07 20:15:12 --> Email Class Initialized
DEBUG - 2019-09-07 20:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 20:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 20:15:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 20:15:12 --> Pagination Class Initialized
INFO - 2019-09-07 20:15:12 --> Database Driver Class Initialized
INFO - 2019-09-07 20:15:12 --> Database Driver Class Initialized
INFO - 2019-09-07 20:15:12 --> Controller Class Initialized
INFO - 2019-09-07 20:15:12 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-07 20:15:12 --> Final output sent to browser
DEBUG - 2019-09-07 20:15:12 --> Total execution time: 0.0653
INFO - 2019-09-07 20:15:16 --> Config Class Initialized
INFO - 2019-09-07 20:15:16 --> Hooks Class Initialized
DEBUG - 2019-09-07 20:15:16 --> UTF-8 Support Enabled
INFO - 2019-09-07 20:15:16 --> Utf8 Class Initialized
INFO - 2019-09-07 20:15:16 --> URI Class Initialized
INFO - 2019-09-07 20:15:16 --> Router Class Initialized
INFO - 2019-09-07 20:15:16 --> Output Class Initialized
INFO - 2019-09-07 20:15:16 --> Security Class Initialized
DEBUG - 2019-09-07 20:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 20:15:16 --> Input Class Initialized
INFO - 2019-09-07 20:15:16 --> Language Class Initialized
INFO - 2019-09-07 20:15:16 --> Loader Class Initialized
INFO - 2019-09-07 20:15:16 --> Helper loaded: url_helper
INFO - 2019-09-07 20:15:16 --> Helper loaded: html_helper
INFO - 2019-09-07 20:15:16 --> Helper loaded: form_helper
INFO - 2019-09-07 20:15:16 --> Helper loaded: cookie_helper
INFO - 2019-09-07 20:15:16 --> Helper loaded: date_helper
INFO - 2019-09-07 20:15:16 --> Form Validation Class Initialized
INFO - 2019-09-07 20:15:16 --> Email Class Initialized
DEBUG - 2019-09-07 20:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 20:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 20:15:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 20:15:16 --> Pagination Class Initialized
INFO - 2019-09-07 20:15:16 --> Database Driver Class Initialized
INFO - 2019-09-07 20:15:16 --> Database Driver Class Initialized
INFO - 2019-09-07 20:15:16 --> Controller Class Initialized
INFO - 2019-09-07 20:24:56 --> Config Class Initialized
INFO - 2019-09-07 20:24:56 --> Hooks Class Initialized
DEBUG - 2019-09-07 20:24:56 --> UTF-8 Support Enabled
INFO - 2019-09-07 20:24:56 --> Utf8 Class Initialized
INFO - 2019-09-07 20:24:56 --> URI Class Initialized
INFO - 2019-09-07 20:24:56 --> Router Class Initialized
INFO - 2019-09-07 20:24:56 --> Output Class Initialized
INFO - 2019-09-07 20:24:56 --> Security Class Initialized
DEBUG - 2019-09-07 20:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 20:24:56 --> Input Class Initialized
INFO - 2019-09-07 20:24:56 --> Language Class Initialized
INFO - 2019-09-07 20:24:56 --> Loader Class Initialized
INFO - 2019-09-07 20:24:56 --> Helper loaded: url_helper
INFO - 2019-09-07 20:24:56 --> Helper loaded: html_helper
INFO - 2019-09-07 20:24:56 --> Helper loaded: form_helper
INFO - 2019-09-07 20:24:56 --> Helper loaded: cookie_helper
INFO - 2019-09-07 20:24:56 --> Helper loaded: date_helper
INFO - 2019-09-07 20:24:56 --> Form Validation Class Initialized
INFO - 2019-09-07 20:24:56 --> Email Class Initialized
DEBUG - 2019-09-07 20:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 20:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 20:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 20:24:56 --> Pagination Class Initialized
INFO - 2019-09-07 20:24:56 --> Database Driver Class Initialized
INFO - 2019-09-07 20:24:56 --> Database Driver Class Initialized
INFO - 2019-09-07 20:24:56 --> Controller Class Initialized
INFO - 2019-09-07 20:24:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-07 20:24:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-07 20:24:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-07 20:24:56 --> Final output sent to browser
DEBUG - 2019-09-07 20:24:56 --> Total execution time: 0.1205
INFO - 2019-09-07 20:24:56 --> Config Class Initialized
INFO - 2019-09-07 20:24:56 --> Hooks Class Initialized
INFO - 2019-09-07 20:24:56 --> Config Class Initialized
INFO - 2019-09-07 20:24:56 --> Hooks Class Initialized
DEBUG - 2019-09-07 20:24:56 --> UTF-8 Support Enabled
INFO - 2019-09-07 20:24:56 --> Utf8 Class Initialized
INFO - 2019-09-07 20:24:56 --> URI Class Initialized
DEBUG - 2019-09-07 20:24:56 --> UTF-8 Support Enabled
INFO - 2019-09-07 20:24:56 --> Utf8 Class Initialized
INFO - 2019-09-07 20:24:56 --> Router Class Initialized
INFO - 2019-09-07 20:24:56 --> URI Class Initialized
INFO - 2019-09-07 20:24:56 --> Output Class Initialized
INFO - 2019-09-07 20:24:56 --> Router Class Initialized
INFO - 2019-09-07 20:24:56 --> Security Class Initialized
INFO - 2019-09-07 20:24:56 --> Output Class Initialized
DEBUG - 2019-09-07 20:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 20:24:56 --> Input Class Initialized
INFO - 2019-09-07 20:24:56 --> Language Class Initialized
INFO - 2019-09-07 20:24:56 --> Security Class Initialized
DEBUG - 2019-09-07 20:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-07 20:24:56 --> Input Class Initialized
INFO - 2019-09-07 20:24:56 --> Language Class Initialized
INFO - 2019-09-07 20:24:56 --> Loader Class Initialized
INFO - 2019-09-07 20:24:56 --> Helper loaded: url_helper
INFO - 2019-09-07 20:24:56 --> Loader Class Initialized
INFO - 2019-09-07 20:24:56 --> Helper loaded: html_helper
INFO - 2019-09-07 20:24:56 --> Helper loaded: url_helper
INFO - 2019-09-07 20:24:56 --> Helper loaded: form_helper
INFO - 2019-09-07 20:24:56 --> Helper loaded: html_helper
INFO - 2019-09-07 20:24:56 --> Helper loaded: cookie_helper
INFO - 2019-09-07 20:24:56 --> Helper loaded: form_helper
INFO - 2019-09-07 20:24:56 --> Helper loaded: cookie_helper
INFO - 2019-09-07 20:24:56 --> Helper loaded: date_helper
INFO - 2019-09-07 20:24:56 --> Helper loaded: date_helper
INFO - 2019-09-07 20:24:56 --> Form Validation Class Initialized
INFO - 2019-09-07 20:24:56 --> Form Validation Class Initialized
INFO - 2019-09-07 20:24:56 --> Email Class Initialized
INFO - 2019-09-07 20:24:56 --> Email Class Initialized
DEBUG - 2019-09-07 20:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 20:24:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-09-07 20:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-07 20:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 20:24:56 --> Pagination Class Initialized
INFO - 2019-09-07 20:24:56 --> Database Driver Class Initialized
INFO - 2019-09-07 20:24:56 --> Database Driver Class Initialized
INFO - 2019-09-07 20:24:56 --> Controller Class Initialized
INFO - 2019-09-07 20:24:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-07 20:24:56 --> Final output sent to browser
DEBUG - 2019-09-07 20:24:56 --> Total execution time: 0.0756
INFO - 2019-09-07 20:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-07 20:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-07 20:24:56 --> Pagination Class Initialized
INFO - 2019-09-07 20:24:56 --> Database Driver Class Initialized
INFO - 2019-09-07 20:24:56 --> Database Driver Class Initialized
INFO - 2019-09-07 20:24:56 --> Controller Class Initialized
INFO - 2019-09-07 20:24:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-07 20:24:56 --> Final output sent to browser
DEBUG - 2019-09-07 20:24:56 --> Total execution time: 0.1092
