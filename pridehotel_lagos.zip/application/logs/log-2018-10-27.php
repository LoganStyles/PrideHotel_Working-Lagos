<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-27 20:36:06 --> Config Class Initialized
INFO - 2018-10-27 20:36:06 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:36:06 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:36:06 --> Utf8 Class Initialized
INFO - 2018-10-27 20:36:06 --> URI Class Initialized
INFO - 2018-10-27 20:36:06 --> Router Class Initialized
INFO - 2018-10-27 20:36:06 --> Output Class Initialized
INFO - 2018-10-27 20:36:07 --> Security Class Initialized
DEBUG - 2018-10-27 20:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:36:07 --> Input Class Initialized
INFO - 2018-10-27 20:36:07 --> Language Class Initialized
INFO - 2018-10-27 20:36:07 --> Loader Class Initialized
INFO - 2018-10-27 20:36:07 --> Helper loaded: url_helper
INFO - 2018-10-27 20:36:07 --> Helper loaded: html_helper
INFO - 2018-10-27 20:36:07 --> Helper loaded: form_helper
INFO - 2018-10-27 20:36:07 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:36:07 --> Helper loaded: date_helper
INFO - 2018-10-27 20:36:07 --> Form Validation Class Initialized
INFO - 2018-10-27 20:36:07 --> Email Class Initialized
DEBUG - 2018-10-27 20:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:36:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:36:07 --> Pagination Class Initialized
INFO - 2018-10-27 20:36:07 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:07 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:07 --> Controller Class Initialized
INFO - 2018-10-27 20:36:07 --> Config Class Initialized
INFO - 2018-10-27 20:36:07 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:36:07 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:36:07 --> Utf8 Class Initialized
INFO - 2018-10-27 20:36:07 --> URI Class Initialized
INFO - 2018-10-27 20:36:07 --> Router Class Initialized
INFO - 2018-10-27 20:36:07 --> Output Class Initialized
INFO - 2018-10-27 20:36:07 --> Security Class Initialized
DEBUG - 2018-10-27 20:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:36:07 --> Input Class Initialized
INFO - 2018-10-27 20:36:07 --> Language Class Initialized
INFO - 2018-10-27 20:36:07 --> Loader Class Initialized
INFO - 2018-10-27 20:36:07 --> Helper loaded: url_helper
INFO - 2018-10-27 20:36:07 --> Helper loaded: html_helper
INFO - 2018-10-27 20:36:07 --> Helper loaded: form_helper
INFO - 2018-10-27 20:36:07 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:36:07 --> Helper loaded: date_helper
INFO - 2018-10-27 20:36:07 --> Form Validation Class Initialized
INFO - 2018-10-27 20:36:07 --> Email Class Initialized
DEBUG - 2018-10-27 20:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:36:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:36:07 --> Pagination Class Initialized
INFO - 2018-10-27 20:36:07 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:07 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:07 --> Controller Class Initialized
INFO - 2018-10-27 20:36:07 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-10-27 20:36:07 --> Final output sent to browser
DEBUG - 2018-10-27 20:36:07 --> Total execution time: 0.1016
INFO - 2018-10-27 20:36:07 --> Config Class Initialized
INFO - 2018-10-27 20:36:07 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:36:07 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:36:07 --> Utf8 Class Initialized
INFO - 2018-10-27 20:36:07 --> URI Class Initialized
INFO - 2018-10-27 20:36:07 --> Router Class Initialized
INFO - 2018-10-27 20:36:07 --> Output Class Initialized
INFO - 2018-10-27 20:36:07 --> Security Class Initialized
DEBUG - 2018-10-27 20:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:36:07 --> Input Class Initialized
INFO - 2018-10-27 20:36:07 --> Language Class Initialized
INFO - 2018-10-27 20:36:07 --> Loader Class Initialized
INFO - 2018-10-27 20:36:07 --> Helper loaded: url_helper
INFO - 2018-10-27 20:36:07 --> Helper loaded: html_helper
INFO - 2018-10-27 20:36:07 --> Helper loaded: form_helper
INFO - 2018-10-27 20:36:07 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:36:07 --> Helper loaded: date_helper
INFO - 2018-10-27 20:36:07 --> Form Validation Class Initialized
INFO - 2018-10-27 20:36:07 --> Email Class Initialized
DEBUG - 2018-10-27 20:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:36:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:36:07 --> Pagination Class Initialized
INFO - 2018-10-27 20:36:07 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:07 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:07 --> Controller Class Initialized
INFO - 2018-10-27 20:36:07 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-10-27 20:36:07 --> Final output sent to browser
DEBUG - 2018-10-27 20:36:07 --> Total execution time: 0.1138
INFO - 2018-10-27 20:36:20 --> Config Class Initialized
INFO - 2018-10-27 20:36:20 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:36:20 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:36:20 --> Utf8 Class Initialized
INFO - 2018-10-27 20:36:20 --> URI Class Initialized
INFO - 2018-10-27 20:36:20 --> Router Class Initialized
INFO - 2018-10-27 20:36:20 --> Output Class Initialized
INFO - 2018-10-27 20:36:20 --> Security Class Initialized
DEBUG - 2018-10-27 20:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:36:20 --> Input Class Initialized
INFO - 2018-10-27 20:36:20 --> Language Class Initialized
INFO - 2018-10-27 20:36:20 --> Loader Class Initialized
INFO - 2018-10-27 20:36:20 --> Helper loaded: url_helper
INFO - 2018-10-27 20:36:20 --> Helper loaded: html_helper
INFO - 2018-10-27 20:36:20 --> Helper loaded: form_helper
INFO - 2018-10-27 20:36:20 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:36:20 --> Helper loaded: date_helper
INFO - 2018-10-27 20:36:20 --> Form Validation Class Initialized
INFO - 2018-10-27 20:36:20 --> Email Class Initialized
DEBUG - 2018-10-27 20:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:36:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:36:20 --> Pagination Class Initialized
INFO - 2018-10-27 20:36:20 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:20 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:20 --> Controller Class Initialized
INFO - 2018-10-27 20:36:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 20:36:20 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-10-27 20:36:20 --> Final output sent to browser
DEBUG - 2018-10-27 20:36:20 --> Total execution time: 0.1155
INFO - 2018-10-27 20:36:34 --> Config Class Initialized
INFO - 2018-10-27 20:36:34 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:36:34 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:36:34 --> Utf8 Class Initialized
INFO - 2018-10-27 20:36:34 --> URI Class Initialized
INFO - 2018-10-27 20:36:34 --> Router Class Initialized
INFO - 2018-10-27 20:36:34 --> Output Class Initialized
INFO - 2018-10-27 20:36:34 --> Security Class Initialized
DEBUG - 2018-10-27 20:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:36:34 --> Input Class Initialized
INFO - 2018-10-27 20:36:34 --> Language Class Initialized
INFO - 2018-10-27 20:36:34 --> Loader Class Initialized
INFO - 2018-10-27 20:36:34 --> Helper loaded: url_helper
INFO - 2018-10-27 20:36:34 --> Helper loaded: html_helper
INFO - 2018-10-27 20:36:34 --> Helper loaded: form_helper
INFO - 2018-10-27 20:36:34 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:36:34 --> Helper loaded: date_helper
INFO - 2018-10-27 20:36:34 --> Form Validation Class Initialized
INFO - 2018-10-27 20:36:34 --> Email Class Initialized
DEBUG - 2018-10-27 20:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:36:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:36:34 --> Pagination Class Initialized
INFO - 2018-10-27 20:36:34 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:34 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:34 --> Controller Class Initialized
INFO - 2018-10-27 20:36:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 20:36:34 --> Config Class Initialized
INFO - 2018-10-27 20:36:34 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:36:34 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:36:34 --> Utf8 Class Initialized
INFO - 2018-10-27 20:36:34 --> URI Class Initialized
INFO - 2018-10-27 20:36:34 --> Router Class Initialized
INFO - 2018-10-27 20:36:34 --> Output Class Initialized
INFO - 2018-10-27 20:36:34 --> Security Class Initialized
DEBUG - 2018-10-27 20:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:36:34 --> Input Class Initialized
INFO - 2018-10-27 20:36:34 --> Language Class Initialized
INFO - 2018-10-27 20:36:34 --> Loader Class Initialized
INFO - 2018-10-27 20:36:34 --> Helper loaded: url_helper
INFO - 2018-10-27 20:36:34 --> Helper loaded: html_helper
INFO - 2018-10-27 20:36:34 --> Helper loaded: form_helper
INFO - 2018-10-27 20:36:34 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:36:34 --> Helper loaded: date_helper
INFO - 2018-10-27 20:36:34 --> Form Validation Class Initialized
INFO - 2018-10-27 20:36:34 --> Email Class Initialized
DEBUG - 2018-10-27 20:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:36:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:36:34 --> Pagination Class Initialized
INFO - 2018-10-27 20:36:34 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:34 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:34 --> Controller Class Initialized
INFO - 2018-10-27 20:36:34 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-10-27 20:36:34 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-10-27 20:36:34 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-10-27 20:36:34 --> Final output sent to browser
DEBUG - 2018-10-27 20:36:34 --> Total execution time: 0.1772
INFO - 2018-10-27 20:36:34 --> Config Class Initialized
INFO - 2018-10-27 20:36:34 --> Config Class Initialized
INFO - 2018-10-27 20:36:34 --> Hooks Class Initialized
INFO - 2018-10-27 20:36:34 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:36:34 --> UTF-8 Support Enabled
DEBUG - 2018-10-27 20:36:34 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:36:34 --> Utf8 Class Initialized
INFO - 2018-10-27 20:36:34 --> Utf8 Class Initialized
INFO - 2018-10-27 20:36:34 --> URI Class Initialized
INFO - 2018-10-27 20:36:34 --> URI Class Initialized
INFO - 2018-10-27 20:36:34 --> Router Class Initialized
INFO - 2018-10-27 20:36:34 --> Router Class Initialized
INFO - 2018-10-27 20:36:34 --> Output Class Initialized
INFO - 2018-10-27 20:36:34 --> Output Class Initialized
INFO - 2018-10-27 20:36:34 --> Security Class Initialized
INFO - 2018-10-27 20:36:34 --> Security Class Initialized
DEBUG - 2018-10-27 20:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:36:34 --> Input Class Initialized
DEBUG - 2018-10-27 20:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:36:34 --> Input Class Initialized
INFO - 2018-10-27 20:36:34 --> Language Class Initialized
INFO - 2018-10-27 20:36:34 --> Language Class Initialized
INFO - 2018-10-27 20:36:34 --> Loader Class Initialized
INFO - 2018-10-27 20:36:34 --> Loader Class Initialized
INFO - 2018-10-27 20:36:34 --> Helper loaded: url_helper
INFO - 2018-10-27 20:36:34 --> Helper loaded: url_helper
INFO - 2018-10-27 20:36:34 --> Helper loaded: html_helper
INFO - 2018-10-27 20:36:34 --> Helper loaded: html_helper
INFO - 2018-10-27 20:36:34 --> Helper loaded: form_helper
INFO - 2018-10-27 20:36:34 --> Helper loaded: form_helper
INFO - 2018-10-27 20:36:34 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:36:34 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:36:34 --> Helper loaded: date_helper
INFO - 2018-10-27 20:36:34 --> Helper loaded: date_helper
INFO - 2018-10-27 20:36:34 --> Form Validation Class Initialized
INFO - 2018-10-27 20:36:34 --> Form Validation Class Initialized
INFO - 2018-10-27 20:36:34 --> Email Class Initialized
INFO - 2018-10-27 20:36:34 --> Email Class Initialized
DEBUG - 2018-10-27 20:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-10-27 20:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:36:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:36:34 --> Pagination Class Initialized
INFO - 2018-10-27 20:36:34 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:34 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:34 --> Controller Class Initialized
INFO - 2018-10-27 20:36:34 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:36:34 --> Final output sent to browser
DEBUG - 2018-10-27 20:36:34 --> Total execution time: 0.1531
INFO - 2018-10-27 20:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:36:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:36:34 --> Pagination Class Initialized
INFO - 2018-10-27 20:36:34 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:34 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:34 --> Controller Class Initialized
INFO - 2018-10-27 20:36:34 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:36:34 --> Final output sent to browser
DEBUG - 2018-10-27 20:36:34 --> Total execution time: 0.2079
INFO - 2018-10-27 20:36:35 --> Config Class Initialized
INFO - 2018-10-27 20:36:35 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:36:35 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:36:35 --> Utf8 Class Initialized
INFO - 2018-10-27 20:36:35 --> URI Class Initialized
INFO - 2018-10-27 20:36:35 --> Router Class Initialized
INFO - 2018-10-27 20:36:35 --> Output Class Initialized
INFO - 2018-10-27 20:36:35 --> Security Class Initialized
DEBUG - 2018-10-27 20:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:36:35 --> Input Class Initialized
INFO - 2018-10-27 20:36:35 --> Language Class Initialized
INFO - 2018-10-27 20:36:35 --> Loader Class Initialized
INFO - 2018-10-27 20:36:35 --> Helper loaded: url_helper
INFO - 2018-10-27 20:36:35 --> Helper loaded: html_helper
INFO - 2018-10-27 20:36:35 --> Helper loaded: form_helper
INFO - 2018-10-27 20:36:35 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:36:35 --> Helper loaded: date_helper
INFO - 2018-10-27 20:36:35 --> Form Validation Class Initialized
INFO - 2018-10-27 20:36:35 --> Email Class Initialized
DEBUG - 2018-10-27 20:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:36:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:36:35 --> Pagination Class Initialized
INFO - 2018-10-27 20:36:35 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:35 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:35 --> Controller Class Initialized
INFO - 2018-10-27 20:36:35 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:36:35 --> Final output sent to browser
DEBUG - 2018-10-27 20:36:35 --> Total execution time: 0.1493
INFO - 2018-10-27 20:36:36 --> Config Class Initialized
INFO - 2018-10-27 20:36:36 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:36:36 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:36:36 --> Utf8 Class Initialized
INFO - 2018-10-27 20:36:36 --> URI Class Initialized
INFO - 2018-10-27 20:36:36 --> Router Class Initialized
INFO - 2018-10-27 20:36:36 --> Output Class Initialized
INFO - 2018-10-27 20:36:36 --> Security Class Initialized
DEBUG - 2018-10-27 20:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:36:36 --> Input Class Initialized
INFO - 2018-10-27 20:36:36 --> Language Class Initialized
INFO - 2018-10-27 20:36:36 --> Loader Class Initialized
INFO - 2018-10-27 20:36:36 --> Helper loaded: url_helper
INFO - 2018-10-27 20:36:36 --> Helper loaded: html_helper
INFO - 2018-10-27 20:36:36 --> Helper loaded: form_helper
INFO - 2018-10-27 20:36:36 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:36:36 --> Helper loaded: date_helper
INFO - 2018-10-27 20:36:36 --> Form Validation Class Initialized
INFO - 2018-10-27 20:36:36 --> Email Class Initialized
DEBUG - 2018-10-27 20:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:36:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:36:36 --> Pagination Class Initialized
INFO - 2018-10-27 20:36:36 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:36 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:36 --> Controller Class Initialized
INFO - 2018-10-27 20:36:36 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-10-27 20:36:36 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/nightaudit.php
INFO - 2018-10-27 20:36:36 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-10-27 20:36:36 --> Final output sent to browser
DEBUG - 2018-10-27 20:36:36 --> Total execution time: 0.1151
INFO - 2018-10-27 20:36:36 --> Config Class Initialized
INFO - 2018-10-27 20:36:36 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:36:36 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:36:36 --> Utf8 Class Initialized
INFO - 2018-10-27 20:36:36 --> URI Class Initialized
INFO - 2018-10-27 20:36:36 --> Router Class Initialized
INFO - 2018-10-27 20:36:36 --> Output Class Initialized
INFO - 2018-10-27 20:36:36 --> Security Class Initialized
DEBUG - 2018-10-27 20:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:36:36 --> Input Class Initialized
INFO - 2018-10-27 20:36:36 --> Language Class Initialized
INFO - 2018-10-27 20:36:36 --> Loader Class Initialized
INFO - 2018-10-27 20:36:36 --> Helper loaded: url_helper
INFO - 2018-10-27 20:36:36 --> Helper loaded: html_helper
INFO - 2018-10-27 20:36:36 --> Helper loaded: form_helper
INFO - 2018-10-27 20:36:36 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:36:36 --> Helper loaded: date_helper
INFO - 2018-10-27 20:36:36 --> Form Validation Class Initialized
INFO - 2018-10-27 20:36:36 --> Email Class Initialized
DEBUG - 2018-10-27 20:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:36:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:36:36 --> Pagination Class Initialized
INFO - 2018-10-27 20:36:36 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:36 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:36 --> Controller Class Initialized
INFO - 2018-10-27 20:36:36 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:36:36 --> Final output sent to browser
DEBUG - 2018-10-27 20:36:36 --> Total execution time: 0.1792
INFO - 2018-10-27 20:36:43 --> Config Class Initialized
INFO - 2018-10-27 20:36:43 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:36:43 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:36:43 --> Utf8 Class Initialized
INFO - 2018-10-27 20:36:43 --> URI Class Initialized
INFO - 2018-10-27 20:36:43 --> Router Class Initialized
INFO - 2018-10-27 20:36:43 --> Output Class Initialized
INFO - 2018-10-27 20:36:43 --> Security Class Initialized
DEBUG - 2018-10-27 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:36:43 --> Input Class Initialized
INFO - 2018-10-27 20:36:43 --> Language Class Initialized
INFO - 2018-10-27 20:36:43 --> Loader Class Initialized
INFO - 2018-10-27 20:36:43 --> Helper loaded: url_helper
INFO - 2018-10-27 20:36:43 --> Helper loaded: html_helper
INFO - 2018-10-27 20:36:43 --> Helper loaded: form_helper
INFO - 2018-10-27 20:36:43 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:36:43 --> Helper loaded: date_helper
INFO - 2018-10-27 20:36:43 --> Form Validation Class Initialized
INFO - 2018-10-27 20:36:43 --> Email Class Initialized
DEBUG - 2018-10-27 20:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:36:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:36:43 --> Pagination Class Initialized
INFO - 2018-10-27 20:36:43 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:43 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:43 --> Controller Class Initialized
INFO - 2018-10-27 20:36:44 --> Final output sent to browser
DEBUG - 2018-10-27 20:36:44 --> Total execution time: 0.9546
INFO - 2018-10-27 20:36:46 --> Config Class Initialized
INFO - 2018-10-27 20:36:46 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:36:46 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:36:46 --> Utf8 Class Initialized
INFO - 2018-10-27 20:36:46 --> URI Class Initialized
INFO - 2018-10-27 20:36:46 --> Router Class Initialized
INFO - 2018-10-27 20:36:46 --> Output Class Initialized
INFO - 2018-10-27 20:36:46 --> Security Class Initialized
DEBUG - 2018-10-27 20:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:36:46 --> Input Class Initialized
INFO - 2018-10-27 20:36:46 --> Language Class Initialized
INFO - 2018-10-27 20:36:46 --> Loader Class Initialized
INFO - 2018-10-27 20:36:46 --> Helper loaded: url_helper
INFO - 2018-10-27 20:36:46 --> Helper loaded: html_helper
INFO - 2018-10-27 20:36:46 --> Helper loaded: form_helper
INFO - 2018-10-27 20:36:46 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:36:46 --> Helper loaded: date_helper
INFO - 2018-10-27 20:36:46 --> Form Validation Class Initialized
INFO - 2018-10-27 20:36:46 --> Email Class Initialized
DEBUG - 2018-10-27 20:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:36:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:36:46 --> Pagination Class Initialized
INFO - 2018-10-27 20:36:46 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:46 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:46 --> Controller Class Initialized
INFO - 2018-10-27 20:36:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-10-27 20:36:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/nightaudit.php
INFO - 2018-10-27 20:36:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-10-27 20:36:46 --> Final output sent to browser
DEBUG - 2018-10-27 20:36:46 --> Total execution time: 0.1242
INFO - 2018-10-27 20:36:46 --> Config Class Initialized
INFO - 2018-10-27 20:36:46 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:36:46 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:36:46 --> Utf8 Class Initialized
INFO - 2018-10-27 20:36:46 --> URI Class Initialized
INFO - 2018-10-27 20:36:46 --> Router Class Initialized
INFO - 2018-10-27 20:36:46 --> Output Class Initialized
INFO - 2018-10-27 20:36:46 --> Security Class Initialized
DEBUG - 2018-10-27 20:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:36:46 --> Input Class Initialized
INFO - 2018-10-27 20:36:46 --> Language Class Initialized
INFO - 2018-10-27 20:36:46 --> Loader Class Initialized
INFO - 2018-10-27 20:36:46 --> Helper loaded: url_helper
INFO - 2018-10-27 20:36:46 --> Helper loaded: html_helper
INFO - 2018-10-27 20:36:46 --> Helper loaded: form_helper
INFO - 2018-10-27 20:36:46 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:36:46 --> Helper loaded: date_helper
INFO - 2018-10-27 20:36:46 --> Form Validation Class Initialized
INFO - 2018-10-27 20:36:46 --> Email Class Initialized
DEBUG - 2018-10-27 20:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:36:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:36:46 --> Pagination Class Initialized
INFO - 2018-10-27 20:36:46 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:46 --> Database Driver Class Initialized
INFO - 2018-10-27 20:36:46 --> Controller Class Initialized
INFO - 2018-10-27 20:36:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:36:46 --> Final output sent to browser
DEBUG - 2018-10-27 20:36:46 --> Total execution time: 0.1854
INFO - 2018-10-27 20:55:39 --> Config Class Initialized
INFO - 2018-10-27 20:55:39 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:55:39 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:55:39 --> Utf8 Class Initialized
INFO - 2018-10-27 20:55:39 --> URI Class Initialized
INFO - 2018-10-27 20:55:39 --> Router Class Initialized
INFO - 2018-10-27 20:55:39 --> Output Class Initialized
INFO - 2018-10-27 20:55:39 --> Security Class Initialized
DEBUG - 2018-10-27 20:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:55:39 --> Input Class Initialized
INFO - 2018-10-27 20:55:39 --> Language Class Initialized
INFO - 2018-10-27 20:55:39 --> Loader Class Initialized
INFO - 2018-10-27 20:55:39 --> Helper loaded: url_helper
INFO - 2018-10-27 20:55:39 --> Helper loaded: html_helper
INFO - 2018-10-27 20:55:39 --> Helper loaded: form_helper
INFO - 2018-10-27 20:55:39 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:55:39 --> Helper loaded: date_helper
INFO - 2018-10-27 20:55:39 --> Form Validation Class Initialized
INFO - 2018-10-27 20:55:39 --> Email Class Initialized
DEBUG - 2018-10-27 20:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:55:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:55:40 --> Pagination Class Initialized
INFO - 2018-10-27 20:55:40 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:40 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:40 --> Controller Class Initialized
INFO - 2018-10-27 20:55:40 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:55:40 --> Final output sent to browser
DEBUG - 2018-10-27 20:55:40 --> Total execution time: 0.1323
INFO - 2018-10-27 20:55:41 --> Config Class Initialized
INFO - 2018-10-27 20:55:41 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:55:41 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:55:41 --> Utf8 Class Initialized
INFO - 2018-10-27 20:55:41 --> URI Class Initialized
INFO - 2018-10-27 20:55:41 --> Router Class Initialized
INFO - 2018-10-27 20:55:41 --> Output Class Initialized
INFO - 2018-10-27 20:55:41 --> Security Class Initialized
DEBUG - 2018-10-27 20:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:55:41 --> Input Class Initialized
INFO - 2018-10-27 20:55:41 --> Language Class Initialized
INFO - 2018-10-27 20:55:41 --> Loader Class Initialized
INFO - 2018-10-27 20:55:41 --> Helper loaded: url_helper
INFO - 2018-10-27 20:55:41 --> Helper loaded: html_helper
INFO - 2018-10-27 20:55:41 --> Helper loaded: form_helper
INFO - 2018-10-27 20:55:41 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:55:41 --> Helper loaded: date_helper
INFO - 2018-10-27 20:55:41 --> Form Validation Class Initialized
INFO - 2018-10-27 20:55:41 --> Email Class Initialized
DEBUG - 2018-10-27 20:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:55:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:55:41 --> Pagination Class Initialized
INFO - 2018-10-27 20:55:41 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:41 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:41 --> Controller Class Initialized
INFO - 2018-10-27 20:55:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-10-27 20:55:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/nightaudit.php
INFO - 2018-10-27 20:55:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-10-27 20:55:41 --> Final output sent to browser
DEBUG - 2018-10-27 20:55:41 --> Total execution time: 0.1504
INFO - 2018-10-27 20:55:41 --> Config Class Initialized
INFO - 2018-10-27 20:55:41 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:55:41 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:55:41 --> Utf8 Class Initialized
INFO - 2018-10-27 20:55:41 --> URI Class Initialized
INFO - 2018-10-27 20:55:41 --> Router Class Initialized
INFO - 2018-10-27 20:55:41 --> Output Class Initialized
INFO - 2018-10-27 20:55:41 --> Security Class Initialized
DEBUG - 2018-10-27 20:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:55:41 --> Input Class Initialized
INFO - 2018-10-27 20:55:41 --> Language Class Initialized
INFO - 2018-10-27 20:55:41 --> Loader Class Initialized
INFO - 2018-10-27 20:55:41 --> Helper loaded: url_helper
INFO - 2018-10-27 20:55:41 --> Helper loaded: html_helper
INFO - 2018-10-27 20:55:41 --> Helper loaded: form_helper
INFO - 2018-10-27 20:55:41 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:55:41 --> Helper loaded: date_helper
INFO - 2018-10-27 20:55:41 --> Form Validation Class Initialized
INFO - 2018-10-27 20:55:41 --> Email Class Initialized
DEBUG - 2018-10-27 20:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:55:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:55:41 --> Pagination Class Initialized
INFO - 2018-10-27 20:55:41 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:41 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:41 --> Controller Class Initialized
INFO - 2018-10-27 20:55:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:55:41 --> Final output sent to browser
DEBUG - 2018-10-27 20:55:41 --> Total execution time: 0.1664
INFO - 2018-10-27 20:55:51 --> Config Class Initialized
INFO - 2018-10-27 20:55:51 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:55:51 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:55:51 --> Utf8 Class Initialized
INFO - 2018-10-27 20:55:51 --> URI Class Initialized
INFO - 2018-10-27 20:55:51 --> Router Class Initialized
INFO - 2018-10-27 20:55:51 --> Output Class Initialized
INFO - 2018-10-27 20:55:51 --> Security Class Initialized
DEBUG - 2018-10-27 20:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:55:51 --> Input Class Initialized
INFO - 2018-10-27 20:55:51 --> Language Class Initialized
INFO - 2018-10-27 20:55:51 --> Loader Class Initialized
INFO - 2018-10-27 20:55:51 --> Helper loaded: url_helper
INFO - 2018-10-27 20:55:51 --> Helper loaded: html_helper
INFO - 2018-10-27 20:55:51 --> Helper loaded: form_helper
INFO - 2018-10-27 20:55:51 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:55:51 --> Helper loaded: date_helper
INFO - 2018-10-27 20:55:51 --> Form Validation Class Initialized
INFO - 2018-10-27 20:55:51 --> Email Class Initialized
DEBUG - 2018-10-27 20:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:55:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:55:51 --> Pagination Class Initialized
INFO - 2018-10-27 20:55:51 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:51 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:51 --> Controller Class Initialized
INFO - 2018-10-27 20:55:51 --> Final output sent to browser
DEBUG - 2018-10-27 20:55:51 --> Total execution time: 0.8310
INFO - 2018-10-27 20:55:54 --> Config Class Initialized
INFO - 2018-10-27 20:55:54 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:55:54 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:55:54 --> Utf8 Class Initialized
INFO - 2018-10-27 20:55:54 --> URI Class Initialized
INFO - 2018-10-27 20:55:54 --> Router Class Initialized
INFO - 2018-10-27 20:55:54 --> Output Class Initialized
INFO - 2018-10-27 20:55:54 --> Security Class Initialized
DEBUG - 2018-10-27 20:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:55:54 --> Input Class Initialized
INFO - 2018-10-27 20:55:54 --> Language Class Initialized
INFO - 2018-10-27 20:55:54 --> Loader Class Initialized
INFO - 2018-10-27 20:55:54 --> Helper loaded: url_helper
INFO - 2018-10-27 20:55:54 --> Helper loaded: html_helper
INFO - 2018-10-27 20:55:54 --> Helper loaded: form_helper
INFO - 2018-10-27 20:55:54 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:55:54 --> Helper loaded: date_helper
INFO - 2018-10-27 20:55:54 --> Form Validation Class Initialized
INFO - 2018-10-27 20:55:54 --> Email Class Initialized
DEBUG - 2018-10-27 20:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:55:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:55:54 --> Pagination Class Initialized
INFO - 2018-10-27 20:55:54 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:54 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:54 --> Controller Class Initialized
INFO - 2018-10-27 20:55:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-10-27 20:55:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/nightaudit.php
INFO - 2018-10-27 20:55:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-10-27 20:55:54 --> Final output sent to browser
DEBUG - 2018-10-27 20:55:54 --> Total execution time: 0.1152
INFO - 2018-10-27 20:55:54 --> Config Class Initialized
INFO - 2018-10-27 20:55:54 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:55:54 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:55:54 --> Utf8 Class Initialized
INFO - 2018-10-27 20:55:54 --> URI Class Initialized
INFO - 2018-10-27 20:55:54 --> Router Class Initialized
INFO - 2018-10-27 20:55:54 --> Output Class Initialized
INFO - 2018-10-27 20:55:54 --> Security Class Initialized
DEBUG - 2018-10-27 20:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:55:54 --> Input Class Initialized
INFO - 2018-10-27 20:55:54 --> Language Class Initialized
INFO - 2018-10-27 20:55:54 --> Loader Class Initialized
INFO - 2018-10-27 20:55:54 --> Helper loaded: url_helper
INFO - 2018-10-27 20:55:54 --> Helper loaded: html_helper
INFO - 2018-10-27 20:55:54 --> Helper loaded: form_helper
INFO - 2018-10-27 20:55:54 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:55:54 --> Helper loaded: date_helper
INFO - 2018-10-27 20:55:54 --> Form Validation Class Initialized
INFO - 2018-10-27 20:55:54 --> Email Class Initialized
DEBUG - 2018-10-27 20:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:55:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:55:54 --> Pagination Class Initialized
INFO - 2018-10-27 20:55:54 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:54 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:54 --> Controller Class Initialized
INFO - 2018-10-27 20:55:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:55:54 --> Final output sent to browser
DEBUG - 2018-10-27 20:55:54 --> Total execution time: 0.1747
INFO - 2018-10-27 20:55:58 --> Config Class Initialized
INFO - 2018-10-27 20:55:58 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:55:58 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:55:58 --> Utf8 Class Initialized
INFO - 2018-10-27 20:55:58 --> URI Class Initialized
INFO - 2018-10-27 20:55:58 --> Router Class Initialized
INFO - 2018-10-27 20:55:58 --> Output Class Initialized
INFO - 2018-10-27 20:55:58 --> Security Class Initialized
DEBUG - 2018-10-27 20:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:55:58 --> Input Class Initialized
INFO - 2018-10-27 20:55:58 --> Language Class Initialized
INFO - 2018-10-27 20:55:58 --> Loader Class Initialized
INFO - 2018-10-27 20:55:58 --> Helper loaded: url_helper
INFO - 2018-10-27 20:55:58 --> Helper loaded: html_helper
INFO - 2018-10-27 20:55:58 --> Helper loaded: form_helper
INFO - 2018-10-27 20:55:58 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:55:58 --> Helper loaded: date_helper
INFO - 2018-10-27 20:55:58 --> Form Validation Class Initialized
INFO - 2018-10-27 20:55:58 --> Email Class Initialized
DEBUG - 2018-10-27 20:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:55:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:55:58 --> Pagination Class Initialized
INFO - 2018-10-27 20:55:58 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:58 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:58 --> Controller Class Initialized
INFO - 2018-10-27 20:55:58 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:55:58 --> Final output sent to browser
DEBUG - 2018-10-27 20:55:58 --> Total execution time: 0.1140
INFO - 2018-10-27 20:55:58 --> Config Class Initialized
INFO - 2018-10-27 20:55:58 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:55:58 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:55:58 --> Utf8 Class Initialized
INFO - 2018-10-27 20:55:58 --> URI Class Initialized
INFO - 2018-10-27 20:55:58 --> Router Class Initialized
INFO - 2018-10-27 20:55:58 --> Output Class Initialized
INFO - 2018-10-27 20:55:58 --> Security Class Initialized
DEBUG - 2018-10-27 20:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:55:58 --> Input Class Initialized
INFO - 2018-10-27 20:55:58 --> Language Class Initialized
INFO - 2018-10-27 20:55:58 --> Loader Class Initialized
INFO - 2018-10-27 20:55:58 --> Helper loaded: url_helper
INFO - 2018-10-27 20:55:58 --> Helper loaded: html_helper
INFO - 2018-10-27 20:55:58 --> Helper loaded: form_helper
INFO - 2018-10-27 20:55:58 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:55:58 --> Helper loaded: date_helper
INFO - 2018-10-27 20:55:58 --> Form Validation Class Initialized
INFO - 2018-10-27 20:55:58 --> Email Class Initialized
DEBUG - 2018-10-27 20:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:55:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:55:58 --> Pagination Class Initialized
INFO - 2018-10-27 20:55:58 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:58 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:58 --> Controller Class Initialized
INFO - 2018-10-27 20:55:58 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:55:58 --> Final output sent to browser
DEBUG - 2018-10-27 20:55:58 --> Total execution time: 0.1065
INFO - 2018-10-27 20:55:59 --> Config Class Initialized
INFO - 2018-10-27 20:55:59 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:55:59 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:55:59 --> Utf8 Class Initialized
INFO - 2018-10-27 20:55:59 --> URI Class Initialized
INFO - 2018-10-27 20:55:59 --> Router Class Initialized
INFO - 2018-10-27 20:55:59 --> Output Class Initialized
INFO - 2018-10-27 20:55:59 --> Security Class Initialized
DEBUG - 2018-10-27 20:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:55:59 --> Input Class Initialized
INFO - 2018-10-27 20:55:59 --> Language Class Initialized
INFO - 2018-10-27 20:55:59 --> Loader Class Initialized
INFO - 2018-10-27 20:55:59 --> Helper loaded: url_helper
INFO - 2018-10-27 20:55:59 --> Helper loaded: html_helper
INFO - 2018-10-27 20:55:59 --> Helper loaded: form_helper
INFO - 2018-10-27 20:55:59 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:55:59 --> Helper loaded: date_helper
INFO - 2018-10-27 20:55:59 --> Form Validation Class Initialized
INFO - 2018-10-27 20:55:59 --> Email Class Initialized
DEBUG - 2018-10-27 20:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:55:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:55:59 --> Pagination Class Initialized
INFO - 2018-10-27 20:55:59 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:59 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:59 --> Controller Class Initialized
INFO - 2018-10-27 20:55:59 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:55:59 --> Final output sent to browser
DEBUG - 2018-10-27 20:55:59 --> Total execution time: 0.1027
INFO - 2018-10-27 20:55:59 --> Config Class Initialized
INFO - 2018-10-27 20:55:59 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:55:59 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:55:59 --> Utf8 Class Initialized
INFO - 2018-10-27 20:55:59 --> URI Class Initialized
INFO - 2018-10-27 20:55:59 --> Router Class Initialized
INFO - 2018-10-27 20:55:59 --> Output Class Initialized
INFO - 2018-10-27 20:55:59 --> Security Class Initialized
DEBUG - 2018-10-27 20:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:55:59 --> Input Class Initialized
INFO - 2018-10-27 20:55:59 --> Language Class Initialized
INFO - 2018-10-27 20:55:59 --> Loader Class Initialized
INFO - 2018-10-27 20:55:59 --> Helper loaded: url_helper
INFO - 2018-10-27 20:55:59 --> Helper loaded: html_helper
INFO - 2018-10-27 20:55:59 --> Helper loaded: form_helper
INFO - 2018-10-27 20:55:59 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:55:59 --> Helper loaded: date_helper
INFO - 2018-10-27 20:55:59 --> Form Validation Class Initialized
INFO - 2018-10-27 20:55:59 --> Email Class Initialized
DEBUG - 2018-10-27 20:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:55:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:55:59 --> Pagination Class Initialized
INFO - 2018-10-27 20:55:59 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:59 --> Database Driver Class Initialized
INFO - 2018-10-27 20:55:59 --> Controller Class Initialized
INFO - 2018-10-27 20:55:59 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-10-27 20:55:59 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-10-27 20:55:59 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-10-27 20:55:59 --> Final output sent to browser
DEBUG - 2018-10-27 20:55:59 --> Total execution time: 0.1215
INFO - 2018-10-27 20:55:59 --> Config Class Initialized
INFO - 2018-10-27 20:55:59 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:55:59 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:55:59 --> Utf8 Class Initialized
INFO - 2018-10-27 20:55:59 --> URI Class Initialized
INFO - 2018-10-27 20:55:59 --> Config Class Initialized
INFO - 2018-10-27 20:55:59 --> Hooks Class Initialized
INFO - 2018-10-27 20:55:59 --> Router Class Initialized
DEBUG - 2018-10-27 20:55:59 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:55:59 --> Output Class Initialized
INFO - 2018-10-27 20:55:59 --> Utf8 Class Initialized
INFO - 2018-10-27 20:55:59 --> Security Class Initialized
INFO - 2018-10-27 20:55:59 --> URI Class Initialized
DEBUG - 2018-10-27 20:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:55:59 --> Router Class Initialized
INFO - 2018-10-27 20:55:59 --> Input Class Initialized
INFO - 2018-10-27 20:55:59 --> Language Class Initialized
INFO - 2018-10-27 20:55:59 --> Output Class Initialized
INFO - 2018-10-27 20:55:59 --> Security Class Initialized
INFO - 2018-10-27 20:55:59 --> Loader Class Initialized
DEBUG - 2018-10-27 20:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:55:59 --> Helper loaded: url_helper
INFO - 2018-10-27 20:55:59 --> Input Class Initialized
INFO - 2018-10-27 20:55:59 --> Language Class Initialized
INFO - 2018-10-27 20:55:59 --> Helper loaded: html_helper
INFO - 2018-10-27 20:55:59 --> Helper loaded: form_helper
INFO - 2018-10-27 20:55:59 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:55:59 --> Loader Class Initialized
INFO - 2018-10-27 20:55:59 --> Helper loaded: date_helper
INFO - 2018-10-27 20:55:59 --> Helper loaded: url_helper
INFO - 2018-10-27 20:55:59 --> Form Validation Class Initialized
INFO - 2018-10-27 20:55:59 --> Helper loaded: html_helper
INFO - 2018-10-27 20:55:59 --> Email Class Initialized
INFO - 2018-10-27 20:55:59 --> Helper loaded: form_helper
INFO - 2018-10-27 20:55:59 --> Helper loaded: cookie_helper
DEBUG - 2018-10-27 20:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:55:59 --> Helper loaded: date_helper
INFO - 2018-10-27 20:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:55:59 --> Form Validation Class Initialized
INFO - 2018-10-27 20:55:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:55:59 --> Pagination Class Initialized
INFO - 2018-10-27 20:55:59 --> Email Class Initialized
DEBUG - 2018-10-27 20:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:55:59 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:00 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:00 --> Controller Class Initialized
INFO - 2018-10-27 20:56:00 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:56:00 --> Final output sent to browser
DEBUG - 2018-10-27 20:56:00 --> Total execution time: 0.1736
INFO - 2018-10-27 20:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:56:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:56:00 --> Pagination Class Initialized
INFO - 2018-10-27 20:56:00 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:00 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:00 --> Controller Class Initialized
INFO - 2018-10-27 20:56:00 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:56:00 --> Final output sent to browser
DEBUG - 2018-10-27 20:56:00 --> Total execution time: 0.2207
INFO - 2018-10-27 20:56:28 --> Config Class Initialized
INFO - 2018-10-27 20:56:28 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:56:28 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:56:28 --> Utf8 Class Initialized
INFO - 2018-10-27 20:56:28 --> URI Class Initialized
INFO - 2018-10-27 20:56:28 --> Router Class Initialized
INFO - 2018-10-27 20:56:28 --> Output Class Initialized
INFO - 2018-10-27 20:56:28 --> Security Class Initialized
DEBUG - 2018-10-27 20:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:56:28 --> Input Class Initialized
INFO - 2018-10-27 20:56:29 --> Language Class Initialized
INFO - 2018-10-27 20:56:29 --> Loader Class Initialized
INFO - 2018-10-27 20:56:29 --> Helper loaded: url_helper
INFO - 2018-10-27 20:56:29 --> Helper loaded: html_helper
INFO - 2018-10-27 20:56:29 --> Helper loaded: form_helper
INFO - 2018-10-27 20:56:29 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:56:29 --> Helper loaded: date_helper
INFO - 2018-10-27 20:56:29 --> Form Validation Class Initialized
INFO - 2018-10-27 20:56:29 --> Email Class Initialized
DEBUG - 2018-10-27 20:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:56:29 --> Pagination Class Initialized
INFO - 2018-10-27 20:56:29 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:29 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:29 --> Controller Class Initialized
INFO - 2018-10-27 20:56:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-10-27 20:56:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-10-27 20:56:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2018-10-27 20:56:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-10-27 20:56:29 --> Final output sent to browser
DEBUG - 2018-10-27 20:56:29 --> Total execution time: 0.1799
INFO - 2018-10-27 20:56:29 --> Config Class Initialized
INFO - 2018-10-27 20:56:29 --> Hooks Class Initialized
INFO - 2018-10-27 20:56:29 --> Config Class Initialized
INFO - 2018-10-27 20:56:29 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:56:29 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:56:29 --> Utf8 Class Initialized
DEBUG - 2018-10-27 20:56:29 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:56:29 --> URI Class Initialized
INFO - 2018-10-27 20:56:29 --> Utf8 Class Initialized
INFO - 2018-10-27 20:56:29 --> URI Class Initialized
INFO - 2018-10-27 20:56:29 --> Router Class Initialized
INFO - 2018-10-27 20:56:29 --> Router Class Initialized
INFO - 2018-10-27 20:56:29 --> Output Class Initialized
INFO - 2018-10-27 20:56:29 --> Output Class Initialized
INFO - 2018-10-27 20:56:29 --> Security Class Initialized
INFO - 2018-10-27 20:56:29 --> Security Class Initialized
DEBUG - 2018-10-27 20:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-27 20:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:56:29 --> Input Class Initialized
INFO - 2018-10-27 20:56:29 --> Input Class Initialized
INFO - 2018-10-27 20:56:29 --> Language Class Initialized
INFO - 2018-10-27 20:56:29 --> Language Class Initialized
INFO - 2018-10-27 20:56:29 --> Loader Class Initialized
INFO - 2018-10-27 20:56:29 --> Loader Class Initialized
INFO - 2018-10-27 20:56:29 --> Helper loaded: url_helper
INFO - 2018-10-27 20:56:29 --> Helper loaded: url_helper
INFO - 2018-10-27 20:56:29 --> Helper loaded: html_helper
INFO - 2018-10-27 20:56:29 --> Helper loaded: html_helper
INFO - 2018-10-27 20:56:29 --> Helper loaded: form_helper
INFO - 2018-10-27 20:56:29 --> Helper loaded: form_helper
INFO - 2018-10-27 20:56:29 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:56:29 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:56:29 --> Helper loaded: date_helper
INFO - 2018-10-27 20:56:29 --> Helper loaded: date_helper
INFO - 2018-10-27 20:56:29 --> Form Validation Class Initialized
INFO - 2018-10-27 20:56:29 --> Form Validation Class Initialized
INFO - 2018-10-27 20:56:29 --> Email Class Initialized
INFO - 2018-10-27 20:56:29 --> Email Class Initialized
DEBUG - 2018-10-27 20:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-10-27 20:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:56:29 --> Pagination Class Initialized
INFO - 2018-10-27 20:56:29 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:29 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:29 --> Controller Class Initialized
INFO - 2018-10-27 20:56:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:56:29 --> Final output sent to browser
DEBUG - 2018-10-27 20:56:29 --> Total execution time: 0.1603
INFO - 2018-10-27 20:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:56:29 --> Pagination Class Initialized
INFO - 2018-10-27 20:56:29 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:29 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:29 --> Controller Class Initialized
INFO - 2018-10-27 20:56:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:56:29 --> Final output sent to browser
DEBUG - 2018-10-27 20:56:29 --> Total execution time: 0.2203
INFO - 2018-10-27 20:56:33 --> Config Class Initialized
INFO - 2018-10-27 20:56:33 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:56:33 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:56:33 --> Utf8 Class Initialized
INFO - 2018-10-27 20:56:33 --> URI Class Initialized
INFO - 2018-10-27 20:56:33 --> Router Class Initialized
INFO - 2018-10-27 20:56:33 --> Output Class Initialized
INFO - 2018-10-27 20:56:33 --> Security Class Initialized
DEBUG - 2018-10-27 20:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:56:33 --> Input Class Initialized
INFO - 2018-10-27 20:56:33 --> Language Class Initialized
INFO - 2018-10-27 20:56:33 --> Loader Class Initialized
INFO - 2018-10-27 20:56:33 --> Helper loaded: url_helper
INFO - 2018-10-27 20:56:33 --> Helper loaded: html_helper
INFO - 2018-10-27 20:56:33 --> Helper loaded: form_helper
INFO - 2018-10-27 20:56:33 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:56:33 --> Helper loaded: date_helper
INFO - 2018-10-27 20:56:33 --> Form Validation Class Initialized
INFO - 2018-10-27 20:56:33 --> Email Class Initialized
DEBUG - 2018-10-27 20:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:56:33 --> Pagination Class Initialized
INFO - 2018-10-27 20:56:33 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:33 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:33 --> Controller Class Initialized
INFO - 2018-10-27 20:56:33 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-10-27 20:56:33 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-10-27 20:56:33 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/person.php
INFO - 2018-10-27 20:56:33 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-10-27 20:56:33 --> Final output sent to browser
DEBUG - 2018-10-27 20:56:33 --> Total execution time: 0.1706
INFO - 2018-10-27 20:56:33 --> Config Class Initialized
INFO - 2018-10-27 20:56:33 --> Config Class Initialized
INFO - 2018-10-27 20:56:33 --> Hooks Class Initialized
INFO - 2018-10-27 20:56:33 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:56:33 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:56:33 --> Utf8 Class Initialized
DEBUG - 2018-10-27 20:56:33 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:56:33 --> URI Class Initialized
INFO - 2018-10-27 20:56:33 --> Utf8 Class Initialized
INFO - 2018-10-27 20:56:33 --> URI Class Initialized
INFO - 2018-10-27 20:56:33 --> Router Class Initialized
INFO - 2018-10-27 20:56:33 --> Router Class Initialized
INFO - 2018-10-27 20:56:33 --> Output Class Initialized
INFO - 2018-10-27 20:56:33 --> Output Class Initialized
INFO - 2018-10-27 20:56:33 --> Security Class Initialized
INFO - 2018-10-27 20:56:33 --> Security Class Initialized
DEBUG - 2018-10-27 20:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-27 20:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:56:33 --> Input Class Initialized
INFO - 2018-10-27 20:56:33 --> Input Class Initialized
INFO - 2018-10-27 20:56:33 --> Language Class Initialized
INFO - 2018-10-27 20:56:33 --> Language Class Initialized
INFO - 2018-10-27 20:56:33 --> Loader Class Initialized
INFO - 2018-10-27 20:56:33 --> Loader Class Initialized
INFO - 2018-10-27 20:56:33 --> Helper loaded: url_helper
INFO - 2018-10-27 20:56:33 --> Helper loaded: url_helper
INFO - 2018-10-27 20:56:33 --> Helper loaded: html_helper
INFO - 2018-10-27 20:56:33 --> Helper loaded: html_helper
INFO - 2018-10-27 20:56:33 --> Helper loaded: form_helper
INFO - 2018-10-27 20:56:33 --> Helper loaded: form_helper
INFO - 2018-10-27 20:56:33 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:56:33 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:56:33 --> Helper loaded: date_helper
INFO - 2018-10-27 20:56:33 --> Helper loaded: date_helper
INFO - 2018-10-27 20:56:33 --> Form Validation Class Initialized
INFO - 2018-10-27 20:56:33 --> Form Validation Class Initialized
INFO - 2018-10-27 20:56:33 --> Email Class Initialized
INFO - 2018-10-27 20:56:33 --> Email Class Initialized
DEBUG - 2018-10-27 20:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-10-27 20:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:56:33 --> Pagination Class Initialized
INFO - 2018-10-27 20:56:33 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:33 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:33 --> Controller Class Initialized
INFO - 2018-10-27 20:56:33 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:56:33 --> Final output sent to browser
DEBUG - 2018-10-27 20:56:33 --> Total execution time: 0.1563
INFO - 2018-10-27 20:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:56:33 --> Pagination Class Initialized
INFO - 2018-10-27 20:56:33 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:33 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:33 --> Controller Class Initialized
INFO - 2018-10-27 20:56:33 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:56:33 --> Final output sent to browser
DEBUG - 2018-10-27 20:56:33 --> Total execution time: 0.2139
INFO - 2018-10-27 20:56:37 --> Config Class Initialized
INFO - 2018-10-27 20:56:37 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:56:37 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:56:37 --> Utf8 Class Initialized
INFO - 2018-10-27 20:56:37 --> URI Class Initialized
INFO - 2018-10-27 20:56:37 --> Router Class Initialized
INFO - 2018-10-27 20:56:37 --> Output Class Initialized
INFO - 2018-10-27 20:56:37 --> Security Class Initialized
DEBUG - 2018-10-27 20:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:56:37 --> Input Class Initialized
INFO - 2018-10-27 20:56:37 --> Language Class Initialized
INFO - 2018-10-27 20:56:37 --> Loader Class Initialized
INFO - 2018-10-27 20:56:37 --> Helper loaded: url_helper
INFO - 2018-10-27 20:56:37 --> Helper loaded: html_helper
INFO - 2018-10-27 20:56:37 --> Helper loaded: form_helper
INFO - 2018-10-27 20:56:37 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:56:37 --> Helper loaded: date_helper
INFO - 2018-10-27 20:56:37 --> Form Validation Class Initialized
INFO - 2018-10-27 20:56:37 --> Email Class Initialized
DEBUG - 2018-10-27 20:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:56:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:56:37 --> Pagination Class Initialized
INFO - 2018-10-27 20:56:37 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:37 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:37 --> Controller Class Initialized
INFO - 2018-10-27 20:56:37 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-10-27 20:56:37 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-10-27 20:56:37 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/person.php
INFO - 2018-10-27 20:56:37 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-10-27 20:56:37 --> Final output sent to browser
DEBUG - 2018-10-27 20:56:37 --> Total execution time: 0.1574
INFO - 2018-10-27 20:56:37 --> Config Class Initialized
INFO - 2018-10-27 20:56:37 --> Config Class Initialized
INFO - 2018-10-27 20:56:37 --> Hooks Class Initialized
INFO - 2018-10-27 20:56:37 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:56:37 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:56:37 --> Utf8 Class Initialized
DEBUG - 2018-10-27 20:56:37 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:56:37 --> Utf8 Class Initialized
INFO - 2018-10-27 20:56:37 --> URI Class Initialized
INFO - 2018-10-27 20:56:37 --> URI Class Initialized
INFO - 2018-10-27 20:56:37 --> Router Class Initialized
INFO - 2018-10-27 20:56:37 --> Router Class Initialized
INFO - 2018-10-27 20:56:37 --> Output Class Initialized
INFO - 2018-10-27 20:56:37 --> Output Class Initialized
INFO - 2018-10-27 20:56:37 --> Security Class Initialized
INFO - 2018-10-27 20:56:37 --> Security Class Initialized
DEBUG - 2018-10-27 20:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-27 20:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:56:37 --> Input Class Initialized
INFO - 2018-10-27 20:56:37 --> Input Class Initialized
INFO - 2018-10-27 20:56:37 --> Language Class Initialized
INFO - 2018-10-27 20:56:37 --> Language Class Initialized
INFO - 2018-10-27 20:56:37 --> Loader Class Initialized
INFO - 2018-10-27 20:56:37 --> Loader Class Initialized
INFO - 2018-10-27 20:56:37 --> Helper loaded: url_helper
INFO - 2018-10-27 20:56:37 --> Helper loaded: url_helper
INFO - 2018-10-27 20:56:37 --> Helper loaded: html_helper
INFO - 2018-10-27 20:56:37 --> Helper loaded: html_helper
INFO - 2018-10-27 20:56:37 --> Helper loaded: form_helper
INFO - 2018-10-27 20:56:37 --> Helper loaded: form_helper
INFO - 2018-10-27 20:56:37 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:56:37 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:56:37 --> Helper loaded: date_helper
INFO - 2018-10-27 20:56:37 --> Helper loaded: date_helper
INFO - 2018-10-27 20:56:37 --> Form Validation Class Initialized
INFO - 2018-10-27 20:56:37 --> Form Validation Class Initialized
INFO - 2018-10-27 20:56:37 --> Email Class Initialized
INFO - 2018-10-27 20:56:37 --> Email Class Initialized
DEBUG - 2018-10-27 20:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-10-27 20:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:56:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:56:37 --> Pagination Class Initialized
INFO - 2018-10-27 20:56:37 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:37 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:37 --> Controller Class Initialized
INFO - 2018-10-27 20:56:37 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:56:37 --> Final output sent to browser
DEBUG - 2018-10-27 20:56:37 --> Total execution time: 0.1521
INFO - 2018-10-27 20:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:56:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:56:37 --> Pagination Class Initialized
INFO - 2018-10-27 20:56:37 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:37 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:37 --> Controller Class Initialized
INFO - 2018-10-27 20:56:37 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:56:37 --> Final output sent to browser
DEBUG - 2018-10-27 20:56:37 --> Total execution time: 0.2072
INFO - 2018-10-27 20:56:52 --> Config Class Initialized
INFO - 2018-10-27 20:56:52 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:56:52 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:56:52 --> Utf8 Class Initialized
INFO - 2018-10-27 20:56:52 --> URI Class Initialized
INFO - 2018-10-27 20:56:52 --> Router Class Initialized
INFO - 2018-10-27 20:56:52 --> Output Class Initialized
INFO - 2018-10-27 20:56:52 --> Security Class Initialized
DEBUG - 2018-10-27 20:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:56:52 --> Input Class Initialized
INFO - 2018-10-27 20:56:52 --> Language Class Initialized
INFO - 2018-10-27 20:56:52 --> Loader Class Initialized
INFO - 2018-10-27 20:56:52 --> Helper loaded: url_helper
INFO - 2018-10-27 20:56:52 --> Helper loaded: html_helper
INFO - 2018-10-27 20:56:52 --> Helper loaded: form_helper
INFO - 2018-10-27 20:56:52 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:56:52 --> Helper loaded: date_helper
INFO - 2018-10-27 20:56:52 --> Form Validation Class Initialized
INFO - 2018-10-27 20:56:52 --> Email Class Initialized
DEBUG - 2018-10-27 20:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:56:52 --> Pagination Class Initialized
INFO - 2018-10-27 20:56:52 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:52 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:53 --> Controller Class Initialized
INFO - 2018-10-27 20:56:53 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-10-27 20:56:53 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-10-27 20:56:53 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/person.php
INFO - 2018-10-27 20:56:53 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-10-27 20:56:53 --> Final output sent to browser
DEBUG - 2018-10-27 20:56:53 --> Total execution time: 0.2708
INFO - 2018-10-27 20:56:53 --> Config Class Initialized
INFO - 2018-10-27 20:56:53 --> Config Class Initialized
INFO - 2018-10-27 20:56:53 --> Hooks Class Initialized
INFO - 2018-10-27 20:56:53 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:56:53 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:56:53 --> Utf8 Class Initialized
DEBUG - 2018-10-27 20:56:53 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:56:53 --> URI Class Initialized
INFO - 2018-10-27 20:56:53 --> Utf8 Class Initialized
INFO - 2018-10-27 20:56:53 --> URI Class Initialized
INFO - 2018-10-27 20:56:53 --> Router Class Initialized
INFO - 2018-10-27 20:56:53 --> Router Class Initialized
INFO - 2018-10-27 20:56:53 --> Output Class Initialized
INFO - 2018-10-27 20:56:53 --> Output Class Initialized
INFO - 2018-10-27 20:56:53 --> Security Class Initialized
INFO - 2018-10-27 20:56:53 --> Security Class Initialized
DEBUG - 2018-10-27 20:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-27 20:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:56:53 --> Input Class Initialized
INFO - 2018-10-27 20:56:53 --> Input Class Initialized
INFO - 2018-10-27 20:56:53 --> Language Class Initialized
INFO - 2018-10-27 20:56:53 --> Language Class Initialized
INFO - 2018-10-27 20:56:53 --> Loader Class Initialized
INFO - 2018-10-27 20:56:53 --> Loader Class Initialized
INFO - 2018-10-27 20:56:53 --> Helper loaded: url_helper
INFO - 2018-10-27 20:56:53 --> Helper loaded: url_helper
INFO - 2018-10-27 20:56:53 --> Helper loaded: html_helper
INFO - 2018-10-27 20:56:53 --> Helper loaded: html_helper
INFO - 2018-10-27 20:56:53 --> Helper loaded: form_helper
INFO - 2018-10-27 20:56:53 --> Helper loaded: form_helper
INFO - 2018-10-27 20:56:53 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:56:53 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:56:53 --> Helper loaded: date_helper
INFO - 2018-10-27 20:56:53 --> Helper loaded: date_helper
INFO - 2018-10-27 20:56:53 --> Form Validation Class Initialized
INFO - 2018-10-27 20:56:53 --> Form Validation Class Initialized
INFO - 2018-10-27 20:56:53 --> Email Class Initialized
INFO - 2018-10-27 20:56:53 --> Email Class Initialized
DEBUG - 2018-10-27 20:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-10-27 20:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:56:53 --> Pagination Class Initialized
INFO - 2018-10-27 20:56:53 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:53 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:53 --> Controller Class Initialized
INFO - 2018-10-27 20:56:53 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:56:53 --> Final output sent to browser
DEBUG - 2018-10-27 20:56:53 --> Total execution time: 0.1599
INFO - 2018-10-27 20:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:56:53 --> Pagination Class Initialized
INFO - 2018-10-27 20:56:53 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:53 --> Database Driver Class Initialized
INFO - 2018-10-27 20:56:53 --> Controller Class Initialized
INFO - 2018-10-27 20:56:53 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:56:53 --> Final output sent to browser
DEBUG - 2018-10-27 20:56:53 --> Total execution time: 0.2166
INFO - 2018-10-27 20:57:01 --> Config Class Initialized
INFO - 2018-10-27 20:57:01 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:57:01 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:57:01 --> Utf8 Class Initialized
INFO - 2018-10-27 20:57:01 --> URI Class Initialized
INFO - 2018-10-27 20:57:01 --> Router Class Initialized
INFO - 2018-10-27 20:57:02 --> Output Class Initialized
INFO - 2018-10-27 20:57:02 --> Security Class Initialized
DEBUG - 2018-10-27 20:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:57:02 --> Input Class Initialized
INFO - 2018-10-27 20:57:02 --> Language Class Initialized
INFO - 2018-10-27 20:57:02 --> Loader Class Initialized
INFO - 2018-10-27 20:57:02 --> Helper loaded: url_helper
INFO - 2018-10-27 20:57:02 --> Helper loaded: html_helper
INFO - 2018-10-27 20:57:02 --> Helper loaded: form_helper
INFO - 2018-10-27 20:57:02 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:57:02 --> Helper loaded: date_helper
INFO - 2018-10-27 20:57:02 --> Form Validation Class Initialized
INFO - 2018-10-27 20:57:02 --> Email Class Initialized
DEBUG - 2018-10-27 20:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:57:02 --> Pagination Class Initialized
INFO - 2018-10-27 20:57:02 --> Database Driver Class Initialized
INFO - 2018-10-27 20:57:02 --> Database Driver Class Initialized
INFO - 2018-10-27 20:57:02 --> Controller Class Initialized
INFO - 2018-10-27 20:57:02 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-10-27 20:57:02 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-10-27 20:57:02 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/person.php
INFO - 2018-10-27 20:57:02 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-10-27 20:57:02 --> Final output sent to browser
DEBUG - 2018-10-27 20:57:02 --> Total execution time: 0.1392
INFO - 2018-10-27 20:57:02 --> Config Class Initialized
INFO - 2018-10-27 20:57:02 --> Config Class Initialized
INFO - 2018-10-27 20:57:02 --> Hooks Class Initialized
INFO - 2018-10-27 20:57:02 --> Hooks Class Initialized
DEBUG - 2018-10-27 20:57:02 --> UTF-8 Support Enabled
DEBUG - 2018-10-27 20:57:02 --> UTF-8 Support Enabled
INFO - 2018-10-27 20:57:02 --> Utf8 Class Initialized
INFO - 2018-10-27 20:57:02 --> Utf8 Class Initialized
INFO - 2018-10-27 20:57:02 --> URI Class Initialized
INFO - 2018-10-27 20:57:02 --> Router Class Initialized
INFO - 2018-10-27 20:57:02 --> URI Class Initialized
INFO - 2018-10-27 20:57:02 --> Output Class Initialized
INFO - 2018-10-27 20:57:02 --> Security Class Initialized
DEBUG - 2018-10-27 20:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:57:02 --> Input Class Initialized
INFO - 2018-10-27 20:57:02 --> Router Class Initialized
INFO - 2018-10-27 20:57:02 --> Language Class Initialized
INFO - 2018-10-27 20:57:02 --> Output Class Initialized
INFO - 2018-10-27 20:57:02 --> Loader Class Initialized
INFO - 2018-10-27 20:57:02 --> Helper loaded: url_helper
INFO - 2018-10-27 20:57:02 --> Security Class Initialized
INFO - 2018-10-27 20:57:02 --> Helper loaded: html_helper
DEBUG - 2018-10-27 20:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 20:57:02 --> Helper loaded: form_helper
INFO - 2018-10-27 20:57:02 --> Input Class Initialized
INFO - 2018-10-27 20:57:02 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:57:02 --> Language Class Initialized
INFO - 2018-10-27 20:57:02 --> Helper loaded: date_helper
INFO - 2018-10-27 20:57:02 --> Form Validation Class Initialized
INFO - 2018-10-27 20:57:02 --> Email Class Initialized
INFO - 2018-10-27 20:57:02 --> Loader Class Initialized
INFO - 2018-10-27 20:57:02 --> Helper loaded: url_helper
INFO - 2018-10-27 20:57:02 --> Helper loaded: html_helper
DEBUG - 2018-10-27 20:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:57:02 --> Helper loaded: form_helper
INFO - 2018-10-27 20:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:57:02 --> Helper loaded: cookie_helper
INFO - 2018-10-27 20:57:02 --> Pagination Class Initialized
INFO - 2018-10-27 20:57:02 --> Helper loaded: date_helper
INFO - 2018-10-27 20:57:02 --> Form Validation Class Initialized
INFO - 2018-10-27 20:57:02 --> Database Driver Class Initialized
INFO - 2018-10-27 20:57:02 --> Database Driver Class Initialized
INFO - 2018-10-27 20:57:02 --> Email Class Initialized
INFO - 2018-10-27 20:57:02 --> Controller Class Initialized
DEBUG - 2018-10-27 20:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 20:57:02 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:57:02 --> Final output sent to browser
DEBUG - 2018-10-27 20:57:02 --> Total execution time: 0.1989
INFO - 2018-10-27 20:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 20:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-27 20:57:02 --> Pagination Class Initialized
INFO - 2018-10-27 20:57:02 --> Database Driver Class Initialized
INFO - 2018-10-27 20:57:02 --> Database Driver Class Initialized
INFO - 2018-10-27 20:57:02 --> Controller Class Initialized
INFO - 2018-10-27 20:57:02 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-27 20:57:02 --> Final output sent to browser
DEBUG - 2018-10-27 20:57:02 --> Total execution time: 0.2626
