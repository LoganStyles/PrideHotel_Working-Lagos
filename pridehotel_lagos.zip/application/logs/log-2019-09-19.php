<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-19 06:12:24 --> Config Class Initialized
INFO - 2019-09-19 06:12:24 --> Hooks Class Initialized
DEBUG - 2019-09-19 06:12:24 --> UTF-8 Support Enabled
INFO - 2019-09-19 06:12:24 --> Utf8 Class Initialized
INFO - 2019-09-19 06:12:24 --> URI Class Initialized
INFO - 2019-09-19 06:12:24 --> Router Class Initialized
INFO - 2019-09-19 06:12:24 --> Output Class Initialized
INFO - 2019-09-19 06:12:24 --> Security Class Initialized
DEBUG - 2019-09-19 06:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 06:12:24 --> Input Class Initialized
INFO - 2019-09-19 06:12:24 --> Language Class Initialized
INFO - 2019-09-19 06:12:24 --> Loader Class Initialized
INFO - 2019-09-19 06:12:24 --> Helper loaded: url_helper
INFO - 2019-09-19 06:12:24 --> Helper loaded: html_helper
INFO - 2019-09-19 06:12:24 --> Helper loaded: form_helper
INFO - 2019-09-19 06:12:24 --> Helper loaded: cookie_helper
INFO - 2019-09-19 06:12:24 --> Helper loaded: date_helper
INFO - 2019-09-19 06:12:24 --> Form Validation Class Initialized
INFO - 2019-09-19 06:12:24 --> Email Class Initialized
DEBUG - 2019-09-19 06:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 06:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 06:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 06:12:24 --> Pagination Class Initialized
INFO - 2019-09-19 06:12:24 --> Database Driver Class Initialized
INFO - 2019-09-19 06:12:24 --> Database Driver Class Initialized
INFO - 2019-09-19 06:12:24 --> Controller Class Initialized
DEBUG - 2019-09-19 06:12:24 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-19 06:12:24 --> Helper loaded: inflector_helper
INFO - 2019-09-19 06:12:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-19 06:12:24 --> Final output sent to browser
DEBUG - 2019-09-19 06:12:24 --> Total execution time: 0.2497
INFO - 2019-09-19 08:10:46 --> Config Class Initialized
INFO - 2019-09-19 08:10:46 --> Hooks Class Initialized
DEBUG - 2019-09-19 08:10:46 --> UTF-8 Support Enabled
INFO - 2019-09-19 08:10:46 --> Utf8 Class Initialized
INFO - 2019-09-19 08:10:46 --> URI Class Initialized
INFO - 2019-09-19 08:10:46 --> Router Class Initialized
INFO - 2019-09-19 08:10:46 --> Output Class Initialized
INFO - 2019-09-19 08:10:46 --> Security Class Initialized
DEBUG - 2019-09-19 08:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 08:10:46 --> Input Class Initialized
INFO - 2019-09-19 08:10:46 --> Language Class Initialized
INFO - 2019-09-19 08:10:46 --> Loader Class Initialized
INFO - 2019-09-19 08:10:46 --> Helper loaded: url_helper
INFO - 2019-09-19 08:10:46 --> Helper loaded: html_helper
INFO - 2019-09-19 08:10:46 --> Helper loaded: form_helper
INFO - 2019-09-19 08:10:46 --> Helper loaded: cookie_helper
INFO - 2019-09-19 08:10:46 --> Helper loaded: date_helper
INFO - 2019-09-19 08:10:46 --> Form Validation Class Initialized
INFO - 2019-09-19 08:10:46 --> Email Class Initialized
DEBUG - 2019-09-19 08:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 08:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 08:10:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 08:10:46 --> Pagination Class Initialized
INFO - 2019-09-19 08:10:46 --> Database Driver Class Initialized
INFO - 2019-09-19 08:10:46 --> Database Driver Class Initialized
INFO - 2019-09-19 08:10:46 --> Controller Class Initialized
DEBUG - 2019-09-19 08:10:46 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-19 08:10:46 --> Helper loaded: inflector_helper
INFO - 2019-09-19 08:10:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-19 08:10:46 --> Final output sent to browser
DEBUG - 2019-09-19 08:10:46 --> Total execution time: 0.1623
INFO - 2019-09-19 09:10:44 --> Config Class Initialized
INFO - 2019-09-19 09:10:44 --> Hooks Class Initialized
DEBUG - 2019-09-19 09:10:44 --> UTF-8 Support Enabled
INFO - 2019-09-19 09:10:44 --> Utf8 Class Initialized
INFO - 2019-09-19 09:10:44 --> URI Class Initialized
INFO - 2019-09-19 09:10:44 --> Router Class Initialized
INFO - 2019-09-19 09:10:44 --> Output Class Initialized
INFO - 2019-09-19 09:10:44 --> Security Class Initialized
DEBUG - 2019-09-19 09:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 09:10:44 --> Input Class Initialized
INFO - 2019-09-19 09:10:44 --> Language Class Initialized
INFO - 2019-09-19 09:10:44 --> Loader Class Initialized
INFO - 2019-09-19 09:10:44 --> Helper loaded: url_helper
INFO - 2019-09-19 09:10:44 --> Helper loaded: html_helper
INFO - 2019-09-19 09:10:44 --> Helper loaded: form_helper
INFO - 2019-09-19 09:10:44 --> Helper loaded: cookie_helper
INFO - 2019-09-19 09:10:44 --> Helper loaded: date_helper
INFO - 2019-09-19 09:10:44 --> Form Validation Class Initialized
INFO - 2019-09-19 09:10:44 --> Email Class Initialized
DEBUG - 2019-09-19 09:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 09:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 09:10:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 09:10:44 --> Pagination Class Initialized
INFO - 2019-09-19 09:10:44 --> Database Driver Class Initialized
INFO - 2019-09-19 09:10:44 --> Database Driver Class Initialized
INFO - 2019-09-19 09:10:44 --> Controller Class Initialized
DEBUG - 2019-09-19 09:10:44 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-19 09:10:44 --> Helper loaded: inflector_helper
INFO - 2019-09-19 09:10:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-19 09:10:44 --> Final output sent to browser
DEBUG - 2019-09-19 09:10:44 --> Total execution time: 0.0635
INFO - 2019-09-19 10:10:44 --> Config Class Initialized
INFO - 2019-09-19 10:10:44 --> Hooks Class Initialized
DEBUG - 2019-09-19 10:10:44 --> UTF-8 Support Enabled
INFO - 2019-09-19 10:10:44 --> Utf8 Class Initialized
INFO - 2019-09-19 10:10:44 --> URI Class Initialized
INFO - 2019-09-19 10:10:44 --> Router Class Initialized
INFO - 2019-09-19 10:10:44 --> Output Class Initialized
INFO - 2019-09-19 10:10:44 --> Security Class Initialized
DEBUG - 2019-09-19 10:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 10:10:44 --> Input Class Initialized
INFO - 2019-09-19 10:10:44 --> Language Class Initialized
INFO - 2019-09-19 10:10:44 --> Loader Class Initialized
INFO - 2019-09-19 10:10:44 --> Helper loaded: url_helper
INFO - 2019-09-19 10:10:44 --> Helper loaded: html_helper
INFO - 2019-09-19 10:10:44 --> Helper loaded: form_helper
INFO - 2019-09-19 10:10:44 --> Helper loaded: cookie_helper
INFO - 2019-09-19 10:10:44 --> Helper loaded: date_helper
INFO - 2019-09-19 10:10:44 --> Form Validation Class Initialized
INFO - 2019-09-19 10:10:44 --> Email Class Initialized
DEBUG - 2019-09-19 10:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 10:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 10:10:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 10:10:44 --> Pagination Class Initialized
INFO - 2019-09-19 10:10:44 --> Database Driver Class Initialized
INFO - 2019-09-19 10:10:44 --> Database Driver Class Initialized
INFO - 2019-09-19 10:10:44 --> Controller Class Initialized
DEBUG - 2019-09-19 10:10:44 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-19 10:10:44 --> Helper loaded: inflector_helper
INFO - 2019-09-19 10:10:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-19 10:10:44 --> Final output sent to browser
DEBUG - 2019-09-19 10:10:44 --> Total execution time: 0.6627
INFO - 2019-09-19 11:10:43 --> Config Class Initialized
INFO - 2019-09-19 11:10:43 --> Hooks Class Initialized
DEBUG - 2019-09-19 11:10:43 --> UTF-8 Support Enabled
INFO - 2019-09-19 11:10:43 --> Utf8 Class Initialized
INFO - 2019-09-19 11:10:43 --> URI Class Initialized
INFO - 2019-09-19 11:10:43 --> Router Class Initialized
INFO - 2019-09-19 11:10:43 --> Output Class Initialized
INFO - 2019-09-19 11:10:43 --> Security Class Initialized
DEBUG - 2019-09-19 11:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 11:10:43 --> Input Class Initialized
INFO - 2019-09-19 11:10:43 --> Language Class Initialized
INFO - 2019-09-19 11:10:43 --> Loader Class Initialized
INFO - 2019-09-19 11:10:43 --> Helper loaded: url_helper
INFO - 2019-09-19 11:10:43 --> Helper loaded: html_helper
INFO - 2019-09-19 11:10:43 --> Helper loaded: form_helper
INFO - 2019-09-19 11:10:43 --> Helper loaded: cookie_helper
INFO - 2019-09-19 11:10:43 --> Helper loaded: date_helper
INFO - 2019-09-19 11:10:43 --> Form Validation Class Initialized
INFO - 2019-09-19 11:10:43 --> Email Class Initialized
DEBUG - 2019-09-19 11:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 11:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 11:10:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 11:10:43 --> Pagination Class Initialized
INFO - 2019-09-19 11:10:43 --> Database Driver Class Initialized
INFO - 2019-09-19 11:10:43 --> Database Driver Class Initialized
INFO - 2019-09-19 11:10:43 --> Controller Class Initialized
DEBUG - 2019-09-19 11:10:43 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-19 11:10:43 --> Helper loaded: inflector_helper
INFO - 2019-09-19 11:10:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-19 11:10:43 --> Final output sent to browser
DEBUG - 2019-09-19 11:10:43 --> Total execution time: 0.0606
INFO - 2019-09-19 12:10:42 --> Config Class Initialized
INFO - 2019-09-19 12:10:42 --> Hooks Class Initialized
DEBUG - 2019-09-19 12:10:42 --> UTF-8 Support Enabled
INFO - 2019-09-19 12:10:42 --> Utf8 Class Initialized
INFO - 2019-09-19 12:10:42 --> URI Class Initialized
INFO - 2019-09-19 12:10:42 --> Router Class Initialized
INFO - 2019-09-19 12:10:42 --> Output Class Initialized
INFO - 2019-09-19 12:10:42 --> Security Class Initialized
DEBUG - 2019-09-19 12:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 12:10:42 --> Input Class Initialized
INFO - 2019-09-19 12:10:42 --> Language Class Initialized
INFO - 2019-09-19 12:10:42 --> Loader Class Initialized
INFO - 2019-09-19 12:10:42 --> Helper loaded: url_helper
INFO - 2019-09-19 12:10:42 --> Helper loaded: html_helper
INFO - 2019-09-19 12:10:42 --> Helper loaded: form_helper
INFO - 2019-09-19 12:10:42 --> Helper loaded: cookie_helper
INFO - 2019-09-19 12:10:42 --> Helper loaded: date_helper
INFO - 2019-09-19 12:10:42 --> Form Validation Class Initialized
INFO - 2019-09-19 12:10:42 --> Email Class Initialized
DEBUG - 2019-09-19 12:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 12:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 12:10:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 12:10:42 --> Pagination Class Initialized
INFO - 2019-09-19 12:10:42 --> Database Driver Class Initialized
INFO - 2019-09-19 12:10:42 --> Database Driver Class Initialized
INFO - 2019-09-19 12:10:42 --> Controller Class Initialized
DEBUG - 2019-09-19 12:10:42 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-19 12:10:42 --> Helper loaded: inflector_helper
INFO - 2019-09-19 12:10:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-19 12:10:42 --> Final output sent to browser
DEBUG - 2019-09-19 12:10:42 --> Total execution time: 0.0672
INFO - 2019-09-19 13:11:11 --> Config Class Initialized
INFO - 2019-09-19 13:11:11 --> Hooks Class Initialized
DEBUG - 2019-09-19 13:11:11 --> UTF-8 Support Enabled
INFO - 2019-09-19 13:11:11 --> Utf8 Class Initialized
INFO - 2019-09-19 13:11:11 --> URI Class Initialized
INFO - 2019-09-19 13:11:11 --> Router Class Initialized
INFO - 2019-09-19 13:11:11 --> Output Class Initialized
INFO - 2019-09-19 13:11:11 --> Security Class Initialized
DEBUG - 2019-09-19 13:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 13:11:11 --> Input Class Initialized
INFO - 2019-09-19 13:11:11 --> Language Class Initialized
INFO - 2019-09-19 13:11:11 --> Loader Class Initialized
INFO - 2019-09-19 13:11:11 --> Helper loaded: url_helper
INFO - 2019-09-19 13:11:11 --> Helper loaded: html_helper
INFO - 2019-09-19 13:11:11 --> Helper loaded: form_helper
INFO - 2019-09-19 13:11:11 --> Helper loaded: cookie_helper
INFO - 2019-09-19 13:11:11 --> Helper loaded: date_helper
INFO - 2019-09-19 13:11:11 --> Form Validation Class Initialized
INFO - 2019-09-19 13:11:11 --> Email Class Initialized
DEBUG - 2019-09-19 13:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 13:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 13:11:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 13:11:11 --> Pagination Class Initialized
INFO - 2019-09-19 13:11:11 --> Database Driver Class Initialized
INFO - 2019-09-19 13:11:11 --> Database Driver Class Initialized
INFO - 2019-09-19 13:11:11 --> Controller Class Initialized
DEBUG - 2019-09-19 13:11:11 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-19 13:11:11 --> Helper loaded: inflector_helper
INFO - 2019-09-19 13:11:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-19 13:11:11 --> Final output sent to browser
DEBUG - 2019-09-19 13:11:11 --> Total execution time: 0.1172
INFO - 2019-09-19 20:07:52 --> Config Class Initialized
INFO - 2019-09-19 20:07:52 --> Hooks Class Initialized
DEBUG - 2019-09-19 20:07:52 --> UTF-8 Support Enabled
INFO - 2019-09-19 20:07:52 --> Utf8 Class Initialized
INFO - 2019-09-19 20:07:52 --> URI Class Initialized
INFO - 2019-09-19 20:07:52 --> Router Class Initialized
INFO - 2019-09-19 20:07:52 --> Output Class Initialized
INFO - 2019-09-19 20:07:52 --> Security Class Initialized
DEBUG - 2019-09-19 20:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 20:07:52 --> Input Class Initialized
INFO - 2019-09-19 20:07:52 --> Language Class Initialized
INFO - 2019-09-19 20:07:52 --> Loader Class Initialized
INFO - 2019-09-19 20:07:53 --> Helper loaded: url_helper
INFO - 2019-09-19 20:07:53 --> Helper loaded: html_helper
INFO - 2019-09-19 20:07:53 --> Helper loaded: form_helper
INFO - 2019-09-19 20:07:53 --> Helper loaded: cookie_helper
INFO - 2019-09-19 20:07:53 --> Helper loaded: date_helper
INFO - 2019-09-19 20:07:53 --> Form Validation Class Initialized
INFO - 2019-09-19 20:07:53 --> Email Class Initialized
DEBUG - 2019-09-19 20:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 20:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 20:07:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 20:07:53 --> Pagination Class Initialized
INFO - 2019-09-19 20:07:54 --> Database Driver Class Initialized
INFO - 2019-09-19 20:07:54 --> Database Driver Class Initialized
INFO - 2019-09-19 20:07:54 --> Controller Class Initialized
INFO - 2019-09-19 20:07:59 --> Config Class Initialized
INFO - 2019-09-19 20:07:59 --> Hooks Class Initialized
DEBUG - 2019-09-19 20:07:59 --> UTF-8 Support Enabled
INFO - 2019-09-19 20:07:59 --> Utf8 Class Initialized
INFO - 2019-09-19 20:07:59 --> URI Class Initialized
INFO - 2019-09-19 20:07:59 --> Router Class Initialized
INFO - 2019-09-19 20:07:59 --> Output Class Initialized
INFO - 2019-09-19 20:07:59 --> Security Class Initialized
DEBUG - 2019-09-19 20:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 20:07:59 --> Input Class Initialized
INFO - 2019-09-19 20:07:59 --> Language Class Initialized
INFO - 2019-09-19 20:07:59 --> Loader Class Initialized
INFO - 2019-09-19 20:07:59 --> Helper loaded: url_helper
INFO - 2019-09-19 20:07:59 --> Helper loaded: html_helper
INFO - 2019-09-19 20:07:59 --> Helper loaded: form_helper
INFO - 2019-09-19 20:07:59 --> Helper loaded: cookie_helper
INFO - 2019-09-19 20:07:59 --> Helper loaded: date_helper
INFO - 2019-09-19 20:07:59 --> Form Validation Class Initialized
INFO - 2019-09-19 20:07:59 --> Email Class Initialized
DEBUG - 2019-09-19 20:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 20:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 20:07:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 20:07:59 --> Pagination Class Initialized
INFO - 2019-09-19 20:07:59 --> Database Driver Class Initialized
INFO - 2019-09-19 20:07:59 --> Database Driver Class Initialized
INFO - 2019-09-19 20:07:59 --> Controller Class Initialized
INFO - 2019-09-19 20:07:59 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-19 20:07:59 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-19 20:07:59 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-19 20:07:59 --> Final output sent to browser
DEBUG - 2019-09-19 20:07:59 --> Total execution time: 0.5035
INFO - 2019-09-19 20:08:01 --> Config Class Initialized
INFO - 2019-09-19 20:08:01 --> Hooks Class Initialized
DEBUG - 2019-09-19 20:08:01 --> UTF-8 Support Enabled
INFO - 2019-09-19 20:08:01 --> Utf8 Class Initialized
INFO - 2019-09-19 20:08:01 --> URI Class Initialized
INFO - 2019-09-19 20:08:01 --> Router Class Initialized
INFO - 2019-09-19 20:08:01 --> Output Class Initialized
INFO - 2019-09-19 20:08:01 --> Security Class Initialized
DEBUG - 2019-09-19 20:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 20:08:01 --> Input Class Initialized
INFO - 2019-09-19 20:08:01 --> Language Class Initialized
INFO - 2019-09-19 20:08:01 --> Loader Class Initialized
INFO - 2019-09-19 20:08:01 --> Helper loaded: url_helper
INFO - 2019-09-19 20:08:01 --> Helper loaded: html_helper
INFO - 2019-09-19 20:08:01 --> Helper loaded: form_helper
INFO - 2019-09-19 20:08:01 --> Helper loaded: cookie_helper
INFO - 2019-09-19 20:08:01 --> Helper loaded: date_helper
INFO - 2019-09-19 20:08:01 --> Form Validation Class Initialized
INFO - 2019-09-19 20:08:01 --> Email Class Initialized
DEBUG - 2019-09-19 20:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 20:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 20:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 20:08:01 --> Pagination Class Initialized
INFO - 2019-09-19 20:08:01 --> Database Driver Class Initialized
INFO - 2019-09-19 20:08:01 --> Database Driver Class Initialized
INFO - 2019-09-19 20:08:01 --> Controller Class Initialized
INFO - 2019-09-19 20:08:01 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 20:08:01 --> Final output sent to browser
DEBUG - 2019-09-19 20:08:01 --> Total execution time: 0.2773
INFO - 2019-09-19 20:08:21 --> Config Class Initialized
INFO - 2019-09-19 20:08:21 --> Hooks Class Initialized
DEBUG - 2019-09-19 20:08:21 --> UTF-8 Support Enabled
INFO - 2019-09-19 20:08:21 --> Utf8 Class Initialized
INFO - 2019-09-19 20:08:21 --> URI Class Initialized
INFO - 2019-09-19 20:08:21 --> Router Class Initialized
INFO - 2019-09-19 20:08:21 --> Output Class Initialized
INFO - 2019-09-19 20:08:21 --> Security Class Initialized
DEBUG - 2019-09-19 20:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 20:08:21 --> Input Class Initialized
INFO - 2019-09-19 20:08:21 --> Language Class Initialized
INFO - 2019-09-19 20:08:21 --> Loader Class Initialized
INFO - 2019-09-19 20:08:21 --> Helper loaded: url_helper
INFO - 2019-09-19 20:08:21 --> Helper loaded: html_helper
INFO - 2019-09-19 20:08:21 --> Helper loaded: form_helper
INFO - 2019-09-19 20:08:21 --> Helper loaded: cookie_helper
INFO - 2019-09-19 20:08:21 --> Helper loaded: date_helper
INFO - 2019-09-19 20:08:21 --> Form Validation Class Initialized
INFO - 2019-09-19 20:08:21 --> Email Class Initialized
DEBUG - 2019-09-19 20:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 20:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 20:08:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 20:08:21 --> Pagination Class Initialized
INFO - 2019-09-19 20:08:21 --> Database Driver Class Initialized
INFO - 2019-09-19 20:08:21 --> Database Driver Class Initialized
INFO - 2019-09-19 20:08:21 --> Controller Class Initialized
INFO - 2019-09-19 20:10:44 --> Config Class Initialized
INFO - 2019-09-19 20:10:44 --> Hooks Class Initialized
DEBUG - 2019-09-19 20:10:44 --> UTF-8 Support Enabled
INFO - 2019-09-19 20:10:44 --> Utf8 Class Initialized
INFO - 2019-09-19 20:10:44 --> URI Class Initialized
INFO - 2019-09-19 20:10:44 --> Router Class Initialized
INFO - 2019-09-19 20:10:44 --> Output Class Initialized
INFO - 2019-09-19 20:10:44 --> Security Class Initialized
DEBUG - 2019-09-19 20:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 20:10:44 --> Input Class Initialized
INFO - 2019-09-19 20:10:44 --> Language Class Initialized
INFO - 2019-09-19 20:10:44 --> Loader Class Initialized
INFO - 2019-09-19 20:10:44 --> Helper loaded: url_helper
INFO - 2019-09-19 20:10:44 --> Helper loaded: html_helper
INFO - 2019-09-19 20:10:44 --> Helper loaded: form_helper
INFO - 2019-09-19 20:10:44 --> Helper loaded: cookie_helper
INFO - 2019-09-19 20:10:44 --> Helper loaded: date_helper
INFO - 2019-09-19 20:10:44 --> Form Validation Class Initialized
INFO - 2019-09-19 20:10:44 --> Email Class Initialized
DEBUG - 2019-09-19 20:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 20:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 20:10:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 20:10:44 --> Pagination Class Initialized
INFO - 2019-09-19 20:10:44 --> Database Driver Class Initialized
INFO - 2019-09-19 20:10:44 --> Database Driver Class Initialized
INFO - 2019-09-19 20:10:44 --> Controller Class Initialized
DEBUG - 2019-09-19 20:10:44 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-19 20:10:44 --> Helper loaded: inflector_helper
INFO - 2019-09-19 20:10:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-19 20:10:44 --> Final output sent to browser
DEBUG - 2019-09-19 20:10:44 --> Total execution time: 0.2261
INFO - 2019-09-19 20:11:09 --> Config Class Initialized
INFO - 2019-09-19 20:11:09 --> Hooks Class Initialized
DEBUG - 2019-09-19 20:11:09 --> UTF-8 Support Enabled
INFO - 2019-09-19 20:11:09 --> Utf8 Class Initialized
INFO - 2019-09-19 20:11:09 --> URI Class Initialized
INFO - 2019-09-19 20:11:09 --> Router Class Initialized
INFO - 2019-09-19 20:11:09 --> Output Class Initialized
INFO - 2019-09-19 20:11:09 --> Security Class Initialized
DEBUG - 2019-09-19 20:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 20:11:09 --> Input Class Initialized
INFO - 2019-09-19 20:11:09 --> Language Class Initialized
INFO - 2019-09-19 20:11:09 --> Loader Class Initialized
INFO - 2019-09-19 20:11:09 --> Helper loaded: url_helper
INFO - 2019-09-19 20:11:09 --> Helper loaded: html_helper
INFO - 2019-09-19 20:11:09 --> Helper loaded: form_helper
INFO - 2019-09-19 20:11:09 --> Helper loaded: cookie_helper
INFO - 2019-09-19 20:11:09 --> Helper loaded: date_helper
INFO - 2019-09-19 20:11:09 --> Form Validation Class Initialized
INFO - 2019-09-19 20:11:09 --> Email Class Initialized
DEBUG - 2019-09-19 20:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 20:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 20:11:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 20:11:09 --> Pagination Class Initialized
INFO - 2019-09-19 20:11:09 --> Database Driver Class Initialized
INFO - 2019-09-19 20:11:09 --> Database Driver Class Initialized
INFO - 2019-09-19 20:11:09 --> Controller Class Initialized
INFO - 2019-09-19 20:11:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-19 20:11:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-19 20:11:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-19 20:11:09 --> Final output sent to browser
DEBUG - 2019-09-19 20:11:09 --> Total execution time: 0.0792
INFO - 2019-09-19 20:11:09 --> Config Class Initialized
INFO - 2019-09-19 20:11:09 --> Hooks Class Initialized
DEBUG - 2019-09-19 20:11:09 --> UTF-8 Support Enabled
INFO - 2019-09-19 20:11:09 --> Utf8 Class Initialized
INFO - 2019-09-19 20:11:09 --> URI Class Initialized
INFO - 2019-09-19 20:11:09 --> Router Class Initialized
INFO - 2019-09-19 20:11:09 --> Output Class Initialized
INFO - 2019-09-19 20:11:09 --> Security Class Initialized
DEBUG - 2019-09-19 20:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 20:11:09 --> Input Class Initialized
INFO - 2019-09-19 20:11:09 --> Language Class Initialized
INFO - 2019-09-19 20:11:09 --> Loader Class Initialized
INFO - 2019-09-19 20:11:09 --> Helper loaded: url_helper
INFO - 2019-09-19 20:11:09 --> Helper loaded: html_helper
INFO - 2019-09-19 20:11:09 --> Helper loaded: form_helper
INFO - 2019-09-19 20:11:09 --> Helper loaded: cookie_helper
INFO - 2019-09-19 20:11:09 --> Helper loaded: date_helper
INFO - 2019-09-19 20:11:09 --> Form Validation Class Initialized
INFO - 2019-09-19 20:11:09 --> Email Class Initialized
DEBUG - 2019-09-19 20:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 20:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 20:11:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 20:11:09 --> Pagination Class Initialized
INFO - 2019-09-19 20:11:09 --> Database Driver Class Initialized
INFO - 2019-09-19 20:11:09 --> Database Driver Class Initialized
INFO - 2019-09-19 20:11:09 --> Controller Class Initialized
INFO - 2019-09-19 20:11:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 20:11:09 --> Final output sent to browser
DEBUG - 2019-09-19 20:11:09 --> Total execution time: 0.0650
INFO - 2019-09-19 20:11:10 --> Config Class Initialized
INFO - 2019-09-19 20:11:10 --> Hooks Class Initialized
DEBUG - 2019-09-19 20:11:10 --> UTF-8 Support Enabled
INFO - 2019-09-19 20:11:10 --> Utf8 Class Initialized
INFO - 2019-09-19 20:11:10 --> URI Class Initialized
INFO - 2019-09-19 20:11:10 --> Router Class Initialized
INFO - 2019-09-19 20:11:10 --> Output Class Initialized
INFO - 2019-09-19 20:11:10 --> Security Class Initialized
DEBUG - 2019-09-19 20:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 20:11:10 --> Input Class Initialized
INFO - 2019-09-19 20:11:10 --> Language Class Initialized
INFO - 2019-09-19 20:11:10 --> Loader Class Initialized
INFO - 2019-09-19 20:11:10 --> Helper loaded: url_helper
INFO - 2019-09-19 20:11:10 --> Helper loaded: html_helper
INFO - 2019-09-19 20:11:10 --> Helper loaded: form_helper
INFO - 2019-09-19 20:11:10 --> Helper loaded: cookie_helper
INFO - 2019-09-19 20:11:10 --> Helper loaded: date_helper
INFO - 2019-09-19 20:11:10 --> Form Validation Class Initialized
INFO - 2019-09-19 20:11:10 --> Email Class Initialized
DEBUG - 2019-09-19 20:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 20:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 20:11:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 20:11:10 --> Pagination Class Initialized
INFO - 2019-09-19 20:11:10 --> Database Driver Class Initialized
INFO - 2019-09-19 20:11:10 --> Database Driver Class Initialized
INFO - 2019-09-19 20:11:10 --> Controller Class Initialized
INFO - 2019-09-19 20:11:10 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 20:11:10 --> Final output sent to browser
DEBUG - 2019-09-19 20:11:10 --> Total execution time: 0.0725
INFO - 2019-09-19 20:11:14 --> Config Class Initialized
INFO - 2019-09-19 20:11:14 --> Hooks Class Initialized
DEBUG - 2019-09-19 20:11:14 --> UTF-8 Support Enabled
INFO - 2019-09-19 20:11:14 --> Utf8 Class Initialized
INFO - 2019-09-19 20:11:14 --> URI Class Initialized
INFO - 2019-09-19 20:11:14 --> Router Class Initialized
INFO - 2019-09-19 20:11:14 --> Output Class Initialized
INFO - 2019-09-19 20:11:14 --> Security Class Initialized
DEBUG - 2019-09-19 20:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 20:11:14 --> Input Class Initialized
INFO - 2019-09-19 20:11:14 --> Language Class Initialized
INFO - 2019-09-19 20:11:14 --> Loader Class Initialized
INFO - 2019-09-19 20:11:14 --> Helper loaded: url_helper
INFO - 2019-09-19 20:11:14 --> Helper loaded: html_helper
INFO - 2019-09-19 20:11:14 --> Helper loaded: form_helper
INFO - 2019-09-19 20:11:14 --> Helper loaded: cookie_helper
INFO - 2019-09-19 20:11:14 --> Helper loaded: date_helper
INFO - 2019-09-19 20:11:14 --> Form Validation Class Initialized
INFO - 2019-09-19 20:11:14 --> Email Class Initialized
DEBUG - 2019-09-19 20:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 20:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 20:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 20:11:14 --> Pagination Class Initialized
INFO - 2019-09-19 20:11:14 --> Database Driver Class Initialized
INFO - 2019-09-19 20:11:14 --> Database Driver Class Initialized
INFO - 2019-09-19 20:11:14 --> Controller Class Initialized
INFO - 2019-09-19 20:12:08 --> Config Class Initialized
INFO - 2019-09-19 20:12:08 --> Hooks Class Initialized
DEBUG - 2019-09-19 20:12:08 --> UTF-8 Support Enabled
INFO - 2019-09-19 20:12:08 --> Utf8 Class Initialized
INFO - 2019-09-19 20:12:08 --> URI Class Initialized
INFO - 2019-09-19 20:12:08 --> Router Class Initialized
INFO - 2019-09-19 20:12:08 --> Output Class Initialized
INFO - 2019-09-19 20:12:08 --> Security Class Initialized
DEBUG - 2019-09-19 20:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 20:12:08 --> Input Class Initialized
INFO - 2019-09-19 20:12:08 --> Language Class Initialized
INFO - 2019-09-19 20:12:08 --> Loader Class Initialized
INFO - 2019-09-19 20:12:08 --> Helper loaded: url_helper
INFO - 2019-09-19 20:12:08 --> Helper loaded: html_helper
INFO - 2019-09-19 20:12:08 --> Helper loaded: form_helper
INFO - 2019-09-19 20:12:08 --> Helper loaded: cookie_helper
INFO - 2019-09-19 20:12:08 --> Helper loaded: date_helper
INFO - 2019-09-19 20:12:08 --> Form Validation Class Initialized
INFO - 2019-09-19 20:12:08 --> Email Class Initialized
DEBUG - 2019-09-19 20:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 20:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 20:12:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 20:12:08 --> Pagination Class Initialized
INFO - 2019-09-19 20:12:08 --> Database Driver Class Initialized
INFO - 2019-09-19 20:12:08 --> Database Driver Class Initialized
INFO - 2019-09-19 20:12:08 --> Controller Class Initialized
INFO - 2019-09-19 20:12:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-19 20:12:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-19 20:12:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-19 20:12:08 --> Final output sent to browser
DEBUG - 2019-09-19 20:12:08 --> Total execution time: 0.0725
INFO - 2019-09-19 20:12:08 --> Config Class Initialized
INFO - 2019-09-19 20:12:08 --> Hooks Class Initialized
DEBUG - 2019-09-19 20:12:08 --> UTF-8 Support Enabled
INFO - 2019-09-19 20:12:08 --> Utf8 Class Initialized
INFO - 2019-09-19 20:12:08 --> URI Class Initialized
INFO - 2019-09-19 20:12:08 --> Router Class Initialized
INFO - 2019-09-19 20:12:08 --> Output Class Initialized
INFO - 2019-09-19 20:12:08 --> Security Class Initialized
DEBUG - 2019-09-19 20:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 20:12:08 --> Input Class Initialized
INFO - 2019-09-19 20:12:08 --> Language Class Initialized
INFO - 2019-09-19 20:12:08 --> Loader Class Initialized
INFO - 2019-09-19 20:12:08 --> Helper loaded: url_helper
INFO - 2019-09-19 20:12:08 --> Helper loaded: html_helper
INFO - 2019-09-19 20:12:08 --> Helper loaded: form_helper
INFO - 2019-09-19 20:12:08 --> Helper loaded: cookie_helper
INFO - 2019-09-19 20:12:08 --> Helper loaded: date_helper
INFO - 2019-09-19 20:12:08 --> Form Validation Class Initialized
INFO - 2019-09-19 20:12:08 --> Email Class Initialized
DEBUG - 2019-09-19 20:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 20:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 20:12:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 20:12:08 --> Pagination Class Initialized
INFO - 2019-09-19 20:12:08 --> Database Driver Class Initialized
INFO - 2019-09-19 20:12:08 --> Database Driver Class Initialized
INFO - 2019-09-19 20:12:08 --> Controller Class Initialized
INFO - 2019-09-19 20:12:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 20:12:09 --> Final output sent to browser
DEBUG - 2019-09-19 20:12:09 --> Total execution time: 0.1499
INFO - 2019-09-19 20:12:15 --> Config Class Initialized
INFO - 2019-09-19 20:12:15 --> Hooks Class Initialized
DEBUG - 2019-09-19 20:12:15 --> UTF-8 Support Enabled
INFO - 2019-09-19 20:12:15 --> Utf8 Class Initialized
INFO - 2019-09-19 20:12:15 --> URI Class Initialized
INFO - 2019-09-19 20:12:15 --> Router Class Initialized
INFO - 2019-09-19 20:12:15 --> Output Class Initialized
INFO - 2019-09-19 20:12:15 --> Security Class Initialized
DEBUG - 2019-09-19 20:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 20:12:15 --> Input Class Initialized
INFO - 2019-09-19 20:12:15 --> Language Class Initialized
INFO - 2019-09-19 20:12:15 --> Loader Class Initialized
INFO - 2019-09-19 20:12:15 --> Helper loaded: url_helper
INFO - 2019-09-19 20:12:15 --> Helper loaded: html_helper
INFO - 2019-09-19 20:12:15 --> Helper loaded: form_helper
INFO - 2019-09-19 20:12:15 --> Helper loaded: cookie_helper
INFO - 2019-09-19 20:12:15 --> Helper loaded: date_helper
INFO - 2019-09-19 20:12:15 --> Form Validation Class Initialized
INFO - 2019-09-19 20:12:15 --> Email Class Initialized
DEBUG - 2019-09-19 20:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 20:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 20:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 20:12:15 --> Pagination Class Initialized
INFO - 2019-09-19 20:12:15 --> Database Driver Class Initialized
INFO - 2019-09-19 20:12:15 --> Database Driver Class Initialized
INFO - 2019-09-19 20:12:15 --> Controller Class Initialized
INFO - 2019-09-19 20:12:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-19 20:12:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report_ledger.php
INFO - 2019-09-19 20:12:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-19 20:12:15 --> Final output sent to browser
DEBUG - 2019-09-19 20:12:15 --> Total execution time: 0.1704
INFO - 2019-09-19 20:13:30 --> Config Class Initialized
INFO - 2019-09-19 20:13:30 --> Hooks Class Initialized
DEBUG - 2019-09-19 20:13:30 --> UTF-8 Support Enabled
INFO - 2019-09-19 20:13:30 --> Utf8 Class Initialized
INFO - 2019-09-19 20:13:30 --> URI Class Initialized
INFO - 2019-09-19 20:13:30 --> Router Class Initialized
INFO - 2019-09-19 20:13:30 --> Output Class Initialized
INFO - 2019-09-19 20:13:30 --> Security Class Initialized
DEBUG - 2019-09-19 20:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 20:13:30 --> Input Class Initialized
INFO - 2019-09-19 20:13:30 --> Language Class Initialized
INFO - 2019-09-19 20:13:30 --> Loader Class Initialized
INFO - 2019-09-19 20:13:30 --> Helper loaded: url_helper
INFO - 2019-09-19 20:13:30 --> Helper loaded: html_helper
INFO - 2019-09-19 20:13:30 --> Helper loaded: form_helper
INFO - 2019-09-19 20:13:30 --> Helper loaded: cookie_helper
INFO - 2019-09-19 20:13:30 --> Helper loaded: date_helper
INFO - 2019-09-19 20:13:30 --> Form Validation Class Initialized
INFO - 2019-09-19 20:13:30 --> Email Class Initialized
DEBUG - 2019-09-19 20:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 20:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 20:13:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 20:13:30 --> Pagination Class Initialized
INFO - 2019-09-19 20:13:30 --> Database Driver Class Initialized
INFO - 2019-09-19 20:13:30 --> Database Driver Class Initialized
INFO - 2019-09-19 20:13:30 --> Controller Class Initialized
INFO - 2019-09-19 20:13:30 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-19 20:13:30 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-19 20:13:30 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-19 20:13:30 --> Final output sent to browser
DEBUG - 2019-09-19 20:13:30 --> Total execution time: 0.0753
INFO - 2019-09-19 20:13:30 --> Config Class Initialized
INFO - 2019-09-19 20:13:30 --> Hooks Class Initialized
DEBUG - 2019-09-19 20:13:30 --> UTF-8 Support Enabled
INFO - 2019-09-19 20:13:30 --> Utf8 Class Initialized
INFO - 2019-09-19 20:13:30 --> URI Class Initialized
INFO - 2019-09-19 20:13:30 --> Router Class Initialized
INFO - 2019-09-19 20:13:30 --> Output Class Initialized
INFO - 2019-09-19 20:13:30 --> Security Class Initialized
DEBUG - 2019-09-19 20:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 20:13:30 --> Input Class Initialized
INFO - 2019-09-19 20:13:30 --> Language Class Initialized
INFO - 2019-09-19 20:13:30 --> Loader Class Initialized
INFO - 2019-09-19 20:13:30 --> Helper loaded: url_helper
INFO - 2019-09-19 20:13:30 --> Helper loaded: html_helper
INFO - 2019-09-19 20:13:30 --> Helper loaded: form_helper
INFO - 2019-09-19 20:13:30 --> Helper loaded: cookie_helper
INFO - 2019-09-19 20:13:30 --> Helper loaded: date_helper
INFO - 2019-09-19 20:13:30 --> Form Validation Class Initialized
INFO - 2019-09-19 20:13:30 --> Email Class Initialized
DEBUG - 2019-09-19 20:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 20:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 20:13:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 20:13:30 --> Pagination Class Initialized
INFO - 2019-09-19 20:13:30 --> Database Driver Class Initialized
INFO - 2019-09-19 20:13:30 --> Database Driver Class Initialized
INFO - 2019-09-19 20:13:30 --> Controller Class Initialized
INFO - 2019-09-19 20:13:30 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 20:13:30 --> Final output sent to browser
DEBUG - 2019-09-19 20:13:30 --> Total execution time: 0.0698
INFO - 2019-09-19 21:10:44 --> Config Class Initialized
INFO - 2019-09-19 21:10:44 --> Hooks Class Initialized
DEBUG - 2019-09-19 21:10:44 --> UTF-8 Support Enabled
INFO - 2019-09-19 21:10:44 --> Utf8 Class Initialized
INFO - 2019-09-19 21:10:44 --> URI Class Initialized
INFO - 2019-09-19 21:10:44 --> Router Class Initialized
INFO - 2019-09-19 21:10:44 --> Output Class Initialized
INFO - 2019-09-19 21:10:44 --> Security Class Initialized
DEBUG - 2019-09-19 21:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 21:10:44 --> Input Class Initialized
INFO - 2019-09-19 21:10:44 --> Language Class Initialized
INFO - 2019-09-19 21:10:44 --> Loader Class Initialized
INFO - 2019-09-19 21:10:44 --> Helper loaded: url_helper
INFO - 2019-09-19 21:10:44 --> Helper loaded: html_helper
INFO - 2019-09-19 21:10:44 --> Helper loaded: form_helper
INFO - 2019-09-19 21:10:44 --> Helper loaded: cookie_helper
INFO - 2019-09-19 21:10:44 --> Helper loaded: date_helper
INFO - 2019-09-19 21:10:44 --> Form Validation Class Initialized
INFO - 2019-09-19 21:10:44 --> Email Class Initialized
DEBUG - 2019-09-19 21:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 21:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 21:10:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 21:10:44 --> Pagination Class Initialized
INFO - 2019-09-19 21:10:44 --> Database Driver Class Initialized
INFO - 2019-09-19 21:10:44 --> Database Driver Class Initialized
INFO - 2019-09-19 21:10:44 --> Controller Class Initialized
DEBUG - 2019-09-19 21:10:44 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-19 21:10:44 --> Helper loaded: inflector_helper
INFO - 2019-09-19 21:10:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-19 21:10:44 --> Final output sent to browser
DEBUG - 2019-09-19 21:10:44 --> Total execution time: 0.0769
INFO - 2019-09-19 22:10:43 --> Config Class Initialized
INFO - 2019-09-19 22:10:43 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:10:43 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:10:43 --> Utf8 Class Initialized
INFO - 2019-09-19 22:10:43 --> URI Class Initialized
INFO - 2019-09-19 22:10:43 --> Router Class Initialized
INFO - 2019-09-19 22:10:43 --> Output Class Initialized
INFO - 2019-09-19 22:10:43 --> Security Class Initialized
DEBUG - 2019-09-19 22:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:10:43 --> Input Class Initialized
INFO - 2019-09-19 22:10:43 --> Language Class Initialized
INFO - 2019-09-19 22:10:43 --> Loader Class Initialized
INFO - 2019-09-19 22:10:43 --> Helper loaded: url_helper
INFO - 2019-09-19 22:10:43 --> Helper loaded: html_helper
INFO - 2019-09-19 22:10:43 --> Helper loaded: form_helper
INFO - 2019-09-19 22:10:43 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:10:43 --> Helper loaded: date_helper
INFO - 2019-09-19 22:10:43 --> Form Validation Class Initialized
INFO - 2019-09-19 22:10:43 --> Email Class Initialized
DEBUG - 2019-09-19 22:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:10:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:10:44 --> Pagination Class Initialized
INFO - 2019-09-19 22:10:44 --> Database Driver Class Initialized
INFO - 2019-09-19 22:10:44 --> Database Driver Class Initialized
INFO - 2019-09-19 22:10:44 --> Controller Class Initialized
DEBUG - 2019-09-19 22:10:44 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-19 22:10:44 --> Helper loaded: inflector_helper
INFO - 2019-09-19 22:10:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-19 22:10:44 --> Final output sent to browser
DEBUG - 2019-09-19 22:10:44 --> Total execution time: 0.0998
INFO - 2019-09-19 22:19:32 --> Config Class Initialized
INFO - 2019-09-19 22:19:32 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:19:32 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:19:32 --> Utf8 Class Initialized
INFO - 2019-09-19 22:19:32 --> URI Class Initialized
INFO - 2019-09-19 22:19:32 --> Router Class Initialized
INFO - 2019-09-19 22:19:32 --> Output Class Initialized
INFO - 2019-09-19 22:19:32 --> Security Class Initialized
DEBUG - 2019-09-19 22:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:19:32 --> Input Class Initialized
INFO - 2019-09-19 22:19:32 --> Language Class Initialized
INFO - 2019-09-19 22:19:32 --> Loader Class Initialized
INFO - 2019-09-19 22:19:32 --> Helper loaded: url_helper
INFO - 2019-09-19 22:19:32 --> Helper loaded: html_helper
INFO - 2019-09-19 22:19:32 --> Helper loaded: form_helper
INFO - 2019-09-19 22:19:32 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:19:32 --> Helper loaded: date_helper
INFO - 2019-09-19 22:19:32 --> Form Validation Class Initialized
INFO - 2019-09-19 22:19:32 --> Email Class Initialized
DEBUG - 2019-09-19 22:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:19:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:19:32 --> Pagination Class Initialized
INFO - 2019-09-19 22:19:32 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:32 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:32 --> Controller Class Initialized
INFO - 2019-09-19 22:19:32 --> Config Class Initialized
INFO - 2019-09-19 22:19:32 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:19:32 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:19:32 --> Utf8 Class Initialized
INFO - 2019-09-19 22:19:32 --> URI Class Initialized
INFO - 2019-09-19 22:19:32 --> Router Class Initialized
INFO - 2019-09-19 22:19:32 --> Output Class Initialized
INFO - 2019-09-19 22:19:32 --> Security Class Initialized
DEBUG - 2019-09-19 22:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:19:32 --> Input Class Initialized
INFO - 2019-09-19 22:19:32 --> Language Class Initialized
INFO - 2019-09-19 22:19:32 --> Loader Class Initialized
INFO - 2019-09-19 22:19:32 --> Helper loaded: url_helper
INFO - 2019-09-19 22:19:32 --> Helper loaded: html_helper
INFO - 2019-09-19 22:19:32 --> Helper loaded: form_helper
INFO - 2019-09-19 22:19:32 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:19:32 --> Helper loaded: date_helper
INFO - 2019-09-19 22:19:32 --> Form Validation Class Initialized
INFO - 2019-09-19 22:19:32 --> Email Class Initialized
DEBUG - 2019-09-19 22:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:19:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:19:32 --> Pagination Class Initialized
INFO - 2019-09-19 22:19:32 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:32 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:32 --> Controller Class Initialized
INFO - 2019-09-19 22:19:32 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:19:32 --> Final output sent to browser
DEBUG - 2019-09-19 22:19:32 --> Total execution time: 0.0688
INFO - 2019-09-19 22:19:32 --> Config Class Initialized
INFO - 2019-09-19 22:19:32 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:19:32 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:19:32 --> Utf8 Class Initialized
INFO - 2019-09-19 22:19:32 --> URI Class Initialized
INFO - 2019-09-19 22:19:32 --> Router Class Initialized
INFO - 2019-09-19 22:19:32 --> Output Class Initialized
INFO - 2019-09-19 22:19:32 --> Security Class Initialized
DEBUG - 2019-09-19 22:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:19:32 --> Input Class Initialized
INFO - 2019-09-19 22:19:32 --> Language Class Initialized
INFO - 2019-09-19 22:19:32 --> Loader Class Initialized
INFO - 2019-09-19 22:19:32 --> Helper loaded: url_helper
INFO - 2019-09-19 22:19:32 --> Helper loaded: html_helper
INFO - 2019-09-19 22:19:32 --> Helper loaded: form_helper
INFO - 2019-09-19 22:19:32 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:19:32 --> Helper loaded: date_helper
INFO - 2019-09-19 22:19:32 --> Form Validation Class Initialized
INFO - 2019-09-19 22:19:32 --> Email Class Initialized
DEBUG - 2019-09-19 22:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:19:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:19:32 --> Pagination Class Initialized
INFO - 2019-09-19 22:19:32 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:32 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:32 --> Controller Class Initialized
INFO - 2019-09-19 22:19:32 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-19 22:19:32 --> Final output sent to browser
DEBUG - 2019-09-19 22:19:32 --> Total execution time: 0.0734
INFO - 2019-09-19 22:19:32 --> Config Class Initialized
INFO - 2019-09-19 22:19:32 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:19:32 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:19:32 --> Utf8 Class Initialized
INFO - 2019-09-19 22:19:32 --> URI Class Initialized
INFO - 2019-09-19 22:19:32 --> Router Class Initialized
INFO - 2019-09-19 22:19:32 --> Output Class Initialized
INFO - 2019-09-19 22:19:32 --> Security Class Initialized
DEBUG - 2019-09-19 22:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:19:32 --> Input Class Initialized
INFO - 2019-09-19 22:19:32 --> Language Class Initialized
INFO - 2019-09-19 22:19:32 --> Loader Class Initialized
INFO - 2019-09-19 22:19:32 --> Helper loaded: url_helper
INFO - 2019-09-19 22:19:32 --> Helper loaded: html_helper
INFO - 2019-09-19 22:19:32 --> Helper loaded: form_helper
INFO - 2019-09-19 22:19:32 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:19:32 --> Helper loaded: date_helper
INFO - 2019-09-19 22:19:32 --> Form Validation Class Initialized
INFO - 2019-09-19 22:19:32 --> Email Class Initialized
DEBUG - 2019-09-19 22:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:19:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:19:32 --> Pagination Class Initialized
INFO - 2019-09-19 22:19:32 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:32 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:32 --> Controller Class Initialized
INFO - 2019-09-19 22:19:32 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-19 22:19:32 --> Final output sent to browser
DEBUG - 2019-09-19 22:19:32 --> Total execution time: 0.0558
INFO - 2019-09-19 22:19:45 --> Config Class Initialized
INFO - 2019-09-19 22:19:45 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:19:45 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:19:45 --> Utf8 Class Initialized
INFO - 2019-09-19 22:19:45 --> URI Class Initialized
INFO - 2019-09-19 22:19:45 --> Router Class Initialized
INFO - 2019-09-19 22:19:45 --> Output Class Initialized
INFO - 2019-09-19 22:19:45 --> Security Class Initialized
DEBUG - 2019-09-19 22:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:19:45 --> Input Class Initialized
INFO - 2019-09-19 22:19:45 --> Language Class Initialized
INFO - 2019-09-19 22:19:45 --> Loader Class Initialized
INFO - 2019-09-19 22:19:45 --> Helper loaded: url_helper
INFO - 2019-09-19 22:19:45 --> Helper loaded: html_helper
INFO - 2019-09-19 22:19:45 --> Helper loaded: form_helper
INFO - 2019-09-19 22:19:45 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:19:45 --> Helper loaded: date_helper
INFO - 2019-09-19 22:19:46 --> Form Validation Class Initialized
INFO - 2019-09-19 22:19:46 --> Email Class Initialized
DEBUG - 2019-09-19 22:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:19:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:19:46 --> Pagination Class Initialized
INFO - 2019-09-19 22:19:46 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:46 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:46 --> Controller Class Initialized
INFO - 2019-09-19 22:19:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-19 22:19:46 --> Config Class Initialized
INFO - 2019-09-19 22:19:46 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:19:46 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:19:46 --> Utf8 Class Initialized
INFO - 2019-09-19 22:19:46 --> URI Class Initialized
INFO - 2019-09-19 22:19:46 --> Router Class Initialized
INFO - 2019-09-19 22:19:46 --> Output Class Initialized
INFO - 2019-09-19 22:19:46 --> Security Class Initialized
DEBUG - 2019-09-19 22:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:19:46 --> Input Class Initialized
INFO - 2019-09-19 22:19:46 --> Language Class Initialized
INFO - 2019-09-19 22:19:46 --> Loader Class Initialized
INFO - 2019-09-19 22:19:46 --> Helper loaded: url_helper
INFO - 2019-09-19 22:19:46 --> Helper loaded: html_helper
INFO - 2019-09-19 22:19:46 --> Helper loaded: form_helper
INFO - 2019-09-19 22:19:46 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:19:46 --> Helper loaded: date_helper
INFO - 2019-09-19 22:19:46 --> Form Validation Class Initialized
INFO - 2019-09-19 22:19:46 --> Email Class Initialized
DEBUG - 2019-09-19 22:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:19:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:19:46 --> Pagination Class Initialized
INFO - 2019-09-19 22:19:46 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:46 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:46 --> Controller Class Initialized
INFO - 2019-09-19 22:19:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-19 22:19:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-19 22:19:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-19 22:19:46 --> Final output sent to browser
DEBUG - 2019-09-19 22:19:46 --> Total execution time: 0.2272
INFO - 2019-09-19 22:19:46 --> Config Class Initialized
INFO - 2019-09-19 22:19:46 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:19:46 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:19:46 --> Utf8 Class Initialized
INFO - 2019-09-19 22:19:46 --> URI Class Initialized
INFO - 2019-09-19 22:19:46 --> Router Class Initialized
INFO - 2019-09-19 22:19:46 --> Output Class Initialized
INFO - 2019-09-19 22:19:46 --> Security Class Initialized
DEBUG - 2019-09-19 22:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:19:46 --> Input Class Initialized
INFO - 2019-09-19 22:19:46 --> Language Class Initialized
INFO - 2019-09-19 22:19:46 --> Loader Class Initialized
INFO - 2019-09-19 22:19:46 --> Helper loaded: url_helper
INFO - 2019-09-19 22:19:46 --> Helper loaded: html_helper
INFO - 2019-09-19 22:19:46 --> Helper loaded: form_helper
INFO - 2019-09-19 22:19:46 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:19:46 --> Helper loaded: date_helper
INFO - 2019-09-19 22:19:46 --> Form Validation Class Initialized
INFO - 2019-09-19 22:19:46 --> Email Class Initialized
DEBUG - 2019-09-19 22:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:19:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:19:46 --> Pagination Class Initialized
INFO - 2019-09-19 22:19:46 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:46 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:46 --> Controller Class Initialized
INFO - 2019-09-19 22:19:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:19:46 --> Final output sent to browser
DEBUG - 2019-09-19 22:19:46 --> Total execution time: 0.0403
INFO - 2019-09-19 22:19:46 --> Config Class Initialized
INFO - 2019-09-19 22:19:46 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:19:46 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:19:46 --> Utf8 Class Initialized
INFO - 2019-09-19 22:19:46 --> URI Class Initialized
INFO - 2019-09-19 22:19:46 --> Router Class Initialized
INFO - 2019-09-19 22:19:46 --> Output Class Initialized
INFO - 2019-09-19 22:19:46 --> Security Class Initialized
DEBUG - 2019-09-19 22:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:19:46 --> Input Class Initialized
INFO - 2019-09-19 22:19:46 --> Language Class Initialized
INFO - 2019-09-19 22:19:46 --> Loader Class Initialized
INFO - 2019-09-19 22:19:46 --> Helper loaded: url_helper
INFO - 2019-09-19 22:19:46 --> Helper loaded: html_helper
INFO - 2019-09-19 22:19:46 --> Helper loaded: form_helper
INFO - 2019-09-19 22:19:46 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:19:46 --> Helper loaded: date_helper
INFO - 2019-09-19 22:19:46 --> Form Validation Class Initialized
INFO - 2019-09-19 22:19:46 --> Email Class Initialized
DEBUG - 2019-09-19 22:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:19:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:19:46 --> Pagination Class Initialized
INFO - 2019-09-19 22:19:46 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:46 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:46 --> Controller Class Initialized
INFO - 2019-09-19 22:19:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:19:46 --> Final output sent to browser
DEBUG - 2019-09-19 22:19:46 --> Total execution time: 0.0732
INFO - 2019-09-19 22:19:49 --> Config Class Initialized
INFO - 2019-09-19 22:19:49 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:19:49 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:19:49 --> Utf8 Class Initialized
INFO - 2019-09-19 22:19:49 --> URI Class Initialized
INFO - 2019-09-19 22:19:49 --> Router Class Initialized
INFO - 2019-09-19 22:19:49 --> Output Class Initialized
INFO - 2019-09-19 22:19:49 --> Security Class Initialized
DEBUG - 2019-09-19 22:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:19:49 --> Input Class Initialized
INFO - 2019-09-19 22:19:49 --> Language Class Initialized
INFO - 2019-09-19 22:19:49 --> Loader Class Initialized
INFO - 2019-09-19 22:19:49 --> Helper loaded: url_helper
INFO - 2019-09-19 22:19:49 --> Helper loaded: html_helper
INFO - 2019-09-19 22:19:49 --> Helper loaded: form_helper
INFO - 2019-09-19 22:19:49 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:19:49 --> Helper loaded: date_helper
INFO - 2019-09-19 22:19:49 --> Form Validation Class Initialized
INFO - 2019-09-19 22:19:49 --> Email Class Initialized
DEBUG - 2019-09-19 22:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:19:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:19:49 --> Pagination Class Initialized
INFO - 2019-09-19 22:19:49 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:49 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:49 --> Controller Class Initialized
INFO - 2019-09-19 22:19:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-19 22:19:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-19 22:19:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-19 22:19:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-19 22:19:49 --> Final output sent to browser
DEBUG - 2019-09-19 22:19:49 --> Total execution time: 0.1355
INFO - 2019-09-19 22:19:49 --> Config Class Initialized
INFO - 2019-09-19 22:19:49 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:19:49 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:19:49 --> Utf8 Class Initialized
INFO - 2019-09-19 22:19:49 --> URI Class Initialized
INFO - 2019-09-19 22:19:49 --> Router Class Initialized
INFO - 2019-09-19 22:19:49 --> Output Class Initialized
INFO - 2019-09-19 22:19:49 --> Security Class Initialized
DEBUG - 2019-09-19 22:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:19:49 --> Input Class Initialized
INFO - 2019-09-19 22:19:49 --> Language Class Initialized
INFO - 2019-09-19 22:19:49 --> Loader Class Initialized
INFO - 2019-09-19 22:19:49 --> Helper loaded: url_helper
INFO - 2019-09-19 22:19:49 --> Helper loaded: html_helper
INFO - 2019-09-19 22:19:49 --> Helper loaded: form_helper
INFO - 2019-09-19 22:19:49 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:19:49 --> Helper loaded: date_helper
INFO - 2019-09-19 22:19:49 --> Form Validation Class Initialized
INFO - 2019-09-19 22:19:49 --> Email Class Initialized
DEBUG - 2019-09-19 22:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:19:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:19:49 --> Pagination Class Initialized
INFO - 2019-09-19 22:19:49 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:49 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:49 --> Controller Class Initialized
INFO - 2019-09-19 22:19:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:19:49 --> Final output sent to browser
DEBUG - 2019-09-19 22:19:49 --> Total execution time: 0.0716
INFO - 2019-09-19 22:19:49 --> Config Class Initialized
INFO - 2019-09-19 22:19:49 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:19:49 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:19:49 --> Utf8 Class Initialized
INFO - 2019-09-19 22:19:49 --> URI Class Initialized
INFO - 2019-09-19 22:19:49 --> Router Class Initialized
INFO - 2019-09-19 22:19:49 --> Output Class Initialized
INFO - 2019-09-19 22:19:49 --> Security Class Initialized
DEBUG - 2019-09-19 22:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:19:49 --> Input Class Initialized
INFO - 2019-09-19 22:19:49 --> Language Class Initialized
INFO - 2019-09-19 22:19:49 --> Loader Class Initialized
INFO - 2019-09-19 22:19:49 --> Helper loaded: url_helper
INFO - 2019-09-19 22:19:49 --> Helper loaded: html_helper
INFO - 2019-09-19 22:19:49 --> Helper loaded: form_helper
INFO - 2019-09-19 22:19:49 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:19:49 --> Helper loaded: date_helper
INFO - 2019-09-19 22:19:49 --> Form Validation Class Initialized
INFO - 2019-09-19 22:19:49 --> Email Class Initialized
DEBUG - 2019-09-19 22:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:19:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:19:49 --> Pagination Class Initialized
INFO - 2019-09-19 22:19:49 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:49 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:49 --> Controller Class Initialized
INFO - 2019-09-19 22:19:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:19:49 --> Final output sent to browser
DEBUG - 2019-09-19 22:19:49 --> Total execution time: 0.0733
INFO - 2019-09-19 22:19:54 --> Config Class Initialized
INFO - 2019-09-19 22:19:54 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:19:54 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:19:54 --> Utf8 Class Initialized
INFO - 2019-09-19 22:19:54 --> URI Class Initialized
INFO - 2019-09-19 22:19:54 --> Router Class Initialized
INFO - 2019-09-19 22:19:54 --> Output Class Initialized
INFO - 2019-09-19 22:19:54 --> Security Class Initialized
DEBUG - 2019-09-19 22:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:19:54 --> Input Class Initialized
INFO - 2019-09-19 22:19:54 --> Language Class Initialized
INFO - 2019-09-19 22:19:54 --> Loader Class Initialized
INFO - 2019-09-19 22:19:54 --> Helper loaded: url_helper
INFO - 2019-09-19 22:19:54 --> Helper loaded: html_helper
INFO - 2019-09-19 22:19:54 --> Helper loaded: form_helper
INFO - 2019-09-19 22:19:54 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:19:54 --> Helper loaded: date_helper
INFO - 2019-09-19 22:19:54 --> Form Validation Class Initialized
INFO - 2019-09-19 22:19:54 --> Email Class Initialized
DEBUG - 2019-09-19 22:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:19:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:19:54 --> Pagination Class Initialized
INFO - 2019-09-19 22:19:54 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:54 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:54 --> Controller Class Initialized
INFO - 2019-09-19 22:19:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-19 22:19:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-19 22:19:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-19 22:19:54 --> Final output sent to browser
DEBUG - 2019-09-19 22:19:54 --> Total execution time: 0.2561
INFO - 2019-09-19 22:19:54 --> Config Class Initialized
INFO - 2019-09-19 22:19:54 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:19:54 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:19:54 --> Utf8 Class Initialized
INFO - 2019-09-19 22:19:54 --> URI Class Initialized
INFO - 2019-09-19 22:19:54 --> Router Class Initialized
INFO - 2019-09-19 22:19:54 --> Output Class Initialized
INFO - 2019-09-19 22:19:54 --> Security Class Initialized
DEBUG - 2019-09-19 22:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:19:54 --> Input Class Initialized
INFO - 2019-09-19 22:19:54 --> Language Class Initialized
INFO - 2019-09-19 22:19:54 --> Loader Class Initialized
INFO - 2019-09-19 22:19:54 --> Helper loaded: url_helper
INFO - 2019-09-19 22:19:54 --> Helper loaded: html_helper
INFO - 2019-09-19 22:19:54 --> Helper loaded: form_helper
INFO - 2019-09-19 22:19:54 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:19:54 --> Helper loaded: date_helper
INFO - 2019-09-19 22:19:54 --> Form Validation Class Initialized
INFO - 2019-09-19 22:19:54 --> Email Class Initialized
DEBUG - 2019-09-19 22:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:19:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:19:54 --> Pagination Class Initialized
INFO - 2019-09-19 22:19:54 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:54 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:54 --> Controller Class Initialized
INFO - 2019-09-19 22:19:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:19:54 --> Final output sent to browser
DEBUG - 2019-09-19 22:19:54 --> Total execution time: 0.0703
INFO - 2019-09-19 22:19:54 --> Config Class Initialized
INFO - 2019-09-19 22:19:54 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:19:54 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:19:54 --> Utf8 Class Initialized
INFO - 2019-09-19 22:19:54 --> URI Class Initialized
INFO - 2019-09-19 22:19:54 --> Router Class Initialized
INFO - 2019-09-19 22:19:54 --> Output Class Initialized
INFO - 2019-09-19 22:19:54 --> Security Class Initialized
DEBUG - 2019-09-19 22:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:19:54 --> Input Class Initialized
INFO - 2019-09-19 22:19:54 --> Language Class Initialized
INFO - 2019-09-19 22:19:54 --> Loader Class Initialized
INFO - 2019-09-19 22:19:54 --> Helper loaded: url_helper
INFO - 2019-09-19 22:19:54 --> Helper loaded: html_helper
INFO - 2019-09-19 22:19:54 --> Helper loaded: form_helper
INFO - 2019-09-19 22:19:54 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:19:54 --> Helper loaded: date_helper
INFO - 2019-09-19 22:19:54 --> Form Validation Class Initialized
INFO - 2019-09-19 22:19:54 --> Email Class Initialized
DEBUG - 2019-09-19 22:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:19:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:19:54 --> Pagination Class Initialized
INFO - 2019-09-19 22:19:54 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:54 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:54 --> Controller Class Initialized
INFO - 2019-09-19 22:19:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:19:54 --> Final output sent to browser
DEBUG - 2019-09-19 22:19:54 --> Total execution time: 0.0685
INFO - 2019-09-19 22:19:59 --> Config Class Initialized
INFO - 2019-09-19 22:19:59 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:19:59 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:19:59 --> Utf8 Class Initialized
INFO - 2019-09-19 22:19:59 --> URI Class Initialized
INFO - 2019-09-19 22:19:59 --> Router Class Initialized
INFO - 2019-09-19 22:19:59 --> Output Class Initialized
INFO - 2019-09-19 22:19:59 --> Security Class Initialized
DEBUG - 2019-09-19 22:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:19:59 --> Input Class Initialized
INFO - 2019-09-19 22:19:59 --> Language Class Initialized
INFO - 2019-09-19 22:19:59 --> Loader Class Initialized
INFO - 2019-09-19 22:19:59 --> Helper loaded: url_helper
INFO - 2019-09-19 22:19:59 --> Helper loaded: html_helper
INFO - 2019-09-19 22:19:59 --> Helper loaded: form_helper
INFO - 2019-09-19 22:19:59 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:19:59 --> Helper loaded: date_helper
INFO - 2019-09-19 22:19:59 --> Form Validation Class Initialized
INFO - 2019-09-19 22:19:59 --> Email Class Initialized
DEBUG - 2019-09-19 22:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:19:59 --> Pagination Class Initialized
INFO - 2019-09-19 22:19:59 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:59 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:59 --> Controller Class Initialized
INFO - 2019-09-19 22:19:59 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-19 22:19:59 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-19 22:19:59 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-19 22:19:59 --> Final output sent to browser
DEBUG - 2019-09-19 22:19:59 --> Total execution time: 0.0682
INFO - 2019-09-19 22:19:59 --> Config Class Initialized
INFO - 2019-09-19 22:19:59 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:19:59 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:19:59 --> Utf8 Class Initialized
INFO - 2019-09-19 22:19:59 --> URI Class Initialized
INFO - 2019-09-19 22:19:59 --> Router Class Initialized
INFO - 2019-09-19 22:19:59 --> Output Class Initialized
INFO - 2019-09-19 22:19:59 --> Security Class Initialized
DEBUG - 2019-09-19 22:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:19:59 --> Input Class Initialized
INFO - 2019-09-19 22:19:59 --> Language Class Initialized
INFO - 2019-09-19 22:19:59 --> Loader Class Initialized
INFO - 2019-09-19 22:19:59 --> Helper loaded: url_helper
INFO - 2019-09-19 22:19:59 --> Helper loaded: html_helper
INFO - 2019-09-19 22:19:59 --> Helper loaded: form_helper
INFO - 2019-09-19 22:19:59 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:19:59 --> Helper loaded: date_helper
INFO - 2019-09-19 22:19:59 --> Form Validation Class Initialized
INFO - 2019-09-19 22:19:59 --> Email Class Initialized
DEBUG - 2019-09-19 22:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:19:59 --> Pagination Class Initialized
INFO - 2019-09-19 22:19:59 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:59 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:59 --> Controller Class Initialized
INFO - 2019-09-19 22:19:59 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:19:59 --> Final output sent to browser
DEBUG - 2019-09-19 22:19:59 --> Total execution time: 0.0747
INFO - 2019-09-19 22:19:59 --> Config Class Initialized
INFO - 2019-09-19 22:19:59 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:19:59 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:19:59 --> Utf8 Class Initialized
INFO - 2019-09-19 22:19:59 --> URI Class Initialized
INFO - 2019-09-19 22:19:59 --> Router Class Initialized
INFO - 2019-09-19 22:19:59 --> Output Class Initialized
INFO - 2019-09-19 22:19:59 --> Security Class Initialized
DEBUG - 2019-09-19 22:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:19:59 --> Input Class Initialized
INFO - 2019-09-19 22:19:59 --> Language Class Initialized
INFO - 2019-09-19 22:19:59 --> Loader Class Initialized
INFO - 2019-09-19 22:19:59 --> Helper loaded: url_helper
INFO - 2019-09-19 22:19:59 --> Helper loaded: html_helper
INFO - 2019-09-19 22:19:59 --> Helper loaded: form_helper
INFO - 2019-09-19 22:19:59 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:19:59 --> Helper loaded: date_helper
INFO - 2019-09-19 22:19:59 --> Form Validation Class Initialized
INFO - 2019-09-19 22:19:59 --> Email Class Initialized
DEBUG - 2019-09-19 22:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:19:59 --> Pagination Class Initialized
INFO - 2019-09-19 22:19:59 --> Database Driver Class Initialized
INFO - 2019-09-19 22:19:59 --> Database Driver Class Initialized
INFO - 2019-09-19 22:20:00 --> Controller Class Initialized
INFO - 2019-09-19 22:20:00 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:20:00 --> Final output sent to browser
DEBUG - 2019-09-19 22:20:00 --> Total execution time: 0.0674
INFO - 2019-09-19 22:20:07 --> Config Class Initialized
INFO - 2019-09-19 22:20:07 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:20:07 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:20:07 --> Utf8 Class Initialized
INFO - 2019-09-19 22:20:07 --> URI Class Initialized
INFO - 2019-09-19 22:20:07 --> Router Class Initialized
INFO - 2019-09-19 22:20:07 --> Output Class Initialized
INFO - 2019-09-19 22:20:07 --> Security Class Initialized
DEBUG - 2019-09-19 22:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:20:07 --> Input Class Initialized
INFO - 2019-09-19 22:20:07 --> Language Class Initialized
INFO - 2019-09-19 22:20:07 --> Loader Class Initialized
INFO - 2019-09-19 22:20:07 --> Helper loaded: url_helper
INFO - 2019-09-19 22:20:07 --> Helper loaded: html_helper
INFO - 2019-09-19 22:20:07 --> Helper loaded: form_helper
INFO - 2019-09-19 22:20:08 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:20:08 --> Helper loaded: date_helper
INFO - 2019-09-19 22:20:08 --> Form Validation Class Initialized
INFO - 2019-09-19 22:20:08 --> Email Class Initialized
DEBUG - 2019-09-19 22:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:20:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:20:08 --> Pagination Class Initialized
INFO - 2019-09-19 22:20:08 --> Database Driver Class Initialized
INFO - 2019-09-19 22:20:08 --> Database Driver Class Initialized
INFO - 2019-09-19 22:20:08 --> Controller Class Initialized
INFO - 2019-09-19 22:20:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-19 22:20:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-19 22:20:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-19 22:20:08 --> Final output sent to browser
DEBUG - 2019-09-19 22:20:08 --> Total execution time: 0.0694
INFO - 2019-09-19 22:20:08 --> Config Class Initialized
INFO - 2019-09-19 22:20:08 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:20:08 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:20:08 --> Utf8 Class Initialized
INFO - 2019-09-19 22:20:08 --> URI Class Initialized
INFO - 2019-09-19 22:20:08 --> Router Class Initialized
INFO - 2019-09-19 22:20:08 --> Output Class Initialized
INFO - 2019-09-19 22:20:08 --> Security Class Initialized
DEBUG - 2019-09-19 22:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:20:08 --> Input Class Initialized
INFO - 2019-09-19 22:20:08 --> Language Class Initialized
INFO - 2019-09-19 22:20:08 --> Loader Class Initialized
INFO - 2019-09-19 22:20:08 --> Helper loaded: url_helper
INFO - 2019-09-19 22:20:08 --> Helper loaded: html_helper
INFO - 2019-09-19 22:20:08 --> Helper loaded: form_helper
INFO - 2019-09-19 22:20:08 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:20:08 --> Helper loaded: date_helper
INFO - 2019-09-19 22:20:08 --> Form Validation Class Initialized
INFO - 2019-09-19 22:20:08 --> Email Class Initialized
DEBUG - 2019-09-19 22:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:20:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:20:08 --> Pagination Class Initialized
INFO - 2019-09-19 22:20:08 --> Database Driver Class Initialized
INFO - 2019-09-19 22:20:08 --> Database Driver Class Initialized
INFO - 2019-09-19 22:20:08 --> Controller Class Initialized
INFO - 2019-09-19 22:20:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:20:08 --> Final output sent to browser
DEBUG - 2019-09-19 22:20:08 --> Total execution time: 0.0603
INFO - 2019-09-19 22:20:08 --> Config Class Initialized
INFO - 2019-09-19 22:20:08 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:20:08 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:20:08 --> Utf8 Class Initialized
INFO - 2019-09-19 22:20:08 --> URI Class Initialized
INFO - 2019-09-19 22:20:08 --> Router Class Initialized
INFO - 2019-09-19 22:20:08 --> Output Class Initialized
INFO - 2019-09-19 22:20:08 --> Security Class Initialized
DEBUG - 2019-09-19 22:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:20:08 --> Input Class Initialized
INFO - 2019-09-19 22:20:08 --> Language Class Initialized
INFO - 2019-09-19 22:20:08 --> Loader Class Initialized
INFO - 2019-09-19 22:20:08 --> Helper loaded: url_helper
INFO - 2019-09-19 22:20:08 --> Helper loaded: html_helper
INFO - 2019-09-19 22:20:08 --> Helper loaded: form_helper
INFO - 2019-09-19 22:20:08 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:20:08 --> Helper loaded: date_helper
INFO - 2019-09-19 22:20:08 --> Form Validation Class Initialized
INFO - 2019-09-19 22:20:08 --> Email Class Initialized
DEBUG - 2019-09-19 22:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:20:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:20:08 --> Pagination Class Initialized
INFO - 2019-09-19 22:20:08 --> Database Driver Class Initialized
INFO - 2019-09-19 22:20:08 --> Database Driver Class Initialized
INFO - 2019-09-19 22:20:08 --> Controller Class Initialized
INFO - 2019-09-19 22:20:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:20:08 --> Final output sent to browser
DEBUG - 2019-09-19 22:20:08 --> Total execution time: 0.0658
INFO - 2019-09-19 22:20:50 --> Config Class Initialized
INFO - 2019-09-19 22:20:50 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:20:50 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:20:50 --> Utf8 Class Initialized
INFO - 2019-09-19 22:20:50 --> URI Class Initialized
INFO - 2019-09-19 22:20:50 --> Router Class Initialized
INFO - 2019-09-19 22:20:50 --> Output Class Initialized
INFO - 2019-09-19 22:20:50 --> Security Class Initialized
DEBUG - 2019-09-19 22:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:20:50 --> Input Class Initialized
INFO - 2019-09-19 22:20:50 --> Language Class Initialized
INFO - 2019-09-19 22:20:50 --> Loader Class Initialized
INFO - 2019-09-19 22:20:50 --> Helper loaded: url_helper
INFO - 2019-09-19 22:20:50 --> Helper loaded: html_helper
INFO - 2019-09-19 22:20:50 --> Helper loaded: form_helper
INFO - 2019-09-19 22:20:50 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:20:50 --> Helper loaded: date_helper
INFO - 2019-09-19 22:20:50 --> Form Validation Class Initialized
INFO - 2019-09-19 22:20:50 --> Email Class Initialized
DEBUG - 2019-09-19 22:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:20:50 --> Pagination Class Initialized
INFO - 2019-09-19 22:20:50 --> Database Driver Class Initialized
INFO - 2019-09-19 22:20:50 --> Database Driver Class Initialized
INFO - 2019-09-19 22:20:50 --> Controller Class Initialized
INFO - 2019-09-19 22:20:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-19 22:20:54 --> Config Class Initialized
INFO - 2019-09-19 22:20:54 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:20:54 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:20:54 --> Utf8 Class Initialized
INFO - 2019-09-19 22:20:54 --> URI Class Initialized
INFO - 2019-09-19 22:20:54 --> Router Class Initialized
INFO - 2019-09-19 22:20:54 --> Output Class Initialized
INFO - 2019-09-19 22:20:54 --> Security Class Initialized
DEBUG - 2019-09-19 22:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:20:54 --> Input Class Initialized
INFO - 2019-09-19 22:20:54 --> Language Class Initialized
INFO - 2019-09-19 22:20:54 --> Loader Class Initialized
INFO - 2019-09-19 22:20:54 --> Helper loaded: url_helper
INFO - 2019-09-19 22:20:54 --> Helper loaded: html_helper
INFO - 2019-09-19 22:20:54 --> Helper loaded: form_helper
INFO - 2019-09-19 22:20:54 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:20:54 --> Helper loaded: date_helper
INFO - 2019-09-19 22:20:54 --> Form Validation Class Initialized
INFO - 2019-09-19 22:20:54 --> Email Class Initialized
DEBUG - 2019-09-19 22:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:20:54 --> Pagination Class Initialized
INFO - 2019-09-19 22:20:54 --> Database Driver Class Initialized
INFO - 2019-09-19 22:20:54 --> Database Driver Class Initialized
INFO - 2019-09-19 22:20:54 --> Controller Class Initialized
INFO - 2019-09-19 22:20:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-19 22:20:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-19 22:20:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-19 22:20:54 --> Final output sent to browser
DEBUG - 2019-09-19 22:20:54 --> Total execution time: 0.0688
INFO - 2019-09-19 22:20:54 --> Config Class Initialized
INFO - 2019-09-19 22:20:54 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:20:54 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:20:54 --> Utf8 Class Initialized
INFO - 2019-09-19 22:20:54 --> URI Class Initialized
INFO - 2019-09-19 22:20:54 --> Router Class Initialized
INFO - 2019-09-19 22:20:54 --> Output Class Initialized
INFO - 2019-09-19 22:20:54 --> Security Class Initialized
DEBUG - 2019-09-19 22:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:20:54 --> Input Class Initialized
INFO - 2019-09-19 22:20:54 --> Language Class Initialized
INFO - 2019-09-19 22:20:54 --> Loader Class Initialized
INFO - 2019-09-19 22:20:54 --> Helper loaded: url_helper
INFO - 2019-09-19 22:20:54 --> Helper loaded: html_helper
INFO - 2019-09-19 22:20:54 --> Helper loaded: form_helper
INFO - 2019-09-19 22:20:54 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:20:54 --> Helper loaded: date_helper
INFO - 2019-09-19 22:20:54 --> Form Validation Class Initialized
INFO - 2019-09-19 22:20:54 --> Email Class Initialized
DEBUG - 2019-09-19 22:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:20:54 --> Pagination Class Initialized
INFO - 2019-09-19 22:20:54 --> Database Driver Class Initialized
INFO - 2019-09-19 22:20:54 --> Database Driver Class Initialized
INFO - 2019-09-19 22:20:54 --> Controller Class Initialized
INFO - 2019-09-19 22:20:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:20:54 --> Final output sent to browser
DEBUG - 2019-09-19 22:20:54 --> Total execution time: 0.0693
INFO - 2019-09-19 22:20:54 --> Config Class Initialized
INFO - 2019-09-19 22:20:54 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:20:54 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:20:54 --> Utf8 Class Initialized
INFO - 2019-09-19 22:20:54 --> URI Class Initialized
INFO - 2019-09-19 22:20:54 --> Router Class Initialized
INFO - 2019-09-19 22:20:54 --> Output Class Initialized
INFO - 2019-09-19 22:20:54 --> Security Class Initialized
DEBUG - 2019-09-19 22:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:20:54 --> Input Class Initialized
INFO - 2019-09-19 22:20:54 --> Language Class Initialized
INFO - 2019-09-19 22:20:54 --> Loader Class Initialized
INFO - 2019-09-19 22:20:54 --> Helper loaded: url_helper
INFO - 2019-09-19 22:20:54 --> Helper loaded: html_helper
INFO - 2019-09-19 22:20:54 --> Helper loaded: form_helper
INFO - 2019-09-19 22:20:54 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:20:54 --> Helper loaded: date_helper
INFO - 2019-09-19 22:20:54 --> Form Validation Class Initialized
INFO - 2019-09-19 22:20:54 --> Email Class Initialized
DEBUG - 2019-09-19 22:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:20:54 --> Pagination Class Initialized
INFO - 2019-09-19 22:20:54 --> Database Driver Class Initialized
INFO - 2019-09-19 22:20:54 --> Database Driver Class Initialized
INFO - 2019-09-19 22:20:54 --> Controller Class Initialized
INFO - 2019-09-19 22:20:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:20:54 --> Final output sent to browser
DEBUG - 2019-09-19 22:20:54 --> Total execution time: 0.0635
INFO - 2019-09-19 22:30:05 --> Config Class Initialized
INFO - 2019-09-19 22:30:05 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:05 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:05 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:05 --> URI Class Initialized
INFO - 2019-09-19 22:30:05 --> Router Class Initialized
INFO - 2019-09-19 22:30:05 --> Output Class Initialized
INFO - 2019-09-19 22:30:05 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:05 --> Input Class Initialized
INFO - 2019-09-19 22:30:05 --> Language Class Initialized
INFO - 2019-09-19 22:30:05 --> Loader Class Initialized
INFO - 2019-09-19 22:30:05 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:05 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:05 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:05 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:05 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:05 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:05 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:05 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:05 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:05 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:05 --> Controller Class Initialized
INFO - 2019-09-19 22:30:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:30:05 --> Final output sent to browser
DEBUG - 2019-09-19 22:30:05 --> Total execution time: 0.0698
INFO - 2019-09-19 22:30:07 --> Config Class Initialized
INFO - 2019-09-19 22:30:07 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:07 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:07 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:07 --> URI Class Initialized
INFO - 2019-09-19 22:30:07 --> Router Class Initialized
INFO - 2019-09-19 22:30:07 --> Output Class Initialized
INFO - 2019-09-19 22:30:07 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:07 --> Input Class Initialized
INFO - 2019-09-19 22:30:07 --> Language Class Initialized
INFO - 2019-09-19 22:30:07 --> Loader Class Initialized
INFO - 2019-09-19 22:30:07 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:07 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:07 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:07 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:07 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:07 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:07 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:07 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:07 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:07 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:07 --> Controller Class Initialized
INFO - 2019-09-19 22:30:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-19 22:30:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-19 22:30:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-19 22:30:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-19 22:30:07 --> Final output sent to browser
DEBUG - 2019-09-19 22:30:07 --> Total execution time: 0.0779
INFO - 2019-09-19 22:30:07 --> Config Class Initialized
INFO - 2019-09-19 22:30:07 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:07 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:07 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:07 --> URI Class Initialized
INFO - 2019-09-19 22:30:07 --> Router Class Initialized
INFO - 2019-09-19 22:30:07 --> Output Class Initialized
INFO - 2019-09-19 22:30:07 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:07 --> Input Class Initialized
INFO - 2019-09-19 22:30:07 --> Language Class Initialized
INFO - 2019-09-19 22:30:07 --> Loader Class Initialized
INFO - 2019-09-19 22:30:07 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:07 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:07 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:07 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:07 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:07 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:07 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:07 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:07 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:07 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:07 --> Controller Class Initialized
INFO - 2019-09-19 22:30:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:30:07 --> Final output sent to browser
DEBUG - 2019-09-19 22:30:07 --> Total execution time: 0.0666
INFO - 2019-09-19 22:30:07 --> Config Class Initialized
INFO - 2019-09-19 22:30:07 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:07 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:07 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:07 --> URI Class Initialized
INFO - 2019-09-19 22:30:07 --> Router Class Initialized
INFO - 2019-09-19 22:30:07 --> Output Class Initialized
INFO - 2019-09-19 22:30:07 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:07 --> Input Class Initialized
INFO - 2019-09-19 22:30:07 --> Language Class Initialized
INFO - 2019-09-19 22:30:07 --> Loader Class Initialized
INFO - 2019-09-19 22:30:07 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:07 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:07 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:07 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:07 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:07 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:07 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:07 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:07 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:07 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:07 --> Controller Class Initialized
INFO - 2019-09-19 22:30:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:30:07 --> Final output sent to browser
DEBUG - 2019-09-19 22:30:07 --> Total execution time: 0.0676
INFO - 2019-09-19 22:30:09 --> Config Class Initialized
INFO - 2019-09-19 22:30:09 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:09 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:09 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:09 --> URI Class Initialized
INFO - 2019-09-19 22:30:09 --> Router Class Initialized
INFO - 2019-09-19 22:30:09 --> Output Class Initialized
INFO - 2019-09-19 22:30:09 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:09 --> Input Class Initialized
INFO - 2019-09-19 22:30:09 --> Language Class Initialized
INFO - 2019-09-19 22:30:09 --> Loader Class Initialized
INFO - 2019-09-19 22:30:09 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:09 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:09 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:09 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:09 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:09 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:09 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:09 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:09 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:09 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:09 --> Controller Class Initialized
INFO - 2019-09-19 22:30:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-19 22:30:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-19 22:30:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-19 22:30:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-19 22:30:09 --> Final output sent to browser
DEBUG - 2019-09-19 22:30:09 --> Total execution time: 0.0853
INFO - 2019-09-19 22:30:09 --> Config Class Initialized
INFO - 2019-09-19 22:30:09 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:09 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:09 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:09 --> URI Class Initialized
INFO - 2019-09-19 22:30:09 --> Router Class Initialized
INFO - 2019-09-19 22:30:09 --> Output Class Initialized
INFO - 2019-09-19 22:30:09 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:09 --> Input Class Initialized
INFO - 2019-09-19 22:30:09 --> Language Class Initialized
INFO - 2019-09-19 22:30:09 --> Loader Class Initialized
INFO - 2019-09-19 22:30:09 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:09 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:09 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:09 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:09 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:09 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:09 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:09 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:09 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:09 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:09 --> Controller Class Initialized
INFO - 2019-09-19 22:30:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:30:09 --> Final output sent to browser
DEBUG - 2019-09-19 22:30:09 --> Total execution time: 0.0769
INFO - 2019-09-19 22:30:09 --> Config Class Initialized
INFO - 2019-09-19 22:30:09 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:09 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:09 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:09 --> URI Class Initialized
INFO - 2019-09-19 22:30:09 --> Router Class Initialized
INFO - 2019-09-19 22:30:09 --> Output Class Initialized
INFO - 2019-09-19 22:30:09 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:09 --> Input Class Initialized
INFO - 2019-09-19 22:30:09 --> Language Class Initialized
INFO - 2019-09-19 22:30:09 --> Loader Class Initialized
INFO - 2019-09-19 22:30:09 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:09 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:09 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:09 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:09 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:09 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:09 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:09 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:09 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:09 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:09 --> Controller Class Initialized
INFO - 2019-09-19 22:30:10 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:30:10 --> Final output sent to browser
DEBUG - 2019-09-19 22:30:10 --> Total execution time: 0.0800
INFO - 2019-09-19 22:30:11 --> Config Class Initialized
INFO - 2019-09-19 22:30:11 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:11 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:11 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:11 --> URI Class Initialized
INFO - 2019-09-19 22:30:11 --> Router Class Initialized
INFO - 2019-09-19 22:30:11 --> Output Class Initialized
INFO - 2019-09-19 22:30:11 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:11 --> Input Class Initialized
INFO - 2019-09-19 22:30:11 --> Language Class Initialized
INFO - 2019-09-19 22:30:11 --> Loader Class Initialized
INFO - 2019-09-19 22:30:11 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:11 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:11 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:11 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:11 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:11 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:11 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:11 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:11 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:11 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:11 --> Controller Class Initialized
INFO - 2019-09-19 22:30:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-19 22:30:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-19 22:30:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-19 22:30:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-19 22:30:11 --> Final output sent to browser
DEBUG - 2019-09-19 22:30:11 --> Total execution time: 0.1113
INFO - 2019-09-19 22:30:11 --> Config Class Initialized
INFO - 2019-09-19 22:30:11 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:11 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:11 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:11 --> URI Class Initialized
INFO - 2019-09-19 22:30:11 --> Router Class Initialized
INFO - 2019-09-19 22:30:11 --> Output Class Initialized
INFO - 2019-09-19 22:30:11 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:11 --> Input Class Initialized
INFO - 2019-09-19 22:30:11 --> Language Class Initialized
INFO - 2019-09-19 22:30:11 --> Loader Class Initialized
INFO - 2019-09-19 22:30:11 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:11 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:11 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:11 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:11 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:11 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:11 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:11 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:11 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:11 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:11 --> Controller Class Initialized
INFO - 2019-09-19 22:30:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:30:11 --> Final output sent to browser
DEBUG - 2019-09-19 22:30:11 --> Total execution time: 0.0616
INFO - 2019-09-19 22:30:11 --> Config Class Initialized
INFO - 2019-09-19 22:30:11 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:11 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:11 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:11 --> URI Class Initialized
INFO - 2019-09-19 22:30:11 --> Router Class Initialized
INFO - 2019-09-19 22:30:11 --> Output Class Initialized
INFO - 2019-09-19 22:30:11 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:11 --> Input Class Initialized
INFO - 2019-09-19 22:30:11 --> Language Class Initialized
INFO - 2019-09-19 22:30:11 --> Loader Class Initialized
INFO - 2019-09-19 22:30:11 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:11 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:11 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:11 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:11 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:11 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:11 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:11 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:11 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:11 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:11 --> Controller Class Initialized
INFO - 2019-09-19 22:30:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:30:11 --> Final output sent to browser
DEBUG - 2019-09-19 22:30:11 --> Total execution time: 0.0637
INFO - 2019-09-19 22:30:15 --> Config Class Initialized
INFO - 2019-09-19 22:30:15 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:15 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:15 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:15 --> URI Class Initialized
INFO - 2019-09-19 22:30:15 --> Router Class Initialized
INFO - 2019-09-19 22:30:15 --> Output Class Initialized
INFO - 2019-09-19 22:30:15 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:15 --> Input Class Initialized
INFO - 2019-09-19 22:30:15 --> Language Class Initialized
INFO - 2019-09-19 22:30:15 --> Loader Class Initialized
INFO - 2019-09-19 22:30:15 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:15 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:15 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:15 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:15 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:15 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:15 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:15 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:15 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:15 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:15 --> Controller Class Initialized
ERROR - 2019-09-19 22:30:15 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-19 22:30:15 --> Config Class Initialized
INFO - 2019-09-19 22:30:15 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:15 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:15 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:15 --> URI Class Initialized
INFO - 2019-09-19 22:30:15 --> Router Class Initialized
INFO - 2019-09-19 22:30:15 --> Output Class Initialized
INFO - 2019-09-19 22:30:15 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:15 --> Input Class Initialized
INFO - 2019-09-19 22:30:15 --> Language Class Initialized
INFO - 2019-09-19 22:30:15 --> Loader Class Initialized
INFO - 2019-09-19 22:30:15 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:15 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:15 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:15 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:15 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:15 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:15 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:15 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:15 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:15 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:15 --> Controller Class Initialized
ERROR - 2019-09-19 22:30:15 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-19 22:30:16 --> Config Class Initialized
INFO - 2019-09-19 22:30:16 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:16 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:16 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:16 --> URI Class Initialized
INFO - 2019-09-19 22:30:16 --> Router Class Initialized
INFO - 2019-09-19 22:30:16 --> Output Class Initialized
INFO - 2019-09-19 22:30:16 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:16 --> Input Class Initialized
INFO - 2019-09-19 22:30:16 --> Language Class Initialized
INFO - 2019-09-19 22:30:16 --> Loader Class Initialized
INFO - 2019-09-19 22:30:16 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:16 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:16 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:16 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:16 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:16 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:16 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:16 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:16 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:16 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:16 --> Controller Class Initialized
ERROR - 2019-09-19 22:30:16 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-19 22:30:16 --> Config Class Initialized
INFO - 2019-09-19 22:30:16 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:16 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:16 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:16 --> URI Class Initialized
INFO - 2019-09-19 22:30:16 --> Router Class Initialized
INFO - 2019-09-19 22:30:16 --> Output Class Initialized
INFO - 2019-09-19 22:30:16 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:16 --> Input Class Initialized
INFO - 2019-09-19 22:30:16 --> Language Class Initialized
INFO - 2019-09-19 22:30:16 --> Loader Class Initialized
INFO - 2019-09-19 22:30:16 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:16 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:16 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:16 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:16 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:16 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:16 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:16 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:16 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:16 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:16 --> Controller Class Initialized
ERROR - 2019-09-19 22:30:16 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-19 22:30:16 --> Config Class Initialized
INFO - 2019-09-19 22:30:16 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:16 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:16 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:16 --> URI Class Initialized
INFO - 2019-09-19 22:30:16 --> Router Class Initialized
INFO - 2019-09-19 22:30:16 --> Output Class Initialized
INFO - 2019-09-19 22:30:16 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:16 --> Input Class Initialized
INFO - 2019-09-19 22:30:16 --> Language Class Initialized
INFO - 2019-09-19 22:30:17 --> Loader Class Initialized
INFO - 2019-09-19 22:30:17 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:17 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:17 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:17 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:17 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:17 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:17 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:17 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:17 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:17 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:17 --> Controller Class Initialized
ERROR - 2019-09-19 22:30:17 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-19 22:30:17 --> Config Class Initialized
INFO - 2019-09-19 22:30:17 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:17 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:17 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:17 --> URI Class Initialized
INFO - 2019-09-19 22:30:17 --> Router Class Initialized
INFO - 2019-09-19 22:30:17 --> Output Class Initialized
INFO - 2019-09-19 22:30:17 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:17 --> Input Class Initialized
INFO - 2019-09-19 22:30:17 --> Language Class Initialized
INFO - 2019-09-19 22:30:17 --> Loader Class Initialized
INFO - 2019-09-19 22:30:17 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:17 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:17 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:17 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:17 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:17 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:17 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:17 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:17 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:17 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:17 --> Controller Class Initialized
ERROR - 2019-09-19 22:30:17 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-19 22:30:29 --> Config Class Initialized
INFO - 2019-09-19 22:30:29 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:29 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:29 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:29 --> URI Class Initialized
INFO - 2019-09-19 22:30:29 --> Router Class Initialized
INFO - 2019-09-19 22:30:29 --> Output Class Initialized
INFO - 2019-09-19 22:30:29 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:29 --> Input Class Initialized
INFO - 2019-09-19 22:30:29 --> Language Class Initialized
INFO - 2019-09-19 22:30:29 --> Loader Class Initialized
INFO - 2019-09-19 22:30:29 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:29 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:29 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:29 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:29 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:29 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:29 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:29 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:29 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:29 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:29 --> Controller Class Initialized
INFO - 2019-09-19 22:30:29 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-19 22:30:29 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-19 22:30:29 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-19 22:30:29 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-19 22:30:29 --> Final output sent to browser
DEBUG - 2019-09-19 22:30:29 --> Total execution time: 0.0798
INFO - 2019-09-19 22:30:29 --> Config Class Initialized
INFO - 2019-09-19 22:30:29 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:29 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:29 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:29 --> URI Class Initialized
INFO - 2019-09-19 22:30:29 --> Router Class Initialized
INFO - 2019-09-19 22:30:29 --> Output Class Initialized
INFO - 2019-09-19 22:30:29 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:29 --> Input Class Initialized
INFO - 2019-09-19 22:30:29 --> Language Class Initialized
INFO - 2019-09-19 22:30:29 --> Loader Class Initialized
INFO - 2019-09-19 22:30:29 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:29 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:29 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:29 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:29 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:29 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:29 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:29 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:29 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:29 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:29 --> Controller Class Initialized
INFO - 2019-09-19 22:30:29 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:30:29 --> Final output sent to browser
DEBUG - 2019-09-19 22:30:29 --> Total execution time: 0.0750
INFO - 2019-09-19 22:30:29 --> Config Class Initialized
INFO - 2019-09-19 22:30:29 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:29 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:29 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:29 --> URI Class Initialized
INFO - 2019-09-19 22:30:29 --> Router Class Initialized
INFO - 2019-09-19 22:30:29 --> Output Class Initialized
INFO - 2019-09-19 22:30:29 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:29 --> Input Class Initialized
INFO - 2019-09-19 22:30:29 --> Language Class Initialized
INFO - 2019-09-19 22:30:29 --> Loader Class Initialized
INFO - 2019-09-19 22:30:29 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:29 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:29 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:29 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:29 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:29 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:29 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:29 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:29 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:29 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:29 --> Controller Class Initialized
INFO - 2019-09-19 22:30:29 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:30:29 --> Final output sent to browser
DEBUG - 2019-09-19 22:30:29 --> Total execution time: 0.0930
INFO - 2019-09-19 22:30:36 --> Config Class Initialized
INFO - 2019-09-19 22:30:36 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:36 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:36 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:36 --> URI Class Initialized
INFO - 2019-09-19 22:30:36 --> Router Class Initialized
INFO - 2019-09-19 22:30:36 --> Output Class Initialized
INFO - 2019-09-19 22:30:36 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:36 --> Input Class Initialized
INFO - 2019-09-19 22:30:36 --> Language Class Initialized
INFO - 2019-09-19 22:30:36 --> Loader Class Initialized
INFO - 2019-09-19 22:30:36 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:36 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:36 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:36 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:36 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:36 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:36 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:36 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:36 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:36 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:36 --> Controller Class Initialized
ERROR - 2019-09-19 22:30:36 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-19 22:30:36 --> Config Class Initialized
INFO - 2019-09-19 22:30:36 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:36 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:36 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:36 --> URI Class Initialized
INFO - 2019-09-19 22:30:36 --> Router Class Initialized
INFO - 2019-09-19 22:30:36 --> Output Class Initialized
INFO - 2019-09-19 22:30:36 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:36 --> Input Class Initialized
INFO - 2019-09-19 22:30:36 --> Language Class Initialized
INFO - 2019-09-19 22:30:36 --> Loader Class Initialized
INFO - 2019-09-19 22:30:36 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:36 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:36 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:36 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:36 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:36 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:36 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:36 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:36 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:36 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:36 --> Controller Class Initialized
ERROR - 2019-09-19 22:30:36 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-19 22:30:37 --> Config Class Initialized
INFO - 2019-09-19 22:30:37 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:37 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:37 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:37 --> URI Class Initialized
INFO - 2019-09-19 22:30:37 --> Router Class Initialized
INFO - 2019-09-19 22:30:37 --> Output Class Initialized
INFO - 2019-09-19 22:30:37 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:37 --> Input Class Initialized
INFO - 2019-09-19 22:30:37 --> Language Class Initialized
INFO - 2019-09-19 22:30:37 --> Loader Class Initialized
INFO - 2019-09-19 22:30:37 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:37 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:37 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:37 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:37 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:37 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:37 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:37 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:37 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:37 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:37 --> Controller Class Initialized
ERROR - 2019-09-19 22:30:37 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-19 22:30:37 --> Config Class Initialized
INFO - 2019-09-19 22:30:37 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:37 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:37 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:37 --> URI Class Initialized
INFO - 2019-09-19 22:30:37 --> Router Class Initialized
INFO - 2019-09-19 22:30:37 --> Output Class Initialized
INFO - 2019-09-19 22:30:37 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:37 --> Input Class Initialized
INFO - 2019-09-19 22:30:37 --> Language Class Initialized
INFO - 2019-09-19 22:30:37 --> Loader Class Initialized
INFO - 2019-09-19 22:30:37 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:37 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:37 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:37 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:37 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:37 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:37 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:37 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:37 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:37 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:37 --> Controller Class Initialized
ERROR - 2019-09-19 22:30:37 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-19 22:30:37 --> Config Class Initialized
INFO - 2019-09-19 22:30:37 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:37 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:37 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:37 --> URI Class Initialized
INFO - 2019-09-19 22:30:37 --> Router Class Initialized
INFO - 2019-09-19 22:30:37 --> Output Class Initialized
INFO - 2019-09-19 22:30:37 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:37 --> Input Class Initialized
INFO - 2019-09-19 22:30:37 --> Language Class Initialized
INFO - 2019-09-19 22:30:37 --> Loader Class Initialized
INFO - 2019-09-19 22:30:37 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:37 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:37 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:37 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:37 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:37 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:37 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:37 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:37 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:37 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:37 --> Controller Class Initialized
ERROR - 2019-09-19 22:30:37 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-19 22:30:37 --> Config Class Initialized
INFO - 2019-09-19 22:30:37 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:37 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:37 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:37 --> URI Class Initialized
INFO - 2019-09-19 22:30:37 --> Router Class Initialized
INFO - 2019-09-19 22:30:37 --> Output Class Initialized
INFO - 2019-09-19 22:30:37 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:37 --> Input Class Initialized
INFO - 2019-09-19 22:30:37 --> Language Class Initialized
INFO - 2019-09-19 22:30:37 --> Loader Class Initialized
INFO - 2019-09-19 22:30:37 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:37 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:37 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:37 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:37 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:37 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:38 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:38 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:38 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:38 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:38 --> Controller Class Initialized
ERROR - 2019-09-19 22:30:38 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-19 22:30:39 --> Config Class Initialized
INFO - 2019-09-19 22:30:39 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:39 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:39 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:39 --> URI Class Initialized
INFO - 2019-09-19 22:30:39 --> Router Class Initialized
INFO - 2019-09-19 22:30:39 --> Output Class Initialized
INFO - 2019-09-19 22:30:39 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:39 --> Input Class Initialized
INFO - 2019-09-19 22:30:39 --> Language Class Initialized
INFO - 2019-09-19 22:30:39 --> Loader Class Initialized
INFO - 2019-09-19 22:30:39 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:39 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:39 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:39 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:39 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:39 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:39 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:39 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:39 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:39 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:39 --> Controller Class Initialized
ERROR - 2019-09-19 22:30:39 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-19 22:30:39 --> Config Class Initialized
INFO - 2019-09-19 22:30:39 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:39 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:39 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:39 --> URI Class Initialized
INFO - 2019-09-19 22:30:39 --> Router Class Initialized
INFO - 2019-09-19 22:30:39 --> Output Class Initialized
INFO - 2019-09-19 22:30:39 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:39 --> Input Class Initialized
INFO - 2019-09-19 22:30:39 --> Language Class Initialized
INFO - 2019-09-19 22:30:39 --> Loader Class Initialized
INFO - 2019-09-19 22:30:39 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:39 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:39 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:39 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:39 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:39 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:39 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:39 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:39 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:39 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:39 --> Controller Class Initialized
ERROR - 2019-09-19 22:30:39 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-19 22:30:40 --> Config Class Initialized
INFO - 2019-09-19 22:30:40 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:40 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:40 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:40 --> URI Class Initialized
INFO - 2019-09-19 22:30:40 --> Router Class Initialized
INFO - 2019-09-19 22:30:40 --> Output Class Initialized
INFO - 2019-09-19 22:30:40 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:40 --> Input Class Initialized
INFO - 2019-09-19 22:30:40 --> Language Class Initialized
INFO - 2019-09-19 22:30:40 --> Loader Class Initialized
INFO - 2019-09-19 22:30:40 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:40 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:40 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:40 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:40 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:40 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:40 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:40 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:40 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:40 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:40 --> Controller Class Initialized
ERROR - 2019-09-19 22:30:40 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-19 22:30:40 --> Config Class Initialized
INFO - 2019-09-19 22:30:40 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:40 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:40 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:40 --> URI Class Initialized
INFO - 2019-09-19 22:30:40 --> Router Class Initialized
INFO - 2019-09-19 22:30:40 --> Output Class Initialized
INFO - 2019-09-19 22:30:40 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:40 --> Input Class Initialized
INFO - 2019-09-19 22:30:40 --> Language Class Initialized
INFO - 2019-09-19 22:30:40 --> Loader Class Initialized
INFO - 2019-09-19 22:30:40 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:40 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:40 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:40 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:40 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:40 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:40 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:40 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:40 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:40 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:40 --> Controller Class Initialized
ERROR - 2019-09-19 22:30:41 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-19 22:30:41 --> Config Class Initialized
INFO - 2019-09-19 22:30:41 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:41 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:41 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:42 --> URI Class Initialized
INFO - 2019-09-19 22:30:42 --> Router Class Initialized
INFO - 2019-09-19 22:30:42 --> Output Class Initialized
INFO - 2019-09-19 22:30:42 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:42 --> Input Class Initialized
INFO - 2019-09-19 22:30:42 --> Language Class Initialized
INFO - 2019-09-19 22:30:42 --> Loader Class Initialized
INFO - 2019-09-19 22:30:42 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:42 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:42 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:42 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:42 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:42 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:42 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:42 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:42 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:42 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:42 --> Controller Class Initialized
ERROR - 2019-09-19 22:30:42 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-19 22:30:46 --> Config Class Initialized
INFO - 2019-09-19 22:30:46 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:46 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:46 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:46 --> URI Class Initialized
INFO - 2019-09-19 22:30:46 --> Router Class Initialized
INFO - 2019-09-19 22:30:46 --> Output Class Initialized
INFO - 2019-09-19 22:30:46 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:46 --> Input Class Initialized
INFO - 2019-09-19 22:30:46 --> Language Class Initialized
INFO - 2019-09-19 22:30:46 --> Loader Class Initialized
INFO - 2019-09-19 22:30:46 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:46 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:46 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:46 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:46 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:46 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:46 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:46 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:46 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:46 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:46 --> Controller Class Initialized
INFO - 2019-09-19 22:30:46 --> Final output sent to browser
DEBUG - 2019-09-19 22:30:46 --> Total execution time: 0.0837
INFO - 2019-09-19 22:30:52 --> Config Class Initialized
INFO - 2019-09-19 22:30:52 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:52 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:52 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:52 --> URI Class Initialized
INFO - 2019-09-19 22:30:52 --> Router Class Initialized
INFO - 2019-09-19 22:30:52 --> Output Class Initialized
INFO - 2019-09-19 22:30:52 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:52 --> Input Class Initialized
INFO - 2019-09-19 22:30:52 --> Language Class Initialized
INFO - 2019-09-19 22:30:52 --> Loader Class Initialized
INFO - 2019-09-19 22:30:52 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:52 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:52 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:52 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:52 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:52 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:52 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:52 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:52 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:52 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:52 --> Controller Class Initialized
INFO - 2019-09-19 22:30:52 --> Final output sent to browser
DEBUG - 2019-09-19 22:30:52 --> Total execution time: 0.1109
INFO - 2019-09-19 22:30:56 --> Config Class Initialized
INFO - 2019-09-19 22:30:56 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:30:56 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:30:56 --> Utf8 Class Initialized
INFO - 2019-09-19 22:30:56 --> URI Class Initialized
INFO - 2019-09-19 22:30:56 --> Router Class Initialized
INFO - 2019-09-19 22:30:56 --> Output Class Initialized
INFO - 2019-09-19 22:30:56 --> Security Class Initialized
DEBUG - 2019-09-19 22:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:30:56 --> Input Class Initialized
INFO - 2019-09-19 22:30:56 --> Language Class Initialized
INFO - 2019-09-19 22:30:56 --> Loader Class Initialized
INFO - 2019-09-19 22:30:56 --> Helper loaded: url_helper
INFO - 2019-09-19 22:30:56 --> Helper loaded: html_helper
INFO - 2019-09-19 22:30:56 --> Helper loaded: form_helper
INFO - 2019-09-19 22:30:56 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:30:56 --> Helper loaded: date_helper
INFO - 2019-09-19 22:30:56 --> Form Validation Class Initialized
INFO - 2019-09-19 22:30:56 --> Email Class Initialized
DEBUG - 2019-09-19 22:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:30:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:30:56 --> Pagination Class Initialized
INFO - 2019-09-19 22:30:56 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:56 --> Database Driver Class Initialized
INFO - 2019-09-19 22:30:56 --> Controller Class Initialized
INFO - 2019-09-19 22:30:56 --> Final output sent to browser
DEBUG - 2019-09-19 22:30:56 --> Total execution time: 0.0582
INFO - 2019-09-19 22:31:08 --> Config Class Initialized
INFO - 2019-09-19 22:31:08 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:31:08 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:31:08 --> Utf8 Class Initialized
INFO - 2019-09-19 22:31:08 --> URI Class Initialized
INFO - 2019-09-19 22:31:08 --> Router Class Initialized
INFO - 2019-09-19 22:31:08 --> Output Class Initialized
INFO - 2019-09-19 22:31:08 --> Security Class Initialized
DEBUG - 2019-09-19 22:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:31:08 --> Input Class Initialized
INFO - 2019-09-19 22:31:08 --> Language Class Initialized
INFO - 2019-09-19 22:31:08 --> Loader Class Initialized
INFO - 2019-09-19 22:31:08 --> Helper loaded: url_helper
INFO - 2019-09-19 22:31:08 --> Helper loaded: html_helper
INFO - 2019-09-19 22:31:08 --> Helper loaded: form_helper
INFO - 2019-09-19 22:31:08 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:31:08 --> Helper loaded: date_helper
INFO - 2019-09-19 22:31:08 --> Form Validation Class Initialized
INFO - 2019-09-19 22:31:08 --> Email Class Initialized
DEBUG - 2019-09-19 22:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:31:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:31:08 --> Pagination Class Initialized
INFO - 2019-09-19 22:31:08 --> Database Driver Class Initialized
INFO - 2019-09-19 22:31:08 --> Database Driver Class Initialized
INFO - 2019-09-19 22:31:08 --> Controller Class Initialized
INFO - 2019-09-19 22:31:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-19 22:31:09 --> Config Class Initialized
INFO - 2019-09-19 22:31:09 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:31:09 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:31:09 --> Utf8 Class Initialized
INFO - 2019-09-19 22:31:09 --> URI Class Initialized
INFO - 2019-09-19 22:31:09 --> Router Class Initialized
INFO - 2019-09-19 22:31:09 --> Output Class Initialized
INFO - 2019-09-19 22:31:09 --> Security Class Initialized
DEBUG - 2019-09-19 22:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:31:09 --> Input Class Initialized
INFO - 2019-09-19 22:31:09 --> Language Class Initialized
INFO - 2019-09-19 22:31:09 --> Loader Class Initialized
INFO - 2019-09-19 22:31:09 --> Helper loaded: url_helper
INFO - 2019-09-19 22:31:09 --> Helper loaded: html_helper
INFO - 2019-09-19 22:31:09 --> Helper loaded: form_helper
INFO - 2019-09-19 22:31:09 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:31:09 --> Helper loaded: date_helper
INFO - 2019-09-19 22:31:09 --> Form Validation Class Initialized
INFO - 2019-09-19 22:31:09 --> Email Class Initialized
DEBUG - 2019-09-19 22:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:31:09 --> Pagination Class Initialized
INFO - 2019-09-19 22:31:09 --> Database Driver Class Initialized
INFO - 2019-09-19 22:31:09 --> Database Driver Class Initialized
INFO - 2019-09-19 22:31:09 --> Controller Class Initialized
INFO - 2019-09-19 22:31:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-19 22:31:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-19 22:31:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/checkin.php
INFO - 2019-09-19 22:31:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-19 22:31:09 --> Final output sent to browser
DEBUG - 2019-09-19 22:31:09 --> Total execution time: 0.0665
INFO - 2019-09-19 22:31:09 --> Config Class Initialized
INFO - 2019-09-19 22:31:09 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:31:09 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:31:09 --> Utf8 Class Initialized
INFO - 2019-09-19 22:31:09 --> URI Class Initialized
INFO - 2019-09-19 22:31:09 --> Router Class Initialized
INFO - 2019-09-19 22:31:09 --> Output Class Initialized
INFO - 2019-09-19 22:31:09 --> Security Class Initialized
DEBUG - 2019-09-19 22:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:31:09 --> Input Class Initialized
INFO - 2019-09-19 22:31:09 --> Language Class Initialized
INFO - 2019-09-19 22:31:09 --> Loader Class Initialized
INFO - 2019-09-19 22:31:09 --> Helper loaded: url_helper
INFO - 2019-09-19 22:31:09 --> Helper loaded: html_helper
INFO - 2019-09-19 22:31:09 --> Helper loaded: form_helper
INFO - 2019-09-19 22:31:09 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:31:09 --> Helper loaded: date_helper
INFO - 2019-09-19 22:31:09 --> Form Validation Class Initialized
INFO - 2019-09-19 22:31:09 --> Email Class Initialized
DEBUG - 2019-09-19 22:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:31:09 --> Pagination Class Initialized
INFO - 2019-09-19 22:31:09 --> Database Driver Class Initialized
INFO - 2019-09-19 22:31:09 --> Database Driver Class Initialized
INFO - 2019-09-19 22:31:09 --> Controller Class Initialized
INFO - 2019-09-19 22:31:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:31:09 --> Final output sent to browser
DEBUG - 2019-09-19 22:31:09 --> Total execution time: 0.0775
INFO - 2019-09-19 22:31:09 --> Config Class Initialized
INFO - 2019-09-19 22:31:09 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:31:09 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:31:09 --> Utf8 Class Initialized
INFO - 2019-09-19 22:31:09 --> URI Class Initialized
INFO - 2019-09-19 22:31:09 --> Router Class Initialized
INFO - 2019-09-19 22:31:09 --> Output Class Initialized
INFO - 2019-09-19 22:31:09 --> Security Class Initialized
DEBUG - 2019-09-19 22:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:31:09 --> Input Class Initialized
INFO - 2019-09-19 22:31:09 --> Language Class Initialized
INFO - 2019-09-19 22:31:09 --> Loader Class Initialized
INFO - 2019-09-19 22:31:09 --> Helper loaded: url_helper
INFO - 2019-09-19 22:31:09 --> Helper loaded: html_helper
INFO - 2019-09-19 22:31:09 --> Helper loaded: form_helper
INFO - 2019-09-19 22:31:09 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:31:09 --> Helper loaded: date_helper
INFO - 2019-09-19 22:31:09 --> Form Validation Class Initialized
INFO - 2019-09-19 22:31:09 --> Email Class Initialized
DEBUG - 2019-09-19 22:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:31:09 --> Pagination Class Initialized
INFO - 2019-09-19 22:31:09 --> Database Driver Class Initialized
INFO - 2019-09-19 22:31:09 --> Database Driver Class Initialized
INFO - 2019-09-19 22:31:09 --> Controller Class Initialized
INFO - 2019-09-19 22:31:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:31:09 --> Final output sent to browser
DEBUG - 2019-09-19 22:31:09 --> Total execution time: 0.0726
INFO - 2019-09-19 22:31:11 --> Config Class Initialized
INFO - 2019-09-19 22:31:11 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:31:11 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:31:11 --> Utf8 Class Initialized
INFO - 2019-09-19 22:31:11 --> URI Class Initialized
INFO - 2019-09-19 22:31:11 --> Router Class Initialized
INFO - 2019-09-19 22:31:11 --> Output Class Initialized
INFO - 2019-09-19 22:31:11 --> Security Class Initialized
DEBUG - 2019-09-19 22:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:31:11 --> Input Class Initialized
INFO - 2019-09-19 22:31:11 --> Language Class Initialized
INFO - 2019-09-19 22:31:11 --> Loader Class Initialized
INFO - 2019-09-19 22:31:11 --> Helper loaded: url_helper
INFO - 2019-09-19 22:31:11 --> Helper loaded: html_helper
INFO - 2019-09-19 22:31:11 --> Helper loaded: form_helper
INFO - 2019-09-19 22:31:11 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:31:11 --> Helper loaded: date_helper
INFO - 2019-09-19 22:31:11 --> Form Validation Class Initialized
INFO - 2019-09-19 22:31:11 --> Email Class Initialized
DEBUG - 2019-09-19 22:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:31:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:31:11 --> Pagination Class Initialized
INFO - 2019-09-19 22:31:11 --> Database Driver Class Initialized
INFO - 2019-09-19 22:31:11 --> Database Driver Class Initialized
INFO - 2019-09-19 22:31:11 --> Controller Class Initialized
INFO - 2019-09-19 22:31:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-19 22:31:11 --> Config Class Initialized
INFO - 2019-09-19 22:31:11 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:31:11 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:31:11 --> Utf8 Class Initialized
INFO - 2019-09-19 22:31:11 --> URI Class Initialized
INFO - 2019-09-19 22:31:11 --> Router Class Initialized
INFO - 2019-09-19 22:31:11 --> Output Class Initialized
INFO - 2019-09-19 22:31:11 --> Security Class Initialized
DEBUG - 2019-09-19 22:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:31:11 --> Input Class Initialized
INFO - 2019-09-19 22:31:11 --> Language Class Initialized
INFO - 2019-09-19 22:31:11 --> Loader Class Initialized
INFO - 2019-09-19 22:31:11 --> Helper loaded: url_helper
INFO - 2019-09-19 22:31:11 --> Helper loaded: html_helper
INFO - 2019-09-19 22:31:11 --> Helper loaded: form_helper
INFO - 2019-09-19 22:31:11 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:31:11 --> Helper loaded: date_helper
INFO - 2019-09-19 22:31:11 --> Form Validation Class Initialized
INFO - 2019-09-19 22:31:11 --> Email Class Initialized
DEBUG - 2019-09-19 22:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:31:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:31:11 --> Pagination Class Initialized
INFO - 2019-09-19 22:31:11 --> Database Driver Class Initialized
INFO - 2019-09-19 22:31:11 --> Database Driver Class Initialized
INFO - 2019-09-19 22:31:11 --> Controller Class Initialized
INFO - 2019-09-19 22:31:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-19 22:31:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-19 22:31:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/checkin.php
INFO - 2019-09-19 22:31:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-19 22:31:11 --> Final output sent to browser
DEBUG - 2019-09-19 22:31:11 --> Total execution time: 0.0620
INFO - 2019-09-19 22:31:11 --> Config Class Initialized
INFO - 2019-09-19 22:31:11 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:31:11 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:31:11 --> Utf8 Class Initialized
INFO - 2019-09-19 22:31:11 --> URI Class Initialized
INFO - 2019-09-19 22:31:11 --> Router Class Initialized
INFO - 2019-09-19 22:31:11 --> Output Class Initialized
INFO - 2019-09-19 22:31:11 --> Security Class Initialized
DEBUG - 2019-09-19 22:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:31:11 --> Input Class Initialized
INFO - 2019-09-19 22:31:11 --> Language Class Initialized
INFO - 2019-09-19 22:31:11 --> Loader Class Initialized
INFO - 2019-09-19 22:31:11 --> Helper loaded: url_helper
INFO - 2019-09-19 22:31:11 --> Helper loaded: html_helper
INFO - 2019-09-19 22:31:11 --> Helper loaded: form_helper
INFO - 2019-09-19 22:31:11 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:31:11 --> Helper loaded: date_helper
INFO - 2019-09-19 22:31:11 --> Form Validation Class Initialized
INFO - 2019-09-19 22:31:11 --> Email Class Initialized
DEBUG - 2019-09-19 22:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:31:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:31:11 --> Pagination Class Initialized
INFO - 2019-09-19 22:31:11 --> Database Driver Class Initialized
INFO - 2019-09-19 22:31:11 --> Database Driver Class Initialized
INFO - 2019-09-19 22:31:11 --> Controller Class Initialized
INFO - 2019-09-19 22:31:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:31:11 --> Final output sent to browser
DEBUG - 2019-09-19 22:31:11 --> Total execution time: 0.0618
INFO - 2019-09-19 22:31:11 --> Config Class Initialized
INFO - 2019-09-19 22:31:11 --> Hooks Class Initialized
DEBUG - 2019-09-19 22:31:11 --> UTF-8 Support Enabled
INFO - 2019-09-19 22:31:11 --> Utf8 Class Initialized
INFO - 2019-09-19 22:31:11 --> URI Class Initialized
INFO - 2019-09-19 22:31:11 --> Router Class Initialized
INFO - 2019-09-19 22:31:11 --> Output Class Initialized
INFO - 2019-09-19 22:31:11 --> Security Class Initialized
DEBUG - 2019-09-19 22:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-19 22:31:11 --> Input Class Initialized
INFO - 2019-09-19 22:31:11 --> Language Class Initialized
INFO - 2019-09-19 22:31:11 --> Loader Class Initialized
INFO - 2019-09-19 22:31:11 --> Helper loaded: url_helper
INFO - 2019-09-19 22:31:11 --> Helper loaded: html_helper
INFO - 2019-09-19 22:31:11 --> Helper loaded: form_helper
INFO - 2019-09-19 22:31:11 --> Helper loaded: cookie_helper
INFO - 2019-09-19 22:31:11 --> Helper loaded: date_helper
INFO - 2019-09-19 22:31:11 --> Form Validation Class Initialized
INFO - 2019-09-19 22:31:11 --> Email Class Initialized
DEBUG - 2019-09-19 22:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-19 22:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-19 22:31:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-19 22:31:11 --> Pagination Class Initialized
INFO - 2019-09-19 22:31:11 --> Database Driver Class Initialized
INFO - 2019-09-19 22:31:11 --> Database Driver Class Initialized
INFO - 2019-09-19 22:31:11 --> Controller Class Initialized
INFO - 2019-09-19 22:31:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-19 22:31:11 --> Final output sent to browser
DEBUG - 2019-09-19 22:31:11 --> Total execution time: 0.0728
