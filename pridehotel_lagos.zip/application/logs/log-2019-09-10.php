<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-10 12:03:16 --> Config Class Initialized
INFO - 2019-09-10 12:03:16 --> Hooks Class Initialized
DEBUG - 2019-09-10 12:03:16 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:03:16 --> Utf8 Class Initialized
INFO - 2019-09-10 12:03:16 --> URI Class Initialized
INFO - 2019-09-10 12:03:16 --> Router Class Initialized
INFO - 2019-09-10 12:03:16 --> Output Class Initialized
INFO - 2019-09-10 12:03:16 --> Security Class Initialized
DEBUG - 2019-09-10 12:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:03:16 --> Input Class Initialized
INFO - 2019-09-10 12:03:16 --> Language Class Initialized
INFO - 2019-09-10 12:03:16 --> Loader Class Initialized
INFO - 2019-09-10 12:03:16 --> Helper loaded: url_helper
INFO - 2019-09-10 12:03:17 --> Helper loaded: html_helper
INFO - 2019-09-10 12:03:17 --> Helper loaded: form_helper
INFO - 2019-09-10 12:03:17 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:03:17 --> Helper loaded: date_helper
INFO - 2019-09-10 12:03:17 --> Form Validation Class Initialized
INFO - 2019-09-10 12:03:17 --> Email Class Initialized
DEBUG - 2019-09-10 12:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:03:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:03:17 --> Pagination Class Initialized
INFO - 2019-09-10 12:03:17 --> Database Driver Class Initialized
INFO - 2019-09-10 12:03:17 --> Database Driver Class Initialized
INFO - 2019-09-10 12:03:17 --> Controller Class Initialized
INFO - 2019-09-10 12:03:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 12:03:18 --> Final output sent to browser
DEBUG - 2019-09-10 12:03:18 --> Total execution time: 1.4588
INFO - 2019-09-10 12:04:11 --> Config Class Initialized
INFO - 2019-09-10 12:04:11 --> Hooks Class Initialized
DEBUG - 2019-09-10 12:04:11 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:04:11 --> Utf8 Class Initialized
INFO - 2019-09-10 12:04:11 --> URI Class Initialized
INFO - 2019-09-10 12:04:11 --> Router Class Initialized
INFO - 2019-09-10 12:04:11 --> Output Class Initialized
INFO - 2019-09-10 12:04:11 --> Security Class Initialized
DEBUG - 2019-09-10 12:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:04:11 --> Input Class Initialized
INFO - 2019-09-10 12:04:11 --> Language Class Initialized
INFO - 2019-09-10 12:04:11 --> Loader Class Initialized
INFO - 2019-09-10 12:04:11 --> Helper loaded: url_helper
INFO - 2019-09-10 12:04:11 --> Helper loaded: html_helper
INFO - 2019-09-10 12:04:11 --> Helper loaded: form_helper
INFO - 2019-09-10 12:04:11 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:04:11 --> Helper loaded: date_helper
INFO - 2019-09-10 12:04:11 --> Form Validation Class Initialized
INFO - 2019-09-10 12:04:11 --> Email Class Initialized
DEBUG - 2019-09-10 12:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:04:11 --> Pagination Class Initialized
INFO - 2019-09-10 12:04:11 --> Database Driver Class Initialized
INFO - 2019-09-10 12:04:11 --> Database Driver Class Initialized
INFO - 2019-09-10 12:04:11 --> Controller Class Initialized
INFO - 2019-09-10 12:04:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 12:04:12 --> Config Class Initialized
INFO - 2019-09-10 12:04:12 --> Hooks Class Initialized
DEBUG - 2019-09-10 12:04:12 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:04:12 --> Utf8 Class Initialized
INFO - 2019-09-10 12:04:12 --> URI Class Initialized
INFO - 2019-09-10 12:04:12 --> Router Class Initialized
INFO - 2019-09-10 12:04:12 --> Output Class Initialized
INFO - 2019-09-10 12:04:12 --> Security Class Initialized
DEBUG - 2019-09-10 12:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:04:12 --> Input Class Initialized
INFO - 2019-09-10 12:04:12 --> Language Class Initialized
INFO - 2019-09-10 12:04:12 --> Loader Class Initialized
INFO - 2019-09-10 12:04:12 --> Helper loaded: url_helper
INFO - 2019-09-10 12:04:12 --> Helper loaded: html_helper
INFO - 2019-09-10 12:04:12 --> Helper loaded: form_helper
INFO - 2019-09-10 12:04:12 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:04:12 --> Helper loaded: date_helper
INFO - 2019-09-10 12:04:12 --> Form Validation Class Initialized
INFO - 2019-09-10 12:04:12 --> Email Class Initialized
DEBUG - 2019-09-10 12:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:04:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:04:12 --> Pagination Class Initialized
INFO - 2019-09-10 12:04:12 --> Database Driver Class Initialized
INFO - 2019-09-10 12:04:12 --> Database Driver Class Initialized
INFO - 2019-09-10 12:04:12 --> Controller Class Initialized
INFO - 2019-09-10 12:04:12 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 12:04:12 --> Final output sent to browser
DEBUG - 2019-09-10 12:04:12 --> Total execution time: 0.1324
INFO - 2019-09-10 12:04:32 --> Config Class Initialized
INFO - 2019-09-10 12:04:32 --> Hooks Class Initialized
DEBUG - 2019-09-10 12:04:32 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:04:32 --> Utf8 Class Initialized
INFO - 2019-09-10 12:04:32 --> URI Class Initialized
INFO - 2019-09-10 12:04:32 --> Router Class Initialized
INFO - 2019-09-10 12:04:32 --> Output Class Initialized
INFO - 2019-09-10 12:04:32 --> Security Class Initialized
DEBUG - 2019-09-10 12:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:04:32 --> Input Class Initialized
INFO - 2019-09-10 12:04:32 --> Language Class Initialized
INFO - 2019-09-10 12:04:32 --> Loader Class Initialized
INFO - 2019-09-10 12:04:32 --> Helper loaded: url_helper
INFO - 2019-09-10 12:04:32 --> Helper loaded: html_helper
INFO - 2019-09-10 12:04:32 --> Helper loaded: form_helper
INFO - 2019-09-10 12:04:32 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:04:32 --> Helper loaded: date_helper
INFO - 2019-09-10 12:04:32 --> Form Validation Class Initialized
INFO - 2019-09-10 12:04:32 --> Email Class Initialized
DEBUG - 2019-09-10 12:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:04:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:04:32 --> Pagination Class Initialized
INFO - 2019-09-10 12:04:32 --> Database Driver Class Initialized
INFO - 2019-09-10 12:04:32 --> Database Driver Class Initialized
INFO - 2019-09-10 12:04:32 --> Controller Class Initialized
INFO - 2019-09-10 12:04:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 12:04:32 --> Config Class Initialized
INFO - 2019-09-10 12:04:32 --> Hooks Class Initialized
DEBUG - 2019-09-10 12:04:32 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:04:32 --> Utf8 Class Initialized
INFO - 2019-09-10 12:04:32 --> URI Class Initialized
INFO - 2019-09-10 12:04:32 --> Router Class Initialized
INFO - 2019-09-10 12:04:32 --> Output Class Initialized
INFO - 2019-09-10 12:04:32 --> Security Class Initialized
DEBUG - 2019-09-10 12:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:04:32 --> Input Class Initialized
INFO - 2019-09-10 12:04:32 --> Language Class Initialized
INFO - 2019-09-10 12:04:32 --> Loader Class Initialized
INFO - 2019-09-10 12:04:32 --> Helper loaded: url_helper
INFO - 2019-09-10 12:04:32 --> Helper loaded: html_helper
INFO - 2019-09-10 12:04:32 --> Helper loaded: form_helper
INFO - 2019-09-10 12:04:32 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:04:32 --> Helper loaded: date_helper
INFO - 2019-09-10 12:04:32 --> Form Validation Class Initialized
INFO - 2019-09-10 12:04:32 --> Email Class Initialized
DEBUG - 2019-09-10 12:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:04:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:04:32 --> Pagination Class Initialized
INFO - 2019-09-10 12:04:32 --> Database Driver Class Initialized
INFO - 2019-09-10 12:04:32 --> Database Driver Class Initialized
INFO - 2019-09-10 12:04:32 --> Controller Class Initialized
INFO - 2019-09-10 12:04:32 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 12:04:32 --> Final output sent to browser
DEBUG - 2019-09-10 12:04:32 --> Total execution time: 0.0881
INFO - 2019-09-10 12:18:46 --> Config Class Initialized
INFO - 2019-09-10 12:18:46 --> Hooks Class Initialized
DEBUG - 2019-09-10 12:18:46 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:18:46 --> Utf8 Class Initialized
INFO - 2019-09-10 12:18:46 --> URI Class Initialized
INFO - 2019-09-10 12:18:46 --> Router Class Initialized
INFO - 2019-09-10 12:18:46 --> Output Class Initialized
INFO - 2019-09-10 12:18:46 --> Security Class Initialized
DEBUG - 2019-09-10 12:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:18:46 --> Input Class Initialized
INFO - 2019-09-10 12:18:46 --> Language Class Initialized
INFO - 2019-09-10 12:18:46 --> Loader Class Initialized
INFO - 2019-09-10 12:18:46 --> Helper loaded: url_helper
INFO - 2019-09-10 12:18:46 --> Helper loaded: html_helper
INFO - 2019-09-10 12:18:46 --> Helper loaded: form_helper
INFO - 2019-09-10 12:18:46 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:18:46 --> Helper loaded: date_helper
INFO - 2019-09-10 12:18:46 --> Form Validation Class Initialized
INFO - 2019-09-10 12:18:46 --> Email Class Initialized
DEBUG - 2019-09-10 12:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:18:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:18:46 --> Pagination Class Initialized
INFO - 2019-09-10 12:18:46 --> Database Driver Class Initialized
INFO - 2019-09-10 12:18:46 --> Database Driver Class Initialized
INFO - 2019-09-10 12:18:46 --> Controller Class Initialized
INFO - 2019-09-10 12:18:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 12:18:46 --> Config Class Initialized
INFO - 2019-09-10 12:18:46 --> Hooks Class Initialized
DEBUG - 2019-09-10 12:18:46 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:18:46 --> Utf8 Class Initialized
INFO - 2019-09-10 12:18:46 --> URI Class Initialized
INFO - 2019-09-10 12:18:46 --> Router Class Initialized
INFO - 2019-09-10 12:18:46 --> Output Class Initialized
INFO - 2019-09-10 12:18:46 --> Security Class Initialized
DEBUG - 2019-09-10 12:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:18:46 --> Input Class Initialized
INFO - 2019-09-10 12:18:46 --> Language Class Initialized
INFO - 2019-09-10 12:18:46 --> Loader Class Initialized
INFO - 2019-09-10 12:18:46 --> Helper loaded: url_helper
INFO - 2019-09-10 12:18:46 --> Helper loaded: html_helper
INFO - 2019-09-10 12:18:46 --> Helper loaded: form_helper
INFO - 2019-09-10 12:18:46 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:18:46 --> Helper loaded: date_helper
INFO - 2019-09-10 12:18:46 --> Form Validation Class Initialized
INFO - 2019-09-10 12:18:46 --> Email Class Initialized
DEBUG - 2019-09-10 12:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:18:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:18:46 --> Pagination Class Initialized
INFO - 2019-09-10 12:18:46 --> Database Driver Class Initialized
INFO - 2019-09-10 12:18:46 --> Database Driver Class Initialized
INFO - 2019-09-10 12:18:46 --> Controller Class Initialized
INFO - 2019-09-10 12:18:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 12:18:46 --> Final output sent to browser
DEBUG - 2019-09-10 12:18:46 --> Total execution time: 0.0488
INFO - 2019-09-10 12:18:57 --> Config Class Initialized
INFO - 2019-09-10 12:18:57 --> Hooks Class Initialized
DEBUG - 2019-09-10 12:18:57 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:18:57 --> Utf8 Class Initialized
INFO - 2019-09-10 12:18:57 --> URI Class Initialized
INFO - 2019-09-10 12:18:57 --> Router Class Initialized
INFO - 2019-09-10 12:18:57 --> Output Class Initialized
INFO - 2019-09-10 12:18:57 --> Security Class Initialized
DEBUG - 2019-09-10 12:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:18:57 --> Input Class Initialized
INFO - 2019-09-10 12:18:57 --> Language Class Initialized
INFO - 2019-09-10 12:18:57 --> Loader Class Initialized
INFO - 2019-09-10 12:18:57 --> Helper loaded: url_helper
INFO - 2019-09-10 12:18:57 --> Helper loaded: html_helper
INFO - 2019-09-10 12:18:58 --> Helper loaded: form_helper
INFO - 2019-09-10 12:18:58 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:18:58 --> Helper loaded: date_helper
INFO - 2019-09-10 12:18:58 --> Form Validation Class Initialized
INFO - 2019-09-10 12:18:58 --> Email Class Initialized
DEBUG - 2019-09-10 12:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:18:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:18:58 --> Pagination Class Initialized
INFO - 2019-09-10 12:18:58 --> Database Driver Class Initialized
INFO - 2019-09-10 12:18:58 --> Database Driver Class Initialized
INFO - 2019-09-10 12:18:58 --> Controller Class Initialized
INFO - 2019-09-10 12:18:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 12:18:58 --> Config Class Initialized
INFO - 2019-09-10 12:18:58 --> Hooks Class Initialized
DEBUG - 2019-09-10 12:18:58 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:18:58 --> Utf8 Class Initialized
INFO - 2019-09-10 12:18:58 --> URI Class Initialized
INFO - 2019-09-10 12:18:58 --> Router Class Initialized
INFO - 2019-09-10 12:18:58 --> Output Class Initialized
INFO - 2019-09-10 12:18:58 --> Security Class Initialized
DEBUG - 2019-09-10 12:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:18:58 --> Input Class Initialized
INFO - 2019-09-10 12:18:58 --> Language Class Initialized
INFO - 2019-09-10 12:18:58 --> Loader Class Initialized
INFO - 2019-09-10 12:18:58 --> Helper loaded: url_helper
INFO - 2019-09-10 12:18:58 --> Helper loaded: html_helper
INFO - 2019-09-10 12:18:58 --> Helper loaded: form_helper
INFO - 2019-09-10 12:18:58 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:18:58 --> Helper loaded: date_helper
INFO - 2019-09-10 12:18:58 --> Form Validation Class Initialized
INFO - 2019-09-10 12:18:58 --> Email Class Initialized
DEBUG - 2019-09-10 12:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:18:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:18:58 --> Pagination Class Initialized
INFO - 2019-09-10 12:18:58 --> Database Driver Class Initialized
INFO - 2019-09-10 12:18:58 --> Database Driver Class Initialized
INFO - 2019-09-10 12:18:58 --> Controller Class Initialized
INFO - 2019-09-10 12:18:58 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 12:18:58 --> Final output sent to browser
DEBUG - 2019-09-10 12:18:58 --> Total execution time: 0.0489
INFO - 2019-09-10 12:19:23 --> Config Class Initialized
INFO - 2019-09-10 12:19:23 --> Hooks Class Initialized
DEBUG - 2019-09-10 12:19:23 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:19:23 --> Utf8 Class Initialized
INFO - 2019-09-10 12:19:23 --> URI Class Initialized
INFO - 2019-09-10 12:19:23 --> Router Class Initialized
INFO - 2019-09-10 12:19:23 --> Output Class Initialized
INFO - 2019-09-10 12:19:23 --> Security Class Initialized
DEBUG - 2019-09-10 12:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:19:23 --> Input Class Initialized
INFO - 2019-09-10 12:19:23 --> Language Class Initialized
INFO - 2019-09-10 12:19:23 --> Loader Class Initialized
INFO - 2019-09-10 12:19:23 --> Helper loaded: url_helper
INFO - 2019-09-10 12:19:23 --> Helper loaded: html_helper
INFO - 2019-09-10 12:19:23 --> Helper loaded: form_helper
INFO - 2019-09-10 12:19:23 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:19:23 --> Helper loaded: date_helper
INFO - 2019-09-10 12:19:23 --> Form Validation Class Initialized
INFO - 2019-09-10 12:19:23 --> Email Class Initialized
DEBUG - 2019-09-10 12:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:19:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:19:23 --> Pagination Class Initialized
INFO - 2019-09-10 12:19:23 --> Database Driver Class Initialized
INFO - 2019-09-10 12:19:23 --> Database Driver Class Initialized
INFO - 2019-09-10 12:19:23 --> Controller Class Initialized
INFO - 2019-09-10 12:19:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 12:19:23 --> Config Class Initialized
INFO - 2019-09-10 12:19:23 --> Hooks Class Initialized
DEBUG - 2019-09-10 12:19:23 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:19:23 --> Utf8 Class Initialized
INFO - 2019-09-10 12:19:23 --> URI Class Initialized
INFO - 2019-09-10 12:19:23 --> Router Class Initialized
INFO - 2019-09-10 12:19:23 --> Output Class Initialized
INFO - 2019-09-10 12:19:23 --> Security Class Initialized
DEBUG - 2019-09-10 12:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:19:23 --> Input Class Initialized
INFO - 2019-09-10 12:19:23 --> Language Class Initialized
INFO - 2019-09-10 12:19:23 --> Loader Class Initialized
INFO - 2019-09-10 12:19:23 --> Helper loaded: url_helper
INFO - 2019-09-10 12:19:23 --> Helper loaded: html_helper
INFO - 2019-09-10 12:19:23 --> Helper loaded: form_helper
INFO - 2019-09-10 12:19:23 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:19:23 --> Helper loaded: date_helper
INFO - 2019-09-10 12:19:23 --> Form Validation Class Initialized
INFO - 2019-09-10 12:19:23 --> Email Class Initialized
DEBUG - 2019-09-10 12:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:19:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:19:23 --> Pagination Class Initialized
INFO - 2019-09-10 12:19:23 --> Database Driver Class Initialized
INFO - 2019-09-10 12:19:23 --> Database Driver Class Initialized
INFO - 2019-09-10 12:19:23 --> Controller Class Initialized
INFO - 2019-09-10 12:19:23 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 12:19:23 --> Final output sent to browser
DEBUG - 2019-09-10 12:19:23 --> Total execution time: 0.0687
INFO - 2019-09-10 12:20:36 --> Config Class Initialized
INFO - 2019-09-10 12:20:36 --> Hooks Class Initialized
DEBUG - 2019-09-10 12:20:36 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:20:36 --> Utf8 Class Initialized
INFO - 2019-09-10 12:20:36 --> URI Class Initialized
INFO - 2019-09-10 12:20:36 --> Router Class Initialized
INFO - 2019-09-10 12:20:36 --> Output Class Initialized
INFO - 2019-09-10 12:20:36 --> Security Class Initialized
DEBUG - 2019-09-10 12:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:20:36 --> Input Class Initialized
INFO - 2019-09-10 12:20:36 --> Language Class Initialized
INFO - 2019-09-10 12:20:36 --> Loader Class Initialized
INFO - 2019-09-10 12:20:36 --> Helper loaded: url_helper
INFO - 2019-09-10 12:20:36 --> Helper loaded: html_helper
INFO - 2019-09-10 12:20:36 --> Helper loaded: form_helper
INFO - 2019-09-10 12:20:36 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:20:36 --> Helper loaded: date_helper
INFO - 2019-09-10 12:20:36 --> Form Validation Class Initialized
INFO - 2019-09-10 12:20:36 --> Email Class Initialized
DEBUG - 2019-09-10 12:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:20:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:20:36 --> Pagination Class Initialized
INFO - 2019-09-10 12:20:36 --> Database Driver Class Initialized
INFO - 2019-09-10 12:20:36 --> Database Driver Class Initialized
INFO - 2019-09-10 12:20:36 --> Controller Class Initialized
INFO - 2019-09-10 12:20:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 12:20:36 --> Config Class Initialized
INFO - 2019-09-10 12:20:36 --> Hooks Class Initialized
DEBUG - 2019-09-10 12:20:36 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:20:36 --> Utf8 Class Initialized
INFO - 2019-09-10 12:20:36 --> URI Class Initialized
INFO - 2019-09-10 12:20:36 --> Router Class Initialized
INFO - 2019-09-10 12:20:36 --> Output Class Initialized
INFO - 2019-09-10 12:20:36 --> Security Class Initialized
DEBUG - 2019-09-10 12:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:20:36 --> Input Class Initialized
INFO - 2019-09-10 12:20:36 --> Language Class Initialized
INFO - 2019-09-10 12:20:36 --> Loader Class Initialized
INFO - 2019-09-10 12:20:36 --> Helper loaded: url_helper
INFO - 2019-09-10 12:20:36 --> Helper loaded: html_helper
INFO - 2019-09-10 12:20:36 --> Helper loaded: form_helper
INFO - 2019-09-10 12:20:36 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:20:36 --> Helper loaded: date_helper
INFO - 2019-09-10 12:20:36 --> Form Validation Class Initialized
INFO - 2019-09-10 12:20:36 --> Email Class Initialized
DEBUG - 2019-09-10 12:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:20:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:20:36 --> Pagination Class Initialized
INFO - 2019-09-10 12:20:36 --> Database Driver Class Initialized
INFO - 2019-09-10 12:20:36 --> Database Driver Class Initialized
INFO - 2019-09-10 12:20:36 --> Controller Class Initialized
INFO - 2019-09-10 12:20:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 12:20:36 --> Final output sent to browser
DEBUG - 2019-09-10 12:20:36 --> Total execution time: 0.0489
INFO - 2019-09-10 12:22:50 --> Config Class Initialized
INFO - 2019-09-10 12:22:50 --> Hooks Class Initialized
DEBUG - 2019-09-10 12:22:50 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:22:50 --> Utf8 Class Initialized
INFO - 2019-09-10 12:22:50 --> URI Class Initialized
INFO - 2019-09-10 12:22:50 --> Router Class Initialized
INFO - 2019-09-10 12:22:50 --> Output Class Initialized
INFO - 2019-09-10 12:22:50 --> Security Class Initialized
DEBUG - 2019-09-10 12:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:22:50 --> Input Class Initialized
INFO - 2019-09-10 12:22:50 --> Language Class Initialized
INFO - 2019-09-10 12:22:50 --> Loader Class Initialized
INFO - 2019-09-10 12:22:50 --> Helper loaded: url_helper
INFO - 2019-09-10 12:22:50 --> Helper loaded: html_helper
INFO - 2019-09-10 12:22:50 --> Helper loaded: form_helper
INFO - 2019-09-10 12:22:50 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:22:51 --> Helper loaded: date_helper
INFO - 2019-09-10 12:22:51 --> Form Validation Class Initialized
INFO - 2019-09-10 12:22:51 --> Email Class Initialized
DEBUG - 2019-09-10 12:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:22:51 --> Pagination Class Initialized
INFO - 2019-09-10 12:22:51 --> Database Driver Class Initialized
INFO - 2019-09-10 12:22:51 --> Database Driver Class Initialized
INFO - 2019-09-10 12:22:51 --> Controller Class Initialized
INFO - 2019-09-10 12:22:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 12:22:51 --> Config Class Initialized
INFO - 2019-09-10 12:22:51 --> Hooks Class Initialized
DEBUG - 2019-09-10 12:22:51 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:22:51 --> Utf8 Class Initialized
INFO - 2019-09-10 12:22:51 --> URI Class Initialized
INFO - 2019-09-10 12:22:51 --> Router Class Initialized
INFO - 2019-09-10 12:22:51 --> Output Class Initialized
INFO - 2019-09-10 12:22:51 --> Security Class Initialized
DEBUG - 2019-09-10 12:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:22:51 --> Input Class Initialized
INFO - 2019-09-10 12:22:51 --> Language Class Initialized
INFO - 2019-09-10 12:22:51 --> Loader Class Initialized
INFO - 2019-09-10 12:22:51 --> Helper loaded: url_helper
INFO - 2019-09-10 12:22:51 --> Helper loaded: html_helper
INFO - 2019-09-10 12:22:51 --> Helper loaded: form_helper
INFO - 2019-09-10 12:22:51 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:22:51 --> Helper loaded: date_helper
INFO - 2019-09-10 12:22:51 --> Form Validation Class Initialized
INFO - 2019-09-10 12:22:51 --> Email Class Initialized
DEBUG - 2019-09-10 12:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:22:51 --> Pagination Class Initialized
INFO - 2019-09-10 12:22:51 --> Database Driver Class Initialized
INFO - 2019-09-10 12:22:51 --> Database Driver Class Initialized
INFO - 2019-09-10 12:22:51 --> Controller Class Initialized
INFO - 2019-09-10 12:22:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 12:22:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-10 12:22:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 12:22:51 --> Final output sent to browser
DEBUG - 2019-09-10 12:22:51 --> Total execution time: 0.1414
INFO - 2019-09-10 12:22:52 --> Config Class Initialized
INFO - 2019-09-10 12:22:52 --> Hooks Class Initialized
INFO - 2019-09-10 12:22:52 --> Config Class Initialized
INFO - 2019-09-10 12:22:52 --> Hooks Class Initialized
DEBUG - 2019-09-10 12:22:52 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:22:52 --> Utf8 Class Initialized
INFO - 2019-09-10 12:22:52 --> URI Class Initialized
DEBUG - 2019-09-10 12:22:52 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:22:52 --> Utf8 Class Initialized
INFO - 2019-09-10 12:22:52 --> Router Class Initialized
INFO - 2019-09-10 12:22:52 --> URI Class Initialized
INFO - 2019-09-10 12:22:52 --> Output Class Initialized
INFO - 2019-09-10 12:22:52 --> Router Class Initialized
INFO - 2019-09-10 12:22:52 --> Security Class Initialized
DEBUG - 2019-09-10 12:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:22:52 --> Output Class Initialized
INFO - 2019-09-10 12:22:52 --> Input Class Initialized
INFO - 2019-09-10 12:22:52 --> Language Class Initialized
INFO - 2019-09-10 12:22:52 --> Security Class Initialized
DEBUG - 2019-09-10 12:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:22:52 --> Input Class Initialized
INFO - 2019-09-10 12:22:52 --> Language Class Initialized
INFO - 2019-09-10 12:22:52 --> Loader Class Initialized
INFO - 2019-09-10 12:22:52 --> Helper loaded: url_helper
INFO - 2019-09-10 12:22:52 --> Helper loaded: html_helper
INFO - 2019-09-10 12:22:52 --> Loader Class Initialized
INFO - 2019-09-10 12:22:52 --> Helper loaded: form_helper
INFO - 2019-09-10 12:22:52 --> Helper loaded: url_helper
INFO - 2019-09-10 12:22:52 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:22:52 --> Helper loaded: html_helper
INFO - 2019-09-10 12:22:52 --> Helper loaded: date_helper
INFO - 2019-09-10 12:22:52 --> Helper loaded: form_helper
INFO - 2019-09-10 12:22:52 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:22:52 --> Form Validation Class Initialized
INFO - 2019-09-10 12:22:52 --> Helper loaded: date_helper
INFO - 2019-09-10 12:22:52 --> Form Validation Class Initialized
INFO - 2019-09-10 12:22:52 --> Email Class Initialized
INFO - 2019-09-10 12:22:52 --> Email Class Initialized
DEBUG - 2019-09-10 12:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:22:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:22:52 --> Pagination Class Initialized
DEBUG - 2019-09-10 12:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:22:52 --> Database Driver Class Initialized
INFO - 2019-09-10 12:22:52 --> Database Driver Class Initialized
INFO - 2019-09-10 12:22:52 --> Controller Class Initialized
INFO - 2019-09-10 12:22:52 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 12:22:52 --> Final output sent to browser
DEBUG - 2019-09-10 12:22:52 --> Total execution time: 0.0660
INFO - 2019-09-10 12:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:22:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:22:52 --> Pagination Class Initialized
INFO - 2019-09-10 12:22:52 --> Database Driver Class Initialized
INFO - 2019-09-10 12:22:52 --> Database Driver Class Initialized
INFO - 2019-09-10 12:22:52 --> Controller Class Initialized
INFO - 2019-09-10 12:22:52 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 12:22:52 --> Final output sent to browser
DEBUG - 2019-09-10 12:22:52 --> Total execution time: 0.0955
INFO - 2019-09-10 12:31:31 --> Config Class Initialized
INFO - 2019-09-10 12:31:31 --> Hooks Class Initialized
DEBUG - 2019-09-10 12:31:31 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:31:31 --> Utf8 Class Initialized
INFO - 2019-09-10 12:31:31 --> URI Class Initialized
INFO - 2019-09-10 12:31:31 --> Router Class Initialized
INFO - 2019-09-10 12:31:31 --> Output Class Initialized
INFO - 2019-09-10 12:31:31 --> Security Class Initialized
DEBUG - 2019-09-10 12:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:31:31 --> Input Class Initialized
INFO - 2019-09-10 12:31:31 --> Language Class Initialized
INFO - 2019-09-10 12:31:31 --> Loader Class Initialized
INFO - 2019-09-10 12:31:31 --> Helper loaded: url_helper
INFO - 2019-09-10 12:31:31 --> Helper loaded: html_helper
INFO - 2019-09-10 12:31:31 --> Helper loaded: form_helper
INFO - 2019-09-10 12:31:31 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:31:31 --> Helper loaded: date_helper
INFO - 2019-09-10 12:31:31 --> Form Validation Class Initialized
INFO - 2019-09-10 12:31:31 --> Email Class Initialized
DEBUG - 2019-09-10 12:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:31:31 --> Pagination Class Initialized
INFO - 2019-09-10 12:31:31 --> Database Driver Class Initialized
INFO - 2019-09-10 12:31:31 --> Database Driver Class Initialized
INFO - 2019-09-10 12:31:31 --> Config Class Initialized
INFO - 2019-09-10 12:31:31 --> Hooks Class Initialized
INFO - 2019-09-10 12:31:31 --> Controller Class Initialized
DEBUG - 2019-09-10 12:31:31 --> UTF-8 Support Enabled
INFO - 2019-09-10 12:31:31 --> Utf8 Class Initialized
INFO - 2019-09-10 12:31:31 --> URI Class Initialized
INFO - 2019-09-10 12:31:31 --> Router Class Initialized
INFO - 2019-09-10 12:31:31 --> Output Class Initialized
INFO - 2019-09-10 12:31:31 --> Security Class Initialized
INFO - 2019-09-10 12:31:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 12:31:31 --> Final output sent to browser
DEBUG - 2019-09-10 12:31:31 --> Total execution time: 0.1159
DEBUG - 2019-09-10 12:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 12:31:31 --> Input Class Initialized
INFO - 2019-09-10 12:31:31 --> Language Class Initialized
INFO - 2019-09-10 12:31:31 --> Loader Class Initialized
INFO - 2019-09-10 12:31:31 --> Helper loaded: url_helper
INFO - 2019-09-10 12:31:31 --> Helper loaded: html_helper
INFO - 2019-09-10 12:31:31 --> Helper loaded: form_helper
INFO - 2019-09-10 12:31:31 --> Helper loaded: cookie_helper
INFO - 2019-09-10 12:31:31 --> Helper loaded: date_helper
INFO - 2019-09-10 12:31:31 --> Form Validation Class Initialized
INFO - 2019-09-10 12:31:31 --> Email Class Initialized
DEBUG - 2019-09-10 12:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 12:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 12:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 12:31:31 --> Pagination Class Initialized
INFO - 2019-09-10 12:31:31 --> Database Driver Class Initialized
INFO - 2019-09-10 12:31:31 --> Database Driver Class Initialized
INFO - 2019-09-10 12:31:31 --> Controller Class Initialized
INFO - 2019-09-10 12:31:32 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 12:31:32 --> Final output sent to browser
DEBUG - 2019-09-10 12:31:32 --> Total execution time: 0.0840
INFO - 2019-09-10 15:44:52 --> Config Class Initialized
INFO - 2019-09-10 15:44:52 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:44:52 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:44:52 --> Utf8 Class Initialized
INFO - 2019-09-10 15:44:52 --> URI Class Initialized
INFO - 2019-09-10 15:44:52 --> Router Class Initialized
INFO - 2019-09-10 15:44:52 --> Output Class Initialized
INFO - 2019-09-10 15:44:52 --> Security Class Initialized
DEBUG - 2019-09-10 15:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:44:52 --> Input Class Initialized
INFO - 2019-09-10 15:44:52 --> Language Class Initialized
INFO - 2019-09-10 15:44:52 --> Loader Class Initialized
INFO - 2019-09-10 15:44:52 --> Helper loaded: url_helper
INFO - 2019-09-10 15:44:52 --> Helper loaded: html_helper
INFO - 2019-09-10 15:44:52 --> Helper loaded: form_helper
INFO - 2019-09-10 15:44:52 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:44:52 --> Helper loaded: date_helper
INFO - 2019-09-10 15:44:52 --> Form Validation Class Initialized
INFO - 2019-09-10 15:44:52 --> Email Class Initialized
DEBUG - 2019-09-10 15:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:44:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:44:53 --> Pagination Class Initialized
INFO - 2019-09-10 15:44:53 --> Database Driver Class Initialized
INFO - 2019-09-10 15:44:53 --> Database Driver Class Initialized
INFO - 2019-09-10 15:44:53 --> Controller Class Initialized
INFO - 2019-09-10 15:44:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 15:44:53 --> Final output sent to browser
DEBUG - 2019-09-10 15:44:53 --> Total execution time: 0.4398
INFO - 2019-09-10 15:44:53 --> Config Class Initialized
INFO - 2019-09-10 15:44:53 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:44:53 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:44:53 --> Utf8 Class Initialized
INFO - 2019-09-10 15:44:53 --> URI Class Initialized
INFO - 2019-09-10 15:44:53 --> Router Class Initialized
INFO - 2019-09-10 15:44:53 --> Output Class Initialized
INFO - 2019-09-10 15:44:53 --> Security Class Initialized
DEBUG - 2019-09-10 15:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:44:53 --> Input Class Initialized
INFO - 2019-09-10 15:44:53 --> Language Class Initialized
INFO - 2019-09-10 15:44:53 --> Loader Class Initialized
INFO - 2019-09-10 15:44:53 --> Helper loaded: url_helper
INFO - 2019-09-10 15:44:53 --> Helper loaded: html_helper
INFO - 2019-09-10 15:44:53 --> Helper loaded: form_helper
INFO - 2019-09-10 15:44:53 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:44:53 --> Helper loaded: date_helper
INFO - 2019-09-10 15:44:53 --> Form Validation Class Initialized
INFO - 2019-09-10 15:44:53 --> Email Class Initialized
DEBUG - 2019-09-10 15:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:44:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:44:53 --> Pagination Class Initialized
INFO - 2019-09-10 15:44:53 --> Database Driver Class Initialized
INFO - 2019-09-10 15:44:53 --> Database Driver Class Initialized
INFO - 2019-09-10 15:44:53 --> Controller Class Initialized
INFO - 2019-09-10 15:44:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 15:44:53 --> Final output sent to browser
DEBUG - 2019-09-10 15:44:53 --> Total execution time: 0.0797
INFO - 2019-09-10 15:44:58 --> Config Class Initialized
INFO - 2019-09-10 15:44:58 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:44:58 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:44:58 --> Utf8 Class Initialized
INFO - 2019-09-10 15:44:58 --> URI Class Initialized
INFO - 2019-09-10 15:44:58 --> Router Class Initialized
INFO - 2019-09-10 15:44:58 --> Output Class Initialized
INFO - 2019-09-10 15:44:58 --> Security Class Initialized
DEBUG - 2019-09-10 15:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:44:58 --> Input Class Initialized
INFO - 2019-09-10 15:44:58 --> Language Class Initialized
INFO - 2019-09-10 15:44:58 --> Loader Class Initialized
INFO - 2019-09-10 15:44:58 --> Helper loaded: url_helper
INFO - 2019-09-10 15:44:58 --> Helper loaded: html_helper
INFO - 2019-09-10 15:44:58 --> Helper loaded: form_helper
INFO - 2019-09-10 15:44:58 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:44:58 --> Helper loaded: date_helper
INFO - 2019-09-10 15:44:58 --> Form Validation Class Initialized
INFO - 2019-09-10 15:44:58 --> Email Class Initialized
DEBUG - 2019-09-10 15:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:44:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:44:58 --> Pagination Class Initialized
INFO - 2019-09-10 15:44:58 --> Database Driver Class Initialized
INFO - 2019-09-10 15:44:58 --> Database Driver Class Initialized
INFO - 2019-09-10 15:44:58 --> Controller Class Initialized
INFO - 2019-09-10 15:44:58 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 15:44:58 --> Final output sent to browser
DEBUG - 2019-09-10 15:44:58 --> Total execution time: 0.0599
INFO - 2019-09-10 15:44:58 --> Config Class Initialized
INFO - 2019-09-10 15:44:58 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:44:58 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:44:58 --> Utf8 Class Initialized
INFO - 2019-09-10 15:44:58 --> URI Class Initialized
INFO - 2019-09-10 15:44:58 --> Router Class Initialized
INFO - 2019-09-10 15:44:58 --> Output Class Initialized
INFO - 2019-09-10 15:44:58 --> Security Class Initialized
DEBUG - 2019-09-10 15:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:44:58 --> Input Class Initialized
INFO - 2019-09-10 15:44:58 --> Language Class Initialized
INFO - 2019-09-10 15:44:58 --> Loader Class Initialized
INFO - 2019-09-10 15:44:58 --> Helper loaded: url_helper
INFO - 2019-09-10 15:44:58 --> Helper loaded: html_helper
INFO - 2019-09-10 15:44:58 --> Helper loaded: form_helper
INFO - 2019-09-10 15:44:58 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:44:58 --> Helper loaded: date_helper
INFO - 2019-09-10 15:44:58 --> Form Validation Class Initialized
INFO - 2019-09-10 15:44:58 --> Email Class Initialized
DEBUG - 2019-09-10 15:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:44:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:44:58 --> Pagination Class Initialized
INFO - 2019-09-10 15:44:58 --> Database Driver Class Initialized
INFO - 2019-09-10 15:44:58 --> Database Driver Class Initialized
INFO - 2019-09-10 15:44:58 --> Controller Class Initialized
INFO - 2019-09-10 15:44:58 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 15:44:58 --> Final output sent to browser
DEBUG - 2019-09-10 15:44:58 --> Total execution time: 0.0902
INFO - 2019-09-10 15:45:10 --> Config Class Initialized
INFO - 2019-09-10 15:45:10 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:45:10 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:45:10 --> Utf8 Class Initialized
INFO - 2019-09-10 15:45:10 --> URI Class Initialized
INFO - 2019-09-10 15:45:10 --> Router Class Initialized
INFO - 2019-09-10 15:45:10 --> Output Class Initialized
INFO - 2019-09-10 15:45:10 --> Security Class Initialized
DEBUG - 2019-09-10 15:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:45:10 --> Input Class Initialized
INFO - 2019-09-10 15:45:10 --> Language Class Initialized
INFO - 2019-09-10 15:45:10 --> Loader Class Initialized
INFO - 2019-09-10 15:45:10 --> Helper loaded: url_helper
INFO - 2019-09-10 15:45:10 --> Helper loaded: html_helper
INFO - 2019-09-10 15:45:10 --> Helper loaded: form_helper
INFO - 2019-09-10 15:45:10 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:45:10 --> Helper loaded: date_helper
INFO - 2019-09-10 15:45:10 --> Form Validation Class Initialized
INFO - 2019-09-10 15:45:10 --> Email Class Initialized
DEBUG - 2019-09-10 15:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:45:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:45:10 --> Pagination Class Initialized
INFO - 2019-09-10 15:45:10 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:10 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:10 --> Controller Class Initialized
INFO - 2019-09-10 15:45:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 15:45:11 --> Config Class Initialized
INFO - 2019-09-10 15:45:11 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:45:11 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:45:11 --> Utf8 Class Initialized
INFO - 2019-09-10 15:45:11 --> URI Class Initialized
INFO - 2019-09-10 15:45:11 --> Router Class Initialized
INFO - 2019-09-10 15:45:11 --> Output Class Initialized
INFO - 2019-09-10 15:45:11 --> Security Class Initialized
DEBUG - 2019-09-10 15:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:45:11 --> Input Class Initialized
INFO - 2019-09-10 15:45:11 --> Language Class Initialized
INFO - 2019-09-10 15:45:11 --> Loader Class Initialized
INFO - 2019-09-10 15:45:11 --> Helper loaded: url_helper
INFO - 2019-09-10 15:45:11 --> Helper loaded: html_helper
INFO - 2019-09-10 15:45:11 --> Helper loaded: form_helper
INFO - 2019-09-10 15:45:11 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:45:11 --> Helper loaded: date_helper
INFO - 2019-09-10 15:45:11 --> Form Validation Class Initialized
INFO - 2019-09-10 15:45:11 --> Email Class Initialized
DEBUG - 2019-09-10 15:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:45:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:45:11 --> Pagination Class Initialized
INFO - 2019-09-10 15:45:11 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:11 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:11 --> Controller Class Initialized
INFO - 2019-09-10 15:45:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 15:45:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-10 15:45:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 15:45:11 --> Final output sent to browser
DEBUG - 2019-09-10 15:45:11 --> Total execution time: 0.1195
INFO - 2019-09-10 15:45:11 --> Config Class Initialized
INFO - 2019-09-10 15:45:11 --> Hooks Class Initialized
INFO - 2019-09-10 15:45:11 --> Config Class Initialized
DEBUG - 2019-09-10 15:45:11 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:45:11 --> Hooks Class Initialized
INFO - 2019-09-10 15:45:11 --> Utf8 Class Initialized
INFO - 2019-09-10 15:45:11 --> URI Class Initialized
DEBUG - 2019-09-10 15:45:11 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:45:11 --> Router Class Initialized
INFO - 2019-09-10 15:45:11 --> Utf8 Class Initialized
INFO - 2019-09-10 15:45:11 --> URI Class Initialized
INFO - 2019-09-10 15:45:11 --> Output Class Initialized
INFO - 2019-09-10 15:45:11 --> Security Class Initialized
INFO - 2019-09-10 15:45:11 --> Router Class Initialized
DEBUG - 2019-09-10 15:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:45:11 --> Input Class Initialized
INFO - 2019-09-10 15:45:11 --> Language Class Initialized
INFO - 2019-09-10 15:45:11 --> Output Class Initialized
INFO - 2019-09-10 15:45:11 --> Security Class Initialized
DEBUG - 2019-09-10 15:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:45:11 --> Input Class Initialized
INFO - 2019-09-10 15:45:11 --> Loader Class Initialized
INFO - 2019-09-10 15:45:11 --> Language Class Initialized
INFO - 2019-09-10 15:45:11 --> Helper loaded: url_helper
INFO - 2019-09-10 15:45:11 --> Helper loaded: html_helper
INFO - 2019-09-10 15:45:11 --> Helper loaded: form_helper
INFO - 2019-09-10 15:45:11 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:45:11 --> Helper loaded: date_helper
INFO - 2019-09-10 15:45:11 --> Loader Class Initialized
INFO - 2019-09-10 15:45:11 --> Helper loaded: url_helper
INFO - 2019-09-10 15:45:11 --> Form Validation Class Initialized
INFO - 2019-09-10 15:45:11 --> Helper loaded: html_helper
INFO - 2019-09-10 15:45:11 --> Email Class Initialized
INFO - 2019-09-10 15:45:11 --> Helper loaded: form_helper
INFO - 2019-09-10 15:45:11 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:45:11 --> Helper loaded: date_helper
DEBUG - 2019-09-10 15:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:45:11 --> Form Validation Class Initialized
INFO - 2019-09-10 15:45:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:45:11 --> Pagination Class Initialized
INFO - 2019-09-10 15:45:11 --> Email Class Initialized
DEBUG - 2019-09-10 15:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:45:11 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:11 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:11 --> Controller Class Initialized
INFO - 2019-09-10 15:45:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 15:45:11 --> Final output sent to browser
DEBUG - 2019-09-10 15:45:11 --> Total execution time: 0.0603
INFO - 2019-09-10 15:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:45:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:45:11 --> Pagination Class Initialized
INFO - 2019-09-10 15:45:11 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:11 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:11 --> Controller Class Initialized
INFO - 2019-09-10 15:45:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 15:45:11 --> Final output sent to browser
DEBUG - 2019-09-10 15:45:11 --> Total execution time: 0.0815
INFO - 2019-09-10 15:45:15 --> Config Class Initialized
INFO - 2019-09-10 15:45:15 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:45:15 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:45:15 --> Utf8 Class Initialized
INFO - 2019-09-10 15:45:15 --> URI Class Initialized
INFO - 2019-09-10 15:45:15 --> Router Class Initialized
INFO - 2019-09-10 15:45:15 --> Output Class Initialized
INFO - 2019-09-10 15:45:15 --> Security Class Initialized
DEBUG - 2019-09-10 15:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:45:15 --> Input Class Initialized
INFO - 2019-09-10 15:45:15 --> Language Class Initialized
INFO - 2019-09-10 15:45:15 --> Loader Class Initialized
INFO - 2019-09-10 15:45:15 --> Helper loaded: url_helper
INFO - 2019-09-10 15:45:15 --> Helper loaded: html_helper
INFO - 2019-09-10 15:45:15 --> Helper loaded: form_helper
INFO - 2019-09-10 15:45:15 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:45:15 --> Helper loaded: date_helper
INFO - 2019-09-10 15:45:15 --> Form Validation Class Initialized
INFO - 2019-09-10 15:45:15 --> Email Class Initialized
DEBUG - 2019-09-10 15:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:45:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:45:15 --> Pagination Class Initialized
INFO - 2019-09-10 15:45:15 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:15 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:15 --> Controller Class Initialized
INFO - 2019-09-10 15:45:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 15:45:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-10 15:45:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-10 15:45:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 15:45:15 --> Final output sent to browser
DEBUG - 2019-09-10 15:45:15 --> Total execution time: 0.2685
INFO - 2019-09-10 15:45:15 --> Config Class Initialized
INFO - 2019-09-10 15:45:15 --> Hooks Class Initialized
INFO - 2019-09-10 15:45:15 --> Config Class Initialized
INFO - 2019-09-10 15:45:15 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:45:15 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:45:15 --> Utf8 Class Initialized
DEBUG - 2019-09-10 15:45:15 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:45:15 --> Utf8 Class Initialized
INFO - 2019-09-10 15:45:15 --> URI Class Initialized
INFO - 2019-09-10 15:45:15 --> URI Class Initialized
INFO - 2019-09-10 15:45:15 --> Router Class Initialized
INFO - 2019-09-10 15:45:15 --> Router Class Initialized
INFO - 2019-09-10 15:45:15 --> Output Class Initialized
INFO - 2019-09-10 15:45:15 --> Output Class Initialized
INFO - 2019-09-10 15:45:15 --> Security Class Initialized
INFO - 2019-09-10 15:45:15 --> Security Class Initialized
DEBUG - 2019-09-10 15:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:45:15 --> Input Class Initialized
DEBUG - 2019-09-10 15:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:45:15 --> Language Class Initialized
INFO - 2019-09-10 15:45:15 --> Input Class Initialized
INFO - 2019-09-10 15:45:15 --> Language Class Initialized
INFO - 2019-09-10 15:45:15 --> Loader Class Initialized
INFO - 2019-09-10 15:45:15 --> Loader Class Initialized
INFO - 2019-09-10 15:45:15 --> Helper loaded: url_helper
INFO - 2019-09-10 15:45:15 --> Helper loaded: url_helper
INFO - 2019-09-10 15:45:15 --> Helper loaded: html_helper
INFO - 2019-09-10 15:45:15 --> Helper loaded: html_helper
INFO - 2019-09-10 15:45:15 --> Helper loaded: form_helper
INFO - 2019-09-10 15:45:15 --> Helper loaded: form_helper
INFO - 2019-09-10 15:45:15 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:45:15 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:45:15 --> Helper loaded: date_helper
INFO - 2019-09-10 15:45:15 --> Helper loaded: date_helper
INFO - 2019-09-10 15:45:15 --> Form Validation Class Initialized
INFO - 2019-09-10 15:45:15 --> Form Validation Class Initialized
INFO - 2019-09-10 15:45:15 --> Email Class Initialized
INFO - 2019-09-10 15:45:15 --> Email Class Initialized
DEBUG - 2019-09-10 15:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-10 15:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:45:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:45:15 --> Pagination Class Initialized
INFO - 2019-09-10 15:45:15 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:15 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:15 --> Controller Class Initialized
INFO - 2019-09-10 15:45:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 15:45:15 --> Final output sent to browser
DEBUG - 2019-09-10 15:45:15 --> Total execution time: 0.0932
INFO - 2019-09-10 15:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:45:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:45:15 --> Pagination Class Initialized
INFO - 2019-09-10 15:45:15 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:15 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:15 --> Controller Class Initialized
INFO - 2019-09-10 15:45:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 15:45:15 --> Final output sent to browser
DEBUG - 2019-09-10 15:45:15 --> Total execution time: 0.1324
INFO - 2019-09-10 15:45:18 --> Config Class Initialized
INFO - 2019-09-10 15:45:18 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:45:18 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:45:18 --> Utf8 Class Initialized
INFO - 2019-09-10 15:45:18 --> URI Class Initialized
INFO - 2019-09-10 15:45:18 --> Router Class Initialized
INFO - 2019-09-10 15:45:18 --> Output Class Initialized
INFO - 2019-09-10 15:45:18 --> Security Class Initialized
DEBUG - 2019-09-10 15:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:45:18 --> Input Class Initialized
INFO - 2019-09-10 15:45:18 --> Language Class Initialized
INFO - 2019-09-10 15:45:18 --> Loader Class Initialized
INFO - 2019-09-10 15:45:18 --> Helper loaded: url_helper
INFO - 2019-09-10 15:45:18 --> Helper loaded: html_helper
INFO - 2019-09-10 15:45:18 --> Helper loaded: form_helper
INFO - 2019-09-10 15:45:18 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:45:18 --> Helper loaded: date_helper
INFO - 2019-09-10 15:45:18 --> Form Validation Class Initialized
INFO - 2019-09-10 15:45:18 --> Email Class Initialized
DEBUG - 2019-09-10 15:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:45:18 --> Pagination Class Initialized
INFO - 2019-09-10 15:45:18 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:18 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:18 --> Controller Class Initialized
INFO - 2019-09-10 15:45:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 15:45:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 15:45:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 15:45:18 --> Final output sent to browser
DEBUG - 2019-09-10 15:45:18 --> Total execution time: 0.2629
INFO - 2019-09-10 15:45:18 --> Config Class Initialized
INFO - 2019-09-10 15:45:18 --> Hooks Class Initialized
INFO - 2019-09-10 15:45:18 --> Config Class Initialized
INFO - 2019-09-10 15:45:18 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:45:18 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:45:18 --> Utf8 Class Initialized
DEBUG - 2019-09-10 15:45:18 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:45:18 --> Utf8 Class Initialized
INFO - 2019-09-10 15:45:18 --> URI Class Initialized
INFO - 2019-09-10 15:45:18 --> URI Class Initialized
INFO - 2019-09-10 15:45:18 --> Router Class Initialized
INFO - 2019-09-10 15:45:18 --> Router Class Initialized
INFO - 2019-09-10 15:45:18 --> Output Class Initialized
INFO - 2019-09-10 15:45:18 --> Output Class Initialized
INFO - 2019-09-10 15:45:18 --> Security Class Initialized
INFO - 2019-09-10 15:45:18 --> Security Class Initialized
DEBUG - 2019-09-10 15:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-10 15:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:45:18 --> Input Class Initialized
INFO - 2019-09-10 15:45:18 --> Input Class Initialized
INFO - 2019-09-10 15:45:18 --> Language Class Initialized
INFO - 2019-09-10 15:45:18 --> Language Class Initialized
INFO - 2019-09-10 15:45:18 --> Loader Class Initialized
INFO - 2019-09-10 15:45:18 --> Loader Class Initialized
INFO - 2019-09-10 15:45:18 --> Helper loaded: url_helper
INFO - 2019-09-10 15:45:18 --> Helper loaded: url_helper
INFO - 2019-09-10 15:45:18 --> Helper loaded: html_helper
INFO - 2019-09-10 15:45:18 --> Helper loaded: html_helper
INFO - 2019-09-10 15:45:18 --> Helper loaded: form_helper
INFO - 2019-09-10 15:45:18 --> Helper loaded: form_helper
INFO - 2019-09-10 15:45:18 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:45:18 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:45:18 --> Helper loaded: date_helper
INFO - 2019-09-10 15:45:18 --> Helper loaded: date_helper
INFO - 2019-09-10 15:45:18 --> Form Validation Class Initialized
INFO - 2019-09-10 15:45:18 --> Form Validation Class Initialized
INFO - 2019-09-10 15:45:18 --> Email Class Initialized
INFO - 2019-09-10 15:45:18 --> Email Class Initialized
DEBUG - 2019-09-10 15:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-10 15:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:45:18 --> Pagination Class Initialized
INFO - 2019-09-10 15:45:18 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:18 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:18 --> Controller Class Initialized
INFO - 2019-09-10 15:45:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 15:45:18 --> Final output sent to browser
DEBUG - 2019-09-10 15:45:18 --> Total execution time: 0.0675
INFO - 2019-09-10 15:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:45:18 --> Pagination Class Initialized
INFO - 2019-09-10 15:45:18 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:18 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:18 --> Controller Class Initialized
INFO - 2019-09-10 15:45:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 15:45:18 --> Final output sent to browser
DEBUG - 2019-09-10 15:45:18 --> Total execution time: 0.1007
INFO - 2019-09-10 15:45:39 --> Config Class Initialized
INFO - 2019-09-10 15:45:39 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:45:39 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:45:39 --> Utf8 Class Initialized
INFO - 2019-09-10 15:45:39 --> URI Class Initialized
INFO - 2019-09-10 15:45:39 --> Router Class Initialized
INFO - 2019-09-10 15:45:39 --> Output Class Initialized
INFO - 2019-09-10 15:45:39 --> Security Class Initialized
DEBUG - 2019-09-10 15:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:45:39 --> Input Class Initialized
INFO - 2019-09-10 15:45:39 --> Language Class Initialized
INFO - 2019-09-10 15:45:39 --> Loader Class Initialized
INFO - 2019-09-10 15:45:39 --> Helper loaded: url_helper
INFO - 2019-09-10 15:45:39 --> Helper loaded: html_helper
INFO - 2019-09-10 15:45:39 --> Helper loaded: form_helper
INFO - 2019-09-10 15:45:39 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:45:39 --> Helper loaded: date_helper
INFO - 2019-09-10 15:45:39 --> Form Validation Class Initialized
INFO - 2019-09-10 15:45:39 --> Email Class Initialized
DEBUG - 2019-09-10 15:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:45:39 --> Pagination Class Initialized
INFO - 2019-09-10 15:45:39 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:39 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:39 --> Controller Class Initialized
INFO - 2019-09-10 15:45:39 --> Final output sent to browser
DEBUG - 2019-09-10 15:45:39 --> Total execution time: 0.1282
INFO - 2019-09-10 15:45:42 --> Config Class Initialized
INFO - 2019-09-10 15:45:42 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:45:42 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:45:42 --> Utf8 Class Initialized
INFO - 2019-09-10 15:45:42 --> URI Class Initialized
INFO - 2019-09-10 15:45:42 --> Router Class Initialized
INFO - 2019-09-10 15:45:42 --> Output Class Initialized
INFO - 2019-09-10 15:45:42 --> Security Class Initialized
DEBUG - 2019-09-10 15:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:45:42 --> Input Class Initialized
INFO - 2019-09-10 15:45:42 --> Language Class Initialized
INFO - 2019-09-10 15:45:42 --> Loader Class Initialized
INFO - 2019-09-10 15:45:42 --> Helper loaded: url_helper
INFO - 2019-09-10 15:45:42 --> Helper loaded: html_helper
INFO - 2019-09-10 15:45:42 --> Helper loaded: form_helper
INFO - 2019-09-10 15:45:42 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:45:42 --> Helper loaded: date_helper
INFO - 2019-09-10 15:45:42 --> Form Validation Class Initialized
INFO - 2019-09-10 15:45:42 --> Email Class Initialized
DEBUG - 2019-09-10 15:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:45:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:45:42 --> Pagination Class Initialized
INFO - 2019-09-10 15:45:42 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:42 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:42 --> Controller Class Initialized
INFO - 2019-09-10 15:45:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 15:45:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 15:45:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 15:45:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 15:45:42 --> Final output sent to browser
DEBUG - 2019-09-10 15:45:42 --> Total execution time: 0.0773
INFO - 2019-09-10 15:45:42 --> Config Class Initialized
INFO - 2019-09-10 15:45:42 --> Hooks Class Initialized
INFO - 2019-09-10 15:45:42 --> Config Class Initialized
INFO - 2019-09-10 15:45:42 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:45:42 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:45:42 --> Utf8 Class Initialized
DEBUG - 2019-09-10 15:45:42 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:45:42 --> Utf8 Class Initialized
INFO - 2019-09-10 15:45:42 --> URI Class Initialized
INFO - 2019-09-10 15:45:42 --> URI Class Initialized
INFO - 2019-09-10 15:45:42 --> Router Class Initialized
INFO - 2019-09-10 15:45:42 --> Router Class Initialized
INFO - 2019-09-10 15:45:42 --> Output Class Initialized
INFO - 2019-09-10 15:45:42 --> Security Class Initialized
INFO - 2019-09-10 15:45:42 --> Output Class Initialized
INFO - 2019-09-10 15:45:42 --> Security Class Initialized
DEBUG - 2019-09-10 15:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:45:42 --> Input Class Initialized
INFO - 2019-09-10 15:45:42 --> Language Class Initialized
DEBUG - 2019-09-10 15:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:45:42 --> Input Class Initialized
INFO - 2019-09-10 15:45:42 --> Language Class Initialized
INFO - 2019-09-10 15:45:42 --> Loader Class Initialized
INFO - 2019-09-10 15:45:42 --> Loader Class Initialized
INFO - 2019-09-10 15:45:42 --> Helper loaded: url_helper
INFO - 2019-09-10 15:45:42 --> Helper loaded: html_helper
INFO - 2019-09-10 15:45:42 --> Helper loaded: url_helper
INFO - 2019-09-10 15:45:42 --> Helper loaded: form_helper
INFO - 2019-09-10 15:45:42 --> Helper loaded: html_helper
INFO - 2019-09-10 15:45:42 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:45:42 --> Helper loaded: form_helper
INFO - 2019-09-10 15:45:42 --> Helper loaded: date_helper
INFO - 2019-09-10 15:45:42 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:45:42 --> Helper loaded: date_helper
INFO - 2019-09-10 15:45:42 --> Form Validation Class Initialized
INFO - 2019-09-10 15:45:42 --> Form Validation Class Initialized
INFO - 2019-09-10 15:45:42 --> Email Class Initialized
INFO - 2019-09-10 15:45:42 --> Email Class Initialized
DEBUG - 2019-09-10 15:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:45:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-09-10 15:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:45:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:45:42 --> Pagination Class Initialized
INFO - 2019-09-10 15:45:42 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:42 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:42 --> Controller Class Initialized
INFO - 2019-09-10 15:45:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 15:45:42 --> Final output sent to browser
DEBUG - 2019-09-10 15:45:42 --> Total execution time: 0.0628
INFO - 2019-09-10 15:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:45:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:45:42 --> Pagination Class Initialized
INFO - 2019-09-10 15:45:42 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:42 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:42 --> Controller Class Initialized
INFO - 2019-09-10 15:45:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 15:45:42 --> Final output sent to browser
DEBUG - 2019-09-10 15:45:42 --> Total execution time: 0.0876
INFO - 2019-09-10 15:45:55 --> Config Class Initialized
INFO - 2019-09-10 15:45:55 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:45:55 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:45:55 --> Utf8 Class Initialized
INFO - 2019-09-10 15:45:55 --> URI Class Initialized
INFO - 2019-09-10 15:45:55 --> Router Class Initialized
INFO - 2019-09-10 15:45:55 --> Output Class Initialized
INFO - 2019-09-10 15:45:55 --> Security Class Initialized
DEBUG - 2019-09-10 15:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:45:55 --> Input Class Initialized
INFO - 2019-09-10 15:45:55 --> Language Class Initialized
INFO - 2019-09-10 15:45:55 --> Loader Class Initialized
INFO - 2019-09-10 15:45:55 --> Helper loaded: url_helper
INFO - 2019-09-10 15:45:55 --> Helper loaded: html_helper
INFO - 2019-09-10 15:45:55 --> Helper loaded: form_helper
INFO - 2019-09-10 15:45:55 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:45:55 --> Helper loaded: date_helper
INFO - 2019-09-10 15:45:55 --> Form Validation Class Initialized
INFO - 2019-09-10 15:45:55 --> Email Class Initialized
DEBUG - 2019-09-10 15:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:45:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:45:55 --> Pagination Class Initialized
INFO - 2019-09-10 15:45:55 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:55 --> Database Driver Class Initialized
INFO - 2019-09-10 15:45:55 --> Controller Class Initialized
INFO - 2019-09-10 15:45:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 15:53:27 --> Config Class Initialized
INFO - 2019-09-10 15:53:27 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:53:27 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:53:27 --> Utf8 Class Initialized
INFO - 2019-09-10 15:53:27 --> URI Class Initialized
INFO - 2019-09-10 15:53:27 --> Router Class Initialized
INFO - 2019-09-10 15:53:27 --> Output Class Initialized
INFO - 2019-09-10 15:53:27 --> Security Class Initialized
DEBUG - 2019-09-10 15:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:53:27 --> Input Class Initialized
INFO - 2019-09-10 15:53:27 --> Language Class Initialized
INFO - 2019-09-10 15:53:27 --> Loader Class Initialized
INFO - 2019-09-10 15:53:27 --> Helper loaded: url_helper
INFO - 2019-09-10 15:53:27 --> Helper loaded: html_helper
INFO - 2019-09-10 15:53:27 --> Helper loaded: form_helper
INFO - 2019-09-10 15:53:27 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:53:27 --> Helper loaded: date_helper
INFO - 2019-09-10 15:53:27 --> Form Validation Class Initialized
INFO - 2019-09-10 15:53:27 --> Email Class Initialized
DEBUG - 2019-09-10 15:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:53:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:53:27 --> Pagination Class Initialized
INFO - 2019-09-10 15:53:27 --> Database Driver Class Initialized
INFO - 2019-09-10 15:53:27 --> Database Driver Class Initialized
INFO - 2019-09-10 15:53:27 --> Controller Class Initialized
INFO - 2019-09-10 15:53:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 15:55:05 --> Config Class Initialized
INFO - 2019-09-10 15:55:05 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:55:05 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:55:05 --> Utf8 Class Initialized
INFO - 2019-09-10 15:55:05 --> URI Class Initialized
INFO - 2019-09-10 15:55:05 --> Router Class Initialized
INFO - 2019-09-10 15:55:05 --> Output Class Initialized
INFO - 2019-09-10 15:55:05 --> Security Class Initialized
DEBUG - 2019-09-10 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:55:05 --> Input Class Initialized
INFO - 2019-09-10 15:55:05 --> Language Class Initialized
INFO - 2019-09-10 15:55:05 --> Loader Class Initialized
INFO - 2019-09-10 15:55:05 --> Helper loaded: url_helper
INFO - 2019-09-10 15:55:05 --> Helper loaded: html_helper
INFO - 2019-09-10 15:55:05 --> Helper loaded: form_helper
INFO - 2019-09-10 15:55:05 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:55:05 --> Helper loaded: date_helper
INFO - 2019-09-10 15:55:05 --> Form Validation Class Initialized
INFO - 2019-09-10 15:55:05 --> Email Class Initialized
DEBUG - 2019-09-10 15:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:55:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:55:05 --> Pagination Class Initialized
INFO - 2019-09-10 15:55:05 --> Database Driver Class Initialized
INFO - 2019-09-10 15:55:05 --> Database Driver Class Initialized
INFO - 2019-09-10 15:55:05 --> Controller Class Initialized
INFO - 2019-09-10 15:55:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 15:55:10 --> Config Class Initialized
INFO - 2019-09-10 15:55:10 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:55:10 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:55:10 --> Utf8 Class Initialized
INFO - 2019-09-10 15:55:10 --> URI Class Initialized
INFO - 2019-09-10 15:55:11 --> Router Class Initialized
INFO - 2019-09-10 15:55:11 --> Output Class Initialized
INFO - 2019-09-10 15:55:11 --> Security Class Initialized
DEBUG - 2019-09-10 15:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:55:11 --> Input Class Initialized
INFO - 2019-09-10 15:55:11 --> Language Class Initialized
INFO - 2019-09-10 15:55:11 --> Loader Class Initialized
INFO - 2019-09-10 15:55:11 --> Helper loaded: url_helper
INFO - 2019-09-10 15:55:11 --> Helper loaded: html_helper
INFO - 2019-09-10 15:55:11 --> Helper loaded: form_helper
INFO - 2019-09-10 15:55:11 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:55:11 --> Helper loaded: date_helper
INFO - 2019-09-10 15:55:11 --> Form Validation Class Initialized
INFO - 2019-09-10 15:55:11 --> Email Class Initialized
DEBUG - 2019-09-10 15:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:55:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:55:11 --> Pagination Class Initialized
INFO - 2019-09-10 15:55:11 --> Database Driver Class Initialized
INFO - 2019-09-10 15:55:11 --> Database Driver Class Initialized
INFO - 2019-09-10 15:55:11 --> Controller Class Initialized
INFO - 2019-09-10 15:55:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 15:55:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 15:55:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 15:55:11 --> Final output sent to browser
DEBUG - 2019-09-10 15:55:11 --> Total execution time: 0.0984
INFO - 2019-09-10 15:55:11 --> Config Class Initialized
INFO - 2019-09-10 15:55:11 --> Hooks Class Initialized
INFO - 2019-09-10 15:55:11 --> Config Class Initialized
INFO - 2019-09-10 15:55:11 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:55:11 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:55:11 --> Utf8 Class Initialized
DEBUG - 2019-09-10 15:55:11 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:55:11 --> Utf8 Class Initialized
INFO - 2019-09-10 15:55:11 --> URI Class Initialized
INFO - 2019-09-10 15:55:11 --> URI Class Initialized
INFO - 2019-09-10 15:55:11 --> Router Class Initialized
INFO - 2019-09-10 15:55:11 --> Router Class Initialized
INFO - 2019-09-10 15:55:11 --> Output Class Initialized
INFO - 2019-09-10 15:55:11 --> Output Class Initialized
INFO - 2019-09-10 15:55:11 --> Security Class Initialized
INFO - 2019-09-10 15:55:11 --> Security Class Initialized
DEBUG - 2019-09-10 15:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:55:11 --> Input Class Initialized
DEBUG - 2019-09-10 15:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:55:11 --> Input Class Initialized
INFO - 2019-09-10 15:55:11 --> Language Class Initialized
INFO - 2019-09-10 15:55:11 --> Language Class Initialized
INFO - 2019-09-10 15:55:11 --> Loader Class Initialized
INFO - 2019-09-10 15:55:11 --> Loader Class Initialized
INFO - 2019-09-10 15:55:11 --> Helper loaded: url_helper
INFO - 2019-09-10 15:55:11 --> Helper loaded: url_helper
INFO - 2019-09-10 15:55:11 --> Helper loaded: html_helper
INFO - 2019-09-10 15:55:11 --> Helper loaded: html_helper
INFO - 2019-09-10 15:55:11 --> Helper loaded: form_helper
INFO - 2019-09-10 15:55:11 --> Helper loaded: form_helper
INFO - 2019-09-10 15:55:11 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:55:11 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:55:11 --> Helper loaded: date_helper
INFO - 2019-09-10 15:55:11 --> Helper loaded: date_helper
INFO - 2019-09-10 15:55:11 --> Form Validation Class Initialized
INFO - 2019-09-10 15:55:11 --> Form Validation Class Initialized
INFO - 2019-09-10 15:55:11 --> Email Class Initialized
INFO - 2019-09-10 15:55:11 --> Email Class Initialized
DEBUG - 2019-09-10 15:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-10 15:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:55:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:55:11 --> Pagination Class Initialized
INFO - 2019-09-10 15:55:11 --> Database Driver Class Initialized
INFO - 2019-09-10 15:55:11 --> Database Driver Class Initialized
INFO - 2019-09-10 15:55:11 --> Controller Class Initialized
INFO - 2019-09-10 15:55:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 15:55:11 --> Final output sent to browser
DEBUG - 2019-09-10 15:55:11 --> Total execution time: 0.0688
INFO - 2019-09-10 15:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:55:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:55:11 --> Pagination Class Initialized
INFO - 2019-09-10 15:55:11 --> Database Driver Class Initialized
INFO - 2019-09-10 15:55:11 --> Database Driver Class Initialized
INFO - 2019-09-10 15:55:11 --> Controller Class Initialized
INFO - 2019-09-10 15:55:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 15:55:11 --> Final output sent to browser
DEBUG - 2019-09-10 15:55:11 --> Total execution time: 0.1193
INFO - 2019-09-10 15:55:43 --> Config Class Initialized
INFO - 2019-09-10 15:55:43 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:55:43 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:55:43 --> Utf8 Class Initialized
INFO - 2019-09-10 15:55:43 --> URI Class Initialized
INFO - 2019-09-10 15:55:43 --> Router Class Initialized
INFO - 2019-09-10 15:55:43 --> Output Class Initialized
INFO - 2019-09-10 15:55:43 --> Security Class Initialized
DEBUG - 2019-09-10 15:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:55:43 --> Input Class Initialized
INFO - 2019-09-10 15:55:43 --> Language Class Initialized
INFO - 2019-09-10 15:55:43 --> Loader Class Initialized
INFO - 2019-09-10 15:55:43 --> Helper loaded: url_helper
INFO - 2019-09-10 15:55:43 --> Helper loaded: html_helper
INFO - 2019-09-10 15:55:43 --> Helper loaded: form_helper
INFO - 2019-09-10 15:55:43 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:55:43 --> Helper loaded: date_helper
INFO - 2019-09-10 15:55:43 --> Form Validation Class Initialized
INFO - 2019-09-10 15:55:43 --> Email Class Initialized
DEBUG - 2019-09-10 15:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:55:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:55:43 --> Pagination Class Initialized
INFO - 2019-09-10 15:55:43 --> Database Driver Class Initialized
INFO - 2019-09-10 15:55:43 --> Database Driver Class Initialized
INFO - 2019-09-10 15:55:43 --> Controller Class Initialized
INFO - 2019-09-10 15:55:43 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 15:55:43 --> Final output sent to browser
DEBUG - 2019-09-10 15:55:43 --> Total execution time: 0.0597
INFO - 2019-09-10 15:55:49 --> Config Class Initialized
INFO - 2019-09-10 15:55:49 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:55:49 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:55:49 --> Utf8 Class Initialized
INFO - 2019-09-10 15:55:49 --> URI Class Initialized
INFO - 2019-09-10 15:55:49 --> Router Class Initialized
INFO - 2019-09-10 15:55:49 --> Output Class Initialized
INFO - 2019-09-10 15:55:49 --> Security Class Initialized
DEBUG - 2019-09-10 15:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:55:49 --> Input Class Initialized
INFO - 2019-09-10 15:55:49 --> Language Class Initialized
INFO - 2019-09-10 15:55:49 --> Loader Class Initialized
INFO - 2019-09-10 15:55:49 --> Helper loaded: url_helper
INFO - 2019-09-10 15:55:49 --> Helper loaded: html_helper
INFO - 2019-09-10 15:55:49 --> Helper loaded: form_helper
INFO - 2019-09-10 15:55:49 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:55:49 --> Helper loaded: date_helper
INFO - 2019-09-10 15:55:49 --> Form Validation Class Initialized
INFO - 2019-09-10 15:55:49 --> Email Class Initialized
DEBUG - 2019-09-10 15:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:55:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:55:49 --> Pagination Class Initialized
INFO - 2019-09-10 15:55:50 --> Database Driver Class Initialized
INFO - 2019-09-10 15:55:50 --> Database Driver Class Initialized
INFO - 2019-09-10 15:55:50 --> Controller Class Initialized
INFO - 2019-09-10 15:55:50 --> Final output sent to browser
DEBUG - 2019-09-10 15:55:50 --> Total execution time: 0.0503
INFO - 2019-09-10 15:55:55 --> Config Class Initialized
INFO - 2019-09-10 15:55:55 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:55:55 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:55:55 --> Utf8 Class Initialized
INFO - 2019-09-10 15:55:55 --> URI Class Initialized
INFO - 2019-09-10 15:55:55 --> Router Class Initialized
INFO - 2019-09-10 15:55:55 --> Output Class Initialized
INFO - 2019-09-10 15:55:55 --> Security Class Initialized
DEBUG - 2019-09-10 15:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:55:55 --> Input Class Initialized
INFO - 2019-09-10 15:55:55 --> Language Class Initialized
INFO - 2019-09-10 15:55:55 --> Loader Class Initialized
INFO - 2019-09-10 15:55:55 --> Helper loaded: url_helper
INFO - 2019-09-10 15:55:55 --> Helper loaded: html_helper
INFO - 2019-09-10 15:55:55 --> Helper loaded: form_helper
INFO - 2019-09-10 15:55:55 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:55:55 --> Helper loaded: date_helper
INFO - 2019-09-10 15:55:55 --> Form Validation Class Initialized
INFO - 2019-09-10 15:55:55 --> Email Class Initialized
DEBUG - 2019-09-10 15:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:55:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:55:55 --> Pagination Class Initialized
INFO - 2019-09-10 15:55:55 --> Database Driver Class Initialized
INFO - 2019-09-10 15:55:55 --> Database Driver Class Initialized
INFO - 2019-09-10 15:55:55 --> Controller Class Initialized
INFO - 2019-09-10 15:55:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 15:56:27 --> Config Class Initialized
INFO - 2019-09-10 15:56:27 --> Hooks Class Initialized
DEBUG - 2019-09-10 15:56:27 --> UTF-8 Support Enabled
INFO - 2019-09-10 15:56:27 --> Utf8 Class Initialized
INFO - 2019-09-10 15:56:27 --> URI Class Initialized
INFO - 2019-09-10 15:56:27 --> Router Class Initialized
INFO - 2019-09-10 15:56:27 --> Output Class Initialized
INFO - 2019-09-10 15:56:27 --> Security Class Initialized
DEBUG - 2019-09-10 15:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 15:56:27 --> Input Class Initialized
INFO - 2019-09-10 15:56:27 --> Language Class Initialized
INFO - 2019-09-10 15:56:27 --> Loader Class Initialized
INFO - 2019-09-10 15:56:27 --> Helper loaded: url_helper
INFO - 2019-09-10 15:56:27 --> Helper loaded: html_helper
INFO - 2019-09-10 15:56:27 --> Helper loaded: form_helper
INFO - 2019-09-10 15:56:27 --> Helper loaded: cookie_helper
INFO - 2019-09-10 15:56:27 --> Helper loaded: date_helper
INFO - 2019-09-10 15:56:27 --> Form Validation Class Initialized
INFO - 2019-09-10 15:56:27 --> Email Class Initialized
DEBUG - 2019-09-10 15:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 15:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 15:56:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 15:56:27 --> Pagination Class Initialized
INFO - 2019-09-10 15:56:27 --> Database Driver Class Initialized
INFO - 2019-09-10 15:56:27 --> Database Driver Class Initialized
INFO - 2019-09-10 15:56:27 --> Controller Class Initialized
INFO - 2019-09-10 15:56:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 16:08:07 --> Config Class Initialized
INFO - 2019-09-10 16:08:07 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:08:08 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:08:08 --> Utf8 Class Initialized
INFO - 2019-09-10 16:08:08 --> URI Class Initialized
INFO - 2019-09-10 16:08:08 --> Router Class Initialized
INFO - 2019-09-10 16:08:08 --> Output Class Initialized
INFO - 2019-09-10 16:08:08 --> Security Class Initialized
DEBUG - 2019-09-10 16:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:08:08 --> Input Class Initialized
INFO - 2019-09-10 16:08:08 --> Language Class Initialized
INFO - 2019-09-10 16:08:08 --> Loader Class Initialized
INFO - 2019-09-10 16:08:08 --> Helper loaded: url_helper
INFO - 2019-09-10 16:08:08 --> Helper loaded: html_helper
INFO - 2019-09-10 16:08:08 --> Helper loaded: form_helper
INFO - 2019-09-10 16:08:08 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:08:08 --> Helper loaded: date_helper
INFO - 2019-09-10 16:08:08 --> Form Validation Class Initialized
INFO - 2019-09-10 16:08:08 --> Email Class Initialized
DEBUG - 2019-09-10 16:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:08:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:08:08 --> Pagination Class Initialized
INFO - 2019-09-10 16:08:08 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:08 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:08 --> Controller Class Initialized
INFO - 2019-09-10 16:08:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:08:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 16:08:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:08:08 --> Final output sent to browser
DEBUG - 2019-09-10 16:08:08 --> Total execution time: 0.0986
INFO - 2019-09-10 16:08:08 --> Config Class Initialized
INFO - 2019-09-10 16:08:08 --> Hooks Class Initialized
INFO - 2019-09-10 16:08:08 --> Config Class Initialized
INFO - 2019-09-10 16:08:08 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:08:08 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:08:08 --> Utf8 Class Initialized
DEBUG - 2019-09-10 16:08:08 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:08:08 --> Utf8 Class Initialized
INFO - 2019-09-10 16:08:08 --> URI Class Initialized
INFO - 2019-09-10 16:08:08 --> URI Class Initialized
INFO - 2019-09-10 16:08:08 --> Router Class Initialized
INFO - 2019-09-10 16:08:08 --> Router Class Initialized
INFO - 2019-09-10 16:08:08 --> Output Class Initialized
INFO - 2019-09-10 16:08:08 --> Output Class Initialized
INFO - 2019-09-10 16:08:08 --> Security Class Initialized
INFO - 2019-09-10 16:08:08 --> Security Class Initialized
DEBUG - 2019-09-10 16:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:08:08 --> Input Class Initialized
INFO - 2019-09-10 16:08:08 --> Language Class Initialized
DEBUG - 2019-09-10 16:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:08:08 --> Input Class Initialized
INFO - 2019-09-10 16:08:08 --> Language Class Initialized
INFO - 2019-09-10 16:08:08 --> Loader Class Initialized
INFO - 2019-09-10 16:08:08 --> Loader Class Initialized
INFO - 2019-09-10 16:08:08 --> Helper loaded: url_helper
INFO - 2019-09-10 16:08:08 --> Helper loaded: html_helper
INFO - 2019-09-10 16:08:08 --> Helper loaded: url_helper
INFO - 2019-09-10 16:08:08 --> Helper loaded: html_helper
INFO - 2019-09-10 16:08:08 --> Helper loaded: form_helper
INFO - 2019-09-10 16:08:08 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:08:08 --> Helper loaded: form_helper
INFO - 2019-09-10 16:08:08 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:08:08 --> Helper loaded: date_helper
INFO - 2019-09-10 16:08:08 --> Helper loaded: date_helper
INFO - 2019-09-10 16:08:08 --> Form Validation Class Initialized
INFO - 2019-09-10 16:08:08 --> Form Validation Class Initialized
INFO - 2019-09-10 16:08:08 --> Email Class Initialized
INFO - 2019-09-10 16:08:08 --> Email Class Initialized
DEBUG - 2019-09-10 16:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-10 16:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:08:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:08:08 --> Pagination Class Initialized
INFO - 2019-09-10 16:08:08 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:08 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:08 --> Controller Class Initialized
INFO - 2019-09-10 16:08:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:08:08 --> Final output sent to browser
DEBUG - 2019-09-10 16:08:08 --> Total execution time: 0.0803
INFO - 2019-09-10 16:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:08:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:08:08 --> Pagination Class Initialized
INFO - 2019-09-10 16:08:08 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:08 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:08 --> Controller Class Initialized
INFO - 2019-09-10 16:08:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:08:08 --> Final output sent to browser
DEBUG - 2019-09-10 16:08:08 --> Total execution time: 0.1188
INFO - 2019-09-10 16:08:08 --> Config Class Initialized
INFO - 2019-09-10 16:08:08 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:08:08 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:08:08 --> Utf8 Class Initialized
INFO - 2019-09-10 16:08:08 --> URI Class Initialized
INFO - 2019-09-10 16:08:08 --> Router Class Initialized
INFO - 2019-09-10 16:08:08 --> Output Class Initialized
INFO - 2019-09-10 16:08:08 --> Security Class Initialized
DEBUG - 2019-09-10 16:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:08:08 --> Input Class Initialized
INFO - 2019-09-10 16:08:08 --> Language Class Initialized
INFO - 2019-09-10 16:08:08 --> Loader Class Initialized
INFO - 2019-09-10 16:08:08 --> Helper loaded: url_helper
INFO - 2019-09-10 16:08:08 --> Helper loaded: html_helper
INFO - 2019-09-10 16:08:08 --> Helper loaded: form_helper
INFO - 2019-09-10 16:08:08 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:08:08 --> Helper loaded: date_helper
INFO - 2019-09-10 16:08:08 --> Form Validation Class Initialized
INFO - 2019-09-10 16:08:08 --> Email Class Initialized
DEBUG - 2019-09-10 16:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:08:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:08:08 --> Pagination Class Initialized
INFO - 2019-09-10 16:08:08 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:08 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:08 --> Controller Class Initialized
INFO - 2019-09-10 16:08:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:08:08 --> Final output sent to browser
DEBUG - 2019-09-10 16:08:08 --> Total execution time: 0.0721
INFO - 2019-09-10 16:08:09 --> Config Class Initialized
INFO - 2019-09-10 16:08:09 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:08:09 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:08:09 --> Utf8 Class Initialized
INFO - 2019-09-10 16:08:09 --> URI Class Initialized
INFO - 2019-09-10 16:08:09 --> Router Class Initialized
INFO - 2019-09-10 16:08:09 --> Output Class Initialized
INFO - 2019-09-10 16:08:09 --> Security Class Initialized
DEBUG - 2019-09-10 16:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:08:09 --> Input Class Initialized
INFO - 2019-09-10 16:08:09 --> Language Class Initialized
INFO - 2019-09-10 16:08:09 --> Loader Class Initialized
INFO - 2019-09-10 16:08:09 --> Helper loaded: url_helper
INFO - 2019-09-10 16:08:09 --> Helper loaded: html_helper
INFO - 2019-09-10 16:08:09 --> Helper loaded: form_helper
INFO - 2019-09-10 16:08:09 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:08:09 --> Helper loaded: date_helper
INFO - 2019-09-10 16:08:09 --> Form Validation Class Initialized
INFO - 2019-09-10 16:08:09 --> Email Class Initialized
DEBUG - 2019-09-10 16:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:08:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:08:09 --> Pagination Class Initialized
INFO - 2019-09-10 16:08:09 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:09 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:09 --> Controller Class Initialized
INFO - 2019-09-10 16:08:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:08:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 16:08:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:08:09 --> Final output sent to browser
DEBUG - 2019-09-10 16:08:09 --> Total execution time: 0.0914
INFO - 2019-09-10 16:08:10 --> Config Class Initialized
INFO - 2019-09-10 16:08:10 --> Hooks Class Initialized
INFO - 2019-09-10 16:08:10 --> Config Class Initialized
INFO - 2019-09-10 16:08:10 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:08:10 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:08:10 --> Utf8 Class Initialized
INFO - 2019-09-10 16:08:10 --> URI Class Initialized
DEBUG - 2019-09-10 16:08:10 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:08:10 --> Utf8 Class Initialized
INFO - 2019-09-10 16:08:10 --> Router Class Initialized
INFO - 2019-09-10 16:08:10 --> URI Class Initialized
INFO - 2019-09-10 16:08:10 --> Output Class Initialized
INFO - 2019-09-10 16:08:10 --> Router Class Initialized
INFO - 2019-09-10 16:08:10 --> Security Class Initialized
INFO - 2019-09-10 16:08:10 --> Output Class Initialized
DEBUG - 2019-09-10 16:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:08:10 --> Input Class Initialized
INFO - 2019-09-10 16:08:10 --> Security Class Initialized
INFO - 2019-09-10 16:08:10 --> Language Class Initialized
DEBUG - 2019-09-10 16:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:08:10 --> Input Class Initialized
INFO - 2019-09-10 16:08:10 --> Language Class Initialized
INFO - 2019-09-10 16:08:10 --> Loader Class Initialized
INFO - 2019-09-10 16:08:10 --> Helper loaded: url_helper
INFO - 2019-09-10 16:08:10 --> Loader Class Initialized
INFO - 2019-09-10 16:08:10 --> Helper loaded: html_helper
INFO - 2019-09-10 16:08:10 --> Helper loaded: url_helper
INFO - 2019-09-10 16:08:10 --> Helper loaded: form_helper
INFO - 2019-09-10 16:08:10 --> Helper loaded: html_helper
INFO - 2019-09-10 16:08:10 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:08:10 --> Helper loaded: form_helper
INFO - 2019-09-10 16:08:10 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:08:10 --> Helper loaded: date_helper
INFO - 2019-09-10 16:08:10 --> Helper loaded: date_helper
INFO - 2019-09-10 16:08:10 --> Form Validation Class Initialized
INFO - 2019-09-10 16:08:10 --> Form Validation Class Initialized
INFO - 2019-09-10 16:08:10 --> Email Class Initialized
INFO - 2019-09-10 16:08:10 --> Email Class Initialized
DEBUG - 2019-09-10 16:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-10 16:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:08:10 --> Pagination Class Initialized
INFO - 2019-09-10 16:08:10 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:10 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:10 --> Controller Class Initialized
INFO - 2019-09-10 16:08:10 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:08:10 --> Final output sent to browser
DEBUG - 2019-09-10 16:08:10 --> Total execution time: 0.0692
INFO - 2019-09-10 16:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:08:10 --> Pagination Class Initialized
INFO - 2019-09-10 16:08:10 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:10 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:10 --> Controller Class Initialized
INFO - 2019-09-10 16:08:10 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:08:10 --> Final output sent to browser
DEBUG - 2019-09-10 16:08:10 --> Total execution time: 0.1018
INFO - 2019-09-10 16:08:14 --> Config Class Initialized
INFO - 2019-09-10 16:08:14 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:08:14 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:08:14 --> Utf8 Class Initialized
INFO - 2019-09-10 16:08:14 --> URI Class Initialized
INFO - 2019-09-10 16:08:14 --> Router Class Initialized
INFO - 2019-09-10 16:08:14 --> Output Class Initialized
INFO - 2019-09-10 16:08:14 --> Security Class Initialized
DEBUG - 2019-09-10 16:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:08:14 --> Input Class Initialized
INFO - 2019-09-10 16:08:14 --> Language Class Initialized
INFO - 2019-09-10 16:08:14 --> Loader Class Initialized
INFO - 2019-09-10 16:08:14 --> Helper loaded: url_helper
INFO - 2019-09-10 16:08:14 --> Helper loaded: html_helper
INFO - 2019-09-10 16:08:14 --> Helper loaded: form_helper
INFO - 2019-09-10 16:08:14 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:08:14 --> Helper loaded: date_helper
INFO - 2019-09-10 16:08:14 --> Form Validation Class Initialized
INFO - 2019-09-10 16:08:14 --> Email Class Initialized
DEBUG - 2019-09-10 16:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:08:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:08:14 --> Pagination Class Initialized
INFO - 2019-09-10 16:08:14 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:14 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:14 --> Controller Class Initialized
INFO - 2019-09-10 16:08:14 --> Final output sent to browser
DEBUG - 2019-09-10 16:08:14 --> Total execution time: 0.0507
INFO - 2019-09-10 16:08:21 --> Config Class Initialized
INFO - 2019-09-10 16:08:21 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:08:21 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:08:21 --> Utf8 Class Initialized
INFO - 2019-09-10 16:08:21 --> URI Class Initialized
INFO - 2019-09-10 16:08:21 --> Router Class Initialized
INFO - 2019-09-10 16:08:21 --> Output Class Initialized
INFO - 2019-09-10 16:08:21 --> Security Class Initialized
DEBUG - 2019-09-10 16:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:08:21 --> Input Class Initialized
INFO - 2019-09-10 16:08:21 --> Language Class Initialized
INFO - 2019-09-10 16:08:21 --> Loader Class Initialized
INFO - 2019-09-10 16:08:21 --> Helper loaded: url_helper
INFO - 2019-09-10 16:08:21 --> Helper loaded: html_helper
INFO - 2019-09-10 16:08:21 --> Helper loaded: form_helper
INFO - 2019-09-10 16:08:21 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:08:21 --> Helper loaded: date_helper
INFO - 2019-09-10 16:08:21 --> Form Validation Class Initialized
INFO - 2019-09-10 16:08:21 --> Email Class Initialized
DEBUG - 2019-09-10 16:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:08:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:08:21 --> Pagination Class Initialized
INFO - 2019-09-10 16:08:21 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:21 --> Database Driver Class Initialized
INFO - 2019-09-10 16:08:21 --> Controller Class Initialized
INFO - 2019-09-10 16:08:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2019-09-10 16:08:21 --> Severity: Notice --> Undefined variable: config C:\wamp64\www\pridehotel_lagos\application\models\Resv_model.php 2555
ERROR - 2019-09-10 16:08:21 --> Severity: error --> Exception: Cannot access empty property C:\wamp64\www\pridehotel_lagos\system\core\Model.php 77
INFO - 2019-09-10 16:09:30 --> Config Class Initialized
INFO - 2019-09-10 16:09:30 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:09:30 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:09:30 --> Utf8 Class Initialized
INFO - 2019-09-10 16:09:30 --> URI Class Initialized
INFO - 2019-09-10 16:09:30 --> Router Class Initialized
INFO - 2019-09-10 16:09:30 --> Output Class Initialized
INFO - 2019-09-10 16:09:30 --> Security Class Initialized
DEBUG - 2019-09-10 16:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:09:30 --> Input Class Initialized
INFO - 2019-09-10 16:09:30 --> Language Class Initialized
INFO - 2019-09-10 16:09:30 --> Loader Class Initialized
INFO - 2019-09-10 16:09:30 --> Helper loaded: url_helper
INFO - 2019-09-10 16:09:30 --> Helper loaded: html_helper
INFO - 2019-09-10 16:09:30 --> Helper loaded: form_helper
INFO - 2019-09-10 16:09:30 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:09:30 --> Helper loaded: date_helper
INFO - 2019-09-10 16:09:30 --> Form Validation Class Initialized
INFO - 2019-09-10 16:09:30 --> Email Class Initialized
DEBUG - 2019-09-10 16:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:09:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:09:30 --> Pagination Class Initialized
INFO - 2019-09-10 16:09:30 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:30 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:30 --> Controller Class Initialized
INFO - 2019-09-10 16:09:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 16:09:31 --> Config Class Initialized
INFO - 2019-09-10 16:09:31 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:09:31 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:09:31 --> Utf8 Class Initialized
INFO - 2019-09-10 16:09:31 --> URI Class Initialized
INFO - 2019-09-10 16:09:31 --> Router Class Initialized
INFO - 2019-09-10 16:09:31 --> Output Class Initialized
INFO - 2019-09-10 16:09:31 --> Security Class Initialized
DEBUG - 2019-09-10 16:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:09:31 --> Input Class Initialized
INFO - 2019-09-10 16:09:31 --> Language Class Initialized
INFO - 2019-09-10 16:09:31 --> Loader Class Initialized
INFO - 2019-09-10 16:09:31 --> Helper loaded: url_helper
INFO - 2019-09-10 16:09:31 --> Helper loaded: html_helper
INFO - 2019-09-10 16:09:31 --> Helper loaded: form_helper
INFO - 2019-09-10 16:09:31 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:09:31 --> Helper loaded: date_helper
INFO - 2019-09-10 16:09:31 --> Form Validation Class Initialized
INFO - 2019-09-10 16:09:31 --> Email Class Initialized
DEBUG - 2019-09-10 16:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:09:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:09:31 --> Pagination Class Initialized
INFO - 2019-09-10 16:09:31 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:31 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:31 --> Controller Class Initialized
INFO - 2019-09-10 16:09:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:09:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 16:09:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:09:31 --> Final output sent to browser
DEBUG - 2019-09-10 16:09:31 --> Total execution time: 0.0634
INFO - 2019-09-10 16:09:31 --> Config Class Initialized
INFO - 2019-09-10 16:09:31 --> Hooks Class Initialized
INFO - 2019-09-10 16:09:31 --> Config Class Initialized
INFO - 2019-09-10 16:09:31 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:09:31 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:09:31 --> Utf8 Class Initialized
INFO - 2019-09-10 16:09:31 --> URI Class Initialized
DEBUG - 2019-09-10 16:09:31 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:09:31 --> Router Class Initialized
INFO - 2019-09-10 16:09:31 --> Utf8 Class Initialized
INFO - 2019-09-10 16:09:31 --> URI Class Initialized
INFO - 2019-09-10 16:09:31 --> Output Class Initialized
INFO - 2019-09-10 16:09:31 --> Security Class Initialized
INFO - 2019-09-10 16:09:31 --> Router Class Initialized
DEBUG - 2019-09-10 16:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:09:31 --> Input Class Initialized
INFO - 2019-09-10 16:09:31 --> Output Class Initialized
INFO - 2019-09-10 16:09:31 --> Language Class Initialized
INFO - 2019-09-10 16:09:31 --> Security Class Initialized
DEBUG - 2019-09-10 16:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:09:31 --> Input Class Initialized
INFO - 2019-09-10 16:09:31 --> Language Class Initialized
INFO - 2019-09-10 16:09:31 --> Loader Class Initialized
INFO - 2019-09-10 16:09:31 --> Helper loaded: url_helper
INFO - 2019-09-10 16:09:31 --> Helper loaded: html_helper
INFO - 2019-09-10 16:09:31 --> Helper loaded: form_helper
INFO - 2019-09-10 16:09:31 --> Loader Class Initialized
INFO - 2019-09-10 16:09:31 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:09:31 --> Helper loaded: date_helper
INFO - 2019-09-10 16:09:31 --> Helper loaded: url_helper
INFO - 2019-09-10 16:09:31 --> Helper loaded: html_helper
INFO - 2019-09-10 16:09:31 --> Form Validation Class Initialized
INFO - 2019-09-10 16:09:31 --> Helper loaded: form_helper
INFO - 2019-09-10 16:09:31 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:09:31 --> Email Class Initialized
DEBUG - 2019-09-10 16:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:09:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:09:31 --> Pagination Class Initialized
INFO - 2019-09-10 16:09:31 --> Helper loaded: date_helper
INFO - 2019-09-10 16:09:31 --> Form Validation Class Initialized
INFO - 2019-09-10 16:09:31 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:31 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:31 --> Email Class Initialized
DEBUG - 2019-09-10 16:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:09:31 --> Controller Class Initialized
INFO - 2019-09-10 16:09:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:09:31 --> Final output sent to browser
DEBUG - 2019-09-10 16:09:31 --> Total execution time: 0.0696
INFO - 2019-09-10 16:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:09:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:09:31 --> Pagination Class Initialized
INFO - 2019-09-10 16:09:31 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:31 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:31 --> Controller Class Initialized
INFO - 2019-09-10 16:09:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:09:31 --> Final output sent to browser
DEBUG - 2019-09-10 16:09:31 --> Total execution time: 0.1017
INFO - 2019-09-10 16:09:45 --> Config Class Initialized
INFO - 2019-09-10 16:09:45 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:09:45 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:09:45 --> Utf8 Class Initialized
INFO - 2019-09-10 16:09:45 --> URI Class Initialized
INFO - 2019-09-10 16:09:45 --> Router Class Initialized
INFO - 2019-09-10 16:09:45 --> Output Class Initialized
INFO - 2019-09-10 16:09:45 --> Security Class Initialized
DEBUG - 2019-09-10 16:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:09:45 --> Input Class Initialized
INFO - 2019-09-10 16:09:45 --> Language Class Initialized
INFO - 2019-09-10 16:09:45 --> Loader Class Initialized
INFO - 2019-09-10 16:09:45 --> Helper loaded: url_helper
INFO - 2019-09-10 16:09:45 --> Helper loaded: html_helper
INFO - 2019-09-10 16:09:45 --> Helper loaded: form_helper
INFO - 2019-09-10 16:09:45 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:09:45 --> Helper loaded: date_helper
INFO - 2019-09-10 16:09:45 --> Form Validation Class Initialized
INFO - 2019-09-10 16:09:45 --> Email Class Initialized
DEBUG - 2019-09-10 16:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:09:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:09:45 --> Pagination Class Initialized
INFO - 2019-09-10 16:09:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:45 --> Controller Class Initialized
INFO - 2019-09-10 16:09:45 --> Final output sent to browser
DEBUG - 2019-09-10 16:09:45 --> Total execution time: 0.0640
INFO - 2019-09-10 16:09:50 --> Config Class Initialized
INFO - 2019-09-10 16:09:50 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:09:50 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:09:50 --> Utf8 Class Initialized
INFO - 2019-09-10 16:09:50 --> URI Class Initialized
INFO - 2019-09-10 16:09:50 --> Router Class Initialized
INFO - 2019-09-10 16:09:50 --> Output Class Initialized
INFO - 2019-09-10 16:09:50 --> Security Class Initialized
DEBUG - 2019-09-10 16:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:09:50 --> Input Class Initialized
INFO - 2019-09-10 16:09:50 --> Language Class Initialized
INFO - 2019-09-10 16:09:50 --> Loader Class Initialized
INFO - 2019-09-10 16:09:50 --> Helper loaded: url_helper
INFO - 2019-09-10 16:09:50 --> Helper loaded: html_helper
INFO - 2019-09-10 16:09:50 --> Helper loaded: form_helper
INFO - 2019-09-10 16:09:50 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:09:50 --> Helper loaded: date_helper
INFO - 2019-09-10 16:09:50 --> Form Validation Class Initialized
INFO - 2019-09-10 16:09:50 --> Email Class Initialized
DEBUG - 2019-09-10 16:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:09:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:09:50 --> Pagination Class Initialized
INFO - 2019-09-10 16:09:50 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:50 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:50 --> Controller Class Initialized
INFO - 2019-09-10 16:09:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 16:09:50 --> Config Class Initialized
INFO - 2019-09-10 16:09:50 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:09:50 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:09:50 --> Utf8 Class Initialized
INFO - 2019-09-10 16:09:50 --> URI Class Initialized
INFO - 2019-09-10 16:09:50 --> Router Class Initialized
INFO - 2019-09-10 16:09:50 --> Output Class Initialized
INFO - 2019-09-10 16:09:50 --> Security Class Initialized
DEBUG - 2019-09-10 16:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:09:50 --> Input Class Initialized
INFO - 2019-09-10 16:09:50 --> Language Class Initialized
INFO - 2019-09-10 16:09:50 --> Loader Class Initialized
INFO - 2019-09-10 16:09:50 --> Helper loaded: url_helper
INFO - 2019-09-10 16:09:50 --> Helper loaded: html_helper
INFO - 2019-09-10 16:09:50 --> Helper loaded: form_helper
INFO - 2019-09-10 16:09:50 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:09:50 --> Helper loaded: date_helper
INFO - 2019-09-10 16:09:50 --> Form Validation Class Initialized
INFO - 2019-09-10 16:09:50 --> Email Class Initialized
DEBUG - 2019-09-10 16:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:09:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:09:50 --> Pagination Class Initialized
INFO - 2019-09-10 16:09:50 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:50 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:50 --> Controller Class Initialized
INFO - 2019-09-10 16:09:50 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:09:50 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 16:09:50 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:09:50 --> Final output sent to browser
DEBUG - 2019-09-10 16:09:50 --> Total execution time: 0.0839
INFO - 2019-09-10 16:09:50 --> Config Class Initialized
INFO - 2019-09-10 16:09:50 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:09:50 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:09:50 --> Config Class Initialized
INFO - 2019-09-10 16:09:50 --> Utf8 Class Initialized
INFO - 2019-09-10 16:09:50 --> Hooks Class Initialized
INFO - 2019-09-10 16:09:50 --> URI Class Initialized
INFO - 2019-09-10 16:09:50 --> Router Class Initialized
DEBUG - 2019-09-10 16:09:50 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:09:50 --> Utf8 Class Initialized
INFO - 2019-09-10 16:09:50 --> Output Class Initialized
INFO - 2019-09-10 16:09:50 --> URI Class Initialized
INFO - 2019-09-10 16:09:50 --> Security Class Initialized
INFO - 2019-09-10 16:09:50 --> Router Class Initialized
DEBUG - 2019-09-10 16:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:09:50 --> Input Class Initialized
INFO - 2019-09-10 16:09:50 --> Output Class Initialized
INFO - 2019-09-10 16:09:50 --> Language Class Initialized
INFO - 2019-09-10 16:09:50 --> Security Class Initialized
DEBUG - 2019-09-10 16:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:09:50 --> Input Class Initialized
INFO - 2019-09-10 16:09:50 --> Language Class Initialized
INFO - 2019-09-10 16:09:50 --> Loader Class Initialized
INFO - 2019-09-10 16:09:50 --> Helper loaded: url_helper
INFO - 2019-09-10 16:09:50 --> Helper loaded: html_helper
INFO - 2019-09-10 16:09:50 --> Loader Class Initialized
INFO - 2019-09-10 16:09:50 --> Helper loaded: form_helper
INFO - 2019-09-10 16:09:50 --> Helper loaded: url_helper
INFO - 2019-09-10 16:09:50 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:09:50 --> Helper loaded: html_helper
INFO - 2019-09-10 16:09:50 --> Helper loaded: date_helper
INFO - 2019-09-10 16:09:50 --> Helper loaded: form_helper
INFO - 2019-09-10 16:09:50 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:09:50 --> Form Validation Class Initialized
INFO - 2019-09-10 16:09:50 --> Helper loaded: date_helper
INFO - 2019-09-10 16:09:50 --> Form Validation Class Initialized
INFO - 2019-09-10 16:09:50 --> Email Class Initialized
DEBUG - 2019-09-10 16:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:09:50 --> Email Class Initialized
INFO - 2019-09-10 16:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:09:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:09:50 --> Pagination Class Initialized
DEBUG - 2019-09-10 16:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:09:50 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:50 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:50 --> Controller Class Initialized
INFO - 2019-09-10 16:09:50 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:09:50 --> Final output sent to browser
DEBUG - 2019-09-10 16:09:50 --> Total execution time: 0.0607
INFO - 2019-09-10 16:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:09:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:09:50 --> Pagination Class Initialized
INFO - 2019-09-10 16:09:50 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:50 --> Database Driver Class Initialized
INFO - 2019-09-10 16:09:50 --> Controller Class Initialized
INFO - 2019-09-10 16:09:50 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:09:50 --> Final output sent to browser
DEBUG - 2019-09-10 16:09:50 --> Total execution time: 0.0849
INFO - 2019-09-10 16:11:25 --> Config Class Initialized
INFO - 2019-09-10 16:11:25 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:11:25 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:25 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:25 --> URI Class Initialized
INFO - 2019-09-10 16:11:25 --> Router Class Initialized
INFO - 2019-09-10 16:11:25 --> Output Class Initialized
INFO - 2019-09-10 16:11:25 --> Security Class Initialized
DEBUG - 2019-09-10 16:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:25 --> Input Class Initialized
INFO - 2019-09-10 16:11:25 --> Language Class Initialized
INFO - 2019-09-10 16:11:25 --> Loader Class Initialized
INFO - 2019-09-10 16:11:25 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:25 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:25 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:25 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:25 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:25 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:25 --> Email Class Initialized
DEBUG - 2019-09-10 16:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:25 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:25 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:25 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:25 --> Controller Class Initialized
INFO - 2019-09-10 16:11:25 --> Config Class Initialized
INFO - 2019-09-10 16:11:25 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:11:25 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:25 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:25 --> URI Class Initialized
INFO - 2019-09-10 16:11:25 --> Router Class Initialized
INFO - 2019-09-10 16:11:25 --> Output Class Initialized
INFO - 2019-09-10 16:11:25 --> Security Class Initialized
DEBUG - 2019-09-10 16:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:25 --> Input Class Initialized
INFO - 2019-09-10 16:11:25 --> Language Class Initialized
INFO - 2019-09-10 16:11:25 --> Loader Class Initialized
INFO - 2019-09-10 16:11:25 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:25 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:25 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:25 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:25 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:25 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:25 --> Email Class Initialized
DEBUG - 2019-09-10 16:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:25 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:25 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:25 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:25 --> Controller Class Initialized
INFO - 2019-09-10 16:11:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:11:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 16:11:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:11:25 --> Final output sent to browser
DEBUG - 2019-09-10 16:11:25 --> Total execution time: 0.0766
INFO - 2019-09-10 16:11:25 --> Config Class Initialized
INFO - 2019-09-10 16:11:25 --> Config Class Initialized
INFO - 2019-09-10 16:11:25 --> Hooks Class Initialized
INFO - 2019-09-10 16:11:25 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:11:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-10 16:11:25 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:25 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:25 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:25 --> URI Class Initialized
INFO - 2019-09-10 16:11:25 --> URI Class Initialized
INFO - 2019-09-10 16:11:25 --> Router Class Initialized
INFO - 2019-09-10 16:11:25 --> Router Class Initialized
INFO - 2019-09-10 16:11:25 --> Output Class Initialized
INFO - 2019-09-10 16:11:25 --> Output Class Initialized
INFO - 2019-09-10 16:11:25 --> Security Class Initialized
INFO - 2019-09-10 16:11:25 --> Security Class Initialized
DEBUG - 2019-09-10 16:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:25 --> Input Class Initialized
DEBUG - 2019-09-10 16:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:25 --> Language Class Initialized
INFO - 2019-09-10 16:11:25 --> Input Class Initialized
INFO - 2019-09-10 16:11:25 --> Language Class Initialized
INFO - 2019-09-10 16:11:25 --> Loader Class Initialized
INFO - 2019-09-10 16:11:25 --> Loader Class Initialized
INFO - 2019-09-10 16:11:25 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:25 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:25 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:25 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:25 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:25 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:25 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:25 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:25 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:25 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:25 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:25 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:25 --> Email Class Initialized
INFO - 2019-09-10 16:11:25 --> Email Class Initialized
DEBUG - 2019-09-10 16:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-10 16:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:25 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:25 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:25 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:25 --> Controller Class Initialized
INFO - 2019-09-10 16:11:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:11:25 --> Final output sent to browser
DEBUG - 2019-09-10 16:11:25 --> Total execution time: 0.0627
INFO - 2019-09-10 16:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:25 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:25 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:25 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:25 --> Controller Class Initialized
INFO - 2019-09-10 16:11:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:11:25 --> Final output sent to browser
DEBUG - 2019-09-10 16:11:25 --> Total execution time: 0.0952
INFO - 2019-09-10 16:11:26 --> Config Class Initialized
INFO - 2019-09-10 16:11:26 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:11:26 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:26 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:26 --> URI Class Initialized
INFO - 2019-09-10 16:11:26 --> Router Class Initialized
INFO - 2019-09-10 16:11:26 --> Output Class Initialized
INFO - 2019-09-10 16:11:26 --> Security Class Initialized
DEBUG - 2019-09-10 16:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:26 --> Input Class Initialized
INFO - 2019-09-10 16:11:26 --> Language Class Initialized
INFO - 2019-09-10 16:11:26 --> Loader Class Initialized
INFO - 2019-09-10 16:11:26 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:26 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:26 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:26 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:26 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:26 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:26 --> Email Class Initialized
DEBUG - 2019-09-10 16:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:26 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:26 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:26 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:26 --> Controller Class Initialized
INFO - 2019-09-10 16:11:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:11:26 --> Final output sent to browser
DEBUG - 2019-09-10 16:11:26 --> Total execution time: 0.0505
INFO - 2019-09-10 16:11:30 --> Config Class Initialized
INFO - 2019-09-10 16:11:30 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:11:30 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:30 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:30 --> URI Class Initialized
INFO - 2019-09-10 16:11:30 --> Router Class Initialized
INFO - 2019-09-10 16:11:30 --> Output Class Initialized
INFO - 2019-09-10 16:11:30 --> Security Class Initialized
DEBUG - 2019-09-10 16:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:30 --> Input Class Initialized
INFO - 2019-09-10 16:11:30 --> Language Class Initialized
INFO - 2019-09-10 16:11:30 --> Loader Class Initialized
INFO - 2019-09-10 16:11:30 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:30 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:30 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:30 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:30 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:30 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:30 --> Email Class Initialized
DEBUG - 2019-09-10 16:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:30 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:30 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:30 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:30 --> Controller Class Initialized
INFO - 2019-09-10 16:11:31 --> Config Class Initialized
INFO - 2019-09-10 16:11:31 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:11:31 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:31 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:31 --> URI Class Initialized
INFO - 2019-09-10 16:11:31 --> Router Class Initialized
INFO - 2019-09-10 16:11:31 --> Output Class Initialized
INFO - 2019-09-10 16:11:31 --> Security Class Initialized
DEBUG - 2019-09-10 16:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:31 --> Input Class Initialized
INFO - 2019-09-10 16:11:31 --> Language Class Initialized
INFO - 2019-09-10 16:11:31 --> Loader Class Initialized
INFO - 2019-09-10 16:11:31 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:31 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:31 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:31 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:31 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:31 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:31 --> Email Class Initialized
DEBUG - 2019-09-10 16:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:31 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:31 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:31 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:31 --> Controller Class Initialized
INFO - 2019-09-10 16:11:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:11:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 16:11:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:11:31 --> Final output sent to browser
DEBUG - 2019-09-10 16:11:31 --> Total execution time: 0.0754
INFO - 2019-09-10 16:11:31 --> Config Class Initialized
INFO - 2019-09-10 16:11:31 --> Hooks Class Initialized
INFO - 2019-09-10 16:11:31 --> Config Class Initialized
INFO - 2019-09-10 16:11:31 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:11:31 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:31 --> Utf8 Class Initialized
DEBUG - 2019-09-10 16:11:31 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:31 --> URI Class Initialized
INFO - 2019-09-10 16:11:31 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:31 --> URI Class Initialized
INFO - 2019-09-10 16:11:31 --> Router Class Initialized
INFO - 2019-09-10 16:11:31 --> Router Class Initialized
INFO - 2019-09-10 16:11:31 --> Output Class Initialized
INFO - 2019-09-10 16:11:31 --> Security Class Initialized
INFO - 2019-09-10 16:11:31 --> Output Class Initialized
DEBUG - 2019-09-10 16:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:31 --> Security Class Initialized
INFO - 2019-09-10 16:11:31 --> Input Class Initialized
INFO - 2019-09-10 16:11:31 --> Language Class Initialized
DEBUG - 2019-09-10 16:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:31 --> Input Class Initialized
INFO - 2019-09-10 16:11:31 --> Language Class Initialized
INFO - 2019-09-10 16:11:31 --> Loader Class Initialized
INFO - 2019-09-10 16:11:31 --> Loader Class Initialized
INFO - 2019-09-10 16:11:31 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:31 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:31 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:31 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:31 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:31 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:31 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:31 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:31 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:31 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:31 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:31 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:31 --> Email Class Initialized
INFO - 2019-09-10 16:11:31 --> Email Class Initialized
DEBUG - 2019-09-10 16:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-09-10 16:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:31 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:31 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:31 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:31 --> Controller Class Initialized
INFO - 2019-09-10 16:11:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:11:31 --> Final output sent to browser
DEBUG - 2019-09-10 16:11:31 --> Total execution time: 0.0587
INFO - 2019-09-10 16:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:31 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:31 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:31 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:31 --> Controller Class Initialized
INFO - 2019-09-10 16:11:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:11:31 --> Final output sent to browser
DEBUG - 2019-09-10 16:11:31 --> Total execution time: 0.0867
INFO - 2019-09-10 16:11:39 --> Config Class Initialized
INFO - 2019-09-10 16:11:39 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:11:39 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:39 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:39 --> URI Class Initialized
INFO - 2019-09-10 16:11:39 --> Router Class Initialized
INFO - 2019-09-10 16:11:39 --> Output Class Initialized
INFO - 2019-09-10 16:11:39 --> Security Class Initialized
DEBUG - 2019-09-10 16:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:39 --> Input Class Initialized
INFO - 2019-09-10 16:11:39 --> Language Class Initialized
INFO - 2019-09-10 16:11:39 --> Loader Class Initialized
INFO - 2019-09-10 16:11:39 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:39 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:39 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:39 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:39 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:39 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:39 --> Email Class Initialized
DEBUG - 2019-09-10 16:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:39 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:39 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:39 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:39 --> Controller Class Initialized
INFO - 2019-09-10 16:11:39 --> Config Class Initialized
INFO - 2019-09-10 16:11:39 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:11:39 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:39 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:39 --> URI Class Initialized
INFO - 2019-09-10 16:11:39 --> Router Class Initialized
INFO - 2019-09-10 16:11:39 --> Output Class Initialized
INFO - 2019-09-10 16:11:39 --> Security Class Initialized
DEBUG - 2019-09-10 16:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:39 --> Input Class Initialized
INFO - 2019-09-10 16:11:39 --> Language Class Initialized
INFO - 2019-09-10 16:11:39 --> Loader Class Initialized
INFO - 2019-09-10 16:11:39 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:39 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:39 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:39 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:39 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:39 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:39 --> Email Class Initialized
DEBUG - 2019-09-10 16:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:39 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:39 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:39 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:39 --> Controller Class Initialized
INFO - 2019-09-10 16:11:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:11:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 16:11:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:11:39 --> Final output sent to browser
DEBUG - 2019-09-10 16:11:39 --> Total execution time: 0.0916
INFO - 2019-09-10 16:11:39 --> Config Class Initialized
INFO - 2019-09-10 16:11:39 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:11:39 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:39 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:39 --> URI Class Initialized
INFO - 2019-09-10 16:11:39 --> Router Class Initialized
INFO - 2019-09-10 16:11:39 --> Config Class Initialized
INFO - 2019-09-10 16:11:39 --> Hooks Class Initialized
INFO - 2019-09-10 16:11:39 --> Output Class Initialized
INFO - 2019-09-10 16:11:39 --> Security Class Initialized
DEBUG - 2019-09-10 16:11:39 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:39 --> Utf8 Class Initialized
DEBUG - 2019-09-10 16:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:39 --> Input Class Initialized
INFO - 2019-09-10 16:11:39 --> URI Class Initialized
INFO - 2019-09-10 16:11:39 --> Language Class Initialized
INFO - 2019-09-10 16:11:39 --> Router Class Initialized
INFO - 2019-09-10 16:11:39 --> Output Class Initialized
INFO - 2019-09-10 16:11:39 --> Security Class Initialized
INFO - 2019-09-10 16:11:39 --> Loader Class Initialized
DEBUG - 2019-09-10 16:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:39 --> Input Class Initialized
INFO - 2019-09-10 16:11:39 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:39 --> Language Class Initialized
INFO - 2019-09-10 16:11:39 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:39 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:39 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:39 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:39 --> Loader Class Initialized
INFO - 2019-09-10 16:11:39 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:39 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:39 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:39 --> Email Class Initialized
INFO - 2019-09-10 16:11:39 --> Helper loaded: form_helper
DEBUG - 2019-09-10 16:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:39 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:39 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:39 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:39 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:39 --> Email Class Initialized
DEBUG - 2019-09-10 16:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:39 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:39 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:39 --> Controller Class Initialized
INFO - 2019-09-10 16:11:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:11:39 --> Final output sent to browser
DEBUG - 2019-09-10 16:11:39 --> Total execution time: 0.0830
INFO - 2019-09-10 16:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:39 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:39 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:39 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:39 --> Controller Class Initialized
INFO - 2019-09-10 16:11:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:11:39 --> Final output sent to browser
DEBUG - 2019-09-10 16:11:39 --> Total execution time: 0.1112
INFO - 2019-09-10 16:11:44 --> Config Class Initialized
INFO - 2019-09-10 16:11:44 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:11:44 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:44 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:44 --> URI Class Initialized
INFO - 2019-09-10 16:11:44 --> Router Class Initialized
INFO - 2019-09-10 16:11:45 --> Output Class Initialized
INFO - 2019-09-10 16:11:45 --> Security Class Initialized
DEBUG - 2019-09-10 16:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:45 --> Input Class Initialized
INFO - 2019-09-10 16:11:45 --> Language Class Initialized
INFO - 2019-09-10 16:11:45 --> Loader Class Initialized
INFO - 2019-09-10 16:11:45 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:45 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:45 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:45 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:45 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:45 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:45 --> Email Class Initialized
DEBUG - 2019-09-10 16:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:45 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:45 --> Controller Class Initialized
INFO - 2019-09-10 16:11:45 --> Config Class Initialized
INFO - 2019-09-10 16:11:45 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:11:45 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:45 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:45 --> URI Class Initialized
INFO - 2019-09-10 16:11:45 --> Router Class Initialized
INFO - 2019-09-10 16:11:45 --> Output Class Initialized
INFO - 2019-09-10 16:11:45 --> Security Class Initialized
DEBUG - 2019-09-10 16:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:45 --> Input Class Initialized
INFO - 2019-09-10 16:11:45 --> Language Class Initialized
INFO - 2019-09-10 16:11:45 --> Loader Class Initialized
INFO - 2019-09-10 16:11:45 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:45 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:45 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:45 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:45 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:45 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:45 --> Email Class Initialized
DEBUG - 2019-09-10 16:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:45 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:45 --> Controller Class Initialized
INFO - 2019-09-10 16:11:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:11:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 16:11:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:11:45 --> Final output sent to browser
DEBUG - 2019-09-10 16:11:45 --> Total execution time: 0.0794
INFO - 2019-09-10 16:11:45 --> Config Class Initialized
INFO - 2019-09-10 16:11:45 --> Hooks Class Initialized
INFO - 2019-09-10 16:11:45 --> Config Class Initialized
INFO - 2019-09-10 16:11:45 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:11:45 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:45 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:45 --> URI Class Initialized
DEBUG - 2019-09-10 16:11:45 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:45 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:45 --> URI Class Initialized
INFO - 2019-09-10 16:11:45 --> Router Class Initialized
INFO - 2019-09-10 16:11:45 --> Router Class Initialized
INFO - 2019-09-10 16:11:45 --> Output Class Initialized
INFO - 2019-09-10 16:11:45 --> Security Class Initialized
INFO - 2019-09-10 16:11:45 --> Output Class Initialized
DEBUG - 2019-09-10 16:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:45 --> Security Class Initialized
INFO - 2019-09-10 16:11:45 --> Input Class Initialized
INFO - 2019-09-10 16:11:45 --> Language Class Initialized
DEBUG - 2019-09-10 16:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:45 --> Input Class Initialized
INFO - 2019-09-10 16:11:45 --> Language Class Initialized
INFO - 2019-09-10 16:11:45 --> Loader Class Initialized
INFO - 2019-09-10 16:11:45 --> Loader Class Initialized
INFO - 2019-09-10 16:11:45 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:45 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:45 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:45 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:45 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:45 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:45 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:45 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:45 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:45 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:45 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:45 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:45 --> Email Class Initialized
INFO - 2019-09-10 16:11:45 --> Email Class Initialized
DEBUG - 2019-09-10 16:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-10 16:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:45 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:45 --> Controller Class Initialized
INFO - 2019-09-10 16:11:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:11:45 --> Final output sent to browser
DEBUG - 2019-09-10 16:11:45 --> Total execution time: 0.0670
INFO - 2019-09-10 16:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:45 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:45 --> Controller Class Initialized
INFO - 2019-09-10 16:11:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:11:45 --> Final output sent to browser
DEBUG - 2019-09-10 16:11:45 --> Total execution time: 0.1003
INFO - 2019-09-10 16:11:49 --> Config Class Initialized
INFO - 2019-09-10 16:11:49 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:11:49 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:49 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:49 --> URI Class Initialized
INFO - 2019-09-10 16:11:49 --> Router Class Initialized
INFO - 2019-09-10 16:11:49 --> Output Class Initialized
INFO - 2019-09-10 16:11:49 --> Security Class Initialized
DEBUG - 2019-09-10 16:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:49 --> Input Class Initialized
INFO - 2019-09-10 16:11:49 --> Language Class Initialized
INFO - 2019-09-10 16:11:49 --> Loader Class Initialized
INFO - 2019-09-10 16:11:49 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:49 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:49 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:49 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:49 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:49 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:49 --> Email Class Initialized
DEBUG - 2019-09-10 16:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:49 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:49 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:49 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:49 --> Controller Class Initialized
INFO - 2019-09-10 16:11:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:11:49 --> Final output sent to browser
DEBUG - 2019-09-10 16:11:49 --> Total execution time: 0.0561
INFO - 2019-09-10 16:11:58 --> Config Class Initialized
INFO - 2019-09-10 16:11:58 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:11:58 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:58 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:58 --> URI Class Initialized
INFO - 2019-09-10 16:11:58 --> Router Class Initialized
INFO - 2019-09-10 16:11:58 --> Output Class Initialized
INFO - 2019-09-10 16:11:58 --> Security Class Initialized
DEBUG - 2019-09-10 16:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:58 --> Input Class Initialized
INFO - 2019-09-10 16:11:58 --> Language Class Initialized
INFO - 2019-09-10 16:11:58 --> Loader Class Initialized
INFO - 2019-09-10 16:11:58 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:58 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:58 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:58 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:58 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:58 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:58 --> Email Class Initialized
DEBUG - 2019-09-10 16:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:58 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:58 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:58 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:58 --> Controller Class Initialized
INFO - 2019-09-10 16:11:58 --> Config Class Initialized
INFO - 2019-09-10 16:11:58 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:11:58 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:58 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:58 --> URI Class Initialized
INFO - 2019-09-10 16:11:58 --> Router Class Initialized
INFO - 2019-09-10 16:11:58 --> Output Class Initialized
INFO - 2019-09-10 16:11:58 --> Security Class Initialized
DEBUG - 2019-09-10 16:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:58 --> Input Class Initialized
INFO - 2019-09-10 16:11:58 --> Language Class Initialized
INFO - 2019-09-10 16:11:58 --> Loader Class Initialized
INFO - 2019-09-10 16:11:58 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:58 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:58 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:58 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:58 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:58 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:58 --> Email Class Initialized
DEBUG - 2019-09-10 16:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:58 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:58 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:58 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:58 --> Controller Class Initialized
INFO - 2019-09-10 16:11:58 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:11:58 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 16:11:58 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:11:58 --> Final output sent to browser
DEBUG - 2019-09-10 16:11:58 --> Total execution time: 0.0936
INFO - 2019-09-10 16:11:58 --> Config Class Initialized
INFO - 2019-09-10 16:11:58 --> Hooks Class Initialized
INFO - 2019-09-10 16:11:58 --> Config Class Initialized
INFO - 2019-09-10 16:11:58 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:11:58 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:58 --> Utf8 Class Initialized
DEBUG - 2019-09-10 16:11:58 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:11:58 --> URI Class Initialized
INFO - 2019-09-10 16:11:58 --> Utf8 Class Initialized
INFO - 2019-09-10 16:11:58 --> URI Class Initialized
INFO - 2019-09-10 16:11:58 --> Router Class Initialized
INFO - 2019-09-10 16:11:58 --> Router Class Initialized
INFO - 2019-09-10 16:11:58 --> Output Class Initialized
INFO - 2019-09-10 16:11:58 --> Security Class Initialized
INFO - 2019-09-10 16:11:58 --> Output Class Initialized
DEBUG - 2019-09-10 16:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:58 --> Security Class Initialized
INFO - 2019-09-10 16:11:58 --> Input Class Initialized
INFO - 2019-09-10 16:11:58 --> Language Class Initialized
DEBUG - 2019-09-10 16:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:11:58 --> Input Class Initialized
INFO - 2019-09-10 16:11:58 --> Language Class Initialized
INFO - 2019-09-10 16:11:58 --> Loader Class Initialized
INFO - 2019-09-10 16:11:58 --> Loader Class Initialized
INFO - 2019-09-10 16:11:58 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:58 --> Helper loaded: url_helper
INFO - 2019-09-10 16:11:58 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:58 --> Helper loaded: html_helper
INFO - 2019-09-10 16:11:58 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:58 --> Helper loaded: form_helper
INFO - 2019-09-10 16:11:58 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:58 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:11:58 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:58 --> Helper loaded: date_helper
INFO - 2019-09-10 16:11:58 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:58 --> Form Validation Class Initialized
INFO - 2019-09-10 16:11:58 --> Email Class Initialized
INFO - 2019-09-10 16:11:58 --> Email Class Initialized
DEBUG - 2019-09-10 16:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-10 16:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:58 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:58 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:58 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:58 --> Controller Class Initialized
INFO - 2019-09-10 16:11:58 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:11:58 --> Final output sent to browser
DEBUG - 2019-09-10 16:11:58 --> Total execution time: 0.0621
INFO - 2019-09-10 16:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:11:58 --> Pagination Class Initialized
INFO - 2019-09-10 16:11:58 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:58 --> Database Driver Class Initialized
INFO - 2019-09-10 16:11:58 --> Controller Class Initialized
INFO - 2019-09-10 16:11:58 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:11:58 --> Final output sent to browser
DEBUG - 2019-09-10 16:11:58 --> Total execution time: 0.0884
INFO - 2019-09-10 16:12:04 --> Config Class Initialized
INFO - 2019-09-10 16:12:04 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:12:04 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:12:04 --> Utf8 Class Initialized
INFO - 2019-09-10 16:12:04 --> URI Class Initialized
INFO - 2019-09-10 16:12:04 --> Router Class Initialized
INFO - 2019-09-10 16:12:04 --> Output Class Initialized
INFO - 2019-09-10 16:12:04 --> Security Class Initialized
DEBUG - 2019-09-10 16:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:12:04 --> Input Class Initialized
INFO - 2019-09-10 16:12:04 --> Language Class Initialized
INFO - 2019-09-10 16:12:04 --> Loader Class Initialized
INFO - 2019-09-10 16:12:04 --> Helper loaded: url_helper
INFO - 2019-09-10 16:12:04 --> Helper loaded: html_helper
INFO - 2019-09-10 16:12:04 --> Helper loaded: form_helper
INFO - 2019-09-10 16:12:04 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:12:04 --> Helper loaded: date_helper
INFO - 2019-09-10 16:12:04 --> Form Validation Class Initialized
INFO - 2019-09-10 16:12:04 --> Email Class Initialized
DEBUG - 2019-09-10 16:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:12:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:12:04 --> Pagination Class Initialized
INFO - 2019-09-10 16:12:04 --> Database Driver Class Initialized
INFO - 2019-09-10 16:12:04 --> Database Driver Class Initialized
INFO - 2019-09-10 16:12:04 --> Controller Class Initialized
INFO - 2019-09-10 16:12:04 --> Final output sent to browser
DEBUG - 2019-09-10 16:12:04 --> Total execution time: 0.0539
INFO - 2019-09-10 16:12:09 --> Config Class Initialized
INFO - 2019-09-10 16:12:09 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:12:09 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:12:09 --> Utf8 Class Initialized
INFO - 2019-09-10 16:12:09 --> URI Class Initialized
INFO - 2019-09-10 16:12:09 --> Router Class Initialized
INFO - 2019-09-10 16:12:09 --> Output Class Initialized
INFO - 2019-09-10 16:12:09 --> Security Class Initialized
DEBUG - 2019-09-10 16:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:12:09 --> Input Class Initialized
INFO - 2019-09-10 16:12:09 --> Language Class Initialized
INFO - 2019-09-10 16:12:09 --> Loader Class Initialized
INFO - 2019-09-10 16:12:09 --> Helper loaded: url_helper
INFO - 2019-09-10 16:12:09 --> Helper loaded: html_helper
INFO - 2019-09-10 16:12:09 --> Helper loaded: form_helper
INFO - 2019-09-10 16:12:09 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:12:09 --> Helper loaded: date_helper
INFO - 2019-09-10 16:12:09 --> Form Validation Class Initialized
INFO - 2019-09-10 16:12:09 --> Email Class Initialized
DEBUG - 2019-09-10 16:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:12:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:12:09 --> Pagination Class Initialized
INFO - 2019-09-10 16:12:09 --> Database Driver Class Initialized
INFO - 2019-09-10 16:12:09 --> Database Driver Class Initialized
INFO - 2019-09-10 16:12:09 --> Controller Class Initialized
INFO - 2019-09-10 16:12:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 16:16:44 --> Config Class Initialized
INFO - 2019-09-10 16:16:44 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:16:44 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:16:44 --> Utf8 Class Initialized
INFO - 2019-09-10 16:16:44 --> URI Class Initialized
INFO - 2019-09-10 16:16:44 --> Router Class Initialized
INFO - 2019-09-10 16:16:44 --> Output Class Initialized
INFO - 2019-09-10 16:16:44 --> Security Class Initialized
DEBUG - 2019-09-10 16:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:16:44 --> Input Class Initialized
INFO - 2019-09-10 16:16:44 --> Language Class Initialized
INFO - 2019-09-10 16:16:44 --> Loader Class Initialized
INFO - 2019-09-10 16:16:44 --> Helper loaded: url_helper
INFO - 2019-09-10 16:16:44 --> Helper loaded: html_helper
INFO - 2019-09-10 16:16:44 --> Helper loaded: form_helper
INFO - 2019-09-10 16:16:44 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:16:44 --> Helper loaded: date_helper
INFO - 2019-09-10 16:16:44 --> Form Validation Class Initialized
INFO - 2019-09-10 16:16:44 --> Email Class Initialized
DEBUG - 2019-09-10 16:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:16:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:16:44 --> Pagination Class Initialized
INFO - 2019-09-10 16:16:44 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:44 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:44 --> Controller Class Initialized
INFO - 2019-09-10 16:16:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:16:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 16:16:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:16:44 --> Final output sent to browser
DEBUG - 2019-09-10 16:16:44 --> Total execution time: 0.1050
INFO - 2019-09-10 16:16:44 --> Config Class Initialized
INFO - 2019-09-10 16:16:44 --> Hooks Class Initialized
INFO - 2019-09-10 16:16:44 --> Config Class Initialized
DEBUG - 2019-09-10 16:16:44 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:16:44 --> Hooks Class Initialized
INFO - 2019-09-10 16:16:44 --> Utf8 Class Initialized
INFO - 2019-09-10 16:16:44 --> URI Class Initialized
DEBUG - 2019-09-10 16:16:44 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:16:44 --> Utf8 Class Initialized
INFO - 2019-09-10 16:16:44 --> Router Class Initialized
INFO - 2019-09-10 16:16:44 --> URI Class Initialized
INFO - 2019-09-10 16:16:44 --> Output Class Initialized
INFO - 2019-09-10 16:16:44 --> Router Class Initialized
INFO - 2019-09-10 16:16:44 --> Security Class Initialized
INFO - 2019-09-10 16:16:44 --> Output Class Initialized
INFO - 2019-09-10 16:16:44 --> Security Class Initialized
DEBUG - 2019-09-10 16:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:16:44 --> Input Class Initialized
INFO - 2019-09-10 16:16:44 --> Language Class Initialized
DEBUG - 2019-09-10 16:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:16:44 --> Input Class Initialized
INFO - 2019-09-10 16:16:44 --> Language Class Initialized
INFO - 2019-09-10 16:16:44 --> Loader Class Initialized
INFO - 2019-09-10 16:16:44 --> Loader Class Initialized
INFO - 2019-09-10 16:16:44 --> Helper loaded: url_helper
INFO - 2019-09-10 16:16:44 --> Helper loaded: html_helper
INFO - 2019-09-10 16:16:44 --> Helper loaded: url_helper
INFO - 2019-09-10 16:16:44 --> Helper loaded: html_helper
INFO - 2019-09-10 16:16:44 --> Helper loaded: form_helper
INFO - 2019-09-10 16:16:44 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:16:44 --> Helper loaded: form_helper
INFO - 2019-09-10 16:16:44 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:16:44 --> Helper loaded: date_helper
INFO - 2019-09-10 16:16:44 --> Helper loaded: date_helper
INFO - 2019-09-10 16:16:44 --> Form Validation Class Initialized
INFO - 2019-09-10 16:16:44 --> Form Validation Class Initialized
INFO - 2019-09-10 16:16:44 --> Email Class Initialized
INFO - 2019-09-10 16:16:44 --> Email Class Initialized
DEBUG - 2019-09-10 16:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-10 16:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:16:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:16:44 --> Pagination Class Initialized
INFO - 2019-09-10 16:16:44 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:44 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:44 --> Controller Class Initialized
INFO - 2019-09-10 16:16:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:16:44 --> Final output sent to browser
DEBUG - 2019-09-10 16:16:44 --> Total execution time: 0.0788
INFO - 2019-09-10 16:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:16:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:16:44 --> Pagination Class Initialized
INFO - 2019-09-10 16:16:44 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:44 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:44 --> Controller Class Initialized
INFO - 2019-09-10 16:16:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:16:44 --> Final output sent to browser
DEBUG - 2019-09-10 16:16:44 --> Total execution time: 0.1093
INFO - 2019-09-10 16:16:44 --> Config Class Initialized
INFO - 2019-09-10 16:16:44 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:16:44 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:16:44 --> Utf8 Class Initialized
INFO - 2019-09-10 16:16:44 --> URI Class Initialized
INFO - 2019-09-10 16:16:44 --> Router Class Initialized
INFO - 2019-09-10 16:16:44 --> Output Class Initialized
INFO - 2019-09-10 16:16:44 --> Security Class Initialized
DEBUG - 2019-09-10 16:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:16:44 --> Input Class Initialized
INFO - 2019-09-10 16:16:44 --> Language Class Initialized
INFO - 2019-09-10 16:16:44 --> Loader Class Initialized
INFO - 2019-09-10 16:16:44 --> Helper loaded: url_helper
INFO - 2019-09-10 16:16:44 --> Helper loaded: html_helper
INFO - 2019-09-10 16:16:44 --> Helper loaded: form_helper
INFO - 2019-09-10 16:16:44 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:16:44 --> Helper loaded: date_helper
INFO - 2019-09-10 16:16:44 --> Form Validation Class Initialized
INFO - 2019-09-10 16:16:44 --> Email Class Initialized
DEBUG - 2019-09-10 16:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:16:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:16:44 --> Pagination Class Initialized
INFO - 2019-09-10 16:16:44 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:44 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:44 --> Controller Class Initialized
INFO - 2019-09-10 16:16:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:16:44 --> Final output sent to browser
DEBUG - 2019-09-10 16:16:44 --> Total execution time: 0.0736
INFO - 2019-09-10 16:16:46 --> Config Class Initialized
INFO - 2019-09-10 16:16:46 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:16:46 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:16:46 --> Utf8 Class Initialized
INFO - 2019-09-10 16:16:46 --> URI Class Initialized
INFO - 2019-09-10 16:16:46 --> Router Class Initialized
INFO - 2019-09-10 16:16:46 --> Output Class Initialized
INFO - 2019-09-10 16:16:46 --> Security Class Initialized
DEBUG - 2019-09-10 16:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:16:46 --> Input Class Initialized
INFO - 2019-09-10 16:16:46 --> Language Class Initialized
INFO - 2019-09-10 16:16:46 --> Loader Class Initialized
INFO - 2019-09-10 16:16:46 --> Helper loaded: url_helper
INFO - 2019-09-10 16:16:46 --> Helper loaded: html_helper
INFO - 2019-09-10 16:16:46 --> Helper loaded: form_helper
INFO - 2019-09-10 16:16:46 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:16:46 --> Helper loaded: date_helper
INFO - 2019-09-10 16:16:46 --> Form Validation Class Initialized
INFO - 2019-09-10 16:16:46 --> Email Class Initialized
DEBUG - 2019-09-10 16:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:16:46 --> Pagination Class Initialized
INFO - 2019-09-10 16:16:46 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:46 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:46 --> Controller Class Initialized
INFO - 2019-09-10 16:16:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:16:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 16:16:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:16:46 --> Final output sent to browser
DEBUG - 2019-09-10 16:16:46 --> Total execution time: 0.0749
INFO - 2019-09-10 16:16:46 --> Config Class Initialized
INFO - 2019-09-10 16:16:46 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:16:46 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:16:46 --> Utf8 Class Initialized
INFO - 2019-09-10 16:16:46 --> URI Class Initialized
INFO - 2019-09-10 16:16:46 --> Config Class Initialized
INFO - 2019-09-10 16:16:46 --> Hooks Class Initialized
INFO - 2019-09-10 16:16:46 --> Router Class Initialized
DEBUG - 2019-09-10 16:16:46 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:16:46 --> Utf8 Class Initialized
INFO - 2019-09-10 16:16:46 --> Output Class Initialized
INFO - 2019-09-10 16:16:46 --> URI Class Initialized
INFO - 2019-09-10 16:16:46 --> Security Class Initialized
DEBUG - 2019-09-10 16:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:16:46 --> Router Class Initialized
INFO - 2019-09-10 16:16:46 --> Input Class Initialized
INFO - 2019-09-10 16:16:46 --> Language Class Initialized
INFO - 2019-09-10 16:16:46 --> Output Class Initialized
INFO - 2019-09-10 16:16:46 --> Security Class Initialized
DEBUG - 2019-09-10 16:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:16:46 --> Input Class Initialized
INFO - 2019-09-10 16:16:46 --> Language Class Initialized
INFO - 2019-09-10 16:16:46 --> Loader Class Initialized
INFO - 2019-09-10 16:16:46 --> Helper loaded: url_helper
INFO - 2019-09-10 16:16:46 --> Helper loaded: html_helper
INFO - 2019-09-10 16:16:46 --> Loader Class Initialized
INFO - 2019-09-10 16:16:46 --> Helper loaded: form_helper
INFO - 2019-09-10 16:16:46 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:16:46 --> Helper loaded: url_helper
INFO - 2019-09-10 16:16:46 --> Helper loaded: html_helper
INFO - 2019-09-10 16:16:46 --> Helper loaded: date_helper
INFO - 2019-09-10 16:16:46 --> Helper loaded: form_helper
INFO - 2019-09-10 16:16:46 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:16:46 --> Form Validation Class Initialized
INFO - 2019-09-10 16:16:46 --> Helper loaded: date_helper
INFO - 2019-09-10 16:16:46 --> Email Class Initialized
INFO - 2019-09-10 16:16:46 --> Form Validation Class Initialized
DEBUG - 2019-09-10 16:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:16:46 --> Email Class Initialized
INFO - 2019-09-10 16:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:16:46 --> Pagination Class Initialized
DEBUG - 2019-09-10 16:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:16:46 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:46 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:46 --> Controller Class Initialized
INFO - 2019-09-10 16:16:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:16:46 --> Final output sent to browser
DEBUG - 2019-09-10 16:16:46 --> Total execution time: 0.0716
INFO - 2019-09-10 16:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:16:46 --> Pagination Class Initialized
INFO - 2019-09-10 16:16:46 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:46 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:46 --> Controller Class Initialized
INFO - 2019-09-10 16:16:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:16:46 --> Final output sent to browser
DEBUG - 2019-09-10 16:16:46 --> Total execution time: 0.0985
INFO - 2019-09-10 16:16:52 --> Config Class Initialized
INFO - 2019-09-10 16:16:52 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:16:52 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:16:52 --> Utf8 Class Initialized
INFO - 2019-09-10 16:16:52 --> URI Class Initialized
INFO - 2019-09-10 16:16:52 --> Router Class Initialized
INFO - 2019-09-10 16:16:52 --> Output Class Initialized
INFO - 2019-09-10 16:16:52 --> Security Class Initialized
DEBUG - 2019-09-10 16:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:16:52 --> Input Class Initialized
INFO - 2019-09-10 16:16:52 --> Language Class Initialized
INFO - 2019-09-10 16:16:52 --> Loader Class Initialized
INFO - 2019-09-10 16:16:52 --> Helper loaded: url_helper
INFO - 2019-09-10 16:16:52 --> Helper loaded: html_helper
INFO - 2019-09-10 16:16:52 --> Helper loaded: form_helper
INFO - 2019-09-10 16:16:52 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:16:52 --> Helper loaded: date_helper
INFO - 2019-09-10 16:16:52 --> Form Validation Class Initialized
INFO - 2019-09-10 16:16:52 --> Email Class Initialized
DEBUG - 2019-09-10 16:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:16:52 --> Pagination Class Initialized
INFO - 2019-09-10 16:16:52 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:52 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:52 --> Controller Class Initialized
INFO - 2019-09-10 16:16:52 --> Config Class Initialized
INFO - 2019-09-10 16:16:52 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:16:52 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:16:52 --> Utf8 Class Initialized
INFO - 2019-09-10 16:16:52 --> URI Class Initialized
INFO - 2019-09-10 16:16:52 --> Router Class Initialized
INFO - 2019-09-10 16:16:52 --> Output Class Initialized
INFO - 2019-09-10 16:16:52 --> Security Class Initialized
DEBUG - 2019-09-10 16:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:16:52 --> Input Class Initialized
INFO - 2019-09-10 16:16:52 --> Language Class Initialized
INFO - 2019-09-10 16:16:52 --> Loader Class Initialized
INFO - 2019-09-10 16:16:52 --> Helper loaded: url_helper
INFO - 2019-09-10 16:16:52 --> Helper loaded: html_helper
INFO - 2019-09-10 16:16:52 --> Helper loaded: form_helper
INFO - 2019-09-10 16:16:52 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:16:52 --> Helper loaded: date_helper
INFO - 2019-09-10 16:16:52 --> Form Validation Class Initialized
INFO - 2019-09-10 16:16:52 --> Email Class Initialized
DEBUG - 2019-09-10 16:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:16:52 --> Pagination Class Initialized
INFO - 2019-09-10 16:16:52 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:52 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:52 --> Controller Class Initialized
INFO - 2019-09-10 16:16:52 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:16:52 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 16:16:52 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:16:52 --> Final output sent to browser
DEBUG - 2019-09-10 16:16:52 --> Total execution time: 0.0715
INFO - 2019-09-10 16:16:52 --> Config Class Initialized
INFO - 2019-09-10 16:16:52 --> Hooks Class Initialized
INFO - 2019-09-10 16:16:52 --> Config Class Initialized
INFO - 2019-09-10 16:16:52 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:16:52 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:16:52 --> Utf8 Class Initialized
INFO - 2019-09-10 16:16:52 --> URI Class Initialized
DEBUG - 2019-09-10 16:16:52 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:16:52 --> Utf8 Class Initialized
INFO - 2019-09-10 16:16:52 --> URI Class Initialized
INFO - 2019-09-10 16:16:52 --> Router Class Initialized
INFO - 2019-09-10 16:16:52 --> Output Class Initialized
INFO - 2019-09-10 16:16:52 --> Router Class Initialized
INFO - 2019-09-10 16:16:52 --> Security Class Initialized
INFO - 2019-09-10 16:16:52 --> Output Class Initialized
INFO - 2019-09-10 16:16:52 --> Security Class Initialized
DEBUG - 2019-09-10 16:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:16:52 --> Input Class Initialized
DEBUG - 2019-09-10 16:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:16:52 --> Language Class Initialized
INFO - 2019-09-10 16:16:52 --> Input Class Initialized
INFO - 2019-09-10 16:16:52 --> Language Class Initialized
INFO - 2019-09-10 16:16:52 --> Loader Class Initialized
INFO - 2019-09-10 16:16:52 --> Loader Class Initialized
INFO - 2019-09-10 16:16:52 --> Helper loaded: url_helper
INFO - 2019-09-10 16:16:52 --> Helper loaded: url_helper
INFO - 2019-09-10 16:16:52 --> Helper loaded: html_helper
INFO - 2019-09-10 16:16:52 --> Helper loaded: html_helper
INFO - 2019-09-10 16:16:52 --> Helper loaded: form_helper
INFO - 2019-09-10 16:16:52 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:16:52 --> Helper loaded: form_helper
INFO - 2019-09-10 16:16:52 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:16:52 --> Helper loaded: date_helper
INFO - 2019-09-10 16:16:52 --> Helper loaded: date_helper
INFO - 2019-09-10 16:16:52 --> Form Validation Class Initialized
INFO - 2019-09-10 16:16:52 --> Form Validation Class Initialized
INFO - 2019-09-10 16:16:52 --> Email Class Initialized
INFO - 2019-09-10 16:16:52 --> Email Class Initialized
DEBUG - 2019-09-10 16:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-10 16:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:16:52 --> Pagination Class Initialized
INFO - 2019-09-10 16:16:52 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:52 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:52 --> Controller Class Initialized
INFO - 2019-09-10 16:16:52 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:16:52 --> Final output sent to browser
DEBUG - 2019-09-10 16:16:52 --> Total execution time: 0.0636
INFO - 2019-09-10 16:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:16:52 --> Pagination Class Initialized
INFO - 2019-09-10 16:16:52 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:52 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:52 --> Controller Class Initialized
INFO - 2019-09-10 16:16:52 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:16:52 --> Final output sent to browser
DEBUG - 2019-09-10 16:16:52 --> Total execution time: 0.0921
INFO - 2019-09-10 16:16:56 --> Config Class Initialized
INFO - 2019-09-10 16:16:56 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:16:56 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:16:56 --> Utf8 Class Initialized
INFO - 2019-09-10 16:16:56 --> URI Class Initialized
INFO - 2019-09-10 16:16:56 --> Router Class Initialized
INFO - 2019-09-10 16:16:56 --> Output Class Initialized
INFO - 2019-09-10 16:16:56 --> Security Class Initialized
DEBUG - 2019-09-10 16:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:16:56 --> Input Class Initialized
INFO - 2019-09-10 16:16:56 --> Language Class Initialized
INFO - 2019-09-10 16:16:56 --> Loader Class Initialized
INFO - 2019-09-10 16:16:56 --> Helper loaded: url_helper
INFO - 2019-09-10 16:16:56 --> Helper loaded: html_helper
INFO - 2019-09-10 16:16:56 --> Helper loaded: form_helper
INFO - 2019-09-10 16:16:56 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:16:56 --> Helper loaded: date_helper
INFO - 2019-09-10 16:16:56 --> Form Validation Class Initialized
INFO - 2019-09-10 16:16:56 --> Email Class Initialized
DEBUG - 2019-09-10 16:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:16:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:16:56 --> Pagination Class Initialized
INFO - 2019-09-10 16:16:56 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:56 --> Database Driver Class Initialized
INFO - 2019-09-10 16:16:56 --> Controller Class Initialized
INFO - 2019-09-10 16:16:56 --> Final output sent to browser
DEBUG - 2019-09-10 16:16:56 --> Total execution time: 0.0514
INFO - 2019-09-10 16:17:03 --> Config Class Initialized
INFO - 2019-09-10 16:17:03 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:17:03 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:17:03 --> Utf8 Class Initialized
INFO - 2019-09-10 16:17:03 --> URI Class Initialized
INFO - 2019-09-10 16:17:03 --> Router Class Initialized
INFO - 2019-09-10 16:17:03 --> Output Class Initialized
INFO - 2019-09-10 16:17:03 --> Security Class Initialized
DEBUG - 2019-09-10 16:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:17:03 --> Input Class Initialized
INFO - 2019-09-10 16:17:03 --> Language Class Initialized
INFO - 2019-09-10 16:17:03 --> Loader Class Initialized
INFO - 2019-09-10 16:17:03 --> Helper loaded: url_helper
INFO - 2019-09-10 16:17:03 --> Helper loaded: html_helper
INFO - 2019-09-10 16:17:03 --> Helper loaded: form_helper
INFO - 2019-09-10 16:17:03 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:17:03 --> Helper loaded: date_helper
INFO - 2019-09-10 16:17:03 --> Form Validation Class Initialized
INFO - 2019-09-10 16:17:03 --> Email Class Initialized
DEBUG - 2019-09-10 16:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:17:03 --> Pagination Class Initialized
INFO - 2019-09-10 16:17:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:17:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:17:03 --> Controller Class Initialized
INFO - 2019-09-10 16:17:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 16:17:55 --> Config Class Initialized
INFO - 2019-09-10 16:17:55 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:17:55 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:17:55 --> Utf8 Class Initialized
INFO - 2019-09-10 16:17:55 --> URI Class Initialized
INFO - 2019-09-10 16:17:55 --> Router Class Initialized
INFO - 2019-09-10 16:17:55 --> Output Class Initialized
INFO - 2019-09-10 16:17:55 --> Security Class Initialized
DEBUG - 2019-09-10 16:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:17:55 --> Input Class Initialized
INFO - 2019-09-10 16:17:55 --> Language Class Initialized
INFO - 2019-09-10 16:17:55 --> Loader Class Initialized
INFO - 2019-09-10 16:17:55 --> Helper loaded: url_helper
INFO - 2019-09-10 16:17:55 --> Helper loaded: html_helper
INFO - 2019-09-10 16:17:55 --> Helper loaded: form_helper
INFO - 2019-09-10 16:17:55 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:17:55 --> Helper loaded: date_helper
INFO - 2019-09-10 16:17:55 --> Form Validation Class Initialized
INFO - 2019-09-10 16:17:55 --> Email Class Initialized
DEBUG - 2019-09-10 16:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:17:55 --> Pagination Class Initialized
INFO - 2019-09-10 16:17:55 --> Database Driver Class Initialized
INFO - 2019-09-10 16:17:55 --> Database Driver Class Initialized
INFO - 2019-09-10 16:17:55 --> Controller Class Initialized
INFO - 2019-09-10 16:17:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 16:26:47 --> Config Class Initialized
INFO - 2019-09-10 16:26:47 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:26:47 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:26:47 --> Utf8 Class Initialized
INFO - 2019-09-10 16:26:47 --> URI Class Initialized
INFO - 2019-09-10 16:26:47 --> Router Class Initialized
INFO - 2019-09-10 16:26:47 --> Output Class Initialized
INFO - 2019-09-10 16:26:47 --> Security Class Initialized
DEBUG - 2019-09-10 16:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:26:47 --> Input Class Initialized
INFO - 2019-09-10 16:26:47 --> Language Class Initialized
INFO - 2019-09-10 16:26:47 --> Loader Class Initialized
INFO - 2019-09-10 16:26:47 --> Helper loaded: url_helper
INFO - 2019-09-10 16:26:47 --> Helper loaded: html_helper
INFO - 2019-09-10 16:26:47 --> Helper loaded: form_helper
INFO - 2019-09-10 16:26:47 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:26:47 --> Helper loaded: date_helper
INFO - 2019-09-10 16:26:47 --> Form Validation Class Initialized
INFO - 2019-09-10 16:26:47 --> Email Class Initialized
DEBUG - 2019-09-10 16:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:26:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:26:47 --> Pagination Class Initialized
INFO - 2019-09-10 16:26:47 --> Database Driver Class Initialized
INFO - 2019-09-10 16:26:47 --> Database Driver Class Initialized
INFO - 2019-09-10 16:26:47 --> Controller Class Initialized
INFO - 2019-09-10 16:26:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:26:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 16:26:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:26:47 --> Final output sent to browser
DEBUG - 2019-09-10 16:26:47 --> Total execution time: 0.0984
INFO - 2019-09-10 16:26:47 --> Config Class Initialized
INFO - 2019-09-10 16:26:47 --> Hooks Class Initialized
INFO - 2019-09-10 16:26:47 --> Config Class Initialized
INFO - 2019-09-10 16:26:47 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:26:47 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:26:47 --> Utf8 Class Initialized
INFO - 2019-09-10 16:26:47 --> URI Class Initialized
DEBUG - 2019-09-10 16:26:47 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:26:47 --> Utf8 Class Initialized
INFO - 2019-09-10 16:26:47 --> Router Class Initialized
INFO - 2019-09-10 16:26:47 --> URI Class Initialized
INFO - 2019-09-10 16:26:47 --> Output Class Initialized
INFO - 2019-09-10 16:26:47 --> Router Class Initialized
INFO - 2019-09-10 16:26:47 --> Security Class Initialized
INFO - 2019-09-10 16:26:47 --> Output Class Initialized
DEBUG - 2019-09-10 16:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:26:47 --> Input Class Initialized
INFO - 2019-09-10 16:26:47 --> Security Class Initialized
INFO - 2019-09-10 16:26:47 --> Language Class Initialized
DEBUG - 2019-09-10 16:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:26:47 --> Input Class Initialized
INFO - 2019-09-10 16:26:47 --> Language Class Initialized
INFO - 2019-09-10 16:26:47 --> Loader Class Initialized
INFO - 2019-09-10 16:26:47 --> Helper loaded: url_helper
INFO - 2019-09-10 16:26:47 --> Loader Class Initialized
INFO - 2019-09-10 16:26:47 --> Helper loaded: html_helper
INFO - 2019-09-10 16:26:47 --> Helper loaded: url_helper
INFO - 2019-09-10 16:26:47 --> Helper loaded: form_helper
INFO - 2019-09-10 16:26:47 --> Helper loaded: html_helper
INFO - 2019-09-10 16:26:47 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:26:47 --> Helper loaded: form_helper
INFO - 2019-09-10 16:26:47 --> Helper loaded: date_helper
INFO - 2019-09-10 16:26:47 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:26:47 --> Form Validation Class Initialized
INFO - 2019-09-10 16:26:47 --> Helper loaded: date_helper
INFO - 2019-09-10 16:26:47 --> Form Validation Class Initialized
INFO - 2019-09-10 16:26:47 --> Email Class Initialized
INFO - 2019-09-10 16:26:47 --> Email Class Initialized
DEBUG - 2019-09-10 16:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:26:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-09-10 16:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:26:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:26:47 --> Pagination Class Initialized
INFO - 2019-09-10 16:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:26:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:26:47 --> Pagination Class Initialized
INFO - 2019-09-10 16:26:47 --> Database Driver Class Initialized
INFO - 2019-09-10 16:26:47 --> Database Driver Class Initialized
INFO - 2019-09-10 16:26:47 --> Database Driver Class Initialized
INFO - 2019-09-10 16:26:47 --> Controller Class Initialized
INFO - 2019-09-10 16:26:47 --> Database Driver Class Initialized
INFO - 2019-09-10 16:26:47 --> Controller Class Initialized
INFO - 2019-09-10 16:26:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:26:47 --> Final output sent to browser
DEBUG - 2019-09-10 16:26:47 --> Total execution time: 0.0776
INFO - 2019-09-10 16:26:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:26:47 --> Final output sent to browser
DEBUG - 2019-09-10 16:26:47 --> Total execution time: 0.0938
INFO - 2019-09-10 16:26:49 --> Config Class Initialized
INFO - 2019-09-10 16:26:49 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:26:49 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:26:49 --> Utf8 Class Initialized
INFO - 2019-09-10 16:26:49 --> URI Class Initialized
INFO - 2019-09-10 16:26:49 --> Router Class Initialized
INFO - 2019-09-10 16:26:49 --> Output Class Initialized
INFO - 2019-09-10 16:26:49 --> Security Class Initialized
DEBUG - 2019-09-10 16:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:26:49 --> Input Class Initialized
INFO - 2019-09-10 16:26:49 --> Language Class Initialized
INFO - 2019-09-10 16:26:49 --> Loader Class Initialized
INFO - 2019-09-10 16:26:49 --> Helper loaded: url_helper
INFO - 2019-09-10 16:26:49 --> Helper loaded: html_helper
INFO - 2019-09-10 16:26:49 --> Helper loaded: form_helper
INFO - 2019-09-10 16:26:49 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:26:49 --> Helper loaded: date_helper
INFO - 2019-09-10 16:26:49 --> Form Validation Class Initialized
INFO - 2019-09-10 16:26:49 --> Email Class Initialized
DEBUG - 2019-09-10 16:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:26:49 --> Pagination Class Initialized
INFO - 2019-09-10 16:26:49 --> Database Driver Class Initialized
INFO - 2019-09-10 16:26:49 --> Database Driver Class Initialized
INFO - 2019-09-10 16:26:49 --> Controller Class Initialized
INFO - 2019-09-10 16:26:49 --> Config Class Initialized
INFO - 2019-09-10 16:26:49 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:26:49 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:26:49 --> Utf8 Class Initialized
INFO - 2019-09-10 16:26:49 --> URI Class Initialized
INFO - 2019-09-10 16:26:49 --> Router Class Initialized
INFO - 2019-09-10 16:26:49 --> Output Class Initialized
INFO - 2019-09-10 16:26:49 --> Security Class Initialized
DEBUG - 2019-09-10 16:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:26:49 --> Input Class Initialized
INFO - 2019-09-10 16:26:49 --> Language Class Initialized
INFO - 2019-09-10 16:26:49 --> Loader Class Initialized
INFO - 2019-09-10 16:26:49 --> Helper loaded: url_helper
INFO - 2019-09-10 16:26:49 --> Helper loaded: html_helper
INFO - 2019-09-10 16:26:49 --> Helper loaded: form_helper
INFO - 2019-09-10 16:26:49 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:26:49 --> Helper loaded: date_helper
INFO - 2019-09-10 16:26:49 --> Form Validation Class Initialized
INFO - 2019-09-10 16:26:49 --> Email Class Initialized
DEBUG - 2019-09-10 16:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:26:49 --> Pagination Class Initialized
INFO - 2019-09-10 16:26:49 --> Database Driver Class Initialized
INFO - 2019-09-10 16:26:49 --> Database Driver Class Initialized
INFO - 2019-09-10 16:26:49 --> Controller Class Initialized
INFO - 2019-09-10 16:26:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 16:26:49 --> Final output sent to browser
DEBUG - 2019-09-10 16:26:49 --> Total execution time: 0.0519
INFO - 2019-09-10 16:26:49 --> Config Class Initialized
INFO - 2019-09-10 16:26:49 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:26:49 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:26:49 --> Utf8 Class Initialized
INFO - 2019-09-10 16:26:49 --> URI Class Initialized
INFO - 2019-09-10 16:26:49 --> Router Class Initialized
INFO - 2019-09-10 16:26:49 --> Output Class Initialized
INFO - 2019-09-10 16:26:49 --> Security Class Initialized
DEBUG - 2019-09-10 16:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:26:49 --> Input Class Initialized
INFO - 2019-09-10 16:26:49 --> Language Class Initialized
INFO - 2019-09-10 16:26:49 --> Loader Class Initialized
INFO - 2019-09-10 16:26:49 --> Helper loaded: url_helper
INFO - 2019-09-10 16:26:49 --> Helper loaded: html_helper
INFO - 2019-09-10 16:26:49 --> Helper loaded: form_helper
INFO - 2019-09-10 16:26:49 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:26:49 --> Helper loaded: date_helper
INFO - 2019-09-10 16:26:49 --> Form Validation Class Initialized
INFO - 2019-09-10 16:26:49 --> Email Class Initialized
DEBUG - 2019-09-10 16:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:26:49 --> Pagination Class Initialized
INFO - 2019-09-10 16:26:49 --> Database Driver Class Initialized
INFO - 2019-09-10 16:26:49 --> Database Driver Class Initialized
INFO - 2019-09-10 16:26:49 --> Controller Class Initialized
INFO - 2019-09-10 16:26:49 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 16:26:49 --> Final output sent to browser
DEBUG - 2019-09-10 16:26:49 --> Total execution time: 0.0917
INFO - 2019-09-10 16:27:03 --> Config Class Initialized
INFO - 2019-09-10 16:27:03 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:27:03 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:27:03 --> Utf8 Class Initialized
INFO - 2019-09-10 16:27:03 --> URI Class Initialized
INFO - 2019-09-10 16:27:03 --> Router Class Initialized
INFO - 2019-09-10 16:27:03 --> Output Class Initialized
INFO - 2019-09-10 16:27:03 --> Security Class Initialized
DEBUG - 2019-09-10 16:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:27:03 --> Input Class Initialized
INFO - 2019-09-10 16:27:03 --> Language Class Initialized
INFO - 2019-09-10 16:27:03 --> Loader Class Initialized
INFO - 2019-09-10 16:27:03 --> Helper loaded: url_helper
INFO - 2019-09-10 16:27:03 --> Helper loaded: html_helper
INFO - 2019-09-10 16:27:03 --> Helper loaded: form_helper
INFO - 2019-09-10 16:27:03 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:27:03 --> Helper loaded: date_helper
INFO - 2019-09-10 16:27:03 --> Form Validation Class Initialized
INFO - 2019-09-10 16:27:03 --> Email Class Initialized
DEBUG - 2019-09-10 16:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:27:03 --> Pagination Class Initialized
INFO - 2019-09-10 16:27:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:27:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:27:03 --> Controller Class Initialized
INFO - 2019-09-10 16:27:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 16:27:03 --> Config Class Initialized
INFO - 2019-09-10 16:27:03 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:27:03 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:27:03 --> Utf8 Class Initialized
INFO - 2019-09-10 16:27:03 --> URI Class Initialized
INFO - 2019-09-10 16:27:03 --> Router Class Initialized
INFO - 2019-09-10 16:27:03 --> Output Class Initialized
INFO - 2019-09-10 16:27:03 --> Security Class Initialized
DEBUG - 2019-09-10 16:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:27:03 --> Input Class Initialized
INFO - 2019-09-10 16:27:03 --> Language Class Initialized
INFO - 2019-09-10 16:27:03 --> Loader Class Initialized
INFO - 2019-09-10 16:27:03 --> Helper loaded: url_helper
INFO - 2019-09-10 16:27:03 --> Helper loaded: html_helper
INFO - 2019-09-10 16:27:03 --> Helper loaded: form_helper
INFO - 2019-09-10 16:27:03 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:27:03 --> Helper loaded: date_helper
INFO - 2019-09-10 16:27:03 --> Form Validation Class Initialized
INFO - 2019-09-10 16:27:03 --> Email Class Initialized
DEBUG - 2019-09-10 16:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:27:03 --> Pagination Class Initialized
INFO - 2019-09-10 16:27:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:27:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:27:03 --> Controller Class Initialized
INFO - 2019-09-10 16:27:03 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 16:27:03 --> Final output sent to browser
DEBUG - 2019-09-10 16:27:03 --> Total execution time: 0.0541
INFO - 2019-09-10 16:29:17 --> Config Class Initialized
INFO - 2019-09-10 16:29:17 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:29:17 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:29:17 --> Utf8 Class Initialized
INFO - 2019-09-10 16:29:17 --> URI Class Initialized
INFO - 2019-09-10 16:29:17 --> Router Class Initialized
INFO - 2019-09-10 16:29:17 --> Output Class Initialized
INFO - 2019-09-10 16:29:17 --> Security Class Initialized
DEBUG - 2019-09-10 16:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:29:17 --> Input Class Initialized
INFO - 2019-09-10 16:29:17 --> Language Class Initialized
INFO - 2019-09-10 16:29:17 --> Loader Class Initialized
INFO - 2019-09-10 16:29:17 --> Helper loaded: url_helper
INFO - 2019-09-10 16:29:17 --> Helper loaded: html_helper
INFO - 2019-09-10 16:29:17 --> Helper loaded: form_helper
INFO - 2019-09-10 16:29:17 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:29:17 --> Helper loaded: date_helper
INFO - 2019-09-10 16:29:17 --> Form Validation Class Initialized
INFO - 2019-09-10 16:29:17 --> Email Class Initialized
DEBUG - 2019-09-10 16:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-10 16:29:17 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\wamp64\www\pridehotel_lagos\system\libraries\Session\Session.php 141
INFO - 2019-09-10 16:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:29:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:29:17 --> Pagination Class Initialized
INFO - 2019-09-10 16:29:17 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:17 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:17 --> Controller Class Initialized
INFO - 2019-09-10 16:29:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 16:29:17 --> Config Class Initialized
INFO - 2019-09-10 16:29:17 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:29:17 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:29:17 --> Utf8 Class Initialized
INFO - 2019-09-10 16:29:17 --> URI Class Initialized
INFO - 2019-09-10 16:29:17 --> Router Class Initialized
INFO - 2019-09-10 16:29:17 --> Output Class Initialized
INFO - 2019-09-10 16:29:17 --> Security Class Initialized
DEBUG - 2019-09-10 16:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:29:17 --> Input Class Initialized
INFO - 2019-09-10 16:29:17 --> Language Class Initialized
INFO - 2019-09-10 16:29:17 --> Loader Class Initialized
INFO - 2019-09-10 16:29:17 --> Helper loaded: url_helper
INFO - 2019-09-10 16:29:17 --> Helper loaded: html_helper
INFO - 2019-09-10 16:29:17 --> Helper loaded: form_helper
INFO - 2019-09-10 16:29:17 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:29:17 --> Helper loaded: date_helper
INFO - 2019-09-10 16:29:17 --> Form Validation Class Initialized
INFO - 2019-09-10 16:29:17 --> Email Class Initialized
DEBUG - 2019-09-10 16:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-10 16:29:17 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\wamp64\www\pridehotel_lagos\system\libraries\Session\Session.php 141
INFO - 2019-09-10 16:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:29:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:29:17 --> Pagination Class Initialized
INFO - 2019-09-10 16:29:17 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:17 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:17 --> Controller Class Initialized
INFO - 2019-09-10 16:29:17 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:29:17 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-10 16:29:17 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:29:17 --> Final output sent to browser
DEBUG - 2019-09-10 16:29:17 --> Total execution time: 0.0717
INFO - 2019-09-10 16:29:18 --> Config Class Initialized
INFO - 2019-09-10 16:29:18 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:29:18 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:29:18 --> Utf8 Class Initialized
INFO - 2019-09-10 16:29:18 --> URI Class Initialized
INFO - 2019-09-10 16:29:18 --> Router Class Initialized
INFO - 2019-09-10 16:29:18 --> Output Class Initialized
INFO - 2019-09-10 16:29:18 --> Security Class Initialized
DEBUG - 2019-09-10 16:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:29:18 --> Input Class Initialized
INFO - 2019-09-10 16:29:18 --> Language Class Initialized
INFO - 2019-09-10 16:29:18 --> Loader Class Initialized
INFO - 2019-09-10 16:29:18 --> Helper loaded: url_helper
INFO - 2019-09-10 16:29:18 --> Helper loaded: html_helper
INFO - 2019-09-10 16:29:18 --> Helper loaded: form_helper
INFO - 2019-09-10 16:29:18 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:29:18 --> Helper loaded: date_helper
INFO - 2019-09-10 16:29:18 --> Form Validation Class Initialized
INFO - 2019-09-10 16:29:18 --> Email Class Initialized
DEBUG - 2019-09-10 16:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-10 16:29:18 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\wamp64\www\pridehotel_lagos\system\libraries\Session\Session.php 141
INFO - 2019-09-10 16:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:29:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:29:18 --> Pagination Class Initialized
INFO - 2019-09-10 16:29:18 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:18 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:18 --> Controller Class Initialized
INFO - 2019-09-10 16:29:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:29:18 --> Final output sent to browser
DEBUG - 2019-09-10 16:29:18 --> Total execution time: 0.0735
INFO - 2019-09-10 16:29:18 --> Config Class Initialized
INFO - 2019-09-10 16:29:18 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:29:18 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:29:18 --> Utf8 Class Initialized
INFO - 2019-09-10 16:29:18 --> URI Class Initialized
INFO - 2019-09-10 16:29:18 --> Router Class Initialized
INFO - 2019-09-10 16:29:18 --> Output Class Initialized
INFO - 2019-09-10 16:29:18 --> Security Class Initialized
DEBUG - 2019-09-10 16:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:29:18 --> Input Class Initialized
INFO - 2019-09-10 16:29:18 --> Language Class Initialized
INFO - 2019-09-10 16:29:18 --> Loader Class Initialized
INFO - 2019-09-10 16:29:18 --> Helper loaded: url_helper
INFO - 2019-09-10 16:29:18 --> Helper loaded: html_helper
INFO - 2019-09-10 16:29:18 --> Helper loaded: form_helper
INFO - 2019-09-10 16:29:18 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:29:18 --> Helper loaded: date_helper
INFO - 2019-09-10 16:29:18 --> Form Validation Class Initialized
INFO - 2019-09-10 16:29:18 --> Email Class Initialized
DEBUG - 2019-09-10 16:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-10 16:29:18 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\wamp64\www\pridehotel_lagos\system\libraries\Session\Session.php 141
INFO - 2019-09-10 16:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:29:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:29:18 --> Pagination Class Initialized
INFO - 2019-09-10 16:29:18 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:18 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:18 --> Controller Class Initialized
INFO - 2019-09-10 16:29:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:29:18 --> Final output sent to browser
DEBUG - 2019-09-10 16:29:18 --> Total execution time: 0.0796
INFO - 2019-09-10 16:29:27 --> Config Class Initialized
INFO - 2019-09-10 16:29:27 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:29:27 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:29:27 --> Utf8 Class Initialized
INFO - 2019-09-10 16:29:27 --> URI Class Initialized
INFO - 2019-09-10 16:29:27 --> Router Class Initialized
INFO - 2019-09-10 16:29:27 --> Output Class Initialized
INFO - 2019-09-10 16:29:27 --> Security Class Initialized
DEBUG - 2019-09-10 16:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:29:27 --> Input Class Initialized
INFO - 2019-09-10 16:29:27 --> Language Class Initialized
INFO - 2019-09-10 16:29:27 --> Loader Class Initialized
INFO - 2019-09-10 16:29:27 --> Helper loaded: url_helper
INFO - 2019-09-10 16:29:27 --> Helper loaded: html_helper
INFO - 2019-09-10 16:29:27 --> Helper loaded: form_helper
INFO - 2019-09-10 16:29:27 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:29:27 --> Helper loaded: date_helper
INFO - 2019-09-10 16:29:27 --> Form Validation Class Initialized
INFO - 2019-09-10 16:29:27 --> Email Class Initialized
DEBUG - 2019-09-10 16:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-10 16:29:27 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\wamp64\www\pridehotel_lagos\system\libraries\Session\Session.php 141
INFO - 2019-09-10 16:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:29:27 --> Pagination Class Initialized
INFO - 2019-09-10 16:29:27 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:27 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:27 --> Controller Class Initialized
INFO - 2019-09-10 16:29:27 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:29:27 --> Final output sent to browser
DEBUG - 2019-09-10 16:29:27 --> Total execution time: 0.0578
INFO - 2019-09-10 16:29:28 --> Config Class Initialized
INFO - 2019-09-10 16:29:28 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:29:28 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:29:28 --> Utf8 Class Initialized
INFO - 2019-09-10 16:29:28 --> URI Class Initialized
INFO - 2019-09-10 16:29:28 --> Router Class Initialized
INFO - 2019-09-10 16:29:28 --> Output Class Initialized
INFO - 2019-09-10 16:29:28 --> Security Class Initialized
DEBUG - 2019-09-10 16:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:29:28 --> Input Class Initialized
INFO - 2019-09-10 16:29:28 --> Language Class Initialized
INFO - 2019-09-10 16:29:28 --> Loader Class Initialized
INFO - 2019-09-10 16:29:28 --> Helper loaded: url_helper
INFO - 2019-09-10 16:29:28 --> Helper loaded: html_helper
INFO - 2019-09-10 16:29:28 --> Helper loaded: form_helper
INFO - 2019-09-10 16:29:28 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:29:28 --> Helper loaded: date_helper
INFO - 2019-09-10 16:29:28 --> Form Validation Class Initialized
INFO - 2019-09-10 16:29:28 --> Email Class Initialized
DEBUG - 2019-09-10 16:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-10 16:29:28 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\wamp64\www\pridehotel_lagos\system\libraries\Session\Session.php 141
INFO - 2019-09-10 16:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:29:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:29:28 --> Pagination Class Initialized
INFO - 2019-09-10 16:29:28 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:28 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:28 --> Controller Class Initialized
INFO - 2019-09-10 16:29:28 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:29:28 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-10 16:29:28 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:29:28 --> Final output sent to browser
DEBUG - 2019-09-10 16:29:28 --> Total execution time: 0.0561
INFO - 2019-09-10 16:29:29 --> Config Class Initialized
INFO - 2019-09-10 16:29:29 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:29:29 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:29:29 --> Utf8 Class Initialized
INFO - 2019-09-10 16:29:29 --> URI Class Initialized
INFO - 2019-09-10 16:29:29 --> Router Class Initialized
INFO - 2019-09-10 16:29:29 --> Output Class Initialized
INFO - 2019-09-10 16:29:29 --> Security Class Initialized
DEBUG - 2019-09-10 16:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:29:29 --> Input Class Initialized
INFO - 2019-09-10 16:29:29 --> Language Class Initialized
INFO - 2019-09-10 16:29:29 --> Loader Class Initialized
INFO - 2019-09-10 16:29:29 --> Helper loaded: url_helper
INFO - 2019-09-10 16:29:29 --> Helper loaded: html_helper
INFO - 2019-09-10 16:29:29 --> Helper loaded: form_helper
INFO - 2019-09-10 16:29:29 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:29:29 --> Helper loaded: date_helper
INFO - 2019-09-10 16:29:29 --> Form Validation Class Initialized
INFO - 2019-09-10 16:29:29 --> Email Class Initialized
DEBUG - 2019-09-10 16:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-10 16:29:29 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\wamp64\www\pridehotel_lagos\system\libraries\Session\Session.php 141
INFO - 2019-09-10 16:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:29:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:29:29 --> Pagination Class Initialized
INFO - 2019-09-10 16:29:29 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:29 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:29 --> Controller Class Initialized
INFO - 2019-09-10 16:29:29 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:29:29 --> Final output sent to browser
DEBUG - 2019-09-10 16:29:29 --> Total execution time: 0.0715
INFO - 2019-09-10 16:29:29 --> Config Class Initialized
INFO - 2019-09-10 16:29:29 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:29:29 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:29:29 --> Utf8 Class Initialized
INFO - 2019-09-10 16:29:29 --> URI Class Initialized
INFO - 2019-09-10 16:29:29 --> Router Class Initialized
INFO - 2019-09-10 16:29:29 --> Output Class Initialized
INFO - 2019-09-10 16:29:29 --> Security Class Initialized
DEBUG - 2019-09-10 16:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:29:29 --> Input Class Initialized
INFO - 2019-09-10 16:29:29 --> Language Class Initialized
INFO - 2019-09-10 16:29:29 --> Loader Class Initialized
INFO - 2019-09-10 16:29:29 --> Helper loaded: url_helper
INFO - 2019-09-10 16:29:29 --> Helper loaded: html_helper
INFO - 2019-09-10 16:29:29 --> Helper loaded: form_helper
INFO - 2019-09-10 16:29:29 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:29:29 --> Helper loaded: date_helper
INFO - 2019-09-10 16:29:29 --> Form Validation Class Initialized
INFO - 2019-09-10 16:29:29 --> Email Class Initialized
DEBUG - 2019-09-10 16:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-10 16:29:29 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\wamp64\www\pridehotel_lagos\system\libraries\Session\Session.php 141
INFO - 2019-09-10 16:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:29:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:29:29 --> Pagination Class Initialized
INFO - 2019-09-10 16:29:29 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:29 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:29 --> Controller Class Initialized
INFO - 2019-09-10 16:29:29 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:29:29 --> Final output sent to browser
DEBUG - 2019-09-10 16:29:29 --> Total execution time: 0.0612
INFO - 2019-09-10 16:29:31 --> Config Class Initialized
INFO - 2019-09-10 16:29:31 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:29:31 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:29:31 --> Utf8 Class Initialized
INFO - 2019-09-10 16:29:31 --> URI Class Initialized
INFO - 2019-09-10 16:29:31 --> Router Class Initialized
INFO - 2019-09-10 16:29:31 --> Output Class Initialized
INFO - 2019-09-10 16:29:31 --> Security Class Initialized
DEBUG - 2019-09-10 16:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:29:31 --> Input Class Initialized
INFO - 2019-09-10 16:29:31 --> Language Class Initialized
INFO - 2019-09-10 16:29:31 --> Loader Class Initialized
INFO - 2019-09-10 16:29:31 --> Helper loaded: url_helper
INFO - 2019-09-10 16:29:31 --> Helper loaded: html_helper
INFO - 2019-09-10 16:29:31 --> Helper loaded: form_helper
INFO - 2019-09-10 16:29:31 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:29:31 --> Helper loaded: date_helper
INFO - 2019-09-10 16:29:31 --> Form Validation Class Initialized
INFO - 2019-09-10 16:29:31 --> Email Class Initialized
DEBUG - 2019-09-10 16:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-10 16:29:31 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\wamp64\www\pridehotel_lagos\system\libraries\Session\Session.php 141
INFO - 2019-09-10 16:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:29:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:29:31 --> Pagination Class Initialized
INFO - 2019-09-10 16:29:31 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:31 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:31 --> Controller Class Initialized
INFO - 2019-09-10 16:29:31 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:29:31 --> Final output sent to browser
DEBUG - 2019-09-10 16:29:31 --> Total execution time: 0.0604
INFO - 2019-09-10 16:29:38 --> Config Class Initialized
INFO - 2019-09-10 16:29:38 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:29:38 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:29:38 --> Utf8 Class Initialized
INFO - 2019-09-10 16:29:38 --> URI Class Initialized
INFO - 2019-09-10 16:29:38 --> Router Class Initialized
INFO - 2019-09-10 16:29:38 --> Output Class Initialized
INFO - 2019-09-10 16:29:38 --> Security Class Initialized
DEBUG - 2019-09-10 16:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:29:38 --> Input Class Initialized
INFO - 2019-09-10 16:29:38 --> Language Class Initialized
INFO - 2019-09-10 16:29:38 --> Loader Class Initialized
INFO - 2019-09-10 16:29:38 --> Helper loaded: url_helper
INFO - 2019-09-10 16:29:38 --> Helper loaded: html_helper
INFO - 2019-09-10 16:29:38 --> Helper loaded: form_helper
INFO - 2019-09-10 16:29:38 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:29:38 --> Helper loaded: date_helper
INFO - 2019-09-10 16:29:38 --> Form Validation Class Initialized
INFO - 2019-09-10 16:29:38 --> Email Class Initialized
DEBUG - 2019-09-10 16:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-10 16:29:38 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\wamp64\www\pridehotel_lagos\system\libraries\Session\Session.php 141
INFO - 2019-09-10 16:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:29:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:29:38 --> Pagination Class Initialized
INFO - 2019-09-10 16:29:38 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:38 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:38 --> Controller Class Initialized
INFO - 2019-09-10 16:29:38 --> Config Class Initialized
INFO - 2019-09-10 16:29:38 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:29:38 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:29:38 --> Utf8 Class Initialized
INFO - 2019-09-10 16:29:38 --> URI Class Initialized
INFO - 2019-09-10 16:29:38 --> Router Class Initialized
INFO - 2019-09-10 16:29:38 --> Output Class Initialized
INFO - 2019-09-10 16:29:38 --> Security Class Initialized
DEBUG - 2019-09-10 16:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:29:38 --> Input Class Initialized
INFO - 2019-09-10 16:29:38 --> Language Class Initialized
INFO - 2019-09-10 16:29:38 --> Loader Class Initialized
INFO - 2019-09-10 16:29:38 --> Helper loaded: url_helper
INFO - 2019-09-10 16:29:38 --> Helper loaded: html_helper
INFO - 2019-09-10 16:29:38 --> Helper loaded: form_helper
INFO - 2019-09-10 16:29:38 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:29:38 --> Helper loaded: date_helper
INFO - 2019-09-10 16:29:38 --> Form Validation Class Initialized
INFO - 2019-09-10 16:29:38 --> Email Class Initialized
DEBUG - 2019-09-10 16:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-10 16:29:38 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\wamp64\www\pridehotel_lagos\system\libraries\Session\Session.php 141
INFO - 2019-09-10 16:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:29:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:29:38 --> Pagination Class Initialized
INFO - 2019-09-10 16:29:38 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:38 --> Database Driver Class Initialized
INFO - 2019-09-10 16:29:38 --> Controller Class Initialized
INFO - 2019-09-10 16:29:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 16:29:38 --> Final output sent to browser
DEBUG - 2019-09-10 16:29:38 --> Total execution time: 0.0489
INFO - 2019-09-10 16:31:43 --> Config Class Initialized
INFO - 2019-09-10 16:31:43 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:31:43 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:31:43 --> Utf8 Class Initialized
INFO - 2019-09-10 16:31:43 --> URI Class Initialized
INFO - 2019-09-10 16:31:43 --> Router Class Initialized
INFO - 2019-09-10 16:31:43 --> Output Class Initialized
INFO - 2019-09-10 16:31:43 --> Security Class Initialized
DEBUG - 2019-09-10 16:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:31:43 --> Input Class Initialized
INFO - 2019-09-10 16:31:43 --> Language Class Initialized
INFO - 2019-09-10 16:31:43 --> Loader Class Initialized
INFO - 2019-09-10 16:31:43 --> Helper loaded: url_helper
INFO - 2019-09-10 16:31:43 --> Helper loaded: html_helper
INFO - 2019-09-10 16:31:43 --> Helper loaded: form_helper
INFO - 2019-09-10 16:31:43 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:31:43 --> Helper loaded: date_helper
INFO - 2019-09-10 16:31:43 --> Form Validation Class Initialized
INFO - 2019-09-10 16:31:43 --> Email Class Initialized
DEBUG - 2019-09-10 16:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:31:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:31:43 --> Pagination Class Initialized
INFO - 2019-09-10 16:31:43 --> Database Driver Class Initialized
INFO - 2019-09-10 16:31:43 --> Database Driver Class Initialized
INFO - 2019-09-10 16:31:43 --> Controller Class Initialized
INFO - 2019-09-10 16:31:43 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 16:31:43 --> Final output sent to browser
DEBUG - 2019-09-10 16:31:43 --> Total execution time: 0.0933
INFO - 2019-09-10 16:31:43 --> Config Class Initialized
INFO - 2019-09-10 16:31:43 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:31:43 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:31:43 --> Utf8 Class Initialized
INFO - 2019-09-10 16:31:43 --> URI Class Initialized
INFO - 2019-09-10 16:31:43 --> Router Class Initialized
INFO - 2019-09-10 16:31:43 --> Output Class Initialized
INFO - 2019-09-10 16:31:43 --> Security Class Initialized
DEBUG - 2019-09-10 16:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:31:43 --> Input Class Initialized
INFO - 2019-09-10 16:31:43 --> Language Class Initialized
INFO - 2019-09-10 16:31:43 --> Loader Class Initialized
INFO - 2019-09-10 16:31:43 --> Helper loaded: url_helper
INFO - 2019-09-10 16:31:43 --> Helper loaded: html_helper
INFO - 2019-09-10 16:31:43 --> Helper loaded: form_helper
INFO - 2019-09-10 16:31:43 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:31:43 --> Helper loaded: date_helper
INFO - 2019-09-10 16:31:43 --> Form Validation Class Initialized
INFO - 2019-09-10 16:31:43 --> Email Class Initialized
DEBUG - 2019-09-10 16:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:31:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:31:43 --> Pagination Class Initialized
INFO - 2019-09-10 16:31:43 --> Database Driver Class Initialized
INFO - 2019-09-10 16:31:43 --> Database Driver Class Initialized
INFO - 2019-09-10 16:31:43 --> Controller Class Initialized
INFO - 2019-09-10 16:31:43 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 16:31:43 --> Final output sent to browser
DEBUG - 2019-09-10 16:31:43 --> Total execution time: 0.0614
INFO - 2019-09-10 16:31:53 --> Config Class Initialized
INFO - 2019-09-10 16:31:53 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:31:53 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:31:53 --> Utf8 Class Initialized
INFO - 2019-09-10 16:31:53 --> URI Class Initialized
INFO - 2019-09-10 16:31:53 --> Router Class Initialized
INFO - 2019-09-10 16:31:53 --> Output Class Initialized
INFO - 2019-09-10 16:31:53 --> Security Class Initialized
DEBUG - 2019-09-10 16:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:31:53 --> Input Class Initialized
INFO - 2019-09-10 16:31:53 --> Language Class Initialized
INFO - 2019-09-10 16:31:53 --> Loader Class Initialized
INFO - 2019-09-10 16:31:53 --> Helper loaded: url_helper
INFO - 2019-09-10 16:31:53 --> Helper loaded: html_helper
INFO - 2019-09-10 16:31:53 --> Helper loaded: form_helper
INFO - 2019-09-10 16:31:53 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:31:53 --> Helper loaded: date_helper
INFO - 2019-09-10 16:31:53 --> Form Validation Class Initialized
INFO - 2019-09-10 16:31:53 --> Email Class Initialized
DEBUG - 2019-09-10 16:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:31:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:31:53 --> Pagination Class Initialized
INFO - 2019-09-10 16:31:53 --> Database Driver Class Initialized
INFO - 2019-09-10 16:31:53 --> Database Driver Class Initialized
INFO - 2019-09-10 16:31:53 --> Controller Class Initialized
INFO - 2019-09-10 16:31:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 16:31:54 --> Config Class Initialized
INFO - 2019-09-10 16:31:54 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:31:54 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:31:54 --> Utf8 Class Initialized
INFO - 2019-09-10 16:31:54 --> URI Class Initialized
INFO - 2019-09-10 16:31:54 --> Router Class Initialized
INFO - 2019-09-10 16:31:54 --> Output Class Initialized
INFO - 2019-09-10 16:31:54 --> Security Class Initialized
DEBUG - 2019-09-10 16:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:31:54 --> Input Class Initialized
INFO - 2019-09-10 16:31:54 --> Language Class Initialized
INFO - 2019-09-10 16:31:54 --> Loader Class Initialized
INFO - 2019-09-10 16:31:54 --> Helper loaded: url_helper
INFO - 2019-09-10 16:31:54 --> Helper loaded: html_helper
INFO - 2019-09-10 16:31:54 --> Helper loaded: form_helper
INFO - 2019-09-10 16:31:54 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:31:54 --> Helper loaded: date_helper
INFO - 2019-09-10 16:31:54 --> Form Validation Class Initialized
INFO - 2019-09-10 16:31:54 --> Email Class Initialized
DEBUG - 2019-09-10 16:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:31:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:31:54 --> Pagination Class Initialized
INFO - 2019-09-10 16:31:54 --> Database Driver Class Initialized
INFO - 2019-09-10 16:31:54 --> Database Driver Class Initialized
INFO - 2019-09-10 16:31:54 --> Controller Class Initialized
INFO - 2019-09-10 16:31:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 16:31:54 --> Final output sent to browser
DEBUG - 2019-09-10 16:31:54 --> Total execution time: 0.0548
INFO - 2019-09-10 16:32:04 --> Config Class Initialized
INFO - 2019-09-10 16:32:04 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:32:04 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:32:04 --> Utf8 Class Initialized
INFO - 2019-09-10 16:32:04 --> URI Class Initialized
INFO - 2019-09-10 16:32:04 --> Router Class Initialized
INFO - 2019-09-10 16:32:04 --> Output Class Initialized
INFO - 2019-09-10 16:32:04 --> Security Class Initialized
DEBUG - 2019-09-10 16:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:32:04 --> Input Class Initialized
INFO - 2019-09-10 16:32:04 --> Language Class Initialized
INFO - 2019-09-10 16:32:04 --> Loader Class Initialized
INFO - 2019-09-10 16:32:04 --> Helper loaded: url_helper
INFO - 2019-09-10 16:32:04 --> Helper loaded: html_helper
INFO - 2019-09-10 16:32:04 --> Helper loaded: form_helper
INFO - 2019-09-10 16:32:04 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:32:04 --> Helper loaded: date_helper
INFO - 2019-09-10 16:32:04 --> Form Validation Class Initialized
INFO - 2019-09-10 16:32:04 --> Email Class Initialized
DEBUG - 2019-09-10 16:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:32:04 --> Pagination Class Initialized
INFO - 2019-09-10 16:32:04 --> Database Driver Class Initialized
INFO - 2019-09-10 16:32:04 --> Database Driver Class Initialized
INFO - 2019-09-10 16:32:04 --> Controller Class Initialized
INFO - 2019-09-10 16:32:04 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 16:32:04 --> Final output sent to browser
DEBUG - 2019-09-10 16:32:04 --> Total execution time: 0.0540
INFO - 2019-09-10 16:32:04 --> Config Class Initialized
INFO - 2019-09-10 16:32:04 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:32:04 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:32:04 --> Utf8 Class Initialized
INFO - 2019-09-10 16:32:04 --> URI Class Initialized
INFO - 2019-09-10 16:32:04 --> Router Class Initialized
INFO - 2019-09-10 16:32:04 --> Output Class Initialized
INFO - 2019-09-10 16:32:05 --> Security Class Initialized
DEBUG - 2019-09-10 16:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:32:05 --> Input Class Initialized
INFO - 2019-09-10 16:32:05 --> Language Class Initialized
INFO - 2019-09-10 16:32:05 --> Loader Class Initialized
INFO - 2019-09-10 16:32:05 --> Helper loaded: url_helper
INFO - 2019-09-10 16:32:05 --> Helper loaded: html_helper
INFO - 2019-09-10 16:32:05 --> Helper loaded: form_helper
INFO - 2019-09-10 16:32:05 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:32:05 --> Helper loaded: date_helper
INFO - 2019-09-10 16:32:05 --> Form Validation Class Initialized
INFO - 2019-09-10 16:32:05 --> Email Class Initialized
DEBUG - 2019-09-10 16:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:32:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:32:05 --> Pagination Class Initialized
INFO - 2019-09-10 16:32:05 --> Database Driver Class Initialized
INFO - 2019-09-10 16:32:05 --> Database Driver Class Initialized
INFO - 2019-09-10 16:32:05 --> Controller Class Initialized
INFO - 2019-09-10 16:32:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 16:32:05 --> Final output sent to browser
DEBUG - 2019-09-10 16:32:05 --> Total execution time: 0.0662
INFO - 2019-09-10 16:32:45 --> Config Class Initialized
INFO - 2019-09-10 16:32:45 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:32:45 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:32:45 --> Utf8 Class Initialized
INFO - 2019-09-10 16:32:45 --> URI Class Initialized
INFO - 2019-09-10 16:32:45 --> Router Class Initialized
INFO - 2019-09-10 16:32:45 --> Output Class Initialized
INFO - 2019-09-10 16:32:45 --> Security Class Initialized
DEBUG - 2019-09-10 16:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:32:45 --> Input Class Initialized
INFO - 2019-09-10 16:32:45 --> Language Class Initialized
INFO - 2019-09-10 16:32:45 --> Loader Class Initialized
INFO - 2019-09-10 16:32:45 --> Helper loaded: url_helper
INFO - 2019-09-10 16:32:45 --> Helper loaded: html_helper
INFO - 2019-09-10 16:32:45 --> Helper loaded: form_helper
INFO - 2019-09-10 16:32:45 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:32:45 --> Helper loaded: date_helper
INFO - 2019-09-10 16:32:45 --> Form Validation Class Initialized
INFO - 2019-09-10 16:32:45 --> Email Class Initialized
DEBUG - 2019-09-10 16:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:32:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:32:45 --> Pagination Class Initialized
INFO - 2019-09-10 16:32:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:32:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:32:45 --> Controller Class Initialized
INFO - 2019-09-10 16:32:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 16:32:45 --> Final output sent to browser
DEBUG - 2019-09-10 16:32:45 --> Total execution time: 0.0587
INFO - 2019-09-10 16:32:45 --> Config Class Initialized
INFO - 2019-09-10 16:32:45 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:32:45 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:32:45 --> Utf8 Class Initialized
INFO - 2019-09-10 16:32:45 --> URI Class Initialized
INFO - 2019-09-10 16:32:45 --> Router Class Initialized
INFO - 2019-09-10 16:32:45 --> Output Class Initialized
INFO - 2019-09-10 16:32:45 --> Security Class Initialized
DEBUG - 2019-09-10 16:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:32:45 --> Input Class Initialized
INFO - 2019-09-10 16:32:45 --> Language Class Initialized
INFO - 2019-09-10 16:32:45 --> Loader Class Initialized
INFO - 2019-09-10 16:32:45 --> Helper loaded: url_helper
INFO - 2019-09-10 16:32:45 --> Helper loaded: html_helper
INFO - 2019-09-10 16:32:45 --> Helper loaded: form_helper
INFO - 2019-09-10 16:32:45 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:32:45 --> Helper loaded: date_helper
INFO - 2019-09-10 16:32:45 --> Form Validation Class Initialized
INFO - 2019-09-10 16:32:45 --> Email Class Initialized
DEBUG - 2019-09-10 16:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:32:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:32:45 --> Pagination Class Initialized
INFO - 2019-09-10 16:32:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:32:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:32:45 --> Controller Class Initialized
INFO - 2019-09-10 16:32:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 16:32:45 --> Final output sent to browser
DEBUG - 2019-09-10 16:32:45 --> Total execution time: 0.0667
INFO - 2019-09-10 16:38:57 --> Config Class Initialized
INFO - 2019-09-10 16:38:57 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:38:57 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:38:57 --> Utf8 Class Initialized
INFO - 2019-09-10 16:38:57 --> URI Class Initialized
INFO - 2019-09-10 16:38:57 --> Router Class Initialized
INFO - 2019-09-10 16:38:57 --> Output Class Initialized
INFO - 2019-09-10 16:38:57 --> Security Class Initialized
DEBUG - 2019-09-10 16:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:38:57 --> Input Class Initialized
INFO - 2019-09-10 16:38:57 --> Language Class Initialized
INFO - 2019-09-10 16:38:57 --> Loader Class Initialized
INFO - 2019-09-10 16:38:57 --> Helper loaded: url_helper
INFO - 2019-09-10 16:38:57 --> Helper loaded: html_helper
INFO - 2019-09-10 16:38:57 --> Helper loaded: form_helper
INFO - 2019-09-10 16:38:57 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:38:57 --> Helper loaded: date_helper
INFO - 2019-09-10 16:38:57 --> Form Validation Class Initialized
INFO - 2019-09-10 16:38:57 --> Email Class Initialized
DEBUG - 2019-09-10 16:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:38:57 --> Pagination Class Initialized
INFO - 2019-09-10 16:38:57 --> Database Driver Class Initialized
INFO - 2019-09-10 16:38:57 --> Database Driver Class Initialized
INFO - 2019-09-10 16:38:57 --> Controller Class Initialized
INFO - 2019-09-10 16:38:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 16:38:57 --> Config Class Initialized
INFO - 2019-09-10 16:38:57 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:38:57 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:38:57 --> Utf8 Class Initialized
INFO - 2019-09-10 16:38:57 --> URI Class Initialized
INFO - 2019-09-10 16:38:57 --> Router Class Initialized
INFO - 2019-09-10 16:38:57 --> Output Class Initialized
INFO - 2019-09-10 16:38:57 --> Security Class Initialized
DEBUG - 2019-09-10 16:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:38:57 --> Input Class Initialized
INFO - 2019-09-10 16:38:57 --> Language Class Initialized
INFO - 2019-09-10 16:38:57 --> Loader Class Initialized
INFO - 2019-09-10 16:38:57 --> Helper loaded: url_helper
INFO - 2019-09-10 16:38:57 --> Helper loaded: html_helper
INFO - 2019-09-10 16:38:57 --> Helper loaded: form_helper
INFO - 2019-09-10 16:38:57 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:38:57 --> Helper loaded: date_helper
INFO - 2019-09-10 16:38:57 --> Form Validation Class Initialized
INFO - 2019-09-10 16:38:58 --> Email Class Initialized
DEBUG - 2019-09-10 16:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:38:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:38:58 --> Pagination Class Initialized
INFO - 2019-09-10 16:38:58 --> Database Driver Class Initialized
INFO - 2019-09-10 16:38:58 --> Database Driver Class Initialized
INFO - 2019-09-10 16:38:58 --> Controller Class Initialized
INFO - 2019-09-10 16:38:58 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-10 16:38:58 --> Final output sent to browser
DEBUG - 2019-09-10 16:38:58 --> Total execution time: 0.0439
INFO - 2019-09-10 16:41:04 --> Config Class Initialized
INFO - 2019-09-10 16:41:04 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:41:04 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:41:04 --> Utf8 Class Initialized
INFO - 2019-09-10 16:41:04 --> URI Class Initialized
INFO - 2019-09-10 16:41:04 --> Router Class Initialized
INFO - 2019-09-10 16:41:04 --> Output Class Initialized
INFO - 2019-09-10 16:41:04 --> Security Class Initialized
DEBUG - 2019-09-10 16:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:41:04 --> Input Class Initialized
INFO - 2019-09-10 16:41:04 --> Language Class Initialized
INFO - 2019-09-10 16:41:04 --> Loader Class Initialized
INFO - 2019-09-10 16:41:04 --> Helper loaded: url_helper
INFO - 2019-09-10 16:41:04 --> Helper loaded: html_helper
INFO - 2019-09-10 16:41:04 --> Helper loaded: form_helper
INFO - 2019-09-10 16:41:04 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:41:04 --> Helper loaded: date_helper
INFO - 2019-09-10 16:41:04 --> Form Validation Class Initialized
INFO - 2019-09-10 16:41:04 --> Email Class Initialized
DEBUG - 2019-09-10 16:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:41:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:41:04 --> Pagination Class Initialized
INFO - 2019-09-10 16:41:04 --> Database Driver Class Initialized
INFO - 2019-09-10 16:41:04 --> Database Driver Class Initialized
INFO - 2019-09-10 16:41:04 --> Controller Class Initialized
INFO - 2019-09-10 16:41:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 16:41:04 --> Config Class Initialized
INFO - 2019-09-10 16:41:04 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:41:04 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:41:04 --> Utf8 Class Initialized
INFO - 2019-09-10 16:41:04 --> URI Class Initialized
INFO - 2019-09-10 16:41:04 --> Router Class Initialized
INFO - 2019-09-10 16:41:04 --> Output Class Initialized
INFO - 2019-09-10 16:41:04 --> Security Class Initialized
DEBUG - 2019-09-10 16:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:41:04 --> Input Class Initialized
INFO - 2019-09-10 16:41:04 --> Language Class Initialized
INFO - 2019-09-10 16:41:04 --> Loader Class Initialized
INFO - 2019-09-10 16:41:04 --> Helper loaded: url_helper
INFO - 2019-09-10 16:41:04 --> Helper loaded: html_helper
INFO - 2019-09-10 16:41:04 --> Helper loaded: form_helper
INFO - 2019-09-10 16:41:04 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:41:04 --> Helper loaded: date_helper
INFO - 2019-09-10 16:41:04 --> Form Validation Class Initialized
INFO - 2019-09-10 16:41:04 --> Email Class Initialized
DEBUG - 2019-09-10 16:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:41:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:41:04 --> Pagination Class Initialized
INFO - 2019-09-10 16:41:04 --> Database Driver Class Initialized
INFO - 2019-09-10 16:41:04 --> Database Driver Class Initialized
INFO - 2019-09-10 16:41:04 --> Controller Class Initialized
INFO - 2019-09-10 16:41:04 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:41:04 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-10 16:41:04 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:41:04 --> Final output sent to browser
DEBUG - 2019-09-10 16:41:04 --> Total execution time: 0.0591
INFO - 2019-09-10 16:41:04 --> Config Class Initialized
INFO - 2019-09-10 16:41:04 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:41:04 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:41:04 --> Utf8 Class Initialized
INFO - 2019-09-10 16:41:04 --> URI Class Initialized
INFO - 2019-09-10 16:41:04 --> Router Class Initialized
INFO - 2019-09-10 16:41:04 --> Output Class Initialized
INFO - 2019-09-10 16:41:04 --> Security Class Initialized
DEBUG - 2019-09-10 16:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:41:04 --> Input Class Initialized
INFO - 2019-09-10 16:41:04 --> Language Class Initialized
INFO - 2019-09-10 16:41:04 --> Loader Class Initialized
INFO - 2019-09-10 16:41:04 --> Helper loaded: url_helper
INFO - 2019-09-10 16:41:04 --> Helper loaded: html_helper
INFO - 2019-09-10 16:41:04 --> Helper loaded: form_helper
INFO - 2019-09-10 16:41:04 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:41:04 --> Helper loaded: date_helper
INFO - 2019-09-10 16:41:04 --> Form Validation Class Initialized
INFO - 2019-09-10 16:41:04 --> Email Class Initialized
DEBUG - 2019-09-10 16:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:41:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:41:04 --> Pagination Class Initialized
INFO - 2019-09-10 16:41:04 --> Database Driver Class Initialized
INFO - 2019-09-10 16:41:04 --> Database Driver Class Initialized
INFO - 2019-09-10 16:41:04 --> Controller Class Initialized
INFO - 2019-09-10 16:41:04 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:41:04 --> Final output sent to browser
DEBUG - 2019-09-10 16:41:04 --> Total execution time: 0.1095
INFO - 2019-09-10 16:41:04 --> Config Class Initialized
INFO - 2019-09-10 16:41:04 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:41:04 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:41:04 --> Utf8 Class Initialized
INFO - 2019-09-10 16:41:04 --> URI Class Initialized
INFO - 2019-09-10 16:41:04 --> Router Class Initialized
INFO - 2019-09-10 16:41:04 --> Output Class Initialized
INFO - 2019-09-10 16:41:04 --> Security Class Initialized
DEBUG - 2019-09-10 16:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:41:04 --> Input Class Initialized
INFO - 2019-09-10 16:41:04 --> Language Class Initialized
INFO - 2019-09-10 16:41:04 --> Loader Class Initialized
INFO - 2019-09-10 16:41:04 --> Helper loaded: url_helper
INFO - 2019-09-10 16:41:04 --> Helper loaded: html_helper
INFO - 2019-09-10 16:41:04 --> Helper loaded: form_helper
INFO - 2019-09-10 16:41:04 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:41:04 --> Helper loaded: date_helper
INFO - 2019-09-10 16:41:04 --> Form Validation Class Initialized
INFO - 2019-09-10 16:41:04 --> Email Class Initialized
DEBUG - 2019-09-10 16:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:41:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:41:04 --> Pagination Class Initialized
INFO - 2019-09-10 16:41:04 --> Database Driver Class Initialized
INFO - 2019-09-10 16:41:04 --> Database Driver Class Initialized
INFO - 2019-09-10 16:41:04 --> Controller Class Initialized
INFO - 2019-09-10 16:41:04 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:41:04 --> Final output sent to browser
DEBUG - 2019-09-10 16:41:04 --> Total execution time: 0.0699
INFO - 2019-09-10 16:42:05 --> Config Class Initialized
INFO - 2019-09-10 16:42:05 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:05 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:05 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:05 --> URI Class Initialized
INFO - 2019-09-10 16:42:05 --> Router Class Initialized
INFO - 2019-09-10 16:42:05 --> Output Class Initialized
INFO - 2019-09-10 16:42:05 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:05 --> Input Class Initialized
INFO - 2019-09-10 16:42:05 --> Language Class Initialized
INFO - 2019-09-10 16:42:05 --> Loader Class Initialized
INFO - 2019-09-10 16:42:05 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:05 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:05 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:05 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:05 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:05 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:05 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:05 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:05 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:05 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:05 --> Controller Class Initialized
INFO - 2019-09-10 16:42:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:42:05 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:05 --> Total execution time: 0.0539
INFO - 2019-09-10 16:42:07 --> Config Class Initialized
INFO - 2019-09-10 16:42:07 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:07 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:07 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:07 --> URI Class Initialized
INFO - 2019-09-10 16:42:07 --> Router Class Initialized
INFO - 2019-09-10 16:42:07 --> Output Class Initialized
INFO - 2019-09-10 16:42:07 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:07 --> Input Class Initialized
INFO - 2019-09-10 16:42:07 --> Language Class Initialized
INFO - 2019-09-10 16:42:07 --> Loader Class Initialized
INFO - 2019-09-10 16:42:07 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:07 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:07 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:07 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:07 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:07 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:07 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:07 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:07 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:07 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:07 --> Controller Class Initialized
INFO - 2019-09-10 16:42:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:42:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-10 16:42:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-10 16:42:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:42:07 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:07 --> Total execution time: 0.1058
INFO - 2019-09-10 16:42:07 --> Config Class Initialized
INFO - 2019-09-10 16:42:07 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:07 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:07 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:07 --> URI Class Initialized
INFO - 2019-09-10 16:42:07 --> Router Class Initialized
INFO - 2019-09-10 16:42:07 --> Output Class Initialized
INFO - 2019-09-10 16:42:07 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:07 --> Input Class Initialized
INFO - 2019-09-10 16:42:07 --> Language Class Initialized
INFO - 2019-09-10 16:42:07 --> Loader Class Initialized
INFO - 2019-09-10 16:42:07 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:07 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:07 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:07 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:07 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:07 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:07 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:07 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:07 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:07 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:07 --> Controller Class Initialized
INFO - 2019-09-10 16:42:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:42:07 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:07 --> Total execution time: 0.0627
INFO - 2019-09-10 16:42:07 --> Config Class Initialized
INFO - 2019-09-10 16:42:07 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:07 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:07 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:07 --> URI Class Initialized
INFO - 2019-09-10 16:42:07 --> Router Class Initialized
INFO - 2019-09-10 16:42:07 --> Output Class Initialized
INFO - 2019-09-10 16:42:07 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:07 --> Input Class Initialized
INFO - 2019-09-10 16:42:07 --> Language Class Initialized
INFO - 2019-09-10 16:42:07 --> Loader Class Initialized
INFO - 2019-09-10 16:42:07 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:07 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:07 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:07 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:07 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:07 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:07 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:07 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:07 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:07 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:07 --> Controller Class Initialized
INFO - 2019-09-10 16:42:07 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:42:07 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:07 --> Total execution time: 0.0643
INFO - 2019-09-10 16:42:09 --> Config Class Initialized
INFO - 2019-09-10 16:42:09 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:09 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:09 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:09 --> URI Class Initialized
INFO - 2019-09-10 16:42:09 --> Router Class Initialized
INFO - 2019-09-10 16:42:09 --> Output Class Initialized
INFO - 2019-09-10 16:42:09 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:09 --> Input Class Initialized
INFO - 2019-09-10 16:42:09 --> Language Class Initialized
INFO - 2019-09-10 16:42:09 --> Loader Class Initialized
INFO - 2019-09-10 16:42:09 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:09 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:09 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:09 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:09 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:09 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:09 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:09 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:09 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:09 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:09 --> Controller Class Initialized
INFO - 2019-09-10 16:42:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:42:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 16:42:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:42:09 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:09 --> Total execution time: 0.0713
INFO - 2019-09-10 16:42:09 --> Config Class Initialized
INFO - 2019-09-10 16:42:09 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:09 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:09 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:09 --> URI Class Initialized
INFO - 2019-09-10 16:42:09 --> Router Class Initialized
INFO - 2019-09-10 16:42:09 --> Output Class Initialized
INFO - 2019-09-10 16:42:09 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:09 --> Input Class Initialized
INFO - 2019-09-10 16:42:09 --> Language Class Initialized
INFO - 2019-09-10 16:42:09 --> Loader Class Initialized
INFO - 2019-09-10 16:42:09 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:09 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:09 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:09 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:09 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:09 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:09 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:09 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:09 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:09 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:09 --> Controller Class Initialized
INFO - 2019-09-10 16:42:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:42:09 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:09 --> Total execution time: 0.0658
INFO - 2019-09-10 16:42:09 --> Config Class Initialized
INFO - 2019-09-10 16:42:09 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:09 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:09 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:09 --> URI Class Initialized
INFO - 2019-09-10 16:42:09 --> Router Class Initialized
INFO - 2019-09-10 16:42:09 --> Output Class Initialized
INFO - 2019-09-10 16:42:09 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:09 --> Input Class Initialized
INFO - 2019-09-10 16:42:09 --> Language Class Initialized
INFO - 2019-09-10 16:42:09 --> Loader Class Initialized
INFO - 2019-09-10 16:42:09 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:09 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:09 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:09 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:09 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:09 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:09 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:09 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:09 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:09 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:09 --> Controller Class Initialized
INFO - 2019-09-10 16:42:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:42:09 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:09 --> Total execution time: 0.0793
INFO - 2019-09-10 16:42:13 --> Config Class Initialized
INFO - 2019-09-10 16:42:13 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:13 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:13 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:13 --> URI Class Initialized
INFO - 2019-09-10 16:42:13 --> Router Class Initialized
INFO - 2019-09-10 16:42:13 --> Output Class Initialized
INFO - 2019-09-10 16:42:13 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:13 --> Input Class Initialized
INFO - 2019-09-10 16:42:13 --> Language Class Initialized
INFO - 2019-09-10 16:42:13 --> Loader Class Initialized
INFO - 2019-09-10 16:42:13 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:13 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:13 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:13 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:13 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:13 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:13 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:13 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:13 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:13 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:13 --> Controller Class Initialized
INFO - 2019-09-10 16:42:13 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:13 --> Total execution time: 0.0633
INFO - 2019-09-10 16:42:18 --> Config Class Initialized
INFO - 2019-09-10 16:42:18 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:18 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:18 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:18 --> URI Class Initialized
INFO - 2019-09-10 16:42:18 --> Router Class Initialized
INFO - 2019-09-10 16:42:18 --> Output Class Initialized
INFO - 2019-09-10 16:42:18 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:18 --> Input Class Initialized
INFO - 2019-09-10 16:42:18 --> Language Class Initialized
INFO - 2019-09-10 16:42:18 --> Loader Class Initialized
INFO - 2019-09-10 16:42:18 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:18 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:18 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:18 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:18 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:18 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:18 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:18 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:18 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:18 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:18 --> Controller Class Initialized
INFO - 2019-09-10 16:42:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 16:42:18 --> Config Class Initialized
INFO - 2019-09-10 16:42:18 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:18 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:18 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:18 --> URI Class Initialized
INFO - 2019-09-10 16:42:18 --> Router Class Initialized
INFO - 2019-09-10 16:42:18 --> Output Class Initialized
INFO - 2019-09-10 16:42:18 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:18 --> Input Class Initialized
INFO - 2019-09-10 16:42:18 --> Language Class Initialized
INFO - 2019-09-10 16:42:18 --> Loader Class Initialized
INFO - 2019-09-10 16:42:18 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:18 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:18 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:18 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:18 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:19 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:19 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:19 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:19 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:19 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:19 --> Controller Class Initialized
INFO - 2019-09-10 16:42:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:42:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-10 16:42:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:42:19 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:19 --> Total execution time: 0.0717
INFO - 2019-09-10 16:42:19 --> Config Class Initialized
INFO - 2019-09-10 16:42:19 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:19 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:19 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:19 --> URI Class Initialized
INFO - 2019-09-10 16:42:19 --> Router Class Initialized
INFO - 2019-09-10 16:42:19 --> Output Class Initialized
INFO - 2019-09-10 16:42:19 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:19 --> Input Class Initialized
INFO - 2019-09-10 16:42:19 --> Language Class Initialized
INFO - 2019-09-10 16:42:19 --> Loader Class Initialized
INFO - 2019-09-10 16:42:19 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:19 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:19 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:19 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:19 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:19 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:19 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:19 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:19 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:19 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:19 --> Controller Class Initialized
INFO - 2019-09-10 16:42:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:42:19 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:19 --> Total execution time: 0.0572
INFO - 2019-09-10 16:42:19 --> Config Class Initialized
INFO - 2019-09-10 16:42:19 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:19 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:19 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:19 --> URI Class Initialized
INFO - 2019-09-10 16:42:19 --> Router Class Initialized
INFO - 2019-09-10 16:42:19 --> Output Class Initialized
INFO - 2019-09-10 16:42:19 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:19 --> Input Class Initialized
INFO - 2019-09-10 16:42:19 --> Language Class Initialized
INFO - 2019-09-10 16:42:19 --> Loader Class Initialized
INFO - 2019-09-10 16:42:19 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:19 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:19 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:19 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:19 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:19 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:19 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:19 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:19 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:19 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:19 --> Controller Class Initialized
INFO - 2019-09-10 16:42:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:42:19 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:19 --> Total execution time: 0.0595
INFO - 2019-09-10 16:42:52 --> Config Class Initialized
INFO - 2019-09-10 16:42:52 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:52 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:52 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:52 --> URI Class Initialized
INFO - 2019-09-10 16:42:52 --> Router Class Initialized
INFO - 2019-09-10 16:42:52 --> Output Class Initialized
INFO - 2019-09-10 16:42:52 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:52 --> Input Class Initialized
INFO - 2019-09-10 16:42:52 --> Language Class Initialized
INFO - 2019-09-10 16:42:52 --> Loader Class Initialized
INFO - 2019-09-10 16:42:52 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:52 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:52 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:52 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:52 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:52 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:52 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:52 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:52 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:52 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:52 --> Controller Class Initialized
INFO - 2019-09-10 16:42:52 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:42:52 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:52 --> Total execution time: 0.0681
INFO - 2019-09-10 16:42:53 --> Config Class Initialized
INFO - 2019-09-10 16:42:53 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:53 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:53 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:53 --> URI Class Initialized
INFO - 2019-09-10 16:42:53 --> Router Class Initialized
INFO - 2019-09-10 16:42:53 --> Output Class Initialized
INFO - 2019-09-10 16:42:53 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:53 --> Input Class Initialized
INFO - 2019-09-10 16:42:53 --> Language Class Initialized
INFO - 2019-09-10 16:42:53 --> Loader Class Initialized
INFO - 2019-09-10 16:42:53 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:53 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:53 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:53 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:53 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:53 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:53 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:53 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:53 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:53 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:53 --> Controller Class Initialized
INFO - 2019-09-10 16:42:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:42:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-10 16:42:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-10 16:42:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:42:53 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:53 --> Total execution time: 0.0702
INFO - 2019-09-10 16:42:53 --> Config Class Initialized
INFO - 2019-09-10 16:42:53 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:53 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:53 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:53 --> URI Class Initialized
INFO - 2019-09-10 16:42:53 --> Router Class Initialized
INFO - 2019-09-10 16:42:53 --> Output Class Initialized
INFO - 2019-09-10 16:42:53 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:53 --> Input Class Initialized
INFO - 2019-09-10 16:42:53 --> Language Class Initialized
INFO - 2019-09-10 16:42:53 --> Loader Class Initialized
INFO - 2019-09-10 16:42:53 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:53 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:53 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:53 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:53 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:53 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:53 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:53 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:53 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:53 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:53 --> Controller Class Initialized
INFO - 2019-09-10 16:42:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:42:53 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:53 --> Total execution time: 0.0596
INFO - 2019-09-10 16:42:53 --> Config Class Initialized
INFO - 2019-09-10 16:42:53 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:53 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:53 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:53 --> URI Class Initialized
INFO - 2019-09-10 16:42:53 --> Router Class Initialized
INFO - 2019-09-10 16:42:53 --> Output Class Initialized
INFO - 2019-09-10 16:42:53 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:53 --> Input Class Initialized
INFO - 2019-09-10 16:42:53 --> Language Class Initialized
INFO - 2019-09-10 16:42:53 --> Loader Class Initialized
INFO - 2019-09-10 16:42:53 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:53 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:53 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:53 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:53 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:53 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:53 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:53 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:53 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:53 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:53 --> Controller Class Initialized
INFO - 2019-09-10 16:42:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:42:53 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:53 --> Total execution time: 0.0794
INFO - 2019-09-10 16:42:54 --> Config Class Initialized
INFO - 2019-09-10 16:42:54 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:54 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:54 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:54 --> URI Class Initialized
INFO - 2019-09-10 16:42:54 --> Router Class Initialized
INFO - 2019-09-10 16:42:54 --> Output Class Initialized
INFO - 2019-09-10 16:42:54 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:54 --> Input Class Initialized
INFO - 2019-09-10 16:42:54 --> Language Class Initialized
INFO - 2019-09-10 16:42:54 --> Loader Class Initialized
INFO - 2019-09-10 16:42:54 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:54 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:54 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:54 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:54 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:54 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:54 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:54 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:54 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:54 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:54 --> Controller Class Initialized
INFO - 2019-09-10 16:42:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:42:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-10 16:42:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-10 16:42:54 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:42:54 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:54 --> Total execution time: 0.0624
INFO - 2019-09-10 16:42:54 --> Config Class Initialized
INFO - 2019-09-10 16:42:54 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:54 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:54 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:54 --> URI Class Initialized
INFO - 2019-09-10 16:42:54 --> Router Class Initialized
INFO - 2019-09-10 16:42:54 --> Output Class Initialized
INFO - 2019-09-10 16:42:54 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:54 --> Input Class Initialized
INFO - 2019-09-10 16:42:54 --> Language Class Initialized
INFO - 2019-09-10 16:42:54 --> Loader Class Initialized
INFO - 2019-09-10 16:42:54 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:54 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:54 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:54 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:54 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:54 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:54 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:55 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:55 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:55 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:55 --> Controller Class Initialized
INFO - 2019-09-10 16:42:55 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:42:55 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:55 --> Total execution time: 0.0554
INFO - 2019-09-10 16:42:55 --> Config Class Initialized
INFO - 2019-09-10 16:42:55 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:42:55 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:42:55 --> Utf8 Class Initialized
INFO - 2019-09-10 16:42:55 --> URI Class Initialized
INFO - 2019-09-10 16:42:55 --> Router Class Initialized
INFO - 2019-09-10 16:42:55 --> Output Class Initialized
INFO - 2019-09-10 16:42:55 --> Security Class Initialized
DEBUG - 2019-09-10 16:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:42:55 --> Input Class Initialized
INFO - 2019-09-10 16:42:55 --> Language Class Initialized
INFO - 2019-09-10 16:42:55 --> Loader Class Initialized
INFO - 2019-09-10 16:42:55 --> Helper loaded: url_helper
INFO - 2019-09-10 16:42:55 --> Helper loaded: html_helper
INFO - 2019-09-10 16:42:55 --> Helper loaded: form_helper
INFO - 2019-09-10 16:42:55 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:42:55 --> Helper loaded: date_helper
INFO - 2019-09-10 16:42:55 --> Form Validation Class Initialized
INFO - 2019-09-10 16:42:55 --> Email Class Initialized
DEBUG - 2019-09-10 16:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:42:55 --> Pagination Class Initialized
INFO - 2019-09-10 16:42:55 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:55 --> Database Driver Class Initialized
INFO - 2019-09-10 16:42:55 --> Controller Class Initialized
INFO - 2019-09-10 16:42:55 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:42:55 --> Final output sent to browser
DEBUG - 2019-09-10 16:42:55 --> Total execution time: 0.0503
INFO - 2019-09-10 16:43:00 --> Config Class Initialized
INFO - 2019-09-10 16:43:00 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:00 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:00 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:00 --> URI Class Initialized
INFO - 2019-09-10 16:43:00 --> Router Class Initialized
INFO - 2019-09-10 16:43:00 --> Output Class Initialized
INFO - 2019-09-10 16:43:00 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:00 --> Input Class Initialized
INFO - 2019-09-10 16:43:00 --> Language Class Initialized
INFO - 2019-09-10 16:43:00 --> Loader Class Initialized
INFO - 2019-09-10 16:43:00 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:00 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:00 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:00 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:00 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:00 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:00 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:00 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:00 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:00 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:00 --> Controller Class Initialized
ERROR - 2019-09-10 16:43:00 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:43:01 --> Config Class Initialized
INFO - 2019-09-10 16:43:01 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:01 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:01 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:01 --> URI Class Initialized
INFO - 2019-09-10 16:43:01 --> Router Class Initialized
INFO - 2019-09-10 16:43:01 --> Output Class Initialized
INFO - 2019-09-10 16:43:01 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:01 --> Input Class Initialized
INFO - 2019-09-10 16:43:01 --> Language Class Initialized
INFO - 2019-09-10 16:43:01 --> Loader Class Initialized
INFO - 2019-09-10 16:43:01 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:01 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:01 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:01 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:01 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:01 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:01 --> Controller Class Initialized
ERROR - 2019-09-10 16:43:01 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:43:01 --> Config Class Initialized
INFO - 2019-09-10 16:43:01 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:01 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:01 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:01 --> URI Class Initialized
INFO - 2019-09-10 16:43:01 --> Router Class Initialized
INFO - 2019-09-10 16:43:01 --> Output Class Initialized
INFO - 2019-09-10 16:43:01 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:01 --> Input Class Initialized
INFO - 2019-09-10 16:43:01 --> Language Class Initialized
INFO - 2019-09-10 16:43:01 --> Loader Class Initialized
INFO - 2019-09-10 16:43:01 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:01 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:01 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:01 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:01 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:01 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:01 --> Controller Class Initialized
ERROR - 2019-09-10 16:43:01 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:43:01 --> Config Class Initialized
INFO - 2019-09-10 16:43:01 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:01 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:01 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:01 --> URI Class Initialized
INFO - 2019-09-10 16:43:01 --> Router Class Initialized
INFO - 2019-09-10 16:43:01 --> Output Class Initialized
INFO - 2019-09-10 16:43:01 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:01 --> Input Class Initialized
INFO - 2019-09-10 16:43:01 --> Language Class Initialized
INFO - 2019-09-10 16:43:01 --> Loader Class Initialized
INFO - 2019-09-10 16:43:01 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:01 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:01 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:01 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:01 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:01 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:01 --> Controller Class Initialized
ERROR - 2019-09-10 16:43:01 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:43:01 --> Config Class Initialized
INFO - 2019-09-10 16:43:01 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:01 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:01 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:01 --> URI Class Initialized
INFO - 2019-09-10 16:43:01 --> Router Class Initialized
INFO - 2019-09-10 16:43:01 --> Output Class Initialized
INFO - 2019-09-10 16:43:01 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:01 --> Input Class Initialized
INFO - 2019-09-10 16:43:01 --> Language Class Initialized
INFO - 2019-09-10 16:43:01 --> Loader Class Initialized
INFO - 2019-09-10 16:43:01 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:01 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:01 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:01 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:01 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:01 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:01 --> Controller Class Initialized
ERROR - 2019-09-10 16:43:01 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:43:01 --> Config Class Initialized
INFO - 2019-09-10 16:43:01 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:01 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:01 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:01 --> URI Class Initialized
INFO - 2019-09-10 16:43:01 --> Router Class Initialized
INFO - 2019-09-10 16:43:01 --> Output Class Initialized
INFO - 2019-09-10 16:43:01 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:01 --> Input Class Initialized
INFO - 2019-09-10 16:43:01 --> Language Class Initialized
INFO - 2019-09-10 16:43:01 --> Loader Class Initialized
INFO - 2019-09-10 16:43:01 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:01 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:01 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:01 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:01 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:01 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:01 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:01 --> Controller Class Initialized
ERROR - 2019-09-10 16:43:01 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:43:02 --> Config Class Initialized
INFO - 2019-09-10 16:43:02 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:02 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:02 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:02 --> URI Class Initialized
INFO - 2019-09-10 16:43:02 --> Router Class Initialized
INFO - 2019-09-10 16:43:02 --> Output Class Initialized
INFO - 2019-09-10 16:43:02 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:02 --> Input Class Initialized
INFO - 2019-09-10 16:43:02 --> Language Class Initialized
INFO - 2019-09-10 16:43:02 --> Loader Class Initialized
INFO - 2019-09-10 16:43:02 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:02 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:02 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:02 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:02 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:02 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:02 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:02 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:02 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:02 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:02 --> Controller Class Initialized
ERROR - 2019-09-10 16:43:02 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:43:02 --> Config Class Initialized
INFO - 2019-09-10 16:43:02 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:02 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:02 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:02 --> URI Class Initialized
INFO - 2019-09-10 16:43:02 --> Router Class Initialized
INFO - 2019-09-10 16:43:02 --> Output Class Initialized
INFO - 2019-09-10 16:43:02 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:02 --> Input Class Initialized
INFO - 2019-09-10 16:43:02 --> Language Class Initialized
INFO - 2019-09-10 16:43:02 --> Loader Class Initialized
INFO - 2019-09-10 16:43:02 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:02 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:02 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:02 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:02 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:02 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:02 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:02 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:02 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:02 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:02 --> Controller Class Initialized
ERROR - 2019-09-10 16:43:02 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:43:02 --> Config Class Initialized
INFO - 2019-09-10 16:43:02 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:02 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:02 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:02 --> URI Class Initialized
INFO - 2019-09-10 16:43:02 --> Router Class Initialized
INFO - 2019-09-10 16:43:02 --> Output Class Initialized
INFO - 2019-09-10 16:43:02 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:02 --> Input Class Initialized
INFO - 2019-09-10 16:43:02 --> Language Class Initialized
INFO - 2019-09-10 16:43:02 --> Loader Class Initialized
INFO - 2019-09-10 16:43:02 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:02 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:02 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:02 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:02 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:02 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:02 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:02 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:02 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:02 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:02 --> Controller Class Initialized
ERROR - 2019-09-10 16:43:02 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:43:03 --> Config Class Initialized
INFO - 2019-09-10 16:43:03 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:03 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:03 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:03 --> URI Class Initialized
INFO - 2019-09-10 16:43:03 --> Router Class Initialized
INFO - 2019-09-10 16:43:03 --> Output Class Initialized
INFO - 2019-09-10 16:43:03 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:03 --> Input Class Initialized
INFO - 2019-09-10 16:43:03 --> Language Class Initialized
INFO - 2019-09-10 16:43:03 --> Loader Class Initialized
INFO - 2019-09-10 16:43:03 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:03 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:03 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:03 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:03 --> Controller Class Initialized
ERROR - 2019-09-10 16:43:03 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:43:03 --> Config Class Initialized
INFO - 2019-09-10 16:43:03 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:03 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:03 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:03 --> URI Class Initialized
INFO - 2019-09-10 16:43:03 --> Router Class Initialized
INFO - 2019-09-10 16:43:03 --> Output Class Initialized
INFO - 2019-09-10 16:43:03 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:03 --> Input Class Initialized
INFO - 2019-09-10 16:43:03 --> Language Class Initialized
INFO - 2019-09-10 16:43:03 --> Loader Class Initialized
INFO - 2019-09-10 16:43:03 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:03 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:03 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:03 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:03 --> Controller Class Initialized
ERROR - 2019-09-10 16:43:03 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:43:03 --> Config Class Initialized
INFO - 2019-09-10 16:43:03 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:03 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:03 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:03 --> URI Class Initialized
INFO - 2019-09-10 16:43:03 --> Router Class Initialized
INFO - 2019-09-10 16:43:03 --> Output Class Initialized
INFO - 2019-09-10 16:43:03 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:03 --> Input Class Initialized
INFO - 2019-09-10 16:43:03 --> Language Class Initialized
INFO - 2019-09-10 16:43:03 --> Loader Class Initialized
INFO - 2019-09-10 16:43:03 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:03 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:03 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:03 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:03 --> Controller Class Initialized
ERROR - 2019-09-10 16:43:03 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:43:03 --> Config Class Initialized
INFO - 2019-09-10 16:43:03 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:03 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:03 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:03 --> URI Class Initialized
INFO - 2019-09-10 16:43:03 --> Router Class Initialized
INFO - 2019-09-10 16:43:03 --> Output Class Initialized
INFO - 2019-09-10 16:43:03 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:03 --> Input Class Initialized
INFO - 2019-09-10 16:43:03 --> Language Class Initialized
INFO - 2019-09-10 16:43:03 --> Loader Class Initialized
INFO - 2019-09-10 16:43:03 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:03 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:03 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:03 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:03 --> Controller Class Initialized
ERROR - 2019-09-10 16:43:03 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:43:03 --> Config Class Initialized
INFO - 2019-09-10 16:43:03 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:03 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:03 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:03 --> URI Class Initialized
INFO - 2019-09-10 16:43:03 --> Router Class Initialized
INFO - 2019-09-10 16:43:03 --> Output Class Initialized
INFO - 2019-09-10 16:43:03 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:03 --> Input Class Initialized
INFO - 2019-09-10 16:43:03 --> Language Class Initialized
INFO - 2019-09-10 16:43:03 --> Loader Class Initialized
INFO - 2019-09-10 16:43:03 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:03 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:03 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:03 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:03 --> Controller Class Initialized
ERROR - 2019-09-10 16:43:03 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:43:03 --> Config Class Initialized
INFO - 2019-09-10 16:43:03 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:03 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:03 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:03 --> URI Class Initialized
INFO - 2019-09-10 16:43:03 --> Router Class Initialized
INFO - 2019-09-10 16:43:03 --> Output Class Initialized
INFO - 2019-09-10 16:43:03 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:03 --> Input Class Initialized
INFO - 2019-09-10 16:43:03 --> Language Class Initialized
INFO - 2019-09-10 16:43:03 --> Loader Class Initialized
INFO - 2019-09-10 16:43:03 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:03 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:03 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:03 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:03 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:03 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:03 --> Controller Class Initialized
ERROR - 2019-09-10 16:43:03 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:43:04 --> Config Class Initialized
INFO - 2019-09-10 16:43:04 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:04 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:04 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:04 --> URI Class Initialized
INFO - 2019-09-10 16:43:04 --> Router Class Initialized
INFO - 2019-09-10 16:43:04 --> Output Class Initialized
INFO - 2019-09-10 16:43:04 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:04 --> Input Class Initialized
INFO - 2019-09-10 16:43:04 --> Language Class Initialized
INFO - 2019-09-10 16:43:04 --> Loader Class Initialized
INFO - 2019-09-10 16:43:04 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:04 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:04 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:04 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:04 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:04 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:04 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:04 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:04 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:04 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:04 --> Controller Class Initialized
ERROR - 2019-09-10 16:43:04 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:43:11 --> Config Class Initialized
INFO - 2019-09-10 16:43:11 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:11 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:11 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:11 --> URI Class Initialized
INFO - 2019-09-10 16:43:11 --> Router Class Initialized
INFO - 2019-09-10 16:43:11 --> Output Class Initialized
INFO - 2019-09-10 16:43:11 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:11 --> Input Class Initialized
INFO - 2019-09-10 16:43:11 --> Language Class Initialized
INFO - 2019-09-10 16:43:11 --> Loader Class Initialized
INFO - 2019-09-10 16:43:11 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:11 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:11 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:11 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:11 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:11 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:11 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:11 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:11 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:11 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:11 --> Controller Class Initialized
INFO - 2019-09-10 16:43:11 --> Final output sent to browser
DEBUG - 2019-09-10 16:43:11 --> Total execution time: 0.0825
INFO - 2019-09-10 16:43:15 --> Config Class Initialized
INFO - 2019-09-10 16:43:15 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:15 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:15 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:15 --> URI Class Initialized
INFO - 2019-09-10 16:43:15 --> Router Class Initialized
INFO - 2019-09-10 16:43:15 --> Output Class Initialized
INFO - 2019-09-10 16:43:15 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:15 --> Input Class Initialized
INFO - 2019-09-10 16:43:15 --> Language Class Initialized
INFO - 2019-09-10 16:43:15 --> Loader Class Initialized
INFO - 2019-09-10 16:43:15 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:15 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:15 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:15 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:15 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:15 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:15 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:15 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:15 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:15 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:15 --> Controller Class Initialized
INFO - 2019-09-10 16:43:15 --> Final output sent to browser
DEBUG - 2019-09-10 16:43:15 --> Total execution time: 0.1242
INFO - 2019-09-10 16:43:18 --> Config Class Initialized
INFO - 2019-09-10 16:43:18 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:18 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:18 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:18 --> URI Class Initialized
INFO - 2019-09-10 16:43:18 --> Router Class Initialized
INFO - 2019-09-10 16:43:18 --> Output Class Initialized
INFO - 2019-09-10 16:43:18 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:18 --> Input Class Initialized
INFO - 2019-09-10 16:43:18 --> Language Class Initialized
INFO - 2019-09-10 16:43:18 --> Loader Class Initialized
INFO - 2019-09-10 16:43:18 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:18 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:18 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:18 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:18 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:18 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:18 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:18 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:18 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:18 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:18 --> Controller Class Initialized
INFO - 2019-09-10 16:43:18 --> Final output sent to browser
DEBUG - 2019-09-10 16:43:18 --> Total execution time: 0.0479
INFO - 2019-09-10 16:43:32 --> Config Class Initialized
INFO - 2019-09-10 16:43:32 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:43:32 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:43:32 --> Utf8 Class Initialized
INFO - 2019-09-10 16:43:32 --> URI Class Initialized
INFO - 2019-09-10 16:43:32 --> Router Class Initialized
INFO - 2019-09-10 16:43:32 --> Output Class Initialized
INFO - 2019-09-10 16:43:32 --> Security Class Initialized
DEBUG - 2019-09-10 16:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:43:32 --> Input Class Initialized
INFO - 2019-09-10 16:43:32 --> Language Class Initialized
INFO - 2019-09-10 16:43:32 --> Loader Class Initialized
INFO - 2019-09-10 16:43:32 --> Helper loaded: url_helper
INFO - 2019-09-10 16:43:32 --> Helper loaded: html_helper
INFO - 2019-09-10 16:43:32 --> Helper loaded: form_helper
INFO - 2019-09-10 16:43:32 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:43:32 --> Helper loaded: date_helper
INFO - 2019-09-10 16:43:32 --> Form Validation Class Initialized
INFO - 2019-09-10 16:43:32 --> Email Class Initialized
DEBUG - 2019-09-10 16:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:43:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:43:32 --> Pagination Class Initialized
INFO - 2019-09-10 16:43:32 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:32 --> Database Driver Class Initialized
INFO - 2019-09-10 16:43:32 --> Controller Class Initialized
INFO - 2019-09-10 16:43:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 16:44:42 --> Config Class Initialized
INFO - 2019-09-10 16:44:42 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:44:42 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:44:42 --> Utf8 Class Initialized
INFO - 2019-09-10 16:44:42 --> URI Class Initialized
INFO - 2019-09-10 16:44:42 --> Router Class Initialized
INFO - 2019-09-10 16:44:42 --> Output Class Initialized
INFO - 2019-09-10 16:44:42 --> Security Class Initialized
DEBUG - 2019-09-10 16:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:44:42 --> Input Class Initialized
INFO - 2019-09-10 16:44:42 --> Language Class Initialized
INFO - 2019-09-10 16:44:42 --> Loader Class Initialized
INFO - 2019-09-10 16:44:42 --> Helper loaded: url_helper
INFO - 2019-09-10 16:44:42 --> Helper loaded: html_helper
INFO - 2019-09-10 16:44:42 --> Helper loaded: form_helper
INFO - 2019-09-10 16:44:42 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:44:42 --> Helper loaded: date_helper
INFO - 2019-09-10 16:44:42 --> Form Validation Class Initialized
INFO - 2019-09-10 16:44:42 --> Email Class Initialized
DEBUG - 2019-09-10 16:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:44:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:44:42 --> Pagination Class Initialized
INFO - 2019-09-10 16:44:42 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:42 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:42 --> Controller Class Initialized
INFO - 2019-09-10 16:44:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:44:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-10 16:44:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-10 16:44:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:44:42 --> Final output sent to browser
DEBUG - 2019-09-10 16:44:42 --> Total execution time: 0.0636
INFO - 2019-09-10 16:44:42 --> Config Class Initialized
INFO - 2019-09-10 16:44:42 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:44:42 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:44:42 --> Utf8 Class Initialized
INFO - 2019-09-10 16:44:42 --> URI Class Initialized
INFO - 2019-09-10 16:44:42 --> Router Class Initialized
INFO - 2019-09-10 16:44:42 --> Output Class Initialized
INFO - 2019-09-10 16:44:42 --> Security Class Initialized
DEBUG - 2019-09-10 16:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:44:42 --> Input Class Initialized
INFO - 2019-09-10 16:44:42 --> Language Class Initialized
INFO - 2019-09-10 16:44:42 --> Loader Class Initialized
INFO - 2019-09-10 16:44:42 --> Helper loaded: url_helper
INFO - 2019-09-10 16:44:42 --> Helper loaded: html_helper
INFO - 2019-09-10 16:44:42 --> Helper loaded: form_helper
INFO - 2019-09-10 16:44:42 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:44:42 --> Helper loaded: date_helper
INFO - 2019-09-10 16:44:42 --> Form Validation Class Initialized
INFO - 2019-09-10 16:44:42 --> Email Class Initialized
DEBUG - 2019-09-10 16:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:44:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:44:42 --> Pagination Class Initialized
INFO - 2019-09-10 16:44:42 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:42 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:42 --> Controller Class Initialized
INFO - 2019-09-10 16:44:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:44:42 --> Final output sent to browser
DEBUG - 2019-09-10 16:44:42 --> Total execution time: 0.0697
INFO - 2019-09-10 16:44:42 --> Config Class Initialized
INFO - 2019-09-10 16:44:42 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:44:42 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:44:42 --> Utf8 Class Initialized
INFO - 2019-09-10 16:44:42 --> URI Class Initialized
INFO - 2019-09-10 16:44:42 --> Router Class Initialized
INFO - 2019-09-10 16:44:42 --> Output Class Initialized
INFO - 2019-09-10 16:44:42 --> Security Class Initialized
DEBUG - 2019-09-10 16:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:44:42 --> Input Class Initialized
INFO - 2019-09-10 16:44:42 --> Language Class Initialized
INFO - 2019-09-10 16:44:42 --> Loader Class Initialized
INFO - 2019-09-10 16:44:42 --> Helper loaded: url_helper
INFO - 2019-09-10 16:44:42 --> Helper loaded: html_helper
INFO - 2019-09-10 16:44:42 --> Helper loaded: form_helper
INFO - 2019-09-10 16:44:42 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:44:42 --> Helper loaded: date_helper
INFO - 2019-09-10 16:44:42 --> Form Validation Class Initialized
INFO - 2019-09-10 16:44:42 --> Email Class Initialized
DEBUG - 2019-09-10 16:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:44:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:44:42 --> Pagination Class Initialized
INFO - 2019-09-10 16:44:42 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:42 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:42 --> Controller Class Initialized
INFO - 2019-09-10 16:44:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:44:42 --> Final output sent to browser
DEBUG - 2019-09-10 16:44:42 --> Total execution time: 0.0716
INFO - 2019-09-10 16:44:43 --> Config Class Initialized
INFO - 2019-09-10 16:44:43 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:44:43 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:44:43 --> Utf8 Class Initialized
INFO - 2019-09-10 16:44:43 --> URI Class Initialized
INFO - 2019-09-10 16:44:43 --> Router Class Initialized
INFO - 2019-09-10 16:44:43 --> Output Class Initialized
INFO - 2019-09-10 16:44:43 --> Security Class Initialized
DEBUG - 2019-09-10 16:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:44:43 --> Input Class Initialized
INFO - 2019-09-10 16:44:43 --> Language Class Initialized
INFO - 2019-09-10 16:44:43 --> Loader Class Initialized
INFO - 2019-09-10 16:44:43 --> Helper loaded: url_helper
INFO - 2019-09-10 16:44:43 --> Helper loaded: html_helper
INFO - 2019-09-10 16:44:43 --> Helper loaded: form_helper
INFO - 2019-09-10 16:44:43 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:44:43 --> Helper loaded: date_helper
INFO - 2019-09-10 16:44:43 --> Form Validation Class Initialized
INFO - 2019-09-10 16:44:43 --> Email Class Initialized
DEBUG - 2019-09-10 16:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:44:43 --> Pagination Class Initialized
INFO - 2019-09-10 16:44:43 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:43 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:43 --> Controller Class Initialized
INFO - 2019-09-10 16:44:43 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:44:43 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-10 16:44:43 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-10 16:44:43 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:44:43 --> Final output sent to browser
DEBUG - 2019-09-10 16:44:43 --> Total execution time: 0.0702
INFO - 2019-09-10 16:44:43 --> Config Class Initialized
INFO - 2019-09-10 16:44:43 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:44:43 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:44:43 --> Utf8 Class Initialized
INFO - 2019-09-10 16:44:43 --> URI Class Initialized
INFO - 2019-09-10 16:44:43 --> Router Class Initialized
INFO - 2019-09-10 16:44:43 --> Output Class Initialized
INFO - 2019-09-10 16:44:43 --> Security Class Initialized
DEBUG - 2019-09-10 16:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:44:43 --> Input Class Initialized
INFO - 2019-09-10 16:44:43 --> Language Class Initialized
INFO - 2019-09-10 16:44:43 --> Loader Class Initialized
INFO - 2019-09-10 16:44:43 --> Helper loaded: url_helper
INFO - 2019-09-10 16:44:43 --> Helper loaded: html_helper
INFO - 2019-09-10 16:44:43 --> Helper loaded: form_helper
INFO - 2019-09-10 16:44:43 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:44:43 --> Helper loaded: date_helper
INFO - 2019-09-10 16:44:43 --> Form Validation Class Initialized
INFO - 2019-09-10 16:44:43 --> Email Class Initialized
DEBUG - 2019-09-10 16:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:44:43 --> Pagination Class Initialized
INFO - 2019-09-10 16:44:43 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:43 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:43 --> Controller Class Initialized
INFO - 2019-09-10 16:44:43 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:44:43 --> Final output sent to browser
DEBUG - 2019-09-10 16:44:43 --> Total execution time: 0.0622
INFO - 2019-09-10 16:44:43 --> Config Class Initialized
INFO - 2019-09-10 16:44:43 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:44:43 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:44:43 --> Utf8 Class Initialized
INFO - 2019-09-10 16:44:43 --> URI Class Initialized
INFO - 2019-09-10 16:44:43 --> Router Class Initialized
INFO - 2019-09-10 16:44:43 --> Output Class Initialized
INFO - 2019-09-10 16:44:43 --> Security Class Initialized
DEBUG - 2019-09-10 16:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:44:43 --> Input Class Initialized
INFO - 2019-09-10 16:44:43 --> Language Class Initialized
INFO - 2019-09-10 16:44:43 --> Loader Class Initialized
INFO - 2019-09-10 16:44:43 --> Helper loaded: url_helper
INFO - 2019-09-10 16:44:43 --> Helper loaded: html_helper
INFO - 2019-09-10 16:44:43 --> Helper loaded: form_helper
INFO - 2019-09-10 16:44:43 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:44:43 --> Helper loaded: date_helper
INFO - 2019-09-10 16:44:43 --> Form Validation Class Initialized
INFO - 2019-09-10 16:44:43 --> Email Class Initialized
DEBUG - 2019-09-10 16:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:44:43 --> Pagination Class Initialized
INFO - 2019-09-10 16:44:43 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:43 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:43 --> Controller Class Initialized
INFO - 2019-09-10 16:44:43 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:44:43 --> Final output sent to browser
DEBUG - 2019-09-10 16:44:43 --> Total execution time: 0.0722
INFO - 2019-09-10 16:44:45 --> Config Class Initialized
INFO - 2019-09-10 16:44:45 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:44:45 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:44:45 --> Utf8 Class Initialized
INFO - 2019-09-10 16:44:45 --> URI Class Initialized
INFO - 2019-09-10 16:44:45 --> Router Class Initialized
INFO - 2019-09-10 16:44:45 --> Output Class Initialized
INFO - 2019-09-10 16:44:45 --> Security Class Initialized
DEBUG - 2019-09-10 16:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:44:45 --> Input Class Initialized
INFO - 2019-09-10 16:44:45 --> Language Class Initialized
INFO - 2019-09-10 16:44:45 --> Loader Class Initialized
INFO - 2019-09-10 16:44:45 --> Helper loaded: url_helper
INFO - 2019-09-10 16:44:45 --> Helper loaded: html_helper
INFO - 2019-09-10 16:44:45 --> Helper loaded: form_helper
INFO - 2019-09-10 16:44:45 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:44:45 --> Helper loaded: date_helper
INFO - 2019-09-10 16:44:45 --> Form Validation Class Initialized
INFO - 2019-09-10 16:44:45 --> Email Class Initialized
DEBUG - 2019-09-10 16:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:44:45 --> Pagination Class Initialized
INFO - 2019-09-10 16:44:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:45 --> Controller Class Initialized
INFO - 2019-09-10 16:44:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:44:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-10 16:44:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-10 16:44:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:44:45 --> Final output sent to browser
DEBUG - 2019-09-10 16:44:45 --> Total execution time: 0.0657
INFO - 2019-09-10 16:44:45 --> Config Class Initialized
INFO - 2019-09-10 16:44:45 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:44:45 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:44:45 --> Utf8 Class Initialized
INFO - 2019-09-10 16:44:45 --> URI Class Initialized
INFO - 2019-09-10 16:44:45 --> Router Class Initialized
INFO - 2019-09-10 16:44:45 --> Output Class Initialized
INFO - 2019-09-10 16:44:45 --> Security Class Initialized
DEBUG - 2019-09-10 16:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:44:45 --> Input Class Initialized
INFO - 2019-09-10 16:44:45 --> Language Class Initialized
INFO - 2019-09-10 16:44:45 --> Loader Class Initialized
INFO - 2019-09-10 16:44:45 --> Helper loaded: url_helper
INFO - 2019-09-10 16:44:45 --> Helper loaded: html_helper
INFO - 2019-09-10 16:44:45 --> Helper loaded: form_helper
INFO - 2019-09-10 16:44:45 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:44:45 --> Helper loaded: date_helper
INFO - 2019-09-10 16:44:45 --> Form Validation Class Initialized
INFO - 2019-09-10 16:44:45 --> Email Class Initialized
DEBUG - 2019-09-10 16:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:44:45 --> Pagination Class Initialized
INFO - 2019-09-10 16:44:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:45 --> Controller Class Initialized
INFO - 2019-09-10 16:44:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:44:45 --> Final output sent to browser
DEBUG - 2019-09-10 16:44:45 --> Total execution time: 0.0548
INFO - 2019-09-10 16:44:45 --> Config Class Initialized
INFO - 2019-09-10 16:44:45 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:44:45 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:44:45 --> Utf8 Class Initialized
INFO - 2019-09-10 16:44:45 --> URI Class Initialized
INFO - 2019-09-10 16:44:45 --> Router Class Initialized
INFO - 2019-09-10 16:44:45 --> Output Class Initialized
INFO - 2019-09-10 16:44:45 --> Security Class Initialized
DEBUG - 2019-09-10 16:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:44:45 --> Input Class Initialized
INFO - 2019-09-10 16:44:45 --> Language Class Initialized
INFO - 2019-09-10 16:44:45 --> Loader Class Initialized
INFO - 2019-09-10 16:44:45 --> Helper loaded: url_helper
INFO - 2019-09-10 16:44:45 --> Helper loaded: html_helper
INFO - 2019-09-10 16:44:45 --> Helper loaded: form_helper
INFO - 2019-09-10 16:44:45 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:44:45 --> Helper loaded: date_helper
INFO - 2019-09-10 16:44:45 --> Form Validation Class Initialized
INFO - 2019-09-10 16:44:45 --> Email Class Initialized
DEBUG - 2019-09-10 16:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:44:45 --> Pagination Class Initialized
INFO - 2019-09-10 16:44:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:45 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:45 --> Controller Class Initialized
INFO - 2019-09-10 16:44:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:44:45 --> Final output sent to browser
DEBUG - 2019-09-10 16:44:45 --> Total execution time: 0.0686
INFO - 2019-09-10 16:44:49 --> Config Class Initialized
INFO - 2019-09-10 16:44:49 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:44:49 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:44:49 --> Utf8 Class Initialized
INFO - 2019-09-10 16:44:49 --> URI Class Initialized
INFO - 2019-09-10 16:44:49 --> Router Class Initialized
INFO - 2019-09-10 16:44:49 --> Output Class Initialized
INFO - 2019-09-10 16:44:49 --> Security Class Initialized
DEBUG - 2019-09-10 16:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:44:49 --> Input Class Initialized
INFO - 2019-09-10 16:44:49 --> Language Class Initialized
INFO - 2019-09-10 16:44:49 --> Loader Class Initialized
INFO - 2019-09-10 16:44:49 --> Helper loaded: url_helper
INFO - 2019-09-10 16:44:49 --> Helper loaded: html_helper
INFO - 2019-09-10 16:44:49 --> Helper loaded: form_helper
INFO - 2019-09-10 16:44:49 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:44:49 --> Helper loaded: date_helper
INFO - 2019-09-10 16:44:49 --> Form Validation Class Initialized
INFO - 2019-09-10 16:44:49 --> Email Class Initialized
DEBUG - 2019-09-10 16:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:44:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:44:49 --> Pagination Class Initialized
INFO - 2019-09-10 16:44:49 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:49 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:49 --> Controller Class Initialized
ERROR - 2019-09-10 16:44:49 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:44:49 --> Config Class Initialized
INFO - 2019-09-10 16:44:49 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:44:49 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:44:49 --> Utf8 Class Initialized
INFO - 2019-09-10 16:44:49 --> URI Class Initialized
INFO - 2019-09-10 16:44:49 --> Router Class Initialized
INFO - 2019-09-10 16:44:49 --> Output Class Initialized
INFO - 2019-09-10 16:44:49 --> Security Class Initialized
DEBUG - 2019-09-10 16:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:44:49 --> Input Class Initialized
INFO - 2019-09-10 16:44:49 --> Language Class Initialized
INFO - 2019-09-10 16:44:49 --> Loader Class Initialized
INFO - 2019-09-10 16:44:49 --> Helper loaded: url_helper
INFO - 2019-09-10 16:44:49 --> Helper loaded: html_helper
INFO - 2019-09-10 16:44:49 --> Helper loaded: form_helper
INFO - 2019-09-10 16:44:49 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:44:49 --> Helper loaded: date_helper
INFO - 2019-09-10 16:44:49 --> Form Validation Class Initialized
INFO - 2019-09-10 16:44:49 --> Email Class Initialized
DEBUG - 2019-09-10 16:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:44:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:44:49 --> Pagination Class Initialized
INFO - 2019-09-10 16:44:49 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:49 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:49 --> Controller Class Initialized
ERROR - 2019-09-10 16:44:49 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:44:49 --> Config Class Initialized
INFO - 2019-09-10 16:44:49 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:44:49 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:44:49 --> Utf8 Class Initialized
INFO - 2019-09-10 16:44:49 --> URI Class Initialized
INFO - 2019-09-10 16:44:49 --> Router Class Initialized
INFO - 2019-09-10 16:44:49 --> Output Class Initialized
INFO - 2019-09-10 16:44:49 --> Security Class Initialized
DEBUG - 2019-09-10 16:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:44:49 --> Input Class Initialized
INFO - 2019-09-10 16:44:49 --> Language Class Initialized
INFO - 2019-09-10 16:44:49 --> Loader Class Initialized
INFO - 2019-09-10 16:44:49 --> Helper loaded: url_helper
INFO - 2019-09-10 16:44:49 --> Helper loaded: html_helper
INFO - 2019-09-10 16:44:49 --> Helper loaded: form_helper
INFO - 2019-09-10 16:44:49 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:44:49 --> Helper loaded: date_helper
INFO - 2019-09-10 16:44:49 --> Form Validation Class Initialized
INFO - 2019-09-10 16:44:49 --> Email Class Initialized
DEBUG - 2019-09-10 16:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:44:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:44:49 --> Pagination Class Initialized
INFO - 2019-09-10 16:44:49 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:49 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:49 --> Controller Class Initialized
ERROR - 2019-09-10 16:44:49 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:44:49 --> Config Class Initialized
INFO - 2019-09-10 16:44:49 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:44:49 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:44:49 --> Utf8 Class Initialized
INFO - 2019-09-10 16:44:49 --> URI Class Initialized
INFO - 2019-09-10 16:44:49 --> Router Class Initialized
INFO - 2019-09-10 16:44:49 --> Output Class Initialized
INFO - 2019-09-10 16:44:49 --> Security Class Initialized
DEBUG - 2019-09-10 16:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:44:49 --> Input Class Initialized
INFO - 2019-09-10 16:44:49 --> Language Class Initialized
INFO - 2019-09-10 16:44:49 --> Loader Class Initialized
INFO - 2019-09-10 16:44:49 --> Helper loaded: url_helper
INFO - 2019-09-10 16:44:49 --> Helper loaded: html_helper
INFO - 2019-09-10 16:44:49 --> Helper loaded: form_helper
INFO - 2019-09-10 16:44:49 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:44:49 --> Helper loaded: date_helper
INFO - 2019-09-10 16:44:49 --> Form Validation Class Initialized
INFO - 2019-09-10 16:44:49 --> Email Class Initialized
DEBUG - 2019-09-10 16:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:44:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:44:49 --> Pagination Class Initialized
INFO - 2019-09-10 16:44:49 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:49 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:49 --> Controller Class Initialized
ERROR - 2019-09-10 16:44:49 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:44:50 --> Config Class Initialized
INFO - 2019-09-10 16:44:50 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:44:50 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:44:50 --> Utf8 Class Initialized
INFO - 2019-09-10 16:44:50 --> URI Class Initialized
INFO - 2019-09-10 16:44:50 --> Router Class Initialized
INFO - 2019-09-10 16:44:50 --> Output Class Initialized
INFO - 2019-09-10 16:44:50 --> Security Class Initialized
DEBUG - 2019-09-10 16:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:44:50 --> Input Class Initialized
INFO - 2019-09-10 16:44:50 --> Language Class Initialized
INFO - 2019-09-10 16:44:50 --> Loader Class Initialized
INFO - 2019-09-10 16:44:50 --> Helper loaded: url_helper
INFO - 2019-09-10 16:44:50 --> Helper loaded: html_helper
INFO - 2019-09-10 16:44:50 --> Helper loaded: form_helper
INFO - 2019-09-10 16:44:50 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:44:50 --> Helper loaded: date_helper
INFO - 2019-09-10 16:44:50 --> Form Validation Class Initialized
INFO - 2019-09-10 16:44:50 --> Email Class Initialized
DEBUG - 2019-09-10 16:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:44:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:44:50 --> Pagination Class Initialized
INFO - 2019-09-10 16:44:50 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:50 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:50 --> Controller Class Initialized
ERROR - 2019-09-10 16:44:50 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:44:50 --> Config Class Initialized
INFO - 2019-09-10 16:44:50 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:44:50 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:44:50 --> Utf8 Class Initialized
INFO - 2019-09-10 16:44:50 --> URI Class Initialized
INFO - 2019-09-10 16:44:50 --> Router Class Initialized
INFO - 2019-09-10 16:44:50 --> Output Class Initialized
INFO - 2019-09-10 16:44:50 --> Security Class Initialized
DEBUG - 2019-09-10 16:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:44:50 --> Input Class Initialized
INFO - 2019-09-10 16:44:50 --> Language Class Initialized
INFO - 2019-09-10 16:44:50 --> Loader Class Initialized
INFO - 2019-09-10 16:44:50 --> Helper loaded: url_helper
INFO - 2019-09-10 16:44:50 --> Helper loaded: html_helper
INFO - 2019-09-10 16:44:50 --> Helper loaded: form_helper
INFO - 2019-09-10 16:44:50 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:44:50 --> Helper loaded: date_helper
INFO - 2019-09-10 16:44:50 --> Form Validation Class Initialized
INFO - 2019-09-10 16:44:50 --> Email Class Initialized
DEBUG - 2019-09-10 16:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:44:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:44:50 --> Pagination Class Initialized
INFO - 2019-09-10 16:44:50 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:50 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:50 --> Controller Class Initialized
ERROR - 2019-09-10 16:44:50 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:44:52 --> Config Class Initialized
INFO - 2019-09-10 16:44:52 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:44:52 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:44:52 --> Utf8 Class Initialized
INFO - 2019-09-10 16:44:52 --> URI Class Initialized
INFO - 2019-09-10 16:44:52 --> Router Class Initialized
INFO - 2019-09-10 16:44:52 --> Output Class Initialized
INFO - 2019-09-10 16:44:52 --> Security Class Initialized
DEBUG - 2019-09-10 16:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:44:52 --> Input Class Initialized
INFO - 2019-09-10 16:44:52 --> Language Class Initialized
INFO - 2019-09-10 16:44:52 --> Loader Class Initialized
INFO - 2019-09-10 16:44:52 --> Helper loaded: url_helper
INFO - 2019-09-10 16:44:52 --> Helper loaded: html_helper
INFO - 2019-09-10 16:44:52 --> Helper loaded: form_helper
INFO - 2019-09-10 16:44:52 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:44:52 --> Helper loaded: date_helper
INFO - 2019-09-10 16:44:52 --> Form Validation Class Initialized
INFO - 2019-09-10 16:44:52 --> Email Class Initialized
DEBUG - 2019-09-10 16:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:44:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:44:52 --> Pagination Class Initialized
INFO - 2019-09-10 16:44:52 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:52 --> Database Driver Class Initialized
INFO - 2019-09-10 16:44:52 --> Controller Class Initialized
ERROR - 2019-09-10 16:44:52 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:45:02 --> Config Class Initialized
INFO - 2019-09-10 16:45:02 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:45:02 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:45:02 --> Utf8 Class Initialized
INFO - 2019-09-10 16:45:02 --> URI Class Initialized
INFO - 2019-09-10 16:45:02 --> Router Class Initialized
INFO - 2019-09-10 16:45:02 --> Output Class Initialized
INFO - 2019-09-10 16:45:02 --> Security Class Initialized
DEBUG - 2019-09-10 16:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:45:02 --> Input Class Initialized
INFO - 2019-09-10 16:45:02 --> Language Class Initialized
INFO - 2019-09-10 16:45:02 --> Loader Class Initialized
INFO - 2019-09-10 16:45:02 --> Helper loaded: url_helper
INFO - 2019-09-10 16:45:02 --> Helper loaded: html_helper
INFO - 2019-09-10 16:45:02 --> Helper loaded: form_helper
INFO - 2019-09-10 16:45:02 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:45:02 --> Helper loaded: date_helper
INFO - 2019-09-10 16:45:02 --> Form Validation Class Initialized
INFO - 2019-09-10 16:45:02 --> Email Class Initialized
DEBUG - 2019-09-10 16:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:45:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:45:02 --> Pagination Class Initialized
INFO - 2019-09-10 16:45:02 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:02 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:02 --> Controller Class Initialized
INFO - 2019-09-10 16:45:02 --> Final output sent to browser
DEBUG - 2019-09-10 16:45:02 --> Total execution time: 0.0627
INFO - 2019-09-10 16:45:05 --> Config Class Initialized
INFO - 2019-09-10 16:45:05 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:45:05 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:45:05 --> Utf8 Class Initialized
INFO - 2019-09-10 16:45:05 --> URI Class Initialized
INFO - 2019-09-10 16:45:05 --> Router Class Initialized
INFO - 2019-09-10 16:45:05 --> Output Class Initialized
INFO - 2019-09-10 16:45:05 --> Security Class Initialized
DEBUG - 2019-09-10 16:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:45:05 --> Input Class Initialized
INFO - 2019-09-10 16:45:05 --> Language Class Initialized
INFO - 2019-09-10 16:45:05 --> Loader Class Initialized
INFO - 2019-09-10 16:45:05 --> Helper loaded: url_helper
INFO - 2019-09-10 16:45:05 --> Helper loaded: html_helper
INFO - 2019-09-10 16:45:05 --> Helper loaded: form_helper
INFO - 2019-09-10 16:45:05 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:45:05 --> Helper loaded: date_helper
INFO - 2019-09-10 16:45:05 --> Form Validation Class Initialized
INFO - 2019-09-10 16:45:05 --> Email Class Initialized
DEBUG - 2019-09-10 16:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:45:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:45:05 --> Pagination Class Initialized
INFO - 2019-09-10 16:45:05 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:05 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:05 --> Controller Class Initialized
INFO - 2019-09-10 16:45:05 --> Final output sent to browser
DEBUG - 2019-09-10 16:45:05 --> Total execution time: 0.0482
INFO - 2019-09-10 16:45:09 --> Config Class Initialized
INFO - 2019-09-10 16:45:09 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:45:09 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:45:09 --> Utf8 Class Initialized
INFO - 2019-09-10 16:45:09 --> URI Class Initialized
INFO - 2019-09-10 16:45:09 --> Router Class Initialized
INFO - 2019-09-10 16:45:09 --> Output Class Initialized
INFO - 2019-09-10 16:45:09 --> Security Class Initialized
DEBUG - 2019-09-10 16:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:45:09 --> Input Class Initialized
INFO - 2019-09-10 16:45:09 --> Language Class Initialized
INFO - 2019-09-10 16:45:09 --> Loader Class Initialized
INFO - 2019-09-10 16:45:09 --> Helper loaded: url_helper
INFO - 2019-09-10 16:45:09 --> Helper loaded: html_helper
INFO - 2019-09-10 16:45:09 --> Helper loaded: form_helper
INFO - 2019-09-10 16:45:09 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:45:09 --> Helper loaded: date_helper
INFO - 2019-09-10 16:45:09 --> Form Validation Class Initialized
INFO - 2019-09-10 16:45:09 --> Email Class Initialized
DEBUG - 2019-09-10 16:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:45:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:45:09 --> Pagination Class Initialized
INFO - 2019-09-10 16:45:09 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:09 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:09 --> Controller Class Initialized
INFO - 2019-09-10 16:45:09 --> Final output sent to browser
DEBUG - 2019-09-10 16:45:09 --> Total execution time: 0.0481
INFO - 2019-09-10 16:45:21 --> Config Class Initialized
INFO - 2019-09-10 16:45:21 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:45:21 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:45:21 --> Utf8 Class Initialized
INFO - 2019-09-10 16:45:21 --> URI Class Initialized
INFO - 2019-09-10 16:45:21 --> Router Class Initialized
INFO - 2019-09-10 16:45:21 --> Output Class Initialized
INFO - 2019-09-10 16:45:21 --> Security Class Initialized
DEBUG - 2019-09-10 16:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:45:21 --> Input Class Initialized
INFO - 2019-09-10 16:45:21 --> Language Class Initialized
INFO - 2019-09-10 16:45:21 --> Loader Class Initialized
INFO - 2019-09-10 16:45:21 --> Helper loaded: url_helper
INFO - 2019-09-10 16:45:21 --> Helper loaded: html_helper
INFO - 2019-09-10 16:45:21 --> Helper loaded: form_helper
INFO - 2019-09-10 16:45:21 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:45:21 --> Helper loaded: date_helper
INFO - 2019-09-10 16:45:21 --> Form Validation Class Initialized
INFO - 2019-09-10 16:45:21 --> Email Class Initialized
DEBUG - 2019-09-10 16:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:45:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:45:21 --> Pagination Class Initialized
INFO - 2019-09-10 16:45:21 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:21 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:21 --> Controller Class Initialized
INFO - 2019-09-10 16:45:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 16:45:22 --> Config Class Initialized
INFO - 2019-09-10 16:45:22 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:45:22 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:45:22 --> Utf8 Class Initialized
INFO - 2019-09-10 16:45:22 --> URI Class Initialized
INFO - 2019-09-10 16:45:22 --> Router Class Initialized
INFO - 2019-09-10 16:45:22 --> Output Class Initialized
INFO - 2019-09-10 16:45:22 --> Security Class Initialized
DEBUG - 2019-09-10 16:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:45:22 --> Input Class Initialized
INFO - 2019-09-10 16:45:22 --> Language Class Initialized
INFO - 2019-09-10 16:45:22 --> Loader Class Initialized
INFO - 2019-09-10 16:45:22 --> Helper loaded: url_helper
INFO - 2019-09-10 16:45:22 --> Helper loaded: html_helper
INFO - 2019-09-10 16:45:22 --> Helper loaded: form_helper
INFO - 2019-09-10 16:45:22 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:45:22 --> Helper loaded: date_helper
INFO - 2019-09-10 16:45:22 --> Form Validation Class Initialized
INFO - 2019-09-10 16:45:22 --> Email Class Initialized
DEBUG - 2019-09-10 16:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:45:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:45:22 --> Pagination Class Initialized
INFO - 2019-09-10 16:45:22 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:22 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:22 --> Controller Class Initialized
INFO - 2019-09-10 16:45:22 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:45:22 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-10 16:45:22 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/checkin.php
INFO - 2019-09-10 16:45:22 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:45:22 --> Final output sent to browser
DEBUG - 2019-09-10 16:45:22 --> Total execution time: 0.0543
INFO - 2019-09-10 16:45:22 --> Config Class Initialized
INFO - 2019-09-10 16:45:22 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:45:22 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:45:22 --> Utf8 Class Initialized
INFO - 2019-09-10 16:45:22 --> URI Class Initialized
INFO - 2019-09-10 16:45:22 --> Router Class Initialized
INFO - 2019-09-10 16:45:22 --> Output Class Initialized
INFO - 2019-09-10 16:45:22 --> Security Class Initialized
DEBUG - 2019-09-10 16:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:45:22 --> Input Class Initialized
INFO - 2019-09-10 16:45:22 --> Language Class Initialized
INFO - 2019-09-10 16:45:22 --> Loader Class Initialized
INFO - 2019-09-10 16:45:22 --> Helper loaded: url_helper
INFO - 2019-09-10 16:45:22 --> Helper loaded: html_helper
INFO - 2019-09-10 16:45:22 --> Helper loaded: form_helper
INFO - 2019-09-10 16:45:22 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:45:22 --> Helper loaded: date_helper
INFO - 2019-09-10 16:45:22 --> Form Validation Class Initialized
INFO - 2019-09-10 16:45:22 --> Email Class Initialized
DEBUG - 2019-09-10 16:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:45:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:45:22 --> Pagination Class Initialized
INFO - 2019-09-10 16:45:22 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:22 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:22 --> Controller Class Initialized
INFO - 2019-09-10 16:45:22 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:45:22 --> Final output sent to browser
DEBUG - 2019-09-10 16:45:22 --> Total execution time: 0.0528
INFO - 2019-09-10 16:45:22 --> Config Class Initialized
INFO - 2019-09-10 16:45:22 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:45:22 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:45:22 --> Utf8 Class Initialized
INFO - 2019-09-10 16:45:22 --> URI Class Initialized
INFO - 2019-09-10 16:45:22 --> Router Class Initialized
INFO - 2019-09-10 16:45:22 --> Output Class Initialized
INFO - 2019-09-10 16:45:22 --> Security Class Initialized
DEBUG - 2019-09-10 16:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:45:22 --> Input Class Initialized
INFO - 2019-09-10 16:45:22 --> Language Class Initialized
INFO - 2019-09-10 16:45:22 --> Loader Class Initialized
INFO - 2019-09-10 16:45:22 --> Helper loaded: url_helper
INFO - 2019-09-10 16:45:22 --> Helper loaded: html_helper
INFO - 2019-09-10 16:45:22 --> Helper loaded: form_helper
INFO - 2019-09-10 16:45:22 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:45:22 --> Helper loaded: date_helper
INFO - 2019-09-10 16:45:22 --> Form Validation Class Initialized
INFO - 2019-09-10 16:45:22 --> Email Class Initialized
DEBUG - 2019-09-10 16:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:45:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:45:22 --> Pagination Class Initialized
INFO - 2019-09-10 16:45:22 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:22 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:22 --> Controller Class Initialized
INFO - 2019-09-10 16:45:22 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:45:22 --> Final output sent to browser
DEBUG - 2019-09-10 16:45:22 --> Total execution time: 0.0621
INFO - 2019-09-10 16:45:38 --> Config Class Initialized
INFO - 2019-09-10 16:45:38 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:45:38 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:45:38 --> Utf8 Class Initialized
INFO - 2019-09-10 16:45:38 --> URI Class Initialized
INFO - 2019-09-10 16:45:38 --> Router Class Initialized
INFO - 2019-09-10 16:45:38 --> Output Class Initialized
INFO - 2019-09-10 16:45:38 --> Security Class Initialized
DEBUG - 2019-09-10 16:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:45:38 --> Input Class Initialized
INFO - 2019-09-10 16:45:38 --> Language Class Initialized
INFO - 2019-09-10 16:45:38 --> Loader Class Initialized
INFO - 2019-09-10 16:45:38 --> Helper loaded: url_helper
INFO - 2019-09-10 16:45:38 --> Helper loaded: html_helper
INFO - 2019-09-10 16:45:38 --> Helper loaded: form_helper
INFO - 2019-09-10 16:45:38 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:45:38 --> Helper loaded: date_helper
INFO - 2019-09-10 16:45:38 --> Form Validation Class Initialized
INFO - 2019-09-10 16:45:38 --> Email Class Initialized
DEBUG - 2019-09-10 16:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:45:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:45:38 --> Pagination Class Initialized
INFO - 2019-09-10 16:45:38 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:38 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:38 --> Controller Class Initialized
INFO - 2019-09-10 16:45:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 16:45:39 --> Config Class Initialized
INFO - 2019-09-10 16:45:39 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:45:39 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:45:39 --> Utf8 Class Initialized
INFO - 2019-09-10 16:45:39 --> URI Class Initialized
INFO - 2019-09-10 16:45:39 --> Router Class Initialized
INFO - 2019-09-10 16:45:39 --> Output Class Initialized
INFO - 2019-09-10 16:45:39 --> Security Class Initialized
DEBUG - 2019-09-10 16:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:45:39 --> Input Class Initialized
INFO - 2019-09-10 16:45:39 --> Language Class Initialized
INFO - 2019-09-10 16:45:39 --> Loader Class Initialized
INFO - 2019-09-10 16:45:39 --> Helper loaded: url_helper
INFO - 2019-09-10 16:45:39 --> Helper loaded: html_helper
INFO - 2019-09-10 16:45:39 --> Helper loaded: form_helper
INFO - 2019-09-10 16:45:39 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:45:39 --> Helper loaded: date_helper
INFO - 2019-09-10 16:45:39 --> Form Validation Class Initialized
INFO - 2019-09-10 16:45:39 --> Email Class Initialized
DEBUG - 2019-09-10 16:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:45:39 --> Pagination Class Initialized
INFO - 2019-09-10 16:45:39 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:39 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:39 --> Controller Class Initialized
INFO - 2019-09-10 16:45:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:45:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-10 16:45:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/checkin.php
INFO - 2019-09-10 16:45:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:45:39 --> Final output sent to browser
DEBUG - 2019-09-10 16:45:39 --> Total execution time: 0.0651
INFO - 2019-09-10 16:45:39 --> Config Class Initialized
INFO - 2019-09-10 16:45:39 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:45:39 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:45:39 --> Utf8 Class Initialized
INFO - 2019-09-10 16:45:39 --> URI Class Initialized
INFO - 2019-09-10 16:45:39 --> Router Class Initialized
INFO - 2019-09-10 16:45:39 --> Output Class Initialized
INFO - 2019-09-10 16:45:39 --> Security Class Initialized
DEBUG - 2019-09-10 16:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:45:39 --> Input Class Initialized
INFO - 2019-09-10 16:45:39 --> Language Class Initialized
INFO - 2019-09-10 16:45:39 --> Loader Class Initialized
INFO - 2019-09-10 16:45:39 --> Helper loaded: url_helper
INFO - 2019-09-10 16:45:39 --> Helper loaded: html_helper
INFO - 2019-09-10 16:45:39 --> Helper loaded: form_helper
INFO - 2019-09-10 16:45:39 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:45:39 --> Helper loaded: date_helper
INFO - 2019-09-10 16:45:39 --> Form Validation Class Initialized
INFO - 2019-09-10 16:45:39 --> Email Class Initialized
DEBUG - 2019-09-10 16:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:45:39 --> Pagination Class Initialized
INFO - 2019-09-10 16:45:39 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:39 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:39 --> Controller Class Initialized
INFO - 2019-09-10 16:45:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:45:39 --> Final output sent to browser
DEBUG - 2019-09-10 16:45:39 --> Total execution time: 0.0548
INFO - 2019-09-10 16:45:39 --> Config Class Initialized
INFO - 2019-09-10 16:45:39 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:45:39 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:45:39 --> Utf8 Class Initialized
INFO - 2019-09-10 16:45:39 --> URI Class Initialized
INFO - 2019-09-10 16:45:39 --> Router Class Initialized
INFO - 2019-09-10 16:45:39 --> Output Class Initialized
INFO - 2019-09-10 16:45:39 --> Security Class Initialized
DEBUG - 2019-09-10 16:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:45:39 --> Input Class Initialized
INFO - 2019-09-10 16:45:39 --> Language Class Initialized
INFO - 2019-09-10 16:45:39 --> Loader Class Initialized
INFO - 2019-09-10 16:45:39 --> Helper loaded: url_helper
INFO - 2019-09-10 16:45:39 --> Helper loaded: html_helper
INFO - 2019-09-10 16:45:39 --> Helper loaded: form_helper
INFO - 2019-09-10 16:45:39 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:45:39 --> Helper loaded: date_helper
INFO - 2019-09-10 16:45:39 --> Form Validation Class Initialized
INFO - 2019-09-10 16:45:39 --> Email Class Initialized
DEBUG - 2019-09-10 16:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:45:39 --> Pagination Class Initialized
INFO - 2019-09-10 16:45:39 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:39 --> Database Driver Class Initialized
INFO - 2019-09-10 16:45:39 --> Controller Class Initialized
INFO - 2019-09-10 16:45:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:45:39 --> Final output sent to browser
DEBUG - 2019-09-10 16:45:39 --> Total execution time: 0.0595
INFO - 2019-09-10 16:50:32 --> Config Class Initialized
INFO - 2019-09-10 16:50:32 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:50:32 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:50:32 --> Utf8 Class Initialized
INFO - 2019-09-10 16:50:32 --> URI Class Initialized
INFO - 2019-09-10 16:50:32 --> Router Class Initialized
INFO - 2019-09-10 16:50:32 --> Output Class Initialized
INFO - 2019-09-10 16:50:32 --> Security Class Initialized
DEBUG - 2019-09-10 16:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:50:32 --> Input Class Initialized
INFO - 2019-09-10 16:50:32 --> Language Class Initialized
INFO - 2019-09-10 16:50:32 --> Loader Class Initialized
INFO - 2019-09-10 16:50:32 --> Helper loaded: url_helper
INFO - 2019-09-10 16:50:32 --> Helper loaded: html_helper
INFO - 2019-09-10 16:50:32 --> Helper loaded: form_helper
INFO - 2019-09-10 16:50:32 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:50:32 --> Helper loaded: date_helper
INFO - 2019-09-10 16:50:32 --> Form Validation Class Initialized
INFO - 2019-09-10 16:50:32 --> Email Class Initialized
DEBUG - 2019-09-10 16:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:50:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:50:32 --> Pagination Class Initialized
INFO - 2019-09-10 16:50:32 --> Database Driver Class Initialized
INFO - 2019-09-10 16:50:32 --> Database Driver Class Initialized
INFO - 2019-09-10 16:50:32 --> Controller Class Initialized
INFO - 2019-09-10 16:50:32 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:50:32 --> Final output sent to browser
DEBUG - 2019-09-10 16:50:32 --> Total execution time: 0.0600
INFO - 2019-09-10 16:50:48 --> Config Class Initialized
INFO - 2019-09-10 16:50:48 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:50:48 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:50:48 --> Utf8 Class Initialized
INFO - 2019-09-10 16:50:48 --> URI Class Initialized
INFO - 2019-09-10 16:50:48 --> Router Class Initialized
INFO - 2019-09-10 16:50:48 --> Output Class Initialized
INFO - 2019-09-10 16:50:48 --> Security Class Initialized
DEBUG - 2019-09-10 16:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:50:48 --> Input Class Initialized
INFO - 2019-09-10 16:50:48 --> Language Class Initialized
INFO - 2019-09-10 16:50:48 --> Loader Class Initialized
INFO - 2019-09-10 16:50:48 --> Helper loaded: url_helper
INFO - 2019-09-10 16:50:48 --> Helper loaded: html_helper
INFO - 2019-09-10 16:50:48 --> Helper loaded: form_helper
INFO - 2019-09-10 16:50:48 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:50:48 --> Helper loaded: date_helper
INFO - 2019-09-10 16:50:48 --> Form Validation Class Initialized
INFO - 2019-09-10 16:50:48 --> Email Class Initialized
DEBUG - 2019-09-10 16:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:50:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:50:48 --> Pagination Class Initialized
INFO - 2019-09-10 16:50:48 --> Database Driver Class Initialized
INFO - 2019-09-10 16:50:48 --> Database Driver Class Initialized
INFO - 2019-09-10 16:50:48 --> Controller Class Initialized
INFO - 2019-09-10 16:50:48 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:50:48 --> Final output sent to browser
DEBUG - 2019-09-10 16:50:48 --> Total execution time: 0.0551
INFO - 2019-09-10 16:58:05 --> Config Class Initialized
INFO - 2019-09-10 16:58:05 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:05 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:05 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:05 --> URI Class Initialized
INFO - 2019-09-10 16:58:05 --> Router Class Initialized
INFO - 2019-09-10 16:58:05 --> Output Class Initialized
INFO - 2019-09-10 16:58:05 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:05 --> Input Class Initialized
INFO - 2019-09-10 16:58:05 --> Language Class Initialized
INFO - 2019-09-10 16:58:05 --> Loader Class Initialized
INFO - 2019-09-10 16:58:05 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:05 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:05 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:05 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:05 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:05 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:05 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:05 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:05 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:05 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:05 --> Controller Class Initialized
INFO - 2019-09-10 16:58:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:58:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-10 16:58:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-10 16:58:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:58:05 --> Final output sent to browser
DEBUG - 2019-09-10 16:58:05 --> Total execution time: 0.0738
INFO - 2019-09-10 16:58:05 --> Config Class Initialized
INFO - 2019-09-10 16:58:05 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:05 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:05 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:05 --> URI Class Initialized
INFO - 2019-09-10 16:58:05 --> Router Class Initialized
INFO - 2019-09-10 16:58:05 --> Output Class Initialized
INFO - 2019-09-10 16:58:05 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:05 --> Input Class Initialized
INFO - 2019-09-10 16:58:05 --> Language Class Initialized
INFO - 2019-09-10 16:58:05 --> Loader Class Initialized
INFO - 2019-09-10 16:58:05 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:05 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:05 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:05 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:05 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:05 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:05 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:05 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:05 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:05 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:05 --> Controller Class Initialized
INFO - 2019-09-10 16:58:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:58:05 --> Final output sent to browser
DEBUG - 2019-09-10 16:58:05 --> Total execution time: 0.0626
INFO - 2019-09-10 16:58:05 --> Config Class Initialized
INFO - 2019-09-10 16:58:05 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:05 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:05 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:05 --> URI Class Initialized
INFO - 2019-09-10 16:58:05 --> Router Class Initialized
INFO - 2019-09-10 16:58:05 --> Output Class Initialized
INFO - 2019-09-10 16:58:05 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:05 --> Input Class Initialized
INFO - 2019-09-10 16:58:05 --> Language Class Initialized
INFO - 2019-09-10 16:58:05 --> Loader Class Initialized
INFO - 2019-09-10 16:58:05 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:05 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:05 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:05 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:05 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:05 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:05 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:05 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:05 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:05 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:05 --> Controller Class Initialized
INFO - 2019-09-10 16:58:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:58:05 --> Final output sent to browser
DEBUG - 2019-09-10 16:58:05 --> Total execution time: 0.0556
INFO - 2019-09-10 16:58:10 --> Config Class Initialized
INFO - 2019-09-10 16:58:10 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:10 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:10 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:10 --> URI Class Initialized
INFO - 2019-09-10 16:58:10 --> Router Class Initialized
INFO - 2019-09-10 16:58:10 --> Output Class Initialized
INFO - 2019-09-10 16:58:10 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:10 --> Input Class Initialized
INFO - 2019-09-10 16:58:10 --> Language Class Initialized
INFO - 2019-09-10 16:58:10 --> Loader Class Initialized
INFO - 2019-09-10 16:58:10 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:10 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:10 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:10 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:10 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:10 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:10 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:10 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:10 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:10 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:10 --> Controller Class Initialized
ERROR - 2019-09-10 16:58:10 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:58:10 --> Config Class Initialized
INFO - 2019-09-10 16:58:10 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:10 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:10 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:10 --> URI Class Initialized
INFO - 2019-09-10 16:58:10 --> Router Class Initialized
INFO - 2019-09-10 16:58:10 --> Output Class Initialized
INFO - 2019-09-10 16:58:10 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:10 --> Input Class Initialized
INFO - 2019-09-10 16:58:10 --> Language Class Initialized
INFO - 2019-09-10 16:58:10 --> Loader Class Initialized
INFO - 2019-09-10 16:58:10 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:10 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:10 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:10 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:10 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:10 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:10 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:10 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:10 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:10 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:10 --> Controller Class Initialized
ERROR - 2019-09-10 16:58:10 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:58:11 --> Config Class Initialized
INFO - 2019-09-10 16:58:11 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:11 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:11 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:11 --> URI Class Initialized
INFO - 2019-09-10 16:58:11 --> Router Class Initialized
INFO - 2019-09-10 16:58:11 --> Output Class Initialized
INFO - 2019-09-10 16:58:11 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:11 --> Input Class Initialized
INFO - 2019-09-10 16:58:11 --> Language Class Initialized
INFO - 2019-09-10 16:58:11 --> Loader Class Initialized
INFO - 2019-09-10 16:58:11 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:11 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:11 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:11 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:11 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:11 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:11 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:11 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:11 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:11 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:11 --> Controller Class Initialized
ERROR - 2019-09-10 16:58:11 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:58:11 --> Config Class Initialized
INFO - 2019-09-10 16:58:11 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:11 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:11 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:11 --> URI Class Initialized
INFO - 2019-09-10 16:58:11 --> Router Class Initialized
INFO - 2019-09-10 16:58:11 --> Output Class Initialized
INFO - 2019-09-10 16:58:11 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:11 --> Input Class Initialized
INFO - 2019-09-10 16:58:11 --> Language Class Initialized
INFO - 2019-09-10 16:58:11 --> Loader Class Initialized
INFO - 2019-09-10 16:58:11 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:11 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:11 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:11 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:11 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:11 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:11 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:11 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:11 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:11 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:11 --> Controller Class Initialized
ERROR - 2019-09-10 16:58:11 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:58:13 --> Config Class Initialized
INFO - 2019-09-10 16:58:13 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:13 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:13 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:13 --> URI Class Initialized
INFO - 2019-09-10 16:58:13 --> Router Class Initialized
INFO - 2019-09-10 16:58:13 --> Output Class Initialized
INFO - 2019-09-10 16:58:13 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:13 --> Input Class Initialized
INFO - 2019-09-10 16:58:13 --> Language Class Initialized
INFO - 2019-09-10 16:58:13 --> Loader Class Initialized
INFO - 2019-09-10 16:58:13 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:13 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:13 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:13 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:13 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:13 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:13 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:13 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:13 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:13 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:13 --> Controller Class Initialized
ERROR - 2019-09-10 16:58:13 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:58:13 --> Config Class Initialized
INFO - 2019-09-10 16:58:13 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:13 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:13 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:13 --> URI Class Initialized
INFO - 2019-09-10 16:58:13 --> Router Class Initialized
INFO - 2019-09-10 16:58:13 --> Output Class Initialized
INFO - 2019-09-10 16:58:13 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:13 --> Input Class Initialized
INFO - 2019-09-10 16:58:13 --> Language Class Initialized
INFO - 2019-09-10 16:58:13 --> Loader Class Initialized
INFO - 2019-09-10 16:58:13 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:13 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:13 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:13 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:13 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:13 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:13 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:13 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:13 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:13 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:13 --> Controller Class Initialized
ERROR - 2019-09-10 16:58:13 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:58:13 --> Config Class Initialized
INFO - 2019-09-10 16:58:13 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:13 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:13 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:13 --> URI Class Initialized
INFO - 2019-09-10 16:58:13 --> Router Class Initialized
INFO - 2019-09-10 16:58:13 --> Output Class Initialized
INFO - 2019-09-10 16:58:13 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:13 --> Input Class Initialized
INFO - 2019-09-10 16:58:13 --> Language Class Initialized
INFO - 2019-09-10 16:58:13 --> Loader Class Initialized
INFO - 2019-09-10 16:58:13 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:13 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:13 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:13 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:13 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:13 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:13 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:13 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:13 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:13 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:13 --> Controller Class Initialized
ERROR - 2019-09-10 16:58:13 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:58:13 --> Config Class Initialized
INFO - 2019-09-10 16:58:13 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:13 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:13 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:13 --> URI Class Initialized
INFO - 2019-09-10 16:58:13 --> Router Class Initialized
INFO - 2019-09-10 16:58:13 --> Output Class Initialized
INFO - 2019-09-10 16:58:13 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:13 --> Input Class Initialized
INFO - 2019-09-10 16:58:13 --> Language Class Initialized
INFO - 2019-09-10 16:58:13 --> Loader Class Initialized
INFO - 2019-09-10 16:58:13 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:13 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:13 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:13 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:13 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:13 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:13 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:13 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:13 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:13 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:13 --> Controller Class Initialized
ERROR - 2019-09-10 16:58:13 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:58:13 --> Config Class Initialized
INFO - 2019-09-10 16:58:13 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:13 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:13 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:13 --> URI Class Initialized
INFO - 2019-09-10 16:58:13 --> Router Class Initialized
INFO - 2019-09-10 16:58:13 --> Output Class Initialized
INFO - 2019-09-10 16:58:13 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:13 --> Input Class Initialized
INFO - 2019-09-10 16:58:13 --> Language Class Initialized
INFO - 2019-09-10 16:58:14 --> Loader Class Initialized
INFO - 2019-09-10 16:58:14 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:14 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:14 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:14 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:14 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:14 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:14 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:14 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:14 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:14 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:14 --> Controller Class Initialized
ERROR - 2019-09-10 16:58:14 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:58:14 --> Config Class Initialized
INFO - 2019-09-10 16:58:14 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:14 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:14 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:14 --> URI Class Initialized
INFO - 2019-09-10 16:58:14 --> Router Class Initialized
INFO - 2019-09-10 16:58:14 --> Output Class Initialized
INFO - 2019-09-10 16:58:14 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:14 --> Input Class Initialized
INFO - 2019-09-10 16:58:14 --> Language Class Initialized
INFO - 2019-09-10 16:58:14 --> Loader Class Initialized
INFO - 2019-09-10 16:58:14 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:14 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:14 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:14 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:14 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:14 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:14 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:14 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:14 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:14 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:14 --> Controller Class Initialized
ERROR - 2019-09-10 16:58:14 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:58:14 --> Config Class Initialized
INFO - 2019-09-10 16:58:14 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:14 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:14 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:14 --> URI Class Initialized
INFO - 2019-09-10 16:58:14 --> Router Class Initialized
INFO - 2019-09-10 16:58:14 --> Output Class Initialized
INFO - 2019-09-10 16:58:14 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:14 --> Input Class Initialized
INFO - 2019-09-10 16:58:14 --> Language Class Initialized
INFO - 2019-09-10 16:58:14 --> Loader Class Initialized
INFO - 2019-09-10 16:58:14 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:14 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:14 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:14 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:14 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:14 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:14 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:14 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:14 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:14 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:14 --> Controller Class Initialized
ERROR - 2019-09-10 16:58:14 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:58:18 --> Config Class Initialized
INFO - 2019-09-10 16:58:18 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:18 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:18 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:18 --> URI Class Initialized
INFO - 2019-09-10 16:58:18 --> Router Class Initialized
INFO - 2019-09-10 16:58:18 --> Output Class Initialized
INFO - 2019-09-10 16:58:18 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:18 --> Input Class Initialized
INFO - 2019-09-10 16:58:18 --> Language Class Initialized
INFO - 2019-09-10 16:58:18 --> Loader Class Initialized
INFO - 2019-09-10 16:58:18 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:18 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:18 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:18 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:18 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:18 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:18 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:18 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:18 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:18 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:18 --> Controller Class Initialized
INFO - 2019-09-10 16:58:18 --> Final output sent to browser
DEBUG - 2019-09-10 16:58:18 --> Total execution time: 0.0545
INFO - 2019-09-10 16:58:22 --> Config Class Initialized
INFO - 2019-09-10 16:58:22 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:22 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:22 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:22 --> URI Class Initialized
INFO - 2019-09-10 16:58:22 --> Router Class Initialized
INFO - 2019-09-10 16:58:22 --> Output Class Initialized
INFO - 2019-09-10 16:58:22 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:22 --> Input Class Initialized
INFO - 2019-09-10 16:58:22 --> Language Class Initialized
INFO - 2019-09-10 16:58:22 --> Loader Class Initialized
INFO - 2019-09-10 16:58:22 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:22 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:22 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:22 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:22 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:22 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:22 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:22 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:22 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:22 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:22 --> Controller Class Initialized
INFO - 2019-09-10 16:58:22 --> Final output sent to browser
DEBUG - 2019-09-10 16:58:22 --> Total execution time: 0.0483
INFO - 2019-09-10 16:58:25 --> Config Class Initialized
INFO - 2019-09-10 16:58:25 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:25 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:25 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:25 --> URI Class Initialized
INFO - 2019-09-10 16:58:25 --> Router Class Initialized
INFO - 2019-09-10 16:58:25 --> Output Class Initialized
INFO - 2019-09-10 16:58:25 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:25 --> Input Class Initialized
INFO - 2019-09-10 16:58:25 --> Language Class Initialized
INFO - 2019-09-10 16:58:25 --> Loader Class Initialized
INFO - 2019-09-10 16:58:25 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:25 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:25 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:25 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:25 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:25 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:25 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:25 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:25 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:25 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:25 --> Controller Class Initialized
INFO - 2019-09-10 16:58:25 --> Final output sent to browser
DEBUG - 2019-09-10 16:58:25 --> Total execution time: 0.0581
INFO - 2019-09-10 16:58:30 --> Config Class Initialized
INFO - 2019-09-10 16:58:30 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:58:30 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:58:30 --> Utf8 Class Initialized
INFO - 2019-09-10 16:58:30 --> URI Class Initialized
INFO - 2019-09-10 16:58:30 --> Router Class Initialized
INFO - 2019-09-10 16:58:30 --> Output Class Initialized
INFO - 2019-09-10 16:58:30 --> Security Class Initialized
DEBUG - 2019-09-10 16:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:58:30 --> Input Class Initialized
INFO - 2019-09-10 16:58:30 --> Language Class Initialized
INFO - 2019-09-10 16:58:30 --> Loader Class Initialized
INFO - 2019-09-10 16:58:30 --> Helper loaded: url_helper
INFO - 2019-09-10 16:58:30 --> Helper loaded: html_helper
INFO - 2019-09-10 16:58:30 --> Helper loaded: form_helper
INFO - 2019-09-10 16:58:30 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:58:30 --> Helper loaded: date_helper
INFO - 2019-09-10 16:58:30 --> Form Validation Class Initialized
INFO - 2019-09-10 16:58:30 --> Email Class Initialized
DEBUG - 2019-09-10 16:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:58:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:58:30 --> Pagination Class Initialized
INFO - 2019-09-10 16:58:30 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:30 --> Database Driver Class Initialized
INFO - 2019-09-10 16:58:30 --> Controller Class Initialized
INFO - 2019-09-10 16:58:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-10 16:59:21 --> Config Class Initialized
INFO - 2019-09-10 16:59:21 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:59:21 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:59:21 --> Utf8 Class Initialized
INFO - 2019-09-10 16:59:21 --> URI Class Initialized
INFO - 2019-09-10 16:59:21 --> Router Class Initialized
INFO - 2019-09-10 16:59:21 --> Output Class Initialized
INFO - 2019-09-10 16:59:21 --> Security Class Initialized
DEBUG - 2019-09-10 16:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:59:21 --> Input Class Initialized
INFO - 2019-09-10 16:59:21 --> Language Class Initialized
INFO - 2019-09-10 16:59:21 --> Loader Class Initialized
INFO - 2019-09-10 16:59:21 --> Helper loaded: url_helper
INFO - 2019-09-10 16:59:21 --> Helper loaded: html_helper
INFO - 2019-09-10 16:59:21 --> Helper loaded: form_helper
INFO - 2019-09-10 16:59:21 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:59:21 --> Helper loaded: date_helper
INFO - 2019-09-10 16:59:21 --> Form Validation Class Initialized
INFO - 2019-09-10 16:59:21 --> Email Class Initialized
DEBUG - 2019-09-10 16:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:59:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:59:21 --> Pagination Class Initialized
INFO - 2019-09-10 16:59:21 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:21 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:21 --> Controller Class Initialized
INFO - 2019-09-10 16:59:21 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:59:21 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-10 16:59:21 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-10 16:59:21 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:59:21 --> Final output sent to browser
DEBUG - 2019-09-10 16:59:21 --> Total execution time: 0.0732
INFO - 2019-09-10 16:59:22 --> Config Class Initialized
INFO - 2019-09-10 16:59:22 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:59:22 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:59:22 --> Utf8 Class Initialized
INFO - 2019-09-10 16:59:22 --> URI Class Initialized
INFO - 2019-09-10 16:59:22 --> Router Class Initialized
INFO - 2019-09-10 16:59:22 --> Output Class Initialized
INFO - 2019-09-10 16:59:22 --> Security Class Initialized
DEBUG - 2019-09-10 16:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:59:22 --> Input Class Initialized
INFO - 2019-09-10 16:59:22 --> Language Class Initialized
INFO - 2019-09-10 16:59:22 --> Loader Class Initialized
INFO - 2019-09-10 16:59:22 --> Helper loaded: url_helper
INFO - 2019-09-10 16:59:22 --> Helper loaded: html_helper
INFO - 2019-09-10 16:59:22 --> Helper loaded: form_helper
INFO - 2019-09-10 16:59:22 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:59:22 --> Helper loaded: date_helper
INFO - 2019-09-10 16:59:22 --> Form Validation Class Initialized
INFO - 2019-09-10 16:59:22 --> Email Class Initialized
DEBUG - 2019-09-10 16:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:59:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:59:22 --> Pagination Class Initialized
INFO - 2019-09-10 16:59:22 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:22 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:22 --> Controller Class Initialized
INFO - 2019-09-10 16:59:22 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:59:22 --> Final output sent to browser
DEBUG - 2019-09-10 16:59:22 --> Total execution time: 0.0769
INFO - 2019-09-10 16:59:22 --> Config Class Initialized
INFO - 2019-09-10 16:59:22 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:59:22 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:59:22 --> Utf8 Class Initialized
INFO - 2019-09-10 16:59:22 --> URI Class Initialized
INFO - 2019-09-10 16:59:22 --> Router Class Initialized
INFO - 2019-09-10 16:59:22 --> Output Class Initialized
INFO - 2019-09-10 16:59:22 --> Security Class Initialized
DEBUG - 2019-09-10 16:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:59:22 --> Input Class Initialized
INFO - 2019-09-10 16:59:22 --> Language Class Initialized
INFO - 2019-09-10 16:59:22 --> Loader Class Initialized
INFO - 2019-09-10 16:59:22 --> Helper loaded: url_helper
INFO - 2019-09-10 16:59:22 --> Helper loaded: html_helper
INFO - 2019-09-10 16:59:22 --> Helper loaded: form_helper
INFO - 2019-09-10 16:59:22 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:59:22 --> Helper loaded: date_helper
INFO - 2019-09-10 16:59:22 --> Form Validation Class Initialized
INFO - 2019-09-10 16:59:22 --> Email Class Initialized
DEBUG - 2019-09-10 16:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:59:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:59:22 --> Pagination Class Initialized
INFO - 2019-09-10 16:59:22 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:22 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:22 --> Controller Class Initialized
INFO - 2019-09-10 16:59:22 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:59:22 --> Final output sent to browser
DEBUG - 2019-09-10 16:59:22 --> Total execution time: 0.0806
INFO - 2019-09-10 16:59:27 --> Config Class Initialized
INFO - 2019-09-10 16:59:27 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:59:27 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:59:27 --> Utf8 Class Initialized
INFO - 2019-09-10 16:59:27 --> URI Class Initialized
INFO - 2019-09-10 16:59:27 --> Router Class Initialized
INFO - 2019-09-10 16:59:27 --> Output Class Initialized
INFO - 2019-09-10 16:59:27 --> Security Class Initialized
DEBUG - 2019-09-10 16:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:59:27 --> Input Class Initialized
INFO - 2019-09-10 16:59:27 --> Language Class Initialized
INFO - 2019-09-10 16:59:27 --> Loader Class Initialized
INFO - 2019-09-10 16:59:27 --> Helper loaded: url_helper
INFO - 2019-09-10 16:59:27 --> Helper loaded: html_helper
INFO - 2019-09-10 16:59:27 --> Helper loaded: form_helper
INFO - 2019-09-10 16:59:27 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:59:27 --> Helper loaded: date_helper
INFO - 2019-09-10 16:59:27 --> Form Validation Class Initialized
INFO - 2019-09-10 16:59:27 --> Email Class Initialized
DEBUG - 2019-09-10 16:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:59:27 --> Pagination Class Initialized
INFO - 2019-09-10 16:59:27 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:27 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:27 --> Controller Class Initialized
INFO - 2019-09-10 16:59:27 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-10 16:59:27 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-10 16:59:27 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-10 16:59:27 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-10 16:59:27 --> Final output sent to browser
DEBUG - 2019-09-10 16:59:27 --> Total execution time: 0.0643
INFO - 2019-09-10 16:59:27 --> Config Class Initialized
INFO - 2019-09-10 16:59:27 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:59:27 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:59:27 --> Utf8 Class Initialized
INFO - 2019-09-10 16:59:27 --> URI Class Initialized
INFO - 2019-09-10 16:59:27 --> Router Class Initialized
INFO - 2019-09-10 16:59:27 --> Output Class Initialized
INFO - 2019-09-10 16:59:27 --> Security Class Initialized
DEBUG - 2019-09-10 16:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:59:27 --> Input Class Initialized
INFO - 2019-09-10 16:59:27 --> Language Class Initialized
INFO - 2019-09-10 16:59:27 --> Loader Class Initialized
INFO - 2019-09-10 16:59:27 --> Helper loaded: url_helper
INFO - 2019-09-10 16:59:27 --> Helper loaded: html_helper
INFO - 2019-09-10 16:59:27 --> Helper loaded: form_helper
INFO - 2019-09-10 16:59:27 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:59:27 --> Helper loaded: date_helper
INFO - 2019-09-10 16:59:27 --> Form Validation Class Initialized
INFO - 2019-09-10 16:59:27 --> Email Class Initialized
DEBUG - 2019-09-10 16:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:59:27 --> Pagination Class Initialized
INFO - 2019-09-10 16:59:27 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:27 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:27 --> Controller Class Initialized
INFO - 2019-09-10 16:59:27 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:59:27 --> Final output sent to browser
DEBUG - 2019-09-10 16:59:27 --> Total execution time: 0.0578
INFO - 2019-09-10 16:59:27 --> Config Class Initialized
INFO - 2019-09-10 16:59:27 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:59:27 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:59:27 --> Utf8 Class Initialized
INFO - 2019-09-10 16:59:27 --> URI Class Initialized
INFO - 2019-09-10 16:59:27 --> Router Class Initialized
INFO - 2019-09-10 16:59:27 --> Output Class Initialized
INFO - 2019-09-10 16:59:27 --> Security Class Initialized
DEBUG - 2019-09-10 16:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:59:27 --> Input Class Initialized
INFO - 2019-09-10 16:59:27 --> Language Class Initialized
INFO - 2019-09-10 16:59:27 --> Loader Class Initialized
INFO - 2019-09-10 16:59:27 --> Helper loaded: url_helper
INFO - 2019-09-10 16:59:27 --> Helper loaded: html_helper
INFO - 2019-09-10 16:59:27 --> Helper loaded: form_helper
INFO - 2019-09-10 16:59:27 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:59:27 --> Helper loaded: date_helper
INFO - 2019-09-10 16:59:27 --> Form Validation Class Initialized
INFO - 2019-09-10 16:59:27 --> Email Class Initialized
DEBUG - 2019-09-10 16:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:59:27 --> Pagination Class Initialized
INFO - 2019-09-10 16:59:27 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:27 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:27 --> Controller Class Initialized
INFO - 2019-09-10 16:59:27 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-10 16:59:27 --> Final output sent to browser
DEBUG - 2019-09-10 16:59:27 --> Total execution time: 0.0670
INFO - 2019-09-10 16:59:30 --> Config Class Initialized
INFO - 2019-09-10 16:59:30 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:59:30 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:59:30 --> Utf8 Class Initialized
INFO - 2019-09-10 16:59:30 --> URI Class Initialized
INFO - 2019-09-10 16:59:30 --> Router Class Initialized
INFO - 2019-09-10 16:59:30 --> Output Class Initialized
INFO - 2019-09-10 16:59:30 --> Security Class Initialized
DEBUG - 2019-09-10 16:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:59:30 --> Input Class Initialized
INFO - 2019-09-10 16:59:30 --> Language Class Initialized
INFO - 2019-09-10 16:59:30 --> Loader Class Initialized
INFO - 2019-09-10 16:59:30 --> Helper loaded: url_helper
INFO - 2019-09-10 16:59:30 --> Helper loaded: html_helper
INFO - 2019-09-10 16:59:30 --> Helper loaded: form_helper
INFO - 2019-09-10 16:59:30 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:59:30 --> Helper loaded: date_helper
INFO - 2019-09-10 16:59:30 --> Form Validation Class Initialized
INFO - 2019-09-10 16:59:30 --> Email Class Initialized
DEBUG - 2019-09-10 16:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:59:30 --> Pagination Class Initialized
INFO - 2019-09-10 16:59:30 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:30 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:30 --> Controller Class Initialized
ERROR - 2019-09-10 16:59:30 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:59:30 --> Config Class Initialized
INFO - 2019-09-10 16:59:30 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:59:30 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:59:30 --> Utf8 Class Initialized
INFO - 2019-09-10 16:59:30 --> URI Class Initialized
INFO - 2019-09-10 16:59:30 --> Router Class Initialized
INFO - 2019-09-10 16:59:30 --> Output Class Initialized
INFO - 2019-09-10 16:59:30 --> Security Class Initialized
DEBUG - 2019-09-10 16:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:59:30 --> Input Class Initialized
INFO - 2019-09-10 16:59:30 --> Language Class Initialized
INFO - 2019-09-10 16:59:30 --> Loader Class Initialized
INFO - 2019-09-10 16:59:30 --> Helper loaded: url_helper
INFO - 2019-09-10 16:59:30 --> Helper loaded: html_helper
INFO - 2019-09-10 16:59:30 --> Helper loaded: form_helper
INFO - 2019-09-10 16:59:30 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:59:30 --> Helper loaded: date_helper
INFO - 2019-09-10 16:59:30 --> Form Validation Class Initialized
INFO - 2019-09-10 16:59:30 --> Email Class Initialized
DEBUG - 2019-09-10 16:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:59:30 --> Pagination Class Initialized
INFO - 2019-09-10 16:59:30 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:30 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:30 --> Controller Class Initialized
ERROR - 2019-09-10 16:59:30 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:59:30 --> Config Class Initialized
INFO - 2019-09-10 16:59:30 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:59:30 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:59:30 --> Utf8 Class Initialized
INFO - 2019-09-10 16:59:30 --> URI Class Initialized
INFO - 2019-09-10 16:59:30 --> Router Class Initialized
INFO - 2019-09-10 16:59:30 --> Output Class Initialized
INFO - 2019-09-10 16:59:30 --> Security Class Initialized
DEBUG - 2019-09-10 16:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:59:30 --> Input Class Initialized
INFO - 2019-09-10 16:59:30 --> Language Class Initialized
INFO - 2019-09-10 16:59:30 --> Loader Class Initialized
INFO - 2019-09-10 16:59:30 --> Helper loaded: url_helper
INFO - 2019-09-10 16:59:30 --> Helper loaded: html_helper
INFO - 2019-09-10 16:59:30 --> Helper loaded: form_helper
INFO - 2019-09-10 16:59:30 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:59:30 --> Helper loaded: date_helper
INFO - 2019-09-10 16:59:30 --> Form Validation Class Initialized
INFO - 2019-09-10 16:59:30 --> Email Class Initialized
DEBUG - 2019-09-10 16:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:59:30 --> Pagination Class Initialized
INFO - 2019-09-10 16:59:30 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:30 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:30 --> Controller Class Initialized
ERROR - 2019-09-10 16:59:30 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:59:30 --> Config Class Initialized
INFO - 2019-09-10 16:59:30 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:59:30 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:59:30 --> Utf8 Class Initialized
INFO - 2019-09-10 16:59:30 --> URI Class Initialized
INFO - 2019-09-10 16:59:30 --> Router Class Initialized
INFO - 2019-09-10 16:59:30 --> Output Class Initialized
INFO - 2019-09-10 16:59:30 --> Security Class Initialized
DEBUG - 2019-09-10 16:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:59:30 --> Input Class Initialized
INFO - 2019-09-10 16:59:30 --> Language Class Initialized
INFO - 2019-09-10 16:59:30 --> Loader Class Initialized
INFO - 2019-09-10 16:59:30 --> Helper loaded: url_helper
INFO - 2019-09-10 16:59:30 --> Helper loaded: html_helper
INFO - 2019-09-10 16:59:30 --> Helper loaded: form_helper
INFO - 2019-09-10 16:59:30 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:59:30 --> Helper loaded: date_helper
INFO - 2019-09-10 16:59:30 --> Form Validation Class Initialized
INFO - 2019-09-10 16:59:30 --> Email Class Initialized
DEBUG - 2019-09-10 16:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:59:30 --> Pagination Class Initialized
INFO - 2019-09-10 16:59:30 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:30 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:30 --> Controller Class Initialized
ERROR - 2019-09-10 16:59:30 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-10 16:59:35 --> Config Class Initialized
INFO - 2019-09-10 16:59:35 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:59:35 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:59:35 --> Utf8 Class Initialized
INFO - 2019-09-10 16:59:35 --> URI Class Initialized
INFO - 2019-09-10 16:59:35 --> Router Class Initialized
INFO - 2019-09-10 16:59:35 --> Output Class Initialized
INFO - 2019-09-10 16:59:35 --> Security Class Initialized
DEBUG - 2019-09-10 16:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:59:35 --> Input Class Initialized
INFO - 2019-09-10 16:59:35 --> Language Class Initialized
INFO - 2019-09-10 16:59:35 --> Loader Class Initialized
INFO - 2019-09-10 16:59:35 --> Helper loaded: url_helper
INFO - 2019-09-10 16:59:35 --> Helper loaded: html_helper
INFO - 2019-09-10 16:59:35 --> Helper loaded: form_helper
INFO - 2019-09-10 16:59:35 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:59:35 --> Helper loaded: date_helper
INFO - 2019-09-10 16:59:35 --> Form Validation Class Initialized
INFO - 2019-09-10 16:59:35 --> Email Class Initialized
DEBUG - 2019-09-10 16:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:59:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:59:35 --> Pagination Class Initialized
INFO - 2019-09-10 16:59:35 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:35 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:35 --> Controller Class Initialized
INFO - 2019-09-10 16:59:35 --> Final output sent to browser
DEBUG - 2019-09-10 16:59:35 --> Total execution time: 0.0503
INFO - 2019-09-10 16:59:39 --> Config Class Initialized
INFO - 2019-09-10 16:59:39 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:59:39 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:59:39 --> Utf8 Class Initialized
INFO - 2019-09-10 16:59:39 --> URI Class Initialized
INFO - 2019-09-10 16:59:39 --> Router Class Initialized
INFO - 2019-09-10 16:59:39 --> Output Class Initialized
INFO - 2019-09-10 16:59:39 --> Security Class Initialized
DEBUG - 2019-09-10 16:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:59:39 --> Input Class Initialized
INFO - 2019-09-10 16:59:39 --> Language Class Initialized
INFO - 2019-09-10 16:59:39 --> Loader Class Initialized
INFO - 2019-09-10 16:59:39 --> Helper loaded: url_helper
INFO - 2019-09-10 16:59:39 --> Helper loaded: html_helper
INFO - 2019-09-10 16:59:39 --> Helper loaded: form_helper
INFO - 2019-09-10 16:59:39 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:59:39 --> Helper loaded: date_helper
INFO - 2019-09-10 16:59:39 --> Form Validation Class Initialized
INFO - 2019-09-10 16:59:39 --> Email Class Initialized
DEBUG - 2019-09-10 16:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:59:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:59:39 --> Pagination Class Initialized
INFO - 2019-09-10 16:59:39 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:39 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:39 --> Controller Class Initialized
INFO - 2019-09-10 16:59:39 --> Final output sent to browser
DEBUG - 2019-09-10 16:59:39 --> Total execution time: 0.0498
INFO - 2019-09-10 16:59:42 --> Config Class Initialized
INFO - 2019-09-10 16:59:42 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:59:42 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:59:42 --> Utf8 Class Initialized
INFO - 2019-09-10 16:59:42 --> URI Class Initialized
INFO - 2019-09-10 16:59:42 --> Router Class Initialized
INFO - 2019-09-10 16:59:42 --> Output Class Initialized
INFO - 2019-09-10 16:59:42 --> Security Class Initialized
DEBUG - 2019-09-10 16:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:59:42 --> Input Class Initialized
INFO - 2019-09-10 16:59:42 --> Language Class Initialized
INFO - 2019-09-10 16:59:42 --> Loader Class Initialized
INFO - 2019-09-10 16:59:42 --> Helper loaded: url_helper
INFO - 2019-09-10 16:59:42 --> Helper loaded: html_helper
INFO - 2019-09-10 16:59:42 --> Helper loaded: form_helper
INFO - 2019-09-10 16:59:42 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:59:42 --> Helper loaded: date_helper
INFO - 2019-09-10 16:59:42 --> Form Validation Class Initialized
INFO - 2019-09-10 16:59:42 --> Email Class Initialized
DEBUG - 2019-09-10 16:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:59:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:59:42 --> Pagination Class Initialized
INFO - 2019-09-10 16:59:42 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:42 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:42 --> Controller Class Initialized
INFO - 2019-09-10 16:59:42 --> Final output sent to browser
DEBUG - 2019-09-10 16:59:42 --> Total execution time: 0.0493
INFO - 2019-09-10 16:59:56 --> Config Class Initialized
INFO - 2019-09-10 16:59:56 --> Hooks Class Initialized
DEBUG - 2019-09-10 16:59:56 --> UTF-8 Support Enabled
INFO - 2019-09-10 16:59:56 --> Utf8 Class Initialized
INFO - 2019-09-10 16:59:56 --> URI Class Initialized
INFO - 2019-09-10 16:59:56 --> Router Class Initialized
INFO - 2019-09-10 16:59:56 --> Output Class Initialized
INFO - 2019-09-10 16:59:56 --> Security Class Initialized
DEBUG - 2019-09-10 16:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-10 16:59:56 --> Input Class Initialized
INFO - 2019-09-10 16:59:56 --> Language Class Initialized
INFO - 2019-09-10 16:59:56 --> Loader Class Initialized
INFO - 2019-09-10 16:59:56 --> Helper loaded: url_helper
INFO - 2019-09-10 16:59:56 --> Helper loaded: html_helper
INFO - 2019-09-10 16:59:56 --> Helper loaded: form_helper
INFO - 2019-09-10 16:59:56 --> Helper loaded: cookie_helper
INFO - 2019-09-10 16:59:56 --> Helper loaded: date_helper
INFO - 2019-09-10 16:59:56 --> Form Validation Class Initialized
INFO - 2019-09-10 16:59:56 --> Email Class Initialized
DEBUG - 2019-09-10 16:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-10 16:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-10 16:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-10 16:59:56 --> Pagination Class Initialized
INFO - 2019-09-10 16:59:56 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:56 --> Database Driver Class Initialized
INFO - 2019-09-10 16:59:56 --> Controller Class Initialized
INFO - 2019-09-10 16:59:56 --> Language file loaded: language/english/form_validation_lang.php
