<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-26 09:43:57 --> Config Class Initialized
INFO - 2018-11-26 09:43:57 --> Hooks Class Initialized
DEBUG - 2018-11-26 09:43:57 --> UTF-8 Support Enabled
INFO - 2018-11-26 09:43:57 --> Utf8 Class Initialized
INFO - 2018-11-26 09:43:57 --> URI Class Initialized
INFO - 2018-11-26 09:43:57 --> Router Class Initialized
INFO - 2018-11-26 09:43:57 --> Output Class Initialized
INFO - 2018-11-26 09:43:57 --> Security Class Initialized
DEBUG - 2018-11-26 09:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 09:43:57 --> Input Class Initialized
INFO - 2018-11-26 09:43:58 --> Language Class Initialized
INFO - 2018-11-26 09:43:58 --> Loader Class Initialized
INFO - 2018-11-26 09:43:58 --> Helper loaded: url_helper
INFO - 2018-11-26 09:43:58 --> Helper loaded: html_helper
INFO - 2018-11-26 09:43:58 --> Helper loaded: form_helper
INFO - 2018-11-26 09:43:58 --> Helper loaded: cookie_helper
INFO - 2018-11-26 09:43:58 --> Helper loaded: date_helper
INFO - 2018-11-26 09:43:59 --> Form Validation Class Initialized
INFO - 2018-11-26 09:43:59 --> Email Class Initialized
DEBUG - 2018-11-26 09:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 09:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 09:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 09:43:59 --> Pagination Class Initialized
INFO - 2018-11-26 09:44:00 --> Database Driver Class Initialized
INFO - 2018-11-26 09:44:00 --> Database Driver Class Initialized
INFO - 2018-11-26 09:44:02 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-26 17:34:09 --> Config Class Initialized
INFO - 2018-11-26 17:34:09 --> Hooks Class Initialized
DEBUG - 2018-11-26 17:34:09 --> UTF-8 Support Enabled
INFO - 2018-11-26 17:34:09 --> Utf8 Class Initialized
INFO - 2018-11-26 17:34:09 --> URI Class Initialized
INFO - 2018-11-26 17:34:09 --> Router Class Initialized
INFO - 2018-11-26 17:34:09 --> Output Class Initialized
INFO - 2018-11-26 17:34:09 --> Security Class Initialized
DEBUG - 2018-11-26 17:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 17:34:09 --> Input Class Initialized
INFO - 2018-11-26 17:34:09 --> Language Class Initialized
INFO - 2018-11-26 17:34:10 --> Loader Class Initialized
INFO - 2018-11-26 17:34:10 --> Helper loaded: url_helper
INFO - 2018-11-26 17:34:10 --> Helper loaded: html_helper
INFO - 2018-11-26 17:34:10 --> Helper loaded: form_helper
INFO - 2018-11-26 17:34:10 --> Helper loaded: cookie_helper
INFO - 2018-11-26 17:34:10 --> Helper loaded: date_helper
INFO - 2018-11-26 17:34:10 --> Form Validation Class Initialized
INFO - 2018-11-26 17:34:10 --> Email Class Initialized
DEBUG - 2018-11-26 17:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 17:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 17:34:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 17:34:10 --> Pagination Class Initialized
INFO - 2018-11-26 17:34:10 --> Database Driver Class Initialized
INFO - 2018-11-26 17:34:10 --> Database Driver Class Initialized
INFO - 2018-11-26 17:34:10 --> Controller Class Initialized
DEBUG - 2018-11-26 17:34:10 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-26 17:34:10 --> Helper loaded: inflector_helper
INFO - 2018-11-26 17:34:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-26 17:34:10 --> Final output sent to browser
DEBUG - 2018-11-26 17:34:10 --> Total execution time: 0.6213
INFO - 2018-11-26 17:36:08 --> Config Class Initialized
INFO - 2018-11-26 17:36:08 --> Hooks Class Initialized
DEBUG - 2018-11-26 17:36:08 --> UTF-8 Support Enabled
INFO - 2018-11-26 17:36:08 --> Utf8 Class Initialized
INFO - 2018-11-26 17:36:08 --> URI Class Initialized
INFO - 2018-11-26 17:36:08 --> Router Class Initialized
INFO - 2018-11-26 17:36:08 --> Output Class Initialized
INFO - 2018-11-26 17:36:08 --> Security Class Initialized
DEBUG - 2018-11-26 17:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 17:36:08 --> Input Class Initialized
INFO - 2018-11-26 17:36:08 --> Language Class Initialized
INFO - 2018-11-26 17:36:08 --> Loader Class Initialized
INFO - 2018-11-26 17:36:08 --> Helper loaded: url_helper
INFO - 2018-11-26 17:36:09 --> Helper loaded: html_helper
INFO - 2018-11-26 17:36:09 --> Helper loaded: form_helper
INFO - 2018-11-26 17:36:09 --> Helper loaded: cookie_helper
INFO - 2018-11-26 17:36:09 --> Helper loaded: date_helper
INFO - 2018-11-26 17:36:09 --> Form Validation Class Initialized
INFO - 2018-11-26 17:36:09 --> Email Class Initialized
DEBUG - 2018-11-26 17:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 17:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 17:36:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 17:36:09 --> Pagination Class Initialized
INFO - 2018-11-26 17:36:09 --> Database Driver Class Initialized
INFO - 2018-11-26 17:36:09 --> Database Driver Class Initialized
INFO - 2018-11-26 17:36:09 --> Controller Class Initialized
DEBUG - 2018-11-26 17:36:09 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-26 17:36:09 --> Helper loaded: inflector_helper
INFO - 2018-11-26 17:36:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-26 17:36:09 --> Final output sent to browser
DEBUG - 2018-11-26 17:36:09 --> Total execution time: 0.3157
INFO - 2018-11-26 17:37:39 --> Config Class Initialized
INFO - 2018-11-26 17:37:39 --> Hooks Class Initialized
DEBUG - 2018-11-26 17:37:39 --> UTF-8 Support Enabled
INFO - 2018-11-26 17:37:39 --> Utf8 Class Initialized
INFO - 2018-11-26 17:37:39 --> URI Class Initialized
INFO - 2018-11-26 17:37:39 --> Router Class Initialized
INFO - 2018-11-26 17:37:39 --> Output Class Initialized
INFO - 2018-11-26 17:37:39 --> Security Class Initialized
DEBUG - 2018-11-26 17:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 17:37:39 --> Input Class Initialized
INFO - 2018-11-26 17:37:39 --> Language Class Initialized
INFO - 2018-11-26 17:37:39 --> Loader Class Initialized
INFO - 2018-11-26 17:37:39 --> Helper loaded: url_helper
INFO - 2018-11-26 17:37:39 --> Helper loaded: html_helper
INFO - 2018-11-26 17:37:39 --> Helper loaded: form_helper
INFO - 2018-11-26 17:37:39 --> Helper loaded: cookie_helper
INFO - 2018-11-26 17:37:39 --> Helper loaded: date_helper
INFO - 2018-11-26 17:37:39 --> Form Validation Class Initialized
INFO - 2018-11-26 17:37:39 --> Email Class Initialized
DEBUG - 2018-11-26 17:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 17:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 17:37:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 17:37:39 --> Pagination Class Initialized
INFO - 2018-11-26 17:37:39 --> Database Driver Class Initialized
INFO - 2018-11-26 17:37:39 --> Database Driver Class Initialized
INFO - 2018-11-26 17:37:39 --> Controller Class Initialized
DEBUG - 2018-11-26 17:37:39 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-26 17:37:39 --> Helper loaded: inflector_helper
INFO - 2018-11-26 17:37:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-26 17:37:39 --> Final output sent to browser
DEBUG - 2018-11-26 17:37:39 --> Total execution time: 0.1253
INFO - 2018-11-26 17:42:34 --> Config Class Initialized
INFO - 2018-11-26 17:42:34 --> Hooks Class Initialized
DEBUG - 2018-11-26 17:42:34 --> UTF-8 Support Enabled
INFO - 2018-11-26 17:42:34 --> Utf8 Class Initialized
INFO - 2018-11-26 17:42:34 --> URI Class Initialized
INFO - 2018-11-26 17:42:34 --> Router Class Initialized
INFO - 2018-11-26 17:42:34 --> Output Class Initialized
INFO - 2018-11-26 17:42:34 --> Security Class Initialized
DEBUG - 2018-11-26 17:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 17:42:34 --> Input Class Initialized
INFO - 2018-11-26 17:42:34 --> Language Class Initialized
INFO - 2018-11-26 17:42:34 --> Loader Class Initialized
INFO - 2018-11-26 17:42:34 --> Helper loaded: url_helper
INFO - 2018-11-26 17:42:34 --> Helper loaded: html_helper
INFO - 2018-11-26 17:42:34 --> Helper loaded: form_helper
INFO - 2018-11-26 17:42:34 --> Helper loaded: cookie_helper
INFO - 2018-11-26 17:42:34 --> Helper loaded: date_helper
INFO - 2018-11-26 17:42:34 --> Form Validation Class Initialized
INFO - 2018-11-26 17:42:34 --> Email Class Initialized
DEBUG - 2018-11-26 17:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 17:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 17:42:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 17:42:34 --> Pagination Class Initialized
INFO - 2018-11-26 17:42:34 --> Database Driver Class Initialized
INFO - 2018-11-26 17:42:34 --> Database Driver Class Initialized
INFO - 2018-11-26 17:42:34 --> Controller Class Initialized
DEBUG - 2018-11-26 17:42:34 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-26 17:42:34 --> Helper loaded: inflector_helper
INFO - 2018-11-26 17:42:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-26 17:42:34 --> Final output sent to browser
DEBUG - 2018-11-26 17:42:34 --> Total execution time: 0.1279
INFO - 2018-11-26 17:56:15 --> Config Class Initialized
INFO - 2018-11-26 17:56:15 --> Hooks Class Initialized
DEBUG - 2018-11-26 17:56:15 --> UTF-8 Support Enabled
INFO - 2018-11-26 17:56:15 --> Utf8 Class Initialized
INFO - 2018-11-26 17:56:15 --> URI Class Initialized
INFO - 2018-11-26 17:56:15 --> Router Class Initialized
INFO - 2018-11-26 17:56:15 --> Output Class Initialized
INFO - 2018-11-26 17:56:15 --> Security Class Initialized
DEBUG - 2018-11-26 17:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 17:56:15 --> Input Class Initialized
INFO - 2018-11-26 17:56:15 --> Language Class Initialized
INFO - 2018-11-26 17:56:15 --> Loader Class Initialized
INFO - 2018-11-26 17:56:15 --> Helper loaded: url_helper
INFO - 2018-11-26 17:56:15 --> Helper loaded: html_helper
INFO - 2018-11-26 17:56:15 --> Helper loaded: form_helper
INFO - 2018-11-26 17:56:15 --> Helper loaded: cookie_helper
INFO - 2018-11-26 17:56:15 --> Helper loaded: date_helper
INFO - 2018-11-26 17:56:15 --> Form Validation Class Initialized
INFO - 2018-11-26 17:56:15 --> Email Class Initialized
DEBUG - 2018-11-26 17:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 17:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 17:56:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 17:56:15 --> Pagination Class Initialized
INFO - 2018-11-26 17:56:15 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:16 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:16 --> Controller Class Initialized
INFO - 2018-11-26 17:56:16 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-26 17:56:16 --> Final output sent to browser
DEBUG - 2018-11-26 17:56:16 --> Total execution time: 0.2109
INFO - 2018-11-26 17:56:16 --> Config Class Initialized
INFO - 2018-11-26 17:56:16 --> Hooks Class Initialized
DEBUG - 2018-11-26 17:56:16 --> UTF-8 Support Enabled
INFO - 2018-11-26 17:56:16 --> Utf8 Class Initialized
INFO - 2018-11-26 17:56:16 --> URI Class Initialized
INFO - 2018-11-26 17:56:16 --> Router Class Initialized
INFO - 2018-11-26 17:56:16 --> Output Class Initialized
INFO - 2018-11-26 17:56:16 --> Security Class Initialized
DEBUG - 2018-11-26 17:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 17:56:16 --> Input Class Initialized
INFO - 2018-11-26 17:56:16 --> Language Class Initialized
INFO - 2018-11-26 17:56:16 --> Loader Class Initialized
INFO - 2018-11-26 17:56:16 --> Helper loaded: url_helper
INFO - 2018-11-26 17:56:16 --> Helper loaded: html_helper
INFO - 2018-11-26 17:56:16 --> Helper loaded: form_helper
INFO - 2018-11-26 17:56:16 --> Helper loaded: cookie_helper
INFO - 2018-11-26 17:56:16 --> Helper loaded: date_helper
INFO - 2018-11-26 17:56:16 --> Form Validation Class Initialized
INFO - 2018-11-26 17:56:16 --> Email Class Initialized
DEBUG - 2018-11-26 17:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 17:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 17:56:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 17:56:17 --> Pagination Class Initialized
INFO - 2018-11-26 17:56:17 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:17 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:17 --> Controller Class Initialized
INFO - 2018-11-26 17:56:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-26 17:56:17 --> Final output sent to browser
DEBUG - 2018-11-26 17:56:17 --> Total execution time: 0.1811
INFO - 2018-11-26 17:56:27 --> Config Class Initialized
INFO - 2018-11-26 17:56:27 --> Hooks Class Initialized
DEBUG - 2018-11-26 17:56:27 --> UTF-8 Support Enabled
INFO - 2018-11-26 17:56:27 --> Utf8 Class Initialized
INFO - 2018-11-26 17:56:27 --> URI Class Initialized
INFO - 2018-11-26 17:56:27 --> Router Class Initialized
INFO - 2018-11-26 17:56:27 --> Output Class Initialized
INFO - 2018-11-26 17:56:27 --> Security Class Initialized
DEBUG - 2018-11-26 17:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 17:56:27 --> Input Class Initialized
INFO - 2018-11-26 17:56:27 --> Language Class Initialized
INFO - 2018-11-26 17:56:27 --> Loader Class Initialized
INFO - 2018-11-26 17:56:27 --> Helper loaded: url_helper
INFO - 2018-11-26 17:56:27 --> Helper loaded: html_helper
INFO - 2018-11-26 17:56:27 --> Helper loaded: form_helper
INFO - 2018-11-26 17:56:27 --> Helper loaded: cookie_helper
INFO - 2018-11-26 17:56:27 --> Helper loaded: date_helper
INFO - 2018-11-26 17:56:27 --> Form Validation Class Initialized
INFO - 2018-11-26 17:56:27 --> Email Class Initialized
DEBUG - 2018-11-26 17:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 17:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 17:56:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 17:56:27 --> Pagination Class Initialized
INFO - 2018-11-26 17:56:27 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:27 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:27 --> Controller Class Initialized
INFO - 2018-11-26 17:56:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-11-26 17:56:27 --> Config Class Initialized
INFO - 2018-11-26 17:56:27 --> Hooks Class Initialized
DEBUG - 2018-11-26 17:56:27 --> UTF-8 Support Enabled
INFO - 2018-11-26 17:56:27 --> Utf8 Class Initialized
INFO - 2018-11-26 17:56:27 --> URI Class Initialized
INFO - 2018-11-26 17:56:27 --> Router Class Initialized
INFO - 2018-11-26 17:56:27 --> Output Class Initialized
INFO - 2018-11-26 17:56:27 --> Security Class Initialized
DEBUG - 2018-11-26 17:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 17:56:27 --> Input Class Initialized
INFO - 2018-11-26 17:56:27 --> Language Class Initialized
INFO - 2018-11-26 17:56:27 --> Loader Class Initialized
INFO - 2018-11-26 17:56:27 --> Helper loaded: url_helper
INFO - 2018-11-26 17:56:27 --> Helper loaded: html_helper
INFO - 2018-11-26 17:56:27 --> Helper loaded: form_helper
INFO - 2018-11-26 17:56:27 --> Helper loaded: cookie_helper
INFO - 2018-11-26 17:56:27 --> Helper loaded: date_helper
INFO - 2018-11-26 17:56:27 --> Form Validation Class Initialized
INFO - 2018-11-26 17:56:27 --> Email Class Initialized
DEBUG - 2018-11-26 17:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 17:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 17:56:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 17:56:27 --> Pagination Class Initialized
INFO - 2018-11-26 17:56:27 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:27 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:27 --> Controller Class Initialized
INFO - 2018-11-26 17:56:27 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-26 17:56:27 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-11-26 17:56:27 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 17:56:27 --> Final output sent to browser
DEBUG - 2018-11-26 17:56:27 --> Total execution time: 0.1538
INFO - 2018-11-26 17:56:28 --> Config Class Initialized
INFO - 2018-11-26 17:56:28 --> Config Class Initialized
INFO - 2018-11-26 17:56:28 --> Hooks Class Initialized
INFO - 2018-11-26 17:56:28 --> Hooks Class Initialized
DEBUG - 2018-11-26 17:56:28 --> UTF-8 Support Enabled
DEBUG - 2018-11-26 17:56:28 --> UTF-8 Support Enabled
INFO - 2018-11-26 17:56:28 --> Utf8 Class Initialized
INFO - 2018-11-26 17:56:28 --> Utf8 Class Initialized
INFO - 2018-11-26 17:56:28 --> URI Class Initialized
INFO - 2018-11-26 17:56:28 --> URI Class Initialized
INFO - 2018-11-26 17:56:28 --> Router Class Initialized
INFO - 2018-11-26 17:56:28 --> Router Class Initialized
INFO - 2018-11-26 17:56:28 --> Output Class Initialized
INFO - 2018-11-26 17:56:28 --> Output Class Initialized
INFO - 2018-11-26 17:56:28 --> Security Class Initialized
INFO - 2018-11-26 17:56:28 --> Security Class Initialized
DEBUG - 2018-11-26 17:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 17:56:28 --> Input Class Initialized
DEBUG - 2018-11-26 17:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 17:56:28 --> Input Class Initialized
INFO - 2018-11-26 17:56:28 --> Language Class Initialized
INFO - 2018-11-26 17:56:28 --> Language Class Initialized
INFO - 2018-11-26 17:56:28 --> Loader Class Initialized
INFO - 2018-11-26 17:56:28 --> Loader Class Initialized
INFO - 2018-11-26 17:56:28 --> Helper loaded: url_helper
INFO - 2018-11-26 17:56:28 --> Helper loaded: url_helper
INFO - 2018-11-26 17:56:28 --> Helper loaded: html_helper
INFO - 2018-11-26 17:56:28 --> Helper loaded: form_helper
INFO - 2018-11-26 17:56:28 --> Helper loaded: html_helper
INFO - 2018-11-26 17:56:28 --> Helper loaded: cookie_helper
INFO - 2018-11-26 17:56:28 --> Helper loaded: form_helper
INFO - 2018-11-26 17:56:28 --> Helper loaded: date_helper
INFO - 2018-11-26 17:56:28 --> Helper loaded: cookie_helper
INFO - 2018-11-26 17:56:28 --> Form Validation Class Initialized
INFO - 2018-11-26 17:56:28 --> Helper loaded: date_helper
INFO - 2018-11-26 17:56:28 --> Email Class Initialized
INFO - 2018-11-26 17:56:28 --> Form Validation Class Initialized
DEBUG - 2018-11-26 17:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 17:56:28 --> Email Class Initialized
INFO - 2018-11-26 17:56:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-11-26 17:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 17:56:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 17:56:28 --> Pagination Class Initialized
INFO - 2018-11-26 17:56:28 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:28 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:28 --> Controller Class Initialized
INFO - 2018-11-26 17:56:28 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-26 17:56:28 --> Final output sent to browser
DEBUG - 2018-11-26 17:56:28 --> Total execution time: 0.2882
INFO - 2018-11-26 17:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 17:56:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 17:56:28 --> Pagination Class Initialized
INFO - 2018-11-26 17:56:28 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:28 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:28 --> Controller Class Initialized
INFO - 2018-11-26 17:56:28 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-26 17:56:28 --> Final output sent to browser
DEBUG - 2018-11-26 17:56:28 --> Total execution time: 0.3951
INFO - 2018-11-26 17:56:29 --> Config Class Initialized
INFO - 2018-11-26 17:56:29 --> Hooks Class Initialized
DEBUG - 2018-11-26 17:56:29 --> UTF-8 Support Enabled
INFO - 2018-11-26 17:56:29 --> Utf8 Class Initialized
INFO - 2018-11-26 17:56:29 --> URI Class Initialized
INFO - 2018-11-26 17:56:29 --> Config Class Initialized
INFO - 2018-11-26 17:56:29 --> Hooks Class Initialized
INFO - 2018-11-26 17:56:29 --> Router Class Initialized
INFO - 2018-11-26 17:56:29 --> Output Class Initialized
DEBUG - 2018-11-26 17:56:29 --> UTF-8 Support Enabled
INFO - 2018-11-26 17:56:29 --> Security Class Initialized
INFO - 2018-11-26 17:56:29 --> Utf8 Class Initialized
INFO - 2018-11-26 17:56:29 --> URI Class Initialized
DEBUG - 2018-11-26 17:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 17:56:29 --> Input Class Initialized
INFO - 2018-11-26 17:56:29 --> Router Class Initialized
INFO - 2018-11-26 17:56:29 --> Language Class Initialized
INFO - 2018-11-26 17:56:29 --> Output Class Initialized
INFO - 2018-11-26 17:56:29 --> Security Class Initialized
INFO - 2018-11-26 17:56:29 --> Loader Class Initialized
DEBUG - 2018-11-26 17:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 17:56:29 --> Helper loaded: url_helper
INFO - 2018-11-26 17:56:29 --> Input Class Initialized
INFO - 2018-11-26 17:56:29 --> Language Class Initialized
INFO - 2018-11-26 17:56:29 --> Helper loaded: html_helper
INFO - 2018-11-26 17:56:29 --> Helper loaded: form_helper
INFO - 2018-11-26 17:56:29 --> Loader Class Initialized
INFO - 2018-11-26 17:56:29 --> Helper loaded: cookie_helper
INFO - 2018-11-26 17:56:29 --> Helper loaded: url_helper
INFO - 2018-11-26 17:56:29 --> Helper loaded: date_helper
INFO - 2018-11-26 17:56:29 --> Helper loaded: html_helper
INFO - 2018-11-26 17:56:29 --> Form Validation Class Initialized
INFO - 2018-11-26 17:56:29 --> Helper loaded: form_helper
INFO - 2018-11-26 17:56:29 --> Helper loaded: cookie_helper
INFO - 2018-11-26 17:56:29 --> Email Class Initialized
INFO - 2018-11-26 17:56:29 --> Helper loaded: date_helper
DEBUG - 2018-11-26 17:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 17:56:29 --> Form Validation Class Initialized
INFO - 2018-11-26 17:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 17:56:29 --> Email Class Initialized
INFO - 2018-11-26 17:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 17:56:29 --> Pagination Class Initialized
DEBUG - 2018-11-26 17:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 17:56:29 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:29 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:29 --> Controller Class Initialized
INFO - 2018-11-26 17:56:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-26 17:56:29 --> Final output sent to browser
DEBUG - 2018-11-26 17:56:29 --> Total execution time: 0.2690
INFO - 2018-11-26 17:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 17:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 17:56:29 --> Pagination Class Initialized
INFO - 2018-11-26 17:56:29 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:29 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:29 --> Controller Class Initialized
INFO - 2018-11-26 17:56:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-26 17:56:29 --> Final output sent to browser
DEBUG - 2018-11-26 17:56:29 --> Total execution time: 0.2344
INFO - 2018-11-26 17:56:45 --> Config Class Initialized
INFO - 2018-11-26 17:56:45 --> Hooks Class Initialized
DEBUG - 2018-11-26 17:56:45 --> UTF-8 Support Enabled
INFO - 2018-11-26 17:56:45 --> Utf8 Class Initialized
INFO - 2018-11-26 17:56:45 --> URI Class Initialized
INFO - 2018-11-26 17:56:45 --> Router Class Initialized
INFO - 2018-11-26 17:56:45 --> Output Class Initialized
INFO - 2018-11-26 17:56:45 --> Security Class Initialized
DEBUG - 2018-11-26 17:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 17:56:45 --> Input Class Initialized
INFO - 2018-11-26 17:56:45 --> Language Class Initialized
INFO - 2018-11-26 17:56:45 --> Loader Class Initialized
INFO - 2018-11-26 17:56:45 --> Helper loaded: url_helper
INFO - 2018-11-26 17:56:45 --> Helper loaded: html_helper
INFO - 2018-11-26 17:56:45 --> Helper loaded: form_helper
INFO - 2018-11-26 17:56:45 --> Helper loaded: cookie_helper
INFO - 2018-11-26 17:56:45 --> Helper loaded: date_helper
INFO - 2018-11-26 17:56:45 --> Form Validation Class Initialized
INFO - 2018-11-26 17:56:45 --> Email Class Initialized
DEBUG - 2018-11-26 17:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 17:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 17:56:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 17:56:45 --> Pagination Class Initialized
INFO - 2018-11-26 17:56:45 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:45 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:45 --> Controller Class Initialized
INFO - 2018-11-26 17:56:45 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-26 17:56:45 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/report.php
INFO - 2018-11-26 17:56:45 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 17:56:45 --> Final output sent to browser
DEBUG - 2018-11-26 17:56:45 --> Total execution time: 0.1340
INFO - 2018-11-26 17:56:45 --> Config Class Initialized
INFO - 2018-11-26 17:56:45 --> Hooks Class Initialized
DEBUG - 2018-11-26 17:56:45 --> UTF-8 Support Enabled
INFO - 2018-11-26 17:56:45 --> Utf8 Class Initialized
INFO - 2018-11-26 17:56:45 --> URI Class Initialized
INFO - 2018-11-26 17:56:45 --> Router Class Initialized
INFO - 2018-11-26 17:56:45 --> Output Class Initialized
INFO - 2018-11-26 17:56:45 --> Security Class Initialized
DEBUG - 2018-11-26 17:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 17:56:45 --> Input Class Initialized
INFO - 2018-11-26 17:56:45 --> Language Class Initialized
INFO - 2018-11-26 17:56:45 --> Loader Class Initialized
INFO - 2018-11-26 17:56:45 --> Helper loaded: url_helper
INFO - 2018-11-26 17:56:45 --> Helper loaded: html_helper
INFO - 2018-11-26 17:56:45 --> Helper loaded: form_helper
INFO - 2018-11-26 17:56:45 --> Helper loaded: cookie_helper
INFO - 2018-11-26 17:56:45 --> Helper loaded: date_helper
INFO - 2018-11-26 17:56:45 --> Form Validation Class Initialized
INFO - 2018-11-26 17:56:45 --> Email Class Initialized
DEBUG - 2018-11-26 17:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 17:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 17:56:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 17:56:45 --> Pagination Class Initialized
INFO - 2018-11-26 17:56:45 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:45 --> Database Driver Class Initialized
INFO - 2018-11-26 17:56:45 --> Controller Class Initialized
INFO - 2018-11-26 17:56:45 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-26 17:56:45 --> Final output sent to browser
DEBUG - 2018-11-26 17:56:45 --> Total execution time: 0.1478
INFO - 2018-11-26 17:57:14 --> Config Class Initialized
INFO - 2018-11-26 17:57:14 --> Hooks Class Initialized
DEBUG - 2018-11-26 17:57:14 --> UTF-8 Support Enabled
INFO - 2018-11-26 17:57:14 --> Utf8 Class Initialized
INFO - 2018-11-26 17:57:14 --> URI Class Initialized
INFO - 2018-11-26 17:57:14 --> Router Class Initialized
INFO - 2018-11-26 17:57:14 --> Output Class Initialized
INFO - 2018-11-26 17:57:14 --> Security Class Initialized
DEBUG - 2018-11-26 17:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 17:57:14 --> Input Class Initialized
INFO - 2018-11-26 17:57:14 --> Language Class Initialized
INFO - 2018-11-26 17:57:14 --> Loader Class Initialized
INFO - 2018-11-26 17:57:14 --> Helper loaded: url_helper
INFO - 2018-11-26 17:57:14 --> Helper loaded: html_helper
INFO - 2018-11-26 17:57:14 --> Helper loaded: form_helper
INFO - 2018-11-26 17:57:14 --> Helper loaded: cookie_helper
INFO - 2018-11-26 17:57:14 --> Helper loaded: date_helper
INFO - 2018-11-26 17:57:14 --> Form Validation Class Initialized
INFO - 2018-11-26 17:57:14 --> Email Class Initialized
DEBUG - 2018-11-26 17:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 17:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 17:57:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 17:57:14 --> Pagination Class Initialized
INFO - 2018-11-26 17:57:14 --> Database Driver Class Initialized
INFO - 2018-11-26 17:57:14 --> Database Driver Class Initialized
INFO - 2018-11-26 17:57:14 --> Controller Class Initialized
ERROR - 2018-11-26 17:57:14 --> Query error: Unknown column 'fo.signature_created' in 'where clause' - Invalid query: SELECT *,SUM(credit) as folio_credit,sum(debit) as folio_debit,count(description) as transactions from reservationfolioitems where date_created between '2018-09-01 00:00:00' and '2018-11-26 23:59:59' and action='sale' and fo.signature_created='JBA' group by account_number
INFO - 2018-11-26 17:57:14 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-26 18:08:09 --> Config Class Initialized
INFO - 2018-11-26 18:08:09 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:08:09 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:08:09 --> Utf8 Class Initialized
INFO - 2018-11-26 18:08:09 --> URI Class Initialized
INFO - 2018-11-26 18:08:09 --> Router Class Initialized
INFO - 2018-11-26 18:08:09 --> Output Class Initialized
INFO - 2018-11-26 18:08:09 --> Security Class Initialized
DEBUG - 2018-11-26 18:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:08:09 --> Input Class Initialized
INFO - 2018-11-26 18:08:09 --> Language Class Initialized
INFO - 2018-11-26 18:08:09 --> Loader Class Initialized
INFO - 2018-11-26 18:08:09 --> Helper loaded: url_helper
INFO - 2018-11-26 18:08:09 --> Helper loaded: html_helper
INFO - 2018-11-26 18:08:09 --> Helper loaded: form_helper
INFO - 2018-11-26 18:08:09 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:08:09 --> Helper loaded: date_helper
INFO - 2018-11-26 18:08:09 --> Form Validation Class Initialized
INFO - 2018-11-26 18:08:09 --> Email Class Initialized
DEBUG - 2018-11-26 18:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:08:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:08:09 --> Pagination Class Initialized
INFO - 2018-11-26 18:08:09 --> Database Driver Class Initialized
INFO - 2018-11-26 18:08:09 --> Database Driver Class Initialized
INFO - 2018-11-26 18:08:09 --> Controller Class Initialized
INFO - 2018-11-26 18:08:09 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_print.php
INFO - 2018-11-26 18:08:09 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/prints/report_sales.php
INFO - 2018-11-26 18:08:09 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:08:09 --> Final output sent to browser
DEBUG - 2018-11-26 18:08:09 --> Total execution time: 0.1409
INFO - 2018-11-26 18:08:15 --> Config Class Initialized
INFO - 2018-11-26 18:08:15 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:08:15 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:08:15 --> Utf8 Class Initialized
INFO - 2018-11-26 18:08:15 --> URI Class Initialized
INFO - 2018-11-26 18:08:15 --> Router Class Initialized
INFO - 2018-11-26 18:08:15 --> Output Class Initialized
INFO - 2018-11-26 18:08:15 --> Security Class Initialized
DEBUG - 2018-11-26 18:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:08:15 --> Input Class Initialized
INFO - 2018-11-26 18:08:15 --> Language Class Initialized
INFO - 2018-11-26 18:08:15 --> Loader Class Initialized
INFO - 2018-11-26 18:08:15 --> Helper loaded: url_helper
INFO - 2018-11-26 18:08:15 --> Helper loaded: html_helper
INFO - 2018-11-26 18:08:15 --> Helper loaded: form_helper
INFO - 2018-11-26 18:08:15 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:08:15 --> Helper loaded: date_helper
INFO - 2018-11-26 18:08:15 --> Form Validation Class Initialized
INFO - 2018-11-26 18:08:15 --> Email Class Initialized
DEBUG - 2018-11-26 18:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:08:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:08:15 --> Pagination Class Initialized
INFO - 2018-11-26 18:08:16 --> Database Driver Class Initialized
INFO - 2018-11-26 18:08:16 --> Database Driver Class Initialized
INFO - 2018-11-26 18:08:16 --> Controller Class Initialized
INFO - 2018-11-26 18:08:16 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-26 18:08:16 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/report.php
INFO - 2018-11-26 18:08:16 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:08:16 --> Final output sent to browser
DEBUG - 2018-11-26 18:08:16 --> Total execution time: 0.1385
INFO - 2018-11-26 18:08:16 --> Config Class Initialized
INFO - 2018-11-26 18:08:16 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:08:16 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:08:16 --> Utf8 Class Initialized
INFO - 2018-11-26 18:08:16 --> URI Class Initialized
INFO - 2018-11-26 18:08:16 --> Router Class Initialized
INFO - 2018-11-26 18:08:16 --> Output Class Initialized
INFO - 2018-11-26 18:08:16 --> Security Class Initialized
DEBUG - 2018-11-26 18:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:08:16 --> Input Class Initialized
INFO - 2018-11-26 18:08:16 --> Language Class Initialized
INFO - 2018-11-26 18:08:16 --> Loader Class Initialized
INFO - 2018-11-26 18:08:16 --> Helper loaded: url_helper
INFO - 2018-11-26 18:08:16 --> Helper loaded: html_helper
INFO - 2018-11-26 18:08:16 --> Helper loaded: form_helper
INFO - 2018-11-26 18:08:16 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:08:16 --> Helper loaded: date_helper
INFO - 2018-11-26 18:08:16 --> Form Validation Class Initialized
INFO - 2018-11-26 18:08:16 --> Email Class Initialized
DEBUG - 2018-11-26 18:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:08:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:08:16 --> Pagination Class Initialized
INFO - 2018-11-26 18:08:16 --> Database Driver Class Initialized
INFO - 2018-11-26 18:08:16 --> Database Driver Class Initialized
INFO - 2018-11-26 18:08:16 --> Controller Class Initialized
INFO - 2018-11-26 18:08:16 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-26 18:08:16 --> Final output sent to browser
DEBUG - 2018-11-26 18:08:16 --> Total execution time: 0.1513
INFO - 2018-11-26 18:08:19 --> Config Class Initialized
INFO - 2018-11-26 18:08:19 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:08:19 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:08:19 --> Utf8 Class Initialized
INFO - 2018-11-26 18:08:19 --> URI Class Initialized
INFO - 2018-11-26 18:08:19 --> Router Class Initialized
INFO - 2018-11-26 18:08:19 --> Output Class Initialized
INFO - 2018-11-26 18:08:19 --> Security Class Initialized
DEBUG - 2018-11-26 18:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:08:19 --> Input Class Initialized
INFO - 2018-11-26 18:08:19 --> Language Class Initialized
INFO - 2018-11-26 18:08:19 --> Loader Class Initialized
INFO - 2018-11-26 18:08:19 --> Helper loaded: url_helper
INFO - 2018-11-26 18:08:19 --> Helper loaded: html_helper
INFO - 2018-11-26 18:08:19 --> Helper loaded: form_helper
INFO - 2018-11-26 18:08:19 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:08:19 --> Helper loaded: date_helper
INFO - 2018-11-26 18:08:19 --> Form Validation Class Initialized
INFO - 2018-11-26 18:08:19 --> Email Class Initialized
DEBUG - 2018-11-26 18:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:08:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:08:19 --> Pagination Class Initialized
INFO - 2018-11-26 18:08:19 --> Database Driver Class Initialized
INFO - 2018-11-26 18:08:19 --> Database Driver Class Initialized
INFO - 2018-11-26 18:08:19 --> Controller Class Initialized
INFO - 2018-11-26 18:08:19 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-26 18:08:19 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/report.php
INFO - 2018-11-26 18:08:19 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:08:19 --> Final output sent to browser
DEBUG - 2018-11-26 18:08:19 --> Total execution time: 0.1245
INFO - 2018-11-26 18:08:19 --> Config Class Initialized
INFO - 2018-11-26 18:08:19 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:08:19 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:08:19 --> Utf8 Class Initialized
INFO - 2018-11-26 18:08:19 --> URI Class Initialized
INFO - 2018-11-26 18:08:19 --> Router Class Initialized
INFO - 2018-11-26 18:08:19 --> Output Class Initialized
INFO - 2018-11-26 18:08:19 --> Security Class Initialized
DEBUG - 2018-11-26 18:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:08:19 --> Input Class Initialized
INFO - 2018-11-26 18:08:19 --> Language Class Initialized
INFO - 2018-11-26 18:08:19 --> Loader Class Initialized
INFO - 2018-11-26 18:08:19 --> Helper loaded: url_helper
INFO - 2018-11-26 18:08:19 --> Helper loaded: html_helper
INFO - 2018-11-26 18:08:19 --> Helper loaded: form_helper
INFO - 2018-11-26 18:08:19 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:08:19 --> Helper loaded: date_helper
INFO - 2018-11-26 18:08:19 --> Form Validation Class Initialized
INFO - 2018-11-26 18:08:19 --> Email Class Initialized
DEBUG - 2018-11-26 18:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:08:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:08:19 --> Pagination Class Initialized
INFO - 2018-11-26 18:08:19 --> Database Driver Class Initialized
INFO - 2018-11-26 18:08:19 --> Database Driver Class Initialized
INFO - 2018-11-26 18:08:19 --> Controller Class Initialized
INFO - 2018-11-26 18:08:19 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-26 18:08:19 --> Final output sent to browser
DEBUG - 2018-11-26 18:08:19 --> Total execution time: 0.1592
INFO - 2018-11-26 18:08:35 --> Config Class Initialized
INFO - 2018-11-26 18:08:35 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:08:35 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:08:35 --> Utf8 Class Initialized
INFO - 2018-11-26 18:08:35 --> URI Class Initialized
INFO - 2018-11-26 18:08:35 --> Router Class Initialized
INFO - 2018-11-26 18:08:35 --> Output Class Initialized
INFO - 2018-11-26 18:08:35 --> Security Class Initialized
DEBUG - 2018-11-26 18:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:08:35 --> Input Class Initialized
INFO - 2018-11-26 18:08:35 --> Language Class Initialized
INFO - 2018-11-26 18:08:35 --> Loader Class Initialized
INFO - 2018-11-26 18:08:35 --> Helper loaded: url_helper
INFO - 2018-11-26 18:08:35 --> Helper loaded: html_helper
INFO - 2018-11-26 18:08:35 --> Helper loaded: form_helper
INFO - 2018-11-26 18:08:35 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:08:35 --> Helper loaded: date_helper
INFO - 2018-11-26 18:08:35 --> Form Validation Class Initialized
INFO - 2018-11-26 18:08:35 --> Email Class Initialized
DEBUG - 2018-11-26 18:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:08:35 --> Pagination Class Initialized
INFO - 2018-11-26 18:08:35 --> Database Driver Class Initialized
INFO - 2018-11-26 18:08:35 --> Database Driver Class Initialized
INFO - 2018-11-26 18:08:35 --> Controller Class Initialized
INFO - 2018-11-26 18:08:35 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-26 18:08:35 --> Final output sent to browser
DEBUG - 2018-11-26 18:08:35 --> Total execution time: 0.1549
INFO - 2018-11-26 18:11:27 --> Config Class Initialized
INFO - 2018-11-26 18:11:27 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:11:27 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:11:27 --> Utf8 Class Initialized
INFO - 2018-11-26 18:11:27 --> URI Class Initialized
INFO - 2018-11-26 18:11:27 --> Router Class Initialized
INFO - 2018-11-26 18:11:27 --> Output Class Initialized
INFO - 2018-11-26 18:11:27 --> Security Class Initialized
DEBUG - 2018-11-26 18:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:11:27 --> Input Class Initialized
INFO - 2018-11-26 18:11:27 --> Language Class Initialized
INFO - 2018-11-26 18:11:27 --> Loader Class Initialized
INFO - 2018-11-26 18:11:27 --> Helper loaded: url_helper
INFO - 2018-11-26 18:11:27 --> Helper loaded: html_helper
INFO - 2018-11-26 18:11:27 --> Helper loaded: form_helper
INFO - 2018-11-26 18:11:27 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:11:27 --> Helper loaded: date_helper
INFO - 2018-11-26 18:11:27 --> Form Validation Class Initialized
INFO - 2018-11-26 18:11:27 --> Email Class Initialized
DEBUG - 2018-11-26 18:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:11:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:11:27 --> Pagination Class Initialized
INFO - 2018-11-26 18:11:27 --> Database Driver Class Initialized
INFO - 2018-11-26 18:11:27 --> Database Driver Class Initialized
INFO - 2018-11-26 18:11:27 --> Controller Class Initialized
INFO - 2018-11-26 18:11:27 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_print.php
INFO - 2018-11-26 18:11:27 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/prints/report.php
INFO - 2018-11-26 18:11:27 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:11:27 --> Final output sent to browser
DEBUG - 2018-11-26 18:11:27 --> Total execution time: 0.1302
INFO - 2018-11-26 18:11:29 --> Config Class Initialized
INFO - 2018-11-26 18:11:29 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:11:29 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:11:29 --> Utf8 Class Initialized
INFO - 2018-11-26 18:11:29 --> URI Class Initialized
INFO - 2018-11-26 18:11:29 --> Router Class Initialized
INFO - 2018-11-26 18:11:29 --> Output Class Initialized
INFO - 2018-11-26 18:11:29 --> Security Class Initialized
DEBUG - 2018-11-26 18:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:11:29 --> Input Class Initialized
INFO - 2018-11-26 18:11:29 --> Language Class Initialized
INFO - 2018-11-26 18:11:30 --> Loader Class Initialized
INFO - 2018-11-26 18:11:30 --> Helper loaded: url_helper
INFO - 2018-11-26 18:11:30 --> Helper loaded: html_helper
INFO - 2018-11-26 18:11:30 --> Helper loaded: form_helper
INFO - 2018-11-26 18:11:30 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:11:30 --> Helper loaded: date_helper
INFO - 2018-11-26 18:11:30 --> Form Validation Class Initialized
INFO - 2018-11-26 18:11:30 --> Email Class Initialized
DEBUG - 2018-11-26 18:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:11:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:11:30 --> Pagination Class Initialized
INFO - 2018-11-26 18:11:30 --> Database Driver Class Initialized
INFO - 2018-11-26 18:11:30 --> Database Driver Class Initialized
INFO - 2018-11-26 18:11:30 --> Controller Class Initialized
INFO - 2018-11-26 18:11:30 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-26 18:11:30 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/report.php
INFO - 2018-11-26 18:11:30 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:11:30 --> Final output sent to browser
DEBUG - 2018-11-26 18:11:30 --> Total execution time: 0.1286
INFO - 2018-11-26 18:11:30 --> Config Class Initialized
INFO - 2018-11-26 18:11:30 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:11:30 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:11:30 --> Utf8 Class Initialized
INFO - 2018-11-26 18:11:30 --> URI Class Initialized
INFO - 2018-11-26 18:11:30 --> Router Class Initialized
INFO - 2018-11-26 18:11:30 --> Output Class Initialized
INFO - 2018-11-26 18:11:30 --> Security Class Initialized
DEBUG - 2018-11-26 18:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:11:30 --> Input Class Initialized
INFO - 2018-11-26 18:11:30 --> Language Class Initialized
INFO - 2018-11-26 18:11:30 --> Loader Class Initialized
INFO - 2018-11-26 18:11:30 --> Helper loaded: url_helper
INFO - 2018-11-26 18:11:30 --> Helper loaded: html_helper
INFO - 2018-11-26 18:11:30 --> Helper loaded: form_helper
INFO - 2018-11-26 18:11:30 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:11:30 --> Helper loaded: date_helper
INFO - 2018-11-26 18:11:30 --> Form Validation Class Initialized
INFO - 2018-11-26 18:11:30 --> Email Class Initialized
DEBUG - 2018-11-26 18:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:11:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:11:30 --> Pagination Class Initialized
INFO - 2018-11-26 18:11:30 --> Database Driver Class Initialized
INFO - 2018-11-26 18:11:30 --> Database Driver Class Initialized
INFO - 2018-11-26 18:11:30 --> Controller Class Initialized
INFO - 2018-11-26 18:11:30 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-26 18:11:30 --> Final output sent to browser
DEBUG - 2018-11-26 18:11:30 --> Total execution time: 0.1896
INFO - 2018-11-26 18:11:51 --> Config Class Initialized
INFO - 2018-11-26 18:11:51 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:11:51 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:11:51 --> Utf8 Class Initialized
INFO - 2018-11-26 18:11:51 --> URI Class Initialized
INFO - 2018-11-26 18:11:51 --> Router Class Initialized
INFO - 2018-11-26 18:11:51 --> Output Class Initialized
INFO - 2018-11-26 18:11:51 --> Security Class Initialized
DEBUG - 2018-11-26 18:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:11:51 --> Input Class Initialized
INFO - 2018-11-26 18:11:51 --> Language Class Initialized
INFO - 2018-11-26 18:11:51 --> Loader Class Initialized
INFO - 2018-11-26 18:11:51 --> Helper loaded: url_helper
INFO - 2018-11-26 18:11:51 --> Helper loaded: html_helper
INFO - 2018-11-26 18:11:51 --> Helper loaded: form_helper
INFO - 2018-11-26 18:11:51 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:11:51 --> Helper loaded: date_helper
INFO - 2018-11-26 18:11:51 --> Form Validation Class Initialized
INFO - 2018-11-26 18:11:51 --> Email Class Initialized
DEBUG - 2018-11-26 18:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:11:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:11:51 --> Pagination Class Initialized
INFO - 2018-11-26 18:11:51 --> Database Driver Class Initialized
INFO - 2018-11-26 18:11:51 --> Database Driver Class Initialized
INFO - 2018-11-26 18:11:51 --> Controller Class Initialized
INFO - 2018-11-26 18:11:51 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_print.php
INFO - 2018-11-26 18:11:51 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/prints/report_sales.php
INFO - 2018-11-26 18:11:51 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:11:51 --> Final output sent to browser
DEBUG - 2018-11-26 18:11:51 --> Total execution time: 0.1511
INFO - 2018-11-26 18:22:45 --> Config Class Initialized
INFO - 2018-11-26 18:22:45 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:22:45 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:22:45 --> Utf8 Class Initialized
INFO - 2018-11-26 18:22:45 --> URI Class Initialized
INFO - 2018-11-26 18:22:45 --> Router Class Initialized
INFO - 2018-11-26 18:22:45 --> Output Class Initialized
INFO - 2018-11-26 18:22:45 --> Security Class Initialized
DEBUG - 2018-11-26 18:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:22:45 --> Input Class Initialized
INFO - 2018-11-26 18:22:45 --> Language Class Initialized
INFO - 2018-11-26 18:22:45 --> Loader Class Initialized
INFO - 2018-11-26 18:22:45 --> Helper loaded: url_helper
INFO - 2018-11-26 18:22:45 --> Helper loaded: html_helper
INFO - 2018-11-26 18:22:45 --> Helper loaded: form_helper
INFO - 2018-11-26 18:22:45 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:22:45 --> Helper loaded: date_helper
INFO - 2018-11-26 18:22:45 --> Form Validation Class Initialized
INFO - 2018-11-26 18:22:45 --> Email Class Initialized
DEBUG - 2018-11-26 18:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:22:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:22:45 --> Pagination Class Initialized
INFO - 2018-11-26 18:22:45 --> Database Driver Class Initialized
INFO - 2018-11-26 18:22:45 --> Database Driver Class Initialized
INFO - 2018-11-26 18:22:45 --> Controller Class Initialized
INFO - 2018-11-26 18:22:45 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-26 18:22:45 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/report.php
INFO - 2018-11-26 18:22:45 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:22:45 --> Final output sent to browser
DEBUG - 2018-11-26 18:22:45 --> Total execution time: 0.1487
INFO - 2018-11-26 18:22:45 --> Config Class Initialized
INFO - 2018-11-26 18:22:45 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:22:45 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:22:45 --> Utf8 Class Initialized
INFO - 2018-11-26 18:22:45 --> URI Class Initialized
INFO - 2018-11-26 18:22:45 --> Router Class Initialized
INFO - 2018-11-26 18:22:45 --> Output Class Initialized
INFO - 2018-11-26 18:22:45 --> Security Class Initialized
DEBUG - 2018-11-26 18:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:22:45 --> Input Class Initialized
INFO - 2018-11-26 18:22:45 --> Language Class Initialized
INFO - 2018-11-26 18:22:45 --> Loader Class Initialized
INFO - 2018-11-26 18:22:45 --> Helper loaded: url_helper
INFO - 2018-11-26 18:22:45 --> Helper loaded: html_helper
INFO - 2018-11-26 18:22:45 --> Helper loaded: form_helper
INFO - 2018-11-26 18:22:45 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:22:45 --> Helper loaded: date_helper
INFO - 2018-11-26 18:22:45 --> Form Validation Class Initialized
INFO - 2018-11-26 18:22:45 --> Email Class Initialized
DEBUG - 2018-11-26 18:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:22:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:22:45 --> Pagination Class Initialized
INFO - 2018-11-26 18:22:45 --> Database Driver Class Initialized
INFO - 2018-11-26 18:22:45 --> Database Driver Class Initialized
INFO - 2018-11-26 18:22:45 --> Controller Class Initialized
INFO - 2018-11-26 18:22:45 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-26 18:22:45 --> Final output sent to browser
DEBUG - 2018-11-26 18:22:45 --> Total execution time: 0.1568
INFO - 2018-11-26 18:22:52 --> Config Class Initialized
INFO - 2018-11-26 18:22:52 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:22:52 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:22:52 --> Utf8 Class Initialized
INFO - 2018-11-26 18:22:52 --> URI Class Initialized
INFO - 2018-11-26 18:22:52 --> Router Class Initialized
INFO - 2018-11-26 18:22:52 --> Output Class Initialized
INFO - 2018-11-26 18:22:52 --> Security Class Initialized
DEBUG - 2018-11-26 18:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:22:52 --> Input Class Initialized
INFO - 2018-11-26 18:22:52 --> Language Class Initialized
INFO - 2018-11-26 18:22:52 --> Loader Class Initialized
INFO - 2018-11-26 18:22:52 --> Helper loaded: url_helper
INFO - 2018-11-26 18:22:52 --> Helper loaded: html_helper
INFO - 2018-11-26 18:22:52 --> Helper loaded: form_helper
INFO - 2018-11-26 18:22:52 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:22:52 --> Helper loaded: date_helper
INFO - 2018-11-26 18:22:52 --> Form Validation Class Initialized
INFO - 2018-11-26 18:22:52 --> Email Class Initialized
DEBUG - 2018-11-26 18:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:22:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:22:52 --> Pagination Class Initialized
INFO - 2018-11-26 18:22:52 --> Database Driver Class Initialized
INFO - 2018-11-26 18:22:52 --> Database Driver Class Initialized
INFO - 2018-11-26 18:22:52 --> Controller Class Initialized
INFO - 2018-11-26 18:23:24 --> Config Class Initialized
INFO - 2018-11-26 18:23:24 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:23:24 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:23:24 --> Utf8 Class Initialized
INFO - 2018-11-26 18:23:24 --> URI Class Initialized
INFO - 2018-11-26 18:23:24 --> Router Class Initialized
INFO - 2018-11-26 18:23:24 --> Output Class Initialized
INFO - 2018-11-26 18:23:24 --> Security Class Initialized
DEBUG - 2018-11-26 18:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:23:24 --> Input Class Initialized
INFO - 2018-11-26 18:23:24 --> Language Class Initialized
INFO - 2018-11-26 18:23:24 --> Loader Class Initialized
INFO - 2018-11-26 18:23:24 --> Helper loaded: url_helper
INFO - 2018-11-26 18:23:24 --> Helper loaded: html_helper
INFO - 2018-11-26 18:23:24 --> Helper loaded: form_helper
INFO - 2018-11-26 18:23:24 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:23:24 --> Helper loaded: date_helper
INFO - 2018-11-26 18:23:24 --> Form Validation Class Initialized
INFO - 2018-11-26 18:23:24 --> Email Class Initialized
DEBUG - 2018-11-26 18:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:23:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:23:24 --> Pagination Class Initialized
INFO - 2018-11-26 18:23:24 --> Database Driver Class Initialized
INFO - 2018-11-26 18:23:24 --> Database Driver Class Initialized
INFO - 2018-11-26 18:23:24 --> Controller Class Initialized
INFO - 2018-11-26 18:24:11 --> Config Class Initialized
INFO - 2018-11-26 18:24:11 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:24:11 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:24:11 --> Utf8 Class Initialized
INFO - 2018-11-26 18:24:11 --> URI Class Initialized
INFO - 2018-11-26 18:24:11 --> Router Class Initialized
INFO - 2018-11-26 18:24:11 --> Output Class Initialized
INFO - 2018-11-26 18:24:11 --> Security Class Initialized
DEBUG - 2018-11-26 18:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:24:11 --> Input Class Initialized
INFO - 2018-11-26 18:24:11 --> Language Class Initialized
INFO - 2018-11-26 18:24:11 --> Loader Class Initialized
INFO - 2018-11-26 18:24:11 --> Helper loaded: url_helper
INFO - 2018-11-26 18:24:11 --> Helper loaded: html_helper
INFO - 2018-11-26 18:24:11 --> Helper loaded: form_helper
INFO - 2018-11-26 18:24:11 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:24:11 --> Helper loaded: date_helper
INFO - 2018-11-26 18:24:11 --> Form Validation Class Initialized
INFO - 2018-11-26 18:24:11 --> Email Class Initialized
DEBUG - 2018-11-26 18:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:24:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:24:11 --> Pagination Class Initialized
INFO - 2018-11-26 18:24:11 --> Database Driver Class Initialized
INFO - 2018-11-26 18:24:11 --> Database Driver Class Initialized
INFO - 2018-11-26 18:24:11 --> Controller Class Initialized
INFO - 2018-11-26 18:24:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-26 18:24:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/report.php
INFO - 2018-11-26 18:24:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:24:11 --> Final output sent to browser
DEBUG - 2018-11-26 18:24:11 --> Total execution time: 0.1325
INFO - 2018-11-26 18:24:11 --> Config Class Initialized
INFO - 2018-11-26 18:24:11 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:24:11 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:24:11 --> Utf8 Class Initialized
INFO - 2018-11-26 18:24:11 --> URI Class Initialized
INFO - 2018-11-26 18:24:11 --> Router Class Initialized
INFO - 2018-11-26 18:24:11 --> Config Class Initialized
INFO - 2018-11-26 18:24:11 --> Output Class Initialized
INFO - 2018-11-26 18:24:11 --> Hooks Class Initialized
INFO - 2018-11-26 18:24:11 --> Security Class Initialized
DEBUG - 2018-11-26 18:24:11 --> UTF-8 Support Enabled
DEBUG - 2018-11-26 18:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:24:11 --> Utf8 Class Initialized
INFO - 2018-11-26 18:24:11 --> Input Class Initialized
INFO - 2018-11-26 18:24:11 --> URI Class Initialized
INFO - 2018-11-26 18:24:11 --> Language Class Initialized
INFO - 2018-11-26 18:24:11 --> Router Class Initialized
INFO - 2018-11-26 18:24:11 --> Output Class Initialized
INFO - 2018-11-26 18:24:11 --> Loader Class Initialized
INFO - 2018-11-26 18:24:11 --> Security Class Initialized
INFO - 2018-11-26 18:24:11 --> Helper loaded: url_helper
DEBUG - 2018-11-26 18:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:24:11 --> Helper loaded: html_helper
INFO - 2018-11-26 18:24:11 --> Input Class Initialized
INFO - 2018-11-26 18:24:11 --> Language Class Initialized
INFO - 2018-11-26 18:24:11 --> Helper loaded: form_helper
INFO - 2018-11-26 18:24:11 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:24:11 --> Loader Class Initialized
INFO - 2018-11-26 18:24:11 --> Helper loaded: date_helper
INFO - 2018-11-26 18:24:11 --> Helper loaded: url_helper
INFO - 2018-11-26 18:24:11 --> Form Validation Class Initialized
INFO - 2018-11-26 18:24:11 --> Helper loaded: html_helper
INFO - 2018-11-26 18:24:11 --> Helper loaded: form_helper
INFO - 2018-11-26 18:24:11 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:24:11 --> Email Class Initialized
INFO - 2018-11-26 18:24:11 --> Helper loaded: date_helper
DEBUG - 2018-11-26 18:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:24:11 --> Form Validation Class Initialized
INFO - 2018-11-26 18:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:24:11 --> Email Class Initialized
INFO - 2018-11-26 18:24:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:24:11 --> Pagination Class Initialized
DEBUG - 2018-11-26 18:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:24:11 --> Database Driver Class Initialized
INFO - 2018-11-26 18:24:11 --> Database Driver Class Initialized
INFO - 2018-11-26 18:24:11 --> Controller Class Initialized
INFO - 2018-11-26 18:24:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-26 18:24:11 --> Final output sent to browser
DEBUG - 2018-11-26 18:24:11 --> Total execution time: 0.1942
INFO - 2018-11-26 18:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:24:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:24:11 --> Pagination Class Initialized
INFO - 2018-11-26 18:24:11 --> Database Driver Class Initialized
INFO - 2018-11-26 18:24:11 --> Database Driver Class Initialized
INFO - 2018-11-26 18:24:11 --> Controller Class Initialized
INFO - 2018-11-26 18:24:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-26 18:24:11 --> Final output sent to browser
DEBUG - 2018-11-26 18:24:11 --> Total execution time: 0.2488
INFO - 2018-11-26 18:24:18 --> Config Class Initialized
INFO - 2018-11-26 18:24:18 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:24:18 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:24:18 --> Utf8 Class Initialized
INFO - 2018-11-26 18:24:18 --> URI Class Initialized
INFO - 2018-11-26 18:24:18 --> Router Class Initialized
INFO - 2018-11-26 18:24:18 --> Output Class Initialized
INFO - 2018-11-26 18:24:18 --> Security Class Initialized
DEBUG - 2018-11-26 18:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:24:18 --> Input Class Initialized
INFO - 2018-11-26 18:24:18 --> Language Class Initialized
INFO - 2018-11-26 18:24:18 --> Loader Class Initialized
INFO - 2018-11-26 18:24:18 --> Helper loaded: url_helper
INFO - 2018-11-26 18:24:18 --> Helper loaded: html_helper
INFO - 2018-11-26 18:24:18 --> Helper loaded: form_helper
INFO - 2018-11-26 18:24:18 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:24:18 --> Helper loaded: date_helper
INFO - 2018-11-26 18:24:18 --> Form Validation Class Initialized
INFO - 2018-11-26 18:24:18 --> Email Class Initialized
DEBUG - 2018-11-26 18:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:24:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:24:18 --> Pagination Class Initialized
INFO - 2018-11-26 18:24:18 --> Database Driver Class Initialized
INFO - 2018-11-26 18:24:18 --> Database Driver Class Initialized
INFO - 2018-11-26 18:24:18 --> Controller Class Initialized
INFO - 2018-11-26 18:46:54 --> Config Class Initialized
INFO - 2018-11-26 18:46:54 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:46:54 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:46:54 --> Utf8 Class Initialized
INFO - 2018-11-26 18:46:54 --> URI Class Initialized
INFO - 2018-11-26 18:46:54 --> Router Class Initialized
INFO - 2018-11-26 18:46:54 --> Output Class Initialized
INFO - 2018-11-26 18:46:54 --> Security Class Initialized
DEBUG - 2018-11-26 18:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:46:54 --> Input Class Initialized
INFO - 2018-11-26 18:46:54 --> Language Class Initialized
INFO - 2018-11-26 18:46:54 --> Loader Class Initialized
INFO - 2018-11-26 18:46:54 --> Helper loaded: url_helper
INFO - 2018-11-26 18:46:54 --> Helper loaded: html_helper
INFO - 2018-11-26 18:46:54 --> Helper loaded: form_helper
INFO - 2018-11-26 18:46:54 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:46:54 --> Helper loaded: date_helper
INFO - 2018-11-26 18:46:54 --> Form Validation Class Initialized
INFO - 2018-11-26 18:46:54 --> Email Class Initialized
DEBUG - 2018-11-26 18:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:46:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:46:54 --> Pagination Class Initialized
INFO - 2018-11-26 18:46:54 --> Database Driver Class Initialized
INFO - 2018-11-26 18:46:54 --> Database Driver Class Initialized
INFO - 2018-11-26 18:46:54 --> Controller Class Initialized
INFO - 2018-11-26 18:46:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-26 18:46:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/report.php
INFO - 2018-11-26 18:46:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:46:54 --> Final output sent to browser
DEBUG - 2018-11-26 18:46:54 --> Total execution time: 0.1761
INFO - 2018-11-26 18:46:54 --> Config Class Initialized
INFO - 2018-11-26 18:46:54 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:46:54 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:46:54 --> Utf8 Class Initialized
INFO - 2018-11-26 18:46:54 --> URI Class Initialized
INFO - 2018-11-26 18:46:54 --> Router Class Initialized
INFO - 2018-11-26 18:46:54 --> Output Class Initialized
INFO - 2018-11-26 18:46:54 --> Security Class Initialized
DEBUG - 2018-11-26 18:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:46:54 --> Input Class Initialized
INFO - 2018-11-26 18:46:54 --> Language Class Initialized
INFO - 2018-11-26 18:46:54 --> Loader Class Initialized
INFO - 2018-11-26 18:46:54 --> Helper loaded: url_helper
INFO - 2018-11-26 18:46:54 --> Helper loaded: html_helper
INFO - 2018-11-26 18:46:54 --> Helper loaded: form_helper
INFO - 2018-11-26 18:46:54 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:46:54 --> Helper loaded: date_helper
INFO - 2018-11-26 18:46:54 --> Form Validation Class Initialized
INFO - 2018-11-26 18:46:54 --> Email Class Initialized
DEBUG - 2018-11-26 18:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:46:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:46:54 --> Pagination Class Initialized
INFO - 2018-11-26 18:46:54 --> Database Driver Class Initialized
INFO - 2018-11-26 18:46:54 --> Database Driver Class Initialized
INFO - 2018-11-26 18:46:54 --> Controller Class Initialized
INFO - 2018-11-26 18:46:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-26 18:46:54 --> Final output sent to browser
DEBUG - 2018-11-26 18:46:54 --> Total execution time: 0.1697
INFO - 2018-11-26 18:46:56 --> Config Class Initialized
INFO - 2018-11-26 18:46:56 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:46:56 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:46:56 --> Utf8 Class Initialized
INFO - 2018-11-26 18:46:56 --> URI Class Initialized
INFO - 2018-11-26 18:46:56 --> Router Class Initialized
INFO - 2018-11-26 18:46:56 --> Output Class Initialized
INFO - 2018-11-26 18:46:56 --> Security Class Initialized
DEBUG - 2018-11-26 18:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:46:56 --> Input Class Initialized
INFO - 2018-11-26 18:46:56 --> Language Class Initialized
INFO - 2018-11-26 18:46:56 --> Loader Class Initialized
INFO - 2018-11-26 18:46:56 --> Helper loaded: url_helper
INFO - 2018-11-26 18:46:56 --> Helper loaded: html_helper
INFO - 2018-11-26 18:46:56 --> Helper loaded: form_helper
INFO - 2018-11-26 18:46:56 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:46:56 --> Helper loaded: date_helper
INFO - 2018-11-26 18:46:56 --> Form Validation Class Initialized
INFO - 2018-11-26 18:46:56 --> Email Class Initialized
DEBUG - 2018-11-26 18:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:46:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:46:56 --> Pagination Class Initialized
INFO - 2018-11-26 18:46:56 --> Database Driver Class Initialized
INFO - 2018-11-26 18:46:56 --> Database Driver Class Initialized
INFO - 2018-11-26 18:46:56 --> Controller Class Initialized
INFO - 2018-11-26 18:46:56 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-26 18:46:56 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/report.php
INFO - 2018-11-26 18:46:56 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:46:56 --> Final output sent to browser
DEBUG - 2018-11-26 18:46:56 --> Total execution time: 0.1501
INFO - 2018-11-26 18:46:56 --> Config Class Initialized
INFO - 2018-11-26 18:46:56 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:46:56 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:46:56 --> Utf8 Class Initialized
INFO - 2018-11-26 18:46:56 --> URI Class Initialized
INFO - 2018-11-26 18:46:56 --> Router Class Initialized
INFO - 2018-11-26 18:46:56 --> Output Class Initialized
INFO - 2018-11-26 18:46:56 --> Security Class Initialized
DEBUG - 2018-11-26 18:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:46:56 --> Input Class Initialized
INFO - 2018-11-26 18:46:56 --> Language Class Initialized
INFO - 2018-11-26 18:46:56 --> Loader Class Initialized
INFO - 2018-11-26 18:46:56 --> Helper loaded: url_helper
INFO - 2018-11-26 18:46:56 --> Helper loaded: html_helper
INFO - 2018-11-26 18:46:56 --> Helper loaded: form_helper
INFO - 2018-11-26 18:46:56 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:46:56 --> Helper loaded: date_helper
INFO - 2018-11-26 18:46:56 --> Form Validation Class Initialized
INFO - 2018-11-26 18:46:56 --> Email Class Initialized
DEBUG - 2018-11-26 18:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:46:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:46:56 --> Pagination Class Initialized
INFO - 2018-11-26 18:46:56 --> Database Driver Class Initialized
INFO - 2018-11-26 18:46:56 --> Database Driver Class Initialized
INFO - 2018-11-26 18:46:56 --> Controller Class Initialized
INFO - 2018-11-26 18:46:56 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-26 18:46:56 --> Final output sent to browser
DEBUG - 2018-11-26 18:46:56 --> Total execution time: 0.1877
INFO - 2018-11-26 18:47:11 --> Config Class Initialized
INFO - 2018-11-26 18:47:11 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:47:11 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:47:11 --> Utf8 Class Initialized
INFO - 2018-11-26 18:47:11 --> URI Class Initialized
INFO - 2018-11-26 18:47:11 --> Router Class Initialized
INFO - 2018-11-26 18:47:11 --> Output Class Initialized
INFO - 2018-11-26 18:47:11 --> Security Class Initialized
DEBUG - 2018-11-26 18:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:47:11 --> Input Class Initialized
INFO - 2018-11-26 18:47:11 --> Language Class Initialized
INFO - 2018-11-26 18:47:11 --> Loader Class Initialized
INFO - 2018-11-26 18:47:11 --> Helper loaded: url_helper
INFO - 2018-11-26 18:47:11 --> Helper loaded: html_helper
INFO - 2018-11-26 18:47:11 --> Helper loaded: form_helper
INFO - 2018-11-26 18:47:11 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:47:11 --> Helper loaded: date_helper
INFO - 2018-11-26 18:47:11 --> Form Validation Class Initialized
INFO - 2018-11-26 18:47:11 --> Email Class Initialized
DEBUG - 2018-11-26 18:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:47:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:47:11 --> Pagination Class Initialized
INFO - 2018-11-26 18:47:11 --> Database Driver Class Initialized
INFO - 2018-11-26 18:47:11 --> Database Driver Class Initialized
INFO - 2018-11-26 18:47:11 --> Controller Class Initialized
INFO - 2018-11-26 18:47:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_print.php
ERROR - 2018-11-26 18:47:11 --> Severity: Notice --> Undefined variable: collection2 C:\wamp64\www\pridehotel\application\views\app\prints\report_sales.php 80
ERROR - 2018-11-26 18:47:11 --> Severity: Notice --> Undefined variable: collection2 C:\wamp64\www\pridehotel\application\views\app\prints\report_sales.php 125
INFO - 2018-11-26 18:47:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/prints/report_sales.php
INFO - 2018-11-26 18:47:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:47:12 --> Final output sent to browser
DEBUG - 2018-11-26 18:47:12 --> Total execution time: 0.1705
INFO - 2018-11-26 18:48:12 --> Config Class Initialized
INFO - 2018-11-26 18:48:12 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:48:12 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:48:12 --> Utf8 Class Initialized
INFO - 2018-11-26 18:48:12 --> URI Class Initialized
INFO - 2018-11-26 18:48:12 --> Router Class Initialized
INFO - 2018-11-26 18:48:12 --> Output Class Initialized
INFO - 2018-11-26 18:48:12 --> Security Class Initialized
DEBUG - 2018-11-26 18:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:48:12 --> Input Class Initialized
INFO - 2018-11-26 18:48:12 --> Language Class Initialized
INFO - 2018-11-26 18:48:12 --> Loader Class Initialized
INFO - 2018-11-26 18:48:12 --> Helper loaded: url_helper
INFO - 2018-11-26 18:48:12 --> Helper loaded: html_helper
INFO - 2018-11-26 18:48:12 --> Helper loaded: form_helper
INFO - 2018-11-26 18:48:12 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:48:12 --> Helper loaded: date_helper
INFO - 2018-11-26 18:48:12 --> Form Validation Class Initialized
INFO - 2018-11-26 18:48:12 --> Email Class Initialized
DEBUG - 2018-11-26 18:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:48:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:48:12 --> Pagination Class Initialized
INFO - 2018-11-26 18:48:12 --> Database Driver Class Initialized
INFO - 2018-11-26 18:48:12 --> Database Driver Class Initialized
INFO - 2018-11-26 18:48:12 --> Controller Class Initialized
INFO - 2018-11-26 18:48:12 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_print.php
ERROR - 2018-11-26 18:48:12 --> Severity: Notice --> Undefined variable: collection2 C:\wamp64\www\pridehotel\application\views\app\prints\report_sales.php 80
ERROR - 2018-11-26 18:48:12 --> Severity: Notice --> Undefined variable: collection2 C:\wamp64\www\pridehotel\application\views\app\prints\report_sales.php 125
INFO - 2018-11-26 18:48:12 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/prints/report_sales.php
INFO - 2018-11-26 18:48:12 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:48:12 --> Final output sent to browser
DEBUG - 2018-11-26 18:48:12 --> Total execution time: 0.1366
INFO - 2018-11-26 18:49:35 --> Config Class Initialized
INFO - 2018-11-26 18:49:35 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:49:35 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:49:35 --> Utf8 Class Initialized
INFO - 2018-11-26 18:49:35 --> URI Class Initialized
INFO - 2018-11-26 18:49:35 --> Router Class Initialized
INFO - 2018-11-26 18:49:35 --> Output Class Initialized
INFO - 2018-11-26 18:49:35 --> Security Class Initialized
DEBUG - 2018-11-26 18:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:49:35 --> Input Class Initialized
INFO - 2018-11-26 18:49:35 --> Language Class Initialized
INFO - 2018-11-26 18:49:35 --> Loader Class Initialized
INFO - 2018-11-26 18:49:35 --> Helper loaded: url_helper
INFO - 2018-11-26 18:49:35 --> Helper loaded: html_helper
INFO - 2018-11-26 18:49:35 --> Helper loaded: form_helper
INFO - 2018-11-26 18:49:35 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:49:35 --> Helper loaded: date_helper
INFO - 2018-11-26 18:49:35 --> Form Validation Class Initialized
INFO - 2018-11-26 18:49:35 --> Email Class Initialized
DEBUG - 2018-11-26 18:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:49:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:49:35 --> Pagination Class Initialized
INFO - 2018-11-26 18:49:35 --> Database Driver Class Initialized
INFO - 2018-11-26 18:49:35 --> Database Driver Class Initialized
INFO - 2018-11-26 18:49:35 --> Controller Class Initialized
INFO - 2018-11-26 18:49:35 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_print.php
INFO - 2018-11-26 18:49:35 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/prints/report_sales.php
INFO - 2018-11-26 18:49:35 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:49:35 --> Final output sent to browser
DEBUG - 2018-11-26 18:49:35 --> Total execution time: 0.1531
INFO - 2018-11-26 18:49:41 --> Config Class Initialized
INFO - 2018-11-26 18:49:41 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:49:41 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:49:41 --> Utf8 Class Initialized
INFO - 2018-11-26 18:49:41 --> URI Class Initialized
INFO - 2018-11-26 18:49:41 --> Router Class Initialized
INFO - 2018-11-26 18:49:41 --> Output Class Initialized
INFO - 2018-11-26 18:49:41 --> Security Class Initialized
DEBUG - 2018-11-26 18:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:49:41 --> Input Class Initialized
INFO - 2018-11-26 18:49:41 --> Language Class Initialized
INFO - 2018-11-26 18:49:41 --> Loader Class Initialized
INFO - 2018-11-26 18:49:41 --> Helper loaded: url_helper
INFO - 2018-11-26 18:49:41 --> Helper loaded: html_helper
INFO - 2018-11-26 18:49:41 --> Helper loaded: form_helper
INFO - 2018-11-26 18:49:41 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:49:41 --> Helper loaded: date_helper
INFO - 2018-11-26 18:49:41 --> Form Validation Class Initialized
INFO - 2018-11-26 18:49:41 --> Email Class Initialized
DEBUG - 2018-11-26 18:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:49:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:49:41 --> Pagination Class Initialized
INFO - 2018-11-26 18:49:41 --> Database Driver Class Initialized
INFO - 2018-11-26 18:49:41 --> Database Driver Class Initialized
INFO - 2018-11-26 18:49:41 --> Controller Class Initialized
INFO - 2018-11-26 18:49:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-26 18:49:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/report.php
INFO - 2018-11-26 18:49:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:49:41 --> Final output sent to browser
DEBUG - 2018-11-26 18:49:41 --> Total execution time: 0.1401
INFO - 2018-11-26 18:49:41 --> Config Class Initialized
INFO - 2018-11-26 18:49:41 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:49:41 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:49:41 --> Utf8 Class Initialized
INFO - 2018-11-26 18:49:41 --> URI Class Initialized
INFO - 2018-11-26 18:49:41 --> Router Class Initialized
INFO - 2018-11-26 18:49:41 --> Output Class Initialized
INFO - 2018-11-26 18:49:41 --> Security Class Initialized
DEBUG - 2018-11-26 18:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:49:41 --> Input Class Initialized
INFO - 2018-11-26 18:49:41 --> Language Class Initialized
INFO - 2018-11-26 18:49:41 --> Loader Class Initialized
INFO - 2018-11-26 18:49:41 --> Helper loaded: url_helper
INFO - 2018-11-26 18:49:41 --> Helper loaded: html_helper
INFO - 2018-11-26 18:49:41 --> Helper loaded: form_helper
INFO - 2018-11-26 18:49:42 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:49:42 --> Helper loaded: date_helper
INFO - 2018-11-26 18:49:42 --> Form Validation Class Initialized
INFO - 2018-11-26 18:49:42 --> Email Class Initialized
DEBUG - 2018-11-26 18:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:49:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:49:42 --> Pagination Class Initialized
INFO - 2018-11-26 18:49:42 --> Database Driver Class Initialized
INFO - 2018-11-26 18:49:42 --> Database Driver Class Initialized
INFO - 2018-11-26 18:49:42 --> Controller Class Initialized
INFO - 2018-11-26 18:49:42 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-26 18:49:42 --> Final output sent to browser
DEBUG - 2018-11-26 18:49:42 --> Total execution time: 0.1667
INFO - 2018-11-26 18:49:51 --> Config Class Initialized
INFO - 2018-11-26 18:49:51 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:49:51 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:49:51 --> Utf8 Class Initialized
INFO - 2018-11-26 18:49:51 --> URI Class Initialized
INFO - 2018-11-26 18:49:51 --> Router Class Initialized
INFO - 2018-11-26 18:49:51 --> Output Class Initialized
INFO - 2018-11-26 18:49:51 --> Security Class Initialized
DEBUG - 2018-11-26 18:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:49:51 --> Input Class Initialized
INFO - 2018-11-26 18:49:51 --> Language Class Initialized
INFO - 2018-11-26 18:49:51 --> Loader Class Initialized
INFO - 2018-11-26 18:49:51 --> Helper loaded: url_helper
INFO - 2018-11-26 18:49:51 --> Helper loaded: html_helper
INFO - 2018-11-26 18:49:51 --> Helper loaded: form_helper
INFO - 2018-11-26 18:49:51 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:49:51 --> Helper loaded: date_helper
INFO - 2018-11-26 18:49:51 --> Form Validation Class Initialized
INFO - 2018-11-26 18:49:51 --> Email Class Initialized
DEBUG - 2018-11-26 18:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:49:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:49:51 --> Pagination Class Initialized
INFO - 2018-11-26 18:49:51 --> Database Driver Class Initialized
INFO - 2018-11-26 18:49:51 --> Database Driver Class Initialized
INFO - 2018-11-26 18:49:51 --> Controller Class Initialized
INFO - 2018-11-26 18:49:51 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_print.php
INFO - 2018-11-26 18:49:51 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/prints/report.php
INFO - 2018-11-26 18:49:51 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:49:51 --> Final output sent to browser
DEBUG - 2018-11-26 18:49:51 --> Total execution time: 0.1555
INFO - 2018-11-26 18:49:53 --> Config Class Initialized
INFO - 2018-11-26 18:49:53 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:49:53 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:49:53 --> Utf8 Class Initialized
INFO - 2018-11-26 18:49:53 --> URI Class Initialized
INFO - 2018-11-26 18:49:53 --> Router Class Initialized
INFO - 2018-11-26 18:49:53 --> Output Class Initialized
INFO - 2018-11-26 18:49:53 --> Security Class Initialized
DEBUG - 2018-11-26 18:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:49:53 --> Input Class Initialized
INFO - 2018-11-26 18:49:53 --> Language Class Initialized
INFO - 2018-11-26 18:49:53 --> Loader Class Initialized
INFO - 2018-11-26 18:49:53 --> Helper loaded: url_helper
INFO - 2018-11-26 18:49:53 --> Helper loaded: html_helper
INFO - 2018-11-26 18:49:53 --> Helper loaded: form_helper
INFO - 2018-11-26 18:49:53 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:49:53 --> Helper loaded: date_helper
INFO - 2018-11-26 18:49:53 --> Form Validation Class Initialized
INFO - 2018-11-26 18:49:53 --> Email Class Initialized
DEBUG - 2018-11-26 18:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:49:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:49:53 --> Pagination Class Initialized
INFO - 2018-11-26 18:49:53 --> Database Driver Class Initialized
INFO - 2018-11-26 18:49:53 --> Database Driver Class Initialized
INFO - 2018-11-26 18:49:53 --> Controller Class Initialized
INFO - 2018-11-26 18:49:53 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-26 18:49:53 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/report.php
INFO - 2018-11-26 18:49:53 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:49:53 --> Final output sent to browser
DEBUG - 2018-11-26 18:49:53 --> Total execution time: 0.1389
INFO - 2018-11-26 18:49:53 --> Config Class Initialized
INFO - 2018-11-26 18:49:53 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:49:53 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:49:53 --> Utf8 Class Initialized
INFO - 2018-11-26 18:49:53 --> URI Class Initialized
INFO - 2018-11-26 18:49:53 --> Router Class Initialized
INFO - 2018-11-26 18:49:53 --> Output Class Initialized
INFO - 2018-11-26 18:49:53 --> Security Class Initialized
DEBUG - 2018-11-26 18:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:49:53 --> Input Class Initialized
INFO - 2018-11-26 18:49:53 --> Language Class Initialized
INFO - 2018-11-26 18:49:53 --> Loader Class Initialized
INFO - 2018-11-26 18:49:53 --> Helper loaded: url_helper
INFO - 2018-11-26 18:49:53 --> Helper loaded: html_helper
INFO - 2018-11-26 18:49:53 --> Helper loaded: form_helper
INFO - 2018-11-26 18:49:53 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:49:54 --> Helper loaded: date_helper
INFO - 2018-11-26 18:49:54 --> Form Validation Class Initialized
INFO - 2018-11-26 18:49:54 --> Email Class Initialized
DEBUG - 2018-11-26 18:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:49:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:49:54 --> Pagination Class Initialized
INFO - 2018-11-26 18:49:54 --> Database Driver Class Initialized
INFO - 2018-11-26 18:49:54 --> Database Driver Class Initialized
INFO - 2018-11-26 18:49:54 --> Controller Class Initialized
INFO - 2018-11-26 18:49:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-26 18:49:54 --> Final output sent to browser
DEBUG - 2018-11-26 18:49:54 --> Total execution time: 0.1720
INFO - 2018-11-26 18:50:08 --> Config Class Initialized
INFO - 2018-11-26 18:50:08 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:50:08 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:50:08 --> Utf8 Class Initialized
INFO - 2018-11-26 18:50:08 --> URI Class Initialized
INFO - 2018-11-26 18:50:08 --> Router Class Initialized
INFO - 2018-11-26 18:50:08 --> Output Class Initialized
INFO - 2018-11-26 18:50:08 --> Security Class Initialized
DEBUG - 2018-11-26 18:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:50:08 --> Input Class Initialized
INFO - 2018-11-26 18:50:08 --> Language Class Initialized
INFO - 2018-11-26 18:50:08 --> Loader Class Initialized
INFO - 2018-11-26 18:50:08 --> Helper loaded: url_helper
INFO - 2018-11-26 18:50:08 --> Helper loaded: html_helper
INFO - 2018-11-26 18:50:08 --> Helper loaded: form_helper
INFO - 2018-11-26 18:50:08 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:50:08 --> Helper loaded: date_helper
INFO - 2018-11-26 18:50:08 --> Form Validation Class Initialized
INFO - 2018-11-26 18:50:08 --> Email Class Initialized
DEBUG - 2018-11-26 18:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:50:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:50:08 --> Pagination Class Initialized
INFO - 2018-11-26 18:50:08 --> Database Driver Class Initialized
INFO - 2018-11-26 18:50:08 --> Database Driver Class Initialized
INFO - 2018-11-26 18:50:08 --> Controller Class Initialized
INFO - 2018-11-26 18:50:08 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_print.php
INFO - 2018-11-26 18:50:08 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/prints/report_sales.php
INFO - 2018-11-26 18:50:08 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:50:08 --> Final output sent to browser
DEBUG - 2018-11-26 18:50:08 --> Total execution time: 0.1798
INFO - 2018-11-26 18:50:22 --> Config Class Initialized
INFO - 2018-11-26 18:50:22 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:50:22 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:50:22 --> Utf8 Class Initialized
INFO - 2018-11-26 18:50:22 --> URI Class Initialized
INFO - 2018-11-26 18:50:22 --> Router Class Initialized
INFO - 2018-11-26 18:50:22 --> Output Class Initialized
INFO - 2018-11-26 18:50:22 --> Security Class Initialized
DEBUG - 2018-11-26 18:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:50:22 --> Input Class Initialized
INFO - 2018-11-26 18:50:22 --> Language Class Initialized
INFO - 2018-11-26 18:50:22 --> Loader Class Initialized
INFO - 2018-11-26 18:50:22 --> Helper loaded: url_helper
INFO - 2018-11-26 18:50:22 --> Helper loaded: html_helper
INFO - 2018-11-26 18:50:22 --> Helper loaded: form_helper
INFO - 2018-11-26 18:50:22 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:50:22 --> Helper loaded: date_helper
INFO - 2018-11-26 18:50:22 --> Form Validation Class Initialized
INFO - 2018-11-26 18:50:22 --> Email Class Initialized
DEBUG - 2018-11-26 18:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:50:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:50:22 --> Pagination Class Initialized
INFO - 2018-11-26 18:50:22 --> Database Driver Class Initialized
INFO - 2018-11-26 18:50:22 --> Database Driver Class Initialized
INFO - 2018-11-26 18:50:22 --> Controller Class Initialized
INFO - 2018-11-26 18:50:22 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-26 18:50:22 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/report.php
INFO - 2018-11-26 18:50:22 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-26 18:50:23 --> Final output sent to browser
DEBUG - 2018-11-26 18:50:23 --> Total execution time: 0.1379
INFO - 2018-11-26 18:50:23 --> Config Class Initialized
INFO - 2018-11-26 18:50:23 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:50:23 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:50:23 --> Utf8 Class Initialized
INFO - 2018-11-26 18:50:23 --> URI Class Initialized
INFO - 2018-11-26 18:50:23 --> Router Class Initialized
INFO - 2018-11-26 18:50:23 --> Output Class Initialized
INFO - 2018-11-26 18:50:23 --> Security Class Initialized
DEBUG - 2018-11-26 18:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:50:23 --> Input Class Initialized
INFO - 2018-11-26 18:50:23 --> Language Class Initialized
INFO - 2018-11-26 18:50:23 --> Loader Class Initialized
INFO - 2018-11-26 18:50:23 --> Helper loaded: url_helper
INFO - 2018-11-26 18:50:23 --> Helper loaded: html_helper
INFO - 2018-11-26 18:50:23 --> Helper loaded: form_helper
INFO - 2018-11-26 18:50:23 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:50:23 --> Helper loaded: date_helper
INFO - 2018-11-26 18:50:23 --> Form Validation Class Initialized
INFO - 2018-11-26 18:50:23 --> Email Class Initialized
DEBUG - 2018-11-26 18:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:50:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:50:23 --> Pagination Class Initialized
INFO - 2018-11-26 18:50:23 --> Database Driver Class Initialized
INFO - 2018-11-26 18:50:23 --> Database Driver Class Initialized
INFO - 2018-11-26 18:50:23 --> Controller Class Initialized
INFO - 2018-11-26 18:50:23 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-26 18:50:23 --> Final output sent to browser
DEBUG - 2018-11-26 18:50:23 --> Total execution time: 0.1491
INFO - 2018-11-26 18:55:29 --> Config Class Initialized
INFO - 2018-11-26 18:55:29 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:55:29 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:55:29 --> Utf8 Class Initialized
INFO - 2018-11-26 18:55:29 --> URI Class Initialized
INFO - 2018-11-26 18:55:29 --> Router Class Initialized
INFO - 2018-11-26 18:55:29 --> Output Class Initialized
INFO - 2018-11-26 18:55:29 --> Security Class Initialized
DEBUG - 2018-11-26 18:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:55:29 --> Input Class Initialized
INFO - 2018-11-26 18:55:29 --> Language Class Initialized
INFO - 2018-11-26 18:55:29 --> Loader Class Initialized
INFO - 2018-11-26 18:55:29 --> Helper loaded: url_helper
INFO - 2018-11-26 18:55:29 --> Helper loaded: html_helper
INFO - 2018-11-26 18:55:29 --> Helper loaded: form_helper
INFO - 2018-11-26 18:55:29 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:55:29 --> Helper loaded: date_helper
INFO - 2018-11-26 18:55:29 --> Form Validation Class Initialized
INFO - 2018-11-26 18:55:29 --> Email Class Initialized
DEBUG - 2018-11-26 18:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:55:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:55:29 --> Pagination Class Initialized
INFO - 2018-11-26 18:55:29 --> Database Driver Class Initialized
INFO - 2018-11-26 18:55:29 --> Database Driver Class Initialized
INFO - 2018-11-26 18:55:29 --> Controller Class Initialized
INFO - 2018-11-26 18:55:29 --> Config Class Initialized
INFO - 2018-11-26 18:55:29 --> Hooks Class Initialized
DEBUG - 2018-11-26 18:55:29 --> UTF-8 Support Enabled
INFO - 2018-11-26 18:55:29 --> Utf8 Class Initialized
INFO - 2018-11-26 18:55:29 --> URI Class Initialized
INFO - 2018-11-26 18:55:29 --> Router Class Initialized
INFO - 2018-11-26 18:55:29 --> Output Class Initialized
INFO - 2018-11-26 18:55:29 --> Security Class Initialized
DEBUG - 2018-11-26 18:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 18:55:29 --> Input Class Initialized
INFO - 2018-11-26 18:55:29 --> Language Class Initialized
INFO - 2018-11-26 18:55:29 --> Loader Class Initialized
INFO - 2018-11-26 18:55:29 --> Helper loaded: url_helper
INFO - 2018-11-26 18:55:29 --> Helper loaded: html_helper
INFO - 2018-11-26 18:55:29 --> Helper loaded: form_helper
INFO - 2018-11-26 18:55:29 --> Helper loaded: cookie_helper
INFO - 2018-11-26 18:55:29 --> Helper loaded: date_helper
INFO - 2018-11-26 18:55:29 --> Form Validation Class Initialized
INFO - 2018-11-26 18:55:29 --> Email Class Initialized
DEBUG - 2018-11-26 18:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 18:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 18:55:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 18:55:29 --> Pagination Class Initialized
INFO - 2018-11-26 18:55:29 --> Database Driver Class Initialized
INFO - 2018-11-26 18:55:29 --> Database Driver Class Initialized
INFO - 2018-11-26 18:55:29 --> Controller Class Initialized
INFO - 2018-11-26 18:55:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-26 18:55:29 --> Final output sent to browser
DEBUG - 2018-11-26 18:55:29 --> Total execution time: 0.1086
INFO - 2018-11-26 20:18:57 --> Config Class Initialized
INFO - 2018-11-26 20:18:57 --> Hooks Class Initialized
DEBUG - 2018-11-26 20:18:57 --> UTF-8 Support Enabled
INFO - 2018-11-26 20:18:57 --> Utf8 Class Initialized
INFO - 2018-11-26 20:18:57 --> URI Class Initialized
INFO - 2018-11-26 20:18:57 --> Router Class Initialized
INFO - 2018-11-26 20:18:58 --> Output Class Initialized
INFO - 2018-11-26 20:18:58 --> Security Class Initialized
DEBUG - 2018-11-26 20:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 20:18:58 --> Input Class Initialized
INFO - 2018-11-26 20:18:58 --> Language Class Initialized
INFO - 2018-11-26 20:18:58 --> Loader Class Initialized
INFO - 2018-11-26 20:18:58 --> Helper loaded: url_helper
INFO - 2018-11-26 20:18:58 --> Helper loaded: html_helper
INFO - 2018-11-26 20:18:58 --> Helper loaded: form_helper
INFO - 2018-11-26 20:18:58 --> Helper loaded: cookie_helper
INFO - 2018-11-26 20:18:58 --> Helper loaded: date_helper
INFO - 2018-11-26 20:18:58 --> Form Validation Class Initialized
INFO - 2018-11-26 20:18:58 --> Email Class Initialized
DEBUG - 2018-11-26 20:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 20:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 20:18:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 20:18:58 --> Pagination Class Initialized
INFO - 2018-11-26 20:18:59 --> Database Driver Class Initialized
INFO - 2018-11-26 20:18:59 --> Database Driver Class Initialized
INFO - 2018-11-26 20:18:59 --> Controller Class Initialized
INFO - 2018-11-26 20:18:59 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-26 20:18:59 --> Final output sent to browser
DEBUG - 2018-11-26 20:18:59 --> Total execution time: 1.9001
INFO - 2018-11-26 20:19:03 --> Config Class Initialized
INFO - 2018-11-26 20:19:03 --> Hooks Class Initialized
DEBUG - 2018-11-26 20:19:03 --> UTF-8 Support Enabled
INFO - 2018-11-26 20:19:03 --> Utf8 Class Initialized
INFO - 2018-11-26 20:19:03 --> URI Class Initialized
INFO - 2018-11-26 20:19:03 --> Router Class Initialized
INFO - 2018-11-26 20:19:03 --> Output Class Initialized
INFO - 2018-11-26 20:19:03 --> Security Class Initialized
DEBUG - 2018-11-26 20:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 20:19:03 --> Input Class Initialized
INFO - 2018-11-26 20:19:03 --> Language Class Initialized
INFO - 2018-11-26 20:19:03 --> Loader Class Initialized
INFO - 2018-11-26 20:19:03 --> Helper loaded: url_helper
INFO - 2018-11-26 20:19:03 --> Helper loaded: html_helper
INFO - 2018-11-26 20:19:03 --> Helper loaded: form_helper
INFO - 2018-11-26 20:19:03 --> Helper loaded: cookie_helper
INFO - 2018-11-26 20:19:03 --> Helper loaded: date_helper
INFO - 2018-11-26 20:19:03 --> Form Validation Class Initialized
INFO - 2018-11-26 20:19:03 --> Email Class Initialized
DEBUG - 2018-11-26 20:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 20:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 20:19:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 20:19:03 --> Pagination Class Initialized
INFO - 2018-11-26 20:19:03 --> Database Driver Class Initialized
INFO - 2018-11-26 20:19:03 --> Database Driver Class Initialized
INFO - 2018-11-26 20:19:03 --> Controller Class Initialized
INFO - 2018-11-26 20:19:03 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-26 20:19:03 --> Final output sent to browser
DEBUG - 2018-11-26 20:19:03 --> Total execution time: 0.2454
INFO - 2018-11-26 20:19:15 --> Config Class Initialized
INFO - 2018-11-26 20:19:15 --> Hooks Class Initialized
DEBUG - 2018-11-26 20:19:15 --> UTF-8 Support Enabled
INFO - 2018-11-26 20:19:15 --> Utf8 Class Initialized
INFO - 2018-11-26 20:19:15 --> URI Class Initialized
INFO - 2018-11-26 20:19:15 --> Router Class Initialized
INFO - 2018-11-26 20:19:15 --> Output Class Initialized
INFO - 2018-11-26 20:19:15 --> Security Class Initialized
DEBUG - 2018-11-26 20:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-26 20:19:15 --> Input Class Initialized
INFO - 2018-11-26 20:19:15 --> Language Class Initialized
INFO - 2018-11-26 20:19:15 --> Loader Class Initialized
INFO - 2018-11-26 20:19:15 --> Helper loaded: url_helper
INFO - 2018-11-26 20:19:15 --> Helper loaded: html_helper
INFO - 2018-11-26 20:19:15 --> Helper loaded: form_helper
INFO - 2018-11-26 20:19:15 --> Helper loaded: cookie_helper
INFO - 2018-11-26 20:19:15 --> Helper loaded: date_helper
INFO - 2018-11-26 20:19:15 --> Form Validation Class Initialized
INFO - 2018-11-26 20:19:15 --> Email Class Initialized
DEBUG - 2018-11-26 20:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-26 20:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-26 20:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-26 20:19:15 --> Pagination Class Initialized
INFO - 2018-11-26 20:19:16 --> Database Driver Class Initialized
INFO - 2018-11-26 20:19:16 --> Database Driver Class Initialized
INFO - 2018-11-26 20:19:16 --> Controller Class Initialized
DEBUG - 2018-11-26 20:19:16 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-26 20:19:16 --> Helper loaded: inflector_helper
INFO - 2018-11-26 20:19:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-26 20:19:16 --> Final output sent to browser
DEBUG - 2018-11-26 20:19:16 --> Total execution time: 0.5192
