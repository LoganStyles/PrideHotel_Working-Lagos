<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-08-27 09:13:50 --> Config Class Initialized
INFO - 2019-08-27 09:13:50 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:13:50 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:13:50 --> Utf8 Class Initialized
INFO - 2019-08-27 09:13:50 --> URI Class Initialized
INFO - 2019-08-27 09:13:50 --> Router Class Initialized
INFO - 2019-08-27 09:13:51 --> Output Class Initialized
INFO - 2019-08-27 09:13:51 --> Security Class Initialized
DEBUG - 2019-08-27 09:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:13:51 --> Input Class Initialized
INFO - 2019-08-27 09:13:51 --> Language Class Initialized
INFO - 2019-08-27 09:13:51 --> Loader Class Initialized
INFO - 2019-08-27 09:13:51 --> Helper loaded: url_helper
INFO - 2019-08-27 09:13:51 --> Helper loaded: html_helper
INFO - 2019-08-27 09:13:52 --> Helper loaded: form_helper
INFO - 2019-08-27 09:13:52 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:13:52 --> Helper loaded: date_helper
INFO - 2019-08-27 09:13:52 --> Form Validation Class Initialized
INFO - 2019-08-27 09:13:52 --> Email Class Initialized
DEBUG - 2019-08-27 09:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:13:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:13:52 --> Pagination Class Initialized
INFO - 2019-08-27 09:13:53 --> Database Driver Class Initialized
INFO - 2019-08-27 09:13:53 --> Database Driver Class Initialized
INFO - 2019-08-27 09:13:55 --> Language file loaded: language/english/db_lang.php
INFO - 2019-08-27 09:14:45 --> Config Class Initialized
INFO - 2019-08-27 09:14:45 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:14:45 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:14:45 --> Utf8 Class Initialized
INFO - 2019-08-27 09:14:45 --> URI Class Initialized
INFO - 2019-08-27 09:14:45 --> Router Class Initialized
INFO - 2019-08-27 09:14:45 --> Output Class Initialized
INFO - 2019-08-27 09:14:45 --> Security Class Initialized
DEBUG - 2019-08-27 09:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:14:45 --> Input Class Initialized
INFO - 2019-08-27 09:14:45 --> Language Class Initialized
INFO - 2019-08-27 09:14:45 --> Loader Class Initialized
INFO - 2019-08-27 09:14:45 --> Helper loaded: url_helper
INFO - 2019-08-27 09:14:45 --> Helper loaded: html_helper
INFO - 2019-08-27 09:14:45 --> Helper loaded: form_helper
INFO - 2019-08-27 09:14:46 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:14:46 --> Helper loaded: date_helper
INFO - 2019-08-27 09:14:46 --> Form Validation Class Initialized
INFO - 2019-08-27 09:14:46 --> Email Class Initialized
DEBUG - 2019-08-27 09:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:14:46 --> Pagination Class Initialized
INFO - 2019-08-27 09:14:46 --> Database Driver Class Initialized
INFO - 2019-08-27 09:14:46 --> Database Driver Class Initialized
INFO - 2019-08-27 09:14:46 --> Controller Class Initialized
INFO - 2019-08-27 09:14:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-27 09:14:46 --> Final output sent to browser
DEBUG - 2019-08-27 09:14:46 --> Total execution time: 1.2614
INFO - 2019-08-27 09:14:47 --> Config Class Initialized
INFO - 2019-08-27 09:14:47 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:14:47 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:14:47 --> Utf8 Class Initialized
INFO - 2019-08-27 09:14:48 --> URI Class Initialized
INFO - 2019-08-27 09:14:48 --> Router Class Initialized
INFO - 2019-08-27 09:14:48 --> Output Class Initialized
INFO - 2019-08-27 09:14:48 --> Security Class Initialized
DEBUG - 2019-08-27 09:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:14:48 --> Input Class Initialized
INFO - 2019-08-27 09:14:48 --> Language Class Initialized
INFO - 2019-08-27 09:14:48 --> Loader Class Initialized
INFO - 2019-08-27 09:14:48 --> Helper loaded: url_helper
INFO - 2019-08-27 09:14:48 --> Helper loaded: html_helper
INFO - 2019-08-27 09:14:48 --> Helper loaded: form_helper
INFO - 2019-08-27 09:14:48 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:14:48 --> Helper loaded: date_helper
INFO - 2019-08-27 09:14:48 --> Form Validation Class Initialized
INFO - 2019-08-27 09:14:48 --> Email Class Initialized
DEBUG - 2019-08-27 09:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:14:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:14:48 --> Pagination Class Initialized
INFO - 2019-08-27 09:14:48 --> Database Driver Class Initialized
INFO - 2019-08-27 09:14:48 --> Database Driver Class Initialized
INFO - 2019-08-27 09:14:48 --> Controller Class Initialized
INFO - 2019-08-27 09:14:48 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-27 09:14:48 --> Final output sent to browser
DEBUG - 2019-08-27 09:14:48 --> Total execution time: 0.9145
INFO - 2019-08-27 09:17:32 --> Config Class Initialized
INFO - 2019-08-27 09:17:32 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:17:32 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:17:32 --> Utf8 Class Initialized
INFO - 2019-08-27 09:17:32 --> URI Class Initialized
INFO - 2019-08-27 09:17:32 --> Router Class Initialized
INFO - 2019-08-27 09:17:32 --> Output Class Initialized
INFO - 2019-08-27 09:17:33 --> Security Class Initialized
DEBUG - 2019-08-27 09:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:17:33 --> Input Class Initialized
INFO - 2019-08-27 09:17:33 --> Language Class Initialized
INFO - 2019-08-27 09:17:33 --> Loader Class Initialized
INFO - 2019-08-27 09:17:33 --> Helper loaded: url_helper
INFO - 2019-08-27 09:17:33 --> Helper loaded: html_helper
INFO - 2019-08-27 09:17:33 --> Helper loaded: form_helper
INFO - 2019-08-27 09:17:33 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:17:33 --> Helper loaded: date_helper
INFO - 2019-08-27 09:17:34 --> Form Validation Class Initialized
INFO - 2019-08-27 09:17:34 --> Email Class Initialized
DEBUG - 2019-08-27 09:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:17:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:17:34 --> Pagination Class Initialized
INFO - 2019-08-27 09:17:35 --> Database Driver Class Initialized
INFO - 2019-08-27 09:17:35 --> Database Driver Class Initialized
INFO - 2019-08-27 09:17:35 --> Controller Class Initialized
INFO - 2019-08-27 09:17:35 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-27 09:17:35 --> Final output sent to browser
DEBUG - 2019-08-27 09:17:35 --> Total execution time: 3.9150
INFO - 2019-08-27 09:17:50 --> Config Class Initialized
INFO - 2019-08-27 09:17:50 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:17:51 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:17:51 --> Utf8 Class Initialized
INFO - 2019-08-27 09:17:51 --> URI Class Initialized
INFO - 2019-08-27 09:17:51 --> Router Class Initialized
INFO - 2019-08-27 09:17:51 --> Output Class Initialized
INFO - 2019-08-27 09:17:51 --> Security Class Initialized
DEBUG - 2019-08-27 09:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:17:51 --> Input Class Initialized
INFO - 2019-08-27 09:17:51 --> Language Class Initialized
INFO - 2019-08-27 09:17:51 --> Loader Class Initialized
INFO - 2019-08-27 09:17:51 --> Helper loaded: url_helper
INFO - 2019-08-27 09:17:51 --> Helper loaded: html_helper
INFO - 2019-08-27 09:17:51 --> Helper loaded: form_helper
INFO - 2019-08-27 09:17:51 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:17:51 --> Helper loaded: date_helper
INFO - 2019-08-27 09:17:51 --> Form Validation Class Initialized
INFO - 2019-08-27 09:17:51 --> Email Class Initialized
DEBUG - 2019-08-27 09:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:17:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:17:51 --> Pagination Class Initialized
INFO - 2019-08-27 09:17:51 --> Database Driver Class Initialized
INFO - 2019-08-27 09:17:51 --> Database Driver Class Initialized
INFO - 2019-08-27 09:17:51 --> Controller Class Initialized
INFO - 2019-08-27 09:17:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-27 09:17:52 --> Config Class Initialized
INFO - 2019-08-27 09:17:52 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:17:52 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:17:52 --> Utf8 Class Initialized
INFO - 2019-08-27 09:17:52 --> URI Class Initialized
INFO - 2019-08-27 09:17:52 --> Router Class Initialized
INFO - 2019-08-27 09:17:52 --> Output Class Initialized
INFO - 2019-08-27 09:17:52 --> Security Class Initialized
DEBUG - 2019-08-27 09:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:17:52 --> Input Class Initialized
INFO - 2019-08-27 09:17:52 --> Language Class Initialized
INFO - 2019-08-27 09:17:52 --> Loader Class Initialized
INFO - 2019-08-27 09:17:52 --> Helper loaded: url_helper
INFO - 2019-08-27 09:17:52 --> Helper loaded: html_helper
INFO - 2019-08-27 09:17:52 --> Helper loaded: form_helper
INFO - 2019-08-27 09:17:52 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:17:52 --> Helper loaded: date_helper
INFO - 2019-08-27 09:17:52 --> Form Validation Class Initialized
INFO - 2019-08-27 09:17:52 --> Email Class Initialized
DEBUG - 2019-08-27 09:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:17:52 --> Pagination Class Initialized
INFO - 2019-08-27 09:17:52 --> Database Driver Class Initialized
INFO - 2019-08-27 09:17:52 --> Database Driver Class Initialized
INFO - 2019-08-27 09:17:52 --> Controller Class Initialized
INFO - 2019-08-27 09:17:53 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 09:17:53 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-27 09:17:53 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 09:17:53 --> Final output sent to browser
DEBUG - 2019-08-27 09:17:53 --> Total execution time: 1.7584
INFO - 2019-08-27 09:17:54 --> Config Class Initialized
INFO - 2019-08-27 09:17:54 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:17:54 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:17:54 --> Utf8 Class Initialized
INFO - 2019-08-27 09:17:54 --> URI Class Initialized
INFO - 2019-08-27 09:17:54 --> Router Class Initialized
INFO - 2019-08-27 09:17:54 --> Config Class Initialized
INFO - 2019-08-27 09:17:54 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:17:54 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:17:54 --> Utf8 Class Initialized
INFO - 2019-08-27 09:17:54 --> URI Class Initialized
INFO - 2019-08-27 09:17:55 --> Router Class Initialized
INFO - 2019-08-27 09:17:55 --> Output Class Initialized
INFO - 2019-08-27 09:17:55 --> Security Class Initialized
INFO - 2019-08-27 09:17:55 --> Output Class Initialized
INFO - 2019-08-27 09:17:55 --> Security Class Initialized
DEBUG - 2019-08-27 09:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-27 09:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:17:55 --> Input Class Initialized
INFO - 2019-08-27 09:17:55 --> Input Class Initialized
INFO - 2019-08-27 09:17:55 --> Language Class Initialized
INFO - 2019-08-27 09:17:55 --> Language Class Initialized
INFO - 2019-08-27 09:17:55 --> Loader Class Initialized
INFO - 2019-08-27 09:17:55 --> Helper loaded: url_helper
INFO - 2019-08-27 09:17:55 --> Loader Class Initialized
INFO - 2019-08-27 09:17:55 --> Helper loaded: html_helper
INFO - 2019-08-27 09:17:55 --> Helper loaded: url_helper
INFO - 2019-08-27 09:17:55 --> Helper loaded: form_helper
INFO - 2019-08-27 09:17:55 --> Helper loaded: html_helper
INFO - 2019-08-27 09:17:55 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:17:55 --> Helper loaded: form_helper
INFO - 2019-08-27 09:17:55 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:17:55 --> Helper loaded: date_helper
INFO - 2019-08-27 09:17:55 --> Helper loaded: date_helper
INFO - 2019-08-27 09:17:55 --> Form Validation Class Initialized
INFO - 2019-08-27 09:17:55 --> Form Validation Class Initialized
INFO - 2019-08-27 09:17:55 --> Email Class Initialized
INFO - 2019-08-27 09:17:55 --> Email Class Initialized
DEBUG - 2019-08-27 09:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-27 09:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:17:55 --> Pagination Class Initialized
INFO - 2019-08-27 09:17:55 --> Database Driver Class Initialized
INFO - 2019-08-27 09:17:56 --> Database Driver Class Initialized
INFO - 2019-08-27 09:17:56 --> Controller Class Initialized
INFO - 2019-08-27 09:17:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 09:17:56 --> Final output sent to browser
DEBUG - 2019-08-27 09:17:56 --> Total execution time: 1.5525
INFO - 2019-08-27 09:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:17:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:17:56 --> Pagination Class Initialized
INFO - 2019-08-27 09:17:56 --> Database Driver Class Initialized
INFO - 2019-08-27 09:17:56 --> Database Driver Class Initialized
INFO - 2019-08-27 09:17:56 --> Controller Class Initialized
INFO - 2019-08-27 09:17:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 09:17:56 --> Final output sent to browser
DEBUG - 2019-08-27 09:17:56 --> Total execution time: 1.8197
INFO - 2019-08-27 09:56:53 --> Config Class Initialized
INFO - 2019-08-27 09:56:53 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:56:53 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:56:53 --> Utf8 Class Initialized
INFO - 2019-08-27 09:56:53 --> URI Class Initialized
INFO - 2019-08-27 09:56:53 --> Router Class Initialized
INFO - 2019-08-27 09:56:53 --> Output Class Initialized
INFO - 2019-08-27 09:56:53 --> Security Class Initialized
DEBUG - 2019-08-27 09:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:56:54 --> Input Class Initialized
INFO - 2019-08-27 09:56:54 --> Language Class Initialized
INFO - 2019-08-27 09:56:54 --> Loader Class Initialized
INFO - 2019-08-27 09:56:54 --> Helper loaded: url_helper
INFO - 2019-08-27 09:56:54 --> Helper loaded: html_helper
INFO - 2019-08-27 09:56:54 --> Helper loaded: form_helper
INFO - 2019-08-27 09:56:54 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:56:54 --> Helper loaded: date_helper
INFO - 2019-08-27 09:56:54 --> Form Validation Class Initialized
INFO - 2019-08-27 09:56:54 --> Email Class Initialized
DEBUG - 2019-08-27 09:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:56:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:56:55 --> Pagination Class Initialized
INFO - 2019-08-27 09:56:55 --> Database Driver Class Initialized
INFO - 2019-08-27 09:56:55 --> Database Driver Class Initialized
INFO - 2019-08-27 09:56:55 --> Controller Class Initialized
INFO - 2019-08-27 09:56:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 09:56:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-27 09:56:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-27 09:56:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 09:56:56 --> Final output sent to browser
DEBUG - 2019-08-27 09:56:56 --> Total execution time: 3.5822
INFO - 2019-08-27 09:56:57 --> Config Class Initialized
INFO - 2019-08-27 09:56:57 --> Config Class Initialized
INFO - 2019-08-27 09:56:57 --> Hooks Class Initialized
INFO - 2019-08-27 09:56:57 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:56:57 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:56:57 --> Utf8 Class Initialized
INFO - 2019-08-27 09:56:57 --> URI Class Initialized
INFO - 2019-08-27 09:56:57 --> Router Class Initialized
INFO - 2019-08-27 09:56:57 --> Output Class Initialized
DEBUG - 2019-08-27 09:56:57 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:56:57 --> Utf8 Class Initialized
INFO - 2019-08-27 09:56:57 --> URI Class Initialized
INFO - 2019-08-27 09:56:57 --> Security Class Initialized
DEBUG - 2019-08-27 09:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:56:57 --> Input Class Initialized
INFO - 2019-08-27 09:56:57 --> Language Class Initialized
INFO - 2019-08-27 09:56:57 --> Router Class Initialized
INFO - 2019-08-27 09:56:57 --> Output Class Initialized
INFO - 2019-08-27 09:56:57 --> Security Class Initialized
DEBUG - 2019-08-27 09:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:56:58 --> Input Class Initialized
INFO - 2019-08-27 09:56:58 --> Language Class Initialized
INFO - 2019-08-27 09:56:58 --> Loader Class Initialized
INFO - 2019-08-27 09:56:58 --> Loader Class Initialized
INFO - 2019-08-27 09:56:58 --> Helper loaded: url_helper
INFO - 2019-08-27 09:56:58 --> Helper loaded: url_helper
INFO - 2019-08-27 09:56:58 --> Helper loaded: html_helper
INFO - 2019-08-27 09:56:58 --> Helper loaded: html_helper
INFO - 2019-08-27 09:56:58 --> Helper loaded: form_helper
INFO - 2019-08-27 09:56:58 --> Helper loaded: form_helper
INFO - 2019-08-27 09:56:58 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:56:58 --> Helper loaded: date_helper
INFO - 2019-08-27 09:56:58 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:56:58 --> Helper loaded: date_helper
INFO - 2019-08-27 09:56:58 --> Form Validation Class Initialized
INFO - 2019-08-27 09:56:58 --> Form Validation Class Initialized
INFO - 2019-08-27 09:56:58 --> Email Class Initialized
INFO - 2019-08-27 09:56:58 --> Email Class Initialized
DEBUG - 2019-08-27 09:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-27 09:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:56:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:56:58 --> Pagination Class Initialized
INFO - 2019-08-27 09:56:58 --> Database Driver Class Initialized
INFO - 2019-08-27 09:56:58 --> Database Driver Class Initialized
INFO - 2019-08-27 09:56:58 --> Controller Class Initialized
INFO - 2019-08-27 09:56:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 09:56:59 --> Final output sent to browser
DEBUG - 2019-08-27 09:56:59 --> Total execution time: 1.8583
INFO - 2019-08-27 09:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:56:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:56:59 --> Pagination Class Initialized
INFO - 2019-08-27 09:56:59 --> Database Driver Class Initialized
INFO - 2019-08-27 09:56:59 --> Database Driver Class Initialized
INFO - 2019-08-27 09:56:59 --> Controller Class Initialized
INFO - 2019-08-27 09:56:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 09:56:59 --> Final output sent to browser
DEBUG - 2019-08-27 09:56:59 --> Total execution time: 2.1567
INFO - 2019-08-27 09:57:39 --> Config Class Initialized
INFO - 2019-08-27 09:57:39 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:57:39 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:57:39 --> Utf8 Class Initialized
INFO - 2019-08-27 09:57:39 --> URI Class Initialized
INFO - 2019-08-27 09:57:39 --> Router Class Initialized
INFO - 2019-08-27 09:57:39 --> Output Class Initialized
INFO - 2019-08-27 09:57:39 --> Security Class Initialized
DEBUG - 2019-08-27 09:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:57:39 --> Input Class Initialized
INFO - 2019-08-27 09:57:39 --> Language Class Initialized
INFO - 2019-08-27 09:57:39 --> Loader Class Initialized
INFO - 2019-08-27 09:57:39 --> Helper loaded: url_helper
INFO - 2019-08-27 09:57:39 --> Helper loaded: html_helper
INFO - 2019-08-27 09:57:39 --> Helper loaded: form_helper
INFO - 2019-08-27 09:57:39 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:57:39 --> Helper loaded: date_helper
INFO - 2019-08-27 09:57:39 --> Form Validation Class Initialized
INFO - 2019-08-27 09:57:39 --> Email Class Initialized
DEBUG - 2019-08-27 09:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:57:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:57:39 --> Pagination Class Initialized
INFO - 2019-08-27 09:57:39 --> Database Driver Class Initialized
INFO - 2019-08-27 09:57:39 --> Database Driver Class Initialized
INFO - 2019-08-27 09:57:39 --> Controller Class Initialized
INFO - 2019-08-27 09:57:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 09:57:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-27 09:57:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/guest.php
INFO - 2019-08-27 09:57:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 09:57:40 --> Final output sent to browser
DEBUG - 2019-08-27 09:57:40 --> Total execution time: 1.1662
INFO - 2019-08-27 09:57:40 --> Config Class Initialized
INFO - 2019-08-27 09:57:40 --> Hooks Class Initialized
INFO - 2019-08-27 09:57:40 --> Config Class Initialized
INFO - 2019-08-27 09:57:40 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:57:40 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:57:40 --> Utf8 Class Initialized
INFO - 2019-08-27 09:57:40 --> URI Class Initialized
INFO - 2019-08-27 09:57:40 --> Router Class Initialized
INFO - 2019-08-27 09:57:40 --> Output Class Initialized
INFO - 2019-08-27 09:57:40 --> Security Class Initialized
DEBUG - 2019-08-27 09:57:40 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:57:41 --> Utf8 Class Initialized
INFO - 2019-08-27 09:57:41 --> URI Class Initialized
INFO - 2019-08-27 09:57:41 --> Router Class Initialized
INFO - 2019-08-27 09:57:41 --> Output Class Initialized
INFO - 2019-08-27 09:57:41 --> Security Class Initialized
DEBUG - 2019-08-27 09:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:57:41 --> Input Class Initialized
INFO - 2019-08-27 09:57:41 --> Language Class Initialized
DEBUG - 2019-08-27 09:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:57:41 --> Input Class Initialized
INFO - 2019-08-27 09:57:41 --> Loader Class Initialized
INFO - 2019-08-27 09:57:41 --> Language Class Initialized
INFO - 2019-08-27 09:57:41 --> Helper loaded: url_helper
INFO - 2019-08-27 09:57:41 --> Helper loaded: html_helper
INFO - 2019-08-27 09:57:41 --> Helper loaded: form_helper
INFO - 2019-08-27 09:57:41 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:57:41 --> Loader Class Initialized
INFO - 2019-08-27 09:57:41 --> Helper loaded: date_helper
INFO - 2019-08-27 09:57:41 --> Helper loaded: url_helper
INFO - 2019-08-27 09:57:41 --> Helper loaded: html_helper
INFO - 2019-08-27 09:57:41 --> Helper loaded: form_helper
INFO - 2019-08-27 09:57:41 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:57:41 --> Helper loaded: date_helper
INFO - 2019-08-27 09:57:42 --> Form Validation Class Initialized
INFO - 2019-08-27 09:57:42 --> Form Validation Class Initialized
INFO - 2019-08-27 09:57:42 --> Email Class Initialized
INFO - 2019-08-27 09:57:42 --> Email Class Initialized
DEBUG - 2019-08-27 09:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-27 09:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:57:42 --> Pagination Class Initialized
INFO - 2019-08-27 09:57:42 --> Database Driver Class Initialized
INFO - 2019-08-27 09:57:42 --> Database Driver Class Initialized
INFO - 2019-08-27 09:57:42 --> Controller Class Initialized
INFO - 2019-08-27 09:57:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 09:57:42 --> Final output sent to browser
DEBUG - 2019-08-27 09:57:42 --> Total execution time: 1.9613
INFO - 2019-08-27 09:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:57:42 --> Pagination Class Initialized
INFO - 2019-08-27 09:57:42 --> Database Driver Class Initialized
INFO - 2019-08-27 09:57:42 --> Database Driver Class Initialized
INFO - 2019-08-27 09:57:42 --> Controller Class Initialized
INFO - 2019-08-27 09:57:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 09:57:42 --> Final output sent to browser
DEBUG - 2019-08-27 09:57:42 --> Total execution time: 2.2925
INFO - 2019-08-27 09:58:03 --> Config Class Initialized
INFO - 2019-08-27 09:58:03 --> Hooks Class Initialized
INFO - 2019-08-27 09:58:03 --> Config Class Initialized
DEBUG - 2019-08-27 09:58:03 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:58:03 --> Hooks Class Initialized
INFO - 2019-08-27 09:58:03 --> Utf8 Class Initialized
DEBUG - 2019-08-27 09:58:03 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:58:03 --> URI Class Initialized
INFO - 2019-08-27 09:58:03 --> Utf8 Class Initialized
INFO - 2019-08-27 09:58:03 --> URI Class Initialized
INFO - 2019-08-27 09:58:03 --> Router Class Initialized
INFO - 2019-08-27 09:58:03 --> Router Class Initialized
INFO - 2019-08-27 09:58:03 --> Output Class Initialized
INFO - 2019-08-27 09:58:03 --> Output Class Initialized
INFO - 2019-08-27 09:58:03 --> Security Class Initialized
INFO - 2019-08-27 09:58:03 --> Security Class Initialized
DEBUG - 2019-08-27 09:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-27 09:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:58:03 --> Input Class Initialized
INFO - 2019-08-27 09:58:03 --> Input Class Initialized
INFO - 2019-08-27 09:58:03 --> Language Class Initialized
INFO - 2019-08-27 09:58:03 --> Language Class Initialized
INFO - 2019-08-27 09:58:03 --> Loader Class Initialized
INFO - 2019-08-27 09:58:03 --> Loader Class Initialized
INFO - 2019-08-27 09:58:03 --> Helper loaded: url_helper
INFO - 2019-08-27 09:58:03 --> Helper loaded: url_helper
INFO - 2019-08-27 09:58:03 --> Helper loaded: html_helper
INFO - 2019-08-27 09:58:03 --> Helper loaded: html_helper
INFO - 2019-08-27 09:58:03 --> Helper loaded: form_helper
INFO - 2019-08-27 09:58:03 --> Helper loaded: form_helper
INFO - 2019-08-27 09:58:03 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:58:03 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:58:03 --> Helper loaded: date_helper
INFO - 2019-08-27 09:58:03 --> Helper loaded: date_helper
INFO - 2019-08-27 09:58:03 --> Form Validation Class Initialized
INFO - 2019-08-27 09:58:03 --> Form Validation Class Initialized
INFO - 2019-08-27 09:58:03 --> Email Class Initialized
INFO - 2019-08-27 09:58:03 --> Email Class Initialized
DEBUG - 2019-08-27 09:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-27 09:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:58:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:58:03 --> Pagination Class Initialized
INFO - 2019-08-27 09:58:03 --> Database Driver Class Initialized
INFO - 2019-08-27 09:58:03 --> Config Class Initialized
INFO - 2019-08-27 09:58:03 --> Database Driver Class Initialized
INFO - 2019-08-27 09:58:03 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:58:04 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:58:04 --> Controller Class Initialized
INFO - 2019-08-27 09:58:04 --> Utf8 Class Initialized
INFO - 2019-08-27 09:58:04 --> URI Class Initialized
INFO - 2019-08-27 09:58:04 --> Router Class Initialized
INFO - 2019-08-27 09:58:04 --> Output Class Initialized
INFO - 2019-08-27 09:58:04 --> Security Class Initialized
ERROR - 2019-08-27 09:58:04 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
DEBUG - 2019-08-27 09:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:58:04 --> Input Class Initialized
INFO - 2019-08-27 09:58:04 --> Language Class Initialized
INFO - 2019-08-27 09:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:58:04 --> Loader Class Initialized
INFO - 2019-08-27 09:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:58:04 --> Helper loaded: url_helper
INFO - 2019-08-27 09:58:04 --> Pagination Class Initialized
INFO - 2019-08-27 09:58:04 --> Helper loaded: html_helper
INFO - 2019-08-27 09:58:04 --> Helper loaded: form_helper
INFO - 2019-08-27 09:58:04 --> Database Driver Class Initialized
INFO - 2019-08-27 09:58:04 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:58:04 --> Database Driver Class Initialized
INFO - 2019-08-27 09:58:04 --> Helper loaded: date_helper
INFO - 2019-08-27 09:58:04 --> Controller Class Initialized
INFO - 2019-08-27 09:58:04 --> Form Validation Class Initialized
INFO - 2019-08-27 09:58:04 --> Email Class Initialized
DEBUG - 2019-08-27 09:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:58:04 --> Config Class Initialized
ERROR - 2019-08-27 09:58:04 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-27 09:58:04 --> Hooks Class Initialized
INFO - 2019-08-27 09:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:58:04 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2019-08-27 09:58:04 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:58:04 --> Pagination Class Initialized
INFO - 2019-08-27 09:58:04 --> Utf8 Class Initialized
INFO - 2019-08-27 09:58:04 --> URI Class Initialized
INFO - 2019-08-27 09:58:04 --> Database Driver Class Initialized
INFO - 2019-08-27 09:58:04 --> Router Class Initialized
INFO - 2019-08-27 09:58:04 --> Database Driver Class Initialized
INFO - 2019-08-27 09:58:04 --> Controller Class Initialized
INFO - 2019-08-27 09:58:04 --> Config Class Initialized
INFO - 2019-08-27 09:58:04 --> Output Class Initialized
INFO - 2019-08-27 09:58:04 --> Hooks Class Initialized
ERROR - 2019-08-27 09:58:04 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-27 09:58:04 --> Security Class Initialized
DEBUG - 2019-08-27 09:58:04 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:58:04 --> Utf8 Class Initialized
DEBUG - 2019-08-27 09:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:58:04 --> URI Class Initialized
INFO - 2019-08-27 09:58:04 --> Input Class Initialized
INFO - 2019-08-27 09:58:04 --> Language Class Initialized
INFO - 2019-08-27 09:58:04 --> Router Class Initialized
INFO - 2019-08-27 09:58:04 --> Loader Class Initialized
INFO - 2019-08-27 09:58:04 --> Output Class Initialized
INFO - 2019-08-27 09:58:05 --> Helper loaded: url_helper
INFO - 2019-08-27 09:58:05 --> Helper loaded: html_helper
INFO - 2019-08-27 09:58:05 --> Security Class Initialized
INFO - 2019-08-27 09:58:05 --> Helper loaded: form_helper
DEBUG - 2019-08-27 09:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:58:05 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:58:05 --> Input Class Initialized
INFO - 2019-08-27 09:58:05 --> Language Class Initialized
INFO - 2019-08-27 09:58:05 --> Helper loaded: date_helper
INFO - 2019-08-27 09:58:05 --> Loader Class Initialized
INFO - 2019-08-27 09:58:05 --> Form Validation Class Initialized
INFO - 2019-08-27 09:58:05 --> Helper loaded: url_helper
INFO - 2019-08-27 09:58:05 --> Email Class Initialized
INFO - 2019-08-27 09:58:05 --> Helper loaded: html_helper
DEBUG - 2019-08-27 09:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:58:05 --> Helper loaded: form_helper
INFO - 2019-08-27 09:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:58:05 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:58:05 --> Helper loaded: date_helper
INFO - 2019-08-27 09:58:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:58:05 --> Form Validation Class Initialized
INFO - 2019-08-27 09:58:05 --> Pagination Class Initialized
INFO - 2019-08-27 09:58:05 --> Email Class Initialized
INFO - 2019-08-27 09:58:05 --> Database Driver Class Initialized
DEBUG - 2019-08-27 09:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:58:05 --> Database Driver Class Initialized
INFO - 2019-08-27 09:58:05 --> Controller Class Initialized
ERROR - 2019-08-27 09:58:05 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-27 09:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:58:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:58:05 --> Pagination Class Initialized
INFO - 2019-08-27 09:58:05 --> Database Driver Class Initialized
INFO - 2019-08-27 09:58:05 --> Database Driver Class Initialized
INFO - 2019-08-27 09:58:05 --> Controller Class Initialized
ERROR - 2019-08-27 09:58:05 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-27 09:58:14 --> Config Class Initialized
INFO - 2019-08-27 09:58:14 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:58:14 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:58:14 --> Utf8 Class Initialized
INFO - 2019-08-27 09:58:14 --> URI Class Initialized
INFO - 2019-08-27 09:58:14 --> Router Class Initialized
INFO - 2019-08-27 09:58:14 --> Output Class Initialized
INFO - 2019-08-27 09:58:14 --> Security Class Initialized
DEBUG - 2019-08-27 09:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:58:14 --> Input Class Initialized
INFO - 2019-08-27 09:58:14 --> Language Class Initialized
INFO - 2019-08-27 09:58:15 --> Loader Class Initialized
INFO - 2019-08-27 09:58:15 --> Helper loaded: url_helper
INFO - 2019-08-27 09:58:15 --> Helper loaded: html_helper
INFO - 2019-08-27 09:58:15 --> Helper loaded: form_helper
INFO - 2019-08-27 09:58:15 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:58:15 --> Helper loaded: date_helper
INFO - 2019-08-27 09:58:15 --> Form Validation Class Initialized
INFO - 2019-08-27 09:58:15 --> Email Class Initialized
DEBUG - 2019-08-27 09:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:58:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:58:15 --> Pagination Class Initialized
INFO - 2019-08-27 09:58:15 --> Database Driver Class Initialized
INFO - 2019-08-27 09:58:15 --> Database Driver Class Initialized
INFO - 2019-08-27 09:58:15 --> Controller Class Initialized
INFO - 2019-08-27 09:58:15 --> Final output sent to browser
DEBUG - 2019-08-27 09:58:15 --> Total execution time: 0.6024
INFO - 2019-08-27 09:58:23 --> Config Class Initialized
INFO - 2019-08-27 09:58:23 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:58:23 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:58:23 --> Utf8 Class Initialized
INFO - 2019-08-27 09:58:23 --> URI Class Initialized
INFO - 2019-08-27 09:58:23 --> Router Class Initialized
INFO - 2019-08-27 09:58:23 --> Output Class Initialized
INFO - 2019-08-27 09:58:23 --> Security Class Initialized
DEBUG - 2019-08-27 09:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:58:23 --> Input Class Initialized
INFO - 2019-08-27 09:58:23 --> Language Class Initialized
INFO - 2019-08-27 09:58:23 --> Loader Class Initialized
INFO - 2019-08-27 09:58:23 --> Helper loaded: url_helper
INFO - 2019-08-27 09:58:24 --> Helper loaded: html_helper
INFO - 2019-08-27 09:58:24 --> Helper loaded: form_helper
INFO - 2019-08-27 09:58:24 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:58:24 --> Helper loaded: date_helper
INFO - 2019-08-27 09:58:24 --> Form Validation Class Initialized
INFO - 2019-08-27 09:58:24 --> Email Class Initialized
DEBUG - 2019-08-27 09:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:58:24 --> Pagination Class Initialized
INFO - 2019-08-27 09:58:24 --> Database Driver Class Initialized
INFO - 2019-08-27 09:58:24 --> Database Driver Class Initialized
INFO - 2019-08-27 09:58:24 --> Controller Class Initialized
INFO - 2019-08-27 09:58:24 --> Final output sent to browser
DEBUG - 2019-08-27 09:58:24 --> Total execution time: 0.5847
INFO - 2019-08-27 09:58:29 --> Config Class Initialized
INFO - 2019-08-27 09:58:29 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:58:29 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:58:29 --> Utf8 Class Initialized
INFO - 2019-08-27 09:58:29 --> URI Class Initialized
INFO - 2019-08-27 09:58:29 --> Router Class Initialized
INFO - 2019-08-27 09:58:29 --> Output Class Initialized
INFO - 2019-08-27 09:58:29 --> Security Class Initialized
DEBUG - 2019-08-27 09:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:58:29 --> Input Class Initialized
INFO - 2019-08-27 09:58:29 --> Language Class Initialized
INFO - 2019-08-27 09:58:29 --> Loader Class Initialized
INFO - 2019-08-27 09:58:29 --> Helper loaded: url_helper
INFO - 2019-08-27 09:58:29 --> Helper loaded: html_helper
INFO - 2019-08-27 09:58:29 --> Helper loaded: form_helper
INFO - 2019-08-27 09:58:29 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:58:29 --> Helper loaded: date_helper
INFO - 2019-08-27 09:58:29 --> Form Validation Class Initialized
INFO - 2019-08-27 09:58:29 --> Email Class Initialized
DEBUG - 2019-08-27 09:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:58:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:58:29 --> Pagination Class Initialized
INFO - 2019-08-27 09:58:29 --> Database Driver Class Initialized
INFO - 2019-08-27 09:58:29 --> Database Driver Class Initialized
INFO - 2019-08-27 09:58:29 --> Controller Class Initialized
INFO - 2019-08-27 09:58:29 --> Final output sent to browser
DEBUG - 2019-08-27 09:58:29 --> Total execution time: 0.5963
INFO - 2019-08-27 09:59:07 --> Config Class Initialized
INFO - 2019-08-27 09:59:07 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:59:07 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:07 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:07 --> URI Class Initialized
INFO - 2019-08-27 09:59:07 --> Router Class Initialized
INFO - 2019-08-27 09:59:07 --> Output Class Initialized
INFO - 2019-08-27 09:59:07 --> Security Class Initialized
DEBUG - 2019-08-27 09:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:07 --> Input Class Initialized
INFO - 2019-08-27 09:59:07 --> Language Class Initialized
INFO - 2019-08-27 09:59:07 --> Loader Class Initialized
INFO - 2019-08-27 09:59:07 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:07 --> Helper loaded: html_helper
INFO - 2019-08-27 09:59:07 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:07 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:07 --> Helper loaded: date_helper
INFO - 2019-08-27 09:59:07 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:07 --> Email Class Initialized
DEBUG - 2019-08-27 09:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:08 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:08 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:08 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:08 --> Controller Class Initialized
INFO - 2019-08-27 09:59:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-27 09:59:08 --> Config Class Initialized
INFO - 2019-08-27 09:59:08 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:59:08 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:08 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:08 --> URI Class Initialized
INFO - 2019-08-27 09:59:08 --> Router Class Initialized
INFO - 2019-08-27 09:59:08 --> Output Class Initialized
INFO - 2019-08-27 09:59:08 --> Security Class Initialized
DEBUG - 2019-08-27 09:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:08 --> Input Class Initialized
INFO - 2019-08-27 09:59:08 --> Language Class Initialized
INFO - 2019-08-27 09:59:08 --> Loader Class Initialized
INFO - 2019-08-27 09:59:08 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:08 --> Helper loaded: html_helper
INFO - 2019-08-27 09:59:08 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:08 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:08 --> Helper loaded: date_helper
INFO - 2019-08-27 09:59:08 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:08 --> Email Class Initialized
DEBUG - 2019-08-27 09:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:08 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:08 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:08 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:08 --> Controller Class Initialized
INFO - 2019-08-27 09:59:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 09:59:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-27 09:59:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/checkin.php
INFO - 2019-08-27 09:59:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 09:59:09 --> Final output sent to browser
DEBUG - 2019-08-27 09:59:09 --> Total execution time: 0.9606
INFO - 2019-08-27 09:59:09 --> Config Class Initialized
INFO - 2019-08-27 09:59:09 --> Hooks Class Initialized
INFO - 2019-08-27 09:59:09 --> Config Class Initialized
INFO - 2019-08-27 09:59:09 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:59:09 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:09 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:09 --> URI Class Initialized
DEBUG - 2019-08-27 09:59:09 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:09 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:09 --> URI Class Initialized
INFO - 2019-08-27 09:59:09 --> Router Class Initialized
INFO - 2019-08-27 09:59:10 --> Output Class Initialized
INFO - 2019-08-27 09:59:10 --> Security Class Initialized
DEBUG - 2019-08-27 09:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:10 --> Input Class Initialized
INFO - 2019-08-27 09:59:10 --> Language Class Initialized
INFO - 2019-08-27 09:59:10 --> Router Class Initialized
INFO - 2019-08-27 09:59:10 --> Output Class Initialized
INFO - 2019-08-27 09:59:10 --> Loader Class Initialized
INFO - 2019-08-27 09:59:10 --> Security Class Initialized
INFO - 2019-08-27 09:59:10 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:10 --> Helper loaded: html_helper
DEBUG - 2019-08-27 09:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:10 --> Input Class Initialized
INFO - 2019-08-27 09:59:10 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:10 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:10 --> Language Class Initialized
INFO - 2019-08-27 09:59:10 --> Helper loaded: date_helper
INFO - 2019-08-27 09:59:10 --> Loader Class Initialized
INFO - 2019-08-27 09:59:10 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:10 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:10 --> Email Class Initialized
INFO - 2019-08-27 09:59:10 --> Helper loaded: html_helper
DEBUG - 2019-08-27 09:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:10 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:10 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:11 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:11 --> Helper loaded: date_helper
INFO - 2019-08-27 09:59:11 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:11 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:11 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:11 --> Email Class Initialized
INFO - 2019-08-27 09:59:11 --> Controller Class Initialized
DEBUG - 2019-08-27 09:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 09:59:11 --> Final output sent to browser
DEBUG - 2019-08-27 09:59:11 --> Total execution time: 1.7559
INFO - 2019-08-27 09:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:11 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:11 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:11 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:11 --> Controller Class Initialized
INFO - 2019-08-27 09:59:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 09:59:11 --> Final output sent to browser
DEBUG - 2019-08-27 09:59:11 --> Total execution time: 2.1107
INFO - 2019-08-27 09:59:14 --> Config Class Initialized
INFO - 2019-08-27 09:59:14 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:59:14 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:14 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:14 --> URI Class Initialized
INFO - 2019-08-27 09:59:15 --> Router Class Initialized
INFO - 2019-08-27 09:59:15 --> Output Class Initialized
INFO - 2019-08-27 09:59:15 --> Security Class Initialized
DEBUG - 2019-08-27 09:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:15 --> Input Class Initialized
INFO - 2019-08-27 09:59:15 --> Language Class Initialized
INFO - 2019-08-27 09:59:15 --> Loader Class Initialized
INFO - 2019-08-27 09:59:15 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:15 --> Helper loaded: html_helper
INFO - 2019-08-27 09:59:15 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:15 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:15 --> Helper loaded: date_helper
INFO - 2019-08-27 09:59:15 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:15 --> Email Class Initialized
DEBUG - 2019-08-27 09:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:15 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:15 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:15 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:15 --> Controller Class Initialized
INFO - 2019-08-27 09:59:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-27 09:59:15 --> Config Class Initialized
INFO - 2019-08-27 09:59:15 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:59:15 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:15 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:15 --> URI Class Initialized
INFO - 2019-08-27 09:59:15 --> Router Class Initialized
INFO - 2019-08-27 09:59:15 --> Output Class Initialized
INFO - 2019-08-27 09:59:15 --> Security Class Initialized
DEBUG - 2019-08-27 09:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:15 --> Input Class Initialized
INFO - 2019-08-27 09:59:15 --> Language Class Initialized
INFO - 2019-08-27 09:59:16 --> Loader Class Initialized
INFO - 2019-08-27 09:59:16 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:16 --> Helper loaded: html_helper
INFO - 2019-08-27 09:59:16 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:16 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:16 --> Helper loaded: date_helper
INFO - 2019-08-27 09:59:16 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:16 --> Email Class Initialized
DEBUG - 2019-08-27 09:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:16 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:16 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:16 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:16 --> Controller Class Initialized
INFO - 2019-08-27 09:59:16 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 09:59:16 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-27 09:59:16 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/checkin.php
INFO - 2019-08-27 09:59:16 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 09:59:16 --> Final output sent to browser
DEBUG - 2019-08-27 09:59:16 --> Total execution time: 0.9007
INFO - 2019-08-27 09:59:16 --> Config Class Initialized
INFO - 2019-08-27 09:59:16 --> Hooks Class Initialized
INFO - 2019-08-27 09:59:17 --> Config Class Initialized
INFO - 2019-08-27 09:59:17 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:59:17 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:17 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:17 --> URI Class Initialized
INFO - 2019-08-27 09:59:17 --> Router Class Initialized
INFO - 2019-08-27 09:59:17 --> Output Class Initialized
INFO - 2019-08-27 09:59:17 --> Security Class Initialized
DEBUG - 2019-08-27 09:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:17 --> Input Class Initialized
INFO - 2019-08-27 09:59:17 --> Language Class Initialized
DEBUG - 2019-08-27 09:59:17 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:17 --> Loader Class Initialized
INFO - 2019-08-27 09:59:17 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:17 --> URI Class Initialized
INFO - 2019-08-27 09:59:17 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:17 --> Router Class Initialized
INFO - 2019-08-27 09:59:17 --> Helper loaded: html_helper
INFO - 2019-08-27 09:59:17 --> Output Class Initialized
INFO - 2019-08-27 09:59:17 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:17 --> Security Class Initialized
INFO - 2019-08-27 09:59:17 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:17 --> Helper loaded: date_helper
DEBUG - 2019-08-27 09:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:17 --> Input Class Initialized
INFO - 2019-08-27 09:59:17 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:17 --> Language Class Initialized
INFO - 2019-08-27 09:59:17 --> Email Class Initialized
INFO - 2019-08-27 09:59:17 --> Loader Class Initialized
DEBUG - 2019-08-27 09:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:18 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:18 --> Helper loaded: html_helper
INFO - 2019-08-27 09:59:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:18 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:18 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:18 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:18 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:18 --> Helper loaded: date_helper
INFO - 2019-08-27 09:59:18 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:18 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:18 --> Controller Class Initialized
INFO - 2019-08-27 09:59:18 --> Email Class Initialized
INFO - 2019-08-27 09:59:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
DEBUG - 2019-08-27 09:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:18 --> Final output sent to browser
DEBUG - 2019-08-27 09:59:18 --> Total execution time: 1.5285
INFO - 2019-08-27 09:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:18 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:18 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:18 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:18 --> Controller Class Initialized
INFO - 2019-08-27 09:59:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 09:59:18 --> Final output sent to browser
DEBUG - 2019-08-27 09:59:18 --> Total execution time: 1.9011
INFO - 2019-08-27 09:59:22 --> Config Class Initialized
INFO - 2019-08-27 09:59:22 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:59:22 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:22 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:22 --> URI Class Initialized
INFO - 2019-08-27 09:59:22 --> Router Class Initialized
INFO - 2019-08-27 09:59:22 --> Output Class Initialized
INFO - 2019-08-27 09:59:22 --> Security Class Initialized
DEBUG - 2019-08-27 09:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:22 --> Input Class Initialized
INFO - 2019-08-27 09:59:22 --> Language Class Initialized
INFO - 2019-08-27 09:59:22 --> Loader Class Initialized
INFO - 2019-08-27 09:59:22 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:22 --> Helper loaded: html_helper
INFO - 2019-08-27 09:59:22 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:22 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:22 --> Helper loaded: date_helper
INFO - 2019-08-27 09:59:22 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:22 --> Email Class Initialized
DEBUG - 2019-08-27 09:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:23 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:23 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:23 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:23 --> Controller Class Initialized
INFO - 2019-08-27 09:59:23 --> Config Class Initialized
INFO - 2019-08-27 09:59:23 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:59:23 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:23 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:23 --> URI Class Initialized
INFO - 2019-08-27 09:59:23 --> Router Class Initialized
INFO - 2019-08-27 09:59:23 --> Output Class Initialized
INFO - 2019-08-27 09:59:23 --> Security Class Initialized
DEBUG - 2019-08-27 09:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:23 --> Input Class Initialized
INFO - 2019-08-27 09:59:23 --> Language Class Initialized
INFO - 2019-08-27 09:59:23 --> Loader Class Initialized
INFO - 2019-08-27 09:59:23 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:23 --> Helper loaded: html_helper
INFO - 2019-08-27 09:59:23 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:23 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:23 --> Helper loaded: date_helper
INFO - 2019-08-27 09:59:23 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:23 --> Email Class Initialized
DEBUG - 2019-08-27 09:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:23 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:23 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:23 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:23 --> Controller Class Initialized
INFO - 2019-08-27 09:59:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 09:59:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-27 09:59:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-27 09:59:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 09:59:24 --> Final output sent to browser
DEBUG - 2019-08-27 09:59:24 --> Total execution time: 0.8950
INFO - 2019-08-27 09:59:24 --> Config Class Initialized
INFO - 2019-08-27 09:59:24 --> Hooks Class Initialized
INFO - 2019-08-27 09:59:24 --> Config Class Initialized
INFO - 2019-08-27 09:59:24 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:59:24 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:24 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:24 --> URI Class Initialized
INFO - 2019-08-27 09:59:24 --> Router Class Initialized
INFO - 2019-08-27 09:59:24 --> Output Class Initialized
DEBUG - 2019-08-27 09:59:24 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:24 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:24 --> URI Class Initialized
INFO - 2019-08-27 09:59:24 --> Security Class Initialized
INFO - 2019-08-27 09:59:24 --> Router Class Initialized
INFO - 2019-08-27 09:59:24 --> Output Class Initialized
DEBUG - 2019-08-27 09:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:24 --> Input Class Initialized
INFO - 2019-08-27 09:59:24 --> Security Class Initialized
INFO - 2019-08-27 09:59:25 --> Language Class Initialized
DEBUG - 2019-08-27 09:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:25 --> Loader Class Initialized
INFO - 2019-08-27 09:59:25 --> Input Class Initialized
INFO - 2019-08-27 09:59:25 --> Language Class Initialized
INFO - 2019-08-27 09:59:25 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:25 --> Helper loaded: html_helper
INFO - 2019-08-27 09:59:25 --> Loader Class Initialized
INFO - 2019-08-27 09:59:25 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:25 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:25 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:25 --> Helper loaded: html_helper
INFO - 2019-08-27 09:59:25 --> Helper loaded: date_helper
INFO - 2019-08-27 09:59:25 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:25 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:25 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:25 --> Email Class Initialized
INFO - 2019-08-27 09:59:25 --> Helper loaded: date_helper
DEBUG - 2019-08-27 09:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:25 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:25 --> Email Class Initialized
INFO - 2019-08-27 09:59:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2019-08-27 09:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:25 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:25 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:25 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:25 --> Controller Class Initialized
INFO - 2019-08-27 09:59:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 09:59:25 --> Final output sent to browser
DEBUG - 2019-08-27 09:59:25 --> Total execution time: 1.4862
INFO - 2019-08-27 09:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:26 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:26 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:26 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:26 --> Controller Class Initialized
INFO - 2019-08-27 09:59:26 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 09:59:26 --> Final output sent to browser
DEBUG - 2019-08-27 09:59:26 --> Total execution time: 1.8976
INFO - 2019-08-27 09:59:28 --> Config Class Initialized
INFO - 2019-08-27 09:59:28 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:59:28 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:28 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:28 --> URI Class Initialized
INFO - 2019-08-27 09:59:28 --> Router Class Initialized
INFO - 2019-08-27 09:59:28 --> Output Class Initialized
INFO - 2019-08-27 09:59:28 --> Security Class Initialized
DEBUG - 2019-08-27 09:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:29 --> Input Class Initialized
INFO - 2019-08-27 09:59:29 --> Language Class Initialized
INFO - 2019-08-27 09:59:29 --> Loader Class Initialized
INFO - 2019-08-27 09:59:29 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:29 --> Helper loaded: html_helper
INFO - 2019-08-27 09:59:29 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:29 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:29 --> Helper loaded: date_helper
INFO - 2019-08-27 09:59:29 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:29 --> Email Class Initialized
DEBUG - 2019-08-27 09:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:29 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:29 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:29 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:29 --> Controller Class Initialized
INFO - 2019-08-27 09:59:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 09:59:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/folio.php
INFO - 2019-08-27 09:59:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 09:59:29 --> Final output sent to browser
DEBUG - 2019-08-27 09:59:29 --> Total execution time: 1.0445
INFO - 2019-08-27 09:59:30 --> Config Class Initialized
INFO - 2019-08-27 09:59:30 --> Config Class Initialized
INFO - 2019-08-27 09:59:30 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:59:30 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:30 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:30 --> Hooks Class Initialized
INFO - 2019-08-27 09:59:30 --> URI Class Initialized
INFO - 2019-08-27 09:59:30 --> Router Class Initialized
INFO - 2019-08-27 09:59:30 --> Output Class Initialized
INFO - 2019-08-27 09:59:30 --> Security Class Initialized
DEBUG - 2019-08-27 09:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:30 --> Input Class Initialized
INFO - 2019-08-27 09:59:30 --> Language Class Initialized
DEBUG - 2019-08-27 09:59:30 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:30 --> Loader Class Initialized
INFO - 2019-08-27 09:59:30 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:30 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:30 --> URI Class Initialized
INFO - 2019-08-27 09:59:30 --> Helper loaded: html_helper
INFO - 2019-08-27 09:59:30 --> Router Class Initialized
INFO - 2019-08-27 09:59:30 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:30 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:30 --> Output Class Initialized
INFO - 2019-08-27 09:59:30 --> Helper loaded: date_helper
INFO - 2019-08-27 09:59:30 --> Security Class Initialized
INFO - 2019-08-27 09:59:30 --> Form Validation Class Initialized
DEBUG - 2019-08-27 09:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:30 --> Email Class Initialized
INFO - 2019-08-27 09:59:30 --> Input Class Initialized
INFO - 2019-08-27 09:59:31 --> Language Class Initialized
DEBUG - 2019-08-27 09:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:31 --> Loader Class Initialized
INFO - 2019-08-27 09:59:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:31 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:31 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:31 --> Helper loaded: html_helper
INFO - 2019-08-27 09:59:31 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:31 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:31 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:31 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:31 --> Helper loaded: date_helper
INFO - 2019-08-27 09:59:31 --> Controller Class Initialized
INFO - 2019-08-27 09:59:31 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:31 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 09:59:31 --> Email Class Initialized
INFO - 2019-08-27 09:59:31 --> Final output sent to browser
DEBUG - 2019-08-27 09:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-27 09:59:31 --> Total execution time: 1.5972
INFO - 2019-08-27 09:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:31 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:31 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:31 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:31 --> Controller Class Initialized
INFO - 2019-08-27 09:59:31 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 09:59:31 --> Final output sent to browser
DEBUG - 2019-08-27 09:59:32 --> Total execution time: 1.9144
INFO - 2019-08-27 09:59:56 --> Config Class Initialized
INFO - 2019-08-27 09:59:56 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:59:56 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:56 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:56 --> URI Class Initialized
INFO - 2019-08-27 09:59:56 --> Router Class Initialized
INFO - 2019-08-27 09:59:56 --> Output Class Initialized
INFO - 2019-08-27 09:59:56 --> Security Class Initialized
DEBUG - 2019-08-27 09:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:56 --> Input Class Initialized
INFO - 2019-08-27 09:59:56 --> Language Class Initialized
INFO - 2019-08-27 09:59:56 --> Loader Class Initialized
INFO - 2019-08-27 09:59:56 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:56 --> Helper loaded: html_helper
INFO - 2019-08-27 09:59:56 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:56 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:56 --> Helper loaded: date_helper
INFO - 2019-08-27 09:59:56 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:56 --> Email Class Initialized
DEBUG - 2019-08-27 09:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:56 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:56 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:56 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:56 --> Controller Class Initialized
INFO - 2019-08-27 09:59:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-27 09:59:57 --> Config Class Initialized
INFO - 2019-08-27 09:59:57 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:59:57 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:57 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:57 --> URI Class Initialized
INFO - 2019-08-27 09:59:57 --> Router Class Initialized
INFO - 2019-08-27 09:59:57 --> Output Class Initialized
INFO - 2019-08-27 09:59:57 --> Security Class Initialized
DEBUG - 2019-08-27 09:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:57 --> Input Class Initialized
INFO - 2019-08-27 09:59:57 --> Language Class Initialized
INFO - 2019-08-27 09:59:57 --> Loader Class Initialized
INFO - 2019-08-27 09:59:57 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:57 --> Helper loaded: html_helper
INFO - 2019-08-27 09:59:57 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:57 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:57 --> Helper loaded: date_helper
INFO - 2019-08-27 09:59:57 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:57 --> Email Class Initialized
DEBUG - 2019-08-27 09:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:57 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:57 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:57 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:57 --> Controller Class Initialized
INFO - 2019-08-27 09:59:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 09:59:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/folio.php
INFO - 2019-08-27 09:59:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 09:59:57 --> Final output sent to browser
DEBUG - 2019-08-27 09:59:57 --> Total execution time: 0.8839
INFO - 2019-08-27 09:59:58 --> Config Class Initialized
INFO - 2019-08-27 09:59:58 --> Config Class Initialized
INFO - 2019-08-27 09:59:58 --> Hooks Class Initialized
INFO - 2019-08-27 09:59:58 --> Hooks Class Initialized
DEBUG - 2019-08-27 09:59:58 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:58 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:58 --> URI Class Initialized
INFO - 2019-08-27 09:59:58 --> Router Class Initialized
INFO - 2019-08-27 09:59:58 --> Output Class Initialized
INFO - 2019-08-27 09:59:58 --> Security Class Initialized
DEBUG - 2019-08-27 09:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:58 --> Input Class Initialized
INFO - 2019-08-27 09:59:58 --> Language Class Initialized
DEBUG - 2019-08-27 09:59:58 --> UTF-8 Support Enabled
INFO - 2019-08-27 09:59:58 --> Loader Class Initialized
INFO - 2019-08-27 09:59:58 --> Utf8 Class Initialized
INFO - 2019-08-27 09:59:58 --> URI Class Initialized
INFO - 2019-08-27 09:59:58 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:58 --> Router Class Initialized
INFO - 2019-08-27 09:59:58 --> Helper loaded: html_helper
INFO - 2019-08-27 09:59:58 --> Output Class Initialized
INFO - 2019-08-27 09:59:58 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:58 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:58 --> Helper loaded: date_helper
INFO - 2019-08-27 09:59:58 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:59 --> Email Class Initialized
DEBUG - 2019-08-27 09:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:59 --> Security Class Initialized
DEBUG - 2019-08-27 09:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 09:59:59 --> Input Class Initialized
INFO - 2019-08-27 09:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:59 --> Language Class Initialized
INFO - 2019-08-27 09:59:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:59 --> Loader Class Initialized
INFO - 2019-08-27 09:59:59 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:59 --> Helper loaded: url_helper
INFO - 2019-08-27 09:59:59 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:59 --> Helper loaded: html_helper
INFO - 2019-08-27 09:59:59 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:59 --> Helper loaded: form_helper
INFO - 2019-08-27 09:59:59 --> Controller Class Initialized
INFO - 2019-08-27 09:59:59 --> Helper loaded: cookie_helper
INFO - 2019-08-27 09:59:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 09:59:59 --> Helper loaded: date_helper
INFO - 2019-08-27 09:59:59 --> Final output sent to browser
DEBUG - 2019-08-27 09:59:59 --> Total execution time: 1.4346
INFO - 2019-08-27 09:59:59 --> Form Validation Class Initialized
INFO - 2019-08-27 09:59:59 --> Email Class Initialized
DEBUG - 2019-08-27 09:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 09:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 09:59:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 09:59:59 --> Pagination Class Initialized
INFO - 2019-08-27 09:59:59 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:59 --> Database Driver Class Initialized
INFO - 2019-08-27 09:59:59 --> Controller Class Initialized
INFO - 2019-08-27 09:59:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:00:00 --> Final output sent to browser
DEBUG - 2019-08-27 10:00:00 --> Total execution time: 1.8659
INFO - 2019-08-27 10:00:11 --> Config Class Initialized
INFO - 2019-08-27 10:00:11 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:00:11 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:00:11 --> Utf8 Class Initialized
INFO - 2019-08-27 10:00:11 --> URI Class Initialized
INFO - 2019-08-27 10:00:11 --> Router Class Initialized
INFO - 2019-08-27 10:00:11 --> Output Class Initialized
INFO - 2019-08-27 10:00:11 --> Security Class Initialized
DEBUG - 2019-08-27 10:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:00:11 --> Input Class Initialized
INFO - 2019-08-27 10:00:11 --> Language Class Initialized
INFO - 2019-08-27 10:00:11 --> Loader Class Initialized
INFO - 2019-08-27 10:00:11 --> Helper loaded: url_helper
INFO - 2019-08-27 10:00:11 --> Helper loaded: html_helper
INFO - 2019-08-27 10:00:11 --> Helper loaded: form_helper
INFO - 2019-08-27 10:00:11 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:00:11 --> Helper loaded: date_helper
INFO - 2019-08-27 10:00:11 --> Form Validation Class Initialized
INFO - 2019-08-27 10:00:11 --> Email Class Initialized
DEBUG - 2019-08-27 10:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:00:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:00:12 --> Pagination Class Initialized
INFO - 2019-08-27 10:00:12 --> Database Driver Class Initialized
INFO - 2019-08-27 10:00:12 --> Database Driver Class Initialized
INFO - 2019-08-27 10:00:12 --> Controller Class Initialized
INFO - 2019-08-27 10:00:12 --> Final output sent to browser
DEBUG - 2019-08-27 10:00:12 --> Total execution time: 0.6187
INFO - 2019-08-27 10:00:35 --> Config Class Initialized
INFO - 2019-08-27 10:00:35 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:00:35 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:00:35 --> Utf8 Class Initialized
INFO - 2019-08-27 10:00:35 --> URI Class Initialized
INFO - 2019-08-27 10:00:35 --> Router Class Initialized
INFO - 2019-08-27 10:00:35 --> Output Class Initialized
INFO - 2019-08-27 10:00:35 --> Security Class Initialized
DEBUG - 2019-08-27 10:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:00:36 --> Input Class Initialized
INFO - 2019-08-27 10:00:36 --> Language Class Initialized
INFO - 2019-08-27 10:00:36 --> Loader Class Initialized
INFO - 2019-08-27 10:00:36 --> Helper loaded: url_helper
INFO - 2019-08-27 10:00:36 --> Helper loaded: html_helper
INFO - 2019-08-27 10:00:36 --> Helper loaded: form_helper
INFO - 2019-08-27 10:00:36 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:00:36 --> Helper loaded: date_helper
INFO - 2019-08-27 10:00:36 --> Form Validation Class Initialized
INFO - 2019-08-27 10:00:36 --> Email Class Initialized
DEBUG - 2019-08-27 10:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:00:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:00:36 --> Pagination Class Initialized
INFO - 2019-08-27 10:00:36 --> Database Driver Class Initialized
INFO - 2019-08-27 10:00:36 --> Database Driver Class Initialized
INFO - 2019-08-27 10:00:36 --> Controller Class Initialized
INFO - 2019-08-27 10:00:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-27 10:00:36 --> Config Class Initialized
INFO - 2019-08-27 10:00:36 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:00:36 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:00:36 --> Utf8 Class Initialized
INFO - 2019-08-27 10:00:36 --> URI Class Initialized
INFO - 2019-08-27 10:00:36 --> Router Class Initialized
INFO - 2019-08-27 10:00:36 --> Output Class Initialized
INFO - 2019-08-27 10:00:36 --> Security Class Initialized
DEBUG - 2019-08-27 10:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:00:36 --> Input Class Initialized
INFO - 2019-08-27 10:00:36 --> Language Class Initialized
INFO - 2019-08-27 10:00:36 --> Loader Class Initialized
INFO - 2019-08-27 10:00:37 --> Helper loaded: url_helper
INFO - 2019-08-27 10:00:37 --> Helper loaded: html_helper
INFO - 2019-08-27 10:00:37 --> Helper loaded: form_helper
INFO - 2019-08-27 10:00:37 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:00:37 --> Helper loaded: date_helper
INFO - 2019-08-27 10:00:37 --> Form Validation Class Initialized
INFO - 2019-08-27 10:00:37 --> Email Class Initialized
DEBUG - 2019-08-27 10:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:00:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:00:37 --> Pagination Class Initialized
INFO - 2019-08-27 10:00:37 --> Database Driver Class Initialized
INFO - 2019-08-27 10:00:37 --> Database Driver Class Initialized
INFO - 2019-08-27 10:00:37 --> Controller Class Initialized
INFO - 2019-08-27 10:00:37 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 10:00:37 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/folio.php
INFO - 2019-08-27 10:00:37 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 10:00:37 --> Final output sent to browser
DEBUG - 2019-08-27 10:00:37 --> Total execution time: 0.9176
INFO - 2019-08-27 10:00:37 --> Config Class Initialized
INFO - 2019-08-27 10:00:37 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:00:37 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:00:37 --> Utf8 Class Initialized
INFO - 2019-08-27 10:00:38 --> URI Class Initialized
INFO - 2019-08-27 10:00:38 --> Router Class Initialized
INFO - 2019-08-27 10:00:38 --> Output Class Initialized
INFO - 2019-08-27 10:00:38 --> Security Class Initialized
DEBUG - 2019-08-27 10:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:00:38 --> Input Class Initialized
INFO - 2019-08-27 10:00:38 --> Config Class Initialized
INFO - 2019-08-27 10:00:38 --> Hooks Class Initialized
INFO - 2019-08-27 10:00:38 --> Language Class Initialized
DEBUG - 2019-08-27 10:00:38 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:00:38 --> Utf8 Class Initialized
INFO - 2019-08-27 10:00:38 --> Loader Class Initialized
INFO - 2019-08-27 10:00:38 --> URI Class Initialized
INFO - 2019-08-27 10:00:38 --> Helper loaded: url_helper
INFO - 2019-08-27 10:00:38 --> Router Class Initialized
INFO - 2019-08-27 10:00:38 --> Helper loaded: html_helper
INFO - 2019-08-27 10:00:38 --> Output Class Initialized
INFO - 2019-08-27 10:00:38 --> Helper loaded: form_helper
INFO - 2019-08-27 10:00:38 --> Security Class Initialized
INFO - 2019-08-27 10:00:38 --> Helper loaded: cookie_helper
DEBUG - 2019-08-27 10:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:00:38 --> Helper loaded: date_helper
INFO - 2019-08-27 10:00:38 --> Input Class Initialized
INFO - 2019-08-27 10:00:38 --> Language Class Initialized
INFO - 2019-08-27 10:00:38 --> Form Validation Class Initialized
INFO - 2019-08-27 10:00:38 --> Loader Class Initialized
INFO - 2019-08-27 10:00:38 --> Email Class Initialized
INFO - 2019-08-27 10:00:38 --> Helper loaded: url_helper
DEBUG - 2019-08-27 10:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:00:38 --> Helper loaded: html_helper
INFO - 2019-08-27 10:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:00:39 --> Helper loaded: form_helper
INFO - 2019-08-27 10:00:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:00:39 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:00:39 --> Pagination Class Initialized
INFO - 2019-08-27 10:00:39 --> Helper loaded: date_helper
INFO - 2019-08-27 10:00:39 --> Database Driver Class Initialized
INFO - 2019-08-27 10:00:39 --> Form Validation Class Initialized
INFO - 2019-08-27 10:00:39 --> Database Driver Class Initialized
INFO - 2019-08-27 10:00:39 --> Email Class Initialized
INFO - 2019-08-27 10:00:39 --> Controller Class Initialized
DEBUG - 2019-08-27 10:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:00:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:00:39 --> Final output sent to browser
DEBUG - 2019-08-27 10:00:39 --> Total execution time: 1.5109
INFO - 2019-08-27 10:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:00:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:00:39 --> Pagination Class Initialized
INFO - 2019-08-27 10:00:39 --> Database Driver Class Initialized
INFO - 2019-08-27 10:00:39 --> Database Driver Class Initialized
INFO - 2019-08-27 10:00:39 --> Controller Class Initialized
INFO - 2019-08-27 10:00:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:00:39 --> Final output sent to browser
DEBUG - 2019-08-27 10:00:39 --> Total execution time: 1.7810
INFO - 2019-08-27 10:00:50 --> Config Class Initialized
INFO - 2019-08-27 10:00:50 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:00:50 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:00:50 --> Utf8 Class Initialized
INFO - 2019-08-27 10:00:51 --> URI Class Initialized
INFO - 2019-08-27 10:00:51 --> Router Class Initialized
INFO - 2019-08-27 10:00:51 --> Output Class Initialized
INFO - 2019-08-27 10:00:51 --> Security Class Initialized
DEBUG - 2019-08-27 10:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:00:51 --> Input Class Initialized
INFO - 2019-08-27 10:00:51 --> Language Class Initialized
INFO - 2019-08-27 10:00:51 --> Loader Class Initialized
INFO - 2019-08-27 10:00:51 --> Helper loaded: url_helper
INFO - 2019-08-27 10:00:51 --> Helper loaded: html_helper
INFO - 2019-08-27 10:00:51 --> Helper loaded: form_helper
INFO - 2019-08-27 10:00:51 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:00:51 --> Helper loaded: date_helper
INFO - 2019-08-27 10:00:51 --> Form Validation Class Initialized
INFO - 2019-08-27 10:00:51 --> Email Class Initialized
DEBUG - 2019-08-27 10:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:00:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:00:51 --> Pagination Class Initialized
INFO - 2019-08-27 10:00:51 --> Database Driver Class Initialized
INFO - 2019-08-27 10:00:51 --> Database Driver Class Initialized
INFO - 2019-08-27 10:00:51 --> Controller Class Initialized
INFO - 2019-08-27 10:00:51 --> Final output sent to browser
DEBUG - 2019-08-27 10:00:51 --> Total execution time: 0.6223
INFO - 2019-08-27 10:00:59 --> Config Class Initialized
INFO - 2019-08-27 10:00:59 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:00:59 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:00:59 --> Utf8 Class Initialized
INFO - 2019-08-27 10:00:59 --> URI Class Initialized
INFO - 2019-08-27 10:00:59 --> Router Class Initialized
INFO - 2019-08-27 10:00:59 --> Output Class Initialized
INFO - 2019-08-27 10:00:59 --> Security Class Initialized
DEBUG - 2019-08-27 10:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:00:59 --> Input Class Initialized
INFO - 2019-08-27 10:00:59 --> Language Class Initialized
INFO - 2019-08-27 10:00:59 --> Loader Class Initialized
INFO - 2019-08-27 10:00:59 --> Helper loaded: url_helper
INFO - 2019-08-27 10:00:59 --> Helper loaded: html_helper
INFO - 2019-08-27 10:00:59 --> Helper loaded: form_helper
INFO - 2019-08-27 10:00:59 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:00:59 --> Helper loaded: date_helper
INFO - 2019-08-27 10:00:59 --> Form Validation Class Initialized
INFO - 2019-08-27 10:01:00 --> Email Class Initialized
DEBUG - 2019-08-27 10:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:01:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:01:00 --> Pagination Class Initialized
INFO - 2019-08-27 10:01:00 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:00 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:00 --> Controller Class Initialized
INFO - 2019-08-27 10:01:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-27 10:01:00 --> Config Class Initialized
INFO - 2019-08-27 10:01:00 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:01:00 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:01:00 --> Utf8 Class Initialized
INFO - 2019-08-27 10:01:00 --> URI Class Initialized
INFO - 2019-08-27 10:01:00 --> Router Class Initialized
INFO - 2019-08-27 10:01:00 --> Output Class Initialized
INFO - 2019-08-27 10:01:00 --> Security Class Initialized
DEBUG - 2019-08-27 10:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:01:00 --> Input Class Initialized
INFO - 2019-08-27 10:01:00 --> Language Class Initialized
INFO - 2019-08-27 10:01:00 --> Loader Class Initialized
INFO - 2019-08-27 10:01:00 --> Helper loaded: url_helper
INFO - 2019-08-27 10:01:01 --> Helper loaded: html_helper
INFO - 2019-08-27 10:01:01 --> Helper loaded: form_helper
INFO - 2019-08-27 10:01:01 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:01:01 --> Helper loaded: date_helper
INFO - 2019-08-27 10:01:01 --> Form Validation Class Initialized
INFO - 2019-08-27 10:01:01 --> Email Class Initialized
DEBUG - 2019-08-27 10:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:01:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:01:01 --> Pagination Class Initialized
INFO - 2019-08-27 10:01:01 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:01 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:01 --> Controller Class Initialized
INFO - 2019-08-27 10:01:01 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 10:01:01 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/folio.php
INFO - 2019-08-27 10:01:01 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 10:01:01 --> Final output sent to browser
DEBUG - 2019-08-27 10:01:01 --> Total execution time: 1.1457
INFO - 2019-08-27 10:01:02 --> Config Class Initialized
INFO - 2019-08-27 10:01:02 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:01:02 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:01:02 --> Utf8 Class Initialized
INFO - 2019-08-27 10:01:02 --> URI Class Initialized
INFO - 2019-08-27 10:01:02 --> Router Class Initialized
INFO - 2019-08-27 10:01:02 --> Config Class Initialized
INFO - 2019-08-27 10:01:02 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:01:02 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:01:02 --> Utf8 Class Initialized
INFO - 2019-08-27 10:01:02 --> URI Class Initialized
INFO - 2019-08-27 10:01:02 --> Router Class Initialized
INFO - 2019-08-27 10:01:02 --> Output Class Initialized
INFO - 2019-08-27 10:01:02 --> Output Class Initialized
INFO - 2019-08-27 10:01:02 --> Security Class Initialized
DEBUG - 2019-08-27 10:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:01:02 --> Input Class Initialized
INFO - 2019-08-27 10:01:03 --> Language Class Initialized
INFO - 2019-08-27 10:01:03 --> Security Class Initialized
INFO - 2019-08-27 10:01:03 --> Loader Class Initialized
DEBUG - 2019-08-27 10:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:01:03 --> Input Class Initialized
INFO - 2019-08-27 10:01:03 --> Helper loaded: url_helper
INFO - 2019-08-27 10:01:03 --> Language Class Initialized
INFO - 2019-08-27 10:01:03 --> Helper loaded: html_helper
INFO - 2019-08-27 10:01:03 --> Helper loaded: form_helper
INFO - 2019-08-27 10:01:03 --> Loader Class Initialized
INFO - 2019-08-27 10:01:03 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:01:03 --> Helper loaded: date_helper
INFO - 2019-08-27 10:01:03 --> Helper loaded: url_helper
INFO - 2019-08-27 10:01:03 --> Helper loaded: html_helper
INFO - 2019-08-27 10:01:03 --> Form Validation Class Initialized
INFO - 2019-08-27 10:01:03 --> Helper loaded: form_helper
INFO - 2019-08-27 10:01:03 --> Email Class Initialized
INFO - 2019-08-27 10:01:03 --> Helper loaded: cookie_helper
DEBUG - 2019-08-27 10:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:01:03 --> Helper loaded: date_helper
INFO - 2019-08-27 10:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:01:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:01:03 --> Form Validation Class Initialized
INFO - 2019-08-27 10:01:03 --> Pagination Class Initialized
INFO - 2019-08-27 10:01:03 --> Email Class Initialized
INFO - 2019-08-27 10:01:03 --> Database Driver Class Initialized
DEBUG - 2019-08-27 10:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:01:03 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:03 --> Controller Class Initialized
INFO - 2019-08-27 10:01:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:01:04 --> Final output sent to browser
DEBUG - 2019-08-27 10:01:04 --> Total execution time: 1.9642
INFO - 2019-08-27 10:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:01:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:01:04 --> Pagination Class Initialized
INFO - 2019-08-27 10:01:04 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:04 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:04 --> Controller Class Initialized
INFO - 2019-08-27 10:01:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:01:04 --> Final output sent to browser
DEBUG - 2019-08-27 10:01:04 --> Total execution time: 2.3025
INFO - 2019-08-27 10:01:16 --> Config Class Initialized
INFO - 2019-08-27 10:01:16 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:01:16 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:01:16 --> Utf8 Class Initialized
INFO - 2019-08-27 10:01:16 --> URI Class Initialized
INFO - 2019-08-27 10:01:16 --> Router Class Initialized
INFO - 2019-08-27 10:01:16 --> Output Class Initialized
INFO - 2019-08-27 10:01:16 --> Security Class Initialized
DEBUG - 2019-08-27 10:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:01:16 --> Input Class Initialized
INFO - 2019-08-27 10:01:16 --> Language Class Initialized
INFO - 2019-08-27 10:01:16 --> Loader Class Initialized
INFO - 2019-08-27 10:01:16 --> Helper loaded: url_helper
INFO - 2019-08-27 10:01:16 --> Helper loaded: html_helper
INFO - 2019-08-27 10:01:16 --> Helper loaded: form_helper
INFO - 2019-08-27 10:01:16 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:01:16 --> Helper loaded: date_helper
INFO - 2019-08-27 10:01:16 --> Form Validation Class Initialized
INFO - 2019-08-27 10:01:16 --> Email Class Initialized
DEBUG - 2019-08-27 10:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:01:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:01:16 --> Pagination Class Initialized
INFO - 2019-08-27 10:01:16 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:16 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:16 --> Controller Class Initialized
INFO - 2019-08-27 10:01:16 --> Final output sent to browser
DEBUG - 2019-08-27 10:01:16 --> Total execution time: 0.6726
INFO - 2019-08-27 10:01:27 --> Config Class Initialized
INFO - 2019-08-27 10:01:27 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:01:27 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:01:27 --> Utf8 Class Initialized
INFO - 2019-08-27 10:01:27 --> URI Class Initialized
INFO - 2019-08-27 10:01:27 --> Router Class Initialized
INFO - 2019-08-27 10:01:27 --> Output Class Initialized
INFO - 2019-08-27 10:01:27 --> Security Class Initialized
DEBUG - 2019-08-27 10:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:01:27 --> Input Class Initialized
INFO - 2019-08-27 10:01:27 --> Language Class Initialized
INFO - 2019-08-27 10:01:27 --> Loader Class Initialized
INFO - 2019-08-27 10:01:27 --> Helper loaded: url_helper
INFO - 2019-08-27 10:01:27 --> Helper loaded: html_helper
INFO - 2019-08-27 10:01:27 --> Helper loaded: form_helper
INFO - 2019-08-27 10:01:27 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:01:27 --> Helper loaded: date_helper
INFO - 2019-08-27 10:01:28 --> Form Validation Class Initialized
INFO - 2019-08-27 10:01:28 --> Email Class Initialized
DEBUG - 2019-08-27 10:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:01:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:01:28 --> Pagination Class Initialized
INFO - 2019-08-27 10:01:28 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:28 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:28 --> Controller Class Initialized
INFO - 2019-08-27 10:01:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-27 10:01:28 --> Config Class Initialized
INFO - 2019-08-27 10:01:28 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:01:28 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:01:28 --> Utf8 Class Initialized
INFO - 2019-08-27 10:01:28 --> URI Class Initialized
INFO - 2019-08-27 10:01:28 --> Router Class Initialized
INFO - 2019-08-27 10:01:28 --> Output Class Initialized
INFO - 2019-08-27 10:01:28 --> Security Class Initialized
DEBUG - 2019-08-27 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:01:28 --> Input Class Initialized
INFO - 2019-08-27 10:01:28 --> Language Class Initialized
INFO - 2019-08-27 10:01:28 --> Loader Class Initialized
INFO - 2019-08-27 10:01:28 --> Helper loaded: url_helper
INFO - 2019-08-27 10:01:28 --> Helper loaded: html_helper
INFO - 2019-08-27 10:01:28 --> Helper loaded: form_helper
INFO - 2019-08-27 10:01:28 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:01:28 --> Helper loaded: date_helper
INFO - 2019-08-27 10:01:28 --> Form Validation Class Initialized
INFO - 2019-08-27 10:01:28 --> Email Class Initialized
DEBUG - 2019-08-27 10:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:01:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:01:29 --> Pagination Class Initialized
INFO - 2019-08-27 10:01:29 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:29 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:29 --> Controller Class Initialized
INFO - 2019-08-27 10:01:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 10:01:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/folio.php
INFO - 2019-08-27 10:01:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 10:01:29 --> Final output sent to browser
DEBUG - 2019-08-27 10:01:29 --> Total execution time: 0.9105
INFO - 2019-08-27 10:01:29 --> Config Class Initialized
INFO - 2019-08-27 10:01:29 --> Config Class Initialized
INFO - 2019-08-27 10:01:29 --> Hooks Class Initialized
INFO - 2019-08-27 10:01:29 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:01:29 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:01:29 --> Utf8 Class Initialized
INFO - 2019-08-27 10:01:29 --> URI Class Initialized
INFO - 2019-08-27 10:01:29 --> Router Class Initialized
INFO - 2019-08-27 10:01:29 --> Output Class Initialized
INFO - 2019-08-27 10:01:30 --> Security Class Initialized
DEBUG - 2019-08-27 10:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:01:30 --> Input Class Initialized
DEBUG - 2019-08-27 10:01:30 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:01:30 --> Utf8 Class Initialized
INFO - 2019-08-27 10:01:30 --> Language Class Initialized
INFO - 2019-08-27 10:01:30 --> URI Class Initialized
INFO - 2019-08-27 10:01:30 --> Loader Class Initialized
INFO - 2019-08-27 10:01:30 --> Router Class Initialized
INFO - 2019-08-27 10:01:30 --> Helper loaded: url_helper
INFO - 2019-08-27 10:01:30 --> Output Class Initialized
INFO - 2019-08-27 10:01:30 --> Helper loaded: html_helper
INFO - 2019-08-27 10:01:30 --> Security Class Initialized
INFO - 2019-08-27 10:01:30 --> Helper loaded: form_helper
DEBUG - 2019-08-27 10:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:01:30 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:01:30 --> Input Class Initialized
INFO - 2019-08-27 10:01:30 --> Helper loaded: date_helper
INFO - 2019-08-27 10:01:30 --> Language Class Initialized
INFO - 2019-08-27 10:01:30 --> Form Validation Class Initialized
INFO - 2019-08-27 10:01:30 --> Loader Class Initialized
INFO - 2019-08-27 10:01:30 --> Email Class Initialized
INFO - 2019-08-27 10:01:30 --> Helper loaded: url_helper
DEBUG - 2019-08-27 10:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:01:30 --> Helper loaded: html_helper
INFO - 2019-08-27 10:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:01:30 --> Helper loaded: form_helper
INFO - 2019-08-27 10:01:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:01:30 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:01:30 --> Pagination Class Initialized
INFO - 2019-08-27 10:01:30 --> Helper loaded: date_helper
INFO - 2019-08-27 10:01:30 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:30 --> Form Validation Class Initialized
INFO - 2019-08-27 10:01:31 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:31 --> Email Class Initialized
INFO - 2019-08-27 10:01:31 --> Controller Class Initialized
DEBUG - 2019-08-27 10:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:01:31 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:01:31 --> Final output sent to browser
DEBUG - 2019-08-27 10:01:31 --> Total execution time: 1.5253
INFO - 2019-08-27 10:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:01:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:01:31 --> Pagination Class Initialized
INFO - 2019-08-27 10:01:31 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:31 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:31 --> Controller Class Initialized
INFO - 2019-08-27 10:01:31 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:01:31 --> Final output sent to browser
DEBUG - 2019-08-27 10:01:31 --> Total execution time: 1.8635
INFO - 2019-08-27 10:01:37 --> Config Class Initialized
INFO - 2019-08-27 10:01:37 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:01:37 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:01:37 --> Utf8 Class Initialized
INFO - 2019-08-27 10:01:37 --> URI Class Initialized
INFO - 2019-08-27 10:01:37 --> Router Class Initialized
INFO - 2019-08-27 10:01:37 --> Output Class Initialized
INFO - 2019-08-27 10:01:37 --> Security Class Initialized
DEBUG - 2019-08-27 10:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:01:37 --> Input Class Initialized
INFO - 2019-08-27 10:01:37 --> Language Class Initialized
INFO - 2019-08-27 10:01:37 --> Loader Class Initialized
INFO - 2019-08-27 10:01:37 --> Helper loaded: url_helper
INFO - 2019-08-27 10:01:37 --> Helper loaded: html_helper
INFO - 2019-08-27 10:01:37 --> Helper loaded: form_helper
INFO - 2019-08-27 10:01:37 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:01:37 --> Helper loaded: date_helper
INFO - 2019-08-27 10:01:37 --> Form Validation Class Initialized
INFO - 2019-08-27 10:01:37 --> Email Class Initialized
DEBUG - 2019-08-27 10:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:01:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:01:38 --> Pagination Class Initialized
INFO - 2019-08-27 10:01:38 --> Config Class Initialized
INFO - 2019-08-27 10:01:38 --> Hooks Class Initialized
INFO - 2019-08-27 10:01:38 --> Database Driver Class Initialized
DEBUG - 2019-08-27 10:01:38 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:01:38 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:38 --> Utf8 Class Initialized
INFO - 2019-08-27 10:01:38 --> Controller Class Initialized
INFO - 2019-08-27 10:01:38 --> URI Class Initialized
INFO - 2019-08-27 10:01:38 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:01:38 --> Router Class Initialized
INFO - 2019-08-27 10:01:38 --> Final output sent to browser
DEBUG - 2019-08-27 10:01:38 --> Total execution time: 1.1654
INFO - 2019-08-27 10:01:38 --> Output Class Initialized
INFO - 2019-08-27 10:01:38 --> Security Class Initialized
DEBUG - 2019-08-27 10:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:01:38 --> Input Class Initialized
INFO - 2019-08-27 10:01:38 --> Language Class Initialized
INFO - 2019-08-27 10:01:38 --> Loader Class Initialized
INFO - 2019-08-27 10:01:38 --> Helper loaded: url_helper
INFO - 2019-08-27 10:01:38 --> Helper loaded: html_helper
INFO - 2019-08-27 10:01:38 --> Helper loaded: form_helper
INFO - 2019-08-27 10:01:38 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:01:38 --> Helper loaded: date_helper
INFO - 2019-08-27 10:01:38 --> Form Validation Class Initialized
INFO - 2019-08-27 10:01:38 --> Email Class Initialized
DEBUG - 2019-08-27 10:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:01:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:01:39 --> Pagination Class Initialized
INFO - 2019-08-27 10:01:39 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:39 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:39 --> Controller Class Initialized
INFO - 2019-08-27 10:01:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:01:39 --> Final output sent to browser
DEBUG - 2019-08-27 10:01:39 --> Total execution time: 1.1250
INFO - 2019-08-27 10:01:40 --> Config Class Initialized
INFO - 2019-08-27 10:01:40 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:01:40 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:01:40 --> Utf8 Class Initialized
INFO - 2019-08-27 10:01:40 --> URI Class Initialized
INFO - 2019-08-27 10:01:40 --> Router Class Initialized
INFO - 2019-08-27 10:01:40 --> Output Class Initialized
INFO - 2019-08-27 10:01:40 --> Security Class Initialized
DEBUG - 2019-08-27 10:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:01:40 --> Input Class Initialized
INFO - 2019-08-27 10:01:40 --> Language Class Initialized
INFO - 2019-08-27 10:01:40 --> Loader Class Initialized
INFO - 2019-08-27 10:01:40 --> Helper loaded: url_helper
INFO - 2019-08-27 10:01:40 --> Helper loaded: html_helper
INFO - 2019-08-27 10:01:40 --> Helper loaded: form_helper
INFO - 2019-08-27 10:01:40 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:01:40 --> Helper loaded: date_helper
INFO - 2019-08-27 10:01:40 --> Form Validation Class Initialized
INFO - 2019-08-27 10:01:40 --> Email Class Initialized
DEBUG - 2019-08-27 10:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:01:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:01:41 --> Pagination Class Initialized
INFO - 2019-08-27 10:01:41 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:41 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:41 --> Controller Class Initialized
INFO - 2019-08-27 10:01:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 10:01:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/nightaudit.php
INFO - 2019-08-27 10:01:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 10:01:41 --> Final output sent to browser
DEBUG - 2019-08-27 10:01:41 --> Total execution time: 1.2584
INFO - 2019-08-27 10:01:41 --> Config Class Initialized
INFO - 2019-08-27 10:01:41 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:01:41 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:01:41 --> Utf8 Class Initialized
INFO - 2019-08-27 10:01:41 --> URI Class Initialized
INFO - 2019-08-27 10:01:42 --> Router Class Initialized
INFO - 2019-08-27 10:01:42 --> Output Class Initialized
INFO - 2019-08-27 10:01:42 --> Security Class Initialized
DEBUG - 2019-08-27 10:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:01:42 --> Input Class Initialized
INFO - 2019-08-27 10:01:42 --> Language Class Initialized
INFO - 2019-08-27 10:01:42 --> Loader Class Initialized
INFO - 2019-08-27 10:01:42 --> Helper loaded: url_helper
INFO - 2019-08-27 10:01:42 --> Helper loaded: html_helper
INFO - 2019-08-27 10:01:42 --> Helper loaded: form_helper
INFO - 2019-08-27 10:01:42 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:01:42 --> Helper loaded: date_helper
INFO - 2019-08-27 10:01:42 --> Form Validation Class Initialized
INFO - 2019-08-27 10:01:42 --> Email Class Initialized
DEBUG - 2019-08-27 10:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:01:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:01:42 --> Pagination Class Initialized
INFO - 2019-08-27 10:01:43 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:43 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:43 --> Controller Class Initialized
INFO - 2019-08-27 10:01:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:01:43 --> Final output sent to browser
DEBUG - 2019-08-27 10:01:43 --> Total execution time: 1.4930
INFO - 2019-08-27 10:01:43 --> Config Class Initialized
INFO - 2019-08-27 10:01:43 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:01:43 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:01:43 --> Utf8 Class Initialized
INFO - 2019-08-27 10:01:43 --> URI Class Initialized
INFO - 2019-08-27 10:01:43 --> Router Class Initialized
INFO - 2019-08-27 10:01:43 --> Output Class Initialized
INFO - 2019-08-27 10:01:43 --> Security Class Initialized
DEBUG - 2019-08-27 10:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:01:43 --> Input Class Initialized
INFO - 2019-08-27 10:01:43 --> Language Class Initialized
INFO - 2019-08-27 10:01:43 --> Loader Class Initialized
INFO - 2019-08-27 10:01:43 --> Helper loaded: url_helper
INFO - 2019-08-27 10:01:43 --> Helper loaded: html_helper
INFO - 2019-08-27 10:01:43 --> Helper loaded: form_helper
INFO - 2019-08-27 10:01:43 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:01:43 --> Helper loaded: date_helper
INFO - 2019-08-27 10:01:44 --> Form Validation Class Initialized
INFO - 2019-08-27 10:01:44 --> Email Class Initialized
DEBUG - 2019-08-27 10:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:01:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:01:44 --> Pagination Class Initialized
INFO - 2019-08-27 10:01:44 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:44 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:44 --> Controller Class Initialized
INFO - 2019-08-27 10:01:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:01:44 --> Final output sent to browser
DEBUG - 2019-08-27 10:01:44 --> Total execution time: 0.9150
INFO - 2019-08-27 10:01:50 --> Config Class Initialized
INFO - 2019-08-27 10:01:50 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:01:50 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:01:50 --> Utf8 Class Initialized
INFO - 2019-08-27 10:01:50 --> URI Class Initialized
INFO - 2019-08-27 10:01:50 --> Router Class Initialized
INFO - 2019-08-27 10:01:50 --> Output Class Initialized
INFO - 2019-08-27 10:01:50 --> Security Class Initialized
DEBUG - 2019-08-27 10:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:01:50 --> Input Class Initialized
INFO - 2019-08-27 10:01:50 --> Language Class Initialized
INFO - 2019-08-27 10:01:50 --> Loader Class Initialized
INFO - 2019-08-27 10:01:50 --> Helper loaded: url_helper
INFO - 2019-08-27 10:01:50 --> Helper loaded: html_helper
INFO - 2019-08-27 10:01:50 --> Helper loaded: form_helper
INFO - 2019-08-27 10:01:50 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:01:50 --> Helper loaded: date_helper
INFO - 2019-08-27 10:01:50 --> Form Validation Class Initialized
INFO - 2019-08-27 10:01:50 --> Email Class Initialized
DEBUG - 2019-08-27 10:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:01:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:01:50 --> Pagination Class Initialized
INFO - 2019-08-27 10:01:50 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:50 --> Database Driver Class Initialized
INFO - 2019-08-27 10:01:50 --> Controller Class Initialized
INFO - 2019-08-27 10:01:51 --> Final output sent to browser
DEBUG - 2019-08-27 10:01:51 --> Total execution time: 0.8528
INFO - 2019-08-27 10:02:27 --> Config Class Initialized
INFO - 2019-08-27 10:02:27 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:02:27 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:02:27 --> Utf8 Class Initialized
INFO - 2019-08-27 10:02:27 --> URI Class Initialized
INFO - 2019-08-27 10:02:27 --> Router Class Initialized
INFO - 2019-08-27 10:02:27 --> Output Class Initialized
INFO - 2019-08-27 10:02:27 --> Security Class Initialized
DEBUG - 2019-08-27 10:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:02:27 --> Input Class Initialized
INFO - 2019-08-27 10:02:27 --> Language Class Initialized
INFO - 2019-08-27 10:02:27 --> Loader Class Initialized
INFO - 2019-08-27 10:02:27 --> Helper loaded: url_helper
INFO - 2019-08-27 10:02:27 --> Helper loaded: html_helper
INFO - 2019-08-27 10:02:27 --> Helper loaded: form_helper
INFO - 2019-08-27 10:02:27 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:02:27 --> Helper loaded: date_helper
INFO - 2019-08-27 10:02:27 --> Form Validation Class Initialized
INFO - 2019-08-27 10:02:27 --> Email Class Initialized
DEBUG - 2019-08-27 10:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:02:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:02:27 --> Pagination Class Initialized
INFO - 2019-08-27 10:02:27 --> Database Driver Class Initialized
INFO - 2019-08-27 10:02:28 --> Database Driver Class Initialized
INFO - 2019-08-27 10:02:28 --> Controller Class Initialized
INFO - 2019-08-27 10:02:28 --> Final output sent to browser
DEBUG - 2019-08-27 10:02:28 --> Total execution time: 0.7560
INFO - 2019-08-27 10:02:39 --> Config Class Initialized
INFO - 2019-08-27 10:02:39 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:02:40 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:02:40 --> Utf8 Class Initialized
INFO - 2019-08-27 10:02:40 --> URI Class Initialized
INFO - 2019-08-27 10:02:40 --> Router Class Initialized
INFO - 2019-08-27 10:02:40 --> Output Class Initialized
INFO - 2019-08-27 10:02:40 --> Security Class Initialized
DEBUG - 2019-08-27 10:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:02:40 --> Input Class Initialized
INFO - 2019-08-27 10:02:40 --> Language Class Initialized
INFO - 2019-08-27 10:02:40 --> Loader Class Initialized
INFO - 2019-08-27 10:02:40 --> Helper loaded: url_helper
INFO - 2019-08-27 10:02:40 --> Helper loaded: html_helper
INFO - 2019-08-27 10:02:40 --> Helper loaded: form_helper
INFO - 2019-08-27 10:02:40 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:02:40 --> Helper loaded: date_helper
INFO - 2019-08-27 10:02:40 --> Form Validation Class Initialized
INFO - 2019-08-27 10:02:40 --> Email Class Initialized
DEBUG - 2019-08-27 10:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:02:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:02:40 --> Pagination Class Initialized
INFO - 2019-08-27 10:02:40 --> Database Driver Class Initialized
INFO - 2019-08-27 10:02:40 --> Database Driver Class Initialized
INFO - 2019-08-27 10:02:40 --> Controller Class Initialized
INFO - 2019-08-27 10:02:40 --> Final output sent to browser
DEBUG - 2019-08-27 10:02:40 --> Total execution time: 0.7050
INFO - 2019-08-27 10:02:42 --> Config Class Initialized
INFO - 2019-08-27 10:02:42 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:02:42 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:02:42 --> Utf8 Class Initialized
INFO - 2019-08-27 10:02:42 --> URI Class Initialized
INFO - 2019-08-27 10:02:42 --> Router Class Initialized
INFO - 2019-08-27 10:02:43 --> Output Class Initialized
INFO - 2019-08-27 10:02:43 --> Security Class Initialized
DEBUG - 2019-08-27 10:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:02:43 --> Input Class Initialized
INFO - 2019-08-27 10:02:43 --> Language Class Initialized
INFO - 2019-08-27 10:02:43 --> Loader Class Initialized
INFO - 2019-08-27 10:02:43 --> Helper loaded: url_helper
INFO - 2019-08-27 10:02:43 --> Helper loaded: html_helper
INFO - 2019-08-27 10:02:43 --> Helper loaded: form_helper
INFO - 2019-08-27 10:02:43 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:02:43 --> Helper loaded: date_helper
INFO - 2019-08-27 10:02:43 --> Form Validation Class Initialized
INFO - 2019-08-27 10:02:43 --> Email Class Initialized
DEBUG - 2019-08-27 10:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:02:43 --> Pagination Class Initialized
INFO - 2019-08-27 10:02:43 --> Database Driver Class Initialized
INFO - 2019-08-27 10:02:43 --> Database Driver Class Initialized
INFO - 2019-08-27 10:02:43 --> Controller Class Initialized
INFO - 2019-08-27 10:02:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 10:02:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/nightaudit.php
INFO - 2019-08-27 10:02:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 10:02:44 --> Final output sent to browser
DEBUG - 2019-08-27 10:02:44 --> Total execution time: 1.2460
INFO - 2019-08-27 10:02:44 --> Config Class Initialized
INFO - 2019-08-27 10:02:44 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:02:44 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:02:44 --> Utf8 Class Initialized
INFO - 2019-08-27 10:02:44 --> URI Class Initialized
INFO - 2019-08-27 10:02:44 --> Router Class Initialized
INFO - 2019-08-27 10:02:44 --> Output Class Initialized
INFO - 2019-08-27 10:02:44 --> Security Class Initialized
DEBUG - 2019-08-27 10:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:02:44 --> Input Class Initialized
INFO - 2019-08-27 10:02:44 --> Language Class Initialized
INFO - 2019-08-27 10:02:44 --> Loader Class Initialized
INFO - 2019-08-27 10:02:44 --> Helper loaded: url_helper
INFO - 2019-08-27 10:02:44 --> Helper loaded: html_helper
INFO - 2019-08-27 10:02:44 --> Helper loaded: form_helper
INFO - 2019-08-27 10:02:45 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:02:45 --> Helper loaded: date_helper
INFO - 2019-08-27 10:02:45 --> Form Validation Class Initialized
INFO - 2019-08-27 10:02:45 --> Email Class Initialized
DEBUG - 2019-08-27 10:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:02:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:02:45 --> Pagination Class Initialized
INFO - 2019-08-27 10:02:45 --> Database Driver Class Initialized
INFO - 2019-08-27 10:02:45 --> Database Driver Class Initialized
INFO - 2019-08-27 10:02:45 --> Controller Class Initialized
INFO - 2019-08-27 10:02:45 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:02:45 --> Final output sent to browser
DEBUG - 2019-08-27 10:02:45 --> Total execution time: 1.2554
INFO - 2019-08-27 10:02:52 --> Config Class Initialized
INFO - 2019-08-27 10:02:52 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:02:52 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:02:52 --> Utf8 Class Initialized
INFO - 2019-08-27 10:02:52 --> URI Class Initialized
INFO - 2019-08-27 10:02:52 --> Router Class Initialized
INFO - 2019-08-27 10:02:52 --> Output Class Initialized
INFO - 2019-08-27 10:02:52 --> Security Class Initialized
DEBUG - 2019-08-27 10:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:02:52 --> Input Class Initialized
INFO - 2019-08-27 10:02:52 --> Language Class Initialized
INFO - 2019-08-27 10:02:52 --> Loader Class Initialized
INFO - 2019-08-27 10:02:52 --> Helper loaded: url_helper
INFO - 2019-08-27 10:02:52 --> Helper loaded: html_helper
INFO - 2019-08-27 10:02:52 --> Helper loaded: form_helper
INFO - 2019-08-27 10:02:52 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:02:52 --> Helper loaded: date_helper
INFO - 2019-08-27 10:02:52 --> Form Validation Class Initialized
INFO - 2019-08-27 10:02:52 --> Email Class Initialized
DEBUG - 2019-08-27 10:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:02:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:02:52 --> Pagination Class Initialized
INFO - 2019-08-27 10:02:52 --> Database Driver Class Initialized
INFO - 2019-08-27 10:02:52 --> Database Driver Class Initialized
INFO - 2019-08-27 10:02:52 --> Controller Class Initialized
INFO - 2019-08-27 10:02:52 --> Final output sent to browser
DEBUG - 2019-08-27 10:02:52 --> Total execution time: 0.8027
INFO - 2019-08-27 10:02:55 --> Config Class Initialized
INFO - 2019-08-27 10:02:55 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:02:55 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:02:55 --> Utf8 Class Initialized
INFO - 2019-08-27 10:02:55 --> URI Class Initialized
INFO - 2019-08-27 10:02:55 --> Router Class Initialized
INFO - 2019-08-27 10:02:55 --> Output Class Initialized
INFO - 2019-08-27 10:02:55 --> Security Class Initialized
DEBUG - 2019-08-27 10:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:02:55 --> Input Class Initialized
INFO - 2019-08-27 10:02:55 --> Language Class Initialized
INFO - 2019-08-27 10:02:55 --> Loader Class Initialized
INFO - 2019-08-27 10:02:55 --> Helper loaded: url_helper
INFO - 2019-08-27 10:02:55 --> Helper loaded: html_helper
INFO - 2019-08-27 10:02:55 --> Helper loaded: form_helper
INFO - 2019-08-27 10:02:55 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:02:55 --> Helper loaded: date_helper
INFO - 2019-08-27 10:02:55 --> Form Validation Class Initialized
INFO - 2019-08-27 10:02:55 --> Email Class Initialized
DEBUG - 2019-08-27 10:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:02:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:02:55 --> Pagination Class Initialized
INFO - 2019-08-27 10:02:55 --> Database Driver Class Initialized
INFO - 2019-08-27 10:02:55 --> Database Driver Class Initialized
INFO - 2019-08-27 10:02:56 --> Controller Class Initialized
INFO - 2019-08-27 10:02:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 10:02:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/nightaudit.php
INFO - 2019-08-27 10:02:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 10:02:56 --> Final output sent to browser
DEBUG - 2019-08-27 10:02:56 --> Total execution time: 1.1384
INFO - 2019-08-27 10:02:56 --> Config Class Initialized
INFO - 2019-08-27 10:02:56 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:02:56 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:02:56 --> Utf8 Class Initialized
INFO - 2019-08-27 10:02:56 --> URI Class Initialized
INFO - 2019-08-27 10:02:56 --> Router Class Initialized
INFO - 2019-08-27 10:02:56 --> Output Class Initialized
INFO - 2019-08-27 10:02:56 --> Security Class Initialized
DEBUG - 2019-08-27 10:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:02:56 --> Input Class Initialized
INFO - 2019-08-27 10:02:56 --> Language Class Initialized
INFO - 2019-08-27 10:02:57 --> Loader Class Initialized
INFO - 2019-08-27 10:02:57 --> Helper loaded: url_helper
INFO - 2019-08-27 10:02:57 --> Helper loaded: html_helper
INFO - 2019-08-27 10:02:57 --> Helper loaded: form_helper
INFO - 2019-08-27 10:02:57 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:02:57 --> Helper loaded: date_helper
INFO - 2019-08-27 10:02:57 --> Form Validation Class Initialized
INFO - 2019-08-27 10:02:57 --> Email Class Initialized
DEBUG - 2019-08-27 10:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:02:57 --> Pagination Class Initialized
INFO - 2019-08-27 10:02:57 --> Database Driver Class Initialized
INFO - 2019-08-27 10:02:57 --> Database Driver Class Initialized
INFO - 2019-08-27 10:02:57 --> Controller Class Initialized
INFO - 2019-08-27 10:02:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:02:57 --> Final output sent to browser
DEBUG - 2019-08-27 10:02:57 --> Total execution time: 1.1376
INFO - 2019-08-27 10:02:58 --> Config Class Initialized
INFO - 2019-08-27 10:02:58 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:02:58 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:02:58 --> Utf8 Class Initialized
INFO - 2019-08-27 10:02:58 --> URI Class Initialized
INFO - 2019-08-27 10:02:58 --> Router Class Initialized
INFO - 2019-08-27 10:02:58 --> Output Class Initialized
INFO - 2019-08-27 10:02:58 --> Security Class Initialized
DEBUG - 2019-08-27 10:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:02:58 --> Input Class Initialized
INFO - 2019-08-27 10:02:58 --> Language Class Initialized
INFO - 2019-08-27 10:02:58 --> Loader Class Initialized
INFO - 2019-08-27 10:02:58 --> Helper loaded: url_helper
INFO - 2019-08-27 10:02:58 --> Helper loaded: html_helper
INFO - 2019-08-27 10:02:58 --> Helper loaded: form_helper
INFO - 2019-08-27 10:02:59 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:02:59 --> Helper loaded: date_helper
INFO - 2019-08-27 10:02:59 --> Form Validation Class Initialized
INFO - 2019-08-27 10:02:59 --> Email Class Initialized
DEBUG - 2019-08-27 10:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:02:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:02:59 --> Pagination Class Initialized
INFO - 2019-08-27 10:02:59 --> Database Driver Class Initialized
INFO - 2019-08-27 10:02:59 --> Database Driver Class Initialized
INFO - 2019-08-27 10:02:59 --> Controller Class Initialized
INFO - 2019-08-27 10:02:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:02:59 --> Final output sent to browser
DEBUG - 2019-08-27 10:02:59 --> Total execution time: 0.8998
INFO - 2019-08-27 10:03:00 --> Config Class Initialized
INFO - 2019-08-27 10:03:00 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:03:00 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:03:00 --> Utf8 Class Initialized
INFO - 2019-08-27 10:03:00 --> URI Class Initialized
INFO - 2019-08-27 10:03:00 --> Router Class Initialized
INFO - 2019-08-27 10:03:00 --> Output Class Initialized
INFO - 2019-08-27 10:03:00 --> Security Class Initialized
DEBUG - 2019-08-27 10:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:03:00 --> Input Class Initialized
INFO - 2019-08-27 10:03:00 --> Language Class Initialized
INFO - 2019-08-27 10:03:00 --> Loader Class Initialized
INFO - 2019-08-27 10:03:00 --> Helper loaded: url_helper
INFO - 2019-08-27 10:03:00 --> Helper loaded: html_helper
INFO - 2019-08-27 10:03:00 --> Helper loaded: form_helper
INFO - 2019-08-27 10:03:00 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:03:00 --> Helper loaded: date_helper
INFO - 2019-08-27 10:03:00 --> Form Validation Class Initialized
INFO - 2019-08-27 10:03:00 --> Email Class Initialized
DEBUG - 2019-08-27 10:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:03:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:03:00 --> Pagination Class Initialized
INFO - 2019-08-27 10:03:00 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:01 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:01 --> Controller Class Initialized
INFO - 2019-08-27 10:03:01 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:03:01 --> Final output sent to browser
DEBUG - 2019-08-27 10:03:01 --> Total execution time: 0.7780
INFO - 2019-08-27 10:03:01 --> Config Class Initialized
INFO - 2019-08-27 10:03:01 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:03:01 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:03:01 --> Utf8 Class Initialized
INFO - 2019-08-27 10:03:01 --> URI Class Initialized
INFO - 2019-08-27 10:03:02 --> Router Class Initialized
INFO - 2019-08-27 10:03:02 --> Output Class Initialized
INFO - 2019-08-27 10:03:02 --> Security Class Initialized
DEBUG - 2019-08-27 10:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:03:02 --> Input Class Initialized
INFO - 2019-08-27 10:03:02 --> Language Class Initialized
INFO - 2019-08-27 10:03:02 --> Loader Class Initialized
INFO - 2019-08-27 10:03:02 --> Helper loaded: url_helper
INFO - 2019-08-27 10:03:02 --> Helper loaded: html_helper
INFO - 2019-08-27 10:03:02 --> Config Class Initialized
INFO - 2019-08-27 10:03:02 --> Helper loaded: form_helper
INFO - 2019-08-27 10:03:02 --> Hooks Class Initialized
INFO - 2019-08-27 10:03:02 --> Helper loaded: cookie_helper
DEBUG - 2019-08-27 10:03:02 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:03:02 --> Helper loaded: date_helper
INFO - 2019-08-27 10:03:02 --> Utf8 Class Initialized
INFO - 2019-08-27 10:03:02 --> URI Class Initialized
INFO - 2019-08-27 10:03:02 --> Form Validation Class Initialized
INFO - 2019-08-27 10:03:02 --> Router Class Initialized
INFO - 2019-08-27 10:03:02 --> Email Class Initialized
INFO - 2019-08-27 10:03:02 --> Output Class Initialized
INFO - 2019-08-27 10:03:02 --> Security Class Initialized
DEBUG - 2019-08-27 10:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-27 10:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:03:02 --> Input Class Initialized
INFO - 2019-08-27 10:03:02 --> Language Class Initialized
INFO - 2019-08-27 10:03:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:03:02 --> Loader Class Initialized
INFO - 2019-08-27 10:03:02 --> Pagination Class Initialized
INFO - 2019-08-27 10:03:02 --> Helper loaded: url_helper
INFO - 2019-08-27 10:03:02 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:02 --> Helper loaded: html_helper
INFO - 2019-08-27 10:03:02 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:02 --> Helper loaded: form_helper
INFO - 2019-08-27 10:03:02 --> Controller Class Initialized
INFO - 2019-08-27 10:03:02 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:03:02 --> Helper loaded: date_helper
INFO - 2019-08-27 10:03:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:03:02 --> Form Validation Class Initialized
INFO - 2019-08-27 10:03:02 --> Final output sent to browser
INFO - 2019-08-27 10:03:03 --> Email Class Initialized
DEBUG - 2019-08-27 10:03:03 --> Total execution time: 1.1885
DEBUG - 2019-08-27 10:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:03:03 --> Pagination Class Initialized
INFO - 2019-08-27 10:03:03 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:03 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:03 --> Controller Class Initialized
INFO - 2019-08-27 10:03:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 10:03:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-27 10:03:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 10:03:03 --> Final output sent to browser
DEBUG - 2019-08-27 10:03:03 --> Total execution time: 1.1188
INFO - 2019-08-27 10:03:03 --> Config Class Initialized
INFO - 2019-08-27 10:03:03 --> Config Class Initialized
INFO - 2019-08-27 10:03:03 --> Hooks Class Initialized
INFO - 2019-08-27 10:03:03 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:03:03 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:03:03 --> Utf8 Class Initialized
INFO - 2019-08-27 10:03:03 --> URI Class Initialized
INFO - 2019-08-27 10:03:03 --> Router Class Initialized
INFO - 2019-08-27 10:03:04 --> Output Class Initialized
DEBUG - 2019-08-27 10:03:04 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:03:04 --> Security Class Initialized
INFO - 2019-08-27 10:03:04 --> Utf8 Class Initialized
INFO - 2019-08-27 10:03:04 --> URI Class Initialized
DEBUG - 2019-08-27 10:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:03:04 --> Input Class Initialized
INFO - 2019-08-27 10:03:04 --> Router Class Initialized
INFO - 2019-08-27 10:03:04 --> Language Class Initialized
INFO - 2019-08-27 10:03:04 --> Output Class Initialized
INFO - 2019-08-27 10:03:04 --> Loader Class Initialized
INFO - 2019-08-27 10:03:04 --> Security Class Initialized
INFO - 2019-08-27 10:03:04 --> Helper loaded: url_helper
DEBUG - 2019-08-27 10:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:03:04 --> Helper loaded: html_helper
INFO - 2019-08-27 10:03:04 --> Input Class Initialized
INFO - 2019-08-27 10:03:04 --> Language Class Initialized
INFO - 2019-08-27 10:03:04 --> Helper loaded: form_helper
INFO - 2019-08-27 10:03:04 --> Loader Class Initialized
INFO - 2019-08-27 10:03:04 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:03:04 --> Helper loaded: date_helper
INFO - 2019-08-27 10:03:04 --> Helper loaded: url_helper
INFO - 2019-08-27 10:03:04 --> Form Validation Class Initialized
INFO - 2019-08-27 10:03:04 --> Helper loaded: html_helper
INFO - 2019-08-27 10:03:04 --> Email Class Initialized
INFO - 2019-08-27 10:03:04 --> Helper loaded: form_helper
DEBUG - 2019-08-27 10:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:03:04 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:03:04 --> Helper loaded: date_helper
INFO - 2019-08-27 10:03:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:03:05 --> Form Validation Class Initialized
INFO - 2019-08-27 10:03:05 --> Pagination Class Initialized
INFO - 2019-08-27 10:03:05 --> Email Class Initialized
INFO - 2019-08-27 10:03:05 --> Database Driver Class Initialized
DEBUG - 2019-08-27 10:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:03:05 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:05 --> Controller Class Initialized
INFO - 2019-08-27 10:03:05 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:03:05 --> Final output sent to browser
DEBUG - 2019-08-27 10:03:05 --> Total execution time: 1.6064
INFO - 2019-08-27 10:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:03:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:03:05 --> Pagination Class Initialized
INFO - 2019-08-27 10:03:05 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:05 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:05 --> Controller Class Initialized
INFO - 2019-08-27 10:03:05 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:03:05 --> Final output sent to browser
DEBUG - 2019-08-27 10:03:05 --> Total execution time: 1.9692
INFO - 2019-08-27 10:03:10 --> Config Class Initialized
INFO - 2019-08-27 10:03:11 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:03:11 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:03:11 --> Utf8 Class Initialized
INFO - 2019-08-27 10:03:11 --> URI Class Initialized
INFO - 2019-08-27 10:03:11 --> Router Class Initialized
INFO - 2019-08-27 10:03:11 --> Output Class Initialized
INFO - 2019-08-27 10:03:11 --> Security Class Initialized
DEBUG - 2019-08-27 10:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:03:11 --> Input Class Initialized
INFO - 2019-08-27 10:03:11 --> Language Class Initialized
INFO - 2019-08-27 10:03:11 --> Loader Class Initialized
INFO - 2019-08-27 10:03:11 --> Helper loaded: url_helper
INFO - 2019-08-27 10:03:11 --> Helper loaded: html_helper
INFO - 2019-08-27 10:03:11 --> Helper loaded: form_helper
INFO - 2019-08-27 10:03:11 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:03:11 --> Helper loaded: date_helper
INFO - 2019-08-27 10:03:11 --> Form Validation Class Initialized
INFO - 2019-08-27 10:03:11 --> Email Class Initialized
DEBUG - 2019-08-27 10:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:03:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:03:11 --> Pagination Class Initialized
INFO - 2019-08-27 10:03:11 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:11 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:11 --> Controller Class Initialized
INFO - 2019-08-27 10:03:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 10:03:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-27 10:03:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-27 10:03:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 10:03:12 --> Final output sent to browser
DEBUG - 2019-08-27 10:03:12 --> Total execution time: 1.0376
INFO - 2019-08-27 10:03:12 --> Config Class Initialized
INFO - 2019-08-27 10:03:12 --> Hooks Class Initialized
INFO - 2019-08-27 10:03:12 --> Config Class Initialized
DEBUG - 2019-08-27 10:03:12 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:03:12 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:03:12 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:03:12 --> Utf8 Class Initialized
INFO - 2019-08-27 10:03:12 --> URI Class Initialized
INFO - 2019-08-27 10:03:12 --> Router Class Initialized
INFO - 2019-08-27 10:03:12 --> Output Class Initialized
INFO - 2019-08-27 10:03:12 --> Security Class Initialized
INFO - 2019-08-27 10:03:12 --> Utf8 Class Initialized
DEBUG - 2019-08-27 10:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:03:12 --> URI Class Initialized
INFO - 2019-08-27 10:03:12 --> Input Class Initialized
INFO - 2019-08-27 10:03:12 --> Language Class Initialized
INFO - 2019-08-27 10:03:12 --> Router Class Initialized
INFO - 2019-08-27 10:03:12 --> Loader Class Initialized
INFO - 2019-08-27 10:03:12 --> Output Class Initialized
INFO - 2019-08-27 10:03:12 --> Helper loaded: url_helper
INFO - 2019-08-27 10:03:12 --> Security Class Initialized
INFO - 2019-08-27 10:03:13 --> Helper loaded: html_helper
DEBUG - 2019-08-27 10:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:03:13 --> Input Class Initialized
INFO - 2019-08-27 10:03:13 --> Helper loaded: form_helper
INFO - 2019-08-27 10:03:13 --> Language Class Initialized
INFO - 2019-08-27 10:03:13 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:03:13 --> Helper loaded: date_helper
INFO - 2019-08-27 10:03:13 --> Loader Class Initialized
INFO - 2019-08-27 10:03:13 --> Form Validation Class Initialized
INFO - 2019-08-27 10:03:13 --> Helper loaded: url_helper
INFO - 2019-08-27 10:03:13 --> Email Class Initialized
INFO - 2019-08-27 10:03:13 --> Helper loaded: html_helper
DEBUG - 2019-08-27 10:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:03:13 --> Helper loaded: form_helper
INFO - 2019-08-27 10:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:03:13 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:03:13 --> Helper loaded: date_helper
INFO - 2019-08-27 10:03:13 --> Pagination Class Initialized
INFO - 2019-08-27 10:03:13 --> Form Validation Class Initialized
INFO - 2019-08-27 10:03:13 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:13 --> Email Class Initialized
INFO - 2019-08-27 10:03:13 --> Database Driver Class Initialized
DEBUG - 2019-08-27 10:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:03:13 --> Controller Class Initialized
INFO - 2019-08-27 10:03:13 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:03:14 --> Final output sent to browser
DEBUG - 2019-08-27 10:03:14 --> Total execution time: 1.7280
INFO - 2019-08-27 10:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:03:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:03:14 --> Pagination Class Initialized
INFO - 2019-08-27 10:03:14 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:14 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:14 --> Controller Class Initialized
INFO - 2019-08-27 10:03:14 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:03:14 --> Final output sent to browser
DEBUG - 2019-08-27 10:03:14 --> Total execution time: 2.1051
INFO - 2019-08-27 10:03:18 --> Config Class Initialized
INFO - 2019-08-27 10:03:18 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:03:18 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:03:18 --> Utf8 Class Initialized
INFO - 2019-08-27 10:03:18 --> URI Class Initialized
INFO - 2019-08-27 10:03:18 --> Router Class Initialized
INFO - 2019-08-27 10:03:18 --> Output Class Initialized
INFO - 2019-08-27 10:03:18 --> Security Class Initialized
DEBUG - 2019-08-27 10:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:03:18 --> Input Class Initialized
INFO - 2019-08-27 10:03:18 --> Language Class Initialized
INFO - 2019-08-27 10:03:18 --> Loader Class Initialized
INFO - 2019-08-27 10:03:18 --> Helper loaded: url_helper
INFO - 2019-08-27 10:03:18 --> Helper loaded: html_helper
INFO - 2019-08-27 10:03:18 --> Helper loaded: form_helper
INFO - 2019-08-27 10:03:18 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:03:18 --> Helper loaded: date_helper
INFO - 2019-08-27 10:03:18 --> Form Validation Class Initialized
INFO - 2019-08-27 10:03:18 --> Email Class Initialized
DEBUG - 2019-08-27 10:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:03:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:03:19 --> Pagination Class Initialized
INFO - 2019-08-27 10:03:19 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:19 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:19 --> Controller Class Initialized
INFO - 2019-08-27 10:03:19 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 10:03:19 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/folio.php
INFO - 2019-08-27 10:03:19 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 10:03:19 --> Final output sent to browser
DEBUG - 2019-08-27 10:03:19 --> Total execution time: 1.0191
INFO - 2019-08-27 10:03:19 --> Config Class Initialized
INFO - 2019-08-27 10:03:19 --> Hooks Class Initialized
INFO - 2019-08-27 10:03:19 --> Config Class Initialized
DEBUG - 2019-08-27 10:03:19 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:03:19 --> Hooks Class Initialized
INFO - 2019-08-27 10:03:19 --> Utf8 Class Initialized
INFO - 2019-08-27 10:03:19 --> URI Class Initialized
INFO - 2019-08-27 10:03:19 --> Router Class Initialized
INFO - 2019-08-27 10:03:19 --> Output Class Initialized
INFO - 2019-08-27 10:03:20 --> Security Class Initialized
DEBUG - 2019-08-27 10:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:03:20 --> Input Class Initialized
DEBUG - 2019-08-27 10:03:20 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:03:20 --> Utf8 Class Initialized
INFO - 2019-08-27 10:03:20 --> Language Class Initialized
INFO - 2019-08-27 10:03:20 --> URI Class Initialized
INFO - 2019-08-27 10:03:20 --> Loader Class Initialized
INFO - 2019-08-27 10:03:20 --> Router Class Initialized
INFO - 2019-08-27 10:03:20 --> Helper loaded: url_helper
INFO - 2019-08-27 10:03:20 --> Output Class Initialized
INFO - 2019-08-27 10:03:20 --> Helper loaded: html_helper
INFO - 2019-08-27 10:03:20 --> Security Class Initialized
INFO - 2019-08-27 10:03:20 --> Helper loaded: form_helper
DEBUG - 2019-08-27 10:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:03:20 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:03:20 --> Input Class Initialized
INFO - 2019-08-27 10:03:20 --> Language Class Initialized
INFO - 2019-08-27 10:03:20 --> Helper loaded: date_helper
INFO - 2019-08-27 10:03:20 --> Loader Class Initialized
INFO - 2019-08-27 10:03:20 --> Form Validation Class Initialized
INFO - 2019-08-27 10:03:20 --> Helper loaded: url_helper
INFO - 2019-08-27 10:03:20 --> Email Class Initialized
INFO - 2019-08-27 10:03:20 --> Helper loaded: html_helper
DEBUG - 2019-08-27 10:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:03:20 --> Helper loaded: form_helper
INFO - 2019-08-27 10:03:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:03:21 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:03:21 --> Pagination Class Initialized
INFO - 2019-08-27 10:03:21 --> Helper loaded: date_helper
INFO - 2019-08-27 10:03:21 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:21 --> Form Validation Class Initialized
INFO - 2019-08-27 10:03:21 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:21 --> Email Class Initialized
INFO - 2019-08-27 10:03:21 --> Controller Class Initialized
DEBUG - 2019-08-27 10:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:03:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:03:21 --> Final output sent to browser
DEBUG - 2019-08-27 10:03:21 --> Total execution time: 1.7032
INFO - 2019-08-27 10:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:03:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:03:21 --> Pagination Class Initialized
INFO - 2019-08-27 10:03:21 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:21 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:21 --> Controller Class Initialized
INFO - 2019-08-27 10:03:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:03:21 --> Final output sent to browser
DEBUG - 2019-08-27 10:03:21 --> Total execution time: 2.0307
INFO - 2019-08-27 10:03:48 --> Config Class Initialized
INFO - 2019-08-27 10:03:48 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:03:48 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:03:48 --> Utf8 Class Initialized
INFO - 2019-08-27 10:03:48 --> URI Class Initialized
INFO - 2019-08-27 10:03:48 --> Router Class Initialized
INFO - 2019-08-27 10:03:48 --> Output Class Initialized
INFO - 2019-08-27 10:03:48 --> Security Class Initialized
DEBUG - 2019-08-27 10:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:03:48 --> Input Class Initialized
INFO - 2019-08-27 10:03:48 --> Language Class Initialized
INFO - 2019-08-27 10:03:48 --> Loader Class Initialized
INFO - 2019-08-27 10:03:48 --> Helper loaded: url_helper
INFO - 2019-08-27 10:03:48 --> Helper loaded: html_helper
INFO - 2019-08-27 10:03:48 --> Helper loaded: form_helper
INFO - 2019-08-27 10:03:48 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:03:48 --> Helper loaded: date_helper
INFO - 2019-08-27 10:03:48 --> Form Validation Class Initialized
INFO - 2019-08-27 10:03:48 --> Email Class Initialized
DEBUG - 2019-08-27 10:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:03:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:03:49 --> Pagination Class Initialized
INFO - 2019-08-27 10:03:49 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:49 --> Database Driver Class Initialized
INFO - 2019-08-27 10:03:49 --> Controller Class Initialized
INFO - 2019-08-27 10:03:49 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_print.php
INFO - 2019-08-27 10:03:49 --> File loaded: C:\wamp\www\pridehotel\application\views\app/prints/folio.php
INFO - 2019-08-27 10:03:49 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 10:03:49 --> Final output sent to browser
DEBUG - 2019-08-27 10:03:49 --> Total execution time: 1.2015
INFO - 2019-08-27 10:05:20 --> Config Class Initialized
INFO - 2019-08-27 10:05:20 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:05:20 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:05:20 --> Utf8 Class Initialized
INFO - 2019-08-27 10:05:20 --> URI Class Initialized
INFO - 2019-08-27 10:05:20 --> Router Class Initialized
INFO - 2019-08-27 10:05:20 --> Output Class Initialized
INFO - 2019-08-27 10:05:20 --> Security Class Initialized
DEBUG - 2019-08-27 10:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:05:20 --> Input Class Initialized
INFO - 2019-08-27 10:05:20 --> Language Class Initialized
INFO - 2019-08-27 10:05:20 --> Loader Class Initialized
INFO - 2019-08-27 10:05:20 --> Helper loaded: url_helper
INFO - 2019-08-27 10:05:20 --> Helper loaded: html_helper
INFO - 2019-08-27 10:05:20 --> Helper loaded: form_helper
INFO - 2019-08-27 10:05:20 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:05:20 --> Helper loaded: date_helper
INFO - 2019-08-27 10:05:20 --> Form Validation Class Initialized
INFO - 2019-08-27 10:05:20 --> Email Class Initialized
DEBUG - 2019-08-27 10:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:05:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:05:20 --> Pagination Class Initialized
INFO - 2019-08-27 10:05:21 --> Database Driver Class Initialized
INFO - 2019-08-27 10:05:21 --> Database Driver Class Initialized
INFO - 2019-08-27 10:05:21 --> Controller Class Initialized
INFO - 2019-08-27 10:05:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 10:05:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/folio.php
INFO - 2019-08-27 10:05:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 10:05:21 --> Final output sent to browser
DEBUG - 2019-08-27 10:05:21 --> Total execution time: 1.0611
INFO - 2019-08-27 10:05:21 --> Config Class Initialized
INFO - 2019-08-27 10:05:21 --> Config Class Initialized
INFO - 2019-08-27 10:05:21 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:05:21 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:05:21 --> Utf8 Class Initialized
INFO - 2019-08-27 10:05:21 --> URI Class Initialized
INFO - 2019-08-27 10:05:21 --> Router Class Initialized
INFO - 2019-08-27 10:05:21 --> Output Class Initialized
INFO - 2019-08-27 10:05:21 --> Security Class Initialized
DEBUG - 2019-08-27 10:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:05:22 --> Input Class Initialized
INFO - 2019-08-27 10:05:22 --> Hooks Class Initialized
INFO - 2019-08-27 10:05:22 --> Language Class Initialized
DEBUG - 2019-08-27 10:05:22 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:05:22 --> Loader Class Initialized
INFO - 2019-08-27 10:05:22 --> Utf8 Class Initialized
INFO - 2019-08-27 10:05:22 --> URI Class Initialized
INFO - 2019-08-27 10:05:22 --> Helper loaded: url_helper
INFO - 2019-08-27 10:05:22 --> Router Class Initialized
INFO - 2019-08-27 10:05:22 --> Helper loaded: html_helper
INFO - 2019-08-27 10:05:22 --> Output Class Initialized
INFO - 2019-08-27 10:05:22 --> Helper loaded: form_helper
INFO - 2019-08-27 10:05:22 --> Security Class Initialized
INFO - 2019-08-27 10:05:22 --> Helper loaded: cookie_helper
DEBUG - 2019-08-27 10:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:05:22 --> Input Class Initialized
INFO - 2019-08-27 10:05:22 --> Helper loaded: date_helper
INFO - 2019-08-27 10:05:22 --> Language Class Initialized
INFO - 2019-08-27 10:05:22 --> Form Validation Class Initialized
INFO - 2019-08-27 10:05:22 --> Loader Class Initialized
INFO - 2019-08-27 10:05:22 --> Email Class Initialized
INFO - 2019-08-27 10:05:22 --> Helper loaded: url_helper
INFO - 2019-08-27 10:05:22 --> Helper loaded: html_helper
INFO - 2019-08-27 10:05:22 --> Helper loaded: form_helper
DEBUG - 2019-08-27 10:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:05:22 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:05:22 --> Helper loaded: date_helper
INFO - 2019-08-27 10:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:05:23 --> Form Validation Class Initialized
INFO - 2019-08-27 10:05:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:05:23 --> Email Class Initialized
INFO - 2019-08-27 10:05:23 --> Pagination Class Initialized
DEBUG - 2019-08-27 10:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:05:23 --> Database Driver Class Initialized
INFO - 2019-08-27 10:05:23 --> Database Driver Class Initialized
INFO - 2019-08-27 10:05:23 --> Controller Class Initialized
INFO - 2019-08-27 10:05:23 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:05:23 --> Final output sent to browser
DEBUG - 2019-08-27 10:05:23 --> Total execution time: 1.6950
INFO - 2019-08-27 10:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:05:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:05:23 --> Pagination Class Initialized
INFO - 2019-08-27 10:05:23 --> Database Driver Class Initialized
INFO - 2019-08-27 10:05:23 --> Database Driver Class Initialized
INFO - 2019-08-27 10:05:23 --> Controller Class Initialized
INFO - 2019-08-27 10:05:23 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:05:23 --> Final output sent to browser
DEBUG - 2019-08-27 10:05:23 --> Total execution time: 2.0954
INFO - 2019-08-27 10:05:30 --> Config Class Initialized
INFO - 2019-08-27 10:05:30 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:05:30 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:05:30 --> Utf8 Class Initialized
INFO - 2019-08-27 10:05:30 --> URI Class Initialized
INFO - 2019-08-27 10:05:30 --> Router Class Initialized
INFO - 2019-08-27 10:05:30 --> Output Class Initialized
INFO - 2019-08-27 10:05:30 --> Security Class Initialized
DEBUG - 2019-08-27 10:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:05:30 --> Input Class Initialized
INFO - 2019-08-27 10:05:30 --> Language Class Initialized
INFO - 2019-08-27 10:05:30 --> Loader Class Initialized
INFO - 2019-08-27 10:05:30 --> Helper loaded: url_helper
INFO - 2019-08-27 10:05:30 --> Helper loaded: html_helper
INFO - 2019-08-27 10:05:30 --> Helper loaded: form_helper
INFO - 2019-08-27 10:05:30 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:05:30 --> Helper loaded: date_helper
INFO - 2019-08-27 10:05:30 --> Form Validation Class Initialized
INFO - 2019-08-27 10:05:30 --> Email Class Initialized
DEBUG - 2019-08-27 10:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:05:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:05:30 --> Pagination Class Initialized
INFO - 2019-08-27 10:05:30 --> Database Driver Class Initialized
INFO - 2019-08-27 10:05:30 --> Database Driver Class Initialized
INFO - 2019-08-27 10:05:30 --> Controller Class Initialized
INFO - 2019-08-27 10:05:30 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_print.php
INFO - 2019-08-27 10:05:30 --> File loaded: C:\wamp\www\pridehotel\application\views\app/prints/receipt.php
INFO - 2019-08-27 10:05:30 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 10:05:30 --> Final output sent to browser
DEBUG - 2019-08-27 10:05:31 --> Total execution time: 0.9059
INFO - 2019-08-27 10:07:57 --> Config Class Initialized
INFO - 2019-08-27 10:07:57 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:07:57 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:07:57 --> Utf8 Class Initialized
INFO - 2019-08-27 10:07:58 --> URI Class Initialized
INFO - 2019-08-27 10:07:58 --> Router Class Initialized
INFO - 2019-08-27 10:07:58 --> Output Class Initialized
INFO - 2019-08-27 10:07:58 --> Security Class Initialized
DEBUG - 2019-08-27 10:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:07:58 --> Input Class Initialized
INFO - 2019-08-27 10:07:58 --> Language Class Initialized
INFO - 2019-08-27 10:07:58 --> Loader Class Initialized
INFO - 2019-08-27 10:07:58 --> Helper loaded: url_helper
INFO - 2019-08-27 10:07:58 --> Helper loaded: html_helper
INFO - 2019-08-27 10:07:58 --> Helper loaded: form_helper
INFO - 2019-08-27 10:07:58 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:07:58 --> Helper loaded: date_helper
INFO - 2019-08-27 10:07:58 --> Form Validation Class Initialized
INFO - 2019-08-27 10:07:58 --> Email Class Initialized
DEBUG - 2019-08-27 10:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:07:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:07:58 --> Pagination Class Initialized
INFO - 2019-08-27 10:07:58 --> Database Driver Class Initialized
INFO - 2019-08-27 10:07:58 --> Database Driver Class Initialized
INFO - 2019-08-27 10:07:58 --> Controller Class Initialized
INFO - 2019-08-27 10:07:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_print.php
INFO - 2019-08-27 10:07:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/prints/folio.php
INFO - 2019-08-27 10:07:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 10:07:58 --> Final output sent to browser
DEBUG - 2019-08-27 10:07:58 --> Total execution time: 0.9775
INFO - 2019-08-27 10:08:07 --> Config Class Initialized
INFO - 2019-08-27 10:08:08 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:08:08 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:08:08 --> Utf8 Class Initialized
INFO - 2019-08-27 10:08:08 --> URI Class Initialized
INFO - 2019-08-27 10:08:08 --> Router Class Initialized
INFO - 2019-08-27 10:08:08 --> Output Class Initialized
INFO - 2019-08-27 10:08:08 --> Security Class Initialized
DEBUG - 2019-08-27 10:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:08:08 --> Input Class Initialized
INFO - 2019-08-27 10:08:08 --> Language Class Initialized
INFO - 2019-08-27 10:08:08 --> Loader Class Initialized
INFO - 2019-08-27 10:08:08 --> Helper loaded: url_helper
INFO - 2019-08-27 10:08:08 --> Helper loaded: html_helper
INFO - 2019-08-27 10:08:08 --> Helper loaded: form_helper
INFO - 2019-08-27 10:08:08 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:08:08 --> Helper loaded: date_helper
INFO - 2019-08-27 10:08:08 --> Form Validation Class Initialized
INFO - 2019-08-27 10:08:08 --> Email Class Initialized
DEBUG - 2019-08-27 10:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:08:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:08:08 --> Pagination Class Initialized
INFO - 2019-08-27 10:08:08 --> Database Driver Class Initialized
INFO - 2019-08-27 10:08:08 --> Database Driver Class Initialized
INFO - 2019-08-27 10:08:08 --> Controller Class Initialized
INFO - 2019-08-27 10:08:08 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 10:08:08 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/folio.php
INFO - 2019-08-27 10:08:08 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 10:08:09 --> Final output sent to browser
DEBUG - 2019-08-27 10:08:09 --> Total execution time: 1.0751
INFO - 2019-08-27 10:08:09 --> Config Class Initialized
INFO - 2019-08-27 10:08:09 --> Hooks Class Initialized
INFO - 2019-08-27 10:08:09 --> Config Class Initialized
INFO - 2019-08-27 10:08:09 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:08:09 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:08:09 --> Utf8 Class Initialized
INFO - 2019-08-27 10:08:09 --> URI Class Initialized
DEBUG - 2019-08-27 10:08:09 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:08:09 --> Utf8 Class Initialized
INFO - 2019-08-27 10:08:09 --> URI Class Initialized
INFO - 2019-08-27 10:08:09 --> Router Class Initialized
INFO - 2019-08-27 10:08:09 --> Output Class Initialized
INFO - 2019-08-27 10:08:09 --> Router Class Initialized
INFO - 2019-08-27 10:08:09 --> Security Class Initialized
INFO - 2019-08-27 10:08:09 --> Output Class Initialized
DEBUG - 2019-08-27 10:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:08:09 --> Security Class Initialized
INFO - 2019-08-27 10:08:09 --> Input Class Initialized
INFO - 2019-08-27 10:08:10 --> Language Class Initialized
DEBUG - 2019-08-27 10:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:08:10 --> Loader Class Initialized
INFO - 2019-08-27 10:08:10 --> Input Class Initialized
INFO - 2019-08-27 10:08:10 --> Helper loaded: url_helper
INFO - 2019-08-27 10:08:10 --> Language Class Initialized
INFO - 2019-08-27 10:08:10 --> Helper loaded: html_helper
INFO - 2019-08-27 10:08:10 --> Loader Class Initialized
INFO - 2019-08-27 10:08:10 --> Helper loaded: form_helper
INFO - 2019-08-27 10:08:10 --> Helper loaded: url_helper
INFO - 2019-08-27 10:08:10 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:08:10 --> Helper loaded: html_helper
INFO - 2019-08-27 10:08:10 --> Helper loaded: date_helper
INFO - 2019-08-27 10:08:10 --> Helper loaded: form_helper
INFO - 2019-08-27 10:08:10 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:08:10 --> Form Validation Class Initialized
INFO - 2019-08-27 10:08:10 --> Helper loaded: date_helper
INFO - 2019-08-27 10:08:10 --> Email Class Initialized
INFO - 2019-08-27 10:08:10 --> Form Validation Class Initialized
DEBUG - 2019-08-27 10:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:08:10 --> Email Class Initialized
INFO - 2019-08-27 10:08:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-08-27 10:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:08:10 --> Pagination Class Initialized
INFO - 2019-08-27 10:08:10 --> Database Driver Class Initialized
INFO - 2019-08-27 10:08:10 --> Database Driver Class Initialized
INFO - 2019-08-27 10:08:10 --> Controller Class Initialized
INFO - 2019-08-27 10:08:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:08:10 --> Final output sent to browser
DEBUG - 2019-08-27 10:08:11 --> Total execution time: 1.6311
INFO - 2019-08-27 10:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:08:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:08:11 --> Pagination Class Initialized
INFO - 2019-08-27 10:08:11 --> Database Driver Class Initialized
INFO - 2019-08-27 10:08:11 --> Database Driver Class Initialized
INFO - 2019-08-27 10:08:11 --> Controller Class Initialized
INFO - 2019-08-27 10:08:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:08:11 --> Final output sent to browser
DEBUG - 2019-08-27 10:08:11 --> Total execution time: 1.9852
INFO - 2019-08-27 10:10:30 --> Config Class Initialized
INFO - 2019-08-27 10:10:30 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:10:30 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:10:30 --> Utf8 Class Initialized
INFO - 2019-08-27 10:10:30 --> URI Class Initialized
INFO - 2019-08-27 10:10:30 --> Router Class Initialized
INFO - 2019-08-27 10:10:30 --> Output Class Initialized
INFO - 2019-08-27 10:10:30 --> Security Class Initialized
DEBUG - 2019-08-27 10:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:10:30 --> Input Class Initialized
INFO - 2019-08-27 10:10:30 --> Language Class Initialized
INFO - 2019-08-27 10:10:30 --> Loader Class Initialized
INFO - 2019-08-27 10:10:30 --> Helper loaded: url_helper
INFO - 2019-08-27 10:10:30 --> Helper loaded: html_helper
INFO - 2019-08-27 10:10:30 --> Helper loaded: form_helper
INFO - 2019-08-27 10:10:30 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:10:30 --> Helper loaded: date_helper
INFO - 2019-08-27 10:10:30 --> Form Validation Class Initialized
INFO - 2019-08-27 10:10:30 --> Email Class Initialized
DEBUG - 2019-08-27 10:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:10:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:10:30 --> Pagination Class Initialized
INFO - 2019-08-27 10:10:30 --> Database Driver Class Initialized
INFO - 2019-08-27 10:10:30 --> Database Driver Class Initialized
INFO - 2019-08-27 10:10:30 --> Controller Class Initialized
INFO - 2019-08-27 10:10:31 --> Final output sent to browser
DEBUG - 2019-08-27 10:10:31 --> Total execution time: 0.7176
INFO - 2019-08-27 10:10:39 --> Config Class Initialized
INFO - 2019-08-27 10:10:39 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:10:39 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:10:39 --> Utf8 Class Initialized
INFO - 2019-08-27 10:10:39 --> URI Class Initialized
INFO - 2019-08-27 10:10:39 --> Router Class Initialized
INFO - 2019-08-27 10:10:39 --> Output Class Initialized
INFO - 2019-08-27 10:10:39 --> Security Class Initialized
DEBUG - 2019-08-27 10:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:10:39 --> Input Class Initialized
INFO - 2019-08-27 10:10:39 --> Language Class Initialized
INFO - 2019-08-27 10:10:39 --> Loader Class Initialized
INFO - 2019-08-27 10:10:39 --> Helper loaded: url_helper
INFO - 2019-08-27 10:10:39 --> Helper loaded: html_helper
INFO - 2019-08-27 10:10:39 --> Helper loaded: form_helper
INFO - 2019-08-27 10:10:39 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:10:39 --> Helper loaded: date_helper
INFO - 2019-08-27 10:10:39 --> Form Validation Class Initialized
INFO - 2019-08-27 10:10:39 --> Email Class Initialized
DEBUG - 2019-08-27 10:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:10:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:10:39 --> Pagination Class Initialized
INFO - 2019-08-27 10:10:39 --> Database Driver Class Initialized
INFO - 2019-08-27 10:10:39 --> Database Driver Class Initialized
INFO - 2019-08-27 10:10:39 --> Controller Class Initialized
INFO - 2019-08-27 10:10:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-27 10:10:40 --> Config Class Initialized
INFO - 2019-08-27 10:10:40 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:10:40 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:10:40 --> Utf8 Class Initialized
INFO - 2019-08-27 10:10:40 --> URI Class Initialized
INFO - 2019-08-27 10:10:40 --> Router Class Initialized
INFO - 2019-08-27 10:10:40 --> Output Class Initialized
INFO - 2019-08-27 10:10:40 --> Security Class Initialized
DEBUG - 2019-08-27 10:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:10:40 --> Input Class Initialized
INFO - 2019-08-27 10:10:40 --> Language Class Initialized
INFO - 2019-08-27 10:10:40 --> Loader Class Initialized
INFO - 2019-08-27 10:10:40 --> Helper loaded: url_helper
INFO - 2019-08-27 10:10:40 --> Helper loaded: html_helper
INFO - 2019-08-27 10:10:40 --> Helper loaded: form_helper
INFO - 2019-08-27 10:10:40 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:10:40 --> Helper loaded: date_helper
INFO - 2019-08-27 10:10:40 --> Form Validation Class Initialized
INFO - 2019-08-27 10:10:40 --> Email Class Initialized
DEBUG - 2019-08-27 10:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:10:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:10:40 --> Pagination Class Initialized
INFO - 2019-08-27 10:10:40 --> Database Driver Class Initialized
INFO - 2019-08-27 10:10:40 --> Database Driver Class Initialized
INFO - 2019-08-27 10:10:40 --> Controller Class Initialized
INFO - 2019-08-27 10:10:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 10:10:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/folio.php
INFO - 2019-08-27 10:10:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 10:10:41 --> Final output sent to browser
DEBUG - 2019-08-27 10:10:41 --> Total execution time: 1.1393
INFO - 2019-08-27 10:10:41 --> Config Class Initialized
INFO - 2019-08-27 10:10:41 --> Config Class Initialized
INFO - 2019-08-27 10:10:41 --> Hooks Class Initialized
INFO - 2019-08-27 10:10:41 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:10:41 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:10:41 --> Utf8 Class Initialized
INFO - 2019-08-27 10:10:41 --> URI Class Initialized
INFO - 2019-08-27 10:10:41 --> Router Class Initialized
INFO - 2019-08-27 10:10:41 --> Output Class Initialized
INFO - 2019-08-27 10:10:41 --> Security Class Initialized
DEBUG - 2019-08-27 10:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:10:41 --> Input Class Initialized
INFO - 2019-08-27 10:10:42 --> Language Class Initialized
DEBUG - 2019-08-27 10:10:42 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:10:42 --> Utf8 Class Initialized
INFO - 2019-08-27 10:10:42 --> Loader Class Initialized
INFO - 2019-08-27 10:10:42 --> URI Class Initialized
INFO - 2019-08-27 10:10:42 --> Helper loaded: url_helper
INFO - 2019-08-27 10:10:42 --> Router Class Initialized
INFO - 2019-08-27 10:10:42 --> Helper loaded: html_helper
INFO - 2019-08-27 10:10:42 --> Output Class Initialized
INFO - 2019-08-27 10:10:42 --> Helper loaded: form_helper
INFO - 2019-08-27 10:10:42 --> Security Class Initialized
INFO - 2019-08-27 10:10:42 --> Helper loaded: cookie_helper
DEBUG - 2019-08-27 10:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:10:42 --> Input Class Initialized
INFO - 2019-08-27 10:10:42 --> Helper loaded: date_helper
INFO - 2019-08-27 10:10:42 --> Language Class Initialized
INFO - 2019-08-27 10:10:42 --> Form Validation Class Initialized
INFO - 2019-08-27 10:10:42 --> Loader Class Initialized
INFO - 2019-08-27 10:10:42 --> Email Class Initialized
INFO - 2019-08-27 10:10:42 --> Helper loaded: url_helper
DEBUG - 2019-08-27 10:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:10:42 --> Helper loaded: html_helper
INFO - 2019-08-27 10:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:10:42 --> Helper loaded: form_helper
INFO - 2019-08-27 10:10:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:10:42 --> Pagination Class Initialized
INFO - 2019-08-27 10:10:42 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:10:42 --> Helper loaded: date_helper
INFO - 2019-08-27 10:10:42 --> Database Driver Class Initialized
INFO - 2019-08-27 10:10:43 --> Form Validation Class Initialized
INFO - 2019-08-27 10:10:43 --> Database Driver Class Initialized
INFO - 2019-08-27 10:10:43 --> Email Class Initialized
INFO - 2019-08-27 10:10:43 --> Controller Class Initialized
DEBUG - 2019-08-27 10:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:10:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:10:43 --> Final output sent to browser
DEBUG - 2019-08-27 10:10:43 --> Total execution time: 1.7062
INFO - 2019-08-27 10:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:10:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:10:43 --> Pagination Class Initialized
INFO - 2019-08-27 10:10:43 --> Database Driver Class Initialized
INFO - 2019-08-27 10:10:43 --> Database Driver Class Initialized
INFO - 2019-08-27 10:10:43 --> Controller Class Initialized
INFO - 2019-08-27 10:10:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:10:43 --> Final output sent to browser
DEBUG - 2019-08-27 10:10:43 --> Total execution time: 2.0907
INFO - 2019-08-27 10:14:37 --> Config Class Initialized
INFO - 2019-08-27 10:14:37 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:14:37 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:14:37 --> Utf8 Class Initialized
INFO - 2019-08-27 10:14:37 --> URI Class Initialized
INFO - 2019-08-27 10:14:37 --> Router Class Initialized
INFO - 2019-08-27 10:14:37 --> Output Class Initialized
INFO - 2019-08-27 10:14:37 --> Security Class Initialized
DEBUG - 2019-08-27 10:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:14:37 --> Input Class Initialized
INFO - 2019-08-27 10:14:38 --> Language Class Initialized
INFO - 2019-08-27 10:14:38 --> Loader Class Initialized
INFO - 2019-08-27 10:14:38 --> Helper loaded: url_helper
INFO - 2019-08-27 10:14:38 --> Helper loaded: html_helper
INFO - 2019-08-27 10:14:38 --> Helper loaded: form_helper
INFO - 2019-08-27 10:14:38 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:14:38 --> Helper loaded: date_helper
INFO - 2019-08-27 10:14:38 --> Form Validation Class Initialized
INFO - 2019-08-27 10:14:38 --> Email Class Initialized
DEBUG - 2019-08-27 10:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:14:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:14:38 --> Pagination Class Initialized
INFO - 2019-08-27 10:14:38 --> Database Driver Class Initialized
INFO - 2019-08-27 10:14:38 --> Database Driver Class Initialized
INFO - 2019-08-27 10:14:38 --> Controller Class Initialized
INFO - 2019-08-27 10:14:38 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_print.php
INFO - 2019-08-27 10:14:38 --> File loaded: C:\wamp\www\pridehotel\application\views\app/prints/folio.php
INFO - 2019-08-27 10:14:38 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 10:14:38 --> Final output sent to browser
DEBUG - 2019-08-27 10:14:38 --> Total execution time: 1.0038
INFO - 2019-08-27 10:16:10 --> Config Class Initialized
INFO - 2019-08-27 10:16:10 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:16:10 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:16:10 --> Utf8 Class Initialized
INFO - 2019-08-27 10:16:11 --> URI Class Initialized
INFO - 2019-08-27 10:16:11 --> Router Class Initialized
INFO - 2019-08-27 10:16:11 --> Output Class Initialized
INFO - 2019-08-27 10:16:11 --> Security Class Initialized
DEBUG - 2019-08-27 10:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:16:11 --> Input Class Initialized
INFO - 2019-08-27 10:16:11 --> Language Class Initialized
INFO - 2019-08-27 10:16:11 --> Loader Class Initialized
INFO - 2019-08-27 10:16:11 --> Helper loaded: url_helper
INFO - 2019-08-27 10:16:11 --> Helper loaded: html_helper
INFO - 2019-08-27 10:16:11 --> Helper loaded: form_helper
INFO - 2019-08-27 10:16:11 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:16:11 --> Helper loaded: date_helper
INFO - 2019-08-27 10:16:11 --> Form Validation Class Initialized
INFO - 2019-08-27 10:16:11 --> Email Class Initialized
DEBUG - 2019-08-27 10:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:16:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:16:11 --> Pagination Class Initialized
INFO - 2019-08-27 10:16:11 --> Database Driver Class Initialized
INFO - 2019-08-27 10:16:11 --> Database Driver Class Initialized
INFO - 2019-08-27 10:16:11 --> Controller Class Initialized
INFO - 2019-08-27 10:16:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 10:16:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/folio.php
INFO - 2019-08-27 10:16:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 10:16:11 --> Final output sent to browser
DEBUG - 2019-08-27 10:16:12 --> Total execution time: 1.0462
INFO - 2019-08-27 10:16:12 --> Config Class Initialized
INFO - 2019-08-27 10:16:12 --> Config Class Initialized
INFO - 2019-08-27 10:16:12 --> Hooks Class Initialized
INFO - 2019-08-27 10:16:12 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:16:12 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:16:12 --> Utf8 Class Initialized
INFO - 2019-08-27 10:16:12 --> URI Class Initialized
INFO - 2019-08-27 10:16:12 --> Router Class Initialized
INFO - 2019-08-27 10:16:12 --> Output Class Initialized
INFO - 2019-08-27 10:16:12 --> Security Class Initialized
DEBUG - 2019-08-27 10:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:16:12 --> Input Class Initialized
INFO - 2019-08-27 10:16:12 --> Language Class Initialized
DEBUG - 2019-08-27 10:16:12 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:16:12 --> Loader Class Initialized
INFO - 2019-08-27 10:16:12 --> Utf8 Class Initialized
INFO - 2019-08-27 10:16:12 --> URI Class Initialized
INFO - 2019-08-27 10:16:12 --> Helper loaded: url_helper
INFO - 2019-08-27 10:16:12 --> Router Class Initialized
INFO - 2019-08-27 10:16:12 --> Helper loaded: html_helper
INFO - 2019-08-27 10:16:12 --> Output Class Initialized
INFO - 2019-08-27 10:16:12 --> Helper loaded: form_helper
INFO - 2019-08-27 10:16:12 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:16:12 --> Security Class Initialized
INFO - 2019-08-27 10:16:13 --> Helper loaded: date_helper
DEBUG - 2019-08-27 10:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:16:13 --> Input Class Initialized
INFO - 2019-08-27 10:16:13 --> Form Validation Class Initialized
INFO - 2019-08-27 10:16:13 --> Language Class Initialized
INFO - 2019-08-27 10:16:13 --> Email Class Initialized
INFO - 2019-08-27 10:16:13 --> Loader Class Initialized
DEBUG - 2019-08-27 10:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:16:13 --> Helper loaded: url_helper
INFO - 2019-08-27 10:16:13 --> Helper loaded: html_helper
INFO - 2019-08-27 10:16:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:16:13 --> Helper loaded: form_helper
INFO - 2019-08-27 10:16:13 --> Pagination Class Initialized
INFO - 2019-08-27 10:16:13 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:16:13 --> Database Driver Class Initialized
INFO - 2019-08-27 10:16:13 --> Helper loaded: date_helper
INFO - 2019-08-27 10:16:13 --> Database Driver Class Initialized
INFO - 2019-08-27 10:16:13 --> Form Validation Class Initialized
INFO - 2019-08-27 10:16:13 --> Controller Class Initialized
INFO - 2019-08-27 10:16:13 --> Email Class Initialized
DEBUG - 2019-08-27 10:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:16:13 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:16:13 --> Final output sent to browser
DEBUG - 2019-08-27 10:16:13 --> Total execution time: 1.5100
INFO - 2019-08-27 10:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:16:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:16:13 --> Pagination Class Initialized
INFO - 2019-08-27 10:16:13 --> Database Driver Class Initialized
INFO - 2019-08-27 10:16:13 --> Database Driver Class Initialized
INFO - 2019-08-27 10:16:14 --> Controller Class Initialized
INFO - 2019-08-27 10:16:14 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:16:14 --> Final output sent to browser
DEBUG - 2019-08-27 10:16:14 --> Total execution time: 1.8842
INFO - 2019-08-27 10:16:29 --> Config Class Initialized
INFO - 2019-08-27 10:16:29 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:16:29 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:16:29 --> Utf8 Class Initialized
INFO - 2019-08-27 10:16:29 --> URI Class Initialized
INFO - 2019-08-27 10:16:30 --> Router Class Initialized
INFO - 2019-08-27 10:16:30 --> Output Class Initialized
INFO - 2019-08-27 10:16:30 --> Security Class Initialized
DEBUG - 2019-08-27 10:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:16:30 --> Input Class Initialized
INFO - 2019-08-27 10:16:30 --> Language Class Initialized
INFO - 2019-08-27 10:16:30 --> Loader Class Initialized
INFO - 2019-08-27 10:16:30 --> Helper loaded: url_helper
INFO - 2019-08-27 10:16:30 --> Helper loaded: html_helper
INFO - 2019-08-27 10:16:30 --> Helper loaded: form_helper
INFO - 2019-08-27 10:16:30 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:16:30 --> Helper loaded: date_helper
INFO - 2019-08-27 10:16:30 --> Form Validation Class Initialized
INFO - 2019-08-27 10:16:30 --> Email Class Initialized
DEBUG - 2019-08-27 10:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:16:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:16:30 --> Pagination Class Initialized
INFO - 2019-08-27 10:16:30 --> Database Driver Class Initialized
INFO - 2019-08-27 10:16:30 --> Database Driver Class Initialized
INFO - 2019-08-27 10:16:30 --> Controller Class Initialized
INFO - 2019-08-27 10:16:30 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:16:30 --> Final output sent to browser
DEBUG - 2019-08-27 10:16:30 --> Total execution time: 0.9934
INFO - 2019-08-27 10:16:31 --> Config Class Initialized
INFO - 2019-08-27 10:16:31 --> Hooks Class Initialized
DEBUG - 2019-08-27 10:16:31 --> UTF-8 Support Enabled
INFO - 2019-08-27 10:16:31 --> Utf8 Class Initialized
INFO - 2019-08-27 10:16:31 --> URI Class Initialized
INFO - 2019-08-27 10:16:31 --> Router Class Initialized
INFO - 2019-08-27 10:16:31 --> Output Class Initialized
INFO - 2019-08-27 10:16:31 --> Security Class Initialized
DEBUG - 2019-08-27 10:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 10:16:31 --> Input Class Initialized
INFO - 2019-08-27 10:16:31 --> Language Class Initialized
INFO - 2019-08-27 10:16:31 --> Loader Class Initialized
INFO - 2019-08-27 10:16:31 --> Helper loaded: url_helper
INFO - 2019-08-27 10:16:32 --> Helper loaded: html_helper
INFO - 2019-08-27 10:16:32 --> Helper loaded: form_helper
INFO - 2019-08-27 10:16:32 --> Helper loaded: cookie_helper
INFO - 2019-08-27 10:16:32 --> Helper loaded: date_helper
INFO - 2019-08-27 10:16:32 --> Form Validation Class Initialized
INFO - 2019-08-27 10:16:32 --> Email Class Initialized
DEBUG - 2019-08-27 10:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 10:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 10:16:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 10:16:32 --> Pagination Class Initialized
INFO - 2019-08-27 10:16:32 --> Database Driver Class Initialized
INFO - 2019-08-27 10:16:32 --> Database Driver Class Initialized
INFO - 2019-08-27 10:16:32 --> Controller Class Initialized
INFO - 2019-08-27 10:16:32 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 10:16:32 --> Final output sent to browser
DEBUG - 2019-08-27 10:16:32 --> Total execution time: 0.8273
INFO - 2019-08-27 12:23:40 --> Config Class Initialized
INFO - 2019-08-27 12:23:40 --> Hooks Class Initialized
DEBUG - 2019-08-27 12:23:40 --> UTF-8 Support Enabled
INFO - 2019-08-27 12:23:40 --> Utf8 Class Initialized
INFO - 2019-08-27 12:23:41 --> URI Class Initialized
INFO - 2019-08-27 12:23:41 --> Router Class Initialized
INFO - 2019-08-27 12:23:41 --> Output Class Initialized
INFO - 2019-08-27 12:23:41 --> Security Class Initialized
DEBUG - 2019-08-27 12:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 12:23:41 --> Input Class Initialized
INFO - 2019-08-27 12:23:41 --> Language Class Initialized
INFO - 2019-08-27 12:23:42 --> Loader Class Initialized
INFO - 2019-08-27 12:23:42 --> Helper loaded: url_helper
INFO - 2019-08-27 12:23:42 --> Helper loaded: html_helper
INFO - 2019-08-27 12:23:43 --> Helper loaded: form_helper
INFO - 2019-08-27 12:23:43 --> Helper loaded: cookie_helper
INFO - 2019-08-27 12:23:43 --> Helper loaded: date_helper
INFO - 2019-08-27 12:23:43 --> Form Validation Class Initialized
INFO - 2019-08-27 12:23:43 --> Email Class Initialized
DEBUG - 2019-08-27 12:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 12:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 12:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 12:23:43 --> Pagination Class Initialized
INFO - 2019-08-27 12:23:44 --> Database Driver Class Initialized
INFO - 2019-08-27 12:23:44 --> Database Driver Class Initialized
INFO - 2019-08-27 12:23:45 --> Controller Class Initialized
INFO - 2019-08-27 12:23:45 --> Config Class Initialized
INFO - 2019-08-27 12:23:45 --> Hooks Class Initialized
DEBUG - 2019-08-27 12:23:45 --> UTF-8 Support Enabled
INFO - 2019-08-27 12:23:45 --> Utf8 Class Initialized
INFO - 2019-08-27 12:23:46 --> URI Class Initialized
INFO - 2019-08-27 12:23:46 --> Router Class Initialized
INFO - 2019-08-27 12:23:46 --> Output Class Initialized
INFO - 2019-08-27 12:23:46 --> Security Class Initialized
DEBUG - 2019-08-27 12:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 12:23:46 --> Input Class Initialized
INFO - 2019-08-27 12:23:46 --> Language Class Initialized
INFO - 2019-08-27 12:23:46 --> Loader Class Initialized
INFO - 2019-08-27 12:23:46 --> Helper loaded: url_helper
INFO - 2019-08-27 12:23:46 --> Helper loaded: html_helper
INFO - 2019-08-27 12:23:46 --> Helper loaded: form_helper
INFO - 2019-08-27 12:23:46 --> Helper loaded: cookie_helper
INFO - 2019-08-27 12:23:46 --> Helper loaded: date_helper
INFO - 2019-08-27 12:23:46 --> Form Validation Class Initialized
INFO - 2019-08-27 12:23:46 --> Email Class Initialized
DEBUG - 2019-08-27 12:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 12:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 12:23:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 12:23:46 --> Pagination Class Initialized
INFO - 2019-08-27 12:23:46 --> Database Driver Class Initialized
INFO - 2019-08-27 12:23:46 --> Database Driver Class Initialized
INFO - 2019-08-27 12:23:46 --> Controller Class Initialized
INFO - 2019-08-27 12:23:47 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-27 12:23:47 --> Final output sent to browser
DEBUG - 2019-08-27 12:23:47 --> Total execution time: 1.2476
INFO - 2019-08-27 12:23:59 --> Config Class Initialized
INFO - 2019-08-27 12:23:59 --> Hooks Class Initialized
DEBUG - 2019-08-27 12:23:59 --> UTF-8 Support Enabled
INFO - 2019-08-27 12:23:59 --> Utf8 Class Initialized
INFO - 2019-08-27 12:23:59 --> URI Class Initialized
INFO - 2019-08-27 12:23:59 --> Router Class Initialized
INFO - 2019-08-27 12:23:59 --> Output Class Initialized
INFO - 2019-08-27 12:23:59 --> Security Class Initialized
DEBUG - 2019-08-27 12:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 12:23:59 --> Input Class Initialized
INFO - 2019-08-27 12:23:59 --> Language Class Initialized
INFO - 2019-08-27 12:23:59 --> Loader Class Initialized
INFO - 2019-08-27 12:23:59 --> Helper loaded: url_helper
INFO - 2019-08-27 12:23:59 --> Helper loaded: html_helper
INFO - 2019-08-27 12:23:59 --> Helper loaded: form_helper
INFO - 2019-08-27 12:23:59 --> Helper loaded: cookie_helper
INFO - 2019-08-27 12:23:59 --> Helper loaded: date_helper
INFO - 2019-08-27 12:23:59 --> Form Validation Class Initialized
INFO - 2019-08-27 12:23:59 --> Email Class Initialized
DEBUG - 2019-08-27 12:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 12:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 12:23:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 12:24:00 --> Pagination Class Initialized
INFO - 2019-08-27 12:24:00 --> Database Driver Class Initialized
INFO - 2019-08-27 12:24:00 --> Database Driver Class Initialized
INFO - 2019-08-27 12:24:00 --> Controller Class Initialized
INFO - 2019-08-27 12:24:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-27 12:24:00 --> Config Class Initialized
INFO - 2019-08-27 12:24:00 --> Hooks Class Initialized
DEBUG - 2019-08-27 12:24:00 --> UTF-8 Support Enabled
INFO - 2019-08-27 12:24:00 --> Utf8 Class Initialized
INFO - 2019-08-27 12:24:00 --> URI Class Initialized
INFO - 2019-08-27 12:24:00 --> Router Class Initialized
INFO - 2019-08-27 12:24:00 --> Output Class Initialized
INFO - 2019-08-27 12:24:00 --> Security Class Initialized
DEBUG - 2019-08-27 12:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 12:24:00 --> Input Class Initialized
INFO - 2019-08-27 12:24:00 --> Language Class Initialized
INFO - 2019-08-27 12:24:00 --> Loader Class Initialized
INFO - 2019-08-27 12:24:00 --> Helper loaded: url_helper
INFO - 2019-08-27 12:24:00 --> Helper loaded: html_helper
INFO - 2019-08-27 12:24:00 --> Helper loaded: form_helper
INFO - 2019-08-27 12:24:00 --> Helper loaded: cookie_helper
INFO - 2019-08-27 12:24:00 --> Helper loaded: date_helper
INFO - 2019-08-27 12:24:00 --> Form Validation Class Initialized
INFO - 2019-08-27 12:24:00 --> Email Class Initialized
DEBUG - 2019-08-27 12:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 12:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 12:24:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 12:24:00 --> Pagination Class Initialized
INFO - 2019-08-27 12:24:01 --> Database Driver Class Initialized
INFO - 2019-08-27 12:24:01 --> Database Driver Class Initialized
INFO - 2019-08-27 12:24:01 --> Controller Class Initialized
INFO - 2019-08-27 12:24:01 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 12:24:01 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-27 12:24:01 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 12:24:01 --> Final output sent to browser
DEBUG - 2019-08-27 12:24:01 --> Total execution time: 1.4251
INFO - 2019-08-27 12:24:02 --> Config Class Initialized
INFO - 2019-08-27 12:24:02 --> Hooks Class Initialized
DEBUG - 2019-08-27 12:24:02 --> UTF-8 Support Enabled
INFO - 2019-08-27 12:24:02 --> Utf8 Class Initialized
INFO - 2019-08-27 12:24:02 --> URI Class Initialized
INFO - 2019-08-27 12:24:02 --> Router Class Initialized
INFO - 2019-08-27 12:24:02 --> Output Class Initialized
INFO - 2019-08-27 12:24:02 --> Security Class Initialized
DEBUG - 2019-08-27 12:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 12:24:02 --> Input Class Initialized
INFO - 2019-08-27 12:24:02 --> Language Class Initialized
INFO - 2019-08-27 12:24:02 --> Config Class Initialized
INFO - 2019-08-27 12:24:02 --> Hooks Class Initialized
DEBUG - 2019-08-27 12:24:02 --> UTF-8 Support Enabled
INFO - 2019-08-27 12:24:02 --> Utf8 Class Initialized
INFO - 2019-08-27 12:24:02 --> Loader Class Initialized
INFO - 2019-08-27 12:24:02 --> URI Class Initialized
INFO - 2019-08-27 12:24:02 --> Helper loaded: url_helper
INFO - 2019-08-27 12:24:03 --> Router Class Initialized
INFO - 2019-08-27 12:24:03 --> Helper loaded: html_helper
INFO - 2019-08-27 12:24:03 --> Output Class Initialized
INFO - 2019-08-27 12:24:03 --> Helper loaded: form_helper
INFO - 2019-08-27 12:24:03 --> Security Class Initialized
INFO - 2019-08-27 12:24:03 --> Helper loaded: cookie_helper
INFO - 2019-08-27 12:24:03 --> Helper loaded: date_helper
DEBUG - 2019-08-27 12:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 12:24:03 --> Input Class Initialized
INFO - 2019-08-27 12:24:03 --> Form Validation Class Initialized
INFO - 2019-08-27 12:24:03 --> Language Class Initialized
INFO - 2019-08-27 12:24:03 --> Email Class Initialized
INFO - 2019-08-27 12:24:03 --> Loader Class Initialized
INFO - 2019-08-27 12:24:03 --> Helper loaded: url_helper
INFO - 2019-08-27 12:24:03 --> Helper loaded: html_helper
DEBUG - 2019-08-27 12:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 12:24:03 --> Helper loaded: form_helper
INFO - 2019-08-27 12:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 12:24:03 --> Helper loaded: cookie_helper
INFO - 2019-08-27 12:24:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 12:24:03 --> Pagination Class Initialized
INFO - 2019-08-27 12:24:03 --> Helper loaded: date_helper
INFO - 2019-08-27 12:24:03 --> Database Driver Class Initialized
INFO - 2019-08-27 12:24:03 --> Form Validation Class Initialized
INFO - 2019-08-27 12:24:03 --> Database Driver Class Initialized
INFO - 2019-08-27 12:24:03 --> Email Class Initialized
INFO - 2019-08-27 12:24:03 --> Controller Class Initialized
DEBUG - 2019-08-27 12:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 12:24:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 12:24:04 --> Final output sent to browser
DEBUG - 2019-08-27 12:24:04 --> Total execution time: 1.7819
INFO - 2019-08-27 12:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 12:24:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 12:24:04 --> Pagination Class Initialized
INFO - 2019-08-27 12:24:04 --> Database Driver Class Initialized
INFO - 2019-08-27 12:24:04 --> Database Driver Class Initialized
INFO - 2019-08-27 12:24:04 --> Controller Class Initialized
INFO - 2019-08-27 12:24:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 12:24:04 --> Final output sent to browser
DEBUG - 2019-08-27 12:24:04 --> Total execution time: 2.1242
INFO - 2019-08-27 12:26:45 --> Config Class Initialized
INFO - 2019-08-27 12:26:46 --> Hooks Class Initialized
DEBUG - 2019-08-27 12:26:46 --> UTF-8 Support Enabled
INFO - 2019-08-27 12:26:46 --> Utf8 Class Initialized
INFO - 2019-08-27 12:26:46 --> URI Class Initialized
INFO - 2019-08-27 12:26:46 --> Config Class Initialized
INFO - 2019-08-27 12:26:46 --> Hooks Class Initialized
INFO - 2019-08-27 12:26:46 --> Router Class Initialized
DEBUG - 2019-08-27 12:26:46 --> UTF-8 Support Enabled
INFO - 2019-08-27 12:26:46 --> Utf8 Class Initialized
INFO - 2019-08-27 12:26:46 --> Output Class Initialized
INFO - 2019-08-27 12:26:46 --> URI Class Initialized
INFO - 2019-08-27 12:26:46 --> Security Class Initialized
INFO - 2019-08-27 12:26:46 --> Router Class Initialized
DEBUG - 2019-08-27 12:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 12:26:46 --> Input Class Initialized
INFO - 2019-08-27 12:26:46 --> Output Class Initialized
INFO - 2019-08-27 12:26:46 --> Language Class Initialized
INFO - 2019-08-27 12:26:46 --> Security Class Initialized
INFO - 2019-08-27 12:26:46 --> Loader Class Initialized
DEBUG - 2019-08-27 12:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 12:26:46 --> Helper loaded: url_helper
INFO - 2019-08-27 12:26:46 --> Input Class Initialized
INFO - 2019-08-27 12:26:46 --> Helper loaded: html_helper
INFO - 2019-08-27 12:26:46 --> Language Class Initialized
INFO - 2019-08-27 12:26:46 --> Helper loaded: form_helper
INFO - 2019-08-27 12:26:46 --> Loader Class Initialized
INFO - 2019-08-27 12:26:46 --> Helper loaded: cookie_helper
INFO - 2019-08-27 12:26:46 --> Helper loaded: url_helper
INFO - 2019-08-27 12:26:46 --> Helper loaded: date_helper
INFO - 2019-08-27 12:26:46 --> Helper loaded: html_helper
INFO - 2019-08-27 12:26:46 --> Form Validation Class Initialized
INFO - 2019-08-27 12:26:46 --> Helper loaded: form_helper
INFO - 2019-08-27 12:26:46 --> Email Class Initialized
INFO - 2019-08-27 12:26:46 --> Helper loaded: cookie_helper
DEBUG - 2019-08-27 12:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 12:26:46 --> Helper loaded: date_helper
INFO - 2019-08-27 12:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 12:26:46 --> Form Validation Class Initialized
INFO - 2019-08-27 12:26:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 12:26:47 --> Email Class Initialized
INFO - 2019-08-27 12:26:47 --> Pagination Class Initialized
DEBUG - 2019-08-27 12:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 12:26:47 --> Database Driver Class Initialized
INFO - 2019-08-27 12:26:47 --> Database Driver Class Initialized
INFO - 2019-08-27 12:26:47 --> Controller Class Initialized
INFO - 2019-08-27 12:26:47 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 12:26:47 --> Final output sent to browser
DEBUG - 2019-08-27 12:26:47 --> Total execution time: 1.2697
INFO - 2019-08-27 12:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 12:26:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 12:26:47 --> Pagination Class Initialized
INFO - 2019-08-27 12:26:47 --> Database Driver Class Initialized
INFO - 2019-08-27 12:26:47 --> Database Driver Class Initialized
INFO - 2019-08-27 12:26:47 --> Controller Class Initialized
INFO - 2019-08-27 12:26:47 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 12:26:47 --> Final output sent to browser
DEBUG - 2019-08-27 12:26:47 --> Total execution time: 1.3425
INFO - 2019-08-27 12:26:48 --> Config Class Initialized
INFO - 2019-08-27 12:26:48 --> Hooks Class Initialized
DEBUG - 2019-08-27 12:26:48 --> UTF-8 Support Enabled
INFO - 2019-08-27 12:26:48 --> Utf8 Class Initialized
INFO - 2019-08-27 12:26:48 --> URI Class Initialized
INFO - 2019-08-27 12:26:48 --> Router Class Initialized
INFO - 2019-08-27 12:26:48 --> Output Class Initialized
INFO - 2019-08-27 12:26:49 --> Security Class Initialized
DEBUG - 2019-08-27 12:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 12:26:49 --> Input Class Initialized
INFO - 2019-08-27 12:26:49 --> Language Class Initialized
INFO - 2019-08-27 12:26:49 --> Loader Class Initialized
INFO - 2019-08-27 12:26:49 --> Helper loaded: url_helper
INFO - 2019-08-27 12:26:49 --> Helper loaded: html_helper
INFO - 2019-08-27 12:26:49 --> Helper loaded: form_helper
INFO - 2019-08-27 12:26:49 --> Helper loaded: cookie_helper
INFO - 2019-08-27 12:26:49 --> Helper loaded: date_helper
INFO - 2019-08-27 12:26:49 --> Form Validation Class Initialized
INFO - 2019-08-27 12:26:49 --> Email Class Initialized
DEBUG - 2019-08-27 12:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 12:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 12:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 12:26:49 --> Pagination Class Initialized
INFO - 2019-08-27 12:26:49 --> Database Driver Class Initialized
INFO - 2019-08-27 12:26:49 --> Database Driver Class Initialized
INFO - 2019-08-27 12:26:49 --> Controller Class Initialized
INFO - 2019-08-27 12:26:49 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-27 12:26:49 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/nightaudit.php
INFO - 2019-08-27 12:26:49 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-27 12:26:49 --> Final output sent to browser
DEBUG - 2019-08-27 12:26:49 --> Total execution time: 0.7546
INFO - 2019-08-27 12:26:49 --> Config Class Initialized
INFO - 2019-08-27 12:26:49 --> Hooks Class Initialized
DEBUG - 2019-08-27 12:26:49 --> UTF-8 Support Enabled
INFO - 2019-08-27 12:26:49 --> Utf8 Class Initialized
INFO - 2019-08-27 12:26:50 --> URI Class Initialized
INFO - 2019-08-27 12:26:50 --> Router Class Initialized
INFO - 2019-08-27 12:26:50 --> Output Class Initialized
INFO - 2019-08-27 12:26:50 --> Security Class Initialized
DEBUG - 2019-08-27 12:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 12:26:50 --> Input Class Initialized
INFO - 2019-08-27 12:26:50 --> Language Class Initialized
INFO - 2019-08-27 12:26:50 --> Loader Class Initialized
INFO - 2019-08-27 12:26:50 --> Helper loaded: url_helper
INFO - 2019-08-27 12:26:50 --> Helper loaded: html_helper
INFO - 2019-08-27 12:26:50 --> Helper loaded: form_helper
INFO - 2019-08-27 12:26:50 --> Helper loaded: cookie_helper
INFO - 2019-08-27 12:26:50 --> Helper loaded: date_helper
INFO - 2019-08-27 12:26:50 --> Form Validation Class Initialized
INFO - 2019-08-27 12:26:50 --> Email Class Initialized
DEBUG - 2019-08-27 12:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 12:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 12:26:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 12:26:50 --> Pagination Class Initialized
INFO - 2019-08-27 12:26:50 --> Config Class Initialized
INFO - 2019-08-27 12:26:50 --> Hooks Class Initialized
INFO - 2019-08-27 12:26:50 --> Database Driver Class Initialized
INFO - 2019-08-27 12:26:50 --> Database Driver Class Initialized
DEBUG - 2019-08-27 12:26:50 --> UTF-8 Support Enabled
INFO - 2019-08-27 12:26:50 --> Controller Class Initialized
INFO - 2019-08-27 12:26:50 --> Utf8 Class Initialized
INFO - 2019-08-27 12:26:50 --> URI Class Initialized
INFO - 2019-08-27 12:26:51 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 12:26:51 --> Router Class Initialized
INFO - 2019-08-27 12:26:51 --> Final output sent to browser
INFO - 2019-08-27 12:26:51 --> Output Class Initialized
DEBUG - 2019-08-27 12:26:51 --> Total execution time: 1.2163
INFO - 2019-08-27 12:26:51 --> Security Class Initialized
DEBUG - 2019-08-27 12:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 12:26:51 --> Input Class Initialized
INFO - 2019-08-27 12:26:51 --> Language Class Initialized
INFO - 2019-08-27 12:26:51 --> Loader Class Initialized
INFO - 2019-08-27 12:26:51 --> Helper loaded: url_helper
INFO - 2019-08-27 12:26:51 --> Helper loaded: html_helper
INFO - 2019-08-27 12:26:51 --> Helper loaded: form_helper
INFO - 2019-08-27 12:26:51 --> Helper loaded: cookie_helper
INFO - 2019-08-27 12:26:51 --> Helper loaded: date_helper
INFO - 2019-08-27 12:26:51 --> Form Validation Class Initialized
INFO - 2019-08-27 12:26:51 --> Email Class Initialized
DEBUG - 2019-08-27 12:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 12:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 12:26:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 12:26:51 --> Pagination Class Initialized
INFO - 2019-08-27 12:26:51 --> Database Driver Class Initialized
INFO - 2019-08-27 12:26:51 --> Database Driver Class Initialized
INFO - 2019-08-27 12:26:51 --> Controller Class Initialized
INFO - 2019-08-27 12:26:51 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-27 12:26:51 --> Final output sent to browser
DEBUG - 2019-08-27 12:26:51 --> Total execution time: 1.1352
INFO - 2019-08-27 12:26:56 --> Config Class Initialized
INFO - 2019-08-27 12:26:56 --> Hooks Class Initialized
DEBUG - 2019-08-27 12:26:56 --> UTF-8 Support Enabled
INFO - 2019-08-27 12:26:56 --> Utf8 Class Initialized
INFO - 2019-08-27 12:26:56 --> URI Class Initialized
INFO - 2019-08-27 12:26:56 --> Router Class Initialized
INFO - 2019-08-27 12:26:56 --> Output Class Initialized
INFO - 2019-08-27 12:26:56 --> Security Class Initialized
DEBUG - 2019-08-27 12:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-27 12:26:56 --> Input Class Initialized
INFO - 2019-08-27 12:26:56 --> Language Class Initialized
INFO - 2019-08-27 12:26:56 --> Loader Class Initialized
INFO - 2019-08-27 12:26:56 --> Helper loaded: url_helper
INFO - 2019-08-27 12:26:56 --> Helper loaded: html_helper
INFO - 2019-08-27 12:26:56 --> Helper loaded: form_helper
INFO - 2019-08-27 12:26:56 --> Helper loaded: cookie_helper
INFO - 2019-08-27 12:26:56 --> Helper loaded: date_helper
INFO - 2019-08-27 12:26:56 --> Form Validation Class Initialized
INFO - 2019-08-27 12:26:56 --> Email Class Initialized
DEBUG - 2019-08-27 12:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-27 12:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-27 12:26:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-27 12:26:56 --> Pagination Class Initialized
INFO - 2019-08-27 12:26:56 --> Database Driver Class Initialized
INFO - 2019-08-27 12:26:56 --> Database Driver Class Initialized
INFO - 2019-08-27 12:26:56 --> Controller Class Initialized
INFO - 2019-08-27 12:26:56 --> Final output sent to browser
DEBUG - 2019-08-27 12:26:56 --> Total execution time: 0.7201
