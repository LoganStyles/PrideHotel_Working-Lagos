<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-17 04:52:50 --> Config Class Initialized
INFO - 2019-09-17 04:52:50 --> Hooks Class Initialized
DEBUG - 2019-09-17 04:52:50 --> UTF-8 Support Enabled
INFO - 2019-09-17 04:52:50 --> Utf8 Class Initialized
INFO - 2019-09-17 04:52:51 --> URI Class Initialized
DEBUG - 2019-09-17 04:52:51 --> No URI present. Default controller set.
INFO - 2019-09-17 04:52:51 --> Router Class Initialized
INFO - 2019-09-17 04:52:51 --> Output Class Initialized
INFO - 2019-09-17 04:52:51 --> Security Class Initialized
DEBUG - 2019-09-17 04:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 04:52:51 --> Input Class Initialized
INFO - 2019-09-17 04:52:51 --> Language Class Initialized
INFO - 2019-09-17 04:52:51 --> Loader Class Initialized
INFO - 2019-09-17 04:52:51 --> Helper loaded: url_helper
INFO - 2019-09-17 04:52:51 --> Helper loaded: html_helper
INFO - 2019-09-17 04:52:52 --> Helper loaded: form_helper
INFO - 2019-09-17 04:52:52 --> Helper loaded: cookie_helper
INFO - 2019-09-17 04:52:52 --> Helper loaded: date_helper
INFO - 2019-09-17 04:52:52 --> Form Validation Class Initialized
INFO - 2019-09-17 04:52:52 --> Email Class Initialized
DEBUG - 2019-09-17 04:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 04:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 04:52:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 04:52:53 --> Pagination Class Initialized
INFO - 2019-09-17 04:52:53 --> Database Driver Class Initialized
INFO - 2019-09-17 04:52:53 --> Database Driver Class Initialized
INFO - 2019-09-17 04:52:53 --> Controller Class Initialized
INFO - 2019-09-17 04:52:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-17 04:52:53 --> Final output sent to browser
DEBUG - 2019-09-17 04:52:53 --> Total execution time: 3.2685
INFO - 2019-09-17 04:54:21 --> Config Class Initialized
INFO - 2019-09-17 04:54:21 --> Hooks Class Initialized
DEBUG - 2019-09-17 04:54:21 --> UTF-8 Support Enabled
INFO - 2019-09-17 04:54:21 --> Utf8 Class Initialized
INFO - 2019-09-17 04:54:21 --> URI Class Initialized
INFO - 2019-09-17 04:54:21 --> Router Class Initialized
INFO - 2019-09-17 04:54:21 --> Output Class Initialized
INFO - 2019-09-17 04:54:21 --> Security Class Initialized
DEBUG - 2019-09-17 04:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 04:54:21 --> Input Class Initialized
INFO - 2019-09-17 04:54:21 --> Language Class Initialized
INFO - 2019-09-17 04:54:21 --> Loader Class Initialized
INFO - 2019-09-17 04:54:21 --> Helper loaded: url_helper
INFO - 2019-09-17 04:54:21 --> Helper loaded: html_helper
INFO - 2019-09-17 04:54:21 --> Helper loaded: form_helper
INFO - 2019-09-17 04:54:21 --> Helper loaded: cookie_helper
INFO - 2019-09-17 04:54:21 --> Helper loaded: date_helper
INFO - 2019-09-17 04:54:21 --> Form Validation Class Initialized
INFO - 2019-09-17 04:54:21 --> Email Class Initialized
DEBUG - 2019-09-17 04:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 04:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 04:54:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 04:54:21 --> Pagination Class Initialized
INFO - 2019-09-17 04:54:21 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:21 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:21 --> Controller Class Initialized
INFO - 2019-09-17 04:54:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-17 04:54:21 --> Config Class Initialized
INFO - 2019-09-17 04:54:21 --> Hooks Class Initialized
DEBUG - 2019-09-17 04:54:21 --> UTF-8 Support Enabled
INFO - 2019-09-17 04:54:21 --> Utf8 Class Initialized
INFO - 2019-09-17 04:54:21 --> URI Class Initialized
INFO - 2019-09-17 04:54:21 --> Router Class Initialized
INFO - 2019-09-17 04:54:21 --> Output Class Initialized
INFO - 2019-09-17 04:54:21 --> Security Class Initialized
DEBUG - 2019-09-17 04:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 04:54:21 --> Input Class Initialized
INFO - 2019-09-17 04:54:21 --> Language Class Initialized
INFO - 2019-09-17 04:54:21 --> Loader Class Initialized
INFO - 2019-09-17 04:54:21 --> Helper loaded: url_helper
INFO - 2019-09-17 04:54:21 --> Helper loaded: html_helper
INFO - 2019-09-17 04:54:21 --> Helper loaded: form_helper
INFO - 2019-09-17 04:54:21 --> Helper loaded: cookie_helper
INFO - 2019-09-17 04:54:21 --> Helper loaded: date_helper
INFO - 2019-09-17 04:54:21 --> Form Validation Class Initialized
INFO - 2019-09-17 04:54:21 --> Email Class Initialized
DEBUG - 2019-09-17 04:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 04:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 04:54:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 04:54:21 --> Pagination Class Initialized
INFO - 2019-09-17 04:54:21 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:21 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:21 --> Controller Class Initialized
INFO - 2019-09-17 04:54:21 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-17 04:54:21 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-17 04:54:21 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-17 04:54:21 --> Final output sent to browser
DEBUG - 2019-09-17 04:54:21 --> Total execution time: 0.1679
INFO - 2019-09-17 04:54:22 --> Config Class Initialized
INFO - 2019-09-17 04:54:22 --> Hooks Class Initialized
DEBUG - 2019-09-17 04:54:22 --> UTF-8 Support Enabled
INFO - 2019-09-17 04:54:22 --> Utf8 Class Initialized
INFO - 2019-09-17 04:54:22 --> URI Class Initialized
INFO - 2019-09-17 04:54:22 --> Router Class Initialized
INFO - 2019-09-17 04:54:22 --> Output Class Initialized
INFO - 2019-09-17 04:54:22 --> Security Class Initialized
DEBUG - 2019-09-17 04:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 04:54:22 --> Input Class Initialized
INFO - 2019-09-17 04:54:22 --> Language Class Initialized
INFO - 2019-09-17 04:54:22 --> Loader Class Initialized
INFO - 2019-09-17 04:54:22 --> Helper loaded: url_helper
INFO - 2019-09-17 04:54:22 --> Helper loaded: html_helper
INFO - 2019-09-17 04:54:22 --> Helper loaded: form_helper
INFO - 2019-09-17 04:54:22 --> Helper loaded: cookie_helper
INFO - 2019-09-17 04:54:22 --> Helper loaded: date_helper
INFO - 2019-09-17 04:54:22 --> Form Validation Class Initialized
INFO - 2019-09-17 04:54:22 --> Email Class Initialized
DEBUG - 2019-09-17 04:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 04:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 04:54:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 04:54:22 --> Pagination Class Initialized
INFO - 2019-09-17 04:54:22 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:22 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:22 --> Controller Class Initialized
INFO - 2019-09-17 04:54:22 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 04:54:22 --> Final output sent to browser
DEBUG - 2019-09-17 04:54:22 --> Total execution time: 0.0833
INFO - 2019-09-17 04:54:22 --> Config Class Initialized
INFO - 2019-09-17 04:54:22 --> Hooks Class Initialized
DEBUG - 2019-09-17 04:54:22 --> UTF-8 Support Enabled
INFO - 2019-09-17 04:54:22 --> Utf8 Class Initialized
INFO - 2019-09-17 04:54:22 --> URI Class Initialized
INFO - 2019-09-17 04:54:22 --> Router Class Initialized
INFO - 2019-09-17 04:54:22 --> Output Class Initialized
INFO - 2019-09-17 04:54:22 --> Security Class Initialized
DEBUG - 2019-09-17 04:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 04:54:22 --> Input Class Initialized
INFO - 2019-09-17 04:54:22 --> Language Class Initialized
INFO - 2019-09-17 04:54:22 --> Loader Class Initialized
INFO - 2019-09-17 04:54:22 --> Helper loaded: url_helper
INFO - 2019-09-17 04:54:22 --> Helper loaded: html_helper
INFO - 2019-09-17 04:54:22 --> Helper loaded: form_helper
INFO - 2019-09-17 04:54:22 --> Helper loaded: cookie_helper
INFO - 2019-09-17 04:54:22 --> Helper loaded: date_helper
INFO - 2019-09-17 04:54:22 --> Form Validation Class Initialized
INFO - 2019-09-17 04:54:22 --> Email Class Initialized
DEBUG - 2019-09-17 04:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 04:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 04:54:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 04:54:22 --> Pagination Class Initialized
INFO - 2019-09-17 04:54:22 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:22 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:22 --> Controller Class Initialized
INFO - 2019-09-17 04:54:22 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 04:54:22 --> Final output sent to browser
DEBUG - 2019-09-17 04:54:22 --> Total execution time: 0.0631
INFO - 2019-09-17 04:54:25 --> Config Class Initialized
INFO - 2019-09-17 04:54:25 --> Hooks Class Initialized
DEBUG - 2019-09-17 04:54:25 --> UTF-8 Support Enabled
INFO - 2019-09-17 04:54:25 --> Utf8 Class Initialized
INFO - 2019-09-17 04:54:25 --> URI Class Initialized
INFO - 2019-09-17 04:54:25 --> Router Class Initialized
INFO - 2019-09-17 04:54:25 --> Output Class Initialized
INFO - 2019-09-17 04:54:25 --> Security Class Initialized
DEBUG - 2019-09-17 04:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 04:54:25 --> Input Class Initialized
INFO - 2019-09-17 04:54:25 --> Language Class Initialized
INFO - 2019-09-17 04:54:25 --> Loader Class Initialized
INFO - 2019-09-17 04:54:25 --> Helper loaded: url_helper
INFO - 2019-09-17 04:54:25 --> Helper loaded: html_helper
INFO - 2019-09-17 04:54:25 --> Helper loaded: form_helper
INFO - 2019-09-17 04:54:25 --> Helper loaded: cookie_helper
INFO - 2019-09-17 04:54:25 --> Helper loaded: date_helper
INFO - 2019-09-17 04:54:25 --> Form Validation Class Initialized
INFO - 2019-09-17 04:54:25 --> Email Class Initialized
DEBUG - 2019-09-17 04:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 04:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 04:54:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 04:54:25 --> Pagination Class Initialized
INFO - 2019-09-17 04:54:25 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:25 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:25 --> Controller Class Initialized
INFO - 2019-09-17 04:54:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 04:54:25 --> Final output sent to browser
DEBUG - 2019-09-17 04:54:25 --> Total execution time: 0.0537
INFO - 2019-09-17 04:54:25 --> Config Class Initialized
INFO - 2019-09-17 04:54:25 --> Hooks Class Initialized
DEBUG - 2019-09-17 04:54:25 --> UTF-8 Support Enabled
INFO - 2019-09-17 04:54:25 --> Utf8 Class Initialized
INFO - 2019-09-17 04:54:25 --> URI Class Initialized
INFO - 2019-09-17 04:54:25 --> Router Class Initialized
INFO - 2019-09-17 04:54:25 --> Output Class Initialized
INFO - 2019-09-17 04:54:25 --> Security Class Initialized
DEBUG - 2019-09-17 04:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 04:54:25 --> Input Class Initialized
INFO - 2019-09-17 04:54:25 --> Language Class Initialized
INFO - 2019-09-17 04:54:25 --> Loader Class Initialized
INFO - 2019-09-17 04:54:25 --> Helper loaded: url_helper
INFO - 2019-09-17 04:54:25 --> Helper loaded: html_helper
INFO - 2019-09-17 04:54:25 --> Helper loaded: form_helper
INFO - 2019-09-17 04:54:25 --> Helper loaded: cookie_helper
INFO - 2019-09-17 04:54:25 --> Helper loaded: date_helper
INFO - 2019-09-17 04:54:25 --> Form Validation Class Initialized
INFO - 2019-09-17 04:54:25 --> Email Class Initialized
DEBUG - 2019-09-17 04:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 04:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 04:54:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 04:54:25 --> Pagination Class Initialized
INFO - 2019-09-17 04:54:25 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:25 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:25 --> Controller Class Initialized
INFO - 2019-09-17 04:54:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 04:54:25 --> Final output sent to browser
DEBUG - 2019-09-17 04:54:25 --> Total execution time: 0.0607
INFO - 2019-09-17 04:54:34 --> Config Class Initialized
INFO - 2019-09-17 04:54:34 --> Hooks Class Initialized
DEBUG - 2019-09-17 04:54:34 --> UTF-8 Support Enabled
INFO - 2019-09-17 04:54:34 --> Utf8 Class Initialized
INFO - 2019-09-17 04:54:34 --> URI Class Initialized
INFO - 2019-09-17 04:54:34 --> Router Class Initialized
INFO - 2019-09-17 04:54:34 --> Output Class Initialized
INFO - 2019-09-17 04:54:34 --> Security Class Initialized
DEBUG - 2019-09-17 04:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 04:54:34 --> Input Class Initialized
INFO - 2019-09-17 04:54:34 --> Language Class Initialized
INFO - 2019-09-17 04:54:34 --> Loader Class Initialized
INFO - 2019-09-17 04:54:34 --> Helper loaded: url_helper
INFO - 2019-09-17 04:54:34 --> Helper loaded: html_helper
INFO - 2019-09-17 04:54:34 --> Helper loaded: form_helper
INFO - 2019-09-17 04:54:34 --> Helper loaded: cookie_helper
INFO - 2019-09-17 04:54:34 --> Helper loaded: date_helper
INFO - 2019-09-17 04:54:34 --> Form Validation Class Initialized
INFO - 2019-09-17 04:54:34 --> Email Class Initialized
DEBUG - 2019-09-17 04:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 04:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 04:54:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 04:54:34 --> Pagination Class Initialized
INFO - 2019-09-17 04:54:34 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:34 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:34 --> Controller Class Initialized
INFO - 2019-09-17 04:54:34 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-17 04:54:34 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/room.php
INFO - 2019-09-17 04:54:34 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-17 04:54:34 --> Final output sent to browser
DEBUG - 2019-09-17 04:54:34 --> Total execution time: 0.1067
INFO - 2019-09-17 04:54:34 --> Config Class Initialized
INFO - 2019-09-17 04:54:34 --> Hooks Class Initialized
DEBUG - 2019-09-17 04:54:34 --> UTF-8 Support Enabled
INFO - 2019-09-17 04:54:34 --> Utf8 Class Initialized
INFO - 2019-09-17 04:54:34 --> URI Class Initialized
INFO - 2019-09-17 04:54:34 --> Router Class Initialized
INFO - 2019-09-17 04:54:34 --> Output Class Initialized
INFO - 2019-09-17 04:54:34 --> Security Class Initialized
DEBUG - 2019-09-17 04:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 04:54:34 --> Input Class Initialized
INFO - 2019-09-17 04:54:34 --> Language Class Initialized
INFO - 2019-09-17 04:54:34 --> Loader Class Initialized
INFO - 2019-09-17 04:54:34 --> Helper loaded: url_helper
INFO - 2019-09-17 04:54:34 --> Helper loaded: html_helper
INFO - 2019-09-17 04:54:34 --> Helper loaded: form_helper
INFO - 2019-09-17 04:54:34 --> Helper loaded: cookie_helper
INFO - 2019-09-17 04:54:34 --> Helper loaded: date_helper
INFO - 2019-09-17 04:54:34 --> Form Validation Class Initialized
INFO - 2019-09-17 04:54:34 --> Email Class Initialized
DEBUG - 2019-09-17 04:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 04:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 04:54:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 04:54:34 --> Pagination Class Initialized
INFO - 2019-09-17 04:54:34 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:34 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:34 --> Controller Class Initialized
INFO - 2019-09-17 04:54:34 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 04:54:34 --> Final output sent to browser
DEBUG - 2019-09-17 04:54:34 --> Total execution time: 0.0513
INFO - 2019-09-17 04:54:34 --> Config Class Initialized
INFO - 2019-09-17 04:54:34 --> Hooks Class Initialized
DEBUG - 2019-09-17 04:54:34 --> UTF-8 Support Enabled
INFO - 2019-09-17 04:54:34 --> Utf8 Class Initialized
INFO - 2019-09-17 04:54:34 --> URI Class Initialized
INFO - 2019-09-17 04:54:34 --> Router Class Initialized
INFO - 2019-09-17 04:54:34 --> Output Class Initialized
INFO - 2019-09-17 04:54:34 --> Security Class Initialized
DEBUG - 2019-09-17 04:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 04:54:34 --> Input Class Initialized
INFO - 2019-09-17 04:54:34 --> Language Class Initialized
INFO - 2019-09-17 04:54:34 --> Loader Class Initialized
INFO - 2019-09-17 04:54:34 --> Helper loaded: url_helper
INFO - 2019-09-17 04:54:34 --> Helper loaded: html_helper
INFO - 2019-09-17 04:54:34 --> Helper loaded: form_helper
INFO - 2019-09-17 04:54:34 --> Helper loaded: cookie_helper
INFO - 2019-09-17 04:54:34 --> Helper loaded: date_helper
INFO - 2019-09-17 04:54:34 --> Form Validation Class Initialized
INFO - 2019-09-17 04:54:34 --> Email Class Initialized
DEBUG - 2019-09-17 04:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 04:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 04:54:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 04:54:34 --> Pagination Class Initialized
INFO - 2019-09-17 04:54:34 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:34 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:34 --> Controller Class Initialized
INFO - 2019-09-17 04:54:34 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 04:54:34 --> Final output sent to browser
DEBUG - 2019-09-17 04:54:34 --> Total execution time: 0.0546
INFO - 2019-09-17 04:54:34 --> Config Class Initialized
INFO - 2019-09-17 04:54:34 --> Hooks Class Initialized
DEBUG - 2019-09-17 04:54:34 --> UTF-8 Support Enabled
INFO - 2019-09-17 04:54:34 --> Utf8 Class Initialized
INFO - 2019-09-17 04:54:34 --> URI Class Initialized
INFO - 2019-09-17 04:54:34 --> Router Class Initialized
INFO - 2019-09-17 04:54:34 --> Output Class Initialized
INFO - 2019-09-17 04:54:34 --> Security Class Initialized
DEBUG - 2019-09-17 04:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 04:54:34 --> Input Class Initialized
INFO - 2019-09-17 04:54:34 --> Language Class Initialized
INFO - 2019-09-17 04:54:34 --> Loader Class Initialized
INFO - 2019-09-17 04:54:34 --> Helper loaded: url_helper
INFO - 2019-09-17 04:54:34 --> Helper loaded: html_helper
INFO - 2019-09-17 04:54:34 --> Helper loaded: form_helper
INFO - 2019-09-17 04:54:34 --> Helper loaded: cookie_helper
INFO - 2019-09-17 04:54:34 --> Helper loaded: date_helper
INFO - 2019-09-17 04:54:34 --> Form Validation Class Initialized
INFO - 2019-09-17 04:54:34 --> Email Class Initialized
DEBUG - 2019-09-17 04:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 04:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 04:54:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 04:54:34 --> Pagination Class Initialized
INFO - 2019-09-17 04:54:34 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:34 --> Database Driver Class Initialized
INFO - 2019-09-17 04:54:34 --> Controller Class Initialized
INFO - 2019-09-17 04:54:34 --> Final output sent to browser
DEBUG - 2019-09-17 04:54:34 --> Total execution time: 0.1059
INFO - 2019-09-17 04:55:15 --> Config Class Initialized
INFO - 2019-09-17 04:55:15 --> Hooks Class Initialized
DEBUG - 2019-09-17 04:55:15 --> UTF-8 Support Enabled
INFO - 2019-09-17 04:55:15 --> Utf8 Class Initialized
INFO - 2019-09-17 04:55:15 --> URI Class Initialized
INFO - 2019-09-17 04:55:15 --> Router Class Initialized
INFO - 2019-09-17 04:55:15 --> Output Class Initialized
INFO - 2019-09-17 04:55:15 --> Security Class Initialized
DEBUG - 2019-09-17 04:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 04:55:15 --> Input Class Initialized
INFO - 2019-09-17 04:55:15 --> Language Class Initialized
INFO - 2019-09-17 04:55:15 --> Loader Class Initialized
INFO - 2019-09-17 04:55:15 --> Helper loaded: url_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: html_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: form_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: cookie_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: date_helper
INFO - 2019-09-17 04:55:15 --> Form Validation Class Initialized
INFO - 2019-09-17 04:55:15 --> Email Class Initialized
DEBUG - 2019-09-17 04:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 04:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 04:55:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 04:55:15 --> Pagination Class Initialized
INFO - 2019-09-17 04:55:15 --> Database Driver Class Initialized
INFO - 2019-09-17 04:55:15 --> Database Driver Class Initialized
INFO - 2019-09-17 04:55:15 --> Controller Class Initialized
INFO - 2019-09-17 04:55:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-17 04:55:15 --> Config Class Initialized
INFO - 2019-09-17 04:55:15 --> Hooks Class Initialized
DEBUG - 2019-09-17 04:55:15 --> UTF-8 Support Enabled
INFO - 2019-09-17 04:55:15 --> Utf8 Class Initialized
INFO - 2019-09-17 04:55:15 --> URI Class Initialized
INFO - 2019-09-17 04:55:15 --> Router Class Initialized
INFO - 2019-09-17 04:55:15 --> Output Class Initialized
INFO - 2019-09-17 04:55:15 --> Security Class Initialized
DEBUG - 2019-09-17 04:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 04:55:15 --> Input Class Initialized
INFO - 2019-09-17 04:55:15 --> Language Class Initialized
INFO - 2019-09-17 04:55:15 --> Loader Class Initialized
INFO - 2019-09-17 04:55:15 --> Helper loaded: url_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: html_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: form_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: cookie_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: date_helper
INFO - 2019-09-17 04:55:15 --> Form Validation Class Initialized
INFO - 2019-09-17 04:55:15 --> Email Class Initialized
DEBUG - 2019-09-17 04:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 04:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 04:55:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 04:55:15 --> Pagination Class Initialized
INFO - 2019-09-17 04:55:15 --> Database Driver Class Initialized
INFO - 2019-09-17 04:55:15 --> Database Driver Class Initialized
INFO - 2019-09-17 04:55:15 --> Controller Class Initialized
INFO - 2019-09-17 04:55:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-17 04:55:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/room.php
INFO - 2019-09-17 04:55:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-17 04:55:15 --> Final output sent to browser
DEBUG - 2019-09-17 04:55:15 --> Total execution time: 0.0478
INFO - 2019-09-17 04:55:15 --> Config Class Initialized
INFO - 2019-09-17 04:55:15 --> Hooks Class Initialized
DEBUG - 2019-09-17 04:55:15 --> UTF-8 Support Enabled
INFO - 2019-09-17 04:55:15 --> Utf8 Class Initialized
INFO - 2019-09-17 04:55:15 --> URI Class Initialized
INFO - 2019-09-17 04:55:15 --> Router Class Initialized
INFO - 2019-09-17 04:55:15 --> Output Class Initialized
INFO - 2019-09-17 04:55:15 --> Security Class Initialized
DEBUG - 2019-09-17 04:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 04:55:15 --> Input Class Initialized
INFO - 2019-09-17 04:55:15 --> Language Class Initialized
INFO - 2019-09-17 04:55:15 --> Loader Class Initialized
INFO - 2019-09-17 04:55:15 --> Helper loaded: url_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: html_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: form_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: cookie_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: date_helper
INFO - 2019-09-17 04:55:15 --> Form Validation Class Initialized
INFO - 2019-09-17 04:55:15 --> Email Class Initialized
DEBUG - 2019-09-17 04:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 04:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 04:55:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 04:55:15 --> Pagination Class Initialized
INFO - 2019-09-17 04:55:15 --> Database Driver Class Initialized
INFO - 2019-09-17 04:55:15 --> Database Driver Class Initialized
INFO - 2019-09-17 04:55:15 --> Controller Class Initialized
INFO - 2019-09-17 04:55:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 04:55:15 --> Final output sent to browser
DEBUG - 2019-09-17 04:55:15 --> Total execution time: 0.0528
INFO - 2019-09-17 04:55:15 --> Config Class Initialized
INFO - 2019-09-17 04:55:15 --> Hooks Class Initialized
DEBUG - 2019-09-17 04:55:15 --> UTF-8 Support Enabled
INFO - 2019-09-17 04:55:15 --> Utf8 Class Initialized
INFO - 2019-09-17 04:55:15 --> URI Class Initialized
INFO - 2019-09-17 04:55:15 --> Router Class Initialized
INFO - 2019-09-17 04:55:15 --> Output Class Initialized
INFO - 2019-09-17 04:55:15 --> Security Class Initialized
DEBUG - 2019-09-17 04:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 04:55:15 --> Input Class Initialized
INFO - 2019-09-17 04:55:15 --> Language Class Initialized
INFO - 2019-09-17 04:55:15 --> Loader Class Initialized
INFO - 2019-09-17 04:55:15 --> Helper loaded: url_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: html_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: form_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: cookie_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: date_helper
INFO - 2019-09-17 04:55:15 --> Form Validation Class Initialized
INFO - 2019-09-17 04:55:15 --> Email Class Initialized
DEBUG - 2019-09-17 04:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 04:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 04:55:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 04:55:15 --> Pagination Class Initialized
INFO - 2019-09-17 04:55:15 --> Database Driver Class Initialized
INFO - 2019-09-17 04:55:15 --> Database Driver Class Initialized
INFO - 2019-09-17 04:55:15 --> Controller Class Initialized
INFO - 2019-09-17 04:55:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 04:55:15 --> Final output sent to browser
DEBUG - 2019-09-17 04:55:15 --> Total execution time: 0.0527
INFO - 2019-09-17 04:55:15 --> Config Class Initialized
INFO - 2019-09-17 04:55:15 --> Hooks Class Initialized
DEBUG - 2019-09-17 04:55:15 --> UTF-8 Support Enabled
INFO - 2019-09-17 04:55:15 --> Utf8 Class Initialized
INFO - 2019-09-17 04:55:15 --> URI Class Initialized
INFO - 2019-09-17 04:55:15 --> Router Class Initialized
INFO - 2019-09-17 04:55:15 --> Output Class Initialized
INFO - 2019-09-17 04:55:15 --> Security Class Initialized
DEBUG - 2019-09-17 04:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 04:55:15 --> Input Class Initialized
INFO - 2019-09-17 04:55:15 --> Language Class Initialized
INFO - 2019-09-17 04:55:15 --> Loader Class Initialized
INFO - 2019-09-17 04:55:15 --> Helper loaded: url_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: html_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: form_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: cookie_helper
INFO - 2019-09-17 04:55:15 --> Helper loaded: date_helper
INFO - 2019-09-17 04:55:15 --> Form Validation Class Initialized
INFO - 2019-09-17 04:55:15 --> Email Class Initialized
DEBUG - 2019-09-17 04:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 04:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 04:55:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 04:55:15 --> Pagination Class Initialized
INFO - 2019-09-17 04:55:15 --> Database Driver Class Initialized
INFO - 2019-09-17 04:55:15 --> Database Driver Class Initialized
INFO - 2019-09-17 04:55:15 --> Controller Class Initialized
INFO - 2019-09-17 04:55:15 --> Final output sent to browser
DEBUG - 2019-09-17 04:55:15 --> Total execution time: 0.0677
INFO - 2019-09-17 05:30:08 --> Config Class Initialized
INFO - 2019-09-17 05:30:08 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:30:08 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:30:08 --> Utf8 Class Initialized
INFO - 2019-09-17 05:30:08 --> URI Class Initialized
INFO - 2019-09-17 05:30:08 --> Router Class Initialized
INFO - 2019-09-17 05:30:08 --> Output Class Initialized
INFO - 2019-09-17 05:30:08 --> Security Class Initialized
DEBUG - 2019-09-17 05:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:30:08 --> Input Class Initialized
INFO - 2019-09-17 05:30:08 --> Language Class Initialized
INFO - 2019-09-17 05:30:08 --> Loader Class Initialized
INFO - 2019-09-17 05:30:08 --> Helper loaded: url_helper
INFO - 2019-09-17 05:30:08 --> Helper loaded: html_helper
INFO - 2019-09-17 05:30:08 --> Helper loaded: form_helper
INFO - 2019-09-17 05:30:08 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:30:08 --> Helper loaded: date_helper
INFO - 2019-09-17 05:30:08 --> Form Validation Class Initialized
INFO - 2019-09-17 05:30:08 --> Email Class Initialized
DEBUG - 2019-09-17 05:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:30:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:30:08 --> Pagination Class Initialized
INFO - 2019-09-17 05:30:08 --> Database Driver Class Initialized
INFO - 2019-09-17 05:30:08 --> Database Driver Class Initialized
INFO - 2019-09-17 05:30:08 --> Controller Class Initialized
INFO - 2019-09-17 05:30:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 05:30:08 --> Final output sent to browser
DEBUG - 2019-09-17 05:30:08 --> Total execution time: 0.0978
INFO - 2019-09-17 05:30:16 --> Config Class Initialized
INFO - 2019-09-17 05:30:16 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:30:16 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:30:16 --> Utf8 Class Initialized
INFO - 2019-09-17 05:30:16 --> URI Class Initialized
INFO - 2019-09-17 05:30:16 --> Router Class Initialized
INFO - 2019-09-17 05:30:16 --> Output Class Initialized
INFO - 2019-09-17 05:30:16 --> Security Class Initialized
DEBUG - 2019-09-17 05:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:30:16 --> Input Class Initialized
INFO - 2019-09-17 05:30:16 --> Language Class Initialized
INFO - 2019-09-17 05:30:16 --> Loader Class Initialized
INFO - 2019-09-17 05:30:16 --> Helper loaded: url_helper
INFO - 2019-09-17 05:30:16 --> Helper loaded: html_helper
INFO - 2019-09-17 05:30:16 --> Helper loaded: form_helper
INFO - 2019-09-17 05:30:16 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:30:16 --> Helper loaded: date_helper
INFO - 2019-09-17 05:30:16 --> Form Validation Class Initialized
INFO - 2019-09-17 05:30:16 --> Email Class Initialized
DEBUG - 2019-09-17 05:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:30:16 --> Pagination Class Initialized
INFO - 2019-09-17 05:30:16 --> Database Driver Class Initialized
INFO - 2019-09-17 05:30:16 --> Database Driver Class Initialized
INFO - 2019-09-17 05:30:16 --> Controller Class Initialized
INFO - 2019-09-17 05:30:16 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-17 05:30:16 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/room.php
INFO - 2019-09-17 05:30:16 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-17 05:30:16 --> Final output sent to browser
DEBUG - 2019-09-17 05:30:16 --> Total execution time: 0.0518
INFO - 2019-09-17 05:30:16 --> Config Class Initialized
INFO - 2019-09-17 05:30:16 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:30:16 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:30:16 --> Utf8 Class Initialized
INFO - 2019-09-17 05:30:16 --> URI Class Initialized
INFO - 2019-09-17 05:30:16 --> Router Class Initialized
INFO - 2019-09-17 05:30:16 --> Output Class Initialized
INFO - 2019-09-17 05:30:16 --> Security Class Initialized
DEBUG - 2019-09-17 05:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:30:16 --> Input Class Initialized
INFO - 2019-09-17 05:30:16 --> Language Class Initialized
INFO - 2019-09-17 05:30:16 --> Loader Class Initialized
INFO - 2019-09-17 05:30:16 --> Helper loaded: url_helper
INFO - 2019-09-17 05:30:16 --> Helper loaded: html_helper
INFO - 2019-09-17 05:30:16 --> Helper loaded: form_helper
INFO - 2019-09-17 05:30:16 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:30:16 --> Helper loaded: date_helper
INFO - 2019-09-17 05:30:16 --> Form Validation Class Initialized
INFO - 2019-09-17 05:30:16 --> Email Class Initialized
DEBUG - 2019-09-17 05:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:30:16 --> Pagination Class Initialized
INFO - 2019-09-17 05:30:16 --> Database Driver Class Initialized
INFO - 2019-09-17 05:30:16 --> Database Driver Class Initialized
INFO - 2019-09-17 05:30:16 --> Controller Class Initialized
INFO - 2019-09-17 05:30:16 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 05:30:16 --> Final output sent to browser
DEBUG - 2019-09-17 05:30:16 --> Total execution time: 0.0842
INFO - 2019-09-17 05:30:16 --> Config Class Initialized
INFO - 2019-09-17 05:30:16 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:30:16 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:30:16 --> Utf8 Class Initialized
INFO - 2019-09-17 05:30:16 --> URI Class Initialized
INFO - 2019-09-17 05:30:16 --> Router Class Initialized
INFO - 2019-09-17 05:30:16 --> Output Class Initialized
INFO - 2019-09-17 05:30:16 --> Security Class Initialized
DEBUG - 2019-09-17 05:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:30:16 --> Input Class Initialized
INFO - 2019-09-17 05:30:16 --> Language Class Initialized
INFO - 2019-09-17 05:30:16 --> Loader Class Initialized
INFO - 2019-09-17 05:30:16 --> Helper loaded: url_helper
INFO - 2019-09-17 05:30:16 --> Helper loaded: html_helper
INFO - 2019-09-17 05:30:16 --> Helper loaded: form_helper
INFO - 2019-09-17 05:30:16 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:30:16 --> Helper loaded: date_helper
INFO - 2019-09-17 05:30:16 --> Form Validation Class Initialized
INFO - 2019-09-17 05:30:16 --> Email Class Initialized
DEBUG - 2019-09-17 05:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:30:16 --> Pagination Class Initialized
INFO - 2019-09-17 05:30:16 --> Database Driver Class Initialized
INFO - 2019-09-17 05:30:16 --> Database Driver Class Initialized
INFO - 2019-09-17 05:30:16 --> Controller Class Initialized
INFO - 2019-09-17 05:30:16 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 05:30:16 --> Final output sent to browser
DEBUG - 2019-09-17 05:30:16 --> Total execution time: 0.0816
INFO - 2019-09-17 05:30:16 --> Config Class Initialized
INFO - 2019-09-17 05:30:16 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:30:16 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:30:16 --> Utf8 Class Initialized
INFO - 2019-09-17 05:30:16 --> URI Class Initialized
INFO - 2019-09-17 05:30:16 --> Router Class Initialized
INFO - 2019-09-17 05:30:16 --> Output Class Initialized
INFO - 2019-09-17 05:30:16 --> Security Class Initialized
DEBUG - 2019-09-17 05:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:30:16 --> Input Class Initialized
INFO - 2019-09-17 05:30:16 --> Language Class Initialized
INFO - 2019-09-17 05:30:16 --> Loader Class Initialized
INFO - 2019-09-17 05:30:16 --> Helper loaded: url_helper
INFO - 2019-09-17 05:30:16 --> Helper loaded: html_helper
INFO - 2019-09-17 05:30:16 --> Helper loaded: form_helper
INFO - 2019-09-17 05:30:16 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:30:16 --> Helper loaded: date_helper
INFO - 2019-09-17 05:30:16 --> Form Validation Class Initialized
INFO - 2019-09-17 05:30:16 --> Email Class Initialized
DEBUG - 2019-09-17 05:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:30:16 --> Pagination Class Initialized
INFO - 2019-09-17 05:30:16 --> Database Driver Class Initialized
INFO - 2019-09-17 05:30:16 --> Database Driver Class Initialized
INFO - 2019-09-17 05:30:16 --> Controller Class Initialized
INFO - 2019-09-17 05:30:16 --> Final output sent to browser
DEBUG - 2019-09-17 05:30:16 --> Total execution time: 0.0963
INFO - 2019-09-17 05:30:17 --> Config Class Initialized
INFO - 2019-09-17 05:30:17 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:30:17 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:30:17 --> Utf8 Class Initialized
INFO - 2019-09-17 05:30:17 --> URI Class Initialized
INFO - 2019-09-17 05:30:17 --> Router Class Initialized
INFO - 2019-09-17 05:30:17 --> Output Class Initialized
INFO - 2019-09-17 05:30:17 --> Security Class Initialized
DEBUG - 2019-09-17 05:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:30:17 --> Input Class Initialized
INFO - 2019-09-17 05:30:17 --> Language Class Initialized
INFO - 2019-09-17 05:30:17 --> Loader Class Initialized
INFO - 2019-09-17 05:30:17 --> Helper loaded: url_helper
INFO - 2019-09-17 05:30:17 --> Helper loaded: html_helper
INFO - 2019-09-17 05:30:17 --> Helper loaded: form_helper
INFO - 2019-09-17 05:30:17 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:30:17 --> Helper loaded: date_helper
INFO - 2019-09-17 05:30:17 --> Form Validation Class Initialized
INFO - 2019-09-17 05:30:17 --> Email Class Initialized
DEBUG - 2019-09-17 05:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:30:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:30:17 --> Pagination Class Initialized
INFO - 2019-09-17 05:30:17 --> Database Driver Class Initialized
INFO - 2019-09-17 05:30:17 --> Database Driver Class Initialized
INFO - 2019-09-17 05:30:17 --> Controller Class Initialized
INFO - 2019-09-17 05:30:17 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 05:30:17 --> Final output sent to browser
DEBUG - 2019-09-17 05:30:17 --> Total execution time: 0.0637
INFO - 2019-09-17 05:31:01 --> Config Class Initialized
INFO - 2019-09-17 05:31:01 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:31:01 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:31:01 --> Utf8 Class Initialized
INFO - 2019-09-17 05:31:01 --> URI Class Initialized
INFO - 2019-09-17 05:31:01 --> Router Class Initialized
INFO - 2019-09-17 05:31:01 --> Output Class Initialized
INFO - 2019-09-17 05:31:01 --> Security Class Initialized
DEBUG - 2019-09-17 05:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:31:01 --> Input Class Initialized
INFO - 2019-09-17 05:31:01 --> Language Class Initialized
INFO - 2019-09-17 05:31:01 --> Loader Class Initialized
INFO - 2019-09-17 05:31:01 --> Helper loaded: url_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: html_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: form_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: date_helper
INFO - 2019-09-17 05:31:01 --> Form Validation Class Initialized
INFO - 2019-09-17 05:31:01 --> Email Class Initialized
DEBUG - 2019-09-17 05:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:31:01 --> Pagination Class Initialized
INFO - 2019-09-17 05:31:01 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:01 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:01 --> Controller Class Initialized
INFO - 2019-09-17 05:31:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-17 05:31:01 --> Config Class Initialized
INFO - 2019-09-17 05:31:01 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:31:01 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:31:01 --> Utf8 Class Initialized
INFO - 2019-09-17 05:31:01 --> URI Class Initialized
INFO - 2019-09-17 05:31:01 --> Router Class Initialized
INFO - 2019-09-17 05:31:01 --> Output Class Initialized
INFO - 2019-09-17 05:31:01 --> Security Class Initialized
DEBUG - 2019-09-17 05:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:31:01 --> Input Class Initialized
INFO - 2019-09-17 05:31:01 --> Language Class Initialized
INFO - 2019-09-17 05:31:01 --> Loader Class Initialized
INFO - 2019-09-17 05:31:01 --> Helper loaded: url_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: html_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: form_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: date_helper
INFO - 2019-09-17 05:31:01 --> Form Validation Class Initialized
INFO - 2019-09-17 05:31:01 --> Email Class Initialized
DEBUG - 2019-09-17 05:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:31:01 --> Pagination Class Initialized
INFO - 2019-09-17 05:31:01 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:01 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:01 --> Controller Class Initialized
INFO - 2019-09-17 05:31:01 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-17 05:31:01 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/room.php
INFO - 2019-09-17 05:31:01 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-17 05:31:01 --> Final output sent to browser
DEBUG - 2019-09-17 05:31:01 --> Total execution time: 0.1053
INFO - 2019-09-17 05:31:01 --> Config Class Initialized
INFO - 2019-09-17 05:31:01 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:31:01 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:31:01 --> Utf8 Class Initialized
INFO - 2019-09-17 05:31:01 --> URI Class Initialized
INFO - 2019-09-17 05:31:01 --> Router Class Initialized
INFO - 2019-09-17 05:31:01 --> Output Class Initialized
INFO - 2019-09-17 05:31:01 --> Security Class Initialized
DEBUG - 2019-09-17 05:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:31:01 --> Input Class Initialized
INFO - 2019-09-17 05:31:01 --> Language Class Initialized
INFO - 2019-09-17 05:31:01 --> Loader Class Initialized
INFO - 2019-09-17 05:31:01 --> Helper loaded: url_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: html_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: form_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: date_helper
INFO - 2019-09-17 05:31:01 --> Form Validation Class Initialized
INFO - 2019-09-17 05:31:01 --> Email Class Initialized
DEBUG - 2019-09-17 05:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:31:01 --> Pagination Class Initialized
INFO - 2019-09-17 05:31:01 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:01 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:01 --> Controller Class Initialized
INFO - 2019-09-17 05:31:01 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 05:31:01 --> Final output sent to browser
DEBUG - 2019-09-17 05:31:01 --> Total execution time: 0.0757
INFO - 2019-09-17 05:31:01 --> Config Class Initialized
INFO - 2019-09-17 05:31:01 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:31:01 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:31:01 --> Utf8 Class Initialized
INFO - 2019-09-17 05:31:01 --> URI Class Initialized
INFO - 2019-09-17 05:31:01 --> Router Class Initialized
INFO - 2019-09-17 05:31:01 --> Output Class Initialized
INFO - 2019-09-17 05:31:01 --> Security Class Initialized
DEBUG - 2019-09-17 05:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:31:01 --> Input Class Initialized
INFO - 2019-09-17 05:31:01 --> Language Class Initialized
INFO - 2019-09-17 05:31:01 --> Loader Class Initialized
INFO - 2019-09-17 05:31:01 --> Helper loaded: url_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: html_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: form_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: date_helper
INFO - 2019-09-17 05:31:01 --> Form Validation Class Initialized
INFO - 2019-09-17 05:31:01 --> Email Class Initialized
DEBUG - 2019-09-17 05:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:31:01 --> Pagination Class Initialized
INFO - 2019-09-17 05:31:01 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:01 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:01 --> Controller Class Initialized
INFO - 2019-09-17 05:31:01 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 05:31:01 --> Final output sent to browser
DEBUG - 2019-09-17 05:31:01 --> Total execution time: 0.0672
INFO - 2019-09-17 05:31:01 --> Config Class Initialized
INFO - 2019-09-17 05:31:01 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:31:01 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:31:01 --> Utf8 Class Initialized
INFO - 2019-09-17 05:31:01 --> URI Class Initialized
INFO - 2019-09-17 05:31:01 --> Router Class Initialized
INFO - 2019-09-17 05:31:01 --> Output Class Initialized
INFO - 2019-09-17 05:31:01 --> Security Class Initialized
DEBUG - 2019-09-17 05:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:31:01 --> Input Class Initialized
INFO - 2019-09-17 05:31:01 --> Language Class Initialized
INFO - 2019-09-17 05:31:01 --> Loader Class Initialized
INFO - 2019-09-17 05:31:01 --> Helper loaded: url_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: html_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: form_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:31:01 --> Helper loaded: date_helper
INFO - 2019-09-17 05:31:01 --> Form Validation Class Initialized
INFO - 2019-09-17 05:31:01 --> Email Class Initialized
DEBUG - 2019-09-17 05:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:31:01 --> Pagination Class Initialized
INFO - 2019-09-17 05:31:01 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:01 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:01 --> Controller Class Initialized
INFO - 2019-09-17 05:31:01 --> Final output sent to browser
DEBUG - 2019-09-17 05:31:01 --> Total execution time: 0.0648
INFO - 2019-09-17 05:31:51 --> Config Class Initialized
INFO - 2019-09-17 05:31:51 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:31:51 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:31:51 --> Utf8 Class Initialized
INFO - 2019-09-17 05:31:51 --> URI Class Initialized
INFO - 2019-09-17 05:31:51 --> Router Class Initialized
INFO - 2019-09-17 05:31:51 --> Output Class Initialized
INFO - 2019-09-17 05:31:51 --> Security Class Initialized
DEBUG - 2019-09-17 05:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:31:51 --> Input Class Initialized
INFO - 2019-09-17 05:31:51 --> Language Class Initialized
INFO - 2019-09-17 05:31:51 --> Loader Class Initialized
INFO - 2019-09-17 05:31:51 --> Helper loaded: url_helper
INFO - 2019-09-17 05:31:51 --> Helper loaded: html_helper
INFO - 2019-09-17 05:31:51 --> Helper loaded: form_helper
INFO - 2019-09-17 05:31:51 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:31:51 --> Helper loaded: date_helper
INFO - 2019-09-17 05:31:51 --> Form Validation Class Initialized
INFO - 2019-09-17 05:31:51 --> Email Class Initialized
DEBUG - 2019-09-17 05:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:31:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:31:51 --> Pagination Class Initialized
INFO - 2019-09-17 05:31:51 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:51 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:51 --> Controller Class Initialized
INFO - 2019-09-17 05:31:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-17 05:31:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/room.php
INFO - 2019-09-17 05:31:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-17 05:31:51 --> Final output sent to browser
DEBUG - 2019-09-17 05:31:51 --> Total execution time: 0.0745
INFO - 2019-09-17 05:31:51 --> Config Class Initialized
INFO - 2019-09-17 05:31:51 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:31:51 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:31:51 --> Utf8 Class Initialized
INFO - 2019-09-17 05:31:51 --> URI Class Initialized
INFO - 2019-09-17 05:31:51 --> Router Class Initialized
INFO - 2019-09-17 05:31:51 --> Output Class Initialized
INFO - 2019-09-17 05:31:51 --> Security Class Initialized
DEBUG - 2019-09-17 05:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:31:51 --> Input Class Initialized
INFO - 2019-09-17 05:31:51 --> Language Class Initialized
INFO - 2019-09-17 05:31:51 --> Loader Class Initialized
INFO - 2019-09-17 05:31:51 --> Helper loaded: url_helper
INFO - 2019-09-17 05:31:51 --> Helper loaded: html_helper
INFO - 2019-09-17 05:31:51 --> Helper loaded: form_helper
INFO - 2019-09-17 05:31:51 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:31:51 --> Helper loaded: date_helper
INFO - 2019-09-17 05:31:51 --> Form Validation Class Initialized
INFO - 2019-09-17 05:31:51 --> Email Class Initialized
DEBUG - 2019-09-17 05:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:31:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:31:51 --> Pagination Class Initialized
INFO - 2019-09-17 05:31:51 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:51 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:51 --> Controller Class Initialized
INFO - 2019-09-17 05:31:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 05:31:51 --> Final output sent to browser
DEBUG - 2019-09-17 05:31:51 --> Total execution time: 0.0590
INFO - 2019-09-17 05:31:51 --> Config Class Initialized
INFO - 2019-09-17 05:31:51 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:31:51 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:31:51 --> Utf8 Class Initialized
INFO - 2019-09-17 05:31:51 --> URI Class Initialized
INFO - 2019-09-17 05:31:51 --> Router Class Initialized
INFO - 2019-09-17 05:31:51 --> Output Class Initialized
INFO - 2019-09-17 05:31:51 --> Security Class Initialized
DEBUG - 2019-09-17 05:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:31:51 --> Input Class Initialized
INFO - 2019-09-17 05:31:51 --> Language Class Initialized
INFO - 2019-09-17 05:31:51 --> Loader Class Initialized
INFO - 2019-09-17 05:31:51 --> Helper loaded: url_helper
INFO - 2019-09-17 05:31:51 --> Helper loaded: html_helper
INFO - 2019-09-17 05:31:51 --> Helper loaded: form_helper
INFO - 2019-09-17 05:31:51 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:31:51 --> Helper loaded: date_helper
INFO - 2019-09-17 05:31:51 --> Form Validation Class Initialized
INFO - 2019-09-17 05:31:51 --> Email Class Initialized
DEBUG - 2019-09-17 05:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:31:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:31:51 --> Pagination Class Initialized
INFO - 2019-09-17 05:31:51 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:51 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:51 --> Controller Class Initialized
INFO - 2019-09-17 05:31:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 05:31:51 --> Final output sent to browser
DEBUG - 2019-09-17 05:31:51 --> Total execution time: 0.0618
INFO - 2019-09-17 05:31:51 --> Config Class Initialized
INFO - 2019-09-17 05:31:51 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:31:51 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:31:51 --> Utf8 Class Initialized
INFO - 2019-09-17 05:31:51 --> URI Class Initialized
INFO - 2019-09-17 05:31:51 --> Router Class Initialized
INFO - 2019-09-17 05:31:51 --> Output Class Initialized
INFO - 2019-09-17 05:31:51 --> Security Class Initialized
DEBUG - 2019-09-17 05:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:31:51 --> Input Class Initialized
INFO - 2019-09-17 05:31:51 --> Language Class Initialized
INFO - 2019-09-17 05:31:51 --> Loader Class Initialized
INFO - 2019-09-17 05:31:51 --> Helper loaded: url_helper
INFO - 2019-09-17 05:31:51 --> Helper loaded: html_helper
INFO - 2019-09-17 05:31:51 --> Helper loaded: form_helper
INFO - 2019-09-17 05:31:51 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:31:51 --> Helper loaded: date_helper
INFO - 2019-09-17 05:31:51 --> Form Validation Class Initialized
INFO - 2019-09-17 05:31:51 --> Email Class Initialized
DEBUG - 2019-09-17 05:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:31:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:31:51 --> Pagination Class Initialized
INFO - 2019-09-17 05:31:51 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:51 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:51 --> Controller Class Initialized
INFO - 2019-09-17 05:31:51 --> Final output sent to browser
DEBUG - 2019-09-17 05:31:51 --> Total execution time: 0.0636
INFO - 2019-09-17 05:31:55 --> Config Class Initialized
INFO - 2019-09-17 05:31:55 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:31:55 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:31:55 --> Utf8 Class Initialized
INFO - 2019-09-17 05:31:55 --> URI Class Initialized
INFO - 2019-09-17 05:31:55 --> Router Class Initialized
INFO - 2019-09-17 05:31:55 --> Output Class Initialized
INFO - 2019-09-17 05:31:55 --> Security Class Initialized
DEBUG - 2019-09-17 05:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:31:55 --> Input Class Initialized
INFO - 2019-09-17 05:31:55 --> Language Class Initialized
INFO - 2019-09-17 05:31:55 --> Loader Class Initialized
INFO - 2019-09-17 05:31:55 --> Helper loaded: url_helper
INFO - 2019-09-17 05:31:55 --> Helper loaded: html_helper
INFO - 2019-09-17 05:31:55 --> Helper loaded: form_helper
INFO - 2019-09-17 05:31:55 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:31:55 --> Helper loaded: date_helper
INFO - 2019-09-17 05:31:55 --> Form Validation Class Initialized
INFO - 2019-09-17 05:31:55 --> Email Class Initialized
DEBUG - 2019-09-17 05:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:31:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:31:55 --> Pagination Class Initialized
INFO - 2019-09-17 05:31:55 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:55 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:55 --> Controller Class Initialized
INFO - 2019-09-17 05:31:55 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-17 05:31:55 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/room.php
INFO - 2019-09-17 05:31:55 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-17 05:31:55 --> Final output sent to browser
DEBUG - 2019-09-17 05:31:55 --> Total execution time: 0.0585
INFO - 2019-09-17 05:31:55 --> Config Class Initialized
INFO - 2019-09-17 05:31:55 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:31:55 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:31:55 --> Utf8 Class Initialized
INFO - 2019-09-17 05:31:55 --> URI Class Initialized
INFO - 2019-09-17 05:31:55 --> Router Class Initialized
INFO - 2019-09-17 05:31:55 --> Output Class Initialized
INFO - 2019-09-17 05:31:55 --> Security Class Initialized
DEBUG - 2019-09-17 05:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:31:55 --> Input Class Initialized
INFO - 2019-09-17 05:31:55 --> Language Class Initialized
INFO - 2019-09-17 05:31:55 --> Loader Class Initialized
INFO - 2019-09-17 05:31:55 --> Helper loaded: url_helper
INFO - 2019-09-17 05:31:55 --> Helper loaded: html_helper
INFO - 2019-09-17 05:31:55 --> Helper loaded: form_helper
INFO - 2019-09-17 05:31:55 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:31:55 --> Helper loaded: date_helper
INFO - 2019-09-17 05:31:55 --> Form Validation Class Initialized
INFO - 2019-09-17 05:31:55 --> Email Class Initialized
DEBUG - 2019-09-17 05:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:31:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:31:55 --> Pagination Class Initialized
INFO - 2019-09-17 05:31:55 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:55 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:55 --> Controller Class Initialized
INFO - 2019-09-17 05:31:55 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 05:31:55 --> Final output sent to browser
DEBUG - 2019-09-17 05:31:55 --> Total execution time: 0.0524
INFO - 2019-09-17 05:31:55 --> Config Class Initialized
INFO - 2019-09-17 05:31:55 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:31:55 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:31:55 --> Utf8 Class Initialized
INFO - 2019-09-17 05:31:55 --> URI Class Initialized
INFO - 2019-09-17 05:31:55 --> Router Class Initialized
INFO - 2019-09-17 05:31:55 --> Output Class Initialized
INFO - 2019-09-17 05:31:55 --> Security Class Initialized
DEBUG - 2019-09-17 05:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:31:55 --> Input Class Initialized
INFO - 2019-09-17 05:31:55 --> Language Class Initialized
INFO - 2019-09-17 05:31:55 --> Loader Class Initialized
INFO - 2019-09-17 05:31:55 --> Helper loaded: url_helper
INFO - 2019-09-17 05:31:55 --> Helper loaded: html_helper
INFO - 2019-09-17 05:31:55 --> Helper loaded: form_helper
INFO - 2019-09-17 05:31:55 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:31:55 --> Helper loaded: date_helper
INFO - 2019-09-17 05:31:55 --> Form Validation Class Initialized
INFO - 2019-09-17 05:31:55 --> Email Class Initialized
DEBUG - 2019-09-17 05:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:31:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:31:55 --> Pagination Class Initialized
INFO - 2019-09-17 05:31:55 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:55 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:55 --> Controller Class Initialized
INFO - 2019-09-17 05:31:55 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 05:31:55 --> Final output sent to browser
DEBUG - 2019-09-17 05:31:55 --> Total execution time: 0.0569
INFO - 2019-09-17 05:31:55 --> Config Class Initialized
INFO - 2019-09-17 05:31:55 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:31:55 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:31:55 --> Utf8 Class Initialized
INFO - 2019-09-17 05:31:55 --> URI Class Initialized
INFO - 2019-09-17 05:31:55 --> Router Class Initialized
INFO - 2019-09-17 05:31:55 --> Output Class Initialized
INFO - 2019-09-17 05:31:55 --> Security Class Initialized
DEBUG - 2019-09-17 05:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:31:55 --> Input Class Initialized
INFO - 2019-09-17 05:31:55 --> Language Class Initialized
INFO - 2019-09-17 05:31:55 --> Loader Class Initialized
INFO - 2019-09-17 05:31:55 --> Helper loaded: url_helper
INFO - 2019-09-17 05:31:55 --> Helper loaded: html_helper
INFO - 2019-09-17 05:31:55 --> Helper loaded: form_helper
INFO - 2019-09-17 05:31:55 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:31:55 --> Helper loaded: date_helper
INFO - 2019-09-17 05:31:55 --> Form Validation Class Initialized
INFO - 2019-09-17 05:31:55 --> Email Class Initialized
DEBUG - 2019-09-17 05:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:31:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:31:55 --> Pagination Class Initialized
INFO - 2019-09-17 05:31:55 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:55 --> Database Driver Class Initialized
INFO - 2019-09-17 05:31:55 --> Controller Class Initialized
INFO - 2019-09-17 05:31:55 --> Final output sent to browser
DEBUG - 2019-09-17 05:31:55 --> Total execution time: 0.0619
INFO - 2019-09-17 05:32:20 --> Config Class Initialized
INFO - 2019-09-17 05:32:20 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:32:20 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:32:20 --> Utf8 Class Initialized
INFO - 2019-09-17 05:32:20 --> URI Class Initialized
INFO - 2019-09-17 05:32:20 --> Router Class Initialized
INFO - 2019-09-17 05:32:20 --> Output Class Initialized
INFO - 2019-09-17 05:32:20 --> Security Class Initialized
DEBUG - 2019-09-17 05:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:32:20 --> Input Class Initialized
INFO - 2019-09-17 05:32:20 --> Language Class Initialized
INFO - 2019-09-17 05:32:20 --> Loader Class Initialized
INFO - 2019-09-17 05:32:20 --> Helper loaded: url_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: html_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: form_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: date_helper
INFO - 2019-09-17 05:32:20 --> Form Validation Class Initialized
INFO - 2019-09-17 05:32:20 --> Email Class Initialized
DEBUG - 2019-09-17 05:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:32:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:32:20 --> Pagination Class Initialized
INFO - 2019-09-17 05:32:20 --> Database Driver Class Initialized
INFO - 2019-09-17 05:32:20 --> Database Driver Class Initialized
INFO - 2019-09-17 05:32:20 --> Controller Class Initialized
INFO - 2019-09-17 05:32:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-17 05:32:20 --> Config Class Initialized
INFO - 2019-09-17 05:32:20 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:32:20 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:32:20 --> Utf8 Class Initialized
INFO - 2019-09-17 05:32:20 --> URI Class Initialized
INFO - 2019-09-17 05:32:20 --> Router Class Initialized
INFO - 2019-09-17 05:32:20 --> Output Class Initialized
INFO - 2019-09-17 05:32:20 --> Security Class Initialized
DEBUG - 2019-09-17 05:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:32:20 --> Input Class Initialized
INFO - 2019-09-17 05:32:20 --> Language Class Initialized
INFO - 2019-09-17 05:32:20 --> Loader Class Initialized
INFO - 2019-09-17 05:32:20 --> Helper loaded: url_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: html_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: form_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: date_helper
INFO - 2019-09-17 05:32:20 --> Form Validation Class Initialized
INFO - 2019-09-17 05:32:20 --> Email Class Initialized
DEBUG - 2019-09-17 05:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:32:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:32:20 --> Pagination Class Initialized
INFO - 2019-09-17 05:32:20 --> Database Driver Class Initialized
INFO - 2019-09-17 05:32:20 --> Database Driver Class Initialized
INFO - 2019-09-17 05:32:20 --> Controller Class Initialized
INFO - 2019-09-17 05:32:20 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-17 05:32:20 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/room.php
INFO - 2019-09-17 05:32:20 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-17 05:32:20 --> Final output sent to browser
DEBUG - 2019-09-17 05:32:20 --> Total execution time: 0.0610
INFO - 2019-09-17 05:32:20 --> Config Class Initialized
INFO - 2019-09-17 05:32:20 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:32:20 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:32:20 --> Utf8 Class Initialized
INFO - 2019-09-17 05:32:20 --> URI Class Initialized
INFO - 2019-09-17 05:32:20 --> Router Class Initialized
INFO - 2019-09-17 05:32:20 --> Output Class Initialized
INFO - 2019-09-17 05:32:20 --> Security Class Initialized
DEBUG - 2019-09-17 05:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:32:20 --> Input Class Initialized
INFO - 2019-09-17 05:32:20 --> Language Class Initialized
INFO - 2019-09-17 05:32:20 --> Loader Class Initialized
INFO - 2019-09-17 05:32:20 --> Helper loaded: url_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: html_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: form_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: date_helper
INFO - 2019-09-17 05:32:20 --> Form Validation Class Initialized
INFO - 2019-09-17 05:32:20 --> Email Class Initialized
DEBUG - 2019-09-17 05:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:32:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:32:20 --> Pagination Class Initialized
INFO - 2019-09-17 05:32:20 --> Database Driver Class Initialized
INFO - 2019-09-17 05:32:20 --> Database Driver Class Initialized
INFO - 2019-09-17 05:32:20 --> Controller Class Initialized
INFO - 2019-09-17 05:32:20 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 05:32:20 --> Final output sent to browser
DEBUG - 2019-09-17 05:32:20 --> Total execution time: 0.0567
INFO - 2019-09-17 05:32:20 --> Config Class Initialized
INFO - 2019-09-17 05:32:20 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:32:20 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:32:20 --> Utf8 Class Initialized
INFO - 2019-09-17 05:32:20 --> URI Class Initialized
INFO - 2019-09-17 05:32:20 --> Router Class Initialized
INFO - 2019-09-17 05:32:20 --> Output Class Initialized
INFO - 2019-09-17 05:32:20 --> Security Class Initialized
DEBUG - 2019-09-17 05:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:32:20 --> Input Class Initialized
INFO - 2019-09-17 05:32:20 --> Language Class Initialized
INFO - 2019-09-17 05:32:20 --> Loader Class Initialized
INFO - 2019-09-17 05:32:20 --> Helper loaded: url_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: html_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: form_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: date_helper
INFO - 2019-09-17 05:32:20 --> Form Validation Class Initialized
INFO - 2019-09-17 05:32:20 --> Email Class Initialized
DEBUG - 2019-09-17 05:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:32:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:32:20 --> Pagination Class Initialized
INFO - 2019-09-17 05:32:20 --> Database Driver Class Initialized
INFO - 2019-09-17 05:32:20 --> Database Driver Class Initialized
INFO - 2019-09-17 05:32:20 --> Controller Class Initialized
INFO - 2019-09-17 05:32:20 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-17 05:32:20 --> Final output sent to browser
DEBUG - 2019-09-17 05:32:20 --> Total execution time: 0.0555
INFO - 2019-09-17 05:32:20 --> Config Class Initialized
INFO - 2019-09-17 05:32:20 --> Hooks Class Initialized
DEBUG - 2019-09-17 05:32:20 --> UTF-8 Support Enabled
INFO - 2019-09-17 05:32:20 --> Utf8 Class Initialized
INFO - 2019-09-17 05:32:20 --> URI Class Initialized
INFO - 2019-09-17 05:32:20 --> Router Class Initialized
INFO - 2019-09-17 05:32:20 --> Output Class Initialized
INFO - 2019-09-17 05:32:20 --> Security Class Initialized
DEBUG - 2019-09-17 05:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-17 05:32:20 --> Input Class Initialized
INFO - 2019-09-17 05:32:20 --> Language Class Initialized
INFO - 2019-09-17 05:32:20 --> Loader Class Initialized
INFO - 2019-09-17 05:32:20 --> Helper loaded: url_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: html_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: form_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: cookie_helper
INFO - 2019-09-17 05:32:20 --> Helper loaded: date_helper
INFO - 2019-09-17 05:32:20 --> Form Validation Class Initialized
INFO - 2019-09-17 05:32:20 --> Email Class Initialized
DEBUG - 2019-09-17 05:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-17 05:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-17 05:32:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-17 05:32:20 --> Pagination Class Initialized
INFO - 2019-09-17 05:32:20 --> Database Driver Class Initialized
INFO - 2019-09-17 05:32:20 --> Database Driver Class Initialized
INFO - 2019-09-17 05:32:20 --> Controller Class Initialized
INFO - 2019-09-17 05:32:20 --> Final output sent to browser
DEBUG - 2019-09-17 05:32:20 --> Total execution time: 0.0636
