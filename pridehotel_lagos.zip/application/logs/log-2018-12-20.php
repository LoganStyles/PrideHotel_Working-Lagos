<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-12-20 12:07:26 --> Config Class Initialized
INFO - 2018-12-20 12:07:26 --> Hooks Class Initialized
DEBUG - 2018-12-20 12:07:26 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:07:26 --> Utf8 Class Initialized
INFO - 2018-12-20 12:07:26 --> URI Class Initialized
DEBUG - 2018-12-20 12:07:26 --> No URI present. Default controller set.
INFO - 2018-12-20 12:07:26 --> Router Class Initialized
INFO - 2018-12-20 12:07:26 --> Output Class Initialized
INFO - 2018-12-20 12:07:26 --> Security Class Initialized
DEBUG - 2018-12-20 12:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:07:26 --> Input Class Initialized
INFO - 2018-12-20 12:07:26 --> Language Class Initialized
INFO - 2018-12-20 12:07:26 --> Loader Class Initialized
INFO - 2018-12-20 12:07:26 --> Helper loaded: url_helper
INFO - 2018-12-20 12:07:26 --> Helper loaded: html_helper
INFO - 2018-12-20 12:07:26 --> Helper loaded: form_helper
INFO - 2018-12-20 12:07:26 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:07:26 --> Helper loaded: date_helper
INFO - 2018-12-20 12:07:26 --> Form Validation Class Initialized
INFO - 2018-12-20 12:07:26 --> Email Class Initialized
DEBUG - 2018-12-20 12:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:07:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:07:26 --> Pagination Class Initialized
INFO - 2018-12-20 12:07:26 --> Database Driver Class Initialized
INFO - 2018-12-20 12:07:26 --> Database Driver Class Initialized
INFO - 2018-12-20 12:07:27 --> Controller Class Initialized
INFO - 2018-12-20 12:07:27 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-12-20 12:07:27 --> Final output sent to browser
DEBUG - 2018-12-20 12:07:27 --> Total execution time: 0.5413
INFO - 2018-12-20 12:07:28 --> Config Class Initialized
INFO - 2018-12-20 12:07:28 --> Hooks Class Initialized
DEBUG - 2018-12-20 12:07:28 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:07:28 --> Utf8 Class Initialized
INFO - 2018-12-20 12:07:28 --> URI Class Initialized
DEBUG - 2018-12-20 12:07:28 --> No URI present. Default controller set.
INFO - 2018-12-20 12:07:28 --> Router Class Initialized
INFO - 2018-12-20 12:07:28 --> Output Class Initialized
INFO - 2018-12-20 12:07:28 --> Security Class Initialized
DEBUG - 2018-12-20 12:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:07:28 --> Input Class Initialized
INFO - 2018-12-20 12:07:28 --> Language Class Initialized
INFO - 2018-12-20 12:07:28 --> Loader Class Initialized
INFO - 2018-12-20 12:07:28 --> Helper loaded: url_helper
INFO - 2018-12-20 12:07:28 --> Helper loaded: html_helper
INFO - 2018-12-20 12:07:28 --> Helper loaded: form_helper
INFO - 2018-12-20 12:07:28 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:07:28 --> Helper loaded: date_helper
INFO - 2018-12-20 12:07:28 --> Form Validation Class Initialized
INFO - 2018-12-20 12:07:28 --> Email Class Initialized
DEBUG - 2018-12-20 12:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:07:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:07:28 --> Pagination Class Initialized
INFO - 2018-12-20 12:07:28 --> Database Driver Class Initialized
INFO - 2018-12-20 12:07:28 --> Database Driver Class Initialized
INFO - 2018-12-20 12:07:28 --> Controller Class Initialized
INFO - 2018-12-20 12:07:28 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-12-20 12:07:28 --> Final output sent to browser
DEBUG - 2018-12-20 12:07:28 --> Total execution time: 0.0809
INFO - 2018-12-20 12:07:40 --> Config Class Initialized
INFO - 2018-12-20 12:07:40 --> Hooks Class Initialized
DEBUG - 2018-12-20 12:07:40 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:07:40 --> Utf8 Class Initialized
INFO - 2018-12-20 12:07:40 --> URI Class Initialized
INFO - 2018-12-20 12:07:40 --> Router Class Initialized
INFO - 2018-12-20 12:07:40 --> Output Class Initialized
INFO - 2018-12-20 12:07:40 --> Security Class Initialized
DEBUG - 2018-12-20 12:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:07:40 --> Input Class Initialized
INFO - 2018-12-20 12:07:40 --> Language Class Initialized
INFO - 2018-12-20 12:07:40 --> Loader Class Initialized
INFO - 2018-12-20 12:07:40 --> Helper loaded: url_helper
INFO - 2018-12-20 12:07:40 --> Helper loaded: html_helper
INFO - 2018-12-20 12:07:40 --> Helper loaded: form_helper
INFO - 2018-12-20 12:07:40 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:07:40 --> Helper loaded: date_helper
INFO - 2018-12-20 12:07:40 --> Form Validation Class Initialized
INFO - 2018-12-20 12:07:40 --> Email Class Initialized
DEBUG - 2018-12-20 12:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:07:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:07:40 --> Pagination Class Initialized
INFO - 2018-12-20 12:07:40 --> Database Driver Class Initialized
INFO - 2018-12-20 12:07:40 --> Database Driver Class Initialized
INFO - 2018-12-20 12:07:40 --> Controller Class Initialized
INFO - 2018-12-20 12:07:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-20 12:07:40 --> Config Class Initialized
INFO - 2018-12-20 12:07:40 --> Hooks Class Initialized
DEBUG - 2018-12-20 12:07:40 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:07:40 --> Utf8 Class Initialized
INFO - 2018-12-20 12:07:40 --> URI Class Initialized
INFO - 2018-12-20 12:07:40 --> Router Class Initialized
INFO - 2018-12-20 12:07:40 --> Output Class Initialized
INFO - 2018-12-20 12:07:40 --> Security Class Initialized
DEBUG - 2018-12-20 12:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:07:40 --> Input Class Initialized
INFO - 2018-12-20 12:07:40 --> Language Class Initialized
INFO - 2018-12-20 12:07:40 --> Loader Class Initialized
INFO - 2018-12-20 12:07:40 --> Helper loaded: url_helper
INFO - 2018-12-20 12:07:40 --> Helper loaded: html_helper
INFO - 2018-12-20 12:07:40 --> Helper loaded: form_helper
INFO - 2018-12-20 12:07:40 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:07:40 --> Helper loaded: date_helper
INFO - 2018-12-20 12:07:40 --> Form Validation Class Initialized
INFO - 2018-12-20 12:07:40 --> Email Class Initialized
DEBUG - 2018-12-20 12:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:07:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:07:40 --> Pagination Class Initialized
INFO - 2018-12-20 12:07:40 --> Database Driver Class Initialized
INFO - 2018-12-20 12:07:40 --> Database Driver Class Initialized
INFO - 2018-12-20 12:07:40 --> Controller Class Initialized
INFO - 2018-12-20 12:07:40 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-20 12:07:40 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-12-20 12:07:40 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-20 12:07:40 --> Final output sent to browser
DEBUG - 2018-12-20 12:07:40 --> Total execution time: 0.1254
INFO - 2018-12-20 12:07:40 --> Config Class Initialized
INFO - 2018-12-20 12:07:40 --> Hooks Class Initialized
DEBUG - 2018-12-20 12:07:40 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:07:40 --> Utf8 Class Initialized
INFO - 2018-12-20 12:07:40 --> URI Class Initialized
INFO - 2018-12-20 12:07:40 --> Config Class Initialized
INFO - 2018-12-20 12:07:40 --> Hooks Class Initialized
INFO - 2018-12-20 12:07:40 --> Router Class Initialized
INFO - 2018-12-20 12:07:40 --> Output Class Initialized
INFO - 2018-12-20 12:07:41 --> Security Class Initialized
DEBUG - 2018-12-20 12:07:41 --> UTF-8 Support Enabled
DEBUG - 2018-12-20 12:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:07:41 --> Utf8 Class Initialized
INFO - 2018-12-20 12:07:41 --> Input Class Initialized
INFO - 2018-12-20 12:07:41 --> Language Class Initialized
INFO - 2018-12-20 12:07:41 --> URI Class Initialized
INFO - 2018-12-20 12:07:41 --> Loader Class Initialized
INFO - 2018-12-20 12:07:41 --> Helper loaded: url_helper
INFO - 2018-12-20 12:07:41 --> Helper loaded: html_helper
INFO - 2018-12-20 12:07:41 --> Router Class Initialized
INFO - 2018-12-20 12:07:41 --> Helper loaded: form_helper
INFO - 2018-12-20 12:07:41 --> Output Class Initialized
INFO - 2018-12-20 12:07:41 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:07:41 --> Security Class Initialized
INFO - 2018-12-20 12:07:41 --> Helper loaded: date_helper
INFO - 2018-12-20 12:07:41 --> Form Validation Class Initialized
INFO - 2018-12-20 12:07:41 --> Email Class Initialized
DEBUG - 2018-12-20 12:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:07:41 --> Input Class Initialized
INFO - 2018-12-20 12:07:41 --> Language Class Initialized
DEBUG - 2018-12-20 12:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:07:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:07:41 --> Pagination Class Initialized
INFO - 2018-12-20 12:07:41 --> Loader Class Initialized
INFO - 2018-12-20 12:07:41 --> Helper loaded: url_helper
INFO - 2018-12-20 12:07:41 --> Helper loaded: html_helper
INFO - 2018-12-20 12:07:41 --> Helper loaded: form_helper
INFO - 2018-12-20 12:07:41 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:07:41 --> Helper loaded: date_helper
INFO - 2018-12-20 12:07:41 --> Database Driver Class Initialized
INFO - 2018-12-20 12:07:41 --> Form Validation Class Initialized
INFO - 2018-12-20 12:07:41 --> Database Driver Class Initialized
INFO - 2018-12-20 12:07:41 --> Email Class Initialized
INFO - 2018-12-20 12:07:41 --> Controller Class Initialized
DEBUG - 2018-12-20 12:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:07:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 12:07:41 --> Final output sent to browser
DEBUG - 2018-12-20 12:07:41 --> Total execution time: 0.1278
INFO - 2018-12-20 12:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:07:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:07:41 --> Pagination Class Initialized
INFO - 2018-12-20 12:07:41 --> Database Driver Class Initialized
INFO - 2018-12-20 12:07:41 --> Database Driver Class Initialized
INFO - 2018-12-20 12:07:41 --> Controller Class Initialized
INFO - 2018-12-20 12:07:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 12:07:41 --> Final output sent to browser
DEBUG - 2018-12-20 12:07:41 --> Total execution time: 0.1710
INFO - 2018-12-20 12:09:18 --> Config Class Initialized
INFO - 2018-12-20 12:09:18 --> Hooks Class Initialized
DEBUG - 2018-12-20 12:09:18 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:09:18 --> Utf8 Class Initialized
INFO - 2018-12-20 12:09:18 --> URI Class Initialized
INFO - 2018-12-20 12:09:18 --> Router Class Initialized
INFO - 2018-12-20 12:09:18 --> Output Class Initialized
INFO - 2018-12-20 12:09:18 --> Security Class Initialized
DEBUG - 2018-12-20 12:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:09:18 --> Input Class Initialized
INFO - 2018-12-20 12:09:18 --> Language Class Initialized
INFO - 2018-12-20 12:09:18 --> Loader Class Initialized
INFO - 2018-12-20 12:09:18 --> Helper loaded: url_helper
INFO - 2018-12-20 12:09:18 --> Helper loaded: html_helper
INFO - 2018-12-20 12:09:18 --> Helper loaded: form_helper
INFO - 2018-12-20 12:09:18 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:09:18 --> Helper loaded: date_helper
INFO - 2018-12-20 12:09:18 --> Form Validation Class Initialized
INFO - 2018-12-20 12:09:18 --> Email Class Initialized
DEBUG - 2018-12-20 12:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:09:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:09:18 --> Pagination Class Initialized
INFO - 2018-12-20 12:09:18 --> Database Driver Class Initialized
INFO - 2018-12-20 12:09:18 --> Database Driver Class Initialized
INFO - 2018-12-20 12:09:18 --> Controller Class Initialized
INFO - 2018-12-20 12:09:18 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 12:09:18 --> Final output sent to browser
DEBUG - 2018-12-20 12:09:18 --> Total execution time: 0.0913
INFO - 2018-12-20 12:26:43 --> Config Class Initialized
INFO - 2018-12-20 12:26:43 --> Hooks Class Initialized
DEBUG - 2018-12-20 12:26:43 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:26:43 --> Utf8 Class Initialized
INFO - 2018-12-20 12:26:43 --> URI Class Initialized
INFO - 2018-12-20 12:26:43 --> Router Class Initialized
INFO - 2018-12-20 12:26:43 --> Output Class Initialized
INFO - 2018-12-20 12:26:43 --> Security Class Initialized
DEBUG - 2018-12-20 12:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:26:43 --> Input Class Initialized
INFO - 2018-12-20 12:26:43 --> Language Class Initialized
INFO - 2018-12-20 12:26:43 --> Loader Class Initialized
INFO - 2018-12-20 12:26:43 --> Helper loaded: url_helper
INFO - 2018-12-20 12:26:43 --> Helper loaded: html_helper
INFO - 2018-12-20 12:26:43 --> Helper loaded: form_helper
INFO - 2018-12-20 12:26:43 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:26:43 --> Helper loaded: date_helper
INFO - 2018-12-20 12:26:43 --> Form Validation Class Initialized
INFO - 2018-12-20 12:26:43 --> Email Class Initialized
DEBUG - 2018-12-20 12:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:26:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:26:43 --> Pagination Class Initialized
INFO - 2018-12-20 12:26:43 --> Database Driver Class Initialized
INFO - 2018-12-20 12:26:43 --> Database Driver Class Initialized
INFO - 2018-12-20 12:26:43 --> Controller Class Initialized
INFO - 2018-12-20 12:26:43 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 12:26:43 --> Final output sent to browser
DEBUG - 2018-12-20 12:26:43 --> Total execution time: 0.1361
INFO - 2018-12-20 12:26:48 --> Config Class Initialized
INFO - 2018-12-20 12:26:48 --> Hooks Class Initialized
DEBUG - 2018-12-20 12:26:48 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:26:48 --> Utf8 Class Initialized
INFO - 2018-12-20 12:26:48 --> URI Class Initialized
INFO - 2018-12-20 12:26:48 --> Router Class Initialized
INFO - 2018-12-20 12:26:48 --> Output Class Initialized
INFO - 2018-12-20 12:26:48 --> Security Class Initialized
DEBUG - 2018-12-20 12:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:26:48 --> Input Class Initialized
INFO - 2018-12-20 12:26:48 --> Language Class Initialized
INFO - 2018-12-20 12:26:48 --> Loader Class Initialized
INFO - 2018-12-20 12:26:48 --> Helper loaded: url_helper
INFO - 2018-12-20 12:26:48 --> Helper loaded: html_helper
INFO - 2018-12-20 12:26:48 --> Helper loaded: form_helper
INFO - 2018-12-20 12:26:48 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:26:48 --> Helper loaded: date_helper
INFO - 2018-12-20 12:26:48 --> Form Validation Class Initialized
INFO - 2018-12-20 12:26:48 --> Email Class Initialized
DEBUG - 2018-12-20 12:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:26:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:26:48 --> Pagination Class Initialized
INFO - 2018-12-20 12:26:48 --> Database Driver Class Initialized
INFO - 2018-12-20 12:26:48 --> Database Driver Class Initialized
INFO - 2018-12-20 12:26:48 --> Controller Class Initialized
INFO - 2018-12-20 12:26:48 --> Config Class Initialized
INFO - 2018-12-20 12:26:48 --> Hooks Class Initialized
DEBUG - 2018-12-20 12:26:48 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:26:48 --> Utf8 Class Initialized
INFO - 2018-12-20 12:26:48 --> URI Class Initialized
INFO - 2018-12-20 12:26:48 --> Router Class Initialized
INFO - 2018-12-20 12:26:48 --> Output Class Initialized
INFO - 2018-12-20 12:26:48 --> Security Class Initialized
DEBUG - 2018-12-20 12:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:26:48 --> Input Class Initialized
INFO - 2018-12-20 12:26:48 --> Language Class Initialized
INFO - 2018-12-20 12:26:48 --> Loader Class Initialized
INFO - 2018-12-20 12:26:48 --> Helper loaded: url_helper
INFO - 2018-12-20 12:26:48 --> Helper loaded: html_helper
INFO - 2018-12-20 12:26:48 --> Helper loaded: form_helper
INFO - 2018-12-20 12:26:48 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:26:48 --> Helper loaded: date_helper
INFO - 2018-12-20 12:26:48 --> Form Validation Class Initialized
INFO - 2018-12-20 12:26:48 --> Email Class Initialized
DEBUG - 2018-12-20 12:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:26:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:26:48 --> Pagination Class Initialized
INFO - 2018-12-20 12:26:48 --> Database Driver Class Initialized
INFO - 2018-12-20 12:26:48 --> Database Driver Class Initialized
INFO - 2018-12-20 12:26:48 --> Controller Class Initialized
INFO - 2018-12-20 12:26:48 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-12-20 12:26:48 --> Final output sent to browser
DEBUG - 2018-12-20 12:26:48 --> Total execution time: 0.0635
INFO - 2018-12-20 12:26:57 --> Config Class Initialized
INFO - 2018-12-20 12:26:57 --> Hooks Class Initialized
DEBUG - 2018-12-20 12:26:57 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:26:57 --> Utf8 Class Initialized
INFO - 2018-12-20 12:26:57 --> URI Class Initialized
INFO - 2018-12-20 12:26:57 --> Router Class Initialized
INFO - 2018-12-20 12:26:57 --> Output Class Initialized
INFO - 2018-12-20 12:26:57 --> Security Class Initialized
DEBUG - 2018-12-20 12:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:26:57 --> Input Class Initialized
INFO - 2018-12-20 12:26:57 --> Language Class Initialized
INFO - 2018-12-20 12:26:57 --> Loader Class Initialized
INFO - 2018-12-20 12:26:57 --> Helper loaded: url_helper
INFO - 2018-12-20 12:26:57 --> Helper loaded: html_helper
INFO - 2018-12-20 12:26:57 --> Helper loaded: form_helper
INFO - 2018-12-20 12:26:57 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:26:57 --> Helper loaded: date_helper
INFO - 2018-12-20 12:26:57 --> Form Validation Class Initialized
INFO - 2018-12-20 12:26:57 --> Email Class Initialized
DEBUG - 2018-12-20 12:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:26:57 --> Pagination Class Initialized
INFO - 2018-12-20 12:26:57 --> Database Driver Class Initialized
INFO - 2018-12-20 12:26:57 --> Database Driver Class Initialized
INFO - 2018-12-20 12:26:57 --> Controller Class Initialized
INFO - 2018-12-20 12:26:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-20 12:26:58 --> Config Class Initialized
INFO - 2018-12-20 12:26:58 --> Hooks Class Initialized
DEBUG - 2018-12-20 12:26:58 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:26:58 --> Utf8 Class Initialized
INFO - 2018-12-20 12:26:58 --> URI Class Initialized
INFO - 2018-12-20 12:26:58 --> Router Class Initialized
INFO - 2018-12-20 12:26:58 --> Output Class Initialized
INFO - 2018-12-20 12:26:58 --> Security Class Initialized
DEBUG - 2018-12-20 12:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:26:58 --> Input Class Initialized
INFO - 2018-12-20 12:26:58 --> Language Class Initialized
INFO - 2018-12-20 12:26:58 --> Loader Class Initialized
INFO - 2018-12-20 12:26:58 --> Helper loaded: url_helper
INFO - 2018-12-20 12:26:58 --> Helper loaded: html_helper
INFO - 2018-12-20 12:26:58 --> Helper loaded: form_helper
INFO - 2018-12-20 12:26:58 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:26:58 --> Helper loaded: date_helper
INFO - 2018-12-20 12:26:58 --> Form Validation Class Initialized
INFO - 2018-12-20 12:26:58 --> Email Class Initialized
DEBUG - 2018-12-20 12:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:26:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:26:58 --> Pagination Class Initialized
INFO - 2018-12-20 12:26:58 --> Database Driver Class Initialized
INFO - 2018-12-20 12:26:58 --> Database Driver Class Initialized
INFO - 2018-12-20 12:26:58 --> Controller Class Initialized
INFO - 2018-12-20 12:26:58 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-20 12:26:58 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-12-20 12:26:58 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-20 12:26:58 --> Final output sent to browser
DEBUG - 2018-12-20 12:26:58 --> Total execution time: 0.0977
INFO - 2018-12-20 12:26:58 --> Config Class Initialized
INFO - 2018-12-20 12:26:58 --> Hooks Class Initialized
INFO - 2018-12-20 12:26:58 --> Config Class Initialized
INFO - 2018-12-20 12:26:58 --> Hooks Class Initialized
DEBUG - 2018-12-20 12:26:58 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:26:58 --> Utf8 Class Initialized
DEBUG - 2018-12-20 12:26:58 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:26:58 --> Utf8 Class Initialized
INFO - 2018-12-20 12:26:58 --> URI Class Initialized
INFO - 2018-12-20 12:26:58 --> URI Class Initialized
INFO - 2018-12-20 12:26:58 --> Router Class Initialized
INFO - 2018-12-20 12:26:58 --> Router Class Initialized
INFO - 2018-12-20 12:26:58 --> Output Class Initialized
INFO - 2018-12-20 12:26:58 --> Output Class Initialized
INFO - 2018-12-20 12:26:58 --> Security Class Initialized
INFO - 2018-12-20 12:26:58 --> Security Class Initialized
DEBUG - 2018-12-20 12:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-12-20 12:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:26:58 --> Input Class Initialized
INFO - 2018-12-20 12:26:58 --> Input Class Initialized
INFO - 2018-12-20 12:26:58 --> Language Class Initialized
INFO - 2018-12-20 12:26:58 --> Language Class Initialized
INFO - 2018-12-20 12:26:58 --> Loader Class Initialized
INFO - 2018-12-20 12:26:58 --> Loader Class Initialized
INFO - 2018-12-20 12:26:58 --> Helper loaded: url_helper
INFO - 2018-12-20 12:26:58 --> Helper loaded: url_helper
INFO - 2018-12-20 12:26:58 --> Helper loaded: html_helper
INFO - 2018-12-20 12:26:58 --> Helper loaded: html_helper
INFO - 2018-12-20 12:26:58 --> Helper loaded: form_helper
INFO - 2018-12-20 12:26:58 --> Helper loaded: form_helper
INFO - 2018-12-20 12:26:58 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:26:58 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:26:58 --> Helper loaded: date_helper
INFO - 2018-12-20 12:26:58 --> Helper loaded: date_helper
INFO - 2018-12-20 12:26:58 --> Form Validation Class Initialized
INFO - 2018-12-20 12:26:58 --> Form Validation Class Initialized
INFO - 2018-12-20 12:26:58 --> Email Class Initialized
INFO - 2018-12-20 12:26:58 --> Email Class Initialized
DEBUG - 2018-12-20 12:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-12-20 12:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:26:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:26:58 --> Pagination Class Initialized
INFO - 2018-12-20 12:26:58 --> Database Driver Class Initialized
INFO - 2018-12-20 12:26:58 --> Database Driver Class Initialized
INFO - 2018-12-20 12:26:58 --> Controller Class Initialized
INFO - 2018-12-20 12:26:58 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 12:26:58 --> Final output sent to browser
DEBUG - 2018-12-20 12:26:58 --> Total execution time: 0.0927
INFO - 2018-12-20 12:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:26:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:26:58 --> Pagination Class Initialized
INFO - 2018-12-20 12:26:58 --> Database Driver Class Initialized
INFO - 2018-12-20 12:26:58 --> Database Driver Class Initialized
INFO - 2018-12-20 12:26:58 --> Controller Class Initialized
INFO - 2018-12-20 12:26:58 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 12:26:58 --> Final output sent to browser
DEBUG - 2018-12-20 12:26:58 --> Total execution time: 0.1508
INFO - 2018-12-20 12:30:17 --> Config Class Initialized
INFO - 2018-12-20 12:30:17 --> Hooks Class Initialized
DEBUG - 2018-12-20 12:30:17 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:30:17 --> Utf8 Class Initialized
INFO - 2018-12-20 12:30:17 --> URI Class Initialized
INFO - 2018-12-20 12:30:17 --> Router Class Initialized
INFO - 2018-12-20 12:30:17 --> Output Class Initialized
INFO - 2018-12-20 12:30:17 --> Security Class Initialized
DEBUG - 2018-12-20 12:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:30:17 --> Input Class Initialized
INFO - 2018-12-20 12:30:17 --> Language Class Initialized
INFO - 2018-12-20 12:30:17 --> Loader Class Initialized
INFO - 2018-12-20 12:30:17 --> Helper loaded: url_helper
INFO - 2018-12-20 12:30:17 --> Helper loaded: html_helper
INFO - 2018-12-20 12:30:17 --> Helper loaded: form_helper
INFO - 2018-12-20 12:30:17 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:30:17 --> Helper loaded: date_helper
INFO - 2018-12-20 12:30:17 --> Form Validation Class Initialized
INFO - 2018-12-20 12:30:17 --> Email Class Initialized
DEBUG - 2018-12-20 12:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:30:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:30:17 --> Pagination Class Initialized
INFO - 2018-12-20 12:30:17 --> Database Driver Class Initialized
INFO - 2018-12-20 12:30:17 --> Database Driver Class Initialized
INFO - 2018-12-20 12:30:17 --> Controller Class Initialized
INFO - 2018-12-20 12:30:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 12:30:17 --> Final output sent to browser
DEBUG - 2018-12-20 12:30:17 --> Total execution time: 0.0704
INFO - 2018-12-20 12:30:18 --> Config Class Initialized
INFO - 2018-12-20 12:30:18 --> Hooks Class Initialized
DEBUG - 2018-12-20 12:30:18 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:30:18 --> Utf8 Class Initialized
INFO - 2018-12-20 12:30:18 --> URI Class Initialized
INFO - 2018-12-20 12:30:18 --> Router Class Initialized
INFO - 2018-12-20 12:30:18 --> Output Class Initialized
INFO - 2018-12-20 12:30:18 --> Security Class Initialized
DEBUG - 2018-12-20 12:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:30:18 --> Input Class Initialized
INFO - 2018-12-20 12:30:18 --> Language Class Initialized
INFO - 2018-12-20 12:30:18 --> Loader Class Initialized
INFO - 2018-12-20 12:30:18 --> Helper loaded: url_helper
INFO - 2018-12-20 12:30:18 --> Helper loaded: html_helper
INFO - 2018-12-20 12:30:18 --> Helper loaded: form_helper
INFO - 2018-12-20 12:30:18 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:30:18 --> Helper loaded: date_helper
INFO - 2018-12-20 12:30:18 --> Form Validation Class Initialized
INFO - 2018-12-20 12:30:18 --> Email Class Initialized
DEBUG - 2018-12-20 12:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:30:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:30:18 --> Pagination Class Initialized
INFO - 2018-12-20 12:30:18 --> Database Driver Class Initialized
INFO - 2018-12-20 12:30:18 --> Database Driver Class Initialized
INFO - 2018-12-20 12:30:18 --> Controller Class Initialized
INFO - 2018-12-20 12:30:18 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 12:30:18 --> Final output sent to browser
DEBUG - 2018-12-20 12:30:18 --> Total execution time: 0.0736
INFO - 2018-12-20 12:30:20 --> Config Class Initialized
INFO - 2018-12-20 12:30:20 --> Hooks Class Initialized
DEBUG - 2018-12-20 12:30:20 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:30:20 --> Utf8 Class Initialized
INFO - 2018-12-20 12:30:20 --> URI Class Initialized
INFO - 2018-12-20 12:30:20 --> Router Class Initialized
INFO - 2018-12-20 12:30:20 --> Output Class Initialized
INFO - 2018-12-20 12:30:20 --> Security Class Initialized
DEBUG - 2018-12-20 12:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:30:20 --> Input Class Initialized
INFO - 2018-12-20 12:30:20 --> Language Class Initialized
INFO - 2018-12-20 12:30:20 --> Loader Class Initialized
INFO - 2018-12-20 12:30:20 --> Helper loaded: url_helper
INFO - 2018-12-20 12:30:20 --> Helper loaded: html_helper
INFO - 2018-12-20 12:30:20 --> Helper loaded: form_helper
INFO - 2018-12-20 12:30:20 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:30:20 --> Helper loaded: date_helper
INFO - 2018-12-20 12:30:20 --> Form Validation Class Initialized
INFO - 2018-12-20 12:30:20 --> Email Class Initialized
DEBUG - 2018-12-20 12:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:30:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:30:20 --> Pagination Class Initialized
INFO - 2018-12-20 12:30:20 --> Database Driver Class Initialized
INFO - 2018-12-20 12:30:20 --> Database Driver Class Initialized
INFO - 2018-12-20 12:30:20 --> Controller Class Initialized
INFO - 2018-12-20 12:30:20 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-20 12:30:20 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/user.php
INFO - 2018-12-20 12:30:20 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-20 12:30:20 --> Final output sent to browser
DEBUG - 2018-12-20 12:30:20 --> Total execution time: 0.1094
INFO - 2018-12-20 12:30:21 --> Config Class Initialized
INFO - 2018-12-20 12:30:21 --> Hooks Class Initialized
INFO - 2018-12-20 12:30:21 --> Config Class Initialized
INFO - 2018-12-20 12:30:21 --> Hooks Class Initialized
DEBUG - 2018-12-20 12:30:21 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:30:21 --> Utf8 Class Initialized
INFO - 2018-12-20 12:30:21 --> URI Class Initialized
DEBUG - 2018-12-20 12:30:21 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:30:21 --> Utf8 Class Initialized
INFO - 2018-12-20 12:30:21 --> Router Class Initialized
INFO - 2018-12-20 12:30:21 --> URI Class Initialized
INFO - 2018-12-20 12:30:21 --> Output Class Initialized
INFO - 2018-12-20 12:30:21 --> Router Class Initialized
INFO - 2018-12-20 12:30:21 --> Security Class Initialized
INFO - 2018-12-20 12:30:21 --> Output Class Initialized
DEBUG - 2018-12-20 12:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:30:21 --> Security Class Initialized
INFO - 2018-12-20 12:30:21 --> Input Class Initialized
DEBUG - 2018-12-20 12:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:30:21 --> Language Class Initialized
INFO - 2018-12-20 12:30:21 --> Input Class Initialized
INFO - 2018-12-20 12:30:21 --> Language Class Initialized
INFO - 2018-12-20 12:30:21 --> Loader Class Initialized
INFO - 2018-12-20 12:30:21 --> Loader Class Initialized
INFO - 2018-12-20 12:30:21 --> Helper loaded: url_helper
INFO - 2018-12-20 12:30:21 --> Helper loaded: url_helper
INFO - 2018-12-20 12:30:21 --> Helper loaded: html_helper
INFO - 2018-12-20 12:30:21 --> Helper loaded: html_helper
INFO - 2018-12-20 12:30:21 --> Helper loaded: form_helper
INFO - 2018-12-20 12:30:21 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:30:21 --> Helper loaded: form_helper
INFO - 2018-12-20 12:30:21 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:30:21 --> Helper loaded: date_helper
INFO - 2018-12-20 12:30:21 --> Helper loaded: date_helper
INFO - 2018-12-20 12:30:21 --> Form Validation Class Initialized
INFO - 2018-12-20 12:30:21 --> Form Validation Class Initialized
INFO - 2018-12-20 12:30:21 --> Email Class Initialized
INFO - 2018-12-20 12:30:21 --> Email Class Initialized
DEBUG - 2018-12-20 12:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-12-20 12:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:30:21 --> Pagination Class Initialized
INFO - 2018-12-20 12:30:21 --> Database Driver Class Initialized
INFO - 2018-12-20 12:30:21 --> Database Driver Class Initialized
INFO - 2018-12-20 12:30:21 --> Controller Class Initialized
INFO - 2018-12-20 12:30:21 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 12:30:21 --> Final output sent to browser
DEBUG - 2018-12-20 12:30:21 --> Total execution time: 0.0939
INFO - 2018-12-20 12:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:30:21 --> Pagination Class Initialized
INFO - 2018-12-20 12:30:21 --> Database Driver Class Initialized
INFO - 2018-12-20 12:30:21 --> Database Driver Class Initialized
INFO - 2018-12-20 12:30:21 --> Controller Class Initialized
INFO - 2018-12-20 12:30:21 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 12:30:21 --> Final output sent to browser
DEBUG - 2018-12-20 12:30:21 --> Total execution time: 0.1297
INFO - 2018-12-20 12:30:21 --> Config Class Initialized
INFO - 2018-12-20 12:30:21 --> Hooks Class Initialized
DEBUG - 2018-12-20 12:30:21 --> UTF-8 Support Enabled
INFO - 2018-12-20 12:30:21 --> Utf8 Class Initialized
INFO - 2018-12-20 12:30:21 --> URI Class Initialized
INFO - 2018-12-20 12:30:21 --> Router Class Initialized
INFO - 2018-12-20 12:30:21 --> Output Class Initialized
INFO - 2018-12-20 12:30:21 --> Security Class Initialized
DEBUG - 2018-12-20 12:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 12:30:21 --> Input Class Initialized
INFO - 2018-12-20 12:30:21 --> Language Class Initialized
INFO - 2018-12-20 12:30:21 --> Loader Class Initialized
INFO - 2018-12-20 12:30:21 --> Helper loaded: url_helper
INFO - 2018-12-20 12:30:21 --> Helper loaded: html_helper
INFO - 2018-12-20 12:30:21 --> Helper loaded: form_helper
INFO - 2018-12-20 12:30:21 --> Helper loaded: cookie_helper
INFO - 2018-12-20 12:30:21 --> Helper loaded: date_helper
INFO - 2018-12-20 12:30:21 --> Form Validation Class Initialized
INFO - 2018-12-20 12:30:21 --> Email Class Initialized
DEBUG - 2018-12-20 12:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 12:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 12:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 12:30:21 --> Pagination Class Initialized
INFO - 2018-12-20 12:30:21 --> Database Driver Class Initialized
INFO - 2018-12-20 12:30:21 --> Database Driver Class Initialized
INFO - 2018-12-20 12:30:21 --> Controller Class Initialized
INFO - 2018-12-20 12:30:21 --> Final output sent to browser
DEBUG - 2018-12-20 12:30:21 --> Total execution time: 0.1450
INFO - 2018-12-20 15:13:21 --> Config Class Initialized
INFO - 2018-12-20 15:13:21 --> Hooks Class Initialized
DEBUG - 2018-12-20 15:13:21 --> UTF-8 Support Enabled
INFO - 2018-12-20 15:13:21 --> Utf8 Class Initialized
INFO - 2018-12-20 15:13:21 --> URI Class Initialized
INFO - 2018-12-20 15:13:21 --> Router Class Initialized
INFO - 2018-12-20 15:13:21 --> Output Class Initialized
INFO - 2018-12-20 15:13:21 --> Security Class Initialized
DEBUG - 2018-12-20 15:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 15:13:21 --> Input Class Initialized
INFO - 2018-12-20 15:13:21 --> Language Class Initialized
INFO - 2018-12-20 15:13:21 --> Loader Class Initialized
INFO - 2018-12-20 15:13:21 --> Helper loaded: url_helper
INFO - 2018-12-20 15:13:21 --> Helper loaded: html_helper
INFO - 2018-12-20 15:13:21 --> Helper loaded: form_helper
INFO - 2018-12-20 15:13:21 --> Helper loaded: cookie_helper
INFO - 2018-12-20 15:13:21 --> Helper loaded: date_helper
INFO - 2018-12-20 15:13:21 --> Form Validation Class Initialized
INFO - 2018-12-20 15:13:21 --> Email Class Initialized
DEBUG - 2018-12-20 15:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 15:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 15:13:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 15:13:21 --> Pagination Class Initialized
INFO - 2018-12-20 15:13:21 --> Database Driver Class Initialized
INFO - 2018-12-20 15:13:21 --> Database Driver Class Initialized
INFO - 2018-12-20 15:13:21 --> Controller Class Initialized
INFO - 2018-12-20 15:13:21 --> Config Class Initialized
INFO - 2018-12-20 15:13:21 --> Hooks Class Initialized
DEBUG - 2018-12-20 15:13:21 --> UTF-8 Support Enabled
INFO - 2018-12-20 15:13:21 --> Utf8 Class Initialized
INFO - 2018-12-20 15:13:21 --> URI Class Initialized
INFO - 2018-12-20 15:13:21 --> Router Class Initialized
INFO - 2018-12-20 15:13:21 --> Output Class Initialized
INFO - 2018-12-20 15:13:21 --> Security Class Initialized
DEBUG - 2018-12-20 15:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 15:13:21 --> Input Class Initialized
INFO - 2018-12-20 15:13:21 --> Language Class Initialized
INFO - 2018-12-20 15:13:21 --> Loader Class Initialized
INFO - 2018-12-20 15:13:21 --> Helper loaded: url_helper
INFO - 2018-12-20 15:13:21 --> Helper loaded: html_helper
INFO - 2018-12-20 15:13:21 --> Helper loaded: form_helper
INFO - 2018-12-20 15:13:21 --> Helper loaded: cookie_helper
INFO - 2018-12-20 15:13:21 --> Helper loaded: date_helper
INFO - 2018-12-20 15:13:21 --> Form Validation Class Initialized
INFO - 2018-12-20 15:13:21 --> Email Class Initialized
DEBUG - 2018-12-20 15:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 15:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 15:13:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 15:13:21 --> Pagination Class Initialized
INFO - 2018-12-20 15:13:21 --> Database Driver Class Initialized
INFO - 2018-12-20 15:13:21 --> Database Driver Class Initialized
INFO - 2018-12-20 15:13:21 --> Controller Class Initialized
INFO - 2018-12-20 15:13:21 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-12-20 15:13:21 --> Final output sent to browser
DEBUG - 2018-12-20 15:13:21 --> Total execution time: 0.0596
INFO - 2018-12-20 15:13:32 --> Config Class Initialized
INFO - 2018-12-20 15:13:32 --> Hooks Class Initialized
DEBUG - 2018-12-20 15:13:32 --> UTF-8 Support Enabled
INFO - 2018-12-20 15:13:32 --> Utf8 Class Initialized
INFO - 2018-12-20 15:13:32 --> URI Class Initialized
INFO - 2018-12-20 15:13:32 --> Router Class Initialized
INFO - 2018-12-20 15:13:32 --> Output Class Initialized
INFO - 2018-12-20 15:13:32 --> Security Class Initialized
DEBUG - 2018-12-20 15:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 15:13:32 --> Input Class Initialized
INFO - 2018-12-20 15:13:32 --> Language Class Initialized
INFO - 2018-12-20 15:13:32 --> Loader Class Initialized
INFO - 2018-12-20 15:13:32 --> Helper loaded: url_helper
INFO - 2018-12-20 15:13:32 --> Helper loaded: html_helper
INFO - 2018-12-20 15:13:32 --> Helper loaded: form_helper
INFO - 2018-12-20 15:13:32 --> Helper loaded: cookie_helper
INFO - 2018-12-20 15:13:32 --> Helper loaded: date_helper
INFO - 2018-12-20 15:13:32 --> Form Validation Class Initialized
INFO - 2018-12-20 15:13:32 --> Email Class Initialized
DEBUG - 2018-12-20 15:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 15:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 15:13:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 15:13:32 --> Pagination Class Initialized
INFO - 2018-12-20 15:13:32 --> Database Driver Class Initialized
INFO - 2018-12-20 15:13:32 --> Database Driver Class Initialized
INFO - 2018-12-20 15:13:32 --> Controller Class Initialized
INFO - 2018-12-20 15:13:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-20 15:13:33 --> Config Class Initialized
INFO - 2018-12-20 15:13:33 --> Hooks Class Initialized
DEBUG - 2018-12-20 15:13:33 --> UTF-8 Support Enabled
INFO - 2018-12-20 15:13:33 --> Utf8 Class Initialized
INFO - 2018-12-20 15:13:33 --> URI Class Initialized
INFO - 2018-12-20 15:13:33 --> Router Class Initialized
INFO - 2018-12-20 15:13:33 --> Output Class Initialized
INFO - 2018-12-20 15:13:33 --> Security Class Initialized
DEBUG - 2018-12-20 15:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 15:13:33 --> Input Class Initialized
INFO - 2018-12-20 15:13:33 --> Language Class Initialized
INFO - 2018-12-20 15:13:33 --> Loader Class Initialized
INFO - 2018-12-20 15:13:33 --> Helper loaded: url_helper
INFO - 2018-12-20 15:13:33 --> Helper loaded: html_helper
INFO - 2018-12-20 15:13:33 --> Helper loaded: form_helper
INFO - 2018-12-20 15:13:33 --> Helper loaded: cookie_helper
INFO - 2018-12-20 15:13:33 --> Helper loaded: date_helper
INFO - 2018-12-20 15:13:33 --> Form Validation Class Initialized
INFO - 2018-12-20 15:13:33 --> Email Class Initialized
DEBUG - 2018-12-20 15:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 15:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 15:13:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 15:13:33 --> Pagination Class Initialized
INFO - 2018-12-20 15:13:33 --> Database Driver Class Initialized
INFO - 2018-12-20 15:13:33 --> Database Driver Class Initialized
INFO - 2018-12-20 15:13:33 --> Controller Class Initialized
INFO - 2018-12-20 15:13:33 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-20 15:13:33 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-12-20 15:13:33 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-20 15:13:33 --> Final output sent to browser
DEBUG - 2018-12-20 15:13:33 --> Total execution time: 0.0717
INFO - 2018-12-20 15:13:33 --> Config Class Initialized
INFO - 2018-12-20 15:13:33 --> Config Class Initialized
INFO - 2018-12-20 15:13:33 --> Hooks Class Initialized
INFO - 2018-12-20 15:13:33 --> Hooks Class Initialized
DEBUG - 2018-12-20 15:13:33 --> UTF-8 Support Enabled
INFO - 2018-12-20 15:13:33 --> Utf8 Class Initialized
DEBUG - 2018-12-20 15:13:33 --> UTF-8 Support Enabled
INFO - 2018-12-20 15:13:33 --> Utf8 Class Initialized
INFO - 2018-12-20 15:13:33 --> URI Class Initialized
INFO - 2018-12-20 15:13:33 --> URI Class Initialized
INFO - 2018-12-20 15:13:33 --> Router Class Initialized
INFO - 2018-12-20 15:13:33 --> Router Class Initialized
INFO - 2018-12-20 15:13:33 --> Output Class Initialized
INFO - 2018-12-20 15:13:33 --> Output Class Initialized
INFO - 2018-12-20 15:13:33 --> Security Class Initialized
INFO - 2018-12-20 15:13:33 --> Security Class Initialized
DEBUG - 2018-12-20 15:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 15:13:33 --> Input Class Initialized
INFO - 2018-12-20 15:13:33 --> Language Class Initialized
DEBUG - 2018-12-20 15:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 15:13:33 --> Input Class Initialized
INFO - 2018-12-20 15:13:33 --> Language Class Initialized
INFO - 2018-12-20 15:13:33 --> Loader Class Initialized
INFO - 2018-12-20 15:13:33 --> Helper loaded: url_helper
INFO - 2018-12-20 15:13:33 --> Helper loaded: html_helper
INFO - 2018-12-20 15:13:33 --> Helper loaded: form_helper
INFO - 2018-12-20 15:13:33 --> Helper loaded: cookie_helper
INFO - 2018-12-20 15:13:33 --> Loader Class Initialized
INFO - 2018-12-20 15:13:33 --> Helper loaded: date_helper
INFO - 2018-12-20 15:13:33 --> Helper loaded: url_helper
INFO - 2018-12-20 15:13:33 --> Form Validation Class Initialized
INFO - 2018-12-20 15:13:33 --> Helper loaded: html_helper
INFO - 2018-12-20 15:13:33 --> Email Class Initialized
INFO - 2018-12-20 15:13:33 --> Helper loaded: form_helper
INFO - 2018-12-20 15:13:33 --> Helper loaded: cookie_helper
DEBUG - 2018-12-20 15:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 15:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 15:13:33 --> Helper loaded: date_helper
INFO - 2018-12-20 15:13:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 15:13:33 --> Form Validation Class Initialized
INFO - 2018-12-20 15:13:33 --> Pagination Class Initialized
INFO - 2018-12-20 15:13:33 --> Email Class Initialized
DEBUG - 2018-12-20 15:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 15:13:33 --> Database Driver Class Initialized
INFO - 2018-12-20 15:13:33 --> Database Driver Class Initialized
INFO - 2018-12-20 15:13:33 --> Controller Class Initialized
INFO - 2018-12-20 15:13:33 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 15:13:33 --> Final output sent to browser
DEBUG - 2018-12-20 15:13:33 --> Total execution time: 0.0918
INFO - 2018-12-20 15:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 15:13:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 15:13:33 --> Pagination Class Initialized
INFO - 2018-12-20 15:13:33 --> Database Driver Class Initialized
INFO - 2018-12-20 15:13:33 --> Database Driver Class Initialized
INFO - 2018-12-20 15:13:33 --> Controller Class Initialized
INFO - 2018-12-20 15:13:33 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 15:13:33 --> Final output sent to browser
DEBUG - 2018-12-20 15:13:33 --> Total execution time: 0.1375
INFO - 2018-12-20 15:13:34 --> Config Class Initialized
INFO - 2018-12-20 15:13:34 --> Hooks Class Initialized
DEBUG - 2018-12-20 15:13:34 --> UTF-8 Support Enabled
INFO - 2018-12-20 15:13:34 --> Utf8 Class Initialized
INFO - 2018-12-20 15:13:34 --> URI Class Initialized
INFO - 2018-12-20 15:13:34 --> Router Class Initialized
INFO - 2018-12-20 15:13:34 --> Output Class Initialized
INFO - 2018-12-20 15:13:34 --> Security Class Initialized
DEBUG - 2018-12-20 15:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 15:13:34 --> Input Class Initialized
INFO - 2018-12-20 15:13:34 --> Language Class Initialized
INFO - 2018-12-20 15:13:34 --> Loader Class Initialized
INFO - 2018-12-20 15:13:34 --> Helper loaded: url_helper
INFO - 2018-12-20 15:13:34 --> Helper loaded: html_helper
INFO - 2018-12-20 15:13:34 --> Helper loaded: form_helper
INFO - 2018-12-20 15:13:34 --> Helper loaded: cookie_helper
INFO - 2018-12-20 15:13:34 --> Helper loaded: date_helper
INFO - 2018-12-20 15:13:34 --> Form Validation Class Initialized
INFO - 2018-12-20 15:13:34 --> Email Class Initialized
DEBUG - 2018-12-20 15:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 15:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 15:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 15:13:34 --> Pagination Class Initialized
INFO - 2018-12-20 15:13:34 --> Database Driver Class Initialized
INFO - 2018-12-20 15:13:34 --> Database Driver Class Initialized
INFO - 2018-12-20 15:13:34 --> Controller Class Initialized
INFO - 2018-12-20 15:13:34 --> Config Class Initialized
INFO - 2018-12-20 15:13:34 --> Hooks Class Initialized
INFO - 2018-12-20 15:13:34 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 15:13:34 --> Final output sent to browser
DEBUG - 2018-12-20 15:13:34 --> Total execution time: 0.0898
DEBUG - 2018-12-20 15:13:34 --> UTF-8 Support Enabled
INFO - 2018-12-20 15:13:34 --> Utf8 Class Initialized
INFO - 2018-12-20 15:13:34 --> URI Class Initialized
INFO - 2018-12-20 15:13:34 --> Router Class Initialized
INFO - 2018-12-20 15:13:34 --> Output Class Initialized
INFO - 2018-12-20 15:13:34 --> Security Class Initialized
DEBUG - 2018-12-20 15:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 15:13:34 --> Input Class Initialized
INFO - 2018-12-20 15:13:34 --> Language Class Initialized
INFO - 2018-12-20 15:13:34 --> Loader Class Initialized
INFO - 2018-12-20 15:13:34 --> Helper loaded: url_helper
INFO - 2018-12-20 15:13:34 --> Helper loaded: html_helper
INFO - 2018-12-20 15:13:34 --> Helper loaded: form_helper
INFO - 2018-12-20 15:13:34 --> Helper loaded: cookie_helper
INFO - 2018-12-20 15:13:34 --> Helper loaded: date_helper
INFO - 2018-12-20 15:13:34 --> Form Validation Class Initialized
INFO - 2018-12-20 15:13:34 --> Email Class Initialized
DEBUG - 2018-12-20 15:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 15:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 15:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 15:13:34 --> Pagination Class Initialized
INFO - 2018-12-20 15:13:34 --> Database Driver Class Initialized
INFO - 2018-12-20 15:13:34 --> Database Driver Class Initialized
INFO - 2018-12-20 15:13:34 --> Controller Class Initialized
INFO - 2018-12-20 15:13:34 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 15:13:34 --> Final output sent to browser
DEBUG - 2018-12-20 15:13:34 --> Total execution time: 0.1532
INFO - 2018-12-20 15:14:05 --> Config Class Initialized
INFO - 2018-12-20 15:14:05 --> Hooks Class Initialized
DEBUG - 2018-12-20 15:14:05 --> UTF-8 Support Enabled
INFO - 2018-12-20 15:14:05 --> Utf8 Class Initialized
INFO - 2018-12-20 15:14:05 --> URI Class Initialized
INFO - 2018-12-20 15:14:05 --> Router Class Initialized
INFO - 2018-12-20 15:14:05 --> Output Class Initialized
INFO - 2018-12-20 15:14:05 --> Security Class Initialized
DEBUG - 2018-12-20 15:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 15:14:05 --> Input Class Initialized
INFO - 2018-12-20 15:14:05 --> Language Class Initialized
INFO - 2018-12-20 15:14:05 --> Loader Class Initialized
INFO - 2018-12-20 15:14:05 --> Helper loaded: url_helper
INFO - 2018-12-20 15:14:05 --> Helper loaded: html_helper
INFO - 2018-12-20 15:14:05 --> Helper loaded: form_helper
INFO - 2018-12-20 15:14:05 --> Helper loaded: cookie_helper
INFO - 2018-12-20 15:14:05 --> Helper loaded: date_helper
INFO - 2018-12-20 15:14:05 --> Form Validation Class Initialized
INFO - 2018-12-20 15:14:05 --> Email Class Initialized
DEBUG - 2018-12-20 15:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 15:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 15:14:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 15:14:05 --> Pagination Class Initialized
INFO - 2018-12-20 15:14:05 --> Database Driver Class Initialized
INFO - 2018-12-20 15:14:05 --> Database Driver Class Initialized
INFO - 2018-12-20 15:14:05 --> Controller Class Initialized
INFO - 2018-12-20 15:14:05 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-20 15:14:05 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/user.php
INFO - 2018-12-20 15:14:05 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-20 15:14:05 --> Final output sent to browser
DEBUG - 2018-12-20 15:14:05 --> Total execution time: 0.0795
INFO - 2018-12-20 15:14:05 --> Config Class Initialized
INFO - 2018-12-20 15:14:05 --> Hooks Class Initialized
INFO - 2018-12-20 15:14:05 --> Config Class Initialized
INFO - 2018-12-20 15:14:05 --> Hooks Class Initialized
DEBUG - 2018-12-20 15:14:05 --> UTF-8 Support Enabled
INFO - 2018-12-20 15:14:05 --> Utf8 Class Initialized
DEBUG - 2018-12-20 15:14:05 --> UTF-8 Support Enabled
INFO - 2018-12-20 15:14:05 --> Utf8 Class Initialized
INFO - 2018-12-20 15:14:05 --> URI Class Initialized
INFO - 2018-12-20 15:14:05 --> URI Class Initialized
INFO - 2018-12-20 15:14:05 --> Router Class Initialized
INFO - 2018-12-20 15:14:05 --> Router Class Initialized
INFO - 2018-12-20 15:14:05 --> Output Class Initialized
INFO - 2018-12-20 15:14:05 --> Output Class Initialized
INFO - 2018-12-20 15:14:05 --> Security Class Initialized
INFO - 2018-12-20 15:14:05 --> Security Class Initialized
DEBUG - 2018-12-20 15:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-12-20 15:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 15:14:05 --> Input Class Initialized
INFO - 2018-12-20 15:14:05 --> Input Class Initialized
INFO - 2018-12-20 15:14:05 --> Language Class Initialized
INFO - 2018-12-20 15:14:05 --> Language Class Initialized
INFO - 2018-12-20 15:14:05 --> Loader Class Initialized
INFO - 2018-12-20 15:14:05 --> Loader Class Initialized
INFO - 2018-12-20 15:14:05 --> Helper loaded: url_helper
INFO - 2018-12-20 15:14:05 --> Helper loaded: url_helper
INFO - 2018-12-20 15:14:05 --> Helper loaded: html_helper
INFO - 2018-12-20 15:14:05 --> Helper loaded: html_helper
INFO - 2018-12-20 15:14:05 --> Helper loaded: form_helper
INFO - 2018-12-20 15:14:05 --> Helper loaded: form_helper
INFO - 2018-12-20 15:14:05 --> Helper loaded: cookie_helper
INFO - 2018-12-20 15:14:05 --> Helper loaded: cookie_helper
INFO - 2018-12-20 15:14:05 --> Helper loaded: date_helper
INFO - 2018-12-20 15:14:05 --> Helper loaded: date_helper
INFO - 2018-12-20 15:14:05 --> Form Validation Class Initialized
INFO - 2018-12-20 15:14:05 --> Form Validation Class Initialized
INFO - 2018-12-20 15:14:05 --> Email Class Initialized
INFO - 2018-12-20 15:14:05 --> Email Class Initialized
DEBUG - 2018-12-20 15:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-12-20 15:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 15:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 15:14:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 15:14:05 --> Pagination Class Initialized
INFO - 2018-12-20 15:14:05 --> Database Driver Class Initialized
INFO - 2018-12-20 15:14:05 --> Database Driver Class Initialized
INFO - 2018-12-20 15:14:05 --> Controller Class Initialized
INFO - 2018-12-20 15:14:05 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 15:14:05 --> Final output sent to browser
DEBUG - 2018-12-20 15:14:05 --> Total execution time: 0.0923
INFO - 2018-12-20 15:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 15:14:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 15:14:05 --> Pagination Class Initialized
INFO - 2018-12-20 15:14:05 --> Database Driver Class Initialized
INFO - 2018-12-20 15:14:05 --> Database Driver Class Initialized
INFO - 2018-12-20 15:14:05 --> Controller Class Initialized
INFO - 2018-12-20 15:14:05 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 15:14:05 --> Final output sent to browser
DEBUG - 2018-12-20 15:14:05 --> Total execution time: 0.1320
INFO - 2018-12-20 15:14:05 --> Config Class Initialized
INFO - 2018-12-20 15:14:05 --> Hooks Class Initialized
DEBUG - 2018-12-20 15:14:05 --> UTF-8 Support Enabled
INFO - 2018-12-20 15:14:05 --> Utf8 Class Initialized
INFO - 2018-12-20 15:14:05 --> URI Class Initialized
INFO - 2018-12-20 15:14:05 --> Router Class Initialized
INFO - 2018-12-20 15:14:05 --> Output Class Initialized
INFO - 2018-12-20 15:14:05 --> Security Class Initialized
DEBUG - 2018-12-20 15:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 15:14:05 --> Input Class Initialized
INFO - 2018-12-20 15:14:05 --> Language Class Initialized
INFO - 2018-12-20 15:14:05 --> Loader Class Initialized
INFO - 2018-12-20 15:14:05 --> Helper loaded: url_helper
INFO - 2018-12-20 15:14:05 --> Helper loaded: html_helper
INFO - 2018-12-20 15:14:05 --> Helper loaded: form_helper
INFO - 2018-12-20 15:14:05 --> Helper loaded: cookie_helper
INFO - 2018-12-20 15:14:05 --> Helper loaded: date_helper
INFO - 2018-12-20 15:14:05 --> Form Validation Class Initialized
INFO - 2018-12-20 15:14:05 --> Email Class Initialized
DEBUG - 2018-12-20 15:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 15:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 15:14:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 15:14:05 --> Pagination Class Initialized
INFO - 2018-12-20 15:14:05 --> Database Driver Class Initialized
INFO - 2018-12-20 15:14:05 --> Database Driver Class Initialized
INFO - 2018-12-20 15:14:05 --> Controller Class Initialized
INFO - 2018-12-20 15:14:05 --> Final output sent to browser
DEBUG - 2018-12-20 15:14:05 --> Total execution time: 0.1048
INFO - 2018-12-20 15:14:10 --> Config Class Initialized
INFO - 2018-12-20 15:14:10 --> Hooks Class Initialized
DEBUG - 2018-12-20 15:14:10 --> UTF-8 Support Enabled
INFO - 2018-12-20 15:14:10 --> Utf8 Class Initialized
INFO - 2018-12-20 15:14:10 --> URI Class Initialized
INFO - 2018-12-20 15:14:10 --> Router Class Initialized
INFO - 2018-12-20 15:14:10 --> Output Class Initialized
INFO - 2018-12-20 15:14:10 --> Security Class Initialized
DEBUG - 2018-12-20 15:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 15:14:10 --> Input Class Initialized
INFO - 2018-12-20 15:14:10 --> Language Class Initialized
INFO - 2018-12-20 15:14:10 --> Loader Class Initialized
INFO - 2018-12-20 15:14:10 --> Helper loaded: url_helper
INFO - 2018-12-20 15:14:10 --> Helper loaded: html_helper
INFO - 2018-12-20 15:14:10 --> Helper loaded: form_helper
INFO - 2018-12-20 15:14:10 --> Helper loaded: cookie_helper
INFO - 2018-12-20 15:14:10 --> Helper loaded: date_helper
INFO - 2018-12-20 15:14:10 --> Form Validation Class Initialized
INFO - 2018-12-20 15:14:10 --> Email Class Initialized
DEBUG - 2018-12-20 15:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 15:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 15:14:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 15:14:10 --> Pagination Class Initialized
INFO - 2018-12-20 15:14:10 --> Database Driver Class Initialized
INFO - 2018-12-20 15:14:10 --> Database Driver Class Initialized
INFO - 2018-12-20 15:14:10 --> Controller Class Initialized
INFO - 2018-12-20 15:14:10 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-20 15:14:10 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/user.php
INFO - 2018-12-20 15:14:10 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-20 15:14:10 --> Final output sent to browser
DEBUG - 2018-12-20 15:14:10 --> Total execution time: 0.0787
INFO - 2018-12-20 15:14:11 --> Config Class Initialized
INFO - 2018-12-20 15:14:11 --> Hooks Class Initialized
INFO - 2018-12-20 15:14:11 --> Config Class Initialized
INFO - 2018-12-20 15:14:11 --> Hooks Class Initialized
DEBUG - 2018-12-20 15:14:11 --> UTF-8 Support Enabled
INFO - 2018-12-20 15:14:11 --> Utf8 Class Initialized
DEBUG - 2018-12-20 15:14:11 --> UTF-8 Support Enabled
INFO - 2018-12-20 15:14:11 --> Utf8 Class Initialized
INFO - 2018-12-20 15:14:11 --> URI Class Initialized
INFO - 2018-12-20 15:14:11 --> URI Class Initialized
INFO - 2018-12-20 15:14:11 --> Router Class Initialized
INFO - 2018-12-20 15:14:11 --> Router Class Initialized
INFO - 2018-12-20 15:14:11 --> Output Class Initialized
INFO - 2018-12-20 15:14:11 --> Output Class Initialized
INFO - 2018-12-20 15:14:11 --> Security Class Initialized
INFO - 2018-12-20 15:14:11 --> Security Class Initialized
DEBUG - 2018-12-20 15:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 15:14:11 --> Input Class Initialized
DEBUG - 2018-12-20 15:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 15:14:11 --> Language Class Initialized
INFO - 2018-12-20 15:14:11 --> Input Class Initialized
INFO - 2018-12-20 15:14:11 --> Language Class Initialized
INFO - 2018-12-20 15:14:11 --> Loader Class Initialized
INFO - 2018-12-20 15:14:11 --> Loader Class Initialized
INFO - 2018-12-20 15:14:11 --> Helper loaded: url_helper
INFO - 2018-12-20 15:14:11 --> Helper loaded: url_helper
INFO - 2018-12-20 15:14:11 --> Helper loaded: html_helper
INFO - 2018-12-20 15:14:11 --> Helper loaded: html_helper
INFO - 2018-12-20 15:14:11 --> Helper loaded: form_helper
INFO - 2018-12-20 15:14:11 --> Helper loaded: cookie_helper
INFO - 2018-12-20 15:14:11 --> Helper loaded: form_helper
INFO - 2018-12-20 15:14:11 --> Helper loaded: cookie_helper
INFO - 2018-12-20 15:14:11 --> Helper loaded: date_helper
INFO - 2018-12-20 15:14:11 --> Helper loaded: date_helper
INFO - 2018-12-20 15:14:11 --> Form Validation Class Initialized
INFO - 2018-12-20 15:14:11 --> Form Validation Class Initialized
INFO - 2018-12-20 15:14:11 --> Email Class Initialized
INFO - 2018-12-20 15:14:11 --> Email Class Initialized
DEBUG - 2018-12-20 15:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 15:14:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-20 15:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 15:14:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 15:14:11 --> Pagination Class Initialized
INFO - 2018-12-20 15:14:11 --> Database Driver Class Initialized
INFO - 2018-12-20 15:14:11 --> Database Driver Class Initialized
INFO - 2018-12-20 15:14:11 --> Controller Class Initialized
INFO - 2018-12-20 15:14:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 15:14:11 --> Final output sent to browser
DEBUG - 2018-12-20 15:14:11 --> Total execution time: 0.0879
INFO - 2018-12-20 15:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 15:14:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 15:14:11 --> Pagination Class Initialized
INFO - 2018-12-20 15:14:11 --> Database Driver Class Initialized
INFO - 2018-12-20 15:14:11 --> Database Driver Class Initialized
INFO - 2018-12-20 15:14:11 --> Controller Class Initialized
INFO - 2018-12-20 15:14:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 15:14:11 --> Final output sent to browser
DEBUG - 2018-12-20 15:14:11 --> Total execution time: 0.1252
INFO - 2018-12-20 15:14:11 --> Config Class Initialized
INFO - 2018-12-20 15:14:11 --> Hooks Class Initialized
DEBUG - 2018-12-20 15:14:11 --> UTF-8 Support Enabled
INFO - 2018-12-20 15:14:11 --> Utf8 Class Initialized
INFO - 2018-12-20 15:14:11 --> URI Class Initialized
INFO - 2018-12-20 15:14:11 --> Router Class Initialized
INFO - 2018-12-20 15:14:11 --> Output Class Initialized
INFO - 2018-12-20 15:14:11 --> Security Class Initialized
DEBUG - 2018-12-20 15:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 15:14:11 --> Input Class Initialized
INFO - 2018-12-20 15:14:11 --> Language Class Initialized
INFO - 2018-12-20 15:14:11 --> Loader Class Initialized
INFO - 2018-12-20 15:14:11 --> Helper loaded: url_helper
INFO - 2018-12-20 15:14:11 --> Helper loaded: html_helper
INFO - 2018-12-20 15:14:11 --> Helper loaded: form_helper
INFO - 2018-12-20 15:14:11 --> Helper loaded: cookie_helper
INFO - 2018-12-20 15:14:11 --> Helper loaded: date_helper
INFO - 2018-12-20 15:14:11 --> Form Validation Class Initialized
INFO - 2018-12-20 15:14:11 --> Email Class Initialized
DEBUG - 2018-12-20 15:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 15:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 15:14:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 15:14:11 --> Pagination Class Initialized
INFO - 2018-12-20 15:14:11 --> Database Driver Class Initialized
INFO - 2018-12-20 15:14:11 --> Database Driver Class Initialized
INFO - 2018-12-20 15:14:11 --> Controller Class Initialized
INFO - 2018-12-20 15:14:11 --> Final output sent to browser
DEBUG - 2018-12-20 15:14:11 --> Total execution time: 0.1119
INFO - 2018-12-20 18:14:06 --> Config Class Initialized
INFO - 2018-12-20 18:14:06 --> Hooks Class Initialized
DEBUG - 2018-12-20 18:14:06 --> UTF-8 Support Enabled
INFO - 2018-12-20 18:14:06 --> Utf8 Class Initialized
INFO - 2018-12-20 18:14:06 --> URI Class Initialized
INFO - 2018-12-20 18:14:06 --> Router Class Initialized
INFO - 2018-12-20 18:14:06 --> Output Class Initialized
INFO - 2018-12-20 18:14:06 --> Security Class Initialized
DEBUG - 2018-12-20 18:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-20 18:14:06 --> Input Class Initialized
INFO - 2018-12-20 18:14:06 --> Language Class Initialized
INFO - 2018-12-20 18:14:06 --> Loader Class Initialized
INFO - 2018-12-20 18:14:06 --> Helper loaded: url_helper
INFO - 2018-12-20 18:14:06 --> Helper loaded: html_helper
INFO - 2018-12-20 18:14:06 --> Helper loaded: form_helper
INFO - 2018-12-20 18:14:06 --> Helper loaded: cookie_helper
INFO - 2018-12-20 18:14:06 --> Helper loaded: date_helper
INFO - 2018-12-20 18:14:06 --> Form Validation Class Initialized
INFO - 2018-12-20 18:14:06 --> Email Class Initialized
DEBUG - 2018-12-20 18:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-20 18:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-20 18:14:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-20 18:14:06 --> Pagination Class Initialized
INFO - 2018-12-20 18:14:06 --> Database Driver Class Initialized
INFO - 2018-12-20 18:14:06 --> Database Driver Class Initialized
INFO - 2018-12-20 18:14:06 --> Controller Class Initialized
INFO - 2018-12-20 18:14:06 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-20 18:14:06 --> Final output sent to browser
DEBUG - 2018-12-20 18:14:06 --> Total execution time: 0.0797
