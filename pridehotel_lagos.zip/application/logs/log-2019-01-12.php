<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-01-12 14:15:38 --> Config Class Initialized
INFO - 2019-01-12 14:15:38 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:15:38 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:15:38 --> Utf8 Class Initialized
INFO - 2019-01-12 14:15:38 --> URI Class Initialized
DEBUG - 2019-01-12 14:15:38 --> No URI present. Default controller set.
INFO - 2019-01-12 14:15:38 --> Router Class Initialized
INFO - 2019-01-12 14:15:38 --> Output Class Initialized
INFO - 2019-01-12 14:15:38 --> Security Class Initialized
DEBUG - 2019-01-12 14:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:15:38 --> Input Class Initialized
INFO - 2019-01-12 14:15:38 --> Language Class Initialized
INFO - 2019-01-12 14:15:38 --> Loader Class Initialized
INFO - 2019-01-12 14:15:38 --> Helper loaded: url_helper
INFO - 2019-01-12 14:15:38 --> Helper loaded: html_helper
INFO - 2019-01-12 14:15:38 --> Helper loaded: form_helper
INFO - 2019-01-12 14:15:38 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:15:38 --> Helper loaded: date_helper
INFO - 2019-01-12 14:15:38 --> Form Validation Class Initialized
INFO - 2019-01-12 14:15:38 --> Email Class Initialized
DEBUG - 2019-01-12 14:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:15:39 --> Pagination Class Initialized
INFO - 2019-01-12 14:15:39 --> Database Driver Class Initialized
INFO - 2019-01-12 14:15:39 --> Database Driver Class Initialized
INFO - 2019-01-12 14:15:39 --> Controller Class Initialized
INFO - 2019-01-12 14:15:39 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-01-12 14:15:39 --> Final output sent to browser
DEBUG - 2019-01-12 14:15:39 --> Total execution time: 1.4432
INFO - 2019-01-12 14:15:53 --> Config Class Initialized
INFO - 2019-01-12 14:15:53 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:15:53 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:15:53 --> Utf8 Class Initialized
INFO - 2019-01-12 14:15:53 --> URI Class Initialized
INFO - 2019-01-12 14:15:53 --> Router Class Initialized
INFO - 2019-01-12 14:15:53 --> Output Class Initialized
INFO - 2019-01-12 14:15:53 --> Security Class Initialized
DEBUG - 2019-01-12 14:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:15:53 --> Input Class Initialized
INFO - 2019-01-12 14:15:53 --> Language Class Initialized
INFO - 2019-01-12 14:15:53 --> Loader Class Initialized
INFO - 2019-01-12 14:15:53 --> Helper loaded: url_helper
INFO - 2019-01-12 14:15:53 --> Helper loaded: html_helper
INFO - 2019-01-12 14:15:53 --> Helper loaded: form_helper
INFO - 2019-01-12 14:15:53 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:15:53 --> Helper loaded: date_helper
INFO - 2019-01-12 14:15:53 --> Form Validation Class Initialized
INFO - 2019-01-12 14:15:53 --> Email Class Initialized
DEBUG - 2019-01-12 14:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:15:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:15:53 --> Pagination Class Initialized
INFO - 2019-01-12 14:15:53 --> Database Driver Class Initialized
INFO - 2019-01-12 14:15:53 --> Database Driver Class Initialized
INFO - 2019-01-12 14:15:53 --> Controller Class Initialized
INFO - 2019-01-12 14:15:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-01-12 14:15:53 --> Config Class Initialized
INFO - 2019-01-12 14:15:53 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:15:53 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:15:53 --> Utf8 Class Initialized
INFO - 2019-01-12 14:15:53 --> URI Class Initialized
INFO - 2019-01-12 14:15:53 --> Router Class Initialized
INFO - 2019-01-12 14:15:53 --> Output Class Initialized
INFO - 2019-01-12 14:15:53 --> Security Class Initialized
DEBUG - 2019-01-12 14:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:15:53 --> Input Class Initialized
INFO - 2019-01-12 14:15:53 --> Language Class Initialized
INFO - 2019-01-12 14:15:53 --> Loader Class Initialized
INFO - 2019-01-12 14:15:54 --> Helper loaded: url_helper
INFO - 2019-01-12 14:15:54 --> Helper loaded: html_helper
INFO - 2019-01-12 14:15:54 --> Helper loaded: form_helper
INFO - 2019-01-12 14:15:54 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:15:54 --> Helper loaded: date_helper
INFO - 2019-01-12 14:15:54 --> Form Validation Class Initialized
INFO - 2019-01-12 14:15:54 --> Email Class Initialized
DEBUG - 2019-01-12 14:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:15:54 --> Pagination Class Initialized
INFO - 2019-01-12 14:15:54 --> Database Driver Class Initialized
INFO - 2019-01-12 14:15:54 --> Database Driver Class Initialized
INFO - 2019-01-12 14:15:54 --> Controller Class Initialized
INFO - 2019-01-12 14:15:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-01-12 14:15:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-01-12 14:15:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-01-12 14:15:54 --> Final output sent to browser
DEBUG - 2019-01-12 14:15:54 --> Total execution time: 0.5698
INFO - 2019-01-12 14:15:55 --> Config Class Initialized
INFO - 2019-01-12 14:15:55 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:15:55 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:15:55 --> Utf8 Class Initialized
INFO - 2019-01-12 14:15:55 --> URI Class Initialized
INFO - 2019-01-12 14:15:55 --> Router Class Initialized
INFO - 2019-01-12 14:15:55 --> Config Class Initialized
INFO - 2019-01-12 14:15:55 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:15:55 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:15:55 --> Utf8 Class Initialized
INFO - 2019-01-12 14:15:55 --> Output Class Initialized
INFO - 2019-01-12 14:15:55 --> URI Class Initialized
INFO - 2019-01-12 14:15:55 --> Security Class Initialized
DEBUG - 2019-01-12 14:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:15:55 --> Input Class Initialized
INFO - 2019-01-12 14:15:55 --> Language Class Initialized
INFO - 2019-01-12 14:15:55 --> Router Class Initialized
INFO - 2019-01-12 14:15:55 --> Loader Class Initialized
INFO - 2019-01-12 14:15:55 --> Output Class Initialized
INFO - 2019-01-12 14:15:55 --> Helper loaded: url_helper
INFO - 2019-01-12 14:15:55 --> Security Class Initialized
INFO - 2019-01-12 14:15:55 --> Helper loaded: html_helper
DEBUG - 2019-01-12 14:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:15:55 --> Input Class Initialized
INFO - 2019-01-12 14:15:55 --> Helper loaded: form_helper
INFO - 2019-01-12 14:15:55 --> Language Class Initialized
INFO - 2019-01-12 14:15:55 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:15:55 --> Helper loaded: date_helper
INFO - 2019-01-12 14:15:55 --> Form Validation Class Initialized
INFO - 2019-01-12 14:15:55 --> Loader Class Initialized
INFO - 2019-01-12 14:15:55 --> Email Class Initialized
INFO - 2019-01-12 14:15:55 --> Helper loaded: url_helper
INFO - 2019-01-12 14:15:55 --> Helper loaded: html_helper
DEBUG - 2019-01-12 14:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:15:55 --> Helper loaded: form_helper
INFO - 2019-01-12 14:15:55 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:15:55 --> Helper loaded: date_helper
INFO - 2019-01-12 14:15:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:15:55 --> Pagination Class Initialized
INFO - 2019-01-12 14:15:55 --> Form Validation Class Initialized
INFO - 2019-01-12 14:15:55 --> Email Class Initialized
DEBUG - 2019-01-12 14:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:15:55 --> Database Driver Class Initialized
INFO - 2019-01-12 14:15:55 --> Database Driver Class Initialized
INFO - 2019-01-12 14:15:55 --> Controller Class Initialized
INFO - 2019-01-12 14:15:55 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-12 14:15:55 --> Final output sent to browser
DEBUG - 2019-01-12 14:15:55 --> Total execution time: 0.1894
INFO - 2019-01-12 14:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:15:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:15:55 --> Pagination Class Initialized
INFO - 2019-01-12 14:15:55 --> Database Driver Class Initialized
INFO - 2019-01-12 14:15:55 --> Database Driver Class Initialized
INFO - 2019-01-12 14:15:55 --> Controller Class Initialized
INFO - 2019-01-12 14:15:55 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-12 14:15:55 --> Final output sent to browser
DEBUG - 2019-01-12 14:15:55 --> Total execution time: 0.3662
INFO - 2019-01-12 14:16:03 --> Config Class Initialized
INFO - 2019-01-12 14:16:03 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:16:03 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:16:03 --> Utf8 Class Initialized
INFO - 2019-01-12 14:16:03 --> URI Class Initialized
INFO - 2019-01-12 14:16:03 --> Router Class Initialized
INFO - 2019-01-12 14:16:03 --> Output Class Initialized
INFO - 2019-01-12 14:16:03 --> Security Class Initialized
DEBUG - 2019-01-12 14:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:16:03 --> Input Class Initialized
INFO - 2019-01-12 14:16:03 --> Language Class Initialized
INFO - 2019-01-12 14:16:03 --> Loader Class Initialized
INFO - 2019-01-12 14:16:03 --> Helper loaded: url_helper
INFO - 2019-01-12 14:16:03 --> Helper loaded: html_helper
INFO - 2019-01-12 14:16:03 --> Helper loaded: form_helper
INFO - 2019-01-12 14:16:03 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:16:03 --> Helper loaded: date_helper
INFO - 2019-01-12 14:16:03 --> Form Validation Class Initialized
INFO - 2019-01-12 14:16:03 --> Email Class Initialized
DEBUG - 2019-01-12 14:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:16:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:16:03 --> Pagination Class Initialized
INFO - 2019-01-12 14:16:03 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:03 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:03 --> Controller Class Initialized
INFO - 2019-01-12 14:16:03 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-01-12 14:16:03 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-01-12 14:16:03 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-01-12 14:16:03 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-01-12 14:16:04 --> Final output sent to browser
DEBUG - 2019-01-12 14:16:04 --> Total execution time: 0.3565
INFO - 2019-01-12 14:16:04 --> Config Class Initialized
INFO - 2019-01-12 14:16:04 --> Hooks Class Initialized
INFO - 2019-01-12 14:16:04 --> Config Class Initialized
INFO - 2019-01-12 14:16:04 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:16:04 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:16:04 --> Utf8 Class Initialized
INFO - 2019-01-12 14:16:04 --> URI Class Initialized
INFO - 2019-01-12 14:16:04 --> Router Class Initialized
INFO - 2019-01-12 14:16:04 --> Output Class Initialized
INFO - 2019-01-12 14:16:04 --> Security Class Initialized
DEBUG - 2019-01-12 14:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:16:04 --> Input Class Initialized
INFO - 2019-01-12 14:16:04 --> Language Class Initialized
INFO - 2019-01-12 14:16:04 --> Loader Class Initialized
INFO - 2019-01-12 14:16:04 --> Helper loaded: url_helper
INFO - 2019-01-12 14:16:04 --> Helper loaded: html_helper
INFO - 2019-01-12 14:16:04 --> Helper loaded: form_helper
DEBUG - 2019-01-12 14:16:04 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:16:04 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:16:04 --> Utf8 Class Initialized
INFO - 2019-01-12 14:16:04 --> URI Class Initialized
INFO - 2019-01-12 14:16:04 --> Helper loaded: date_helper
INFO - 2019-01-12 14:16:04 --> Form Validation Class Initialized
INFO - 2019-01-12 14:16:04 --> Email Class Initialized
DEBUG - 2019-01-12 14:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:16:04 --> Router Class Initialized
INFO - 2019-01-12 14:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:16:04 --> Pagination Class Initialized
INFO - 2019-01-12 14:16:04 --> Output Class Initialized
INFO - 2019-01-12 14:16:04 --> Security Class Initialized
DEBUG - 2019-01-12 14:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:16:04 --> Input Class Initialized
INFO - 2019-01-12 14:16:04 --> Language Class Initialized
INFO - 2019-01-12 14:16:04 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:04 --> Loader Class Initialized
INFO - 2019-01-12 14:16:04 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:04 --> Helper loaded: url_helper
INFO - 2019-01-12 14:16:04 --> Helper loaded: html_helper
INFO - 2019-01-12 14:16:04 --> Helper loaded: form_helper
INFO - 2019-01-12 14:16:04 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:16:04 --> Controller Class Initialized
INFO - 2019-01-12 14:16:04 --> Helper loaded: date_helper
INFO - 2019-01-12 14:16:04 --> Form Validation Class Initialized
INFO - 2019-01-12 14:16:04 --> Email Class Initialized
DEBUG - 2019-01-12 14:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:16:04 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-12 14:16:04 --> Final output sent to browser
DEBUG - 2019-01-12 14:16:04 --> Total execution time: 0.0751
INFO - 2019-01-12 14:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:16:04 --> Pagination Class Initialized
INFO - 2019-01-12 14:16:04 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:04 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:04 --> Controller Class Initialized
INFO - 2019-01-12 14:16:04 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-12 14:16:04 --> Final output sent to browser
DEBUG - 2019-01-12 14:16:04 --> Total execution time: 0.1124
INFO - 2019-01-12 14:16:09 --> Config Class Initialized
INFO - 2019-01-12 14:16:09 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:16:09 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:16:09 --> Utf8 Class Initialized
INFO - 2019-01-12 14:16:09 --> URI Class Initialized
INFO - 2019-01-12 14:16:09 --> Router Class Initialized
INFO - 2019-01-12 14:16:09 --> Output Class Initialized
INFO - 2019-01-12 14:16:09 --> Security Class Initialized
DEBUG - 2019-01-12 14:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:16:09 --> Input Class Initialized
INFO - 2019-01-12 14:16:09 --> Language Class Initialized
INFO - 2019-01-12 14:16:09 --> Loader Class Initialized
INFO - 2019-01-12 14:16:09 --> Helper loaded: url_helper
INFO - 2019-01-12 14:16:09 --> Helper loaded: html_helper
INFO - 2019-01-12 14:16:09 --> Helper loaded: form_helper
INFO - 2019-01-12 14:16:09 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:16:09 --> Helper loaded: date_helper
INFO - 2019-01-12 14:16:09 --> Form Validation Class Initialized
INFO - 2019-01-12 14:16:09 --> Email Class Initialized
DEBUG - 2019-01-12 14:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:16:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:16:09 --> Pagination Class Initialized
INFO - 2019-01-12 14:16:09 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:09 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:09 --> Controller Class Initialized
INFO - 2019-01-12 14:16:09 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-01-12 14:16:09 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/folio.php
INFO - 2019-01-12 14:16:09 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-01-12 14:16:09 --> Final output sent to browser
DEBUG - 2019-01-12 14:16:09 --> Total execution time: 0.4647
INFO - 2019-01-12 14:16:09 --> Config Class Initialized
INFO - 2019-01-12 14:16:09 --> Hooks Class Initialized
INFO - 2019-01-12 14:16:09 --> Config Class Initialized
INFO - 2019-01-12 14:16:09 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:16:09 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:16:09 --> Utf8 Class Initialized
DEBUG - 2019-01-12 14:16:09 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:16:09 --> Utf8 Class Initialized
INFO - 2019-01-12 14:16:09 --> URI Class Initialized
INFO - 2019-01-12 14:16:09 --> URI Class Initialized
INFO - 2019-01-12 14:16:09 --> Router Class Initialized
INFO - 2019-01-12 14:16:09 --> Router Class Initialized
INFO - 2019-01-12 14:16:09 --> Output Class Initialized
INFO - 2019-01-12 14:16:09 --> Output Class Initialized
INFO - 2019-01-12 14:16:09 --> Security Class Initialized
INFO - 2019-01-12 14:16:09 --> Security Class Initialized
DEBUG - 2019-01-12 14:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-01-12 14:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:16:09 --> Input Class Initialized
INFO - 2019-01-12 14:16:09 --> Input Class Initialized
INFO - 2019-01-12 14:16:09 --> Language Class Initialized
INFO - 2019-01-12 14:16:09 --> Language Class Initialized
INFO - 2019-01-12 14:16:09 --> Loader Class Initialized
INFO - 2019-01-12 14:16:09 --> Loader Class Initialized
INFO - 2019-01-12 14:16:09 --> Helper loaded: url_helper
INFO - 2019-01-12 14:16:09 --> Helper loaded: html_helper
INFO - 2019-01-12 14:16:09 --> Helper loaded: url_helper
INFO - 2019-01-12 14:16:09 --> Helper loaded: html_helper
INFO - 2019-01-12 14:16:09 --> Helper loaded: form_helper
INFO - 2019-01-12 14:16:09 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:16:09 --> Helper loaded: form_helper
INFO - 2019-01-12 14:16:09 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:16:09 --> Helper loaded: date_helper
INFO - 2019-01-12 14:16:09 --> Helper loaded: date_helper
INFO - 2019-01-12 14:16:09 --> Form Validation Class Initialized
INFO - 2019-01-12 14:16:09 --> Form Validation Class Initialized
INFO - 2019-01-12 14:16:09 --> Email Class Initialized
INFO - 2019-01-12 14:16:09 --> Email Class Initialized
DEBUG - 2019-01-12 14:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-01-12 14:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:16:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:16:09 --> Pagination Class Initialized
INFO - 2019-01-12 14:16:09 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:09 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:09 --> Controller Class Initialized
INFO - 2019-01-12 14:16:09 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-12 14:16:09 --> Final output sent to browser
DEBUG - 2019-01-12 14:16:09 --> Total execution time: 0.0694
INFO - 2019-01-12 14:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:16:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:16:09 --> Pagination Class Initialized
INFO - 2019-01-12 14:16:09 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:09 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:09 --> Controller Class Initialized
INFO - 2019-01-12 14:16:09 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-12 14:16:09 --> Final output sent to browser
DEBUG - 2019-01-12 14:16:09 --> Total execution time: 0.1055
INFO - 2019-01-12 14:16:45 --> Config Class Initialized
INFO - 2019-01-12 14:16:45 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:16:45 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:16:45 --> Utf8 Class Initialized
INFO - 2019-01-12 14:16:45 --> URI Class Initialized
INFO - 2019-01-12 14:16:45 --> Router Class Initialized
INFO - 2019-01-12 14:16:45 --> Output Class Initialized
INFO - 2019-01-12 14:16:45 --> Security Class Initialized
DEBUG - 2019-01-12 14:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:16:45 --> Input Class Initialized
INFO - 2019-01-12 14:16:45 --> Language Class Initialized
INFO - 2019-01-12 14:16:45 --> Loader Class Initialized
INFO - 2019-01-12 14:16:45 --> Helper loaded: url_helper
INFO - 2019-01-12 14:16:45 --> Helper loaded: html_helper
INFO - 2019-01-12 14:16:45 --> Helper loaded: form_helper
INFO - 2019-01-12 14:16:45 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:16:45 --> Helper loaded: date_helper
INFO - 2019-01-12 14:16:45 --> Form Validation Class Initialized
INFO - 2019-01-12 14:16:45 --> Email Class Initialized
DEBUG - 2019-01-12 14:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:16:45 --> Pagination Class Initialized
INFO - 2019-01-12 14:16:45 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:45 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:45 --> Controller Class Initialized
INFO - 2019-01-12 14:16:45 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-12 14:16:45 --> Final output sent to browser
DEBUG - 2019-01-12 14:16:45 --> Total execution time: 0.2625
INFO - 2019-01-12 14:16:46 --> Config Class Initialized
INFO - 2019-01-12 14:16:46 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:16:46 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:16:46 --> Utf8 Class Initialized
INFO - 2019-01-12 14:16:46 --> URI Class Initialized
INFO - 2019-01-12 14:16:46 --> Router Class Initialized
INFO - 2019-01-12 14:16:46 --> Output Class Initialized
INFO - 2019-01-12 14:16:46 --> Security Class Initialized
DEBUG - 2019-01-12 14:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:16:46 --> Input Class Initialized
INFO - 2019-01-12 14:16:46 --> Language Class Initialized
INFO - 2019-01-12 14:16:46 --> Loader Class Initialized
INFO - 2019-01-12 14:16:46 --> Helper loaded: url_helper
INFO - 2019-01-12 14:16:46 --> Helper loaded: html_helper
INFO - 2019-01-12 14:16:46 --> Helper loaded: form_helper
INFO - 2019-01-12 14:16:46 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:16:46 --> Helper loaded: date_helper
INFO - 2019-01-12 14:16:46 --> Form Validation Class Initialized
INFO - 2019-01-12 14:16:46 --> Email Class Initialized
DEBUG - 2019-01-12 14:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:16:46 --> Pagination Class Initialized
INFO - 2019-01-12 14:16:46 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:46 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:46 --> Controller Class Initialized
INFO - 2019-01-12 14:16:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-12 14:16:46 --> Final output sent to browser
DEBUG - 2019-01-12 14:16:46 --> Total execution time: 0.0623
INFO - 2019-01-12 14:16:49 --> Config Class Initialized
INFO - 2019-01-12 14:16:49 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:16:49 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:16:49 --> Utf8 Class Initialized
INFO - 2019-01-12 14:16:49 --> URI Class Initialized
INFO - 2019-01-12 14:16:49 --> Router Class Initialized
INFO - 2019-01-12 14:16:49 --> Output Class Initialized
INFO - 2019-01-12 14:16:49 --> Security Class Initialized
DEBUG - 2019-01-12 14:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:16:49 --> Input Class Initialized
INFO - 2019-01-12 14:16:49 --> Language Class Initialized
INFO - 2019-01-12 14:16:49 --> Loader Class Initialized
INFO - 2019-01-12 14:16:49 --> Helper loaded: url_helper
INFO - 2019-01-12 14:16:49 --> Helper loaded: html_helper
INFO - 2019-01-12 14:16:49 --> Helper loaded: form_helper
INFO - 2019-01-12 14:16:49 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:16:49 --> Helper loaded: date_helper
INFO - 2019-01-12 14:16:49 --> Form Validation Class Initialized
INFO - 2019-01-12 14:16:49 --> Email Class Initialized
DEBUG - 2019-01-12 14:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:16:49 --> Pagination Class Initialized
INFO - 2019-01-12 14:16:49 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:49 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:49 --> Controller Class Initialized
INFO - 2019-01-12 14:16:49 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-01-12 14:16:49 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/ledger.php
INFO - 2019-01-12 14:16:49 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-01-12 14:16:49 --> Final output sent to browser
DEBUG - 2019-01-12 14:16:49 --> Total execution time: 0.1608
INFO - 2019-01-12 14:16:49 --> Config Class Initialized
INFO - 2019-01-12 14:16:49 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:16:49 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:16:49 --> Utf8 Class Initialized
INFO - 2019-01-12 14:16:49 --> URI Class Initialized
INFO - 2019-01-12 14:16:49 --> Router Class Initialized
INFO - 2019-01-12 14:16:49 --> Output Class Initialized
INFO - 2019-01-12 14:16:49 --> Security Class Initialized
DEBUG - 2019-01-12 14:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:16:49 --> Input Class Initialized
INFO - 2019-01-12 14:16:49 --> Language Class Initialized
INFO - 2019-01-12 14:16:49 --> Loader Class Initialized
INFO - 2019-01-12 14:16:49 --> Config Class Initialized
INFO - 2019-01-12 14:16:49 --> Helper loaded: url_helper
INFO - 2019-01-12 14:16:49 --> Hooks Class Initialized
INFO - 2019-01-12 14:16:49 --> Helper loaded: html_helper
INFO - 2019-01-12 14:16:49 --> Helper loaded: form_helper
DEBUG - 2019-01-12 14:16:49 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:16:49 --> Utf8 Class Initialized
INFO - 2019-01-12 14:16:49 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:16:49 --> URI Class Initialized
INFO - 2019-01-12 14:16:49 --> Helper loaded: date_helper
INFO - 2019-01-12 14:16:49 --> Router Class Initialized
INFO - 2019-01-12 14:16:49 --> Form Validation Class Initialized
INFO - 2019-01-12 14:16:49 --> Output Class Initialized
INFO - 2019-01-12 14:16:49 --> Email Class Initialized
INFO - 2019-01-12 14:16:49 --> Security Class Initialized
DEBUG - 2019-01-12 14:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:16:49 --> Input Class Initialized
DEBUG - 2019-01-12 14:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:16:49 --> Language Class Initialized
INFO - 2019-01-12 14:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:16:49 --> Pagination Class Initialized
INFO - 2019-01-12 14:16:49 --> Loader Class Initialized
INFO - 2019-01-12 14:16:49 --> Helper loaded: url_helper
INFO - 2019-01-12 14:16:49 --> Helper loaded: html_helper
INFO - 2019-01-12 14:16:49 --> Helper loaded: form_helper
INFO - 2019-01-12 14:16:49 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:49 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:16:49 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:49 --> Helper loaded: date_helper
INFO - 2019-01-12 14:16:49 --> Form Validation Class Initialized
INFO - 2019-01-12 14:16:49 --> Email Class Initialized
INFO - 2019-01-12 14:16:49 --> Controller Class Initialized
DEBUG - 2019-01-12 14:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:16:49 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-12 14:16:49 --> Final output sent to browser
DEBUG - 2019-01-12 14:16:49 --> Total execution time: 0.0922
INFO - 2019-01-12 14:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:16:49 --> Pagination Class Initialized
INFO - 2019-01-12 14:16:49 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:49 --> Database Driver Class Initialized
INFO - 2019-01-12 14:16:49 --> Controller Class Initialized
INFO - 2019-01-12 14:16:49 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-12 14:16:49 --> Final output sent to browser
DEBUG - 2019-01-12 14:16:49 --> Total execution time: 0.0969
INFO - 2019-01-12 14:19:14 --> Config Class Initialized
INFO - 2019-01-12 14:19:14 --> Hooks Class Initialized
INFO - 2019-01-12 14:19:14 --> Config Class Initialized
INFO - 2019-01-12 14:19:14 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:19:14 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:19:14 --> Utf8 Class Initialized
INFO - 2019-01-12 14:19:14 --> URI Class Initialized
DEBUG - 2019-01-12 14:19:14 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:19:14 --> Utf8 Class Initialized
INFO - 2019-01-12 14:19:14 --> URI Class Initialized
INFO - 2019-01-12 14:19:14 --> Router Class Initialized
INFO - 2019-01-12 14:19:14 --> Router Class Initialized
INFO - 2019-01-12 14:19:14 --> Output Class Initialized
INFO - 2019-01-12 14:19:14 --> Security Class Initialized
INFO - 2019-01-12 14:19:14 --> Output Class Initialized
INFO - 2019-01-12 14:19:14 --> Security Class Initialized
DEBUG - 2019-01-12 14:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:19:14 --> Input Class Initialized
INFO - 2019-01-12 14:19:14 --> Language Class Initialized
DEBUG - 2019-01-12 14:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:19:14 --> Input Class Initialized
INFO - 2019-01-12 14:19:14 --> Language Class Initialized
INFO - 2019-01-12 14:19:14 --> Loader Class Initialized
INFO - 2019-01-12 14:19:14 --> Loader Class Initialized
INFO - 2019-01-12 14:19:14 --> Helper loaded: url_helper
INFO - 2019-01-12 14:19:14 --> Helper loaded: html_helper
INFO - 2019-01-12 14:19:14 --> Helper loaded: url_helper
INFO - 2019-01-12 14:19:14 --> Helper loaded: form_helper
INFO - 2019-01-12 14:19:14 --> Helper loaded: html_helper
INFO - 2019-01-12 14:19:14 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:19:14 --> Helper loaded: form_helper
INFO - 2019-01-12 14:19:14 --> Helper loaded: date_helper
INFO - 2019-01-12 14:19:14 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:19:14 --> Helper loaded: date_helper
INFO - 2019-01-12 14:19:14 --> Form Validation Class Initialized
INFO - 2019-01-12 14:19:14 --> Form Validation Class Initialized
INFO - 2019-01-12 14:19:14 --> Email Class Initialized
INFO - 2019-01-12 14:19:14 --> Email Class Initialized
DEBUG - 2019-01-12 14:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:19:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-01-12 14:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:19:15 --> Pagination Class Initialized
INFO - 2019-01-12 14:19:15 --> Database Driver Class Initialized
INFO - 2019-01-12 14:19:15 --> Database Driver Class Initialized
INFO - 2019-01-12 14:19:15 --> Controller Class Initialized
INFO - 2019-01-12 14:19:15 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-12 14:19:15 --> Final output sent to browser
DEBUG - 2019-01-12 14:19:15 --> Total execution time: 0.1078
INFO - 2019-01-12 14:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:19:15 --> Pagination Class Initialized
INFO - 2019-01-12 14:19:15 --> Database Driver Class Initialized
INFO - 2019-01-12 14:19:15 --> Database Driver Class Initialized
INFO - 2019-01-12 14:19:15 --> Controller Class Initialized
INFO - 2019-01-12 14:19:15 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-12 14:19:15 --> Final output sent to browser
DEBUG - 2019-01-12 14:19:15 --> Total execution time: 0.1187
INFO - 2019-01-12 14:19:35 --> Config Class Initialized
INFO - 2019-01-12 14:19:35 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:19:35 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:19:35 --> Utf8 Class Initialized
INFO - 2019-01-12 14:19:35 --> URI Class Initialized
INFO - 2019-01-12 14:19:35 --> Router Class Initialized
INFO - 2019-01-12 14:19:35 --> Output Class Initialized
INFO - 2019-01-12 14:19:35 --> Security Class Initialized
DEBUG - 2019-01-12 14:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:19:35 --> Input Class Initialized
INFO - 2019-01-12 14:19:35 --> Language Class Initialized
INFO - 2019-01-12 14:19:35 --> Loader Class Initialized
INFO - 2019-01-12 14:19:35 --> Helper loaded: url_helper
INFO - 2019-01-12 14:19:35 --> Helper loaded: html_helper
INFO - 2019-01-12 14:19:35 --> Helper loaded: form_helper
INFO - 2019-01-12 14:19:35 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:19:35 --> Helper loaded: date_helper
INFO - 2019-01-12 14:19:35 --> Form Validation Class Initialized
INFO - 2019-01-12 14:19:35 --> Email Class Initialized
DEBUG - 2019-01-12 14:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:19:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:19:35 --> Pagination Class Initialized
INFO - 2019-01-12 14:19:35 --> Database Driver Class Initialized
INFO - 2019-01-12 14:19:35 --> Database Driver Class Initialized
INFO - 2019-01-12 14:19:35 --> Controller Class Initialized
INFO - 2019-01-12 14:19:35 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-01-12 14:19:35 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/report.php
INFO - 2019-01-12 14:19:35 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-01-12 14:19:35 --> Final output sent to browser
DEBUG - 2019-01-12 14:19:35 --> Total execution time: 0.0867
INFO - 2019-01-12 14:19:36 --> Config Class Initialized
INFO - 2019-01-12 14:19:36 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:19:36 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:19:36 --> Utf8 Class Initialized
INFO - 2019-01-12 14:19:36 --> URI Class Initialized
INFO - 2019-01-12 14:19:36 --> Router Class Initialized
INFO - 2019-01-12 14:19:36 --> Output Class Initialized
INFO - 2019-01-12 14:19:36 --> Security Class Initialized
DEBUG - 2019-01-12 14:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:19:36 --> Input Class Initialized
INFO - 2019-01-12 14:19:36 --> Language Class Initialized
INFO - 2019-01-12 14:19:36 --> Loader Class Initialized
INFO - 2019-01-12 14:19:36 --> Helper loaded: url_helper
INFO - 2019-01-12 14:19:36 --> Helper loaded: html_helper
INFO - 2019-01-12 14:19:36 --> Helper loaded: form_helper
INFO - 2019-01-12 14:19:36 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:19:36 --> Helper loaded: date_helper
INFO - 2019-01-12 14:19:36 --> Form Validation Class Initialized
INFO - 2019-01-12 14:19:36 --> Email Class Initialized
DEBUG - 2019-01-12 14:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:19:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:19:36 --> Pagination Class Initialized
INFO - 2019-01-12 14:19:36 --> Database Driver Class Initialized
INFO - 2019-01-12 14:19:36 --> Database Driver Class Initialized
INFO - 2019-01-12 14:19:36 --> Controller Class Initialized
INFO - 2019-01-12 14:19:36 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-12 14:19:36 --> Final output sent to browser
DEBUG - 2019-01-12 14:19:36 --> Total execution time: 0.0716
INFO - 2019-01-12 14:19:36 --> Config Class Initialized
INFO - 2019-01-12 14:19:36 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:19:36 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:19:36 --> Utf8 Class Initialized
INFO - 2019-01-12 14:19:36 --> URI Class Initialized
INFO - 2019-01-12 14:19:36 --> Router Class Initialized
INFO - 2019-01-12 14:19:36 --> Output Class Initialized
INFO - 2019-01-12 14:19:36 --> Security Class Initialized
DEBUG - 2019-01-12 14:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:19:36 --> Input Class Initialized
INFO - 2019-01-12 14:19:36 --> Language Class Initialized
INFO - 2019-01-12 14:19:36 --> Loader Class Initialized
INFO - 2019-01-12 14:19:36 --> Helper loaded: url_helper
INFO - 2019-01-12 14:19:36 --> Helper loaded: html_helper
INFO - 2019-01-12 14:19:36 --> Helper loaded: form_helper
INFO - 2019-01-12 14:19:36 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:19:36 --> Helper loaded: date_helper
INFO - 2019-01-12 14:19:36 --> Form Validation Class Initialized
INFO - 2019-01-12 14:19:36 --> Email Class Initialized
DEBUG - 2019-01-12 14:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:19:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:19:36 --> Pagination Class Initialized
INFO - 2019-01-12 14:19:36 --> Database Driver Class Initialized
INFO - 2019-01-12 14:19:36 --> Database Driver Class Initialized
INFO - 2019-01-12 14:19:36 --> Controller Class Initialized
INFO - 2019-01-12 14:19:36 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-12 14:19:36 --> Final output sent to browser
DEBUG - 2019-01-12 14:19:36 --> Total execution time: 0.0625
INFO - 2019-01-12 14:19:46 --> Config Class Initialized
INFO - 2019-01-12 14:19:46 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:19:46 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:19:46 --> Utf8 Class Initialized
INFO - 2019-01-12 14:19:46 --> URI Class Initialized
INFO - 2019-01-12 14:19:46 --> Router Class Initialized
INFO - 2019-01-12 14:19:46 --> Output Class Initialized
INFO - 2019-01-12 14:19:46 --> Security Class Initialized
DEBUG - 2019-01-12 14:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:19:46 --> Input Class Initialized
INFO - 2019-01-12 14:19:46 --> Language Class Initialized
INFO - 2019-01-12 14:19:46 --> Loader Class Initialized
INFO - 2019-01-12 14:19:46 --> Helper loaded: url_helper
INFO - 2019-01-12 14:19:46 --> Helper loaded: html_helper
INFO - 2019-01-12 14:19:46 --> Helper loaded: form_helper
INFO - 2019-01-12 14:19:46 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:19:46 --> Helper loaded: date_helper
INFO - 2019-01-12 14:19:46 --> Form Validation Class Initialized
INFO - 2019-01-12 14:19:46 --> Email Class Initialized
DEBUG - 2019-01-12 14:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:19:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:19:46 --> Pagination Class Initialized
INFO - 2019-01-12 14:19:46 --> Database Driver Class Initialized
INFO - 2019-01-12 14:19:46 --> Database Driver Class Initialized
INFO - 2019-01-12 14:19:46 --> Controller Class Initialized
INFO - 2019-01-12 14:19:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_print.php
INFO - 2019-01-12 14:19:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/prints/report_police.php
INFO - 2019-01-12 14:19:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-01-12 14:19:46 --> Final output sent to browser
DEBUG - 2019-01-12 14:19:46 --> Total execution time: 0.3121
INFO - 2019-01-12 14:20:18 --> Config Class Initialized
INFO - 2019-01-12 14:20:18 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:20:18 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:20:18 --> Utf8 Class Initialized
INFO - 2019-01-12 14:20:18 --> URI Class Initialized
INFO - 2019-01-12 14:20:18 --> Router Class Initialized
INFO - 2019-01-12 14:20:18 --> Output Class Initialized
INFO - 2019-01-12 14:20:18 --> Security Class Initialized
DEBUG - 2019-01-12 14:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:20:18 --> Input Class Initialized
INFO - 2019-01-12 14:20:18 --> Language Class Initialized
INFO - 2019-01-12 14:20:18 --> Loader Class Initialized
INFO - 2019-01-12 14:20:18 --> Helper loaded: url_helper
INFO - 2019-01-12 14:20:18 --> Helper loaded: html_helper
INFO - 2019-01-12 14:20:18 --> Helper loaded: form_helper
INFO - 2019-01-12 14:20:18 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:20:18 --> Helper loaded: date_helper
INFO - 2019-01-12 14:20:18 --> Form Validation Class Initialized
INFO - 2019-01-12 14:20:18 --> Email Class Initialized
DEBUG - 2019-01-12 14:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:20:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:20:18 --> Pagination Class Initialized
INFO - 2019-01-12 14:20:18 --> Database Driver Class Initialized
INFO - 2019-01-12 14:20:18 --> Database Driver Class Initialized
INFO - 2019-01-12 14:20:18 --> Controller Class Initialized
INFO - 2019-01-12 14:20:18 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-01-12 14:20:18 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/report.php
INFO - 2019-01-12 14:20:18 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-01-12 14:20:18 --> Final output sent to browser
DEBUG - 2019-01-12 14:20:18 --> Total execution time: 0.0870
INFO - 2019-01-12 14:20:19 --> Config Class Initialized
INFO - 2019-01-12 14:20:19 --> Hooks Class Initialized
DEBUG - 2019-01-12 14:20:19 --> UTF-8 Support Enabled
INFO - 2019-01-12 14:20:19 --> Utf8 Class Initialized
INFO - 2019-01-12 14:20:19 --> URI Class Initialized
INFO - 2019-01-12 14:20:19 --> Router Class Initialized
INFO - 2019-01-12 14:20:19 --> Output Class Initialized
INFO - 2019-01-12 14:20:19 --> Security Class Initialized
DEBUG - 2019-01-12 14:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 14:20:19 --> Input Class Initialized
INFO - 2019-01-12 14:20:19 --> Language Class Initialized
INFO - 2019-01-12 14:20:19 --> Loader Class Initialized
INFO - 2019-01-12 14:20:19 --> Helper loaded: url_helper
INFO - 2019-01-12 14:20:19 --> Helper loaded: html_helper
INFO - 2019-01-12 14:20:19 --> Helper loaded: form_helper
INFO - 2019-01-12 14:20:19 --> Helper loaded: cookie_helper
INFO - 2019-01-12 14:20:19 --> Helper loaded: date_helper
INFO - 2019-01-12 14:20:19 --> Form Validation Class Initialized
INFO - 2019-01-12 14:20:19 --> Email Class Initialized
DEBUG - 2019-01-12 14:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 14:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 14:20:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 14:20:19 --> Pagination Class Initialized
INFO - 2019-01-12 14:20:19 --> Database Driver Class Initialized
INFO - 2019-01-12 14:20:19 --> Database Driver Class Initialized
INFO - 2019-01-12 14:20:19 --> Controller Class Initialized
INFO - 2019-01-12 14:20:19 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-12 14:20:19 --> Final output sent to browser
DEBUG - 2019-01-12 14:20:19 --> Total execution time: 0.0757
INFO - 2019-01-12 17:45:56 --> Config Class Initialized
INFO - 2019-01-12 17:45:56 --> Hooks Class Initialized
DEBUG - 2019-01-12 17:45:56 --> UTF-8 Support Enabled
INFO - 2019-01-12 17:45:56 --> Utf8 Class Initialized
INFO - 2019-01-12 17:45:57 --> URI Class Initialized
INFO - 2019-01-12 17:45:58 --> Router Class Initialized
INFO - 2019-01-12 17:45:58 --> Output Class Initialized
INFO - 2019-01-12 17:45:58 --> Security Class Initialized
DEBUG - 2019-01-12 17:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-12 17:45:58 --> Input Class Initialized
INFO - 2019-01-12 17:45:58 --> Language Class Initialized
INFO - 2019-01-12 17:45:58 --> Loader Class Initialized
INFO - 2019-01-12 17:45:59 --> Helper loaded: url_helper
INFO - 2019-01-12 17:45:59 --> Helper loaded: html_helper
INFO - 2019-01-12 17:45:59 --> Helper loaded: form_helper
INFO - 2019-01-12 17:45:59 --> Helper loaded: cookie_helper
INFO - 2019-01-12 17:45:59 --> Helper loaded: date_helper
INFO - 2019-01-12 17:45:59 --> Form Validation Class Initialized
INFO - 2019-01-12 17:45:59 --> Email Class Initialized
DEBUG - 2019-01-12 17:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-12 17:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-12 17:46:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-12 17:46:00 --> Pagination Class Initialized
INFO - 2019-01-12 17:46:00 --> Database Driver Class Initialized
INFO - 2019-01-12 17:46:00 --> Database Driver Class Initialized
INFO - 2019-01-12 17:46:02 --> Language file loaded: language/english/db_lang.php
