<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2004-01-01 00:02:14 --> Config Class Initialized
INFO - 2004-01-01 00:02:14 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:02:14 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:02:14 --> Utf8 Class Initialized
INFO - 2004-01-01 00:02:14 --> URI Class Initialized
INFO - 2004-01-01 00:02:15 --> Router Class Initialized
INFO - 2004-01-01 00:02:15 --> Output Class Initialized
INFO - 2004-01-01 00:02:15 --> Security Class Initialized
DEBUG - 2004-01-01 00:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:02:15 --> Input Class Initialized
INFO - 2004-01-01 00:02:15 --> Language Class Initialized
INFO - 2004-01-01 00:02:15 --> Loader Class Initialized
INFO - 2004-01-01 00:02:15 --> Helper loaded: url_helper
INFO - 2004-01-01 00:02:15 --> Helper loaded: html_helper
INFO - 2004-01-01 00:02:15 --> Helper loaded: form_helper
INFO - 2004-01-01 00:02:15 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:02:15 --> Helper loaded: date_helper
INFO - 2004-01-01 00:02:16 --> Form Validation Class Initialized
INFO - 2004-01-01 00:02:16 --> Email Class Initialized
DEBUG - 2004-01-01 00:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:02:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:02:16 --> Pagination Class Initialized
INFO - 2004-01-01 00:02:17 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:17 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:18 --> Controller Class Initialized
INFO - 2004-01-01 00:02:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2004-01-01 00:02:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2004-01-01 00:02:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2004-01-01 00:02:18 --> Final output sent to browser
DEBUG - 2004-01-01 00:02:18 --> Total execution time: 4.6644
INFO - 2004-01-01 00:02:22 --> Config Class Initialized
INFO - 2004-01-01 00:02:22 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:02:22 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:02:22 --> Utf8 Class Initialized
INFO - 2004-01-01 00:02:22 --> URI Class Initialized
INFO - 2004-01-01 00:02:22 --> Router Class Initialized
INFO - 2004-01-01 00:02:22 --> Output Class Initialized
INFO - 2004-01-01 00:02:22 --> Config Class Initialized
INFO - 2004-01-01 00:02:22 --> Hooks Class Initialized
INFO - 2004-01-01 00:02:22 --> Security Class Initialized
DEBUG - 2004-01-01 00:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:02:22 --> Input Class Initialized
INFO - 2004-01-01 00:02:22 --> Language Class Initialized
DEBUG - 2004-01-01 00:02:22 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:02:22 --> Utf8 Class Initialized
INFO - 2004-01-01 00:02:22 --> URI Class Initialized
INFO - 2004-01-01 00:02:22 --> Router Class Initialized
INFO - 2004-01-01 00:02:22 --> Loader Class Initialized
INFO - 2004-01-01 00:02:22 --> Output Class Initialized
INFO - 2004-01-01 00:02:22 --> Helper loaded: url_helper
INFO - 2004-01-01 00:02:22 --> Helper loaded: html_helper
INFO - 2004-01-01 00:02:22 --> Helper loaded: form_helper
INFO - 2004-01-01 00:02:22 --> Security Class Initialized
INFO - 2004-01-01 00:02:22 --> Helper loaded: cookie_helper
DEBUG - 2004-01-01 00:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:02:22 --> Helper loaded: date_helper
INFO - 2004-01-01 00:02:22 --> Input Class Initialized
INFO - 2004-01-01 00:02:22 --> Language Class Initialized
INFO - 2004-01-01 00:02:22 --> Form Validation Class Initialized
INFO - 2004-01-01 00:02:22 --> Email Class Initialized
INFO - 2004-01-01 00:02:22 --> Loader Class Initialized
DEBUG - 2004-01-01 00:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:02:22 --> Helper loaded: url_helper
INFO - 2004-01-01 00:02:22 --> Helper loaded: html_helper
INFO - 2004-01-01 00:02:22 --> Helper loaded: form_helper
INFO - 2004-01-01 00:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:02:22 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:02:22 --> Helper loaded: date_helper
INFO - 2004-01-01 00:02:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:02:22 --> Pagination Class Initialized
INFO - 2004-01-01 00:02:22 --> Form Validation Class Initialized
INFO - 2004-01-01 00:02:22 --> Email Class Initialized
INFO - 2004-01-01 00:02:22 --> Database Driver Class Initialized
DEBUG - 2004-01-01 00:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:02:22 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:22 --> Controller Class Initialized
INFO - 2004-01-01 00:02:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:02:22 --> Final output sent to browser
DEBUG - 2004-01-01 00:02:22 --> Total execution time: 0.2184
INFO - 2004-01-01 00:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:02:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:02:22 --> Pagination Class Initialized
INFO - 2004-01-01 00:02:22 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:22 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:22 --> Controller Class Initialized
INFO - 2004-01-01 00:02:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:02:22 --> Final output sent to browser
DEBUG - 2004-01-01 00:02:22 --> Total execution time: 0.2964
INFO - 2004-01-01 00:02:36 --> Config Class Initialized
INFO - 2004-01-01 00:02:36 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:02:36 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:02:36 --> Utf8 Class Initialized
INFO - 2004-01-01 00:02:36 --> URI Class Initialized
INFO - 2004-01-01 00:02:36 --> Router Class Initialized
INFO - 2004-01-01 00:02:36 --> Output Class Initialized
INFO - 2004-01-01 00:02:36 --> Security Class Initialized
DEBUG - 2004-01-01 00:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:02:36 --> Input Class Initialized
INFO - 2004-01-01 00:02:36 --> Language Class Initialized
INFO - 2004-01-01 00:02:36 --> Loader Class Initialized
INFO - 2004-01-01 00:02:36 --> Helper loaded: url_helper
INFO - 2004-01-01 00:02:36 --> Helper loaded: html_helper
INFO - 2004-01-01 00:02:36 --> Helper loaded: form_helper
INFO - 2004-01-01 00:02:36 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:02:36 --> Helper loaded: date_helper
INFO - 2004-01-01 00:02:36 --> Form Validation Class Initialized
INFO - 2004-01-01 00:02:36 --> Email Class Initialized
DEBUG - 2004-01-01 00:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:02:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:02:36 --> Pagination Class Initialized
INFO - 2004-01-01 00:02:36 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:36 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:36 --> Controller Class Initialized
INFO - 2004-01-01 00:02:36 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:02:36 --> Final output sent to browser
DEBUG - 2004-01-01 00:02:36 --> Total execution time: 0.2028
INFO - 2004-01-01 00:02:38 --> Config Class Initialized
INFO - 2004-01-01 00:02:38 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:02:38 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:02:38 --> Utf8 Class Initialized
INFO - 2004-01-01 00:02:38 --> URI Class Initialized
INFO - 2004-01-01 00:02:38 --> Router Class Initialized
INFO - 2004-01-01 00:02:38 --> Output Class Initialized
INFO - 2004-01-01 00:02:38 --> Security Class Initialized
DEBUG - 2004-01-01 00:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:02:38 --> Input Class Initialized
INFO - 2004-01-01 00:02:38 --> Language Class Initialized
INFO - 2004-01-01 00:02:38 --> Loader Class Initialized
INFO - 2004-01-01 00:02:38 --> Helper loaded: url_helper
INFO - 2004-01-01 00:02:38 --> Helper loaded: html_helper
INFO - 2004-01-01 00:02:38 --> Helper loaded: form_helper
INFO - 2004-01-01 00:02:38 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:02:38 --> Helper loaded: date_helper
INFO - 2004-01-01 00:02:38 --> Form Validation Class Initialized
INFO - 2004-01-01 00:02:38 --> Email Class Initialized
DEBUG - 2004-01-01 00:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:02:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:02:38 --> Pagination Class Initialized
INFO - 2004-01-01 00:02:38 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:38 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:38 --> Controller Class Initialized
INFO - 2004-01-01 00:02:38 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2004-01-01 00:02:38 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2004-01-01 00:02:38 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2004-01-01 00:02:38 --> Final output sent to browser
DEBUG - 2004-01-01 00:02:38 --> Total execution time: 0.1872
INFO - 2004-01-01 00:02:38 --> Config Class Initialized
INFO - 2004-01-01 00:02:38 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:02:39 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:02:39 --> Utf8 Class Initialized
INFO - 2004-01-01 00:02:39 --> URI Class Initialized
INFO - 2004-01-01 00:02:39 --> Router Class Initialized
INFO - 2004-01-01 00:02:39 --> Output Class Initialized
INFO - 2004-01-01 00:02:39 --> Security Class Initialized
DEBUG - 2004-01-01 00:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:02:39 --> Input Class Initialized
INFO - 2004-01-01 00:02:39 --> Language Class Initialized
INFO - 2004-01-01 00:02:39 --> Loader Class Initialized
INFO - 2004-01-01 00:02:39 --> Helper loaded: url_helper
INFO - 2004-01-01 00:02:39 --> Helper loaded: html_helper
INFO - 2004-01-01 00:02:39 --> Helper loaded: form_helper
INFO - 2004-01-01 00:02:39 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:02:39 --> Helper loaded: date_helper
INFO - 2004-01-01 00:02:39 --> Form Validation Class Initialized
INFO - 2004-01-01 00:02:39 --> Email Class Initialized
DEBUG - 2004-01-01 00:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:02:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:02:39 --> Pagination Class Initialized
INFO - 2004-01-01 00:02:39 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:39 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:39 --> Config Class Initialized
INFO - 2004-01-01 00:02:39 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:02:39 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:02:39 --> Utf8 Class Initialized
INFO - 2004-01-01 00:02:39 --> URI Class Initialized
INFO - 2004-01-01 00:02:39 --> Router Class Initialized
INFO - 2004-01-01 00:02:39 --> Output Class Initialized
INFO - 2004-01-01 00:02:39 --> Security Class Initialized
INFO - 2004-01-01 00:02:39 --> Controller Class Initialized
DEBUG - 2004-01-01 00:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:02:39 --> Input Class Initialized
INFO - 2004-01-01 00:02:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:02:39 --> Final output sent to browser
DEBUG - 2004-01-01 00:02:39 --> Total execution time: 0.2184
INFO - 2004-01-01 00:02:39 --> Language Class Initialized
INFO - 2004-01-01 00:02:39 --> Loader Class Initialized
INFO - 2004-01-01 00:02:39 --> Helper loaded: url_helper
INFO - 2004-01-01 00:02:39 --> Helper loaded: html_helper
INFO - 2004-01-01 00:02:39 --> Helper loaded: form_helper
INFO - 2004-01-01 00:02:39 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:02:39 --> Helper loaded: date_helper
INFO - 2004-01-01 00:02:39 --> Form Validation Class Initialized
INFO - 2004-01-01 00:02:39 --> Email Class Initialized
DEBUG - 2004-01-01 00:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:02:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:02:39 --> Pagination Class Initialized
INFO - 2004-01-01 00:02:39 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:39 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:39 --> Controller Class Initialized
INFO - 2004-01-01 00:02:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:02:39 --> Final output sent to browser
DEBUG - 2004-01-01 00:02:39 --> Total execution time: 0.2652
INFO - 2004-01-01 00:02:40 --> Config Class Initialized
INFO - 2004-01-01 00:02:40 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:02:40 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:02:40 --> Utf8 Class Initialized
INFO - 2004-01-01 00:02:40 --> URI Class Initialized
INFO - 2004-01-01 00:02:40 --> Router Class Initialized
INFO - 2004-01-01 00:02:40 --> Output Class Initialized
INFO - 2004-01-01 00:02:40 --> Security Class Initialized
DEBUG - 2004-01-01 00:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:02:40 --> Input Class Initialized
INFO - 2004-01-01 00:02:40 --> Language Class Initialized
INFO - 2004-01-01 00:02:40 --> Loader Class Initialized
INFO - 2004-01-01 00:02:40 --> Helper loaded: url_helper
INFO - 2004-01-01 00:02:40 --> Helper loaded: html_helper
INFO - 2004-01-01 00:02:40 --> Helper loaded: form_helper
INFO - 2004-01-01 00:02:40 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:02:40 --> Helper loaded: date_helper
INFO - 2004-01-01 00:02:40 --> Form Validation Class Initialized
INFO - 2004-01-01 00:02:40 --> Email Class Initialized
DEBUG - 2004-01-01 00:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:02:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:02:40 --> Pagination Class Initialized
INFO - 2004-01-01 00:02:40 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:40 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:40 --> Controller Class Initialized
INFO - 2004-01-01 00:02:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2004-01-01 00:02:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2004-01-01 00:02:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/guest.php
INFO - 2004-01-01 00:02:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2004-01-01 00:02:41 --> Final output sent to browser
DEBUG - 2004-01-01 00:02:41 --> Total execution time: 0.4836
INFO - 2004-01-01 00:02:41 --> Config Class Initialized
INFO - 2004-01-01 00:02:41 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:02:41 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:02:41 --> Utf8 Class Initialized
INFO - 2004-01-01 00:02:41 --> URI Class Initialized
INFO - 2004-01-01 00:02:41 --> Config Class Initialized
INFO - 2004-01-01 00:02:41 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:02:41 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:02:41 --> Utf8 Class Initialized
INFO - 2004-01-01 00:02:41 --> URI Class Initialized
INFO - 2004-01-01 00:02:41 --> Router Class Initialized
INFO - 2004-01-01 00:02:41 --> Output Class Initialized
INFO - 2004-01-01 00:02:41 --> Security Class Initialized
INFO - 2004-01-01 00:02:41 --> Router Class Initialized
INFO - 2004-01-01 00:02:41 --> Output Class Initialized
INFO - 2004-01-01 00:02:41 --> Security Class Initialized
DEBUG - 2004-01-01 00:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:02:41 --> Input Class Initialized
INFO - 2004-01-01 00:02:41 --> Language Class Initialized
INFO - 2004-01-01 00:02:41 --> Loader Class Initialized
INFO - 2004-01-01 00:02:41 --> Helper loaded: url_helper
INFO - 2004-01-01 00:02:41 --> Helper loaded: html_helper
INFO - 2004-01-01 00:02:41 --> Helper loaded: form_helper
INFO - 2004-01-01 00:02:41 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:02:41 --> Helper loaded: date_helper
INFO - 2004-01-01 00:02:41 --> Form Validation Class Initialized
DEBUG - 2004-01-01 00:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:02:41 --> Input Class Initialized
INFO - 2004-01-01 00:02:41 --> Language Class Initialized
INFO - 2004-01-01 00:02:41 --> Loader Class Initialized
INFO - 2004-01-01 00:02:41 --> Helper loaded: url_helper
INFO - 2004-01-01 00:02:41 --> Helper loaded: html_helper
INFO - 2004-01-01 00:02:41 --> Helper loaded: form_helper
INFO - 2004-01-01 00:02:41 --> Email Class Initialized
DEBUG - 2004-01-01 00:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:02:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:02:41 --> Pagination Class Initialized
INFO - 2004-01-01 00:02:41 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:02:41 --> Helper loaded: date_helper
INFO - 2004-01-01 00:02:41 --> Form Validation Class Initialized
INFO - 2004-01-01 00:02:41 --> Email Class Initialized
DEBUG - 2004-01-01 00:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:02:41 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:41 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:41 --> Controller Class Initialized
INFO - 2004-01-01 00:02:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:02:41 --> Final output sent to browser
DEBUG - 2004-01-01 00:02:41 --> Total execution time: 0.3588
INFO - 2004-01-01 00:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:02:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:02:41 --> Pagination Class Initialized
INFO - 2004-01-01 00:02:41 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:41 --> Database Driver Class Initialized
INFO - 2004-01-01 00:02:42 --> Controller Class Initialized
INFO - 2004-01-01 00:02:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:02:42 --> Final output sent to browser
DEBUG - 2004-01-01 00:02:42 --> Total execution time: 0.7176
INFO - 2004-01-01 00:03:02 --> Config Class Initialized
INFO - 2004-01-01 00:03:02 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:02 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:02 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:02 --> URI Class Initialized
INFO - 2004-01-01 00:03:02 --> Router Class Initialized
INFO - 2004-01-01 00:03:02 --> Output Class Initialized
INFO - 2004-01-01 00:03:02 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:02 --> Input Class Initialized
INFO - 2004-01-01 00:03:02 --> Language Class Initialized
INFO - 2004-01-01 00:03:02 --> Loader Class Initialized
INFO - 2004-01-01 00:03:02 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:02 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:02 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:02 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:02 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:02 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:02 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:02 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:02 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:02 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:02 --> Controller Class Initialized
INFO - 2004-01-01 00:03:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2004-01-01 00:03:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2004-01-01 00:03:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2004-01-01 00:03:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2004-01-01 00:03:02 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:02 --> Total execution time: 0.2964
INFO - 2004-01-01 00:03:03 --> Config Class Initialized
INFO - 2004-01-01 00:03:03 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:03 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:03 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:03 --> URI Class Initialized
INFO - 2004-01-01 00:03:03 --> Router Class Initialized
INFO - 2004-01-01 00:03:03 --> Output Class Initialized
INFO - 2004-01-01 00:03:03 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:03 --> Input Class Initialized
INFO - 2004-01-01 00:03:03 --> Language Class Initialized
INFO - 2004-01-01 00:03:03 --> Loader Class Initialized
INFO - 2004-01-01 00:03:03 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:03 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:03 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:03 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:03 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:03 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:03 --> Config Class Initialized
INFO - 2004-01-01 00:03:03 --> Hooks Class Initialized
INFO - 2004-01-01 00:03:03 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:03 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:03 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:03 --> URI Class Initialized
DEBUG - 2004-01-01 00:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:03 --> Router Class Initialized
INFO - 2004-01-01 00:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:03 --> Output Class Initialized
INFO - 2004-01-01 00:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:03 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:03 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:03 --> Input Class Initialized
INFO - 2004-01-01 00:03:03 --> Language Class Initialized
INFO - 2004-01-01 00:03:03 --> Loader Class Initialized
INFO - 2004-01-01 00:03:03 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:03 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:03 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:03 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:03 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:03 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:03 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:03 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:03 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:03 --> Controller Class Initialized
INFO - 2004-01-01 00:03:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:03:03 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:03 --> Total execution time: 0.2496
INFO - 2004-01-01 00:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:03 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:03 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:03 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:03 --> Controller Class Initialized
INFO - 2004-01-01 00:03:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:03:03 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:03 --> Total execution time: 0.2964
INFO - 2004-01-01 00:03:09 --> Config Class Initialized
INFO - 2004-01-01 00:03:09 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:09 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:09 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:09 --> URI Class Initialized
INFO - 2004-01-01 00:03:09 --> Router Class Initialized
INFO - 2004-01-01 00:03:09 --> Output Class Initialized
INFO - 2004-01-01 00:03:09 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:09 --> Input Class Initialized
INFO - 2004-01-01 00:03:09 --> Language Class Initialized
INFO - 2004-01-01 00:03:09 --> Loader Class Initialized
INFO - 2004-01-01 00:03:09 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:09 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:09 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:09 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:09 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:09 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:09 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:09 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:09 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:09 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:09 --> Controller Class Initialized
INFO - 2004-01-01 00:03:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:03:09 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:09 --> Total execution time: 0.1716
INFO - 2004-01-01 00:03:11 --> Config Class Initialized
INFO - 2004-01-01 00:03:11 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:11 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:11 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:11 --> URI Class Initialized
INFO - 2004-01-01 00:03:11 --> Router Class Initialized
INFO - 2004-01-01 00:03:11 --> Output Class Initialized
INFO - 2004-01-01 00:03:11 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:11 --> Input Class Initialized
INFO - 2004-01-01 00:03:11 --> Language Class Initialized
INFO - 2004-01-01 00:03:11 --> Loader Class Initialized
INFO - 2004-01-01 00:03:11 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:11 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:11 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:11 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:11 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:11 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:11 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:11 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:11 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:11 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:11 --> Controller Class Initialized
INFO - 2004-01-01 00:03:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:03:11 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:11 --> Total execution time: 0.2184
INFO - 2004-01-01 00:03:12 --> Config Class Initialized
INFO - 2004-01-01 00:03:12 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:12 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:12 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:12 --> URI Class Initialized
INFO - 2004-01-01 00:03:12 --> Router Class Initialized
INFO - 2004-01-01 00:03:12 --> Output Class Initialized
INFO - 2004-01-01 00:03:12 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:12 --> Input Class Initialized
INFO - 2004-01-01 00:03:12 --> Language Class Initialized
INFO - 2004-01-01 00:03:12 --> Loader Class Initialized
INFO - 2004-01-01 00:03:12 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:12 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:12 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:12 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:12 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:12 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:12 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:12 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:12 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:12 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:12 --> Controller Class Initialized
INFO - 2004-01-01 00:03:12 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2004-01-01 00:03:12 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/ledger.php
INFO - 2004-01-01 00:03:12 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2004-01-01 00:03:12 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:12 --> Total execution time: 0.2340
INFO - 2004-01-01 00:03:13 --> Config Class Initialized
INFO - 2004-01-01 00:03:13 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:13 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:13 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:13 --> URI Class Initialized
INFO - 2004-01-01 00:03:13 --> Router Class Initialized
INFO - 2004-01-01 00:03:13 --> Output Class Initialized
INFO - 2004-01-01 00:03:13 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:13 --> Input Class Initialized
INFO - 2004-01-01 00:03:13 --> Language Class Initialized
INFO - 2004-01-01 00:03:13 --> Loader Class Initialized
INFO - 2004-01-01 00:03:13 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:13 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:13 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:13 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:13 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:13 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:13 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:13 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:13 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:13 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:13 --> Config Class Initialized
INFO - 2004-01-01 00:03:13 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:13 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:13 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:13 --> URI Class Initialized
INFO - 2004-01-01 00:03:13 --> Router Class Initialized
INFO - 2004-01-01 00:03:13 --> Output Class Initialized
INFO - 2004-01-01 00:03:13 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:13 --> Input Class Initialized
INFO - 2004-01-01 00:03:13 --> Language Class Initialized
INFO - 2004-01-01 00:03:13 --> Loader Class Initialized
INFO - 2004-01-01 00:03:13 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:13 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:13 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:13 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:13 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:13 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:13 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:13 --> Controller Class Initialized
INFO - 2004-01-01 00:03:13 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:03:13 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:13 --> Total execution time: 0.6396
INFO - 2004-01-01 00:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:13 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:13 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:13 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:13 --> Controller Class Initialized
INFO - 2004-01-01 00:03:13 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:03:13 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:13 --> Total execution time: 0.3120
INFO - 2004-01-01 00:03:17 --> Config Class Initialized
INFO - 2004-01-01 00:03:17 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:17 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:17 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:17 --> URI Class Initialized
INFO - 2004-01-01 00:03:17 --> Router Class Initialized
INFO - 2004-01-01 00:03:17 --> Output Class Initialized
INFO - 2004-01-01 00:03:17 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:17 --> Input Class Initialized
INFO - 2004-01-01 00:03:17 --> Language Class Initialized
INFO - 2004-01-01 00:03:17 --> Loader Class Initialized
INFO - 2004-01-01 00:03:17 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:17 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:17 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:17 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:17 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:17 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:17 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:17 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:17 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:17 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:17 --> Controller Class Initialized
INFO - 2004-01-01 00:03:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2004-01-01 00:03:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/ledger.php
INFO - 2004-01-01 00:03:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2004-01-01 00:03:18 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:18 --> Total execution time: 0.1716
INFO - 2004-01-01 00:03:18 --> Config Class Initialized
INFO - 2004-01-01 00:03:18 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:18 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:18 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:18 --> URI Class Initialized
INFO - 2004-01-01 00:03:18 --> Router Class Initialized
INFO - 2004-01-01 00:03:18 --> Output Class Initialized
INFO - 2004-01-01 00:03:18 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:18 --> Input Class Initialized
INFO - 2004-01-01 00:03:18 --> Language Class Initialized
INFO - 2004-01-01 00:03:18 --> Loader Class Initialized
INFO - 2004-01-01 00:03:18 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:18 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:18 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:18 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:18 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:18 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:18 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:18 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:18 --> Config Class Initialized
INFO - 2004-01-01 00:03:18 --> Hooks Class Initialized
INFO - 2004-01-01 00:03:18 --> Database Driver Class Initialized
DEBUG - 2004-01-01 00:03:18 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:18 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:18 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:18 --> URI Class Initialized
INFO - 2004-01-01 00:03:18 --> Router Class Initialized
INFO - 2004-01-01 00:03:18 --> Output Class Initialized
INFO - 2004-01-01 00:03:18 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:18 --> Input Class Initialized
INFO - 2004-01-01 00:03:18 --> Language Class Initialized
INFO - 2004-01-01 00:03:18 --> Loader Class Initialized
INFO - 2004-01-01 00:03:18 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:18 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:18 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:18 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:18 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:18 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:18 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:18 --> Controller Class Initialized
INFO - 2004-01-01 00:03:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:03:18 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:18 --> Total execution time: 0.2652
INFO - 2004-01-01 00:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:18 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:18 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:18 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:18 --> Controller Class Initialized
INFO - 2004-01-01 00:03:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:03:18 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:18 --> Total execution time: 0.2964
INFO - 2004-01-01 00:03:19 --> Config Class Initialized
INFO - 2004-01-01 00:03:19 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:19 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:19 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:19 --> URI Class Initialized
INFO - 2004-01-01 00:03:19 --> Router Class Initialized
INFO - 2004-01-01 00:03:19 --> Output Class Initialized
INFO - 2004-01-01 00:03:19 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:19 --> Input Class Initialized
INFO - 2004-01-01 00:03:19 --> Language Class Initialized
INFO - 2004-01-01 00:03:19 --> Loader Class Initialized
INFO - 2004-01-01 00:03:19 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:19 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:19 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:19 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:19 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:19 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:19 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:19 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:19 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:19 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:19 --> Config Class Initialized
INFO - 2004-01-01 00:03:19 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:19 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:19 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:19 --> Controller Class Initialized
INFO - 2004-01-01 00:03:19 --> URI Class Initialized
INFO - 2004-01-01 00:03:20 --> Router Class Initialized
INFO - 2004-01-01 00:03:20 --> Output Class Initialized
INFO - 2004-01-01 00:03:20 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:20 --> Input Class Initialized
INFO - 2004-01-01 00:03:20 --> Language Class Initialized
INFO - 2004-01-01 00:03:20 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:03:20 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:20 --> Total execution time: 0.2028
INFO - 2004-01-01 00:03:20 --> Loader Class Initialized
INFO - 2004-01-01 00:03:20 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:20 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:20 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:20 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:20 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:20 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:20 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:20 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:20 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:20 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:20 --> Controller Class Initialized
INFO - 2004-01-01 00:03:20 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:03:20 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:20 --> Total execution time: 0.1872
INFO - 2004-01-01 00:03:25 --> Config Class Initialized
INFO - 2004-01-01 00:03:25 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:25 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:25 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:25 --> URI Class Initialized
INFO - 2004-01-01 00:03:25 --> Router Class Initialized
INFO - 2004-01-01 00:03:25 --> Output Class Initialized
INFO - 2004-01-01 00:03:25 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:25 --> Input Class Initialized
INFO - 2004-01-01 00:03:25 --> Language Class Initialized
INFO - 2004-01-01 00:03:25 --> Loader Class Initialized
INFO - 2004-01-01 00:03:25 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:25 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:25 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:25 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:25 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:25 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:25 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:25 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:25 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:25 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:25 --> Controller Class Initialized
INFO - 2004-01-01 00:03:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2004-01-01 00:03:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2004-01-01 00:03:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2004-01-01 00:03:25 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:25 --> Total execution time: 0.1872
INFO - 2004-01-01 00:03:25 --> Config Class Initialized
INFO - 2004-01-01 00:03:25 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:25 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:25 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:25 --> URI Class Initialized
INFO - 2004-01-01 00:03:25 --> Router Class Initialized
INFO - 2004-01-01 00:03:25 --> Output Class Initialized
INFO - 2004-01-01 00:03:25 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:25 --> Input Class Initialized
INFO - 2004-01-01 00:03:25 --> Language Class Initialized
INFO - 2004-01-01 00:03:25 --> Loader Class Initialized
INFO - 2004-01-01 00:03:25 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:25 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:25 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:25 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:25 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:25 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:25 --> Email Class Initialized
INFO - 2004-01-01 00:03:25 --> Config Class Initialized
INFO - 2004-01-01 00:03:25 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:25 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:25 --> Utf8 Class Initialized
DEBUG - 2004-01-01 00:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:25 --> URI Class Initialized
INFO - 2004-01-01 00:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:25 --> Router Class Initialized
INFO - 2004-01-01 00:03:25 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:25 --> Output Class Initialized
INFO - 2004-01-01 00:03:25 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:25 --> Input Class Initialized
INFO - 2004-01-01 00:03:25 --> Language Class Initialized
INFO - 2004-01-01 00:03:25 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:25 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:25 --> Loader Class Initialized
INFO - 2004-01-01 00:03:25 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:25 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:25 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:25 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:25 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:25 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:25 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:25 --> Controller Class Initialized
INFO - 2004-01-01 00:03:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:03:25 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:25 --> Total execution time: 0.2496
INFO - 2004-01-01 00:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:25 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:25 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:26 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:26 --> Controller Class Initialized
INFO - 2004-01-01 00:03:26 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:03:26 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:26 --> Total execution time: 0.2496
INFO - 2004-01-01 00:03:44 --> Config Class Initialized
INFO - 2004-01-01 00:03:44 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:44 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:44 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:44 --> URI Class Initialized
INFO - 2004-01-01 00:03:44 --> Router Class Initialized
INFO - 2004-01-01 00:03:44 --> Output Class Initialized
INFO - 2004-01-01 00:03:44 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:44 --> Input Class Initialized
INFO - 2004-01-01 00:03:44 --> Language Class Initialized
INFO - 2004-01-01 00:03:44 --> Loader Class Initialized
INFO - 2004-01-01 00:03:44 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:44 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:44 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:44 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:44 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:44 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:44 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:44 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:44 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:44 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:44 --> Controller Class Initialized
INFO - 2004-01-01 00:03:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:03:44 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:44 --> Total execution time: 0.2028
INFO - 2004-01-01 00:03:50 --> Config Class Initialized
INFO - 2004-01-01 00:03:50 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:50 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:50 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:50 --> URI Class Initialized
INFO - 2004-01-01 00:03:50 --> Router Class Initialized
INFO - 2004-01-01 00:03:50 --> Output Class Initialized
INFO - 2004-01-01 00:03:50 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:50 --> Input Class Initialized
INFO - 2004-01-01 00:03:50 --> Language Class Initialized
INFO - 2004-01-01 00:03:50 --> Loader Class Initialized
INFO - 2004-01-01 00:03:50 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:50 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:50 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:50 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:50 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:50 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:50 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:50 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:50 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:50 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:50 --> Controller Class Initialized
INFO - 2004-01-01 00:03:50 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:03:50 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:50 --> Total execution time: 0.1872
INFO - 2004-01-01 00:03:58 --> Config Class Initialized
INFO - 2004-01-01 00:03:58 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:58 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:58 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:58 --> URI Class Initialized
INFO - 2004-01-01 00:03:58 --> Router Class Initialized
INFO - 2004-01-01 00:03:58 --> Output Class Initialized
INFO - 2004-01-01 00:03:58 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:58 --> Input Class Initialized
INFO - 2004-01-01 00:03:58 --> Language Class Initialized
INFO - 2004-01-01 00:03:58 --> Loader Class Initialized
INFO - 2004-01-01 00:03:58 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:58 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:58 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:58 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:58 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:58 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:58 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:58 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:58 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:58 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:58 --> Controller Class Initialized
INFO - 2004-01-01 00:03:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2004-01-01 00:03:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation_group.php
INFO - 2004-01-01 00:03:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2004-01-01 00:03:58 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:58 --> Total execution time: 0.2340
INFO - 2004-01-01 00:03:58 --> Config Class Initialized
INFO - 2004-01-01 00:03:58 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:58 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:58 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:58 --> URI Class Initialized
INFO - 2004-01-01 00:03:58 --> Router Class Initialized
INFO - 2004-01-01 00:03:58 --> Output Class Initialized
INFO - 2004-01-01 00:03:58 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:58 --> Input Class Initialized
INFO - 2004-01-01 00:03:58 --> Language Class Initialized
INFO - 2004-01-01 00:03:58 --> Loader Class Initialized
INFO - 2004-01-01 00:03:58 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:58 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:58 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:58 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:58 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:58 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:59 --> Email Class Initialized
INFO - 2004-01-01 00:03:59 --> Config Class Initialized
INFO - 2004-01-01 00:03:59 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2004-01-01 00:03:59 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:03:59 --> Utf8 Class Initialized
INFO - 2004-01-01 00:03:59 --> URI Class Initialized
INFO - 2004-01-01 00:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:59 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:59 --> Router Class Initialized
INFO - 2004-01-01 00:03:59 --> Output Class Initialized
INFO - 2004-01-01 00:03:59 --> Security Class Initialized
DEBUG - 2004-01-01 00:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:03:59 --> Input Class Initialized
INFO - 2004-01-01 00:03:59 --> Language Class Initialized
INFO - 2004-01-01 00:03:59 --> Loader Class Initialized
INFO - 2004-01-01 00:03:59 --> Helper loaded: url_helper
INFO - 2004-01-01 00:03:59 --> Helper loaded: html_helper
INFO - 2004-01-01 00:03:59 --> Helper loaded: form_helper
INFO - 2004-01-01 00:03:59 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:03:59 --> Helper loaded: date_helper
INFO - 2004-01-01 00:03:59 --> Form Validation Class Initialized
INFO - 2004-01-01 00:03:59 --> Email Class Initialized
DEBUG - 2004-01-01 00:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:03:59 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:59 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:59 --> Controller Class Initialized
INFO - 2004-01-01 00:03:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:03:59 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:59 --> Total execution time: 0.2496
INFO - 2004-01-01 00:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:03:59 --> Pagination Class Initialized
INFO - 2004-01-01 00:03:59 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:59 --> Database Driver Class Initialized
INFO - 2004-01-01 00:03:59 --> Controller Class Initialized
INFO - 2004-01-01 00:03:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:03:59 --> Final output sent to browser
DEBUG - 2004-01-01 00:03:59 --> Total execution time: 0.2652
INFO - 2004-01-01 00:04:10 --> Config Class Initialized
INFO - 2004-01-01 00:04:10 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:04:10 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:04:10 --> Utf8 Class Initialized
INFO - 2004-01-01 00:04:10 --> URI Class Initialized
INFO - 2004-01-01 00:04:10 --> Router Class Initialized
INFO - 2004-01-01 00:04:10 --> Output Class Initialized
INFO - 2004-01-01 00:04:10 --> Security Class Initialized
DEBUG - 2004-01-01 00:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:04:10 --> Input Class Initialized
INFO - 2004-01-01 00:04:10 --> Language Class Initialized
INFO - 2004-01-01 00:04:10 --> Loader Class Initialized
INFO - 2004-01-01 00:04:10 --> Helper loaded: url_helper
INFO - 2004-01-01 00:04:10 --> Helper loaded: html_helper
INFO - 2004-01-01 00:04:10 --> Helper loaded: form_helper
INFO - 2004-01-01 00:04:10 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:04:10 --> Helper loaded: date_helper
INFO - 2004-01-01 00:04:10 --> Form Validation Class Initialized
INFO - 2004-01-01 00:04:10 --> Email Class Initialized
DEBUG - 2004-01-01 00:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:04:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:04:10 --> Pagination Class Initialized
INFO - 2004-01-01 00:04:10 --> Database Driver Class Initialized
INFO - 2004-01-01 00:04:10 --> Database Driver Class Initialized
INFO - 2004-01-01 00:04:10 --> Controller Class Initialized
INFO - 2004-01-01 00:04:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2004-01-01 00:04:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation_group.php
INFO - 2004-01-01 00:04:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation_group.php
INFO - 2004-01-01 00:04:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2004-01-01 00:04:10 --> Final output sent to browser
DEBUG - 2004-01-01 00:04:10 --> Total execution time: 0.2184
INFO - 2004-01-01 00:04:10 --> Config Class Initialized
INFO - 2004-01-01 00:04:10 --> Hooks Class Initialized
DEBUG - 2004-01-01 00:04:10 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:04:10 --> Utf8 Class Initialized
INFO - 2004-01-01 00:04:10 --> URI Class Initialized
INFO - 2004-01-01 00:04:10 --> Router Class Initialized
INFO - 2004-01-01 00:04:10 --> Output Class Initialized
INFO - 2004-01-01 00:04:10 --> Security Class Initialized
DEBUG - 2004-01-01 00:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:04:10 --> Input Class Initialized
INFO - 2004-01-01 00:04:10 --> Language Class Initialized
INFO - 2004-01-01 00:04:10 --> Loader Class Initialized
INFO - 2004-01-01 00:04:10 --> Config Class Initialized
INFO - 2004-01-01 00:04:10 --> Hooks Class Initialized
INFO - 2004-01-01 00:04:10 --> Helper loaded: url_helper
INFO - 2004-01-01 00:04:10 --> Helper loaded: html_helper
DEBUG - 2004-01-01 00:04:10 --> UTF-8 Support Enabled
INFO - 2004-01-01 00:04:10 --> Utf8 Class Initialized
INFO - 2004-01-01 00:04:10 --> Helper loaded: form_helper
INFO - 2004-01-01 00:04:10 --> URI Class Initialized
INFO - 2004-01-01 00:04:10 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:04:10 --> Helper loaded: date_helper
INFO - 2004-01-01 00:04:10 --> Router Class Initialized
INFO - 2004-01-01 00:04:10 --> Form Validation Class Initialized
INFO - 2004-01-01 00:04:10 --> Output Class Initialized
INFO - 2004-01-01 00:04:10 --> Security Class Initialized
DEBUG - 2004-01-01 00:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2004-01-01 00:04:10 --> Input Class Initialized
INFO - 2004-01-01 00:04:10 --> Language Class Initialized
INFO - 2004-01-01 00:04:10 --> Email Class Initialized
DEBUG - 2004-01-01 00:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:04:10 --> Loader Class Initialized
INFO - 2004-01-01 00:04:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:04:10 --> Helper loaded: url_helper
INFO - 2004-01-01 00:04:10 --> Pagination Class Initialized
INFO - 2004-01-01 00:04:10 --> Helper loaded: html_helper
INFO - 2004-01-01 00:04:10 --> Helper loaded: form_helper
INFO - 2004-01-01 00:04:10 --> Helper loaded: cookie_helper
INFO - 2004-01-01 00:04:10 --> Helper loaded: date_helper
INFO - 2004-01-01 00:04:10 --> Form Validation Class Initialized
INFO - 2004-01-01 00:04:10 --> Database Driver Class Initialized
INFO - 2004-01-01 00:04:10 --> Database Driver Class Initialized
INFO - 2004-01-01 00:04:10 --> Email Class Initialized
DEBUG - 2004-01-01 00:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2004-01-01 00:04:10 --> Controller Class Initialized
INFO - 2004-01-01 00:04:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:04:10 --> Final output sent to browser
DEBUG - 2004-01-01 00:04:10 --> Total execution time: 0.1872
INFO - 2004-01-01 00:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2004-01-01 00:04:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2004-01-01 00:04:10 --> Pagination Class Initialized
INFO - 2004-01-01 00:04:10 --> Database Driver Class Initialized
INFO - 2004-01-01 00:04:10 --> Database Driver Class Initialized
INFO - 2004-01-01 00:04:10 --> Controller Class Initialized
INFO - 2004-01-01 00:04:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2004-01-01 00:04:10 --> Final output sent to browser
DEBUG - 2004-01-01 00:04:10 --> Total execution time: 0.2340
