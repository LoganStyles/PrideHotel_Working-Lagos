<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-14 05:02:30 --> Config Class Initialized
INFO - 2019-09-14 05:02:30 --> Hooks Class Initialized
DEBUG - 2019-09-14 05:02:31 --> UTF-8 Support Enabled
INFO - 2019-09-14 05:02:31 --> Utf8 Class Initialized
INFO - 2019-09-14 05:02:31 --> URI Class Initialized
INFO - 2019-09-14 05:02:32 --> Router Class Initialized
INFO - 2019-09-14 05:02:32 --> Output Class Initialized
INFO - 2019-09-14 05:02:32 --> Security Class Initialized
DEBUG - 2019-09-14 05:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 05:02:33 --> Input Class Initialized
INFO - 2019-09-14 05:02:33 --> Language Class Initialized
INFO - 2019-09-14 05:02:34 --> Loader Class Initialized
INFO - 2019-09-14 05:02:34 --> Helper loaded: url_helper
INFO - 2019-09-14 05:02:34 --> Helper loaded: html_helper
INFO - 2019-09-14 05:02:35 --> Helper loaded: form_helper
INFO - 2019-09-14 05:02:35 --> Helper loaded: cookie_helper
INFO - 2019-09-14 05:02:35 --> Helper loaded: date_helper
INFO - 2019-09-14 05:02:35 --> Form Validation Class Initialized
INFO - 2019-09-14 05:02:36 --> Email Class Initialized
DEBUG - 2019-09-14 05:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 05:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 05:02:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 05:02:36 --> Pagination Class Initialized
INFO - 2019-09-14 05:02:37 --> Database Driver Class Initialized
INFO - 2019-09-14 05:02:37 --> Database Driver Class Initialized
INFO - 2019-09-14 05:02:37 --> Controller Class Initialized
INFO - 2019-09-14 05:02:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-14 05:02:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-14 05:02:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-14 05:02:38 --> Final output sent to browser
DEBUG - 2019-09-14 05:02:38 --> Total execution time: 8.5874
INFO - 2019-09-14 05:02:44 --> Config Class Initialized
INFO - 2019-09-14 05:02:44 --> Hooks Class Initialized
DEBUG - 2019-09-14 05:02:44 --> UTF-8 Support Enabled
INFO - 2019-09-14 05:02:44 --> Utf8 Class Initialized
INFO - 2019-09-14 05:02:44 --> URI Class Initialized
INFO - 2019-09-14 05:02:44 --> Router Class Initialized
INFO - 2019-09-14 05:02:44 --> Output Class Initialized
INFO - 2019-09-14 05:02:44 --> Security Class Initialized
DEBUG - 2019-09-14 05:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 05:02:44 --> Input Class Initialized
INFO - 2019-09-14 05:02:44 --> Language Class Initialized
INFO - 2019-09-14 05:02:44 --> Loader Class Initialized
INFO - 2019-09-14 05:02:44 --> Helper loaded: url_helper
INFO - 2019-09-14 05:02:44 --> Helper loaded: html_helper
INFO - 2019-09-14 05:02:44 --> Helper loaded: form_helper
INFO - 2019-09-14 05:02:44 --> Helper loaded: cookie_helper
INFO - 2019-09-14 05:02:44 --> Helper loaded: date_helper
INFO - 2019-09-14 05:02:44 --> Form Validation Class Initialized
INFO - 2019-09-14 05:02:44 --> Email Class Initialized
DEBUG - 2019-09-14 05:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 05:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 05:02:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 05:02:44 --> Pagination Class Initialized
INFO - 2019-09-14 05:02:44 --> Database Driver Class Initialized
INFO - 2019-09-14 05:02:44 --> Database Driver Class Initialized
INFO - 2019-09-14 05:02:44 --> Controller Class Initialized
INFO - 2019-09-14 05:02:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 05:02:44 --> Final output sent to browser
DEBUG - 2019-09-14 05:02:44 --> Total execution time: 0.2313
INFO - 2019-09-14 05:02:44 --> Config Class Initialized
INFO - 2019-09-14 05:02:44 --> Hooks Class Initialized
DEBUG - 2019-09-14 05:02:44 --> UTF-8 Support Enabled
INFO - 2019-09-14 05:02:44 --> Utf8 Class Initialized
INFO - 2019-09-14 05:02:44 --> URI Class Initialized
INFO - 2019-09-14 05:02:44 --> Router Class Initialized
INFO - 2019-09-14 05:02:44 --> Output Class Initialized
INFO - 2019-09-14 05:02:44 --> Security Class Initialized
DEBUG - 2019-09-14 05:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 05:02:44 --> Input Class Initialized
INFO - 2019-09-14 05:02:44 --> Language Class Initialized
INFO - 2019-09-14 05:02:44 --> Loader Class Initialized
INFO - 2019-09-14 05:02:44 --> Helper loaded: url_helper
INFO - 2019-09-14 05:02:44 --> Helper loaded: html_helper
INFO - 2019-09-14 05:02:44 --> Helper loaded: form_helper
INFO - 2019-09-14 05:02:44 --> Helper loaded: cookie_helper
INFO - 2019-09-14 05:02:44 --> Helper loaded: date_helper
INFO - 2019-09-14 05:02:44 --> Form Validation Class Initialized
INFO - 2019-09-14 05:02:44 --> Email Class Initialized
DEBUG - 2019-09-14 05:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 05:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 05:02:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 05:02:44 --> Pagination Class Initialized
INFO - 2019-09-14 05:02:44 --> Database Driver Class Initialized
INFO - 2019-09-14 05:02:44 --> Database Driver Class Initialized
INFO - 2019-09-14 05:02:44 --> Controller Class Initialized
INFO - 2019-09-14 05:02:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 05:02:44 --> Final output sent to browser
DEBUG - 2019-09-14 05:02:44 --> Total execution time: 0.0846
INFO - 2019-09-14 10:41:13 --> Config Class Initialized
INFO - 2019-09-14 10:41:13 --> Hooks Class Initialized
DEBUG - 2019-09-14 10:41:13 --> UTF-8 Support Enabled
INFO - 2019-09-14 10:41:13 --> Utf8 Class Initialized
INFO - 2019-09-14 10:41:13 --> URI Class Initialized
INFO - 2019-09-14 10:41:13 --> Router Class Initialized
INFO - 2019-09-14 10:41:13 --> Output Class Initialized
INFO - 2019-09-14 10:41:13 --> Security Class Initialized
DEBUG - 2019-09-14 10:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 10:41:13 --> Input Class Initialized
INFO - 2019-09-14 10:41:13 --> Language Class Initialized
INFO - 2019-09-14 10:41:13 --> Loader Class Initialized
INFO - 2019-09-14 10:41:13 --> Helper loaded: url_helper
INFO - 2019-09-14 10:41:13 --> Helper loaded: html_helper
INFO - 2019-09-14 10:41:13 --> Helper loaded: form_helper
INFO - 2019-09-14 10:41:13 --> Helper loaded: cookie_helper
INFO - 2019-09-14 10:41:13 --> Helper loaded: date_helper
INFO - 2019-09-14 10:41:13 --> Form Validation Class Initialized
INFO - 2019-09-14 10:41:13 --> Email Class Initialized
DEBUG - 2019-09-14 10:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 10:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 10:41:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 10:41:13 --> Pagination Class Initialized
INFO - 2019-09-14 10:41:13 --> Database Driver Class Initialized
INFO - 2019-09-14 10:41:13 --> Database Driver Class Initialized
INFO - 2019-09-14 10:41:13 --> Controller Class Initialized
DEBUG - 2019-09-14 10:41:13 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 10:41:13 --> Helper loaded: inflector_helper
INFO - 2019-09-14 10:41:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 10:42:15 --> Config Class Initialized
INFO - 2019-09-14 10:42:15 --> Hooks Class Initialized
DEBUG - 2019-09-14 10:42:15 --> UTF-8 Support Enabled
INFO - 2019-09-14 10:42:15 --> Utf8 Class Initialized
INFO - 2019-09-14 10:42:15 --> URI Class Initialized
INFO - 2019-09-14 10:42:15 --> Router Class Initialized
INFO - 2019-09-14 10:42:15 --> Output Class Initialized
INFO - 2019-09-14 10:42:15 --> Security Class Initialized
DEBUG - 2019-09-14 10:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 10:42:15 --> Input Class Initialized
INFO - 2019-09-14 10:42:15 --> Language Class Initialized
INFO - 2019-09-14 10:42:15 --> Loader Class Initialized
INFO - 2019-09-14 10:42:15 --> Helper loaded: url_helper
INFO - 2019-09-14 10:42:15 --> Helper loaded: html_helper
INFO - 2019-09-14 10:42:15 --> Helper loaded: form_helper
INFO - 2019-09-14 10:42:15 --> Helper loaded: cookie_helper
INFO - 2019-09-14 10:42:15 --> Helper loaded: date_helper
INFO - 2019-09-14 10:42:15 --> Form Validation Class Initialized
INFO - 2019-09-14 10:42:15 --> Email Class Initialized
DEBUG - 2019-09-14 10:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 10:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 10:42:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 10:42:15 --> Pagination Class Initialized
INFO - 2019-09-14 10:42:15 --> Database Driver Class Initialized
INFO - 2019-09-14 10:42:15 --> Database Driver Class Initialized
INFO - 2019-09-14 10:42:15 --> Controller Class Initialized
DEBUG - 2019-09-14 10:42:15 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 10:42:15 --> Helper loaded: inflector_helper
INFO - 2019-09-14 10:42:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 10:44:39 --> Config Class Initialized
INFO - 2019-09-14 10:44:39 --> Hooks Class Initialized
DEBUG - 2019-09-14 10:44:39 --> UTF-8 Support Enabled
INFO - 2019-09-14 10:44:39 --> Utf8 Class Initialized
INFO - 2019-09-14 10:44:39 --> URI Class Initialized
INFO - 2019-09-14 10:44:39 --> Router Class Initialized
INFO - 2019-09-14 10:44:39 --> Output Class Initialized
INFO - 2019-09-14 10:44:39 --> Security Class Initialized
DEBUG - 2019-09-14 10:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 10:44:39 --> Input Class Initialized
INFO - 2019-09-14 10:44:39 --> Language Class Initialized
INFO - 2019-09-14 10:44:39 --> Loader Class Initialized
INFO - 2019-09-14 10:44:39 --> Helper loaded: url_helper
INFO - 2019-09-14 10:44:39 --> Helper loaded: html_helper
INFO - 2019-09-14 10:44:39 --> Helper loaded: form_helper
INFO - 2019-09-14 10:44:39 --> Helper loaded: cookie_helper
INFO - 2019-09-14 10:44:39 --> Helper loaded: date_helper
INFO - 2019-09-14 10:44:39 --> Form Validation Class Initialized
INFO - 2019-09-14 10:44:39 --> Email Class Initialized
DEBUG - 2019-09-14 10:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 10:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 10:44:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 10:44:39 --> Pagination Class Initialized
INFO - 2019-09-14 10:44:39 --> Database Driver Class Initialized
INFO - 2019-09-14 10:44:39 --> Database Driver Class Initialized
INFO - 2019-09-14 10:44:39 --> Controller Class Initialized
DEBUG - 2019-09-14 10:44:39 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 10:44:39 --> Helper loaded: inflector_helper
INFO - 2019-09-14 10:44:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 10:44:39 --> Final output sent to browser
DEBUG - 2019-09-14 10:44:39 --> Total execution time: 0.0418
INFO - 2019-09-14 10:46:07 --> Config Class Initialized
INFO - 2019-09-14 10:46:07 --> Hooks Class Initialized
DEBUG - 2019-09-14 10:46:07 --> UTF-8 Support Enabled
INFO - 2019-09-14 10:46:07 --> Utf8 Class Initialized
INFO - 2019-09-14 10:46:07 --> URI Class Initialized
INFO - 2019-09-14 10:46:07 --> Router Class Initialized
INFO - 2019-09-14 10:46:07 --> Output Class Initialized
INFO - 2019-09-14 10:46:07 --> Security Class Initialized
DEBUG - 2019-09-14 10:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 10:46:07 --> Input Class Initialized
INFO - 2019-09-14 10:46:07 --> Language Class Initialized
INFO - 2019-09-14 10:46:07 --> Loader Class Initialized
INFO - 2019-09-14 10:46:07 --> Helper loaded: url_helper
INFO - 2019-09-14 10:46:07 --> Helper loaded: html_helper
INFO - 2019-09-14 10:46:07 --> Helper loaded: form_helper
INFO - 2019-09-14 10:46:07 --> Helper loaded: cookie_helper
INFO - 2019-09-14 10:46:07 --> Helper loaded: date_helper
INFO - 2019-09-14 10:46:07 --> Form Validation Class Initialized
INFO - 2019-09-14 10:46:07 --> Email Class Initialized
DEBUG - 2019-09-14 10:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 10:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 10:46:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 10:46:07 --> Pagination Class Initialized
INFO - 2019-09-14 10:46:07 --> Database Driver Class Initialized
INFO - 2019-09-14 10:46:07 --> Database Driver Class Initialized
INFO - 2019-09-14 10:46:07 --> Controller Class Initialized
DEBUG - 2019-09-14 10:46:07 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 10:46:07 --> Helper loaded: inflector_helper
INFO - 2019-09-14 10:46:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 10:49:57 --> Config Class Initialized
INFO - 2019-09-14 10:49:57 --> Hooks Class Initialized
DEBUG - 2019-09-14 10:49:57 --> UTF-8 Support Enabled
INFO - 2019-09-14 10:49:57 --> Utf8 Class Initialized
INFO - 2019-09-14 10:49:57 --> URI Class Initialized
INFO - 2019-09-14 10:49:57 --> Router Class Initialized
INFO - 2019-09-14 10:49:57 --> Output Class Initialized
INFO - 2019-09-14 10:49:57 --> Security Class Initialized
DEBUG - 2019-09-14 10:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 10:49:57 --> Input Class Initialized
INFO - 2019-09-14 10:49:57 --> Language Class Initialized
INFO - 2019-09-14 10:49:57 --> Loader Class Initialized
INFO - 2019-09-14 10:49:57 --> Helper loaded: url_helper
INFO - 2019-09-14 10:49:57 --> Helper loaded: html_helper
INFO - 2019-09-14 10:49:57 --> Helper loaded: form_helper
INFO - 2019-09-14 10:49:57 --> Helper loaded: cookie_helper
INFO - 2019-09-14 10:49:57 --> Helper loaded: date_helper
INFO - 2019-09-14 10:49:57 --> Form Validation Class Initialized
INFO - 2019-09-14 10:49:57 --> Email Class Initialized
DEBUG - 2019-09-14 10:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 10:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 10:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 10:49:57 --> Pagination Class Initialized
INFO - 2019-09-14 10:49:57 --> Database Driver Class Initialized
INFO - 2019-09-14 10:49:57 --> Database Driver Class Initialized
INFO - 2019-09-14 10:49:57 --> Controller Class Initialized
DEBUG - 2019-09-14 10:49:57 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 10:49:57 --> Helper loaded: inflector_helper
INFO - 2019-09-14 10:49:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 10:49:57 --> Final output sent to browser
DEBUG - 2019-09-14 10:49:57 --> Total execution time: 0.0518
INFO - 2019-09-14 10:50:05 --> Config Class Initialized
INFO - 2019-09-14 10:50:05 --> Hooks Class Initialized
DEBUG - 2019-09-14 10:50:05 --> UTF-8 Support Enabled
INFO - 2019-09-14 10:50:05 --> Utf8 Class Initialized
INFO - 2019-09-14 10:50:05 --> URI Class Initialized
INFO - 2019-09-14 10:50:05 --> Router Class Initialized
INFO - 2019-09-14 10:50:05 --> Output Class Initialized
INFO - 2019-09-14 10:50:05 --> Security Class Initialized
DEBUG - 2019-09-14 10:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 10:50:05 --> Input Class Initialized
INFO - 2019-09-14 10:50:05 --> Language Class Initialized
INFO - 2019-09-14 10:50:05 --> Loader Class Initialized
INFO - 2019-09-14 10:50:05 --> Helper loaded: url_helper
INFO - 2019-09-14 10:50:05 --> Helper loaded: html_helper
INFO - 2019-09-14 10:50:05 --> Helper loaded: form_helper
INFO - 2019-09-14 10:50:05 --> Helper loaded: cookie_helper
INFO - 2019-09-14 10:50:05 --> Helper loaded: date_helper
INFO - 2019-09-14 10:50:05 --> Form Validation Class Initialized
INFO - 2019-09-14 10:50:05 --> Email Class Initialized
DEBUG - 2019-09-14 10:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 10:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 10:50:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 10:50:05 --> Pagination Class Initialized
INFO - 2019-09-14 10:50:05 --> Database Driver Class Initialized
INFO - 2019-09-14 10:50:05 --> Database Driver Class Initialized
INFO - 2019-09-14 10:50:05 --> Controller Class Initialized
DEBUG - 2019-09-14 10:50:05 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 10:50:05 --> Helper loaded: inflector_helper
INFO - 2019-09-14 10:50:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 10:50:05 --> Final output sent to browser
DEBUG - 2019-09-14 10:50:05 --> Total execution time: 0.0441
INFO - 2019-09-14 11:36:51 --> Config Class Initialized
INFO - 2019-09-14 11:36:51 --> Hooks Class Initialized
DEBUG - 2019-09-14 11:36:51 --> UTF-8 Support Enabled
INFO - 2019-09-14 11:36:51 --> Utf8 Class Initialized
INFO - 2019-09-14 11:36:51 --> URI Class Initialized
INFO - 2019-09-14 11:36:51 --> Router Class Initialized
INFO - 2019-09-14 11:36:51 --> Output Class Initialized
INFO - 2019-09-14 11:36:51 --> Security Class Initialized
DEBUG - 2019-09-14 11:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 11:36:51 --> Input Class Initialized
INFO - 2019-09-14 11:36:51 --> Language Class Initialized
INFO - 2019-09-14 11:36:51 --> Loader Class Initialized
INFO - 2019-09-14 11:36:51 --> Helper loaded: url_helper
INFO - 2019-09-14 11:36:51 --> Helper loaded: html_helper
INFO - 2019-09-14 11:36:51 --> Helper loaded: form_helper
INFO - 2019-09-14 11:36:51 --> Helper loaded: cookie_helper
INFO - 2019-09-14 11:36:51 --> Helper loaded: date_helper
INFO - 2019-09-14 11:36:51 --> Form Validation Class Initialized
INFO - 2019-09-14 11:36:51 --> Email Class Initialized
DEBUG - 2019-09-14 11:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 11:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 11:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 11:36:51 --> Pagination Class Initialized
INFO - 2019-09-14 11:36:51 --> Database Driver Class Initialized
INFO - 2019-09-14 11:36:51 --> Database Driver Class Initialized
INFO - 2019-09-14 11:36:51 --> Controller Class Initialized
DEBUG - 2019-09-14 11:36:51 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 11:36:51 --> Helper loaded: inflector_helper
INFO - 2019-09-14 11:36:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 11:36:51 --> Final output sent to browser
DEBUG - 2019-09-14 11:36:51 --> Total execution time: 0.0544
INFO - 2019-09-14 11:37:26 --> Config Class Initialized
INFO - 2019-09-14 11:37:26 --> Hooks Class Initialized
DEBUG - 2019-09-14 11:37:26 --> UTF-8 Support Enabled
INFO - 2019-09-14 11:37:26 --> Utf8 Class Initialized
INFO - 2019-09-14 11:37:26 --> URI Class Initialized
INFO - 2019-09-14 11:37:26 --> Router Class Initialized
INFO - 2019-09-14 11:37:26 --> Output Class Initialized
INFO - 2019-09-14 11:37:26 --> Security Class Initialized
DEBUG - 2019-09-14 11:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 11:37:26 --> Input Class Initialized
INFO - 2019-09-14 11:37:26 --> Language Class Initialized
INFO - 2019-09-14 11:37:26 --> Loader Class Initialized
INFO - 2019-09-14 11:37:26 --> Helper loaded: url_helper
INFO - 2019-09-14 11:37:26 --> Helper loaded: html_helper
INFO - 2019-09-14 11:37:26 --> Helper loaded: form_helper
INFO - 2019-09-14 11:37:26 --> Helper loaded: cookie_helper
INFO - 2019-09-14 11:37:26 --> Helper loaded: date_helper
INFO - 2019-09-14 11:37:26 --> Form Validation Class Initialized
INFO - 2019-09-14 11:37:26 --> Email Class Initialized
DEBUG - 2019-09-14 11:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 11:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 11:37:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 11:37:26 --> Pagination Class Initialized
INFO - 2019-09-14 11:37:26 --> Database Driver Class Initialized
INFO - 2019-09-14 11:37:26 --> Database Driver Class Initialized
INFO - 2019-09-14 11:37:26 --> Controller Class Initialized
DEBUG - 2019-09-14 11:37:26 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 11:37:26 --> Helper loaded: inflector_helper
INFO - 2019-09-14 11:37:26 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 11:37:26 --> Severity: Notice --> Array to string conversion C:\wamp64\www\pridehotel_lagos\system\database\DB_driver.php 1476
ERROR - 2019-09-14 11:37:26 --> Severity: Notice --> Array to string conversion C:\wamp64\www\pridehotel_lagos\system\database\DB_driver.php 1476
ERROR - 2019-09-14 11:37:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0, 1) VALUES (Array, Array)' at line 1 - Invalid query: INSERT INTO `reservationitems` (0, 1) VALUES (Array, Array)
INFO - 2019-09-14 11:37:26 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 11:40:34 --> Config Class Initialized
INFO - 2019-09-14 11:40:34 --> Hooks Class Initialized
DEBUG - 2019-09-14 11:40:34 --> UTF-8 Support Enabled
INFO - 2019-09-14 11:40:34 --> Utf8 Class Initialized
INFO - 2019-09-14 11:40:34 --> URI Class Initialized
INFO - 2019-09-14 11:40:34 --> Router Class Initialized
INFO - 2019-09-14 11:40:34 --> Output Class Initialized
INFO - 2019-09-14 11:40:34 --> Security Class Initialized
DEBUG - 2019-09-14 11:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 11:40:34 --> Input Class Initialized
INFO - 2019-09-14 11:40:34 --> Language Class Initialized
INFO - 2019-09-14 11:40:34 --> Loader Class Initialized
INFO - 2019-09-14 11:40:34 --> Helper loaded: url_helper
INFO - 2019-09-14 11:40:34 --> Helper loaded: html_helper
INFO - 2019-09-14 11:40:34 --> Helper loaded: form_helper
INFO - 2019-09-14 11:40:34 --> Helper loaded: cookie_helper
INFO - 2019-09-14 11:40:34 --> Helper loaded: date_helper
INFO - 2019-09-14 11:40:34 --> Form Validation Class Initialized
INFO - 2019-09-14 11:40:35 --> Email Class Initialized
DEBUG - 2019-09-14 11:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 11:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 11:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 11:40:35 --> Pagination Class Initialized
INFO - 2019-09-14 11:40:35 --> Database Driver Class Initialized
INFO - 2019-09-14 11:40:35 --> Database Driver Class Initialized
INFO - 2019-09-14 11:40:35 --> Controller Class Initialized
DEBUG - 2019-09-14 11:40:35 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 11:40:35 --> Helper loaded: inflector_helper
INFO - 2019-09-14 11:40:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 11:44:05 --> Config Class Initialized
INFO - 2019-09-14 11:44:05 --> Hooks Class Initialized
DEBUG - 2019-09-14 11:44:05 --> UTF-8 Support Enabled
INFO - 2019-09-14 11:44:05 --> Utf8 Class Initialized
INFO - 2019-09-14 11:44:05 --> URI Class Initialized
INFO - 2019-09-14 11:44:05 --> Router Class Initialized
INFO - 2019-09-14 11:44:05 --> Output Class Initialized
INFO - 2019-09-14 11:44:05 --> Security Class Initialized
DEBUG - 2019-09-14 11:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 11:44:05 --> Input Class Initialized
INFO - 2019-09-14 11:44:05 --> Language Class Initialized
INFO - 2019-09-14 11:44:05 --> Loader Class Initialized
INFO - 2019-09-14 11:44:05 --> Helper loaded: url_helper
INFO - 2019-09-14 11:44:05 --> Helper loaded: html_helper
INFO - 2019-09-14 11:44:05 --> Helper loaded: form_helper
INFO - 2019-09-14 11:44:05 --> Helper loaded: cookie_helper
INFO - 2019-09-14 11:44:05 --> Helper loaded: date_helper
INFO - 2019-09-14 11:44:05 --> Form Validation Class Initialized
INFO - 2019-09-14 11:44:05 --> Email Class Initialized
DEBUG - 2019-09-14 11:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 11:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 11:44:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 11:44:05 --> Pagination Class Initialized
INFO - 2019-09-14 11:44:05 --> Database Driver Class Initialized
INFO - 2019-09-14 11:44:05 --> Database Driver Class Initialized
INFO - 2019-09-14 11:44:05 --> Controller Class Initialized
DEBUG - 2019-09-14 11:44:05 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 11:44:05 --> Helper loaded: inflector_helper
INFO - 2019-09-14 11:44:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 11:47:21 --> Config Class Initialized
INFO - 2019-09-14 11:47:21 --> Hooks Class Initialized
DEBUG - 2019-09-14 11:47:21 --> UTF-8 Support Enabled
INFO - 2019-09-14 11:47:21 --> Utf8 Class Initialized
INFO - 2019-09-14 11:47:21 --> URI Class Initialized
INFO - 2019-09-14 11:47:21 --> Router Class Initialized
INFO - 2019-09-14 11:47:21 --> Output Class Initialized
INFO - 2019-09-14 11:47:21 --> Security Class Initialized
DEBUG - 2019-09-14 11:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 11:47:21 --> Input Class Initialized
INFO - 2019-09-14 11:47:21 --> Language Class Initialized
INFO - 2019-09-14 11:47:21 --> Loader Class Initialized
INFO - 2019-09-14 11:47:21 --> Helper loaded: url_helper
INFO - 2019-09-14 11:47:21 --> Helper loaded: html_helper
INFO - 2019-09-14 11:47:21 --> Helper loaded: form_helper
INFO - 2019-09-14 11:47:21 --> Helper loaded: cookie_helper
INFO - 2019-09-14 11:47:21 --> Helper loaded: date_helper
INFO - 2019-09-14 11:47:21 --> Form Validation Class Initialized
INFO - 2019-09-14 11:47:21 --> Email Class Initialized
DEBUG - 2019-09-14 11:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 11:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 11:47:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 11:47:21 --> Pagination Class Initialized
INFO - 2019-09-14 11:47:21 --> Database Driver Class Initialized
INFO - 2019-09-14 11:47:21 --> Database Driver Class Initialized
INFO - 2019-09-14 11:47:21 --> Controller Class Initialized
DEBUG - 2019-09-14 11:47:21 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 11:47:21 --> Helper loaded: inflector_helper
INFO - 2019-09-14 11:47:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 11:47:41 --> Config Class Initialized
INFO - 2019-09-14 11:47:41 --> Hooks Class Initialized
DEBUG - 2019-09-14 11:47:41 --> UTF-8 Support Enabled
INFO - 2019-09-14 11:47:41 --> Utf8 Class Initialized
INFO - 2019-09-14 11:47:41 --> URI Class Initialized
INFO - 2019-09-14 11:47:41 --> Router Class Initialized
INFO - 2019-09-14 11:47:41 --> Output Class Initialized
INFO - 2019-09-14 11:47:41 --> Security Class Initialized
DEBUG - 2019-09-14 11:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 11:47:41 --> Input Class Initialized
INFO - 2019-09-14 11:47:41 --> Language Class Initialized
INFO - 2019-09-14 11:47:41 --> Loader Class Initialized
INFO - 2019-09-14 11:47:41 --> Helper loaded: url_helper
INFO - 2019-09-14 11:47:41 --> Helper loaded: html_helper
INFO - 2019-09-14 11:47:41 --> Helper loaded: form_helper
INFO - 2019-09-14 11:47:41 --> Helper loaded: cookie_helper
INFO - 2019-09-14 11:47:41 --> Helper loaded: date_helper
INFO - 2019-09-14 11:47:41 --> Form Validation Class Initialized
INFO - 2019-09-14 11:47:41 --> Email Class Initialized
DEBUG - 2019-09-14 11:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 11:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 11:47:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 11:47:41 --> Pagination Class Initialized
INFO - 2019-09-14 11:47:41 --> Database Driver Class Initialized
INFO - 2019-09-14 11:47:41 --> Database Driver Class Initialized
INFO - 2019-09-14 11:47:41 --> Controller Class Initialized
DEBUG - 2019-09-14 11:47:41 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 11:47:41 --> Helper loaded: inflector_helper
INFO - 2019-09-14 11:47:41 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 11:47:41 --> Severity: Notice --> Array to string conversion C:\wamp64\www\pridehotel_lagos\system\database\DB_driver.php 1476
ERROR - 2019-09-14 11:47:41 --> Severity: Notice --> Array to string conversion C:\wamp64\www\pridehotel_lagos\system\database\DB_driver.php 1476
ERROR - 2019-09-14 11:47:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0, 1) VALUES (Array, Array)' at line 1 - Invalid query: INSERT INTO `reservationitems` (0, 1) VALUES (Array, Array)
INFO - 2019-09-14 11:47:41 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 11:50:49 --> Config Class Initialized
INFO - 2019-09-14 11:50:49 --> Hooks Class Initialized
DEBUG - 2019-09-14 11:50:49 --> UTF-8 Support Enabled
INFO - 2019-09-14 11:50:49 --> Utf8 Class Initialized
INFO - 2019-09-14 11:50:49 --> URI Class Initialized
INFO - 2019-09-14 11:50:49 --> Router Class Initialized
INFO - 2019-09-14 11:50:49 --> Output Class Initialized
INFO - 2019-09-14 11:50:49 --> Security Class Initialized
DEBUG - 2019-09-14 11:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 11:50:49 --> Input Class Initialized
INFO - 2019-09-14 11:50:49 --> Language Class Initialized
INFO - 2019-09-14 11:50:49 --> Loader Class Initialized
INFO - 2019-09-14 11:50:49 --> Helper loaded: url_helper
INFO - 2019-09-14 11:50:49 --> Helper loaded: html_helper
INFO - 2019-09-14 11:50:49 --> Helper loaded: form_helper
INFO - 2019-09-14 11:50:49 --> Helper loaded: cookie_helper
INFO - 2019-09-14 11:50:49 --> Helper loaded: date_helper
INFO - 2019-09-14 11:50:49 --> Form Validation Class Initialized
INFO - 2019-09-14 11:50:49 --> Email Class Initialized
DEBUG - 2019-09-14 11:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 11:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 11:50:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 11:50:49 --> Pagination Class Initialized
INFO - 2019-09-14 11:50:49 --> Database Driver Class Initialized
INFO - 2019-09-14 11:50:49 --> Database Driver Class Initialized
INFO - 2019-09-14 11:50:49 --> Controller Class Initialized
DEBUG - 2019-09-14 11:50:49 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 11:50:49 --> Helper loaded: inflector_helper
INFO - 2019-09-14 11:50:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 11:52:55 --> Config Class Initialized
INFO - 2019-09-14 11:52:55 --> Hooks Class Initialized
DEBUG - 2019-09-14 11:52:55 --> UTF-8 Support Enabled
INFO - 2019-09-14 11:52:55 --> Utf8 Class Initialized
INFO - 2019-09-14 11:52:55 --> URI Class Initialized
INFO - 2019-09-14 11:52:55 --> Router Class Initialized
INFO - 2019-09-14 11:52:55 --> Output Class Initialized
INFO - 2019-09-14 11:52:55 --> Security Class Initialized
DEBUG - 2019-09-14 11:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 11:52:55 --> Input Class Initialized
INFO - 2019-09-14 11:52:55 --> Language Class Initialized
INFO - 2019-09-14 11:52:55 --> Loader Class Initialized
INFO - 2019-09-14 11:52:55 --> Helper loaded: url_helper
INFO - 2019-09-14 11:52:55 --> Helper loaded: html_helper
INFO - 2019-09-14 11:52:55 --> Helper loaded: form_helper
INFO - 2019-09-14 11:52:55 --> Helper loaded: cookie_helper
INFO - 2019-09-14 11:52:55 --> Helper loaded: date_helper
INFO - 2019-09-14 11:52:55 --> Form Validation Class Initialized
INFO - 2019-09-14 11:52:55 --> Email Class Initialized
DEBUG - 2019-09-14 11:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 11:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 11:52:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 11:52:55 --> Pagination Class Initialized
INFO - 2019-09-14 11:52:55 --> Database Driver Class Initialized
INFO - 2019-09-14 11:52:55 --> Database Driver Class Initialized
INFO - 2019-09-14 11:52:55 --> Controller Class Initialized
DEBUG - 2019-09-14 11:52:55 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 11:52:55 --> Helper loaded: inflector_helper
INFO - 2019-09-14 11:52:55 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 11:52:55 --> Query error: Duplicate entry '000000000001' for key 'reservations_id' - Invalid query: INSERT INTO `reservationitems` (`reservation_id`, `account_type`, `master_id`, `arrival`, `nights`, `departure`, `room_number`, `roomtype`, `client_type`, `client_name`, `agency_name`, `agency_contact`, `guest1`, `guest2`, `guest_count`, `adults`, `children`, `type`, `remarks`, `date_created`, `date_modified`, `signature_created`, `signature_modified`, `status`, `deleted`, `actual_arrival`, `actual_departure`, `last_room_charge`, `last_account_close`) VALUES ('000000000001', 'ROOM', '', '2019-09-09', 2, '2019-09-09', 1, 6, 'person', 'francis', '', '', 'francis', '', 1, 1, 0, 'reservation', '', '2019-09-09', '2019-09-09', 'maz', 'max', 'staying', '0', '2019-09-09', '2019-09-09', '2019-09-09', '2019-09-09')
INFO - 2019-09-14 11:52:55 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 12:19:24 --> Config Class Initialized
INFO - 2019-09-14 12:19:24 --> Hooks Class Initialized
DEBUG - 2019-09-14 12:19:24 --> UTF-8 Support Enabled
INFO - 2019-09-14 12:19:24 --> Utf8 Class Initialized
INFO - 2019-09-14 12:19:24 --> URI Class Initialized
INFO - 2019-09-14 12:19:24 --> Router Class Initialized
INFO - 2019-09-14 12:19:24 --> Output Class Initialized
INFO - 2019-09-14 12:19:25 --> Security Class Initialized
DEBUG - 2019-09-14 12:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 12:19:25 --> Input Class Initialized
INFO - 2019-09-14 12:19:25 --> Language Class Initialized
INFO - 2019-09-14 12:19:25 --> Loader Class Initialized
INFO - 2019-09-14 12:19:25 --> Helper loaded: url_helper
INFO - 2019-09-14 12:19:25 --> Helper loaded: html_helper
INFO - 2019-09-14 12:19:25 --> Helper loaded: form_helper
INFO - 2019-09-14 12:19:25 --> Helper loaded: cookie_helper
INFO - 2019-09-14 12:19:25 --> Helper loaded: date_helper
INFO - 2019-09-14 12:19:25 --> Form Validation Class Initialized
INFO - 2019-09-14 12:19:25 --> Email Class Initialized
DEBUG - 2019-09-14 12:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 12:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 12:19:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 12:19:25 --> Pagination Class Initialized
INFO - 2019-09-14 12:19:25 --> Database Driver Class Initialized
INFO - 2019-09-14 12:19:25 --> Database Driver Class Initialized
INFO - 2019-09-14 12:19:25 --> Controller Class Initialized
DEBUG - 2019-09-14 12:19:25 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 12:19:25 --> Helper loaded: inflector_helper
INFO - 2019-09-14 12:19:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 12:19:25 --> Final output sent to browser
DEBUG - 2019-09-14 12:19:25 --> Total execution time: 0.2480
INFO - 2019-09-14 12:20:38 --> Config Class Initialized
INFO - 2019-09-14 12:20:38 --> Hooks Class Initialized
DEBUG - 2019-09-14 12:20:38 --> UTF-8 Support Enabled
INFO - 2019-09-14 12:20:38 --> Utf8 Class Initialized
INFO - 2019-09-14 12:20:38 --> URI Class Initialized
INFO - 2019-09-14 12:20:38 --> Router Class Initialized
INFO - 2019-09-14 12:20:38 --> Output Class Initialized
INFO - 2019-09-14 12:20:38 --> Security Class Initialized
DEBUG - 2019-09-14 12:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 12:20:38 --> Input Class Initialized
INFO - 2019-09-14 12:20:38 --> Language Class Initialized
INFO - 2019-09-14 12:20:38 --> Loader Class Initialized
INFO - 2019-09-14 12:20:38 --> Helper loaded: url_helper
INFO - 2019-09-14 12:20:38 --> Helper loaded: html_helper
INFO - 2019-09-14 12:20:38 --> Helper loaded: form_helper
INFO - 2019-09-14 12:20:38 --> Helper loaded: cookie_helper
INFO - 2019-09-14 12:20:38 --> Helper loaded: date_helper
INFO - 2019-09-14 12:20:38 --> Form Validation Class Initialized
INFO - 2019-09-14 12:20:38 --> Email Class Initialized
DEBUG - 2019-09-14 12:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 12:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 12:20:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 12:20:38 --> Pagination Class Initialized
INFO - 2019-09-14 12:20:38 --> Database Driver Class Initialized
INFO - 2019-09-14 12:20:38 --> Database Driver Class Initialized
INFO - 2019-09-14 12:20:38 --> Controller Class Initialized
DEBUG - 2019-09-14 12:20:38 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 12:20:38 --> Helper loaded: inflector_helper
INFO - 2019-09-14 12:20:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 12:20:38 --> Final output sent to browser
DEBUG - 2019-09-14 12:20:38 --> Total execution time: 0.2824
INFO - 2019-09-14 12:20:49 --> Config Class Initialized
INFO - 2019-09-14 12:20:49 --> Hooks Class Initialized
DEBUG - 2019-09-14 12:20:49 --> UTF-8 Support Enabled
INFO - 2019-09-14 12:20:49 --> Utf8 Class Initialized
INFO - 2019-09-14 12:20:49 --> URI Class Initialized
INFO - 2019-09-14 12:20:49 --> Router Class Initialized
INFO - 2019-09-14 12:20:49 --> Output Class Initialized
INFO - 2019-09-14 12:20:49 --> Security Class Initialized
DEBUG - 2019-09-14 12:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 12:20:49 --> Input Class Initialized
INFO - 2019-09-14 12:20:49 --> Language Class Initialized
INFO - 2019-09-14 12:20:49 --> Loader Class Initialized
INFO - 2019-09-14 12:20:49 --> Helper loaded: url_helper
INFO - 2019-09-14 12:20:49 --> Helper loaded: html_helper
INFO - 2019-09-14 12:20:49 --> Helper loaded: form_helper
INFO - 2019-09-14 12:20:49 --> Helper loaded: cookie_helper
INFO - 2019-09-14 12:20:49 --> Helper loaded: date_helper
INFO - 2019-09-14 12:20:49 --> Form Validation Class Initialized
INFO - 2019-09-14 12:20:49 --> Email Class Initialized
DEBUG - 2019-09-14 12:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 12:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 12:20:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 12:20:49 --> Pagination Class Initialized
INFO - 2019-09-14 12:20:49 --> Database Driver Class Initialized
INFO - 2019-09-14 12:20:49 --> Database Driver Class Initialized
INFO - 2019-09-14 12:20:49 --> Controller Class Initialized
DEBUG - 2019-09-14 12:20:49 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 12:20:49 --> Helper loaded: inflector_helper
INFO - 2019-09-14 12:20:49 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 12:20:49 --> Query error: Duplicate entry '000000000001' for key 'reservations_id' - Invalid query: INSERT INTO `reservationitems` (`reservation_id`, `account_type`, `master_id`, `arrival`, `nights`, `departure`, `room_number`, `roomtype`, `client_type`, `client_name`, `agency_name`, `agency_contact`, `guest1`, `guest2`, `guest_count`, `adults`, `children`, `type`, `remarks`, `date_created`, `date_modified`, `signature_created`, `signature_modified`, `status`, `deleted`, `actual_arrival`, `actual_departure`, `last_room_charge`, `last_account_close`) VALUES ('000000000001', 'ROOM', '', '2019-09-09', 2, '2019-09-09', 1, 6, 'person', 'francis', '', '', 'francis', '', 1, 1, 0, 'reservation', '', '2019-09-09', '2019-09-09', 'maz', 'max', 'staying', '0', '2019-09-09', '2019-09-09', '2019-09-09', '2019-09-09')
INFO - 2019-09-14 12:20:49 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 12:36:03 --> Config Class Initialized
INFO - 2019-09-14 12:36:03 --> Hooks Class Initialized
DEBUG - 2019-09-14 12:36:03 --> UTF-8 Support Enabled
INFO - 2019-09-14 12:36:03 --> Utf8 Class Initialized
INFO - 2019-09-14 12:36:03 --> URI Class Initialized
INFO - 2019-09-14 12:36:03 --> Router Class Initialized
INFO - 2019-09-14 12:36:03 --> Output Class Initialized
INFO - 2019-09-14 12:36:03 --> Security Class Initialized
DEBUG - 2019-09-14 12:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 12:36:03 --> Input Class Initialized
INFO - 2019-09-14 12:36:03 --> Language Class Initialized
INFO - 2019-09-14 12:36:03 --> Loader Class Initialized
INFO - 2019-09-14 12:36:03 --> Helper loaded: url_helper
INFO - 2019-09-14 12:36:03 --> Helper loaded: html_helper
INFO - 2019-09-14 12:36:03 --> Helper loaded: form_helper
INFO - 2019-09-14 12:36:03 --> Helper loaded: cookie_helper
INFO - 2019-09-14 12:36:03 --> Helper loaded: date_helper
INFO - 2019-09-14 12:36:03 --> Form Validation Class Initialized
INFO - 2019-09-14 12:36:03 --> Email Class Initialized
DEBUG - 2019-09-14 12:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 12:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 12:36:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 12:36:03 --> Pagination Class Initialized
INFO - 2019-09-14 12:36:03 --> Database Driver Class Initialized
INFO - 2019-09-14 12:36:03 --> Database Driver Class Initialized
INFO - 2019-09-14 12:36:03 --> Controller Class Initialized
DEBUG - 2019-09-14 12:36:03 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 12:36:03 --> Helper loaded: inflector_helper
INFO - 2019-09-14 12:36:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 12:36:03 --> Final output sent to browser
DEBUG - 2019-09-14 12:36:03 --> Total execution time: 0.3078
INFO - 2019-09-14 12:36:34 --> Config Class Initialized
INFO - 2019-09-14 12:36:34 --> Hooks Class Initialized
DEBUG - 2019-09-14 12:36:34 --> UTF-8 Support Enabled
INFO - 2019-09-14 12:36:34 --> Utf8 Class Initialized
INFO - 2019-09-14 12:36:34 --> URI Class Initialized
INFO - 2019-09-14 12:36:34 --> Router Class Initialized
INFO - 2019-09-14 12:36:34 --> Output Class Initialized
INFO - 2019-09-14 12:36:34 --> Security Class Initialized
DEBUG - 2019-09-14 12:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 12:36:34 --> Input Class Initialized
INFO - 2019-09-14 12:36:34 --> Language Class Initialized
INFO - 2019-09-14 12:36:34 --> Loader Class Initialized
INFO - 2019-09-14 12:36:34 --> Helper loaded: url_helper
INFO - 2019-09-14 12:36:34 --> Helper loaded: html_helper
INFO - 2019-09-14 12:36:34 --> Helper loaded: form_helper
INFO - 2019-09-14 12:36:34 --> Helper loaded: cookie_helper
INFO - 2019-09-14 12:36:34 --> Helper loaded: date_helper
INFO - 2019-09-14 12:36:34 --> Form Validation Class Initialized
INFO - 2019-09-14 12:36:34 --> Email Class Initialized
DEBUG - 2019-09-14 12:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 12:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 12:36:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 12:36:34 --> Pagination Class Initialized
INFO - 2019-09-14 12:36:34 --> Database Driver Class Initialized
INFO - 2019-09-14 12:36:34 --> Database Driver Class Initialized
INFO - 2019-09-14 12:36:34 --> Controller Class Initialized
DEBUG - 2019-09-14 12:36:34 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 12:36:34 --> Helper loaded: inflector_helper
INFO - 2019-09-14 12:36:34 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 12:36:34 --> Query error: Duplicate entry '000000000001' for key 'reservations_id' - Invalid query: INSERT INTO `reservationitems` (`reservation_id`, `account_type`, `master_id`, `arrival`, `nights`, `departure`, `room_number`, `roomtype`, `client_type`, `client_name`, `agency_name`, `agency_contact`, `guest1`, `guest2`, `guest_count`, `adults`, `children`, `type`, `remarks`, `date_created`, `date_modified`, `signature_created`, `signature_modified`, `status`, `deleted`, `actual_arrival`, `actual_departure`, `last_room_charge`, `last_account_close`) VALUES ('000000000001', 'ROOM', '', '2019-09-09', 2, '2019-09-09', 1, 6, 'person', 'francis', '', '', 'francis', '', 1, 1, 0, 'reservation', '', '2019-09-09', '2019-09-09', 'maz', 'max', 'staying', '0', '2019-09-09', '2019-09-09', '2019-09-09', '2019-09-09')
INFO - 2019-09-14 12:36:34 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 12:45:37 --> Config Class Initialized
INFO - 2019-09-14 12:45:37 --> Hooks Class Initialized
DEBUG - 2019-09-14 12:45:37 --> UTF-8 Support Enabled
INFO - 2019-09-14 12:45:37 --> Utf8 Class Initialized
INFO - 2019-09-14 12:45:37 --> URI Class Initialized
INFO - 2019-09-14 12:45:37 --> Router Class Initialized
INFO - 2019-09-14 12:45:37 --> Output Class Initialized
INFO - 2019-09-14 12:45:37 --> Security Class Initialized
DEBUG - 2019-09-14 12:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 12:45:37 --> Input Class Initialized
INFO - 2019-09-14 12:45:37 --> Language Class Initialized
INFO - 2019-09-14 12:45:37 --> Loader Class Initialized
INFO - 2019-09-14 12:45:37 --> Helper loaded: url_helper
INFO - 2019-09-14 12:45:37 --> Helper loaded: html_helper
INFO - 2019-09-14 12:45:37 --> Helper loaded: form_helper
INFO - 2019-09-14 12:45:37 --> Helper loaded: cookie_helper
INFO - 2019-09-14 12:45:37 --> Helper loaded: date_helper
INFO - 2019-09-14 12:45:37 --> Form Validation Class Initialized
INFO - 2019-09-14 12:45:37 --> Email Class Initialized
DEBUG - 2019-09-14 12:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 12:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 12:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 12:45:37 --> Pagination Class Initialized
INFO - 2019-09-14 12:45:37 --> Database Driver Class Initialized
INFO - 2019-09-14 12:45:37 --> Database Driver Class Initialized
INFO - 2019-09-14 12:45:37 --> Controller Class Initialized
DEBUG - 2019-09-14 12:45:37 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 12:45:37 --> Helper loaded: inflector_helper
INFO - 2019-09-14 12:45:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 12:45:37 --> Final output sent to browser
DEBUG - 2019-09-14 12:45:37 --> Total execution time: 0.1690
INFO - 2019-09-14 12:46:39 --> Config Class Initialized
INFO - 2019-09-14 12:46:39 --> Hooks Class Initialized
DEBUG - 2019-09-14 12:46:39 --> UTF-8 Support Enabled
INFO - 2019-09-14 12:46:39 --> Utf8 Class Initialized
INFO - 2019-09-14 12:46:39 --> URI Class Initialized
INFO - 2019-09-14 12:46:39 --> Router Class Initialized
INFO - 2019-09-14 12:46:39 --> Output Class Initialized
INFO - 2019-09-14 12:46:39 --> Security Class Initialized
DEBUG - 2019-09-14 12:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 12:46:39 --> Input Class Initialized
INFO - 2019-09-14 12:46:39 --> Language Class Initialized
INFO - 2019-09-14 12:46:39 --> Loader Class Initialized
INFO - 2019-09-14 12:46:39 --> Helper loaded: url_helper
INFO - 2019-09-14 12:46:39 --> Helper loaded: html_helper
INFO - 2019-09-14 12:46:39 --> Helper loaded: form_helper
INFO - 2019-09-14 12:46:39 --> Helper loaded: cookie_helper
INFO - 2019-09-14 12:46:39 --> Helper loaded: date_helper
INFO - 2019-09-14 12:46:39 --> Form Validation Class Initialized
INFO - 2019-09-14 12:46:39 --> Email Class Initialized
DEBUG - 2019-09-14 12:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 12:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 12:46:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 12:46:39 --> Pagination Class Initialized
INFO - 2019-09-14 12:46:39 --> Database Driver Class Initialized
INFO - 2019-09-14 12:46:39 --> Database Driver Class Initialized
INFO - 2019-09-14 12:46:39 --> Controller Class Initialized
DEBUG - 2019-09-14 12:46:39 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 12:46:39 --> Helper loaded: inflector_helper
INFO - 2019-09-14 12:46:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 12:46:39 --> Final output sent to browser
DEBUG - 2019-09-14 12:46:39 --> Total execution time: 0.3509
INFO - 2019-09-14 12:47:42 --> Config Class Initialized
INFO - 2019-09-14 12:47:42 --> Hooks Class Initialized
DEBUG - 2019-09-14 12:47:42 --> UTF-8 Support Enabled
INFO - 2019-09-14 12:47:42 --> Utf8 Class Initialized
INFO - 2019-09-14 12:47:42 --> URI Class Initialized
INFO - 2019-09-14 12:47:42 --> Router Class Initialized
INFO - 2019-09-14 12:47:42 --> Output Class Initialized
INFO - 2019-09-14 12:47:42 --> Security Class Initialized
DEBUG - 2019-09-14 12:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 12:47:42 --> Input Class Initialized
INFO - 2019-09-14 12:47:42 --> Language Class Initialized
INFO - 2019-09-14 12:47:42 --> Loader Class Initialized
INFO - 2019-09-14 12:47:42 --> Helper loaded: url_helper
INFO - 2019-09-14 12:47:42 --> Helper loaded: html_helper
INFO - 2019-09-14 12:47:42 --> Helper loaded: form_helper
INFO - 2019-09-14 12:47:42 --> Helper loaded: cookie_helper
INFO - 2019-09-14 12:47:42 --> Helper loaded: date_helper
INFO - 2019-09-14 12:47:42 --> Form Validation Class Initialized
INFO - 2019-09-14 12:47:42 --> Email Class Initialized
DEBUG - 2019-09-14 12:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 12:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 12:47:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 12:47:42 --> Pagination Class Initialized
INFO - 2019-09-14 12:47:42 --> Database Driver Class Initialized
INFO - 2019-09-14 12:47:42 --> Database Driver Class Initialized
INFO - 2019-09-14 12:47:42 --> Controller Class Initialized
DEBUG - 2019-09-14 12:47:42 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 12:47:42 --> Helper loaded: inflector_helper
INFO - 2019-09-14 12:47:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 12:47:42 --> Final output sent to browser
DEBUG - 2019-09-14 12:47:42 --> Total execution time: 0.1607
INFO - 2019-09-14 12:53:45 --> Config Class Initialized
INFO - 2019-09-14 12:53:45 --> Hooks Class Initialized
DEBUG - 2019-09-14 12:53:45 --> UTF-8 Support Enabled
INFO - 2019-09-14 12:53:45 --> Utf8 Class Initialized
INFO - 2019-09-14 12:53:45 --> URI Class Initialized
INFO - 2019-09-14 12:53:45 --> Router Class Initialized
INFO - 2019-09-14 12:53:45 --> Output Class Initialized
INFO - 2019-09-14 12:53:45 --> Security Class Initialized
DEBUG - 2019-09-14 12:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 12:53:45 --> Input Class Initialized
INFO - 2019-09-14 12:53:45 --> Language Class Initialized
INFO - 2019-09-14 12:53:45 --> Loader Class Initialized
INFO - 2019-09-14 12:53:45 --> Helper loaded: url_helper
INFO - 2019-09-14 12:53:45 --> Helper loaded: html_helper
INFO - 2019-09-14 12:53:45 --> Helper loaded: form_helper
INFO - 2019-09-14 12:53:45 --> Helper loaded: cookie_helper
INFO - 2019-09-14 12:53:45 --> Helper loaded: date_helper
INFO - 2019-09-14 12:53:45 --> Form Validation Class Initialized
INFO - 2019-09-14 12:53:45 --> Email Class Initialized
DEBUG - 2019-09-14 12:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 12:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 12:53:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 12:53:45 --> Pagination Class Initialized
INFO - 2019-09-14 12:53:46 --> Database Driver Class Initialized
INFO - 2019-09-14 12:53:46 --> Database Driver Class Initialized
INFO - 2019-09-14 12:53:46 --> Controller Class Initialized
DEBUG - 2019-09-14 12:53:46 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 12:53:46 --> Helper loaded: inflector_helper
INFO - 2019-09-14 12:53:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 12:53:46 --> Final output sent to browser
DEBUG - 2019-09-14 12:53:46 --> Total execution time: 0.2486
INFO - 2019-09-14 12:53:59 --> Config Class Initialized
INFO - 2019-09-14 12:53:59 --> Hooks Class Initialized
DEBUG - 2019-09-14 12:53:59 --> UTF-8 Support Enabled
INFO - 2019-09-14 12:53:59 --> Utf8 Class Initialized
INFO - 2019-09-14 12:53:59 --> URI Class Initialized
INFO - 2019-09-14 12:53:59 --> Router Class Initialized
INFO - 2019-09-14 12:53:59 --> Output Class Initialized
INFO - 2019-09-14 12:53:59 --> Security Class Initialized
DEBUG - 2019-09-14 12:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 12:53:59 --> Input Class Initialized
INFO - 2019-09-14 12:53:59 --> Language Class Initialized
INFO - 2019-09-14 12:53:59 --> Loader Class Initialized
INFO - 2019-09-14 12:53:59 --> Helper loaded: url_helper
INFO - 2019-09-14 12:53:59 --> Helper loaded: html_helper
INFO - 2019-09-14 12:53:59 --> Helper loaded: form_helper
INFO - 2019-09-14 12:53:59 --> Helper loaded: cookie_helper
INFO - 2019-09-14 12:53:59 --> Helper loaded: date_helper
INFO - 2019-09-14 12:53:59 --> Form Validation Class Initialized
INFO - 2019-09-14 12:53:59 --> Email Class Initialized
DEBUG - 2019-09-14 12:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 12:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 12:53:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 12:53:59 --> Pagination Class Initialized
INFO - 2019-09-14 12:53:59 --> Database Driver Class Initialized
INFO - 2019-09-14 12:53:59 --> Database Driver Class Initialized
INFO - 2019-09-14 12:53:59 --> Controller Class Initialized
DEBUG - 2019-09-14 12:53:59 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 12:53:59 --> Helper loaded: inflector_helper
INFO - 2019-09-14 12:53:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 12:53:59 --> Final output sent to browser
DEBUG - 2019-09-14 12:53:59 --> Total execution time: 0.1621
INFO - 2019-09-14 15:00:25 --> Config Class Initialized
INFO - 2019-09-14 15:00:25 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:00:25 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:00:25 --> Utf8 Class Initialized
INFO - 2019-09-14 15:00:25 --> URI Class Initialized
INFO - 2019-09-14 15:00:25 --> Router Class Initialized
INFO - 2019-09-14 15:00:25 --> Output Class Initialized
INFO - 2019-09-14 15:00:25 --> Security Class Initialized
DEBUG - 2019-09-14 15:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:00:25 --> Input Class Initialized
INFO - 2019-09-14 15:00:25 --> Language Class Initialized
INFO - 2019-09-14 15:00:25 --> Loader Class Initialized
INFO - 2019-09-14 15:00:25 --> Helper loaded: url_helper
INFO - 2019-09-14 15:00:25 --> Helper loaded: html_helper
INFO - 2019-09-14 15:00:25 --> Helper loaded: form_helper
INFO - 2019-09-14 15:00:25 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:00:25 --> Helper loaded: date_helper
INFO - 2019-09-14 15:00:25 --> Form Validation Class Initialized
INFO - 2019-09-14 15:00:25 --> Email Class Initialized
DEBUG - 2019-09-14 15:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:00:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:00:25 --> Pagination Class Initialized
INFO - 2019-09-14 15:00:25 --> Database Driver Class Initialized
INFO - 2019-09-14 15:00:25 --> Database Driver Class Initialized
INFO - 2019-09-14 15:00:25 --> Controller Class Initialized
ERROR - 2019-09-14 15:00:25 --> Query error: Table 'pridehotel_online_reports.siteitems' doesn't exist - Invalid query: SELECT * from siteitems where 1=1 order by ID 
INFO - 2019-09-14 15:00:25 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 15:00:33 --> Config Class Initialized
INFO - 2019-09-14 15:00:33 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:00:33 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:00:33 --> Utf8 Class Initialized
INFO - 2019-09-14 15:00:33 --> URI Class Initialized
INFO - 2019-09-14 15:00:33 --> Router Class Initialized
INFO - 2019-09-14 15:00:33 --> Output Class Initialized
INFO - 2019-09-14 15:00:33 --> Security Class Initialized
DEBUG - 2019-09-14 15:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:00:33 --> Input Class Initialized
INFO - 2019-09-14 15:00:33 --> Language Class Initialized
INFO - 2019-09-14 15:00:33 --> Loader Class Initialized
INFO - 2019-09-14 15:00:33 --> Helper loaded: url_helper
INFO - 2019-09-14 15:00:33 --> Helper loaded: html_helper
INFO - 2019-09-14 15:00:33 --> Helper loaded: form_helper
INFO - 2019-09-14 15:00:33 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:00:33 --> Helper loaded: date_helper
INFO - 2019-09-14 15:00:33 --> Form Validation Class Initialized
INFO - 2019-09-14 15:00:33 --> Email Class Initialized
DEBUG - 2019-09-14 15:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:00:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:00:33 --> Pagination Class Initialized
INFO - 2019-09-14 15:00:33 --> Database Driver Class Initialized
INFO - 2019-09-14 15:00:33 --> Database Driver Class Initialized
INFO - 2019-09-14 15:00:33 --> Controller Class Initialized
ERROR - 2019-09-14 15:00:33 --> Query error: Table 'pridehotel_online_reports.siteitems' doesn't exist - Invalid query: SELECT * from siteitems where 1=1 order by ID 
INFO - 2019-09-14 15:00:33 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 15:01:04 --> Config Class Initialized
INFO - 2019-09-14 15:01:04 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:04 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:04 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:04 --> URI Class Initialized
INFO - 2019-09-14 15:01:04 --> Router Class Initialized
INFO - 2019-09-14 15:01:04 --> Output Class Initialized
INFO - 2019-09-14 15:01:04 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:04 --> Input Class Initialized
INFO - 2019-09-14 15:01:04 --> Language Class Initialized
INFO - 2019-09-14 15:01:04 --> Loader Class Initialized
INFO - 2019-09-14 15:01:04 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:04 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:04 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:04 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:04 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:04 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:04 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:04 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:04 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:04 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:04 --> Controller Class Initialized
INFO - 2019-09-14 15:01:04 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-14 15:01:04 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-09-14 15:01:04 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-14 15:01:04 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:04 --> Total execution time: 0.3111
INFO - 2019-09-14 15:01:05 --> Config Class Initialized
INFO - 2019-09-14 15:01:05 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:05 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:05 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:05 --> URI Class Initialized
INFO - 2019-09-14 15:01:05 --> Router Class Initialized
INFO - 2019-09-14 15:01:05 --> Output Class Initialized
INFO - 2019-09-14 15:01:05 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:05 --> Input Class Initialized
INFO - 2019-09-14 15:01:05 --> Language Class Initialized
INFO - 2019-09-14 15:01:05 --> Loader Class Initialized
INFO - 2019-09-14 15:01:05 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:05 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:05 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:05 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:05 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:05 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:05 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:05 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:05 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:05 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:05 --> Controller Class Initialized
INFO - 2019-09-14 15:01:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:01:05 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:05 --> Total execution time: 0.1398
INFO - 2019-09-14 15:01:05 --> Config Class Initialized
INFO - 2019-09-14 15:01:05 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:05 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:05 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:05 --> URI Class Initialized
INFO - 2019-09-14 15:01:05 --> Router Class Initialized
INFO - 2019-09-14 15:01:05 --> Output Class Initialized
INFO - 2019-09-14 15:01:05 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:05 --> Input Class Initialized
INFO - 2019-09-14 15:01:05 --> Language Class Initialized
INFO - 2019-09-14 15:01:05 --> Loader Class Initialized
INFO - 2019-09-14 15:01:05 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:05 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:05 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:05 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:05 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:05 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:05 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:05 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:05 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:05 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:05 --> Controller Class Initialized
INFO - 2019-09-14 15:01:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:01:05 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:05 --> Total execution time: 0.0518
INFO - 2019-09-14 15:01:08 --> Config Class Initialized
INFO - 2019-09-14 15:01:08 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:08 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:08 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:08 --> URI Class Initialized
INFO - 2019-09-14 15:01:08 --> Router Class Initialized
INFO - 2019-09-14 15:01:08 --> Output Class Initialized
INFO - 2019-09-14 15:01:08 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:08 --> Input Class Initialized
INFO - 2019-09-14 15:01:08 --> Language Class Initialized
INFO - 2019-09-14 15:01:08 --> Loader Class Initialized
INFO - 2019-09-14 15:01:08 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:08 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:08 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:08 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:08 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:08 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:08 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:08 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:08 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:08 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:08 --> Controller Class Initialized
INFO - 2019-09-14 15:01:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-14 15:01:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-14 15:01:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-14 15:01:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-14 15:01:08 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:08 --> Total execution time: 0.1884
INFO - 2019-09-14 15:01:08 --> Config Class Initialized
INFO - 2019-09-14 15:01:08 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:08 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:08 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:08 --> URI Class Initialized
INFO - 2019-09-14 15:01:08 --> Router Class Initialized
INFO - 2019-09-14 15:01:08 --> Output Class Initialized
INFO - 2019-09-14 15:01:08 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:08 --> Input Class Initialized
INFO - 2019-09-14 15:01:08 --> Language Class Initialized
INFO - 2019-09-14 15:01:08 --> Loader Class Initialized
INFO - 2019-09-14 15:01:08 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:08 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:08 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:08 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:08 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:08 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:08 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:08 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:08 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:08 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:08 --> Controller Class Initialized
INFO - 2019-09-14 15:01:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:01:08 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:08 --> Total execution time: 0.0561
INFO - 2019-09-14 15:01:08 --> Config Class Initialized
INFO - 2019-09-14 15:01:08 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:08 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:08 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:08 --> URI Class Initialized
INFO - 2019-09-14 15:01:08 --> Router Class Initialized
INFO - 2019-09-14 15:01:08 --> Output Class Initialized
INFO - 2019-09-14 15:01:08 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:08 --> Input Class Initialized
INFO - 2019-09-14 15:01:08 --> Language Class Initialized
INFO - 2019-09-14 15:01:08 --> Loader Class Initialized
INFO - 2019-09-14 15:01:08 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:08 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:08 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:08 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:08 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:08 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:08 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:08 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:08 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:08 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:08 --> Controller Class Initialized
INFO - 2019-09-14 15:01:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:01:08 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:08 --> Total execution time: 0.0690
INFO - 2019-09-14 15:01:09 --> Config Class Initialized
INFO - 2019-09-14 15:01:09 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:09 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:09 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:09 --> URI Class Initialized
INFO - 2019-09-14 15:01:09 --> Router Class Initialized
INFO - 2019-09-14 15:01:09 --> Output Class Initialized
INFO - 2019-09-14 15:01:09 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:09 --> Input Class Initialized
INFO - 2019-09-14 15:01:09 --> Language Class Initialized
INFO - 2019-09-14 15:01:09 --> Loader Class Initialized
INFO - 2019-09-14 15:01:09 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:09 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:09 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:09 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:09 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:09 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:09 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:09 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:09 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:09 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:09 --> Controller Class Initialized
INFO - 2019-09-14 15:01:10 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-14 15:01:10 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-14 15:01:10 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-14 15:01:10 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-14 15:01:10 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:10 --> Total execution time: 0.1080
INFO - 2019-09-14 15:01:10 --> Config Class Initialized
INFO - 2019-09-14 15:01:10 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:10 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:10 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:10 --> URI Class Initialized
INFO - 2019-09-14 15:01:10 --> Router Class Initialized
INFO - 2019-09-14 15:01:10 --> Output Class Initialized
INFO - 2019-09-14 15:01:10 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:10 --> Input Class Initialized
INFO - 2019-09-14 15:01:10 --> Language Class Initialized
INFO - 2019-09-14 15:01:10 --> Loader Class Initialized
INFO - 2019-09-14 15:01:10 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:10 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:10 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:10 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:10 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:10 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:10 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:10 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:10 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:10 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:10 --> Controller Class Initialized
INFO - 2019-09-14 15:01:10 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:01:10 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:10 --> Total execution time: 0.0582
INFO - 2019-09-14 15:01:10 --> Config Class Initialized
INFO - 2019-09-14 15:01:10 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:10 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:10 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:10 --> URI Class Initialized
INFO - 2019-09-14 15:01:10 --> Router Class Initialized
INFO - 2019-09-14 15:01:10 --> Output Class Initialized
INFO - 2019-09-14 15:01:10 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:10 --> Input Class Initialized
INFO - 2019-09-14 15:01:10 --> Language Class Initialized
INFO - 2019-09-14 15:01:10 --> Loader Class Initialized
INFO - 2019-09-14 15:01:10 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:10 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:10 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:10 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:10 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:10 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:10 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:10 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:10 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:10 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:10 --> Controller Class Initialized
INFO - 2019-09-14 15:01:10 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:01:10 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:10 --> Total execution time: 0.0509
INFO - 2019-09-14 15:01:17 --> Config Class Initialized
INFO - 2019-09-14 15:01:17 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:17 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:17 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:17 --> URI Class Initialized
INFO - 2019-09-14 15:01:17 --> Router Class Initialized
INFO - 2019-09-14 15:01:17 --> Output Class Initialized
INFO - 2019-09-14 15:01:17 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:17 --> Input Class Initialized
INFO - 2019-09-14 15:01:17 --> Language Class Initialized
INFO - 2019-09-14 15:01:17 --> Loader Class Initialized
INFO - 2019-09-14 15:01:17 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:17 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:17 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:17 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:17 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:17 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:17 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:17 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:17 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:17 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:17 --> Controller Class Initialized
ERROR - 2019-09-14 15:01:18 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-14 15:01:18 --> Config Class Initialized
INFO - 2019-09-14 15:01:18 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:18 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:18 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:18 --> URI Class Initialized
INFO - 2019-09-14 15:01:18 --> Router Class Initialized
INFO - 2019-09-14 15:01:18 --> Output Class Initialized
INFO - 2019-09-14 15:01:18 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:18 --> Input Class Initialized
INFO - 2019-09-14 15:01:18 --> Language Class Initialized
INFO - 2019-09-14 15:01:18 --> Loader Class Initialized
INFO - 2019-09-14 15:01:18 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:18 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:18 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:18 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:18 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:18 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:18 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:18 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:18 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:18 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:18 --> Controller Class Initialized
ERROR - 2019-09-14 15:01:18 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-14 15:01:18 --> Config Class Initialized
INFO - 2019-09-14 15:01:18 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:18 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:18 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:18 --> URI Class Initialized
INFO - 2019-09-14 15:01:18 --> Router Class Initialized
INFO - 2019-09-14 15:01:18 --> Output Class Initialized
INFO - 2019-09-14 15:01:18 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:18 --> Input Class Initialized
INFO - 2019-09-14 15:01:18 --> Language Class Initialized
INFO - 2019-09-14 15:01:18 --> Loader Class Initialized
INFO - 2019-09-14 15:01:18 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:18 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:18 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:18 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:18 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:18 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:18 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:18 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:18 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:18 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:18 --> Controller Class Initialized
ERROR - 2019-09-14 15:01:18 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-14 15:01:18 --> Config Class Initialized
INFO - 2019-09-14 15:01:18 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:18 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:18 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:18 --> URI Class Initialized
INFO - 2019-09-14 15:01:18 --> Router Class Initialized
INFO - 2019-09-14 15:01:18 --> Output Class Initialized
INFO - 2019-09-14 15:01:18 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:18 --> Input Class Initialized
INFO - 2019-09-14 15:01:18 --> Language Class Initialized
INFO - 2019-09-14 15:01:18 --> Loader Class Initialized
INFO - 2019-09-14 15:01:18 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:18 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:18 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:18 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:18 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:18 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:18 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:18 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:18 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:18 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:18 --> Controller Class Initialized
ERROR - 2019-09-14 15:01:18 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-14 15:01:18 --> Config Class Initialized
INFO - 2019-09-14 15:01:18 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:18 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:18 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:18 --> URI Class Initialized
INFO - 2019-09-14 15:01:19 --> Router Class Initialized
INFO - 2019-09-14 15:01:19 --> Output Class Initialized
INFO - 2019-09-14 15:01:19 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:19 --> Input Class Initialized
INFO - 2019-09-14 15:01:19 --> Language Class Initialized
INFO - 2019-09-14 15:01:19 --> Loader Class Initialized
INFO - 2019-09-14 15:01:19 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:19 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:19 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:19 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:19 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:19 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:19 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:19 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:19 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:19 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:19 --> Controller Class Initialized
ERROR - 2019-09-14 15:01:19 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-14 15:01:19 --> Config Class Initialized
INFO - 2019-09-14 15:01:19 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:19 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:19 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:19 --> URI Class Initialized
INFO - 2019-09-14 15:01:19 --> Router Class Initialized
INFO - 2019-09-14 15:01:19 --> Output Class Initialized
INFO - 2019-09-14 15:01:19 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:19 --> Input Class Initialized
INFO - 2019-09-14 15:01:19 --> Language Class Initialized
INFO - 2019-09-14 15:01:19 --> Loader Class Initialized
INFO - 2019-09-14 15:01:19 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:19 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:19 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:19 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:19 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:19 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:19 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:19 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:19 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:19 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:19 --> Controller Class Initialized
ERROR - 2019-09-14 15:01:19 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-14 15:01:19 --> Config Class Initialized
INFO - 2019-09-14 15:01:19 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:19 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:19 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:19 --> URI Class Initialized
INFO - 2019-09-14 15:01:19 --> Router Class Initialized
INFO - 2019-09-14 15:01:19 --> Output Class Initialized
INFO - 2019-09-14 15:01:19 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:19 --> Input Class Initialized
INFO - 2019-09-14 15:01:19 --> Language Class Initialized
INFO - 2019-09-14 15:01:19 --> Loader Class Initialized
INFO - 2019-09-14 15:01:19 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:19 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:19 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:19 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:19 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:19 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:19 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:19 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:19 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:19 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:19 --> Controller Class Initialized
ERROR - 2019-09-14 15:01:19 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-14 15:01:20 --> Config Class Initialized
INFO - 2019-09-14 15:01:20 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:20 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:20 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:20 --> URI Class Initialized
INFO - 2019-09-14 15:01:20 --> Router Class Initialized
INFO - 2019-09-14 15:01:20 --> Output Class Initialized
INFO - 2019-09-14 15:01:20 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:20 --> Input Class Initialized
INFO - 2019-09-14 15:01:20 --> Language Class Initialized
INFO - 2019-09-14 15:01:20 --> Loader Class Initialized
INFO - 2019-09-14 15:01:20 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:20 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:20 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:20 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:20 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:20 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:20 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:20 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:20 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:20 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:20 --> Controller Class Initialized
ERROR - 2019-09-14 15:01:20 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-14 15:01:20 --> Config Class Initialized
INFO - 2019-09-14 15:01:20 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:20 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:20 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:20 --> URI Class Initialized
INFO - 2019-09-14 15:01:20 --> Router Class Initialized
INFO - 2019-09-14 15:01:20 --> Output Class Initialized
INFO - 2019-09-14 15:01:20 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:20 --> Input Class Initialized
INFO - 2019-09-14 15:01:20 --> Language Class Initialized
INFO - 2019-09-14 15:01:20 --> Loader Class Initialized
INFO - 2019-09-14 15:01:20 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:20 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:20 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:20 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:20 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:20 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:20 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:20 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:20 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:20 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:20 --> Controller Class Initialized
ERROR - 2019-09-14 15:01:20 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-14 15:01:21 --> Config Class Initialized
INFO - 2019-09-14 15:01:21 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:21 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:21 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:21 --> URI Class Initialized
INFO - 2019-09-14 15:01:21 --> Router Class Initialized
INFO - 2019-09-14 15:01:21 --> Output Class Initialized
INFO - 2019-09-14 15:01:21 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:21 --> Input Class Initialized
INFO - 2019-09-14 15:01:21 --> Language Class Initialized
INFO - 2019-09-14 15:01:21 --> Loader Class Initialized
INFO - 2019-09-14 15:01:21 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:21 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:21 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:21 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:21 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:21 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:21 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:21 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:21 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:21 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:21 --> Controller Class Initialized
ERROR - 2019-09-14 15:01:21 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-14 15:01:21 --> Config Class Initialized
INFO - 2019-09-14 15:01:21 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:21 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:21 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:21 --> URI Class Initialized
INFO - 2019-09-14 15:01:21 --> Router Class Initialized
INFO - 2019-09-14 15:01:21 --> Output Class Initialized
INFO - 2019-09-14 15:01:21 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:21 --> Input Class Initialized
INFO - 2019-09-14 15:01:21 --> Language Class Initialized
INFO - 2019-09-14 15:01:21 --> Loader Class Initialized
INFO - 2019-09-14 15:01:21 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:21 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:21 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:21 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:21 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:21 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:21 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:21 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:21 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:21 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:21 --> Controller Class Initialized
ERROR - 2019-09-14 15:01:21 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-14 15:01:21 --> Config Class Initialized
INFO - 2019-09-14 15:01:21 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:21 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:21 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:21 --> URI Class Initialized
INFO - 2019-09-14 15:01:21 --> Router Class Initialized
INFO - 2019-09-14 15:01:21 --> Output Class Initialized
INFO - 2019-09-14 15:01:21 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:21 --> Input Class Initialized
INFO - 2019-09-14 15:01:21 --> Language Class Initialized
INFO - 2019-09-14 15:01:21 --> Loader Class Initialized
INFO - 2019-09-14 15:01:21 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:21 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:21 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:21 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:21 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:21 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:21 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:21 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:21 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:21 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:21 --> Controller Class Initialized
ERROR - 2019-09-14 15:01:21 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-14 15:01:24 --> Config Class Initialized
INFO - 2019-09-14 15:01:24 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:24 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:24 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:24 --> URI Class Initialized
INFO - 2019-09-14 15:01:24 --> Router Class Initialized
INFO - 2019-09-14 15:01:24 --> Output Class Initialized
INFO - 2019-09-14 15:01:24 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:24 --> Input Class Initialized
INFO - 2019-09-14 15:01:24 --> Language Class Initialized
INFO - 2019-09-14 15:01:24 --> Loader Class Initialized
INFO - 2019-09-14 15:01:24 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:24 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:24 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:24 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:24 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:24 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:24 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:24 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:24 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:24 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:24 --> Controller Class Initialized
INFO - 2019-09-14 15:01:24 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:24 --> Total execution time: 0.0961
INFO - 2019-09-14 15:01:28 --> Config Class Initialized
INFO - 2019-09-14 15:01:28 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:28 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:28 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:28 --> URI Class Initialized
INFO - 2019-09-14 15:01:28 --> Router Class Initialized
INFO - 2019-09-14 15:01:28 --> Output Class Initialized
INFO - 2019-09-14 15:01:28 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:28 --> Input Class Initialized
INFO - 2019-09-14 15:01:28 --> Language Class Initialized
INFO - 2019-09-14 15:01:28 --> Loader Class Initialized
INFO - 2019-09-14 15:01:28 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:28 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:28 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:28 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:28 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:28 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:28 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:28 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:28 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:28 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:28 --> Controller Class Initialized
INFO - 2019-09-14 15:01:28 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:28 --> Total execution time: 0.0839
INFO - 2019-09-14 15:01:32 --> Config Class Initialized
INFO - 2019-09-14 15:01:32 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:32 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:32 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:32 --> URI Class Initialized
INFO - 2019-09-14 15:01:32 --> Router Class Initialized
INFO - 2019-09-14 15:01:32 --> Output Class Initialized
INFO - 2019-09-14 15:01:32 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:32 --> Input Class Initialized
INFO - 2019-09-14 15:01:32 --> Language Class Initialized
INFO - 2019-09-14 15:01:32 --> Loader Class Initialized
INFO - 2019-09-14 15:01:32 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:32 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:32 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:32 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:32 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:32 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:32 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:32 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:32 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:32 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:32 --> Controller Class Initialized
INFO - 2019-09-14 15:01:32 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:32 --> Total execution time: 0.0487
INFO - 2019-09-14 15:01:38 --> Config Class Initialized
INFO - 2019-09-14 15:01:38 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:38 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:38 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:38 --> URI Class Initialized
INFO - 2019-09-14 15:01:38 --> Router Class Initialized
INFO - 2019-09-14 15:01:38 --> Output Class Initialized
INFO - 2019-09-14 15:01:38 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:38 --> Input Class Initialized
INFO - 2019-09-14 15:01:38 --> Language Class Initialized
INFO - 2019-09-14 15:01:38 --> Loader Class Initialized
INFO - 2019-09-14 15:01:38 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:38 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:38 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:38 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:38 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:38 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:38 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:38 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:38 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:38 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:38 --> Controller Class Initialized
INFO - 2019-09-14 15:01:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:01:38 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:38 --> Total execution time: 0.0522
INFO - 2019-09-14 15:01:38 --> Config Class Initialized
INFO - 2019-09-14 15:01:38 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:38 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:38 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:38 --> URI Class Initialized
INFO - 2019-09-14 15:01:38 --> Router Class Initialized
INFO - 2019-09-14 15:01:38 --> Output Class Initialized
INFO - 2019-09-14 15:01:38 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:38 --> Input Class Initialized
INFO - 2019-09-14 15:01:38 --> Language Class Initialized
INFO - 2019-09-14 15:01:38 --> Loader Class Initialized
INFO - 2019-09-14 15:01:38 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:38 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:38 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:38 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:38 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:38 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:38 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:38 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:38 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:38 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:38 --> Controller Class Initialized
INFO - 2019-09-14 15:01:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:01:38 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:38 --> Total execution time: 0.0507
INFO - 2019-09-14 15:01:40 --> Config Class Initialized
INFO - 2019-09-14 15:01:40 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:40 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:40 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:40 --> URI Class Initialized
INFO - 2019-09-14 15:01:40 --> Router Class Initialized
INFO - 2019-09-14 15:01:40 --> Output Class Initialized
INFO - 2019-09-14 15:01:40 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:40 --> Input Class Initialized
INFO - 2019-09-14 15:01:40 --> Language Class Initialized
INFO - 2019-09-14 15:01:40 --> Loader Class Initialized
INFO - 2019-09-14 15:01:40 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:40 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:40 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:40 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:40 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:40 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:40 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:40 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:40 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:40 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:40 --> Controller Class Initialized
INFO - 2019-09-14 15:01:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-14 15:01:40 --> Config Class Initialized
INFO - 2019-09-14 15:01:40 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:40 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:40 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:40 --> URI Class Initialized
INFO - 2019-09-14 15:01:40 --> Router Class Initialized
INFO - 2019-09-14 15:01:40 --> Output Class Initialized
INFO - 2019-09-14 15:01:40 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:40 --> Input Class Initialized
INFO - 2019-09-14 15:01:40 --> Language Class Initialized
INFO - 2019-09-14 15:01:40 --> Loader Class Initialized
INFO - 2019-09-14 15:01:40 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:40 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:40 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:40 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:40 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:40 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:40 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:40 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:40 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:40 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:40 --> Controller Class Initialized
INFO - 2019-09-14 15:01:40 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-14 15:01:40 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-14 15:01:40 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-14 15:01:40 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-14 15:01:40 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:40 --> Total execution time: 0.0734
INFO - 2019-09-14 15:01:40 --> Config Class Initialized
INFO - 2019-09-14 15:01:40 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:40 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:40 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:40 --> URI Class Initialized
INFO - 2019-09-14 15:01:40 --> Router Class Initialized
INFO - 2019-09-14 15:01:40 --> Output Class Initialized
INFO - 2019-09-14 15:01:40 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:40 --> Input Class Initialized
INFO - 2019-09-14 15:01:40 --> Language Class Initialized
INFO - 2019-09-14 15:01:40 --> Loader Class Initialized
INFO - 2019-09-14 15:01:40 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:40 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:40 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:40 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:40 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:40 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:40 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:40 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:40 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:40 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:40 --> Controller Class Initialized
INFO - 2019-09-14 15:01:40 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:01:40 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:40 --> Total execution time: 0.0565
INFO - 2019-09-14 15:01:40 --> Config Class Initialized
INFO - 2019-09-14 15:01:40 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:40 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:40 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:40 --> URI Class Initialized
INFO - 2019-09-14 15:01:40 --> Router Class Initialized
INFO - 2019-09-14 15:01:40 --> Output Class Initialized
INFO - 2019-09-14 15:01:40 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:40 --> Input Class Initialized
INFO - 2019-09-14 15:01:40 --> Language Class Initialized
INFO - 2019-09-14 15:01:40 --> Loader Class Initialized
INFO - 2019-09-14 15:01:40 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:40 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:40 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:40 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:40 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:40 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:40 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:40 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:40 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:40 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:40 --> Controller Class Initialized
INFO - 2019-09-14 15:01:40 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:01:40 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:40 --> Total execution time: 0.0555
INFO - 2019-09-14 15:01:42 --> Config Class Initialized
INFO - 2019-09-14 15:01:42 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:42 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:42 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:42 --> URI Class Initialized
INFO - 2019-09-14 15:01:42 --> Router Class Initialized
INFO - 2019-09-14 15:01:42 --> Output Class Initialized
INFO - 2019-09-14 15:01:42 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:42 --> Input Class Initialized
INFO - 2019-09-14 15:01:42 --> Language Class Initialized
INFO - 2019-09-14 15:01:42 --> Loader Class Initialized
INFO - 2019-09-14 15:01:42 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:42 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:42 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:42 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:42 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:42 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:42 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:42 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:42 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:42 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:42 --> Controller Class Initialized
INFO - 2019-09-14 15:01:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-14 15:01:42 --> Config Class Initialized
INFO - 2019-09-14 15:01:42 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:42 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:42 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:42 --> URI Class Initialized
INFO - 2019-09-14 15:01:42 --> Router Class Initialized
INFO - 2019-09-14 15:01:42 --> Output Class Initialized
INFO - 2019-09-14 15:01:42 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:42 --> Input Class Initialized
INFO - 2019-09-14 15:01:42 --> Language Class Initialized
INFO - 2019-09-14 15:01:42 --> Loader Class Initialized
INFO - 2019-09-14 15:01:42 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:42 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:42 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:42 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:42 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:42 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:42 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:42 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:42 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:42 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:42 --> Controller Class Initialized
INFO - 2019-09-14 15:01:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-14 15:01:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-14 15:01:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-14 15:01:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-14 15:01:42 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:42 --> Total execution time: 0.0757
INFO - 2019-09-14 15:01:42 --> Config Class Initialized
INFO - 2019-09-14 15:01:42 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:42 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:42 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:43 --> URI Class Initialized
INFO - 2019-09-14 15:01:43 --> Router Class Initialized
INFO - 2019-09-14 15:01:43 --> Output Class Initialized
INFO - 2019-09-14 15:01:43 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:43 --> Input Class Initialized
INFO - 2019-09-14 15:01:43 --> Language Class Initialized
INFO - 2019-09-14 15:01:43 --> Loader Class Initialized
INFO - 2019-09-14 15:01:43 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:43 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:43 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:43 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:43 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:43 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:43 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:43 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:43 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:43 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:43 --> Controller Class Initialized
INFO - 2019-09-14 15:01:43 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:01:43 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:43 --> Total execution time: 0.0552
INFO - 2019-09-14 15:01:43 --> Config Class Initialized
INFO - 2019-09-14 15:01:43 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:43 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:43 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:43 --> URI Class Initialized
INFO - 2019-09-14 15:01:43 --> Router Class Initialized
INFO - 2019-09-14 15:01:43 --> Output Class Initialized
INFO - 2019-09-14 15:01:43 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:43 --> Input Class Initialized
INFO - 2019-09-14 15:01:43 --> Language Class Initialized
INFO - 2019-09-14 15:01:43 --> Loader Class Initialized
INFO - 2019-09-14 15:01:43 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:43 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:43 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:43 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:43 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:43 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:43 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:43 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:43 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:43 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:43 --> Controller Class Initialized
INFO - 2019-09-14 15:01:43 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:01:43 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:43 --> Total execution time: 0.0589
INFO - 2019-09-14 15:01:46 --> Config Class Initialized
INFO - 2019-09-14 15:01:46 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:01:46 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:01:46 --> Utf8 Class Initialized
INFO - 2019-09-14 15:01:46 --> URI Class Initialized
INFO - 2019-09-14 15:01:46 --> Router Class Initialized
INFO - 2019-09-14 15:01:46 --> Output Class Initialized
INFO - 2019-09-14 15:01:46 --> Security Class Initialized
DEBUG - 2019-09-14 15:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:01:46 --> Input Class Initialized
INFO - 2019-09-14 15:01:46 --> Language Class Initialized
INFO - 2019-09-14 15:01:46 --> Loader Class Initialized
INFO - 2019-09-14 15:01:46 --> Helper loaded: url_helper
INFO - 2019-09-14 15:01:46 --> Helper loaded: html_helper
INFO - 2019-09-14 15:01:46 --> Helper loaded: form_helper
INFO - 2019-09-14 15:01:46 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:01:46 --> Helper loaded: date_helper
INFO - 2019-09-14 15:01:46 --> Form Validation Class Initialized
INFO - 2019-09-14 15:01:46 --> Email Class Initialized
DEBUG - 2019-09-14 15:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:01:46 --> Pagination Class Initialized
INFO - 2019-09-14 15:01:46 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:46 --> Database Driver Class Initialized
INFO - 2019-09-14 15:01:46 --> Controller Class Initialized
INFO - 2019-09-14 15:01:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:01:46 --> Final output sent to browser
DEBUG - 2019-09-14 15:01:46 --> Total execution time: 0.0490
INFO - 2019-09-14 15:02:04 --> Config Class Initialized
INFO - 2019-09-14 15:02:04 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:02:04 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:02:04 --> Utf8 Class Initialized
INFO - 2019-09-14 15:02:04 --> URI Class Initialized
INFO - 2019-09-14 15:02:04 --> Router Class Initialized
INFO - 2019-09-14 15:02:04 --> Output Class Initialized
INFO - 2019-09-14 15:02:04 --> Security Class Initialized
DEBUG - 2019-09-14 15:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:02:04 --> Input Class Initialized
INFO - 2019-09-14 15:02:04 --> Language Class Initialized
INFO - 2019-09-14 15:02:04 --> Loader Class Initialized
INFO - 2019-09-14 15:02:04 --> Helper loaded: url_helper
INFO - 2019-09-14 15:02:04 --> Helper loaded: html_helper
INFO - 2019-09-14 15:02:04 --> Helper loaded: form_helper
INFO - 2019-09-14 15:02:04 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:02:04 --> Helper loaded: date_helper
INFO - 2019-09-14 15:02:04 --> Form Validation Class Initialized
INFO - 2019-09-14 15:02:04 --> Email Class Initialized
DEBUG - 2019-09-14 15:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:02:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:02:04 --> Pagination Class Initialized
INFO - 2019-09-14 15:02:04 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:04 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:04 --> Controller Class Initialized
ERROR - 2019-09-14 15:02:04 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-14 15:02:04 --> Config Class Initialized
INFO - 2019-09-14 15:02:04 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:02:04 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:02:04 --> Utf8 Class Initialized
INFO - 2019-09-14 15:02:04 --> URI Class Initialized
INFO - 2019-09-14 15:02:04 --> Router Class Initialized
INFO - 2019-09-14 15:02:04 --> Output Class Initialized
INFO - 2019-09-14 15:02:04 --> Security Class Initialized
DEBUG - 2019-09-14 15:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:02:04 --> Input Class Initialized
INFO - 2019-09-14 15:02:04 --> Language Class Initialized
INFO - 2019-09-14 15:02:04 --> Loader Class Initialized
INFO - 2019-09-14 15:02:04 --> Helper loaded: url_helper
INFO - 2019-09-14 15:02:04 --> Helper loaded: html_helper
INFO - 2019-09-14 15:02:04 --> Helper loaded: form_helper
INFO - 2019-09-14 15:02:04 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:02:04 --> Helper loaded: date_helper
INFO - 2019-09-14 15:02:04 --> Form Validation Class Initialized
INFO - 2019-09-14 15:02:04 --> Email Class Initialized
DEBUG - 2019-09-14 15:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:02:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:02:04 --> Pagination Class Initialized
INFO - 2019-09-14 15:02:04 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:04 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:04 --> Controller Class Initialized
ERROR - 2019-09-14 15:02:04 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-14 15:02:05 --> Config Class Initialized
INFO - 2019-09-14 15:02:05 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:02:05 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:02:05 --> Utf8 Class Initialized
INFO - 2019-09-14 15:02:05 --> URI Class Initialized
INFO - 2019-09-14 15:02:05 --> Router Class Initialized
INFO - 2019-09-14 15:02:05 --> Output Class Initialized
INFO - 2019-09-14 15:02:05 --> Security Class Initialized
DEBUG - 2019-09-14 15:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:02:05 --> Input Class Initialized
INFO - 2019-09-14 15:02:05 --> Language Class Initialized
INFO - 2019-09-14 15:02:05 --> Loader Class Initialized
INFO - 2019-09-14 15:02:05 --> Helper loaded: url_helper
INFO - 2019-09-14 15:02:05 --> Helper loaded: html_helper
INFO - 2019-09-14 15:02:05 --> Helper loaded: form_helper
INFO - 2019-09-14 15:02:05 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:02:05 --> Helper loaded: date_helper
INFO - 2019-09-14 15:02:05 --> Form Validation Class Initialized
INFO - 2019-09-14 15:02:05 --> Email Class Initialized
DEBUG - 2019-09-14 15:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:02:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:02:05 --> Pagination Class Initialized
INFO - 2019-09-14 15:02:05 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:05 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:05 --> Controller Class Initialized
ERROR - 2019-09-14 15:02:05 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-14 15:02:07 --> Config Class Initialized
INFO - 2019-09-14 15:02:07 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:02:07 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:02:07 --> Utf8 Class Initialized
INFO - 2019-09-14 15:02:07 --> URI Class Initialized
INFO - 2019-09-14 15:02:07 --> Router Class Initialized
INFO - 2019-09-14 15:02:07 --> Output Class Initialized
INFO - 2019-09-14 15:02:07 --> Security Class Initialized
DEBUG - 2019-09-14 15:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:02:07 --> Input Class Initialized
INFO - 2019-09-14 15:02:07 --> Language Class Initialized
INFO - 2019-09-14 15:02:07 --> Loader Class Initialized
INFO - 2019-09-14 15:02:07 --> Helper loaded: url_helper
INFO - 2019-09-14 15:02:07 --> Helper loaded: html_helper
INFO - 2019-09-14 15:02:07 --> Helper loaded: form_helper
INFO - 2019-09-14 15:02:07 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:02:07 --> Helper loaded: date_helper
INFO - 2019-09-14 15:02:07 --> Form Validation Class Initialized
INFO - 2019-09-14 15:02:07 --> Email Class Initialized
DEBUG - 2019-09-14 15:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:02:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:02:07 --> Pagination Class Initialized
INFO - 2019-09-14 15:02:07 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:07 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:07 --> Controller Class Initialized
INFO - 2019-09-14 15:02:07 --> Final output sent to browser
DEBUG - 2019-09-14 15:02:07 --> Total execution time: 0.0507
INFO - 2019-09-14 15:02:11 --> Config Class Initialized
INFO - 2019-09-14 15:02:11 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:02:11 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:02:11 --> Utf8 Class Initialized
INFO - 2019-09-14 15:02:11 --> URI Class Initialized
INFO - 2019-09-14 15:02:11 --> Router Class Initialized
INFO - 2019-09-14 15:02:11 --> Output Class Initialized
INFO - 2019-09-14 15:02:11 --> Security Class Initialized
DEBUG - 2019-09-14 15:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:02:11 --> Input Class Initialized
INFO - 2019-09-14 15:02:11 --> Language Class Initialized
INFO - 2019-09-14 15:02:11 --> Loader Class Initialized
INFO - 2019-09-14 15:02:11 --> Helper loaded: url_helper
INFO - 2019-09-14 15:02:11 --> Helper loaded: html_helper
INFO - 2019-09-14 15:02:11 --> Helper loaded: form_helper
INFO - 2019-09-14 15:02:11 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:02:11 --> Helper loaded: date_helper
INFO - 2019-09-14 15:02:11 --> Form Validation Class Initialized
INFO - 2019-09-14 15:02:11 --> Email Class Initialized
DEBUG - 2019-09-14 15:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:02:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:02:11 --> Pagination Class Initialized
INFO - 2019-09-14 15:02:11 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:11 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:11 --> Controller Class Initialized
INFO - 2019-09-14 15:02:11 --> Final output sent to browser
DEBUG - 2019-09-14 15:02:11 --> Total execution time: 0.0628
INFO - 2019-09-14 15:02:14 --> Config Class Initialized
INFO - 2019-09-14 15:02:14 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:02:14 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:02:14 --> Utf8 Class Initialized
INFO - 2019-09-14 15:02:14 --> URI Class Initialized
INFO - 2019-09-14 15:02:14 --> Router Class Initialized
INFO - 2019-09-14 15:02:14 --> Output Class Initialized
INFO - 2019-09-14 15:02:14 --> Security Class Initialized
DEBUG - 2019-09-14 15:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:02:14 --> Input Class Initialized
INFO - 2019-09-14 15:02:14 --> Language Class Initialized
INFO - 2019-09-14 15:02:14 --> Loader Class Initialized
INFO - 2019-09-14 15:02:14 --> Helper loaded: url_helper
INFO - 2019-09-14 15:02:14 --> Helper loaded: html_helper
INFO - 2019-09-14 15:02:14 --> Helper loaded: form_helper
INFO - 2019-09-14 15:02:14 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:02:14 --> Helper loaded: date_helper
INFO - 2019-09-14 15:02:14 --> Form Validation Class Initialized
INFO - 2019-09-14 15:02:14 --> Email Class Initialized
DEBUG - 2019-09-14 15:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:02:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:02:14 --> Pagination Class Initialized
INFO - 2019-09-14 15:02:14 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:14 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:14 --> Controller Class Initialized
INFO - 2019-09-14 15:02:14 --> Final output sent to browser
DEBUG - 2019-09-14 15:02:14 --> Total execution time: 0.0583
INFO - 2019-09-14 15:02:18 --> Config Class Initialized
INFO - 2019-09-14 15:02:18 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:02:18 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:02:18 --> Utf8 Class Initialized
INFO - 2019-09-14 15:02:18 --> URI Class Initialized
INFO - 2019-09-14 15:02:18 --> Router Class Initialized
INFO - 2019-09-14 15:02:18 --> Output Class Initialized
INFO - 2019-09-14 15:02:18 --> Security Class Initialized
DEBUG - 2019-09-14 15:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:02:18 --> Input Class Initialized
INFO - 2019-09-14 15:02:18 --> Language Class Initialized
INFO - 2019-09-14 15:02:18 --> Loader Class Initialized
INFO - 2019-09-14 15:02:18 --> Helper loaded: url_helper
INFO - 2019-09-14 15:02:18 --> Helper loaded: html_helper
INFO - 2019-09-14 15:02:18 --> Helper loaded: form_helper
INFO - 2019-09-14 15:02:18 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:02:18 --> Helper loaded: date_helper
INFO - 2019-09-14 15:02:18 --> Form Validation Class Initialized
INFO - 2019-09-14 15:02:18 --> Email Class Initialized
DEBUG - 2019-09-14 15:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:02:18 --> Pagination Class Initialized
INFO - 2019-09-14 15:02:18 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:18 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:18 --> Controller Class Initialized
INFO - 2019-09-14 15:02:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-14 15:02:18 --> Config Class Initialized
INFO - 2019-09-14 15:02:18 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:02:18 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:02:18 --> Utf8 Class Initialized
INFO - 2019-09-14 15:02:18 --> URI Class Initialized
INFO - 2019-09-14 15:02:18 --> Router Class Initialized
INFO - 2019-09-14 15:02:18 --> Output Class Initialized
INFO - 2019-09-14 15:02:18 --> Security Class Initialized
DEBUG - 2019-09-14 15:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:02:18 --> Input Class Initialized
INFO - 2019-09-14 15:02:18 --> Language Class Initialized
INFO - 2019-09-14 15:02:18 --> Loader Class Initialized
INFO - 2019-09-14 15:02:18 --> Helper loaded: url_helper
INFO - 2019-09-14 15:02:18 --> Helper loaded: html_helper
INFO - 2019-09-14 15:02:18 --> Helper loaded: form_helper
INFO - 2019-09-14 15:02:18 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:02:18 --> Helper loaded: date_helper
INFO - 2019-09-14 15:02:18 --> Form Validation Class Initialized
INFO - 2019-09-14 15:02:18 --> Email Class Initialized
DEBUG - 2019-09-14 15:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:02:18 --> Pagination Class Initialized
INFO - 2019-09-14 15:02:18 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:18 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:18 --> Controller Class Initialized
INFO - 2019-09-14 15:02:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-14 15:02:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-14 15:02:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-14 15:02:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-14 15:02:18 --> Final output sent to browser
DEBUG - 2019-09-14 15:02:18 --> Total execution time: 0.0631
INFO - 2019-09-14 15:02:18 --> Config Class Initialized
INFO - 2019-09-14 15:02:18 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:02:18 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:02:18 --> Utf8 Class Initialized
INFO - 2019-09-14 15:02:18 --> URI Class Initialized
INFO - 2019-09-14 15:02:18 --> Router Class Initialized
INFO - 2019-09-14 15:02:18 --> Output Class Initialized
INFO - 2019-09-14 15:02:18 --> Security Class Initialized
DEBUG - 2019-09-14 15:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:02:18 --> Input Class Initialized
INFO - 2019-09-14 15:02:18 --> Language Class Initialized
INFO - 2019-09-14 15:02:18 --> Loader Class Initialized
INFO - 2019-09-14 15:02:18 --> Helper loaded: url_helper
INFO - 2019-09-14 15:02:18 --> Helper loaded: html_helper
INFO - 2019-09-14 15:02:18 --> Helper loaded: form_helper
INFO - 2019-09-14 15:02:18 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:02:18 --> Helper loaded: date_helper
INFO - 2019-09-14 15:02:18 --> Form Validation Class Initialized
INFO - 2019-09-14 15:02:18 --> Email Class Initialized
DEBUG - 2019-09-14 15:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:02:18 --> Pagination Class Initialized
INFO - 2019-09-14 15:02:18 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:18 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:18 --> Controller Class Initialized
INFO - 2019-09-14 15:02:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:02:18 --> Final output sent to browser
DEBUG - 2019-09-14 15:02:18 --> Total execution time: 0.0526
INFO - 2019-09-14 15:02:18 --> Config Class Initialized
INFO - 2019-09-14 15:02:18 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:02:18 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:02:18 --> Utf8 Class Initialized
INFO - 2019-09-14 15:02:18 --> URI Class Initialized
INFO - 2019-09-14 15:02:18 --> Router Class Initialized
INFO - 2019-09-14 15:02:18 --> Output Class Initialized
INFO - 2019-09-14 15:02:18 --> Security Class Initialized
DEBUG - 2019-09-14 15:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:02:18 --> Input Class Initialized
INFO - 2019-09-14 15:02:18 --> Language Class Initialized
INFO - 2019-09-14 15:02:18 --> Loader Class Initialized
INFO - 2019-09-14 15:02:18 --> Helper loaded: url_helper
INFO - 2019-09-14 15:02:18 --> Helper loaded: html_helper
INFO - 2019-09-14 15:02:18 --> Helper loaded: form_helper
INFO - 2019-09-14 15:02:18 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:02:18 --> Helper loaded: date_helper
INFO - 2019-09-14 15:02:18 --> Form Validation Class Initialized
INFO - 2019-09-14 15:02:18 --> Email Class Initialized
DEBUG - 2019-09-14 15:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:02:18 --> Pagination Class Initialized
INFO - 2019-09-14 15:02:18 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:18 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:18 --> Controller Class Initialized
INFO - 2019-09-14 15:02:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:02:18 --> Final output sent to browser
DEBUG - 2019-09-14 15:02:18 --> Total execution time: 0.0518
INFO - 2019-09-14 15:02:20 --> Config Class Initialized
INFO - 2019-09-14 15:02:20 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:02:20 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:02:20 --> Utf8 Class Initialized
INFO - 2019-09-14 15:02:20 --> URI Class Initialized
INFO - 2019-09-14 15:02:20 --> Router Class Initialized
INFO - 2019-09-14 15:02:20 --> Output Class Initialized
INFO - 2019-09-14 15:02:20 --> Security Class Initialized
DEBUG - 2019-09-14 15:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:02:20 --> Input Class Initialized
INFO - 2019-09-14 15:02:20 --> Language Class Initialized
INFO - 2019-09-14 15:02:20 --> Loader Class Initialized
INFO - 2019-09-14 15:02:20 --> Helper loaded: url_helper
INFO - 2019-09-14 15:02:20 --> Helper loaded: html_helper
INFO - 2019-09-14 15:02:20 --> Helper loaded: form_helper
INFO - 2019-09-14 15:02:20 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:02:20 --> Helper loaded: date_helper
INFO - 2019-09-14 15:02:20 --> Form Validation Class Initialized
INFO - 2019-09-14 15:02:20 --> Email Class Initialized
DEBUG - 2019-09-14 15:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:02:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:02:20 --> Pagination Class Initialized
INFO - 2019-09-14 15:02:20 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:20 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:20 --> Controller Class Initialized
INFO - 2019-09-14 15:02:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-14 15:02:20 --> Config Class Initialized
INFO - 2019-09-14 15:02:20 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:02:20 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:02:20 --> Utf8 Class Initialized
INFO - 2019-09-14 15:02:20 --> URI Class Initialized
INFO - 2019-09-14 15:02:20 --> Router Class Initialized
INFO - 2019-09-14 15:02:20 --> Output Class Initialized
INFO - 2019-09-14 15:02:20 --> Security Class Initialized
DEBUG - 2019-09-14 15:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:02:20 --> Input Class Initialized
INFO - 2019-09-14 15:02:20 --> Language Class Initialized
INFO - 2019-09-14 15:02:20 --> Loader Class Initialized
INFO - 2019-09-14 15:02:20 --> Helper loaded: url_helper
INFO - 2019-09-14 15:02:20 --> Helper loaded: html_helper
INFO - 2019-09-14 15:02:20 --> Helper loaded: form_helper
INFO - 2019-09-14 15:02:20 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:02:20 --> Helper loaded: date_helper
INFO - 2019-09-14 15:02:20 --> Form Validation Class Initialized
INFO - 2019-09-14 15:02:20 --> Email Class Initialized
DEBUG - 2019-09-14 15:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:02:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:02:20 --> Pagination Class Initialized
INFO - 2019-09-14 15:02:20 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:20 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:20 --> Controller Class Initialized
INFO - 2019-09-14 15:02:20 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-14 15:02:20 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-14 15:02:20 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-14 15:02:20 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-14 15:02:20 --> Final output sent to browser
DEBUG - 2019-09-14 15:02:20 --> Total execution time: 0.0537
INFO - 2019-09-14 15:02:20 --> Config Class Initialized
INFO - 2019-09-14 15:02:20 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:02:20 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:02:20 --> Utf8 Class Initialized
INFO - 2019-09-14 15:02:20 --> URI Class Initialized
INFO - 2019-09-14 15:02:20 --> Router Class Initialized
INFO - 2019-09-14 15:02:20 --> Output Class Initialized
INFO - 2019-09-14 15:02:20 --> Security Class Initialized
DEBUG - 2019-09-14 15:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:02:20 --> Input Class Initialized
INFO - 2019-09-14 15:02:20 --> Language Class Initialized
INFO - 2019-09-14 15:02:20 --> Loader Class Initialized
INFO - 2019-09-14 15:02:20 --> Helper loaded: url_helper
INFO - 2019-09-14 15:02:20 --> Helper loaded: html_helper
INFO - 2019-09-14 15:02:20 --> Helper loaded: form_helper
INFO - 2019-09-14 15:02:20 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:02:20 --> Helper loaded: date_helper
INFO - 2019-09-14 15:02:20 --> Form Validation Class Initialized
INFO - 2019-09-14 15:02:20 --> Email Class Initialized
DEBUG - 2019-09-14 15:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:02:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:02:20 --> Pagination Class Initialized
INFO - 2019-09-14 15:02:20 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:20 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:20 --> Controller Class Initialized
INFO - 2019-09-14 15:02:20 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:02:20 --> Final output sent to browser
DEBUG - 2019-09-14 15:02:20 --> Total execution time: 0.0626
INFO - 2019-09-14 15:02:20 --> Config Class Initialized
INFO - 2019-09-14 15:02:20 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:02:20 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:02:20 --> Utf8 Class Initialized
INFO - 2019-09-14 15:02:20 --> URI Class Initialized
INFO - 2019-09-14 15:02:20 --> Router Class Initialized
INFO - 2019-09-14 15:02:20 --> Output Class Initialized
INFO - 2019-09-14 15:02:20 --> Security Class Initialized
DEBUG - 2019-09-14 15:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:02:20 --> Input Class Initialized
INFO - 2019-09-14 15:02:20 --> Language Class Initialized
INFO - 2019-09-14 15:02:20 --> Loader Class Initialized
INFO - 2019-09-14 15:02:20 --> Helper loaded: url_helper
INFO - 2019-09-14 15:02:20 --> Helper loaded: html_helper
INFO - 2019-09-14 15:02:20 --> Helper loaded: form_helper
INFO - 2019-09-14 15:02:20 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:02:20 --> Helper loaded: date_helper
INFO - 2019-09-14 15:02:20 --> Form Validation Class Initialized
INFO - 2019-09-14 15:02:20 --> Email Class Initialized
DEBUG - 2019-09-14 15:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:02:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:02:20 --> Pagination Class Initialized
INFO - 2019-09-14 15:02:20 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:20 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:20 --> Controller Class Initialized
INFO - 2019-09-14 15:02:20 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:02:20 --> Final output sent to browser
DEBUG - 2019-09-14 15:02:20 --> Total execution time: 0.0617
INFO - 2019-09-14 15:02:26 --> Config Class Initialized
INFO - 2019-09-14 15:02:26 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:02:26 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:02:26 --> Utf8 Class Initialized
INFO - 2019-09-14 15:02:26 --> URI Class Initialized
INFO - 2019-09-14 15:02:26 --> Router Class Initialized
INFO - 2019-09-14 15:02:26 --> Output Class Initialized
INFO - 2019-09-14 15:02:26 --> Security Class Initialized
DEBUG - 2019-09-14 15:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:02:26 --> Input Class Initialized
INFO - 2019-09-14 15:02:26 --> Language Class Initialized
INFO - 2019-09-14 15:02:26 --> Loader Class Initialized
INFO - 2019-09-14 15:02:26 --> Helper loaded: url_helper
INFO - 2019-09-14 15:02:26 --> Helper loaded: html_helper
INFO - 2019-09-14 15:02:26 --> Helper loaded: form_helper
INFO - 2019-09-14 15:02:26 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:02:26 --> Helper loaded: date_helper
INFO - 2019-09-14 15:02:26 --> Form Validation Class Initialized
INFO - 2019-09-14 15:02:26 --> Email Class Initialized
DEBUG - 2019-09-14 15:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:02:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:02:26 --> Pagination Class Initialized
INFO - 2019-09-14 15:02:26 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:26 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:26 --> Controller Class Initialized
INFO - 2019-09-14 15:02:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-14 15:02:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-14 15:02:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-14 15:02:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-14 15:02:26 --> Final output sent to browser
DEBUG - 2019-09-14 15:02:26 --> Total execution time: 0.1103
INFO - 2019-09-14 15:02:26 --> Config Class Initialized
INFO - 2019-09-14 15:02:26 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:02:26 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:02:26 --> Utf8 Class Initialized
INFO - 2019-09-14 15:02:26 --> URI Class Initialized
INFO - 2019-09-14 15:02:26 --> Router Class Initialized
INFO - 2019-09-14 15:02:26 --> Output Class Initialized
INFO - 2019-09-14 15:02:26 --> Security Class Initialized
DEBUG - 2019-09-14 15:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:02:26 --> Input Class Initialized
INFO - 2019-09-14 15:02:26 --> Language Class Initialized
INFO - 2019-09-14 15:02:26 --> Loader Class Initialized
INFO - 2019-09-14 15:02:26 --> Helper loaded: url_helper
INFO - 2019-09-14 15:02:26 --> Helper loaded: html_helper
INFO - 2019-09-14 15:02:26 --> Helper loaded: form_helper
INFO - 2019-09-14 15:02:26 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:02:26 --> Helper loaded: date_helper
INFO - 2019-09-14 15:02:26 --> Form Validation Class Initialized
INFO - 2019-09-14 15:02:26 --> Email Class Initialized
DEBUG - 2019-09-14 15:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:02:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:02:26 --> Pagination Class Initialized
INFO - 2019-09-14 15:02:26 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:26 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:26 --> Controller Class Initialized
INFO - 2019-09-14 15:02:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:02:26 --> Final output sent to browser
DEBUG - 2019-09-14 15:02:26 --> Total execution time: 0.0585
INFO - 2019-09-14 15:02:26 --> Config Class Initialized
INFO - 2019-09-14 15:02:26 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:02:26 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:02:26 --> Utf8 Class Initialized
INFO - 2019-09-14 15:02:26 --> URI Class Initialized
INFO - 2019-09-14 15:02:26 --> Router Class Initialized
INFO - 2019-09-14 15:02:26 --> Output Class Initialized
INFO - 2019-09-14 15:02:26 --> Security Class Initialized
DEBUG - 2019-09-14 15:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:02:26 --> Input Class Initialized
INFO - 2019-09-14 15:02:26 --> Language Class Initialized
INFO - 2019-09-14 15:02:26 --> Loader Class Initialized
INFO - 2019-09-14 15:02:26 --> Helper loaded: url_helper
INFO - 2019-09-14 15:02:26 --> Helper loaded: html_helper
INFO - 2019-09-14 15:02:26 --> Helper loaded: form_helper
INFO - 2019-09-14 15:02:26 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:02:26 --> Helper loaded: date_helper
INFO - 2019-09-14 15:02:26 --> Form Validation Class Initialized
INFO - 2019-09-14 15:02:26 --> Email Class Initialized
DEBUG - 2019-09-14 15:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:02:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:02:26 --> Pagination Class Initialized
INFO - 2019-09-14 15:02:26 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:26 --> Database Driver Class Initialized
INFO - 2019-09-14 15:02:26 --> Controller Class Initialized
INFO - 2019-09-14 15:02:26 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-14 15:02:26 --> Final output sent to browser
DEBUG - 2019-09-14 15:02:26 --> Total execution time: 0.0639
INFO - 2019-09-14 15:05:04 --> Config Class Initialized
INFO - 2019-09-14 15:05:04 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:05:04 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:05:04 --> Utf8 Class Initialized
INFO - 2019-09-14 15:05:04 --> URI Class Initialized
INFO - 2019-09-14 15:05:04 --> Router Class Initialized
INFO - 2019-09-14 15:05:04 --> Output Class Initialized
INFO - 2019-09-14 15:05:04 --> Security Class Initialized
DEBUG - 2019-09-14 15:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:05:04 --> Input Class Initialized
INFO - 2019-09-14 15:05:04 --> Language Class Initialized
INFO - 2019-09-14 15:05:04 --> Loader Class Initialized
INFO - 2019-09-14 15:05:04 --> Helper loaded: url_helper
INFO - 2019-09-14 15:05:04 --> Helper loaded: html_helper
INFO - 2019-09-14 15:05:04 --> Helper loaded: form_helper
INFO - 2019-09-14 15:05:04 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:05:04 --> Helper loaded: date_helper
INFO - 2019-09-14 15:05:04 --> Form Validation Class Initialized
INFO - 2019-09-14 15:05:04 --> Email Class Initialized
DEBUG - 2019-09-14 15:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:05:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:05:04 --> Pagination Class Initialized
INFO - 2019-09-14 15:05:04 --> Database Driver Class Initialized
INFO - 2019-09-14 15:05:04 --> Database Driver Class Initialized
INFO - 2019-09-14 15:05:04 --> Controller Class Initialized
DEBUG - 2019-09-14 15:05:04 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 15:05:04 --> Helper loaded: inflector_helper
INFO - 2019-09-14 15:05:04 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 15:05:04 --> Severity: Notice --> Undefined index: reservation_id C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 29
ERROR - 2019-09-14 15:05:04 --> Query error: Unknown column 'ReservationID' in 'field list' - Invalid query: INSERT INTO `reservationitems` (`ReservationID`, `AccountType`, `MasterID`, `Arrival`, `Departure`, `Nights`, `RoomNumber`, `RoomType`, `ClientType`, `ClientName`, `AgencyName`, `AgencyContact`, `Guest1`, `Guest2`, `GuestCount`, `Adults`, `Children`, `Type`, `Remarks`, `DateCreated`, `DateModified`, `SignatureCreated`, `SignatureModified`, `Status`, `Deleted`, `ActualArrival`, `ActualDeparture`, `LastRoomCharge`, `LastAccountClose`) VALUES ('000000000009', 'ROOM', '', '2019-08-29T00:00:00', '2019-08-31T00:00:00', 2, 12, 7, 'person', 'collins brad', '', '', 'collins brad', '', 1, 1, 0, 'reservation', '', '2019-08-28T15:01:40', '0001-01-01T00:00:00', 'MAZ', '', 'confirmed', '0', '0001-01-01T00:00:00', '0001-01-01T00:00:00', '0001-01-01T00:00:00', '0001-01-01T00:00:00')
INFO - 2019-09-14 15:05:04 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 15:06:14 --> Config Class Initialized
INFO - 2019-09-14 15:06:14 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:06:14 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:06:14 --> Utf8 Class Initialized
INFO - 2019-09-14 15:06:14 --> URI Class Initialized
INFO - 2019-09-14 15:06:14 --> Router Class Initialized
INFO - 2019-09-14 15:06:14 --> Output Class Initialized
INFO - 2019-09-14 15:06:14 --> Security Class Initialized
DEBUG - 2019-09-14 15:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:06:14 --> Input Class Initialized
INFO - 2019-09-14 15:06:14 --> Language Class Initialized
INFO - 2019-09-14 15:06:14 --> Loader Class Initialized
INFO - 2019-09-14 15:06:14 --> Helper loaded: url_helper
INFO - 2019-09-14 15:06:14 --> Helper loaded: html_helper
INFO - 2019-09-14 15:06:14 --> Helper loaded: form_helper
INFO - 2019-09-14 15:06:14 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:06:14 --> Helper loaded: date_helper
INFO - 2019-09-14 15:06:14 --> Form Validation Class Initialized
INFO - 2019-09-14 15:06:14 --> Email Class Initialized
DEBUG - 2019-09-14 15:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:06:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:06:14 --> Pagination Class Initialized
INFO - 2019-09-14 15:06:14 --> Database Driver Class Initialized
INFO - 2019-09-14 15:06:14 --> Database Driver Class Initialized
INFO - 2019-09-14 15:06:14 --> Controller Class Initialized
DEBUG - 2019-09-14 15:06:14 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 15:06:14 --> Helper loaded: inflector_helper
INFO - 2019-09-14 15:06:14 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 15:06:14 --> Severity: Notice --> Undefined index: reservation_id C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 29
ERROR - 2019-09-14 15:06:14 --> Query error: Unknown column 'ReservationID' in 'field list' - Invalid query: INSERT INTO `reservationitems` (`ReservationID`, `AccountType`, `MasterID`, `Arrival`, `Departure`, `Nights`, `RoomNumber`, `RoomType`, `ClientType`, `ClientName`, `AgencyName`, `AgencyContact`, `Guest1`, `Guest2`, `GuestCount`, `Adults`, `Children`, `Type`, `Remarks`, `DateCreated`, `DateModified`, `SignatureCreated`, `SignatureModified`, `Status`, `Deleted`, `ActualArrival`, `ActualDeparture`, `LastRoomCharge`, `LastAccountClose`) VALUES ('000000000009', 'ROOM', '', '2019-08-29T00:00:00', '2019-08-31T00:00:00', 2, 12, 7, 'person', 'collins brad', '', '', 'collins brad', '', 1, 1, 0, 'reservation', '', '2019-08-28T15:01:40', '0001-01-01T00:00:00', 'MAZ', '', 'confirmed', '0', '0001-01-01T00:00:00', '0001-01-01T00:00:00', '0001-01-01T00:00:00', '0001-01-01T00:00:00')
INFO - 2019-09-14 15:06:14 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 15:07:27 --> Config Class Initialized
INFO - 2019-09-14 15:07:27 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:07:27 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:07:27 --> Utf8 Class Initialized
INFO - 2019-09-14 15:07:27 --> URI Class Initialized
INFO - 2019-09-14 15:07:27 --> Router Class Initialized
INFO - 2019-09-14 15:07:27 --> Output Class Initialized
INFO - 2019-09-14 15:07:27 --> Security Class Initialized
DEBUG - 2019-09-14 15:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:07:27 --> Input Class Initialized
INFO - 2019-09-14 15:07:27 --> Language Class Initialized
INFO - 2019-09-14 15:07:27 --> Loader Class Initialized
INFO - 2019-09-14 15:07:27 --> Helper loaded: url_helper
INFO - 2019-09-14 15:07:27 --> Helper loaded: html_helper
INFO - 2019-09-14 15:07:27 --> Helper loaded: form_helper
INFO - 2019-09-14 15:07:27 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:07:27 --> Helper loaded: date_helper
INFO - 2019-09-14 15:07:27 --> Form Validation Class Initialized
INFO - 2019-09-14 15:07:27 --> Email Class Initialized
DEBUG - 2019-09-14 15:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:07:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:07:27 --> Pagination Class Initialized
INFO - 2019-09-14 15:07:27 --> Database Driver Class Initialized
INFO - 2019-09-14 15:07:27 --> Database Driver Class Initialized
INFO - 2019-09-14 15:07:27 --> Controller Class Initialized
DEBUG - 2019-09-14 15:07:27 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 15:07:27 --> Helper loaded: inflector_helper
INFO - 2019-09-14 15:07:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 15:07:27 --> Final output sent to browser
DEBUG - 2019-09-14 15:07:27 --> Total execution time: 0.1515
INFO - 2019-09-14 15:10:59 --> Config Class Initialized
INFO - 2019-09-14 15:10:59 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:10:59 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:10:59 --> Utf8 Class Initialized
INFO - 2019-09-14 15:10:59 --> URI Class Initialized
INFO - 2019-09-14 15:10:59 --> Router Class Initialized
INFO - 2019-09-14 15:10:59 --> Output Class Initialized
INFO - 2019-09-14 15:10:59 --> Security Class Initialized
DEBUG - 2019-09-14 15:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:10:59 --> Input Class Initialized
INFO - 2019-09-14 15:10:59 --> Language Class Initialized
INFO - 2019-09-14 15:10:59 --> Loader Class Initialized
INFO - 2019-09-14 15:10:59 --> Helper loaded: url_helper
INFO - 2019-09-14 15:10:59 --> Helper loaded: html_helper
INFO - 2019-09-14 15:10:59 --> Helper loaded: form_helper
INFO - 2019-09-14 15:10:59 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:10:59 --> Helper loaded: date_helper
INFO - 2019-09-14 15:10:59 --> Form Validation Class Initialized
INFO - 2019-09-14 15:10:59 --> Email Class Initialized
DEBUG - 2019-09-14 15:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:10:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:10:59 --> Pagination Class Initialized
INFO - 2019-09-14 15:10:59 --> Database Driver Class Initialized
INFO - 2019-09-14 15:10:59 --> Database Driver Class Initialized
INFO - 2019-09-14 15:10:59 --> Controller Class Initialized
DEBUG - 2019-09-14 15:10:59 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 15:10:59 --> Helper loaded: inflector_helper
INFO - 2019-09-14 15:10:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 15:11:28 --> Config Class Initialized
INFO - 2019-09-14 15:11:28 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:11:28 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:11:28 --> Utf8 Class Initialized
INFO - 2019-09-14 15:11:28 --> URI Class Initialized
INFO - 2019-09-14 15:11:28 --> Router Class Initialized
INFO - 2019-09-14 15:11:28 --> Output Class Initialized
INFO - 2019-09-14 15:11:28 --> Security Class Initialized
DEBUG - 2019-09-14 15:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:11:28 --> Input Class Initialized
INFO - 2019-09-14 15:11:28 --> Language Class Initialized
INFO - 2019-09-14 15:11:28 --> Loader Class Initialized
INFO - 2019-09-14 15:11:28 --> Helper loaded: url_helper
INFO - 2019-09-14 15:11:28 --> Helper loaded: html_helper
INFO - 2019-09-14 15:11:28 --> Helper loaded: form_helper
INFO - 2019-09-14 15:11:28 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:11:28 --> Helper loaded: date_helper
INFO - 2019-09-14 15:11:28 --> Form Validation Class Initialized
INFO - 2019-09-14 15:11:28 --> Email Class Initialized
DEBUG - 2019-09-14 15:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:11:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:11:28 --> Pagination Class Initialized
INFO - 2019-09-14 15:11:28 --> Database Driver Class Initialized
INFO - 2019-09-14 15:11:28 --> Database Driver Class Initialized
INFO - 2019-09-14 15:11:28 --> Controller Class Initialized
DEBUG - 2019-09-14 15:11:28 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 15:11:28 --> Helper loaded: inflector_helper
INFO - 2019-09-14 15:11:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 15:15:37 --> Config Class Initialized
INFO - 2019-09-14 15:15:37 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:15:37 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:15:37 --> Utf8 Class Initialized
INFO - 2019-09-14 15:15:37 --> URI Class Initialized
INFO - 2019-09-14 15:15:37 --> Router Class Initialized
INFO - 2019-09-14 15:15:37 --> Output Class Initialized
INFO - 2019-09-14 15:15:37 --> Security Class Initialized
DEBUG - 2019-09-14 15:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:15:37 --> Input Class Initialized
INFO - 2019-09-14 15:15:37 --> Language Class Initialized
INFO - 2019-09-14 15:15:37 --> Loader Class Initialized
INFO - 2019-09-14 15:15:37 --> Helper loaded: url_helper
INFO - 2019-09-14 15:15:37 --> Helper loaded: html_helper
INFO - 2019-09-14 15:15:37 --> Helper loaded: form_helper
INFO - 2019-09-14 15:15:37 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:15:37 --> Helper loaded: date_helper
INFO - 2019-09-14 15:15:37 --> Form Validation Class Initialized
INFO - 2019-09-14 15:15:37 --> Email Class Initialized
DEBUG - 2019-09-14 15:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:15:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:15:37 --> Pagination Class Initialized
INFO - 2019-09-14 15:15:37 --> Database Driver Class Initialized
INFO - 2019-09-14 15:15:37 --> Database Driver Class Initialized
INFO - 2019-09-14 15:15:37 --> Controller Class Initialized
DEBUG - 2019-09-14 15:15:37 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 15:15:37 --> Helper loaded: inflector_helper
INFO - 2019-09-14 15:15:37 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 15:15:37 --> Severity: Notice --> Undefined index: reservation_id C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 29
ERROR - 2019-09-14 15:15:37 --> Query error: Unknown column 'ReservationID' in 'field list' - Invalid query: INSERT INTO `reservationitems` (`ReservationID`, `AccountType`, `MasterID`, `Arrival`, `Departure`, `Nights`, `RoomNumber`, `RoomType`, `ClientType`, `ClientName`, `AgencyName`, `AgencyContact`, `Guest1`, `Guest2`, `GuestCount`, `Adults`, `Children`, `Type`, `Remarks`, `DateCreated`, `DateModified`, `SignatureCreated`, `SignatureModified`, `Status`, `Deleted`, `ActualArrival`, `ActualDeparture`, `LastRoomCharge`, `LastAccountClose`) VALUES ('000000000009', 'ROOM', '', '2019-08-29T00:00:00', '2019-08-31T00:00:00', 2, 12, 7, 'person', 'collins brad', '', '', 'collins brad', '', 1, 1, 0, 'reservation', '', '2019-08-28T15:01:40', '0001-01-01T00:00:00', 'MAZ', '', 'confirmed', '0', '0001-01-01T00:00:00', '0001-01-01T00:00:00', '0001-01-01T00:00:00', '0001-01-01T00:00:00')
INFO - 2019-09-14 15:15:37 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 15:16:32 --> Config Class Initialized
INFO - 2019-09-14 15:16:32 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:16:32 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:16:32 --> Utf8 Class Initialized
INFO - 2019-09-14 15:16:32 --> URI Class Initialized
INFO - 2019-09-14 15:16:32 --> Router Class Initialized
INFO - 2019-09-14 15:16:32 --> Output Class Initialized
INFO - 2019-09-14 15:16:32 --> Security Class Initialized
DEBUG - 2019-09-14 15:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:16:32 --> Input Class Initialized
INFO - 2019-09-14 15:16:32 --> Language Class Initialized
INFO - 2019-09-14 15:16:32 --> Loader Class Initialized
INFO - 2019-09-14 15:16:32 --> Helper loaded: url_helper
INFO - 2019-09-14 15:16:32 --> Helper loaded: html_helper
INFO - 2019-09-14 15:16:32 --> Helper loaded: form_helper
INFO - 2019-09-14 15:16:32 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:16:32 --> Helper loaded: date_helper
INFO - 2019-09-14 15:16:32 --> Form Validation Class Initialized
INFO - 2019-09-14 15:16:32 --> Email Class Initialized
DEBUG - 2019-09-14 15:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:16:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:16:32 --> Pagination Class Initialized
INFO - 2019-09-14 15:16:32 --> Database Driver Class Initialized
INFO - 2019-09-14 15:16:32 --> Database Driver Class Initialized
INFO - 2019-09-14 15:16:32 --> Controller Class Initialized
DEBUG - 2019-09-14 15:16:32 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 15:16:32 --> Helper loaded: inflector_helper
INFO - 2019-09-14 15:16:32 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 15:16:32 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\wamp64\www\pridehotel_lagos\application\controllers\api\Service.php 85
ERROR - 2019-09-14 15:16:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 27
INFO - 2019-09-14 15:16:32 --> Final output sent to browser
DEBUG - 2019-09-14 15:16:32 --> Total execution time: 0.0615
INFO - 2019-09-14 15:18:59 --> Config Class Initialized
INFO - 2019-09-14 15:18:59 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:18:59 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:18:59 --> Utf8 Class Initialized
INFO - 2019-09-14 15:18:59 --> URI Class Initialized
INFO - 2019-09-14 15:18:59 --> Router Class Initialized
INFO - 2019-09-14 15:18:59 --> Output Class Initialized
INFO - 2019-09-14 15:18:59 --> Security Class Initialized
DEBUG - 2019-09-14 15:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:18:59 --> Input Class Initialized
INFO - 2019-09-14 15:18:59 --> Language Class Initialized
INFO - 2019-09-14 15:18:59 --> Loader Class Initialized
INFO - 2019-09-14 15:18:59 --> Helper loaded: url_helper
INFO - 2019-09-14 15:18:59 --> Helper loaded: html_helper
INFO - 2019-09-14 15:18:59 --> Helper loaded: form_helper
INFO - 2019-09-14 15:18:59 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:18:59 --> Helper loaded: date_helper
INFO - 2019-09-14 15:18:59 --> Form Validation Class Initialized
INFO - 2019-09-14 15:18:59 --> Email Class Initialized
DEBUG - 2019-09-14 15:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:18:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:18:59 --> Pagination Class Initialized
INFO - 2019-09-14 15:18:59 --> Database Driver Class Initialized
INFO - 2019-09-14 15:18:59 --> Database Driver Class Initialized
INFO - 2019-09-14 15:19:00 --> Controller Class Initialized
DEBUG - 2019-09-14 15:19:00 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 15:19:00 --> Helper loaded: inflector_helper
INFO - 2019-09-14 15:19:00 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 15:19:00 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\wamp64\www\pridehotel_lagos\application\controllers\api\Service.php 85
ERROR - 2019-09-14 15:19:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 27
INFO - 2019-09-14 15:19:00 --> Final output sent to browser
DEBUG - 2019-09-14 15:19:00 --> Total execution time: 0.0644
INFO - 2019-09-14 15:35:23 --> Config Class Initialized
INFO - 2019-09-14 15:35:23 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:35:23 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:35:23 --> Utf8 Class Initialized
INFO - 2019-09-14 15:35:23 --> URI Class Initialized
INFO - 2019-09-14 15:35:23 --> Router Class Initialized
INFO - 2019-09-14 15:35:23 --> Output Class Initialized
INFO - 2019-09-14 15:35:23 --> Security Class Initialized
DEBUG - 2019-09-14 15:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:35:23 --> Input Class Initialized
INFO - 2019-09-14 15:35:23 --> Language Class Initialized
INFO - 2019-09-14 15:35:23 --> Loader Class Initialized
INFO - 2019-09-14 15:35:23 --> Helper loaded: url_helper
INFO - 2019-09-14 15:35:23 --> Helper loaded: html_helper
INFO - 2019-09-14 15:35:23 --> Helper loaded: form_helper
INFO - 2019-09-14 15:35:23 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:35:23 --> Helper loaded: date_helper
INFO - 2019-09-14 15:35:23 --> Form Validation Class Initialized
INFO - 2019-09-14 15:35:23 --> Email Class Initialized
DEBUG - 2019-09-14 15:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:35:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:35:23 --> Pagination Class Initialized
INFO - 2019-09-14 15:35:23 --> Database Driver Class Initialized
INFO - 2019-09-14 15:35:23 --> Database Driver Class Initialized
INFO - 2019-09-14 15:35:23 --> Controller Class Initialized
DEBUG - 2019-09-14 15:35:23 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 15:35:23 --> Helper loaded: inflector_helper
INFO - 2019-09-14 15:35:23 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 15:35:23 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\wamp64\www\pridehotel_lagos\application\controllers\api\Service.php 85
ERROR - 2019-09-14 15:35:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 27
INFO - 2019-09-14 15:35:23 --> Final output sent to browser
DEBUG - 2019-09-14 15:35:23 --> Total execution time: 0.0649
INFO - 2019-09-14 15:47:57 --> Config Class Initialized
INFO - 2019-09-14 15:47:57 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:47:57 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:47:57 --> Utf8 Class Initialized
INFO - 2019-09-14 15:47:57 --> URI Class Initialized
INFO - 2019-09-14 15:47:57 --> Router Class Initialized
INFO - 2019-09-14 15:47:57 --> Output Class Initialized
INFO - 2019-09-14 15:47:57 --> Security Class Initialized
DEBUG - 2019-09-14 15:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:47:57 --> Input Class Initialized
INFO - 2019-09-14 15:47:57 --> Language Class Initialized
INFO - 2019-09-14 15:47:57 --> Loader Class Initialized
INFO - 2019-09-14 15:47:57 --> Helper loaded: url_helper
INFO - 2019-09-14 15:47:57 --> Helper loaded: html_helper
INFO - 2019-09-14 15:47:57 --> Helper loaded: form_helper
INFO - 2019-09-14 15:47:57 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:47:57 --> Helper loaded: date_helper
INFO - 2019-09-14 15:47:57 --> Form Validation Class Initialized
INFO - 2019-09-14 15:47:57 --> Email Class Initialized
DEBUG - 2019-09-14 15:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:47:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:47:57 --> Pagination Class Initialized
INFO - 2019-09-14 15:47:57 --> Database Driver Class Initialized
INFO - 2019-09-14 15:47:57 --> Database Driver Class Initialized
INFO - 2019-09-14 15:47:57 --> Controller Class Initialized
DEBUG - 2019-09-14 15:47:57 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 15:47:57 --> Helper loaded: inflector_helper
INFO - 2019-09-14 15:47:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 15:57:26 --> Config Class Initialized
INFO - 2019-09-14 15:57:26 --> Hooks Class Initialized
DEBUG - 2019-09-14 15:57:26 --> UTF-8 Support Enabled
INFO - 2019-09-14 15:57:26 --> Utf8 Class Initialized
INFO - 2019-09-14 15:57:26 --> URI Class Initialized
INFO - 2019-09-14 15:57:26 --> Router Class Initialized
INFO - 2019-09-14 15:57:26 --> Output Class Initialized
INFO - 2019-09-14 15:57:26 --> Security Class Initialized
DEBUG - 2019-09-14 15:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 15:57:26 --> Input Class Initialized
INFO - 2019-09-14 15:57:26 --> Language Class Initialized
INFO - 2019-09-14 15:57:26 --> Loader Class Initialized
INFO - 2019-09-14 15:57:26 --> Helper loaded: url_helper
INFO - 2019-09-14 15:57:26 --> Helper loaded: html_helper
INFO - 2019-09-14 15:57:26 --> Helper loaded: form_helper
INFO - 2019-09-14 15:57:26 --> Helper loaded: cookie_helper
INFO - 2019-09-14 15:57:26 --> Helper loaded: date_helper
INFO - 2019-09-14 15:57:26 --> Form Validation Class Initialized
INFO - 2019-09-14 15:57:26 --> Email Class Initialized
DEBUG - 2019-09-14 15:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 15:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 15:57:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 15:57:26 --> Pagination Class Initialized
INFO - 2019-09-14 15:57:26 --> Database Driver Class Initialized
INFO - 2019-09-14 15:57:26 --> Database Driver Class Initialized
INFO - 2019-09-14 15:57:26 --> Controller Class Initialized
DEBUG - 2019-09-14 15:57:26 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 15:57:26 --> Helper loaded: inflector_helper
INFO - 2019-09-14 15:57:26 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 15:57:26 --> Severity: Warning --> Illegal string offset 'reservation_id' C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 29
ERROR - 2019-09-14 15:57:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`brad","Guest2":"","GuestCount":1,"Adults":1,"Children":0,"Type":"reservation","' at line 1 - Invalid query: INSERT INTO `reservationitems` (`[{"ReservationID":"000000000009","AccountType":"ROOM","MasterID":"","Arrival":"2019-08-29T00:00:00","Departure":"2019-08-31T00:00:00","Nights":2,"RoomNumber":12,"RoomType":7,"ClientType":"person","ClientName":"collins brad","AgencyName":"","AgencyContact":"","Guest1":"collins` `brad","Guest2":"","GuestCount":1,"Adults":1,"Children":0,"Type":"reservation","Remarks":"","DateCreated":"2019-08-28T15:01:40","DateModified":"0001-01-01T00:00:00","SignatureCreated":"MAZ","SignatureModified":"","Status":"confirmed","Deleted":"0","ActualArrival":"0001-01-01T00:00:00","ActualDeparture":"0001-01-01T00:00:00","LastRoomCharge":"0001-01-01T00:00:00","LastAccountClose":"0001-01-01T00:00:00"},{"ReservationID":"000000000010","AccountType":"ROOM","MasterID":"","Arrival":"2019-08-31T00:00:00","Departure":"2019-09-05T00:00:00","Nights":5,"RoomNumber":13,"RoomType":7,"ClientType":"person","ClientName":"ola","AgencyName":"","AgencyContact":"","Guest1":"ola","Guest2":"","GuestCount":1,"Adults":1,"Children":0,"Type":"reservation","Remarks":"","DateCreated":"2019-08-28T15:02:18","DateModified":"0001-01-01T00:00:00","SignatureCreated":"MAZ","SignatureModified":"","Status":"confirmed","Deleted":"0","ActualArrival":"0001-01-01T00:00:00","ActualDeparture":"0001-01-01T00:00:00","LastRoomCharge":"0001-01-01T00:00:00","LastAccountClose":"0001-01-01T00:00:00"}]`) VALUES ('')
INFO - 2019-09-14 15:57:26 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 16:00:18 --> Config Class Initialized
INFO - 2019-09-14 16:00:18 --> Hooks Class Initialized
DEBUG - 2019-09-14 16:00:18 --> UTF-8 Support Enabled
INFO - 2019-09-14 16:00:18 --> Utf8 Class Initialized
INFO - 2019-09-14 16:00:18 --> URI Class Initialized
INFO - 2019-09-14 16:00:18 --> Router Class Initialized
INFO - 2019-09-14 16:00:18 --> Output Class Initialized
INFO - 2019-09-14 16:00:18 --> Security Class Initialized
DEBUG - 2019-09-14 16:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 16:00:18 --> Input Class Initialized
INFO - 2019-09-14 16:00:18 --> Language Class Initialized
INFO - 2019-09-14 16:00:18 --> Loader Class Initialized
INFO - 2019-09-14 16:00:18 --> Helper loaded: url_helper
INFO - 2019-09-14 16:00:18 --> Helper loaded: html_helper
INFO - 2019-09-14 16:00:18 --> Helper loaded: form_helper
INFO - 2019-09-14 16:00:18 --> Helper loaded: cookie_helper
INFO - 2019-09-14 16:00:18 --> Helper loaded: date_helper
INFO - 2019-09-14 16:00:18 --> Form Validation Class Initialized
INFO - 2019-09-14 16:00:18 --> Email Class Initialized
DEBUG - 2019-09-14 16:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 16:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 16:00:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 16:00:18 --> Pagination Class Initialized
INFO - 2019-09-14 16:00:18 --> Database Driver Class Initialized
INFO - 2019-09-14 16:00:18 --> Database Driver Class Initialized
INFO - 2019-09-14 16:00:18 --> Controller Class Initialized
DEBUG - 2019-09-14 16:00:18 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 16:00:18 --> Helper loaded: inflector_helper
INFO - 2019-09-14 16:00:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 16:00:57 --> Config Class Initialized
INFO - 2019-09-14 16:00:57 --> Hooks Class Initialized
DEBUG - 2019-09-14 16:00:57 --> UTF-8 Support Enabled
INFO - 2019-09-14 16:00:57 --> Utf8 Class Initialized
INFO - 2019-09-14 16:00:57 --> URI Class Initialized
INFO - 2019-09-14 16:00:57 --> Router Class Initialized
INFO - 2019-09-14 16:00:57 --> Output Class Initialized
INFO - 2019-09-14 16:00:57 --> Security Class Initialized
DEBUG - 2019-09-14 16:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 16:00:57 --> Input Class Initialized
INFO - 2019-09-14 16:00:57 --> Language Class Initialized
INFO - 2019-09-14 16:00:57 --> Loader Class Initialized
INFO - 2019-09-14 16:00:57 --> Helper loaded: url_helper
INFO - 2019-09-14 16:00:57 --> Helper loaded: html_helper
INFO - 2019-09-14 16:00:57 --> Helper loaded: form_helper
INFO - 2019-09-14 16:00:57 --> Helper loaded: cookie_helper
INFO - 2019-09-14 16:00:57 --> Helper loaded: date_helper
INFO - 2019-09-14 16:00:57 --> Form Validation Class Initialized
INFO - 2019-09-14 16:00:57 --> Email Class Initialized
DEBUG - 2019-09-14 16:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 16:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 16:00:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 16:00:57 --> Pagination Class Initialized
INFO - 2019-09-14 16:00:57 --> Database Driver Class Initialized
INFO - 2019-09-14 16:00:57 --> Database Driver Class Initialized
INFO - 2019-09-14 16:00:57 --> Controller Class Initialized
DEBUG - 2019-09-14 16:00:57 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 16:00:57 --> Helper loaded: inflector_helper
INFO - 2019-09-14 16:00:57 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 16:00:57 --> Severity: Warning --> Illegal string offset 'ReservationID' C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 30
ERROR - 2019-09-14 16:00:57 --> Query error: Unknown column 'ReservationID' in 'where clause' - Invalid query: SELECT `ID`
FROM `reservationitems`
WHERE `ReservationID` = '['
INFO - 2019-09-14 16:00:57 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 16:01:38 --> Config Class Initialized
INFO - 2019-09-14 16:01:38 --> Hooks Class Initialized
DEBUG - 2019-09-14 16:01:38 --> UTF-8 Support Enabled
INFO - 2019-09-14 16:01:38 --> Utf8 Class Initialized
INFO - 2019-09-14 16:01:38 --> URI Class Initialized
INFO - 2019-09-14 16:01:38 --> Router Class Initialized
INFO - 2019-09-14 16:01:38 --> Output Class Initialized
INFO - 2019-09-14 16:01:38 --> Security Class Initialized
DEBUG - 2019-09-14 16:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 16:01:38 --> Input Class Initialized
INFO - 2019-09-14 16:01:38 --> Language Class Initialized
INFO - 2019-09-14 16:01:38 --> Loader Class Initialized
INFO - 2019-09-14 16:01:38 --> Helper loaded: url_helper
INFO - 2019-09-14 16:01:38 --> Helper loaded: html_helper
INFO - 2019-09-14 16:01:38 --> Helper loaded: form_helper
INFO - 2019-09-14 16:01:38 --> Helper loaded: cookie_helper
INFO - 2019-09-14 16:01:38 --> Helper loaded: date_helper
INFO - 2019-09-14 16:01:38 --> Form Validation Class Initialized
INFO - 2019-09-14 16:01:38 --> Email Class Initialized
DEBUG - 2019-09-14 16:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 16:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 16:01:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 16:01:38 --> Pagination Class Initialized
INFO - 2019-09-14 16:01:38 --> Database Driver Class Initialized
INFO - 2019-09-14 16:01:38 --> Database Driver Class Initialized
INFO - 2019-09-14 16:01:38 --> Controller Class Initialized
DEBUG - 2019-09-14 16:01:38 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 16:01:38 --> Helper loaded: inflector_helper
INFO - 2019-09-14 16:01:38 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 16:01:38 --> Severity: Warning --> Illegal string offset 'ReservationID' C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 31
ERROR - 2019-09-14 16:01:38 --> Query error: Unknown column 'ReservationID' in 'where clause' - Invalid query: SELECT `ID`
FROM `reservationitems`
WHERE `ReservationID` = '['
INFO - 2019-09-14 16:01:38 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 16:03:14 --> Config Class Initialized
INFO - 2019-09-14 16:03:14 --> Hooks Class Initialized
DEBUG - 2019-09-14 16:03:14 --> UTF-8 Support Enabled
INFO - 2019-09-14 16:03:14 --> Utf8 Class Initialized
INFO - 2019-09-14 16:03:14 --> URI Class Initialized
INFO - 2019-09-14 16:03:14 --> Router Class Initialized
INFO - 2019-09-14 16:03:14 --> Output Class Initialized
INFO - 2019-09-14 16:03:14 --> Security Class Initialized
DEBUG - 2019-09-14 16:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 16:03:14 --> Input Class Initialized
INFO - 2019-09-14 16:03:14 --> Language Class Initialized
INFO - 2019-09-14 16:03:14 --> Loader Class Initialized
INFO - 2019-09-14 16:03:14 --> Helper loaded: url_helper
INFO - 2019-09-14 16:03:14 --> Helper loaded: html_helper
INFO - 2019-09-14 16:03:14 --> Helper loaded: form_helper
INFO - 2019-09-14 16:03:14 --> Helper loaded: cookie_helper
INFO - 2019-09-14 16:03:14 --> Helper loaded: date_helper
INFO - 2019-09-14 16:03:14 --> Form Validation Class Initialized
INFO - 2019-09-14 16:03:14 --> Email Class Initialized
DEBUG - 2019-09-14 16:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 16:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 16:03:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 16:03:14 --> Pagination Class Initialized
INFO - 2019-09-14 16:03:14 --> Database Driver Class Initialized
INFO - 2019-09-14 16:03:14 --> Database Driver Class Initialized
INFO - 2019-09-14 16:03:14 --> Controller Class Initialized
DEBUG - 2019-09-14 16:03:14 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 16:03:14 --> Helper loaded: inflector_helper
INFO - 2019-09-14 16:03:14 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 16:03:14 --> Severity: Warning --> Illegal string offset 'ReservationID' C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 33
ERROR - 2019-09-14 16:03:14 --> Query error: Unknown column 'ReservationID' in 'where clause' - Invalid query: SELECT `ID`
FROM `reservationitems`
WHERE `ReservationID` = '['
INFO - 2019-09-14 16:03:14 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 16:04:14 --> Config Class Initialized
INFO - 2019-09-14 16:04:14 --> Hooks Class Initialized
DEBUG - 2019-09-14 16:04:14 --> UTF-8 Support Enabled
INFO - 2019-09-14 16:04:14 --> Utf8 Class Initialized
INFO - 2019-09-14 16:04:14 --> URI Class Initialized
INFO - 2019-09-14 16:04:14 --> Router Class Initialized
INFO - 2019-09-14 16:04:14 --> Output Class Initialized
INFO - 2019-09-14 16:04:14 --> Security Class Initialized
DEBUG - 2019-09-14 16:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 16:04:14 --> Input Class Initialized
INFO - 2019-09-14 16:04:14 --> Language Class Initialized
INFO - 2019-09-14 16:04:14 --> Loader Class Initialized
INFO - 2019-09-14 16:04:14 --> Helper loaded: url_helper
INFO - 2019-09-14 16:04:14 --> Helper loaded: html_helper
INFO - 2019-09-14 16:04:14 --> Helper loaded: form_helper
INFO - 2019-09-14 16:04:14 --> Helper loaded: cookie_helper
INFO - 2019-09-14 16:04:14 --> Helper loaded: date_helper
INFO - 2019-09-14 16:04:14 --> Form Validation Class Initialized
INFO - 2019-09-14 16:04:14 --> Email Class Initialized
DEBUG - 2019-09-14 16:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 16:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 16:04:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 16:04:14 --> Pagination Class Initialized
INFO - 2019-09-14 16:04:15 --> Database Driver Class Initialized
INFO - 2019-09-14 16:04:15 --> Database Driver Class Initialized
INFO - 2019-09-14 16:04:15 --> Controller Class Initialized
DEBUG - 2019-09-14 16:04:15 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 16:04:15 --> Helper loaded: inflector_helper
INFO - 2019-09-14 16:04:15 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 16:04:15 --> Severity: Warning --> Illegal string offset 'ReservationID' C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 35
ERROR - 2019-09-14 16:04:15 --> Query error: Unknown column 'ReservationID' in 'where clause' - Invalid query: SELECT `ID`
FROM `reservationitems`
WHERE `ReservationID` = '['
INFO - 2019-09-14 16:04:15 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 16:37:49 --> Config Class Initialized
INFO - 2019-09-14 16:37:49 --> Hooks Class Initialized
DEBUG - 2019-09-14 16:37:49 --> UTF-8 Support Enabled
INFO - 2019-09-14 16:37:49 --> Utf8 Class Initialized
INFO - 2019-09-14 16:37:49 --> URI Class Initialized
INFO - 2019-09-14 16:37:49 --> Router Class Initialized
INFO - 2019-09-14 16:37:49 --> Output Class Initialized
INFO - 2019-09-14 16:37:49 --> Security Class Initialized
DEBUG - 2019-09-14 16:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 16:37:49 --> Input Class Initialized
INFO - 2019-09-14 16:37:49 --> Language Class Initialized
INFO - 2019-09-14 16:37:49 --> Loader Class Initialized
INFO - 2019-09-14 16:37:49 --> Helper loaded: url_helper
INFO - 2019-09-14 16:37:49 --> Helper loaded: html_helper
INFO - 2019-09-14 16:37:49 --> Helper loaded: form_helper
INFO - 2019-09-14 16:37:49 --> Helper loaded: cookie_helper
INFO - 2019-09-14 16:37:49 --> Helper loaded: date_helper
INFO - 2019-09-14 16:37:49 --> Form Validation Class Initialized
INFO - 2019-09-14 16:37:49 --> Email Class Initialized
DEBUG - 2019-09-14 16:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 16:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 16:37:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 16:37:49 --> Pagination Class Initialized
INFO - 2019-09-14 16:37:49 --> Database Driver Class Initialized
INFO - 2019-09-14 16:37:49 --> Database Driver Class Initialized
INFO - 2019-09-14 16:37:49 --> Controller Class Initialized
DEBUG - 2019-09-14 16:37:49 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 16:37:49 --> Helper loaded: inflector_helper
INFO - 2019-09-14 16:37:49 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 16:37:49 --> Severity: Warning --> Illegal string offset 'ReservationID' C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 37
ERROR - 2019-09-14 16:37:49 --> Query error: Unknown column 'ReservationID' in 'where clause' - Invalid query: SELECT `ID`
FROM `reservationitems`
WHERE `ReservationID` = '['
INFO - 2019-09-14 16:37:49 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 16:38:22 --> Config Class Initialized
INFO - 2019-09-14 16:38:22 --> Hooks Class Initialized
DEBUG - 2019-09-14 16:38:22 --> UTF-8 Support Enabled
INFO - 2019-09-14 16:38:22 --> Utf8 Class Initialized
INFO - 2019-09-14 16:38:22 --> URI Class Initialized
INFO - 2019-09-14 16:38:22 --> Router Class Initialized
INFO - 2019-09-14 16:38:22 --> Output Class Initialized
INFO - 2019-09-14 16:38:22 --> Security Class Initialized
DEBUG - 2019-09-14 16:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 16:38:22 --> Input Class Initialized
INFO - 2019-09-14 16:38:22 --> Language Class Initialized
INFO - 2019-09-14 16:38:22 --> Loader Class Initialized
INFO - 2019-09-14 16:38:22 --> Helper loaded: url_helper
INFO - 2019-09-14 16:38:22 --> Helper loaded: html_helper
INFO - 2019-09-14 16:38:22 --> Helper loaded: form_helper
INFO - 2019-09-14 16:38:22 --> Helper loaded: cookie_helper
INFO - 2019-09-14 16:38:22 --> Helper loaded: date_helper
INFO - 2019-09-14 16:38:22 --> Form Validation Class Initialized
INFO - 2019-09-14 16:38:22 --> Email Class Initialized
DEBUG - 2019-09-14 16:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 16:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 16:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 16:38:22 --> Pagination Class Initialized
INFO - 2019-09-14 16:38:22 --> Database Driver Class Initialized
INFO - 2019-09-14 16:38:22 --> Database Driver Class Initialized
INFO - 2019-09-14 16:38:22 --> Controller Class Initialized
DEBUG - 2019-09-14 16:38:22 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 16:38:22 --> Helper loaded: inflector_helper
INFO - 2019-09-14 16:38:22 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 16:38:22 --> Severity: Warning --> Illegal string offset 'ReservationID' C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 37
ERROR - 2019-09-14 16:38:22 --> Query error: Unknown column 'ReservationID' in 'where clause' - Invalid query: SELECT `ID`
FROM `reservationitems`
WHERE `ReservationID` = '['
INFO - 2019-09-14 16:38:22 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 16:39:31 --> Config Class Initialized
INFO - 2019-09-14 16:39:31 --> Hooks Class Initialized
DEBUG - 2019-09-14 16:39:31 --> UTF-8 Support Enabled
INFO - 2019-09-14 16:39:31 --> Utf8 Class Initialized
INFO - 2019-09-14 16:39:31 --> URI Class Initialized
INFO - 2019-09-14 16:39:31 --> Router Class Initialized
INFO - 2019-09-14 16:39:31 --> Output Class Initialized
INFO - 2019-09-14 16:39:31 --> Security Class Initialized
DEBUG - 2019-09-14 16:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 16:39:31 --> Input Class Initialized
INFO - 2019-09-14 16:39:31 --> Language Class Initialized
INFO - 2019-09-14 16:39:31 --> Loader Class Initialized
INFO - 2019-09-14 16:39:31 --> Helper loaded: url_helper
INFO - 2019-09-14 16:39:31 --> Helper loaded: html_helper
INFO - 2019-09-14 16:39:31 --> Helper loaded: form_helper
INFO - 2019-09-14 16:39:31 --> Helper loaded: cookie_helper
INFO - 2019-09-14 16:39:31 --> Helper loaded: date_helper
INFO - 2019-09-14 16:39:31 --> Form Validation Class Initialized
INFO - 2019-09-14 16:39:31 --> Email Class Initialized
DEBUG - 2019-09-14 16:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 16:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 16:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 16:39:31 --> Pagination Class Initialized
INFO - 2019-09-14 16:39:31 --> Database Driver Class Initialized
INFO - 2019-09-14 16:39:31 --> Database Driver Class Initialized
INFO - 2019-09-14 16:39:31 --> Controller Class Initialized
DEBUG - 2019-09-14 16:39:31 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 16:39:31 --> Helper loaded: inflector_helper
INFO - 2019-09-14 16:39:31 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 16:39:31 --> Severity: Warning --> Illegal string offset 'ReservationID' C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 37
ERROR - 2019-09-14 16:39:31 --> Query error: Unknown column 'ReservationID' in 'where clause' - Invalid query: SELECT `ID`
FROM `reservationitems`
WHERE `ReservationID` = '['
INFO - 2019-09-14 16:39:31 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 16:57:55 --> Config Class Initialized
INFO - 2019-09-14 16:57:55 --> Hooks Class Initialized
DEBUG - 2019-09-14 16:57:55 --> UTF-8 Support Enabled
INFO - 2019-09-14 16:57:55 --> Utf8 Class Initialized
INFO - 2019-09-14 16:57:55 --> URI Class Initialized
INFO - 2019-09-14 16:57:55 --> Router Class Initialized
INFO - 2019-09-14 16:57:55 --> Output Class Initialized
INFO - 2019-09-14 16:57:55 --> Security Class Initialized
DEBUG - 2019-09-14 16:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 16:57:55 --> Input Class Initialized
INFO - 2019-09-14 16:57:55 --> Language Class Initialized
INFO - 2019-09-14 16:57:55 --> Loader Class Initialized
INFO - 2019-09-14 16:57:55 --> Helper loaded: url_helper
INFO - 2019-09-14 16:57:55 --> Helper loaded: html_helper
INFO - 2019-09-14 16:57:55 --> Helper loaded: form_helper
INFO - 2019-09-14 16:57:55 --> Helper loaded: cookie_helper
INFO - 2019-09-14 16:57:55 --> Helper loaded: date_helper
INFO - 2019-09-14 16:57:55 --> Form Validation Class Initialized
INFO - 2019-09-14 16:57:55 --> Email Class Initialized
DEBUG - 2019-09-14 16:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 16:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 16:57:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 16:57:55 --> Pagination Class Initialized
INFO - 2019-09-14 16:57:55 --> Database Driver Class Initialized
INFO - 2019-09-14 16:57:55 --> Database Driver Class Initialized
INFO - 2019-09-14 16:57:55 --> Controller Class Initialized
DEBUG - 2019-09-14 16:57:55 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 16:57:55 --> Helper loaded: inflector_helper
INFO - 2019-09-14 16:57:55 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 16:57:55 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 37
INFO - 2019-09-14 17:00:06 --> Config Class Initialized
INFO - 2019-09-14 17:00:06 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:00:06 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:00:06 --> Utf8 Class Initialized
INFO - 2019-09-14 17:00:06 --> URI Class Initialized
INFO - 2019-09-14 17:00:06 --> Router Class Initialized
INFO - 2019-09-14 17:00:06 --> Output Class Initialized
INFO - 2019-09-14 17:00:06 --> Security Class Initialized
DEBUG - 2019-09-14 17:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:00:06 --> Input Class Initialized
INFO - 2019-09-14 17:00:06 --> Language Class Initialized
INFO - 2019-09-14 17:00:06 --> Loader Class Initialized
INFO - 2019-09-14 17:00:06 --> Helper loaded: url_helper
INFO - 2019-09-14 17:00:06 --> Helper loaded: html_helper
INFO - 2019-09-14 17:00:06 --> Helper loaded: form_helper
INFO - 2019-09-14 17:00:06 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:00:06 --> Helper loaded: date_helper
INFO - 2019-09-14 17:00:06 --> Form Validation Class Initialized
INFO - 2019-09-14 17:00:06 --> Email Class Initialized
DEBUG - 2019-09-14 17:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:00:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:00:06 --> Pagination Class Initialized
INFO - 2019-09-14 17:00:06 --> Database Driver Class Initialized
INFO - 2019-09-14 17:00:06 --> Database Driver Class Initialized
INFO - 2019-09-14 17:00:06 --> Controller Class Initialized
DEBUG - 2019-09-14 17:00:06 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:00:06 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:00:06 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 17:00:06 --> Query error: Unknown column 'ReservationID' in 'where clause' - Invalid query: SELECT `ID`
FROM `reservationitems`
WHERE `ReservationID` = '000000000009'
INFO - 2019-09-14 17:00:06 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 17:00:34 --> Config Class Initialized
INFO - 2019-09-14 17:00:34 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:00:34 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:00:34 --> Utf8 Class Initialized
INFO - 2019-09-14 17:00:34 --> URI Class Initialized
INFO - 2019-09-14 17:00:34 --> Router Class Initialized
INFO - 2019-09-14 17:00:34 --> Output Class Initialized
INFO - 2019-09-14 17:00:34 --> Security Class Initialized
DEBUG - 2019-09-14 17:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:00:34 --> Input Class Initialized
INFO - 2019-09-14 17:00:34 --> Language Class Initialized
INFO - 2019-09-14 17:00:34 --> Loader Class Initialized
INFO - 2019-09-14 17:00:34 --> Helper loaded: url_helper
INFO - 2019-09-14 17:00:34 --> Helper loaded: html_helper
INFO - 2019-09-14 17:00:34 --> Helper loaded: form_helper
INFO - 2019-09-14 17:00:34 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:00:34 --> Helper loaded: date_helper
INFO - 2019-09-14 17:00:34 --> Form Validation Class Initialized
INFO - 2019-09-14 17:00:34 --> Email Class Initialized
DEBUG - 2019-09-14 17:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:00:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:00:34 --> Pagination Class Initialized
INFO - 2019-09-14 17:00:34 --> Database Driver Class Initialized
INFO - 2019-09-14 17:00:34 --> Database Driver Class Initialized
INFO - 2019-09-14 17:00:34 --> Controller Class Initialized
DEBUG - 2019-09-14 17:00:34 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:00:34 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:00:34 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 17:00:34 --> Severity: Notice --> Undefined index: reservation_id C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 37
ERROR - 2019-09-14 17:00:34 --> Query error: Unknown column 'ReservationID' in 'field list' - Invalid query: INSERT INTO `reservationitems` (`ReservationID`, `AccountType`, `MasterID`, `Arrival`, `Departure`, `Nights`, `RoomNumber`, `RoomType`, `ClientType`, `ClientName`, `AgencyName`, `AgencyContact`, `Guest1`, `Guest2`, `GuestCount`, `Adults`, `Children`, `Type`, `Remarks`, `DateCreated`, `DateModified`, `SignatureCreated`, `SignatureModified`, `Status`, `Deleted`, `ActualArrival`, `ActualDeparture`, `LastRoomCharge`, `LastAccountClose`) VALUES ('000000000009', 'ROOM', '', '2019-08-29T00:00:00', '2019-08-31T00:00:00', 2, 12, 7, 'person', 'collins brad', '', '', 'collins brad', '', 1, 1, 0, 'reservation', '', '2019-08-28T15:01:40', '0001-01-01T00:00:00', 'MAZ', '', 'confirmed', '0', '0001-01-01T00:00:00', '0001-01-01T00:00:00', '0001-01-01T00:00:00', '0001-01-01T00:00:00')
INFO - 2019-09-14 17:00:34 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 17:02:07 --> Config Class Initialized
INFO - 2019-09-14 17:02:07 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:02:07 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:02:07 --> Utf8 Class Initialized
INFO - 2019-09-14 17:02:07 --> URI Class Initialized
INFO - 2019-09-14 17:02:07 --> Router Class Initialized
INFO - 2019-09-14 17:02:07 --> Output Class Initialized
INFO - 2019-09-14 17:02:07 --> Security Class Initialized
DEBUG - 2019-09-14 17:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:02:07 --> Input Class Initialized
INFO - 2019-09-14 17:02:07 --> Language Class Initialized
INFO - 2019-09-14 17:02:07 --> Loader Class Initialized
INFO - 2019-09-14 17:02:07 --> Helper loaded: url_helper
INFO - 2019-09-14 17:02:07 --> Helper loaded: html_helper
INFO - 2019-09-14 17:02:07 --> Helper loaded: form_helper
INFO - 2019-09-14 17:02:07 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:02:07 --> Helper loaded: date_helper
INFO - 2019-09-14 17:02:07 --> Form Validation Class Initialized
INFO - 2019-09-14 17:02:07 --> Email Class Initialized
DEBUG - 2019-09-14 17:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:02:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:02:07 --> Pagination Class Initialized
INFO - 2019-09-14 17:02:07 --> Database Driver Class Initialized
INFO - 2019-09-14 17:02:07 --> Database Driver Class Initialized
INFO - 2019-09-14 17:02:07 --> Controller Class Initialized
DEBUG - 2019-09-14 17:02:07 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:02:07 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:02:07 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 17:02:07 --> Query error: Unknown column 'ReservationID' in 'where clause' - Invalid query: SELECT `ID`
FROM `reservationitems`
WHERE `ReservationID` = '000000000009'
INFO - 2019-09-14 17:02:07 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 17:11:09 --> Config Class Initialized
INFO - 2019-09-14 17:11:09 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:11:09 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:11:09 --> Utf8 Class Initialized
INFO - 2019-09-14 17:11:09 --> URI Class Initialized
INFO - 2019-09-14 17:11:09 --> Router Class Initialized
INFO - 2019-09-14 17:11:09 --> Output Class Initialized
INFO - 2019-09-14 17:11:09 --> Security Class Initialized
DEBUG - 2019-09-14 17:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:11:09 --> Input Class Initialized
INFO - 2019-09-14 17:11:09 --> Language Class Initialized
INFO - 2019-09-14 17:11:09 --> Loader Class Initialized
INFO - 2019-09-14 17:11:09 --> Helper loaded: url_helper
INFO - 2019-09-14 17:11:09 --> Helper loaded: html_helper
INFO - 2019-09-14 17:11:09 --> Helper loaded: form_helper
INFO - 2019-09-14 17:11:09 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:11:09 --> Helper loaded: date_helper
INFO - 2019-09-14 17:11:09 --> Form Validation Class Initialized
INFO - 2019-09-14 17:11:09 --> Email Class Initialized
DEBUG - 2019-09-14 17:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:11:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:11:09 --> Pagination Class Initialized
INFO - 2019-09-14 17:11:09 --> Database Driver Class Initialized
INFO - 2019-09-14 17:11:09 --> Database Driver Class Initialized
INFO - 2019-09-14 17:11:09 --> Controller Class Initialized
DEBUG - 2019-09-14 17:11:09 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:11:09 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:11:09 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 17:11:09 --> Severity: Notice --> Undefined index: reservation_id C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 33
ERROR - 2019-09-14 17:11:09 --> Query error: Unknown column 'ReservationID' in 'field list' - Invalid query: INSERT INTO `reservationitems` (`ReservationID`, `AccountType`, `MasterID`, `Arrival`, `Departure`, `Nights`, `RoomNumber`, `RoomType`, `ClientType`, `ClientName`, `AgencyName`, `AgencyContact`, `Guest1`, `Guest2`, `GuestCount`, `Adults`, `Children`, `Type`, `Remarks`, `DateCreated`, `DateModified`, `SignatureCreated`, `SignatureModified`, `Status`, `Deleted`, `ActualArrival`, `ActualDeparture`, `LastRoomCharge`, `LastAccountClose`) VALUES ('000000000009', 'ROOM', '', '2019-08-29T00:00:00', '2019-08-31T00:00:00', 2, 12, 7, 'person', 'collins brad', '', '', 'collins brad', '', 1, 1, 0, 'reservation', '', '2019-08-28T15:01:40', '0001-01-01T00:00:00', 'MAZ', '', 'confirmed', '0', '0001-01-01T00:00:00', '0001-01-01T00:00:00', '0001-01-01T00:00:00', '0001-01-01T00:00:00')
INFO - 2019-09-14 17:11:09 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 17:11:24 --> Config Class Initialized
INFO - 2019-09-14 17:11:24 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:11:24 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:11:24 --> Utf8 Class Initialized
INFO - 2019-09-14 17:11:24 --> URI Class Initialized
INFO - 2019-09-14 17:11:24 --> Router Class Initialized
INFO - 2019-09-14 17:11:24 --> Output Class Initialized
INFO - 2019-09-14 17:11:24 --> Security Class Initialized
DEBUG - 2019-09-14 17:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:11:24 --> Input Class Initialized
INFO - 2019-09-14 17:11:24 --> Language Class Initialized
INFO - 2019-09-14 17:11:24 --> Loader Class Initialized
INFO - 2019-09-14 17:11:24 --> Helper loaded: url_helper
INFO - 2019-09-14 17:11:24 --> Helper loaded: html_helper
INFO - 2019-09-14 17:11:24 --> Helper loaded: form_helper
INFO - 2019-09-14 17:11:24 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:11:24 --> Helper loaded: date_helper
INFO - 2019-09-14 17:11:24 --> Form Validation Class Initialized
INFO - 2019-09-14 17:11:24 --> Email Class Initialized
DEBUG - 2019-09-14 17:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:11:24 --> Pagination Class Initialized
INFO - 2019-09-14 17:11:24 --> Database Driver Class Initialized
INFO - 2019-09-14 17:11:24 --> Database Driver Class Initialized
INFO - 2019-09-14 17:11:24 --> Controller Class Initialized
DEBUG - 2019-09-14 17:11:24 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:11:24 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:11:24 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 17:11:24 --> Severity: Notice --> Undefined index: reservation_id C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 33
ERROR - 2019-09-14 17:11:24 --> Query error: Unknown column 'ReservationID' in 'field list' - Invalid query: INSERT INTO `reservationitems` (`ReservationID`, `AccountType`, `MasterID`, `Arrival`, `Departure`, `Nights`, `RoomNumber`, `RoomType`, `ClientType`, `ClientName`, `AgencyName`, `AgencyContact`, `Guest1`, `Guest2`, `GuestCount`, `Adults`, `Children`, `Type`, `Remarks`, `DateCreated`, `DateModified`, `SignatureCreated`, `SignatureModified`, `Status`, `Deleted`, `ActualArrival`, `ActualDeparture`, `LastRoomCharge`, `LastAccountClose`) VALUES ('000000000009', 'ROOM', '', '2019-08-29T00:00:00', '2019-08-31T00:00:00', 2, 12, 7, 'person', 'collins brad', '', '', 'collins brad', '', 1, 1, 0, 'reservation', '', '2019-08-28T15:01:40', '0001-01-01T00:00:00', 'MAZ', '', 'confirmed', '0', '0001-01-01T00:00:00', '0001-01-01T00:00:00', '0001-01-01T00:00:00', '0001-01-01T00:00:00')
INFO - 2019-09-14 17:11:24 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-14 17:12:15 --> Config Class Initialized
INFO - 2019-09-14 17:12:15 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:12:15 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:12:15 --> Utf8 Class Initialized
INFO - 2019-09-14 17:12:15 --> URI Class Initialized
INFO - 2019-09-14 17:12:15 --> Router Class Initialized
INFO - 2019-09-14 17:12:15 --> Output Class Initialized
INFO - 2019-09-14 17:12:15 --> Security Class Initialized
DEBUG - 2019-09-14 17:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:12:15 --> Input Class Initialized
INFO - 2019-09-14 17:12:15 --> Language Class Initialized
INFO - 2019-09-14 17:12:15 --> Loader Class Initialized
INFO - 2019-09-14 17:12:15 --> Helper loaded: url_helper
INFO - 2019-09-14 17:12:15 --> Helper loaded: html_helper
INFO - 2019-09-14 17:12:15 --> Helper loaded: form_helper
INFO - 2019-09-14 17:12:15 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:12:15 --> Helper loaded: date_helper
INFO - 2019-09-14 17:12:15 --> Form Validation Class Initialized
INFO - 2019-09-14 17:12:15 --> Email Class Initialized
DEBUG - 2019-09-14 17:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:12:15 --> Pagination Class Initialized
INFO - 2019-09-14 17:12:15 --> Database Driver Class Initialized
INFO - 2019-09-14 17:12:15 --> Database Driver Class Initialized
INFO - 2019-09-14 17:12:15 --> Controller Class Initialized
DEBUG - 2019-09-14 17:12:15 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:12:15 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:12:15 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 17:12:15 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 27
ERROR - 2019-09-14 17:12:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 29
INFO - 2019-09-14 17:12:15 --> Final output sent to browser
DEBUG - 2019-09-14 17:12:15 --> Total execution time: 0.0645
INFO - 2019-09-14 17:13:09 --> Config Class Initialized
INFO - 2019-09-14 17:13:09 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:13:09 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:13:09 --> Utf8 Class Initialized
INFO - 2019-09-14 17:13:09 --> URI Class Initialized
INFO - 2019-09-14 17:13:09 --> Router Class Initialized
INFO - 2019-09-14 17:13:09 --> Output Class Initialized
INFO - 2019-09-14 17:13:09 --> Security Class Initialized
DEBUG - 2019-09-14 17:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:13:09 --> Input Class Initialized
INFO - 2019-09-14 17:13:09 --> Language Class Initialized
INFO - 2019-09-14 17:13:09 --> Loader Class Initialized
INFO - 2019-09-14 17:13:09 --> Helper loaded: url_helper
INFO - 2019-09-14 17:13:09 --> Helper loaded: html_helper
INFO - 2019-09-14 17:13:09 --> Helper loaded: form_helper
INFO - 2019-09-14 17:13:09 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:13:09 --> Helper loaded: date_helper
INFO - 2019-09-14 17:13:09 --> Form Validation Class Initialized
INFO - 2019-09-14 17:13:09 --> Email Class Initialized
DEBUG - 2019-09-14 17:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:13:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:13:09 --> Pagination Class Initialized
INFO - 2019-09-14 17:13:09 --> Database Driver Class Initialized
INFO - 2019-09-14 17:13:09 --> Database Driver Class Initialized
INFO - 2019-09-14 17:13:09 --> Controller Class Initialized
DEBUG - 2019-09-14 17:13:09 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:13:09 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:13:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 17:13:09 --> Final output sent to browser
DEBUG - 2019-09-14 17:13:09 --> Total execution time: 0.0641
INFO - 2019-09-14 17:15:21 --> Config Class Initialized
INFO - 2019-09-14 17:15:21 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:15:21 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:15:21 --> Utf8 Class Initialized
INFO - 2019-09-14 17:15:21 --> URI Class Initialized
INFO - 2019-09-14 17:15:21 --> Router Class Initialized
INFO - 2019-09-14 17:15:21 --> Output Class Initialized
INFO - 2019-09-14 17:15:21 --> Security Class Initialized
DEBUG - 2019-09-14 17:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:15:21 --> Input Class Initialized
INFO - 2019-09-14 17:15:21 --> Language Class Initialized
INFO - 2019-09-14 17:15:21 --> Loader Class Initialized
INFO - 2019-09-14 17:15:21 --> Helper loaded: url_helper
INFO - 2019-09-14 17:15:21 --> Helper loaded: html_helper
INFO - 2019-09-14 17:15:21 --> Helper loaded: form_helper
INFO - 2019-09-14 17:15:21 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:15:21 --> Helper loaded: date_helper
INFO - 2019-09-14 17:15:21 --> Form Validation Class Initialized
INFO - 2019-09-14 17:15:21 --> Email Class Initialized
DEBUG - 2019-09-14 17:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:15:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:15:21 --> Pagination Class Initialized
INFO - 2019-09-14 17:15:21 --> Database Driver Class Initialized
INFO - 2019-09-14 17:15:21 --> Database Driver Class Initialized
INFO - 2019-09-14 17:15:21 --> Controller Class Initialized
DEBUG - 2019-09-14 17:15:21 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:15:21 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:15:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 17:15:21 --> Final output sent to browser
DEBUG - 2019-09-14 17:15:21 --> Total execution time: 0.0726
INFO - 2019-09-14 17:15:46 --> Config Class Initialized
INFO - 2019-09-14 17:15:46 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:15:46 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:15:46 --> Utf8 Class Initialized
INFO - 2019-09-14 17:15:46 --> URI Class Initialized
INFO - 2019-09-14 17:15:46 --> Router Class Initialized
INFO - 2019-09-14 17:15:46 --> Output Class Initialized
INFO - 2019-09-14 17:15:46 --> Security Class Initialized
DEBUG - 2019-09-14 17:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:15:46 --> Input Class Initialized
INFO - 2019-09-14 17:15:46 --> Language Class Initialized
INFO - 2019-09-14 17:15:46 --> Loader Class Initialized
INFO - 2019-09-14 17:15:46 --> Helper loaded: url_helper
INFO - 2019-09-14 17:15:46 --> Helper loaded: html_helper
INFO - 2019-09-14 17:15:46 --> Helper loaded: form_helper
INFO - 2019-09-14 17:15:46 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:15:46 --> Helper loaded: date_helper
INFO - 2019-09-14 17:15:46 --> Form Validation Class Initialized
INFO - 2019-09-14 17:15:46 --> Email Class Initialized
DEBUG - 2019-09-14 17:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:15:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:15:46 --> Pagination Class Initialized
INFO - 2019-09-14 17:15:46 --> Database Driver Class Initialized
INFO - 2019-09-14 17:15:46 --> Database Driver Class Initialized
INFO - 2019-09-14 17:15:46 --> Controller Class Initialized
DEBUG - 2019-09-14 17:15:46 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:15:46 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:15:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 17:15:46 --> Final output sent to browser
DEBUG - 2019-09-14 17:15:46 --> Total execution time: 0.0556
INFO - 2019-09-14 17:17:16 --> Config Class Initialized
INFO - 2019-09-14 17:17:16 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:17:16 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:17:16 --> Utf8 Class Initialized
INFO - 2019-09-14 17:17:16 --> URI Class Initialized
INFO - 2019-09-14 17:17:16 --> Router Class Initialized
INFO - 2019-09-14 17:17:16 --> Output Class Initialized
INFO - 2019-09-14 17:17:16 --> Security Class Initialized
DEBUG - 2019-09-14 17:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:17:16 --> Input Class Initialized
INFO - 2019-09-14 17:17:16 --> Language Class Initialized
INFO - 2019-09-14 17:17:16 --> Loader Class Initialized
INFO - 2019-09-14 17:17:16 --> Helper loaded: url_helper
INFO - 2019-09-14 17:17:16 --> Helper loaded: html_helper
INFO - 2019-09-14 17:17:16 --> Helper loaded: form_helper
INFO - 2019-09-14 17:17:16 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:17:16 --> Helper loaded: date_helper
INFO - 2019-09-14 17:17:16 --> Form Validation Class Initialized
INFO - 2019-09-14 17:17:16 --> Email Class Initialized
DEBUG - 2019-09-14 17:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:17:16 --> Pagination Class Initialized
INFO - 2019-09-14 17:17:16 --> Database Driver Class Initialized
INFO - 2019-09-14 17:17:16 --> Database Driver Class Initialized
INFO - 2019-09-14 17:17:16 --> Controller Class Initialized
DEBUG - 2019-09-14 17:17:16 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:17:16 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:17:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 17:17:16 --> Final output sent to browser
DEBUG - 2019-09-14 17:17:16 --> Total execution time: 0.0508
INFO - 2019-09-14 17:17:34 --> Config Class Initialized
INFO - 2019-09-14 17:17:34 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:17:34 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:17:34 --> Utf8 Class Initialized
INFO - 2019-09-14 17:17:34 --> URI Class Initialized
INFO - 2019-09-14 17:17:34 --> Router Class Initialized
INFO - 2019-09-14 17:17:34 --> Output Class Initialized
INFO - 2019-09-14 17:17:34 --> Security Class Initialized
DEBUG - 2019-09-14 17:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:17:34 --> Input Class Initialized
INFO - 2019-09-14 17:17:34 --> Language Class Initialized
INFO - 2019-09-14 17:17:34 --> Loader Class Initialized
INFO - 2019-09-14 17:17:34 --> Helper loaded: url_helper
INFO - 2019-09-14 17:17:34 --> Helper loaded: html_helper
INFO - 2019-09-14 17:17:34 --> Helper loaded: form_helper
INFO - 2019-09-14 17:17:34 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:17:34 --> Helper loaded: date_helper
INFO - 2019-09-14 17:17:34 --> Form Validation Class Initialized
INFO - 2019-09-14 17:17:34 --> Email Class Initialized
DEBUG - 2019-09-14 17:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:17:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:17:34 --> Pagination Class Initialized
INFO - 2019-09-14 17:17:34 --> Database Driver Class Initialized
INFO - 2019-09-14 17:17:34 --> Database Driver Class Initialized
INFO - 2019-09-14 17:17:34 --> Controller Class Initialized
DEBUG - 2019-09-14 17:17:34 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:17:34 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:17:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 17:17:49 --> Config Class Initialized
INFO - 2019-09-14 17:17:49 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:17:49 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:17:49 --> Utf8 Class Initialized
INFO - 2019-09-14 17:17:49 --> URI Class Initialized
INFO - 2019-09-14 17:17:49 --> Router Class Initialized
INFO - 2019-09-14 17:17:49 --> Output Class Initialized
INFO - 2019-09-14 17:17:49 --> Security Class Initialized
DEBUG - 2019-09-14 17:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:17:49 --> Input Class Initialized
INFO - 2019-09-14 17:17:49 --> Language Class Initialized
INFO - 2019-09-14 17:17:49 --> Loader Class Initialized
INFO - 2019-09-14 17:17:49 --> Helper loaded: url_helper
INFO - 2019-09-14 17:17:49 --> Helper loaded: html_helper
INFO - 2019-09-14 17:17:49 --> Helper loaded: form_helper
INFO - 2019-09-14 17:17:49 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:17:49 --> Helper loaded: date_helper
INFO - 2019-09-14 17:17:49 --> Form Validation Class Initialized
INFO - 2019-09-14 17:17:49 --> Email Class Initialized
DEBUG - 2019-09-14 17:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:17:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:17:49 --> Pagination Class Initialized
INFO - 2019-09-14 17:17:49 --> Database Driver Class Initialized
INFO - 2019-09-14 17:17:49 --> Database Driver Class Initialized
INFO - 2019-09-14 17:17:49 --> Controller Class Initialized
DEBUG - 2019-09-14 17:17:49 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:17:49 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:17:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 17:18:01 --> Config Class Initialized
INFO - 2019-09-14 17:18:01 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:18:01 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:18:01 --> Utf8 Class Initialized
INFO - 2019-09-14 17:18:01 --> URI Class Initialized
INFO - 2019-09-14 17:18:01 --> Router Class Initialized
INFO - 2019-09-14 17:18:01 --> Output Class Initialized
INFO - 2019-09-14 17:18:01 --> Security Class Initialized
DEBUG - 2019-09-14 17:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:18:01 --> Input Class Initialized
INFO - 2019-09-14 17:18:01 --> Language Class Initialized
INFO - 2019-09-14 17:18:01 --> Loader Class Initialized
INFO - 2019-09-14 17:18:01 --> Helper loaded: url_helper
INFO - 2019-09-14 17:18:01 --> Helper loaded: html_helper
INFO - 2019-09-14 17:18:01 --> Helper loaded: form_helper
INFO - 2019-09-14 17:18:01 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:18:01 --> Helper loaded: date_helper
INFO - 2019-09-14 17:18:01 --> Form Validation Class Initialized
INFO - 2019-09-14 17:18:01 --> Email Class Initialized
DEBUG - 2019-09-14 17:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:18:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:18:01 --> Pagination Class Initialized
INFO - 2019-09-14 17:18:01 --> Database Driver Class Initialized
INFO - 2019-09-14 17:18:01 --> Database Driver Class Initialized
INFO - 2019-09-14 17:18:01 --> Controller Class Initialized
DEBUG - 2019-09-14 17:18:01 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:18:01 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:18:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 17:18:01 --> Final output sent to browser
DEBUG - 2019-09-14 17:18:01 --> Total execution time: 0.2192
INFO - 2019-09-14 17:29:51 --> Config Class Initialized
INFO - 2019-09-14 17:29:51 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:29:51 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:29:51 --> Utf8 Class Initialized
INFO - 2019-09-14 17:29:51 --> URI Class Initialized
INFO - 2019-09-14 17:29:51 --> Router Class Initialized
INFO - 2019-09-14 17:29:51 --> Output Class Initialized
INFO - 2019-09-14 17:29:51 --> Security Class Initialized
DEBUG - 2019-09-14 17:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:29:51 --> Input Class Initialized
INFO - 2019-09-14 17:29:51 --> Language Class Initialized
INFO - 2019-09-14 17:29:51 --> Loader Class Initialized
INFO - 2019-09-14 17:29:51 --> Helper loaded: url_helper
INFO - 2019-09-14 17:29:51 --> Helper loaded: html_helper
INFO - 2019-09-14 17:29:51 --> Helper loaded: form_helper
INFO - 2019-09-14 17:29:51 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:29:51 --> Helper loaded: date_helper
INFO - 2019-09-14 17:29:51 --> Form Validation Class Initialized
INFO - 2019-09-14 17:29:51 --> Email Class Initialized
DEBUG - 2019-09-14 17:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:29:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:29:51 --> Pagination Class Initialized
INFO - 2019-09-14 17:29:51 --> Database Driver Class Initialized
INFO - 2019-09-14 17:29:51 --> Database Driver Class Initialized
INFO - 2019-09-14 17:29:51 --> Controller Class Initialized
DEBUG - 2019-09-14 17:29:51 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:29:51 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:29:51 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 17:29:51 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 27
ERROR - 2019-09-14 17:29:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 29
INFO - 2019-09-14 17:29:51 --> Final output sent to browser
DEBUG - 2019-09-14 17:29:51 --> Total execution time: 0.0744
INFO - 2019-09-14 17:34:42 --> Config Class Initialized
INFO - 2019-09-14 17:34:42 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:34:42 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:34:42 --> Utf8 Class Initialized
INFO - 2019-09-14 17:34:42 --> URI Class Initialized
INFO - 2019-09-14 17:34:42 --> Router Class Initialized
INFO - 2019-09-14 17:34:42 --> Output Class Initialized
INFO - 2019-09-14 17:34:42 --> Security Class Initialized
DEBUG - 2019-09-14 17:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:34:42 --> Input Class Initialized
INFO - 2019-09-14 17:34:42 --> Language Class Initialized
INFO - 2019-09-14 17:34:42 --> Loader Class Initialized
INFO - 2019-09-14 17:34:42 --> Helper loaded: url_helper
INFO - 2019-09-14 17:34:42 --> Helper loaded: html_helper
INFO - 2019-09-14 17:34:42 --> Helper loaded: form_helper
INFO - 2019-09-14 17:34:42 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:34:42 --> Helper loaded: date_helper
INFO - 2019-09-14 17:34:42 --> Form Validation Class Initialized
INFO - 2019-09-14 17:34:42 --> Email Class Initialized
DEBUG - 2019-09-14 17:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:34:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:34:42 --> Pagination Class Initialized
INFO - 2019-09-14 17:34:42 --> Database Driver Class Initialized
INFO - 2019-09-14 17:34:42 --> Database Driver Class Initialized
INFO - 2019-09-14 17:34:42 --> Controller Class Initialized
DEBUG - 2019-09-14 17:34:42 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:34:42 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:34:42 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 17:34:42 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 27
ERROR - 2019-09-14 17:34:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 29
INFO - 2019-09-14 17:34:42 --> Final output sent to browser
DEBUG - 2019-09-14 17:34:42 --> Total execution time: 0.0592
INFO - 2019-09-14 17:37:26 --> Config Class Initialized
INFO - 2019-09-14 17:37:26 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:37:26 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:37:26 --> Utf8 Class Initialized
INFO - 2019-09-14 17:37:26 --> URI Class Initialized
INFO - 2019-09-14 17:37:26 --> Router Class Initialized
INFO - 2019-09-14 17:37:26 --> Output Class Initialized
INFO - 2019-09-14 17:37:26 --> Security Class Initialized
DEBUG - 2019-09-14 17:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:37:26 --> Input Class Initialized
INFO - 2019-09-14 17:37:26 --> Language Class Initialized
INFO - 2019-09-14 17:37:26 --> Loader Class Initialized
INFO - 2019-09-14 17:37:26 --> Helper loaded: url_helper
INFO - 2019-09-14 17:37:26 --> Helper loaded: html_helper
INFO - 2019-09-14 17:37:26 --> Helper loaded: form_helper
INFO - 2019-09-14 17:37:26 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:37:26 --> Helper loaded: date_helper
INFO - 2019-09-14 17:37:26 --> Form Validation Class Initialized
INFO - 2019-09-14 17:37:26 --> Email Class Initialized
DEBUG - 2019-09-14 17:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:37:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:37:26 --> Pagination Class Initialized
INFO - 2019-09-14 17:37:26 --> Database Driver Class Initialized
INFO - 2019-09-14 17:37:26 --> Database Driver Class Initialized
INFO - 2019-09-14 17:37:26 --> Controller Class Initialized
DEBUG - 2019-09-14 17:37:26 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:37:26 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:37:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 17:37:27 --> Final output sent to browser
DEBUG - 2019-09-14 17:37:27 --> Total execution time: 0.1703
INFO - 2019-09-14 17:39:04 --> Config Class Initialized
INFO - 2019-09-14 17:39:04 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:39:04 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:39:04 --> Utf8 Class Initialized
INFO - 2019-09-14 17:39:04 --> URI Class Initialized
INFO - 2019-09-14 17:39:04 --> Router Class Initialized
INFO - 2019-09-14 17:39:04 --> Output Class Initialized
INFO - 2019-09-14 17:39:04 --> Security Class Initialized
DEBUG - 2019-09-14 17:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:39:04 --> Input Class Initialized
INFO - 2019-09-14 17:39:04 --> Language Class Initialized
INFO - 2019-09-14 17:39:04 --> Loader Class Initialized
INFO - 2019-09-14 17:39:04 --> Helper loaded: url_helper
INFO - 2019-09-14 17:39:04 --> Helper loaded: html_helper
INFO - 2019-09-14 17:39:04 --> Helper loaded: form_helper
INFO - 2019-09-14 17:39:04 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:39:04 --> Helper loaded: date_helper
INFO - 2019-09-14 17:39:04 --> Form Validation Class Initialized
INFO - 2019-09-14 17:39:04 --> Email Class Initialized
DEBUG - 2019-09-14 17:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:39:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:39:04 --> Pagination Class Initialized
INFO - 2019-09-14 17:39:04 --> Database Driver Class Initialized
INFO - 2019-09-14 17:39:04 --> Database Driver Class Initialized
INFO - 2019-09-14 17:39:04 --> Controller Class Initialized
DEBUG - 2019-09-14 17:39:04 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:39:04 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:39:04 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 17:39:04 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 27
ERROR - 2019-09-14 17:39:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 29
INFO - 2019-09-14 17:39:04 --> Final output sent to browser
DEBUG - 2019-09-14 17:39:04 --> Total execution time: 0.0455
INFO - 2019-09-14 17:46:40 --> Config Class Initialized
INFO - 2019-09-14 17:46:40 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:46:40 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:46:40 --> Utf8 Class Initialized
INFO - 2019-09-14 17:46:40 --> URI Class Initialized
INFO - 2019-09-14 17:46:40 --> Router Class Initialized
INFO - 2019-09-14 17:46:40 --> Output Class Initialized
INFO - 2019-09-14 17:46:40 --> Security Class Initialized
DEBUG - 2019-09-14 17:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:46:40 --> Input Class Initialized
INFO - 2019-09-14 17:46:40 --> Language Class Initialized
INFO - 2019-09-14 17:46:40 --> Loader Class Initialized
INFO - 2019-09-14 17:46:40 --> Helper loaded: url_helper
INFO - 2019-09-14 17:46:40 --> Helper loaded: html_helper
INFO - 2019-09-14 17:46:40 --> Helper loaded: form_helper
INFO - 2019-09-14 17:46:40 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:46:40 --> Helper loaded: date_helper
INFO - 2019-09-14 17:46:40 --> Form Validation Class Initialized
INFO - 2019-09-14 17:46:40 --> Email Class Initialized
DEBUG - 2019-09-14 17:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:46:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:46:40 --> Pagination Class Initialized
INFO - 2019-09-14 17:46:40 --> Database Driver Class Initialized
INFO - 2019-09-14 17:46:40 --> Database Driver Class Initialized
INFO - 2019-09-14 17:46:40 --> Controller Class Initialized
DEBUG - 2019-09-14 17:46:40 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:46:40 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:46:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 17:46:40 --> Final output sent to browser
DEBUG - 2019-09-14 17:46:40 --> Total execution time: 0.0585
INFO - 2019-09-14 17:46:44 --> Config Class Initialized
INFO - 2019-09-14 17:46:44 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:46:44 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:46:44 --> Utf8 Class Initialized
INFO - 2019-09-14 17:46:44 --> URI Class Initialized
INFO - 2019-09-14 17:46:44 --> Router Class Initialized
INFO - 2019-09-14 17:46:44 --> Output Class Initialized
INFO - 2019-09-14 17:46:44 --> Security Class Initialized
DEBUG - 2019-09-14 17:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:46:44 --> Input Class Initialized
INFO - 2019-09-14 17:46:44 --> Language Class Initialized
INFO - 2019-09-14 17:46:44 --> Loader Class Initialized
INFO - 2019-09-14 17:46:44 --> Helper loaded: url_helper
INFO - 2019-09-14 17:46:44 --> Helper loaded: html_helper
INFO - 2019-09-14 17:46:44 --> Helper loaded: form_helper
INFO - 2019-09-14 17:46:44 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:46:44 --> Helper loaded: date_helper
INFO - 2019-09-14 17:46:44 --> Form Validation Class Initialized
INFO - 2019-09-14 17:46:44 --> Email Class Initialized
DEBUG - 2019-09-14 17:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:46:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:46:44 --> Pagination Class Initialized
INFO - 2019-09-14 17:46:44 --> Database Driver Class Initialized
INFO - 2019-09-14 17:46:44 --> Database Driver Class Initialized
INFO - 2019-09-14 17:46:44 --> Controller Class Initialized
DEBUG - 2019-09-14 17:46:44 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:46:44 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:46:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 17:46:44 --> Final output sent to browser
DEBUG - 2019-09-14 17:46:44 --> Total execution time: 0.0538
INFO - 2019-09-14 17:47:12 --> Config Class Initialized
INFO - 2019-09-14 17:47:12 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:47:12 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:47:12 --> Utf8 Class Initialized
INFO - 2019-09-14 17:47:12 --> URI Class Initialized
INFO - 2019-09-14 17:47:12 --> Router Class Initialized
INFO - 2019-09-14 17:47:12 --> Output Class Initialized
INFO - 2019-09-14 17:47:12 --> Security Class Initialized
DEBUG - 2019-09-14 17:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:47:12 --> Input Class Initialized
INFO - 2019-09-14 17:47:12 --> Language Class Initialized
INFO - 2019-09-14 17:47:12 --> Loader Class Initialized
INFO - 2019-09-14 17:47:12 --> Helper loaded: url_helper
INFO - 2019-09-14 17:47:12 --> Helper loaded: html_helper
INFO - 2019-09-14 17:47:12 --> Helper loaded: form_helper
INFO - 2019-09-14 17:47:12 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:47:12 --> Helper loaded: date_helper
INFO - 2019-09-14 17:47:12 --> Form Validation Class Initialized
INFO - 2019-09-14 17:47:12 --> Email Class Initialized
DEBUG - 2019-09-14 17:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:47:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:47:12 --> Pagination Class Initialized
INFO - 2019-09-14 17:47:12 --> Database Driver Class Initialized
INFO - 2019-09-14 17:47:12 --> Database Driver Class Initialized
INFO - 2019-09-14 17:47:12 --> Controller Class Initialized
DEBUG - 2019-09-14 17:47:12 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:47:12 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:47:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 17:47:12 --> Final output sent to browser
DEBUG - 2019-09-14 17:47:12 --> Total execution time: 0.2260
INFO - 2019-09-14 17:47:35 --> Config Class Initialized
INFO - 2019-09-14 17:47:35 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:47:35 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:47:35 --> Utf8 Class Initialized
INFO - 2019-09-14 17:47:35 --> URI Class Initialized
INFO - 2019-09-14 17:47:35 --> Router Class Initialized
INFO - 2019-09-14 17:47:35 --> Output Class Initialized
INFO - 2019-09-14 17:47:35 --> Security Class Initialized
DEBUG - 2019-09-14 17:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:47:35 --> Input Class Initialized
INFO - 2019-09-14 17:47:35 --> Language Class Initialized
INFO - 2019-09-14 17:47:35 --> Loader Class Initialized
INFO - 2019-09-14 17:47:35 --> Helper loaded: url_helper
INFO - 2019-09-14 17:47:35 --> Helper loaded: html_helper
INFO - 2019-09-14 17:47:35 --> Helper loaded: form_helper
INFO - 2019-09-14 17:47:35 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:47:35 --> Helper loaded: date_helper
INFO - 2019-09-14 17:47:35 --> Form Validation Class Initialized
INFO - 2019-09-14 17:47:35 --> Email Class Initialized
DEBUG - 2019-09-14 17:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:47:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:47:35 --> Pagination Class Initialized
INFO - 2019-09-14 17:47:35 --> Database Driver Class Initialized
INFO - 2019-09-14 17:47:35 --> Database Driver Class Initialized
INFO - 2019-09-14 17:47:35 --> Controller Class Initialized
DEBUG - 2019-09-14 17:47:35 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:47:35 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:47:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 17:47:35 --> Final output sent to browser
DEBUG - 2019-09-14 17:47:35 --> Total execution time: 0.0600
INFO - 2019-09-14 17:56:48 --> Config Class Initialized
INFO - 2019-09-14 17:56:48 --> Hooks Class Initialized
DEBUG - 2019-09-14 17:56:48 --> UTF-8 Support Enabled
INFO - 2019-09-14 17:56:48 --> Utf8 Class Initialized
INFO - 2019-09-14 17:56:48 --> URI Class Initialized
INFO - 2019-09-14 17:56:48 --> Router Class Initialized
INFO - 2019-09-14 17:56:48 --> Output Class Initialized
INFO - 2019-09-14 17:56:48 --> Security Class Initialized
DEBUG - 2019-09-14 17:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 17:56:48 --> Input Class Initialized
INFO - 2019-09-14 17:56:48 --> Language Class Initialized
INFO - 2019-09-14 17:56:48 --> Loader Class Initialized
INFO - 2019-09-14 17:56:48 --> Helper loaded: url_helper
INFO - 2019-09-14 17:56:48 --> Helper loaded: html_helper
INFO - 2019-09-14 17:56:48 --> Helper loaded: form_helper
INFO - 2019-09-14 17:56:48 --> Helper loaded: cookie_helper
INFO - 2019-09-14 17:56:48 --> Helper loaded: date_helper
INFO - 2019-09-14 17:56:48 --> Form Validation Class Initialized
INFO - 2019-09-14 17:56:48 --> Email Class Initialized
DEBUG - 2019-09-14 17:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 17:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 17:56:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 17:56:48 --> Pagination Class Initialized
INFO - 2019-09-14 17:56:48 --> Database Driver Class Initialized
INFO - 2019-09-14 17:56:48 --> Database Driver Class Initialized
INFO - 2019-09-14 17:56:48 --> Controller Class Initialized
DEBUG - 2019-09-14 17:56:48 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 17:56:48 --> Helper loaded: inflector_helper
INFO - 2019-09-14 17:56:48 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-14 17:56:48 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 27
ERROR - 2019-09-14 17:56:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 29
INFO - 2019-09-14 17:56:48 --> Final output sent to browser
DEBUG - 2019-09-14 17:56:48 --> Total execution time: 0.0636
INFO - 2019-09-14 18:15:46 --> Config Class Initialized
INFO - 2019-09-14 18:15:46 --> Hooks Class Initialized
DEBUG - 2019-09-14 18:15:46 --> UTF-8 Support Enabled
INFO - 2019-09-14 18:15:46 --> Utf8 Class Initialized
INFO - 2019-09-14 18:15:46 --> URI Class Initialized
INFO - 2019-09-14 18:15:46 --> Router Class Initialized
INFO - 2019-09-14 18:15:46 --> Output Class Initialized
INFO - 2019-09-14 18:15:46 --> Security Class Initialized
DEBUG - 2019-09-14 18:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 18:15:46 --> Input Class Initialized
INFO - 2019-09-14 18:15:46 --> Language Class Initialized
INFO - 2019-09-14 18:15:46 --> Loader Class Initialized
INFO - 2019-09-14 18:15:46 --> Helper loaded: url_helper
INFO - 2019-09-14 18:15:46 --> Helper loaded: html_helper
INFO - 2019-09-14 18:15:46 --> Helper loaded: form_helper
INFO - 2019-09-14 18:15:46 --> Helper loaded: cookie_helper
INFO - 2019-09-14 18:15:46 --> Helper loaded: date_helper
INFO - 2019-09-14 18:15:46 --> Form Validation Class Initialized
INFO - 2019-09-14 18:15:46 --> Email Class Initialized
DEBUG - 2019-09-14 18:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 18:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 18:15:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 18:15:46 --> Pagination Class Initialized
INFO - 2019-09-14 18:15:46 --> Database Driver Class Initialized
INFO - 2019-09-14 18:15:46 --> Database Driver Class Initialized
INFO - 2019-09-14 18:15:46 --> Controller Class Initialized
DEBUG - 2019-09-14 18:15:46 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 18:15:46 --> Helper loaded: inflector_helper
INFO - 2019-09-14 18:15:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 19:41:35 --> Config Class Initialized
INFO - 2019-09-14 19:41:35 --> Hooks Class Initialized
DEBUG - 2019-09-14 19:41:35 --> UTF-8 Support Enabled
INFO - 2019-09-14 19:41:35 --> Utf8 Class Initialized
INFO - 2019-09-14 19:41:35 --> URI Class Initialized
INFO - 2019-09-14 19:41:35 --> Router Class Initialized
INFO - 2019-09-14 19:41:35 --> Output Class Initialized
INFO - 2019-09-14 19:41:35 --> Security Class Initialized
DEBUG - 2019-09-14 19:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 19:41:35 --> Input Class Initialized
INFO - 2019-09-14 19:41:35 --> Language Class Initialized
INFO - 2019-09-14 19:41:35 --> Loader Class Initialized
INFO - 2019-09-14 19:41:35 --> Helper loaded: url_helper
INFO - 2019-09-14 19:41:35 --> Helper loaded: html_helper
INFO - 2019-09-14 19:41:35 --> Helper loaded: form_helper
INFO - 2019-09-14 19:41:35 --> Helper loaded: cookie_helper
INFO - 2019-09-14 19:41:35 --> Helper loaded: date_helper
INFO - 2019-09-14 19:41:35 --> Form Validation Class Initialized
INFO - 2019-09-14 19:41:36 --> Email Class Initialized
DEBUG - 2019-09-14 19:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 19:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 19:41:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 19:41:36 --> Pagination Class Initialized
INFO - 2019-09-14 19:41:36 --> Database Driver Class Initialized
INFO - 2019-09-14 19:41:36 --> Database Driver Class Initialized
INFO - 2019-09-14 19:41:36 --> Controller Class Initialized
DEBUG - 2019-09-14 19:41:36 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 19:41:36 --> Helper loaded: inflector_helper
INFO - 2019-09-14 19:41:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-14 19:43:01 --> Config Class Initialized
INFO - 2019-09-14 19:43:01 --> Hooks Class Initialized
DEBUG - 2019-09-14 19:43:01 --> UTF-8 Support Enabled
INFO - 2019-09-14 19:43:01 --> Utf8 Class Initialized
INFO - 2019-09-14 19:43:01 --> URI Class Initialized
INFO - 2019-09-14 19:43:01 --> Router Class Initialized
INFO - 2019-09-14 19:43:01 --> Output Class Initialized
INFO - 2019-09-14 19:43:01 --> Security Class Initialized
DEBUG - 2019-09-14 19:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-14 19:43:01 --> Input Class Initialized
INFO - 2019-09-14 19:43:01 --> Language Class Initialized
INFO - 2019-09-14 19:43:02 --> Loader Class Initialized
INFO - 2019-09-14 19:43:02 --> Helper loaded: url_helper
INFO - 2019-09-14 19:43:02 --> Helper loaded: html_helper
INFO - 2019-09-14 19:43:02 --> Helper loaded: form_helper
INFO - 2019-09-14 19:43:02 --> Helper loaded: cookie_helper
INFO - 2019-09-14 19:43:02 --> Helper loaded: date_helper
INFO - 2019-09-14 19:43:02 --> Form Validation Class Initialized
INFO - 2019-09-14 19:43:02 --> Email Class Initialized
DEBUG - 2019-09-14 19:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-14 19:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-14 19:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-14 19:43:02 --> Pagination Class Initialized
INFO - 2019-09-14 19:43:02 --> Database Driver Class Initialized
INFO - 2019-09-14 19:43:02 --> Database Driver Class Initialized
INFO - 2019-09-14 19:43:02 --> Controller Class Initialized
DEBUG - 2019-09-14 19:43:02 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-14 19:43:02 --> Helper loaded: inflector_helper
INFO - 2019-09-14 19:43:02 --> Language file loaded: language/english/rest_controller_lang.php
