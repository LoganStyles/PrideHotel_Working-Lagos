<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-28 19:59:56 --> Config Class Initialized
INFO - 2018-11-28 19:59:56 --> Hooks Class Initialized
DEBUG - 2018-11-28 19:59:56 --> UTF-8 Support Enabled
INFO - 2018-11-28 19:59:56 --> Utf8 Class Initialized
INFO - 2018-11-28 19:59:56 --> URI Class Initialized
DEBUG - 2018-11-28 19:59:56 --> No URI present. Default controller set.
INFO - 2018-11-28 19:59:56 --> Router Class Initialized
INFO - 2018-11-28 19:59:56 --> Output Class Initialized
INFO - 2018-11-28 19:59:56 --> Security Class Initialized
DEBUG - 2018-11-28 19:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-28 19:59:56 --> Input Class Initialized
INFO - 2018-11-28 19:59:56 --> Language Class Initialized
INFO - 2018-11-28 19:59:56 --> Loader Class Initialized
INFO - 2018-11-28 19:59:56 --> Helper loaded: url_helper
INFO - 2018-11-28 19:59:56 --> Helper loaded: html_helper
INFO - 2018-11-28 19:59:56 --> Helper loaded: form_helper
INFO - 2018-11-28 19:59:56 --> Helper loaded: cookie_helper
INFO - 2018-11-28 19:59:56 --> Helper loaded: date_helper
INFO - 2018-11-28 19:59:56 --> Form Validation Class Initialized
INFO - 2018-11-28 19:59:56 --> Email Class Initialized
DEBUG - 2018-11-28 19:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-28 19:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-28 19:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-28 19:59:56 --> Pagination Class Initialized
INFO - 2018-11-28 19:59:56 --> Database Driver Class Initialized
INFO - 2018-11-28 19:59:56 --> Database Driver Class Initialized
INFO - 2018-11-28 19:59:56 --> Controller Class Initialized
INFO - 2018-11-28 19:59:57 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-28 19:59:57 --> Final output sent to browser
DEBUG - 2018-11-28 19:59:57 --> Total execution time: 1.0776
INFO - 2018-11-28 20:00:09 --> Config Class Initialized
INFO - 2018-11-28 20:00:09 --> Hooks Class Initialized
DEBUG - 2018-11-28 20:00:09 --> UTF-8 Support Enabled
INFO - 2018-11-28 20:00:09 --> Utf8 Class Initialized
INFO - 2018-11-28 20:00:09 --> URI Class Initialized
INFO - 2018-11-28 20:00:09 --> Router Class Initialized
INFO - 2018-11-28 20:00:09 --> Output Class Initialized
INFO - 2018-11-28 20:00:09 --> Security Class Initialized
DEBUG - 2018-11-28 20:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-28 20:00:09 --> Input Class Initialized
INFO - 2018-11-28 20:00:09 --> Language Class Initialized
INFO - 2018-11-28 20:00:09 --> Loader Class Initialized
INFO - 2018-11-28 20:00:09 --> Helper loaded: url_helper
INFO - 2018-11-28 20:00:09 --> Helper loaded: html_helper
INFO - 2018-11-28 20:00:09 --> Helper loaded: form_helper
INFO - 2018-11-28 20:00:09 --> Helper loaded: cookie_helper
INFO - 2018-11-28 20:00:09 --> Helper loaded: date_helper
INFO - 2018-11-28 20:00:09 --> Form Validation Class Initialized
INFO - 2018-11-28 20:00:09 --> Email Class Initialized
DEBUG - 2018-11-28 20:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-28 20:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-28 20:00:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-28 20:00:09 --> Pagination Class Initialized
INFO - 2018-11-28 20:00:09 --> Database Driver Class Initialized
INFO - 2018-11-28 20:00:09 --> Database Driver Class Initialized
INFO - 2018-11-28 20:00:09 --> Controller Class Initialized
INFO - 2018-11-28 20:00:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-11-28 20:00:09 --> Config Class Initialized
INFO - 2018-11-28 20:00:09 --> Hooks Class Initialized
DEBUG - 2018-11-28 20:00:09 --> UTF-8 Support Enabled
INFO - 2018-11-28 20:00:09 --> Utf8 Class Initialized
INFO - 2018-11-28 20:00:09 --> URI Class Initialized
INFO - 2018-11-28 20:00:09 --> Router Class Initialized
INFO - 2018-11-28 20:00:09 --> Output Class Initialized
INFO - 2018-11-28 20:00:09 --> Security Class Initialized
DEBUG - 2018-11-28 20:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-28 20:00:09 --> Input Class Initialized
INFO - 2018-11-28 20:00:09 --> Language Class Initialized
INFO - 2018-11-28 20:00:09 --> Loader Class Initialized
INFO - 2018-11-28 20:00:09 --> Helper loaded: url_helper
INFO - 2018-11-28 20:00:09 --> Helper loaded: html_helper
INFO - 2018-11-28 20:00:09 --> Helper loaded: form_helper
INFO - 2018-11-28 20:00:09 --> Helper loaded: cookie_helper
INFO - 2018-11-28 20:00:09 --> Helper loaded: date_helper
INFO - 2018-11-28 20:00:09 --> Form Validation Class Initialized
INFO - 2018-11-28 20:00:09 --> Email Class Initialized
DEBUG - 2018-11-28 20:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-28 20:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-28 20:00:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-28 20:00:09 --> Pagination Class Initialized
INFO - 2018-11-28 20:00:10 --> Database Driver Class Initialized
INFO - 2018-11-28 20:00:10 --> Database Driver Class Initialized
INFO - 2018-11-28 20:00:10 --> Controller Class Initialized
INFO - 2018-11-28 20:00:10 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-28 20:00:10 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-11-28 20:00:10 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-28 20:00:10 --> Final output sent to browser
DEBUG - 2018-11-28 20:00:10 --> Total execution time: 0.3769
INFO - 2018-11-28 20:00:10 --> Config Class Initialized
INFO - 2018-11-28 20:00:10 --> Config Class Initialized
INFO - 2018-11-28 20:00:10 --> Hooks Class Initialized
INFO - 2018-11-28 20:00:10 --> Hooks Class Initialized
DEBUG - 2018-11-28 20:00:10 --> UTF-8 Support Enabled
DEBUG - 2018-11-28 20:00:10 --> UTF-8 Support Enabled
INFO - 2018-11-28 20:00:10 --> Utf8 Class Initialized
INFO - 2018-11-28 20:00:10 --> Utf8 Class Initialized
INFO - 2018-11-28 20:00:10 --> URI Class Initialized
INFO - 2018-11-28 20:00:10 --> URI Class Initialized
INFO - 2018-11-28 20:00:10 --> Router Class Initialized
INFO - 2018-11-28 20:00:10 --> Router Class Initialized
INFO - 2018-11-28 20:00:10 --> Output Class Initialized
INFO - 2018-11-28 20:00:10 --> Output Class Initialized
INFO - 2018-11-28 20:00:10 --> Security Class Initialized
INFO - 2018-11-28 20:00:10 --> Security Class Initialized
DEBUG - 2018-11-28 20:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-28 20:00:10 --> Input Class Initialized
DEBUG - 2018-11-28 20:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-28 20:00:10 --> Input Class Initialized
INFO - 2018-11-28 20:00:10 --> Language Class Initialized
INFO - 2018-11-28 20:00:10 --> Language Class Initialized
INFO - 2018-11-28 20:00:10 --> Loader Class Initialized
INFO - 2018-11-28 20:00:10 --> Loader Class Initialized
INFO - 2018-11-28 20:00:10 --> Helper loaded: url_helper
INFO - 2018-11-28 20:00:10 --> Helper loaded: url_helper
INFO - 2018-11-28 20:00:10 --> Helper loaded: html_helper
INFO - 2018-11-28 20:00:10 --> Helper loaded: html_helper
INFO - 2018-11-28 20:00:10 --> Helper loaded: form_helper
INFO - 2018-11-28 20:00:10 --> Helper loaded: form_helper
INFO - 2018-11-28 20:00:10 --> Helper loaded: cookie_helper
INFO - 2018-11-28 20:00:10 --> Helper loaded: cookie_helper
INFO - 2018-11-28 20:00:10 --> Helper loaded: date_helper
INFO - 2018-11-28 20:00:10 --> Form Validation Class Initialized
INFO - 2018-11-28 20:00:10 --> Helper loaded: date_helper
INFO - 2018-11-28 20:00:10 --> Form Validation Class Initialized
INFO - 2018-11-28 20:00:10 --> Email Class Initialized
INFO - 2018-11-28 20:00:10 --> Email Class Initialized
DEBUG - 2018-11-28 20:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-28 20:00:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-11-28 20:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-28 20:00:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-28 20:00:10 --> Pagination Class Initialized
INFO - 2018-11-28 20:00:10 --> Database Driver Class Initialized
INFO - 2018-11-28 20:00:10 --> Database Driver Class Initialized
INFO - 2018-11-28 20:00:11 --> Controller Class Initialized
INFO - 2018-11-28 20:00:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-28 20:00:11 --> Final output sent to browser
DEBUG - 2018-11-28 20:00:11 --> Total execution time: 0.3907
INFO - 2018-11-28 20:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-28 20:00:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-28 20:00:11 --> Pagination Class Initialized
INFO - 2018-11-28 20:00:11 --> Database Driver Class Initialized
INFO - 2018-11-28 20:00:11 --> Database Driver Class Initialized
INFO - 2018-11-28 20:00:11 --> Controller Class Initialized
INFO - 2018-11-28 20:00:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-28 20:00:11 --> Final output sent to browser
DEBUG - 2018-11-28 20:00:11 --> Total execution time: 0.5291
INFO - 2018-11-28 20:04:54 --> Config Class Initialized
INFO - 2018-11-28 20:04:54 --> Hooks Class Initialized
DEBUG - 2018-11-28 20:04:54 --> UTF-8 Support Enabled
INFO - 2018-11-28 20:04:54 --> Utf8 Class Initialized
INFO - 2018-11-28 20:04:54 --> URI Class Initialized
INFO - 2018-11-28 20:04:54 --> Router Class Initialized
INFO - 2018-11-28 20:04:54 --> Output Class Initialized
INFO - 2018-11-28 20:04:54 --> Security Class Initialized
DEBUG - 2018-11-28 20:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-28 20:04:54 --> Input Class Initialized
INFO - 2018-11-28 20:04:54 --> Language Class Initialized
INFO - 2018-11-28 20:04:54 --> Loader Class Initialized
INFO - 2018-11-28 20:04:54 --> Helper loaded: url_helper
INFO - 2018-11-28 20:04:54 --> Helper loaded: html_helper
INFO - 2018-11-28 20:04:54 --> Helper loaded: form_helper
INFO - 2018-11-28 20:04:54 --> Helper loaded: cookie_helper
INFO - 2018-11-28 20:04:54 --> Helper loaded: date_helper
INFO - 2018-11-28 20:04:54 --> Form Validation Class Initialized
INFO - 2018-11-28 20:04:54 --> Email Class Initialized
DEBUG - 2018-11-28 20:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-28 20:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-28 20:04:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-28 20:04:54 --> Pagination Class Initialized
INFO - 2018-11-28 20:04:54 --> Database Driver Class Initialized
INFO - 2018-11-28 20:04:54 --> Database Driver Class Initialized
INFO - 2018-11-28 20:04:54 --> Controller Class Initialized
INFO - 2018-11-28 20:04:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-28 20:04:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-11-28 20:04:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2018-11-28 20:04:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-28 20:04:54 --> Final output sent to browser
DEBUG - 2018-11-28 20:04:54 --> Total execution time: 0.4787
INFO - 2018-11-28 20:04:55 --> Config Class Initialized
INFO - 2018-11-28 20:04:55 --> Config Class Initialized
INFO - 2018-11-28 20:04:55 --> Hooks Class Initialized
INFO - 2018-11-28 20:04:55 --> Hooks Class Initialized
DEBUG - 2018-11-28 20:04:55 --> UTF-8 Support Enabled
INFO - 2018-11-28 20:04:55 --> Utf8 Class Initialized
DEBUG - 2018-11-28 20:04:55 --> UTF-8 Support Enabled
INFO - 2018-11-28 20:04:55 --> Utf8 Class Initialized
INFO - 2018-11-28 20:04:55 --> URI Class Initialized
INFO - 2018-11-28 20:04:55 --> URI Class Initialized
INFO - 2018-11-28 20:04:55 --> Router Class Initialized
INFO - 2018-11-28 20:04:55 --> Router Class Initialized
INFO - 2018-11-28 20:04:55 --> Output Class Initialized
INFO - 2018-11-28 20:04:55 --> Output Class Initialized
INFO - 2018-11-28 20:04:55 --> Security Class Initialized
INFO - 2018-11-28 20:04:55 --> Security Class Initialized
DEBUG - 2018-11-28 20:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-28 20:04:55 --> Input Class Initialized
DEBUG - 2018-11-28 20:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-28 20:04:55 --> Input Class Initialized
INFO - 2018-11-28 20:04:55 --> Language Class Initialized
INFO - 2018-11-28 20:04:55 --> Language Class Initialized
INFO - 2018-11-28 20:04:55 --> Loader Class Initialized
INFO - 2018-11-28 20:04:55 --> Loader Class Initialized
INFO - 2018-11-28 20:04:55 --> Helper loaded: url_helper
INFO - 2018-11-28 20:04:55 --> Helper loaded: url_helper
INFO - 2018-11-28 20:04:55 --> Helper loaded: html_helper
INFO - 2018-11-28 20:04:55 --> Helper loaded: html_helper
INFO - 2018-11-28 20:04:55 --> Helper loaded: form_helper
INFO - 2018-11-28 20:04:55 --> Helper loaded: form_helper
INFO - 2018-11-28 20:04:55 --> Helper loaded: cookie_helper
INFO - 2018-11-28 20:04:55 --> Helper loaded: cookie_helper
INFO - 2018-11-28 20:04:55 --> Helper loaded: date_helper
INFO - 2018-11-28 20:04:55 --> Helper loaded: date_helper
INFO - 2018-11-28 20:04:55 --> Form Validation Class Initialized
INFO - 2018-11-28 20:04:55 --> Form Validation Class Initialized
INFO - 2018-11-28 20:04:55 --> Email Class Initialized
INFO - 2018-11-28 20:04:55 --> Email Class Initialized
DEBUG - 2018-11-28 20:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-28 20:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-28 20:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-28 20:04:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-28 20:04:55 --> Pagination Class Initialized
INFO - 2018-11-28 20:04:55 --> Database Driver Class Initialized
INFO - 2018-11-28 20:04:55 --> Database Driver Class Initialized
INFO - 2018-11-28 20:04:55 --> Controller Class Initialized
INFO - 2018-11-28 20:04:55 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-28 20:04:55 --> Final output sent to browser
DEBUG - 2018-11-28 20:04:55 --> Total execution time: 0.3271
INFO - 2018-11-28 20:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-28 20:04:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-28 20:04:55 --> Pagination Class Initialized
INFO - 2018-11-28 20:04:55 --> Database Driver Class Initialized
INFO - 2018-11-28 20:04:55 --> Database Driver Class Initialized
INFO - 2018-11-28 20:04:55 --> Controller Class Initialized
INFO - 2018-11-28 20:04:55 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-28 20:04:55 --> Final output sent to browser
DEBUG - 2018-11-28 20:04:55 --> Total execution time: 0.4381
INFO - 2018-11-28 21:20:53 --> Config Class Initialized
INFO - 2018-11-28 21:20:53 --> Hooks Class Initialized
DEBUG - 2018-11-28 21:20:53 --> UTF-8 Support Enabled
INFO - 2018-11-28 21:20:53 --> Utf8 Class Initialized
INFO - 2018-11-28 21:20:53 --> URI Class Initialized
INFO - 2018-11-28 21:20:53 --> Router Class Initialized
INFO - 2018-11-28 21:20:53 --> Output Class Initialized
INFO - 2018-11-28 21:20:53 --> Security Class Initialized
DEBUG - 2018-11-28 21:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-28 21:20:53 --> Input Class Initialized
INFO - 2018-11-28 21:20:53 --> Language Class Initialized
INFO - 2018-11-28 21:20:53 --> Loader Class Initialized
INFO - 2018-11-28 21:20:53 --> Helper loaded: url_helper
INFO - 2018-11-28 21:20:53 --> Helper loaded: html_helper
INFO - 2018-11-28 21:20:53 --> Helper loaded: form_helper
INFO - 2018-11-28 21:20:53 --> Helper loaded: cookie_helper
INFO - 2018-11-28 21:20:53 --> Helper loaded: date_helper
INFO - 2018-11-28 21:20:53 --> Form Validation Class Initialized
INFO - 2018-11-28 21:20:53 --> Email Class Initialized
DEBUG - 2018-11-28 21:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-28 21:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-28 21:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-28 21:20:53 --> Pagination Class Initialized
INFO - 2018-11-28 21:20:53 --> Database Driver Class Initialized
INFO - 2018-11-28 21:20:53 --> Database Driver Class Initialized
INFO - 2018-11-28 21:20:53 --> Controller Class Initialized
INFO - 2018-11-28 21:20:53 --> Config Class Initialized
INFO - 2018-11-28 21:20:53 --> Hooks Class Initialized
DEBUG - 2018-11-28 21:20:53 --> UTF-8 Support Enabled
INFO - 2018-11-28 21:20:53 --> Utf8 Class Initialized
INFO - 2018-11-28 21:20:53 --> URI Class Initialized
INFO - 2018-11-28 21:20:53 --> Router Class Initialized
INFO - 2018-11-28 21:20:54 --> Output Class Initialized
INFO - 2018-11-28 21:20:54 --> Security Class Initialized
DEBUG - 2018-11-28 21:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-28 21:20:54 --> Input Class Initialized
INFO - 2018-11-28 21:20:54 --> Language Class Initialized
INFO - 2018-11-28 21:20:54 --> Loader Class Initialized
INFO - 2018-11-28 21:20:54 --> Helper loaded: url_helper
INFO - 2018-11-28 21:20:54 --> Helper loaded: html_helper
INFO - 2018-11-28 21:20:54 --> Helper loaded: form_helper
INFO - 2018-11-28 21:20:54 --> Helper loaded: cookie_helper
INFO - 2018-11-28 21:20:54 --> Helper loaded: date_helper
INFO - 2018-11-28 21:20:54 --> Form Validation Class Initialized
INFO - 2018-11-28 21:20:54 --> Email Class Initialized
DEBUG - 2018-11-28 21:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-28 21:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-28 21:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-28 21:20:54 --> Pagination Class Initialized
INFO - 2018-11-28 21:20:54 --> Database Driver Class Initialized
INFO - 2018-11-28 21:20:54 --> Database Driver Class Initialized
INFO - 2018-11-28 21:20:54 --> Controller Class Initialized
INFO - 2018-11-28 21:20:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-28 21:20:54 --> Final output sent to browser
DEBUG - 2018-11-28 21:20:54 --> Total execution time: 0.2241
INFO - 2018-11-28 21:20:58 --> Config Class Initialized
INFO - 2018-11-28 21:20:58 --> Hooks Class Initialized
DEBUG - 2018-11-28 21:20:58 --> UTF-8 Support Enabled
INFO - 2018-11-28 21:20:58 --> Utf8 Class Initialized
INFO - 2018-11-28 21:20:58 --> URI Class Initialized
INFO - 2018-11-28 21:20:58 --> Router Class Initialized
INFO - 2018-11-28 21:20:58 --> Output Class Initialized
INFO - 2018-11-28 21:20:58 --> Security Class Initialized
DEBUG - 2018-11-28 21:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-28 21:20:58 --> Input Class Initialized
INFO - 2018-11-28 21:20:58 --> Language Class Initialized
INFO - 2018-11-28 21:20:58 --> Loader Class Initialized
INFO - 2018-11-28 21:20:58 --> Helper loaded: url_helper
INFO - 2018-11-28 21:20:58 --> Helper loaded: html_helper
INFO - 2018-11-28 21:20:58 --> Helper loaded: form_helper
INFO - 2018-11-28 21:20:58 --> Helper loaded: cookie_helper
INFO - 2018-11-28 21:20:58 --> Helper loaded: date_helper
INFO - 2018-11-28 21:20:58 --> Form Validation Class Initialized
INFO - 2018-11-28 21:20:58 --> Email Class Initialized
DEBUG - 2018-11-28 21:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-28 21:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-28 21:20:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-28 21:20:58 --> Pagination Class Initialized
INFO - 2018-11-28 21:20:58 --> Database Driver Class Initialized
INFO - 2018-11-28 21:20:58 --> Database Driver Class Initialized
INFO - 2018-11-28 21:20:58 --> Controller Class Initialized
INFO - 2018-11-28 21:20:58 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-28 21:20:58 --> Final output sent to browser
DEBUG - 2018-11-28 21:20:58 --> Total execution time: 0.2531
INFO - 2018-11-28 21:20:58 --> Config Class Initialized
INFO - 2018-11-28 21:20:58 --> Hooks Class Initialized
DEBUG - 2018-11-28 21:20:58 --> UTF-8 Support Enabled
INFO - 2018-11-28 21:20:58 --> Utf8 Class Initialized
INFO - 2018-11-28 21:20:58 --> URI Class Initialized
INFO - 2018-11-28 21:20:58 --> Router Class Initialized
INFO - 2018-11-28 21:20:58 --> Output Class Initialized
INFO - 2018-11-28 21:20:58 --> Security Class Initialized
DEBUG - 2018-11-28 21:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-28 21:20:58 --> Input Class Initialized
INFO - 2018-11-28 21:20:58 --> Language Class Initialized
INFO - 2018-11-28 21:20:58 --> Loader Class Initialized
INFO - 2018-11-28 21:20:58 --> Helper loaded: url_helper
INFO - 2018-11-28 21:20:58 --> Helper loaded: html_helper
INFO - 2018-11-28 21:20:58 --> Helper loaded: form_helper
INFO - 2018-11-28 21:20:58 --> Helper loaded: cookie_helper
INFO - 2018-11-28 21:20:58 --> Helper loaded: date_helper
INFO - 2018-11-28 21:20:58 --> Form Validation Class Initialized
INFO - 2018-11-28 21:20:58 --> Email Class Initialized
DEBUG - 2018-11-28 21:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-28 21:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-28 21:20:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-28 21:20:58 --> Pagination Class Initialized
INFO - 2018-11-28 21:20:58 --> Database Driver Class Initialized
INFO - 2018-11-28 21:20:58 --> Database Driver Class Initialized
INFO - 2018-11-28 21:20:58 --> Controller Class Initialized
INFO - 2018-11-28 21:20:58 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-28 21:20:58 --> Final output sent to browser
DEBUG - 2018-11-28 21:20:58 --> Total execution time: 0.2562
