<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-20 16:13:02 --> Config Class Initialized
INFO - 2018-11-20 16:13:02 --> Hooks Class Initialized
DEBUG - 2018-11-20 16:13:02 --> UTF-8 Support Enabled
INFO - 2018-11-20 16:13:02 --> Utf8 Class Initialized
INFO - 2018-11-20 16:13:02 --> URI Class Initialized
DEBUG - 2018-11-20 16:13:02 --> No URI present. Default controller set.
INFO - 2018-11-20 16:13:02 --> Router Class Initialized
INFO - 2018-11-20 16:13:02 --> Output Class Initialized
INFO - 2018-11-20 16:13:02 --> Security Class Initialized
DEBUG - 2018-11-20 16:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 16:13:02 --> Input Class Initialized
INFO - 2018-11-20 16:13:02 --> Language Class Initialized
INFO - 2018-11-20 16:13:02 --> Loader Class Initialized
INFO - 2018-11-20 16:13:02 --> Helper loaded: url_helper
INFO - 2018-11-20 16:13:02 --> Helper loaded: html_helper
INFO - 2018-11-20 16:13:02 --> Helper loaded: form_helper
INFO - 2018-11-20 16:13:02 --> Helper loaded: cookie_helper
INFO - 2018-11-20 16:13:02 --> Helper loaded: date_helper
INFO - 2018-11-20 16:13:02 --> Form Validation Class Initialized
INFO - 2018-11-20 16:13:02 --> Email Class Initialized
DEBUG - 2018-11-20 16:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 16:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 16:13:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 16:13:02 --> Pagination Class Initialized
INFO - 2018-11-20 16:13:02 --> Database Driver Class Initialized
INFO - 2018-11-20 16:13:02 --> Database Driver Class Initialized
INFO - 2018-11-20 16:13:02 --> Controller Class Initialized
INFO - 2018-11-20 16:13:02 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-20 16:13:02 --> Final output sent to browser
DEBUG - 2018-11-20 16:13:02 --> Total execution time: 0.5653
INFO - 2018-11-20 16:13:10 --> Config Class Initialized
INFO - 2018-11-20 16:13:10 --> Hooks Class Initialized
DEBUG - 2018-11-20 16:13:10 --> UTF-8 Support Enabled
INFO - 2018-11-20 16:13:10 --> Utf8 Class Initialized
INFO - 2018-11-20 16:13:10 --> URI Class Initialized
DEBUG - 2018-11-20 16:13:10 --> No URI present. Default controller set.
INFO - 2018-11-20 16:13:10 --> Router Class Initialized
INFO - 2018-11-20 16:13:10 --> Output Class Initialized
INFO - 2018-11-20 16:13:10 --> Security Class Initialized
DEBUG - 2018-11-20 16:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 16:13:10 --> Input Class Initialized
INFO - 2018-11-20 16:13:10 --> Language Class Initialized
INFO - 2018-11-20 16:13:10 --> Loader Class Initialized
INFO - 2018-11-20 16:13:10 --> Helper loaded: url_helper
INFO - 2018-11-20 16:13:10 --> Helper loaded: html_helper
INFO - 2018-11-20 16:13:10 --> Helper loaded: form_helper
INFO - 2018-11-20 16:13:10 --> Helper loaded: cookie_helper
INFO - 2018-11-20 16:13:10 --> Helper loaded: date_helper
INFO - 2018-11-20 16:13:10 --> Form Validation Class Initialized
INFO - 2018-11-20 16:13:10 --> Email Class Initialized
DEBUG - 2018-11-20 16:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 16:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 16:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 16:13:10 --> Pagination Class Initialized
INFO - 2018-11-20 16:13:10 --> Database Driver Class Initialized
INFO - 2018-11-20 16:13:10 --> Database Driver Class Initialized
INFO - 2018-11-20 16:13:10 --> Controller Class Initialized
INFO - 2018-11-20 16:13:10 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-20 16:13:10 --> Final output sent to browser
DEBUG - 2018-11-20 16:13:10 --> Total execution time: 0.1148
INFO - 2018-11-20 16:15:04 --> Config Class Initialized
INFO - 2018-11-20 16:15:04 --> Hooks Class Initialized
DEBUG - 2018-11-20 16:15:04 --> UTF-8 Support Enabled
INFO - 2018-11-20 16:15:04 --> Utf8 Class Initialized
INFO - 2018-11-20 16:15:04 --> URI Class Initialized
INFO - 2018-11-20 16:15:04 --> Router Class Initialized
INFO - 2018-11-20 16:15:04 --> Output Class Initialized
INFO - 2018-11-20 16:15:04 --> Security Class Initialized
DEBUG - 2018-11-20 16:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 16:15:04 --> Input Class Initialized
INFO - 2018-11-20 16:15:04 --> Language Class Initialized
INFO - 2018-11-20 16:15:04 --> Loader Class Initialized
INFO - 2018-11-20 16:15:04 --> Helper loaded: url_helper
INFO - 2018-11-20 16:15:04 --> Helper loaded: html_helper
INFO - 2018-11-20 16:15:04 --> Helper loaded: form_helper
INFO - 2018-11-20 16:15:04 --> Helper loaded: cookie_helper
INFO - 2018-11-20 16:15:04 --> Helper loaded: date_helper
INFO - 2018-11-20 16:15:04 --> Form Validation Class Initialized
INFO - 2018-11-20 16:15:04 --> Email Class Initialized
DEBUG - 2018-11-20 16:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 16:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 16:15:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 16:15:04 --> Pagination Class Initialized
INFO - 2018-11-20 16:15:04 --> Database Driver Class Initialized
INFO - 2018-11-20 16:15:04 --> Database Driver Class Initialized
INFO - 2018-11-20 16:15:04 --> Controller Class Initialized
INFO - 2018-11-20 16:15:04 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-20 16:15:04 --> Final output sent to browser
DEBUG - 2018-11-20 16:15:04 --> Total execution time: 0.1645
INFO - 2018-11-20 16:15:04 --> Config Class Initialized
INFO - 2018-11-20 16:15:04 --> Hooks Class Initialized
DEBUG - 2018-11-20 16:15:04 --> UTF-8 Support Enabled
INFO - 2018-11-20 16:15:04 --> Utf8 Class Initialized
INFO - 2018-11-20 16:15:04 --> URI Class Initialized
INFO - 2018-11-20 16:15:04 --> Router Class Initialized
INFO - 2018-11-20 16:15:04 --> Output Class Initialized
INFO - 2018-11-20 16:15:04 --> Security Class Initialized
DEBUG - 2018-11-20 16:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 16:15:04 --> Input Class Initialized
INFO - 2018-11-20 16:15:04 --> Language Class Initialized
INFO - 2018-11-20 16:15:04 --> Loader Class Initialized
INFO - 2018-11-20 16:15:04 --> Helper loaded: url_helper
INFO - 2018-11-20 16:15:04 --> Helper loaded: html_helper
INFO - 2018-11-20 16:15:04 --> Helper loaded: form_helper
INFO - 2018-11-20 16:15:04 --> Helper loaded: cookie_helper
INFO - 2018-11-20 16:15:04 --> Helper loaded: date_helper
INFO - 2018-11-20 16:15:04 --> Form Validation Class Initialized
INFO - 2018-11-20 16:15:04 --> Email Class Initialized
DEBUG - 2018-11-20 16:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 16:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 16:15:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 16:15:04 --> Pagination Class Initialized
INFO - 2018-11-20 16:15:04 --> Database Driver Class Initialized
INFO - 2018-11-20 16:15:04 --> Database Driver Class Initialized
INFO - 2018-11-20 16:15:04 --> Controller Class Initialized
INFO - 2018-11-20 16:15:04 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-20 16:15:04 --> Final output sent to browser
DEBUG - 2018-11-20 16:15:04 --> Total execution time: 0.0956
INFO - 2018-11-20 16:15:16 --> Config Class Initialized
INFO - 2018-11-20 16:15:16 --> Hooks Class Initialized
DEBUG - 2018-11-20 16:15:16 --> UTF-8 Support Enabled
INFO - 2018-11-20 16:15:16 --> Utf8 Class Initialized
INFO - 2018-11-20 16:15:16 --> URI Class Initialized
INFO - 2018-11-20 16:15:16 --> Router Class Initialized
INFO - 2018-11-20 16:15:16 --> Output Class Initialized
INFO - 2018-11-20 16:15:16 --> Security Class Initialized
DEBUG - 2018-11-20 16:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 16:15:16 --> Input Class Initialized
INFO - 2018-11-20 16:15:16 --> Language Class Initialized
INFO - 2018-11-20 16:15:16 --> Loader Class Initialized
INFO - 2018-11-20 16:15:16 --> Helper loaded: url_helper
INFO - 2018-11-20 16:15:16 --> Helper loaded: html_helper
INFO - 2018-11-20 16:15:16 --> Helper loaded: form_helper
INFO - 2018-11-20 16:15:16 --> Helper loaded: cookie_helper
INFO - 2018-11-20 16:15:16 --> Helper loaded: date_helper
INFO - 2018-11-20 16:15:16 --> Form Validation Class Initialized
INFO - 2018-11-20 16:15:16 --> Email Class Initialized
DEBUG - 2018-11-20 16:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 16:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 16:15:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 16:15:16 --> Pagination Class Initialized
INFO - 2018-11-20 16:15:16 --> Database Driver Class Initialized
INFO - 2018-11-20 16:15:16 --> Database Driver Class Initialized
INFO - 2018-11-20 16:15:16 --> Controller Class Initialized
INFO - 2018-11-20 16:15:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-11-20 16:15:17 --> Config Class Initialized
INFO - 2018-11-20 16:15:17 --> Hooks Class Initialized
DEBUG - 2018-11-20 16:15:17 --> UTF-8 Support Enabled
INFO - 2018-11-20 16:15:17 --> Utf8 Class Initialized
INFO - 2018-11-20 16:15:17 --> URI Class Initialized
INFO - 2018-11-20 16:15:17 --> Router Class Initialized
INFO - 2018-11-20 16:15:17 --> Output Class Initialized
INFO - 2018-11-20 16:15:17 --> Security Class Initialized
DEBUG - 2018-11-20 16:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 16:15:17 --> Input Class Initialized
INFO - 2018-11-20 16:15:17 --> Language Class Initialized
INFO - 2018-11-20 16:15:17 --> Loader Class Initialized
INFO - 2018-11-20 16:15:17 --> Helper loaded: url_helper
INFO - 2018-11-20 16:15:17 --> Helper loaded: html_helper
INFO - 2018-11-20 16:15:17 --> Helper loaded: form_helper
INFO - 2018-11-20 16:15:17 --> Helper loaded: cookie_helper
INFO - 2018-11-20 16:15:17 --> Helper loaded: date_helper
INFO - 2018-11-20 16:15:17 --> Form Validation Class Initialized
INFO - 2018-11-20 16:15:17 --> Email Class Initialized
DEBUG - 2018-11-20 16:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 16:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 16:15:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 16:15:17 --> Pagination Class Initialized
INFO - 2018-11-20 16:15:17 --> Database Driver Class Initialized
INFO - 2018-11-20 16:15:17 --> Database Driver Class Initialized
INFO - 2018-11-20 16:15:17 --> Controller Class Initialized
INFO - 2018-11-20 16:15:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-20 16:15:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-11-20 16:15:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-20 16:15:17 --> Final output sent to browser
DEBUG - 2018-11-20 16:15:17 --> Total execution time: 0.1575
INFO - 2018-11-20 16:15:17 --> Config Class Initialized
INFO - 2018-11-20 16:15:17 --> Hooks Class Initialized
DEBUG - 2018-11-20 16:15:17 --> UTF-8 Support Enabled
INFO - 2018-11-20 16:15:17 --> Utf8 Class Initialized
INFO - 2018-11-20 16:15:17 --> URI Class Initialized
INFO - 2018-11-20 16:15:17 --> Router Class Initialized
INFO - 2018-11-20 16:15:17 --> Output Class Initialized
INFO - 2018-11-20 16:15:17 --> Config Class Initialized
INFO - 2018-11-20 16:15:17 --> Security Class Initialized
INFO - 2018-11-20 16:15:17 --> Hooks Class Initialized
DEBUG - 2018-11-20 16:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-20 16:15:17 --> UTF-8 Support Enabled
INFO - 2018-11-20 16:15:17 --> Utf8 Class Initialized
INFO - 2018-11-20 16:15:17 --> Input Class Initialized
INFO - 2018-11-20 16:15:17 --> URI Class Initialized
INFO - 2018-11-20 16:15:17 --> Router Class Initialized
INFO - 2018-11-20 16:15:17 --> Output Class Initialized
INFO - 2018-11-20 16:15:17 --> Language Class Initialized
INFO - 2018-11-20 16:15:17 --> Security Class Initialized
DEBUG - 2018-11-20 16:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 16:15:17 --> Loader Class Initialized
INFO - 2018-11-20 16:15:17 --> Input Class Initialized
INFO - 2018-11-20 16:15:17 --> Language Class Initialized
INFO - 2018-11-20 16:15:17 --> Helper loaded: url_helper
INFO - 2018-11-20 16:15:17 --> Helper loaded: html_helper
INFO - 2018-11-20 16:15:17 --> Loader Class Initialized
INFO - 2018-11-20 16:15:17 --> Helper loaded: form_helper
INFO - 2018-11-20 16:15:17 --> Helper loaded: url_helper
INFO - 2018-11-20 16:15:17 --> Helper loaded: cookie_helper
INFO - 2018-11-20 16:15:17 --> Helper loaded: html_helper
INFO - 2018-11-20 16:15:17 --> Helper loaded: date_helper
INFO - 2018-11-20 16:15:17 --> Helper loaded: form_helper
INFO - 2018-11-20 16:15:17 --> Form Validation Class Initialized
INFO - 2018-11-20 16:15:17 --> Helper loaded: cookie_helper
INFO - 2018-11-20 16:15:17 --> Helper loaded: date_helper
INFO - 2018-11-20 16:15:17 --> Email Class Initialized
INFO - 2018-11-20 16:15:17 --> Form Validation Class Initialized
DEBUG - 2018-11-20 16:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 16:15:17 --> Email Class Initialized
INFO - 2018-11-20 16:15:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-11-20 16:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 16:15:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 16:15:17 --> Pagination Class Initialized
INFO - 2018-11-20 16:15:17 --> Database Driver Class Initialized
INFO - 2018-11-20 16:15:17 --> Database Driver Class Initialized
INFO - 2018-11-20 16:15:17 --> Controller Class Initialized
INFO - 2018-11-20 16:15:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-20 16:15:17 --> Final output sent to browser
DEBUG - 2018-11-20 16:15:17 --> Total execution time: 0.1989
INFO - 2018-11-20 16:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 16:15:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 16:15:17 --> Pagination Class Initialized
INFO - 2018-11-20 16:15:17 --> Database Driver Class Initialized
INFO - 2018-11-20 16:15:17 --> Database Driver Class Initialized
INFO - 2018-11-20 16:15:17 --> Controller Class Initialized
INFO - 2018-11-20 16:15:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-20 16:15:17 --> Final output sent to browser
DEBUG - 2018-11-20 16:15:17 --> Total execution time: 0.2434
INFO - 2018-11-20 16:16:47 --> Config Class Initialized
INFO - 2018-11-20 16:16:47 --> Hooks Class Initialized
DEBUG - 2018-11-20 16:16:47 --> UTF-8 Support Enabled
INFO - 2018-11-20 16:16:47 --> Utf8 Class Initialized
INFO - 2018-11-20 16:16:47 --> URI Class Initialized
INFO - 2018-11-20 16:16:47 --> Router Class Initialized
INFO - 2018-11-20 16:16:47 --> Output Class Initialized
INFO - 2018-11-20 16:16:47 --> Security Class Initialized
DEBUG - 2018-11-20 16:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 16:16:47 --> Input Class Initialized
INFO - 2018-11-20 16:16:47 --> Language Class Initialized
INFO - 2018-11-20 16:16:47 --> Loader Class Initialized
INFO - 2018-11-20 16:16:47 --> Helper loaded: url_helper
INFO - 2018-11-20 16:16:47 --> Helper loaded: html_helper
INFO - 2018-11-20 16:16:47 --> Helper loaded: form_helper
INFO - 2018-11-20 16:16:47 --> Helper loaded: cookie_helper
INFO - 2018-11-20 16:16:47 --> Helper loaded: date_helper
INFO - 2018-11-20 16:16:47 --> Form Validation Class Initialized
INFO - 2018-11-20 16:16:47 --> Email Class Initialized
DEBUG - 2018-11-20 16:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 16:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 16:16:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 16:16:47 --> Pagination Class Initialized
INFO - 2018-11-20 16:16:47 --> Database Driver Class Initialized
INFO - 2018-11-20 16:16:47 --> Database Driver Class Initialized
INFO - 2018-11-20 16:16:47 --> Controller Class Initialized
INFO - 2018-11-20 16:16:47 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-20 16:16:47 --> Final output sent to browser
DEBUG - 2018-11-20 16:16:47 --> Total execution time: 0.1324
INFO - 2018-11-20 16:16:48 --> Config Class Initialized
INFO - 2018-11-20 16:16:48 --> Hooks Class Initialized
DEBUG - 2018-11-20 16:16:48 --> UTF-8 Support Enabled
INFO - 2018-11-20 16:16:48 --> Utf8 Class Initialized
INFO - 2018-11-20 16:16:48 --> URI Class Initialized
INFO - 2018-11-20 16:16:48 --> Router Class Initialized
INFO - 2018-11-20 16:16:48 --> Output Class Initialized
INFO - 2018-11-20 16:16:48 --> Security Class Initialized
DEBUG - 2018-11-20 16:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 16:16:48 --> Input Class Initialized
INFO - 2018-11-20 16:16:48 --> Language Class Initialized
INFO - 2018-11-20 16:16:48 --> Loader Class Initialized
INFO - 2018-11-20 16:16:48 --> Helper loaded: url_helper
INFO - 2018-11-20 16:16:48 --> Helper loaded: html_helper
INFO - 2018-11-20 16:16:48 --> Helper loaded: form_helper
INFO - 2018-11-20 16:16:48 --> Helper loaded: cookie_helper
INFO - 2018-11-20 16:16:48 --> Helper loaded: date_helper
INFO - 2018-11-20 16:16:48 --> Form Validation Class Initialized
INFO - 2018-11-20 16:16:48 --> Email Class Initialized
DEBUG - 2018-11-20 16:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 16:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 16:16:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 16:16:48 --> Pagination Class Initialized
INFO - 2018-11-20 16:16:48 --> Database Driver Class Initialized
INFO - 2018-11-20 16:16:48 --> Database Driver Class Initialized
INFO - 2018-11-20 16:16:48 --> Controller Class Initialized
INFO - 2018-11-20 16:16:48 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-20 16:16:48 --> Final output sent to browser
DEBUG - 2018-11-20 16:16:48 --> Total execution time: 0.1038
INFO - 2018-11-20 16:16:49 --> Config Class Initialized
INFO - 2018-11-20 16:16:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 16:16:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 16:16:49 --> Utf8 Class Initialized
INFO - 2018-11-20 16:16:49 --> URI Class Initialized
INFO - 2018-11-20 16:16:49 --> Router Class Initialized
INFO - 2018-11-20 16:16:49 --> Output Class Initialized
INFO - 2018-11-20 16:16:49 --> Security Class Initialized
DEBUG - 2018-11-20 16:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 16:16:49 --> Input Class Initialized
INFO - 2018-11-20 16:16:49 --> Language Class Initialized
INFO - 2018-11-20 16:16:49 --> Loader Class Initialized
INFO - 2018-11-20 16:16:49 --> Helper loaded: url_helper
INFO - 2018-11-20 16:16:49 --> Helper loaded: html_helper
INFO - 2018-11-20 16:16:49 --> Helper loaded: form_helper
INFO - 2018-11-20 16:16:49 --> Helper loaded: cookie_helper
INFO - 2018-11-20 16:16:49 --> Helper loaded: date_helper
INFO - 2018-11-20 16:16:49 --> Form Validation Class Initialized
INFO - 2018-11-20 16:16:49 --> Email Class Initialized
DEBUG - 2018-11-20 16:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 16:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 16:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 16:16:49 --> Pagination Class Initialized
INFO - 2018-11-20 16:16:49 --> Database Driver Class Initialized
INFO - 2018-11-20 16:16:49 --> Database Driver Class Initialized
INFO - 2018-11-20 16:16:49 --> Controller Class Initialized
INFO - 2018-11-20 16:16:49 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-20 16:16:49 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/account_class.php
INFO - 2018-11-20 16:16:49 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-20 16:16:49 --> Final output sent to browser
DEBUG - 2018-11-20 16:16:49 --> Total execution time: 0.1179
INFO - 2018-11-20 16:16:49 --> Config Class Initialized
INFO - 2018-11-20 16:16:49 --> Config Class Initialized
INFO - 2018-11-20 16:16:49 --> Hooks Class Initialized
INFO - 2018-11-20 16:16:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 16:16:49 --> UTF-8 Support Enabled
DEBUG - 2018-11-20 16:16:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 16:16:49 --> Utf8 Class Initialized
INFO - 2018-11-20 16:16:49 --> Utf8 Class Initialized
INFO - 2018-11-20 16:16:49 --> URI Class Initialized
INFO - 2018-11-20 16:16:49 --> URI Class Initialized
INFO - 2018-11-20 16:16:49 --> Router Class Initialized
INFO - 2018-11-20 16:16:49 --> Router Class Initialized
INFO - 2018-11-20 16:16:49 --> Output Class Initialized
INFO - 2018-11-20 16:16:49 --> Output Class Initialized
INFO - 2018-11-20 16:16:49 --> Security Class Initialized
INFO - 2018-11-20 16:16:49 --> Security Class Initialized
DEBUG - 2018-11-20 16:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-20 16:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 16:16:49 --> Input Class Initialized
INFO - 2018-11-20 16:16:49 --> Input Class Initialized
INFO - 2018-11-20 16:16:49 --> Language Class Initialized
INFO - 2018-11-20 16:16:49 --> Language Class Initialized
INFO - 2018-11-20 16:16:49 --> Loader Class Initialized
INFO - 2018-11-20 16:16:49 --> Loader Class Initialized
INFO - 2018-11-20 16:16:49 --> Helper loaded: url_helper
INFO - 2018-11-20 16:16:49 --> Helper loaded: url_helper
INFO - 2018-11-20 16:16:49 --> Helper loaded: html_helper
INFO - 2018-11-20 16:16:49 --> Helper loaded: html_helper
INFO - 2018-11-20 16:16:49 --> Helper loaded: form_helper
INFO - 2018-11-20 16:16:49 --> Helper loaded: form_helper
INFO - 2018-11-20 16:16:49 --> Helper loaded: cookie_helper
INFO - 2018-11-20 16:16:49 --> Helper loaded: cookie_helper
INFO - 2018-11-20 16:16:49 --> Helper loaded: date_helper
INFO - 2018-11-20 16:16:49 --> Helper loaded: date_helper
INFO - 2018-11-20 16:16:49 --> Form Validation Class Initialized
INFO - 2018-11-20 16:16:49 --> Form Validation Class Initialized
INFO - 2018-11-20 16:16:49 --> Email Class Initialized
INFO - 2018-11-20 16:16:49 --> Email Class Initialized
DEBUG - 2018-11-20 16:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-20 16:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 16:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 16:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 16:16:49 --> Pagination Class Initialized
INFO - 2018-11-20 16:16:49 --> Database Driver Class Initialized
INFO - 2018-11-20 16:16:49 --> Database Driver Class Initialized
INFO - 2018-11-20 16:16:49 --> Controller Class Initialized
INFO - 2018-11-20 16:16:49 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-20 16:16:49 --> Final output sent to browser
DEBUG - 2018-11-20 16:16:49 --> Total execution time: 0.1379
INFO - 2018-11-20 16:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 16:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 16:16:49 --> Pagination Class Initialized
INFO - 2018-11-20 16:16:49 --> Database Driver Class Initialized
INFO - 2018-11-20 16:16:49 --> Database Driver Class Initialized
INFO - 2018-11-20 16:16:49 --> Controller Class Initialized
INFO - 2018-11-20 16:16:49 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-20 16:16:49 --> Final output sent to browser
DEBUG - 2018-11-20 16:16:49 --> Total execution time: 0.2098
INFO - 2018-11-20 16:16:49 --> Config Class Initialized
INFO - 2018-11-20 16:16:49 --> Hooks Class Initialized
DEBUG - 2018-11-20 16:16:49 --> UTF-8 Support Enabled
INFO - 2018-11-20 16:16:49 --> Utf8 Class Initialized
INFO - 2018-11-20 16:16:49 --> URI Class Initialized
INFO - 2018-11-20 16:16:49 --> Router Class Initialized
INFO - 2018-11-20 16:16:49 --> Output Class Initialized
INFO - 2018-11-20 16:16:49 --> Security Class Initialized
DEBUG - 2018-11-20 16:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-20 16:16:49 --> Input Class Initialized
INFO - 2018-11-20 16:16:49 --> Language Class Initialized
INFO - 2018-11-20 16:16:49 --> Loader Class Initialized
INFO - 2018-11-20 16:16:49 --> Helper loaded: url_helper
INFO - 2018-11-20 16:16:49 --> Helper loaded: html_helper
INFO - 2018-11-20 16:16:49 --> Helper loaded: form_helper
INFO - 2018-11-20 16:16:49 --> Helper loaded: cookie_helper
INFO - 2018-11-20 16:16:49 --> Helper loaded: date_helper
INFO - 2018-11-20 16:16:49 --> Form Validation Class Initialized
INFO - 2018-11-20 16:16:49 --> Email Class Initialized
DEBUG - 2018-11-20 16:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-20 16:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-20 16:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-20 16:16:49 --> Pagination Class Initialized
INFO - 2018-11-20 16:16:49 --> Database Driver Class Initialized
INFO - 2018-11-20 16:16:49 --> Database Driver Class Initialized
INFO - 2018-11-20 16:16:49 --> Controller Class Initialized
INFO - 2018-11-20 16:16:49 --> Final output sent to browser
DEBUG - 2018-11-20 16:16:49 --> Total execution time: 0.1261
