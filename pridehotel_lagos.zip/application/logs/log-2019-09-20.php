<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-20 01:13:41 --> Config Class Initialized
INFO - 2019-09-20 01:13:41 --> Hooks Class Initialized
DEBUG - 2019-09-20 01:13:42 --> UTF-8 Support Enabled
INFO - 2019-09-20 01:13:42 --> Utf8 Class Initialized
INFO - 2019-09-20 01:13:42 --> URI Class Initialized
INFO - 2019-09-20 01:13:42 --> Router Class Initialized
INFO - 2019-09-20 01:13:42 --> Output Class Initialized
INFO - 2019-09-20 01:13:42 --> Security Class Initialized
DEBUG - 2019-09-20 01:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-20 01:13:42 --> Input Class Initialized
INFO - 2019-09-20 01:13:42 --> Language Class Initialized
INFO - 2019-09-20 01:13:42 --> Loader Class Initialized
INFO - 2019-09-20 01:13:42 --> Helper loaded: url_helper
INFO - 2019-09-20 01:13:42 --> Helper loaded: html_helper
INFO - 2019-09-20 01:13:42 --> Helper loaded: form_helper
INFO - 2019-09-20 01:13:42 --> Helper loaded: cookie_helper
INFO - 2019-09-20 01:13:42 --> Helper loaded: date_helper
INFO - 2019-09-20 01:13:42 --> Form Validation Class Initialized
INFO - 2019-09-20 01:13:42 --> Email Class Initialized
DEBUG - 2019-09-20 01:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-20 01:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-20 01:13:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-20 01:13:42 --> Pagination Class Initialized
INFO - 2019-09-20 01:13:42 --> Database Driver Class Initialized
INFO - 2019-09-20 01:13:42 --> Database Driver Class Initialized
INFO - 2019-09-20 01:13:42 --> Controller Class Initialized
INFO - 2019-09-20 01:13:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-20 01:13:42 --> Final output sent to browser
DEBUG - 2019-09-20 01:13:42 --> Total execution time: 0.5678
INFO - 2019-09-20 01:13:42 --> Config Class Initialized
INFO - 2019-09-20 01:13:42 --> Hooks Class Initialized
DEBUG - 2019-09-20 01:13:42 --> UTF-8 Support Enabled
INFO - 2019-09-20 01:13:42 --> Utf8 Class Initialized
INFO - 2019-09-20 01:13:42 --> URI Class Initialized
INFO - 2019-09-20 01:13:42 --> Router Class Initialized
INFO - 2019-09-20 01:13:42 --> Output Class Initialized
INFO - 2019-09-20 01:13:42 --> Security Class Initialized
DEBUG - 2019-09-20 01:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-20 01:13:42 --> Input Class Initialized
INFO - 2019-09-20 01:13:42 --> Language Class Initialized
INFO - 2019-09-20 01:13:42 --> Loader Class Initialized
INFO - 2019-09-20 01:13:42 --> Helper loaded: url_helper
INFO - 2019-09-20 01:13:42 --> Helper loaded: html_helper
INFO - 2019-09-20 01:13:42 --> Helper loaded: form_helper
INFO - 2019-09-20 01:13:42 --> Helper loaded: cookie_helper
INFO - 2019-09-20 01:13:42 --> Helper loaded: date_helper
INFO - 2019-09-20 01:13:42 --> Form Validation Class Initialized
INFO - 2019-09-20 01:13:42 --> Email Class Initialized
DEBUG - 2019-09-20 01:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-20 01:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-20 01:13:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-20 01:13:42 --> Pagination Class Initialized
INFO - 2019-09-20 01:13:42 --> Database Driver Class Initialized
INFO - 2019-09-20 01:13:42 --> Database Driver Class Initialized
INFO - 2019-09-20 01:13:42 --> Controller Class Initialized
INFO - 2019-09-20 01:13:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-20 01:13:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-20 01:13:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-20 01:13:42 --> Final output sent to browser
DEBUG - 2019-09-20 01:13:42 --> Total execution time: 0.1373
INFO - 2019-09-20 01:13:43 --> Config Class Initialized
INFO - 2019-09-20 01:13:43 --> Hooks Class Initialized
DEBUG - 2019-09-20 01:13:43 --> UTF-8 Support Enabled
INFO - 2019-09-20 01:13:43 --> Utf8 Class Initialized
INFO - 2019-09-20 01:13:43 --> URI Class Initialized
INFO - 2019-09-20 01:13:43 --> Router Class Initialized
INFO - 2019-09-20 01:13:43 --> Output Class Initialized
INFO - 2019-09-20 01:13:43 --> Security Class Initialized
DEBUG - 2019-09-20 01:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-20 01:13:43 --> Input Class Initialized
INFO - 2019-09-20 01:13:43 --> Language Class Initialized
INFO - 2019-09-20 01:13:43 --> Loader Class Initialized
INFO - 2019-09-20 01:13:43 --> Helper loaded: url_helper
INFO - 2019-09-20 01:13:43 --> Helper loaded: html_helper
INFO - 2019-09-20 01:13:43 --> Helper loaded: form_helper
INFO - 2019-09-20 01:13:43 --> Helper loaded: cookie_helper
INFO - 2019-09-20 01:13:43 --> Helper loaded: date_helper
INFO - 2019-09-20 01:13:43 --> Form Validation Class Initialized
INFO - 2019-09-20 01:13:43 --> Email Class Initialized
DEBUG - 2019-09-20 01:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-20 01:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-20 01:13:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-20 01:13:43 --> Pagination Class Initialized
INFO - 2019-09-20 01:13:43 --> Database Driver Class Initialized
INFO - 2019-09-20 01:13:43 --> Database Driver Class Initialized
INFO - 2019-09-20 01:13:43 --> Controller Class Initialized
INFO - 2019-09-20 01:13:43 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-20 01:13:43 --> Final output sent to browser
DEBUG - 2019-09-20 01:13:43 --> Total execution time: 0.0627
INFO - 2019-09-20 02:01:27 --> Config Class Initialized
INFO - 2019-09-20 02:01:27 --> Hooks Class Initialized
DEBUG - 2019-09-20 02:01:27 --> UTF-8 Support Enabled
INFO - 2019-09-20 02:01:27 --> Utf8 Class Initialized
INFO - 2019-09-20 02:01:27 --> URI Class Initialized
INFO - 2019-09-20 02:01:27 --> Router Class Initialized
INFO - 2019-09-20 02:01:27 --> Output Class Initialized
INFO - 2019-09-20 02:01:27 --> Security Class Initialized
DEBUG - 2019-09-20 02:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-20 02:01:27 --> Input Class Initialized
INFO - 2019-09-20 02:01:27 --> Language Class Initialized
INFO - 2019-09-20 02:01:27 --> Loader Class Initialized
INFO - 2019-09-20 02:01:27 --> Helper loaded: url_helper
INFO - 2019-09-20 02:01:27 --> Helper loaded: html_helper
INFO - 2019-09-20 02:01:27 --> Helper loaded: form_helper
INFO - 2019-09-20 02:01:27 --> Helper loaded: cookie_helper
INFO - 2019-09-20 02:01:27 --> Helper loaded: date_helper
INFO - 2019-09-20 02:01:27 --> Form Validation Class Initialized
INFO - 2019-09-20 02:01:27 --> Email Class Initialized
DEBUG - 2019-09-20 02:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-20 02:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-20 02:01:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-20 02:01:27 --> Pagination Class Initialized
INFO - 2019-09-20 02:01:27 --> Database Driver Class Initialized
INFO - 2019-09-20 02:01:27 --> Database Driver Class Initialized
INFO - 2019-09-20 02:01:27 --> Controller Class Initialized
INFO - 2019-09-20 02:01:27 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-20 02:01:27 --> Final output sent to browser
DEBUG - 2019-09-20 02:01:27 --> Total execution time: 0.0669
