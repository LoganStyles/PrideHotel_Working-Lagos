<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-12-03 20:38:16 --> Config Class Initialized
INFO - 2018-12-03 20:38:16 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:38:16 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:38:16 --> Utf8 Class Initialized
INFO - 2018-12-03 20:38:16 --> URI Class Initialized
DEBUG - 2018-12-03 20:38:16 --> No URI present. Default controller set.
INFO - 2018-12-03 20:38:16 --> Router Class Initialized
INFO - 2018-12-03 20:38:16 --> Output Class Initialized
INFO - 2018-12-03 20:38:16 --> Security Class Initialized
DEBUG - 2018-12-03 20:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:38:16 --> Input Class Initialized
INFO - 2018-12-03 20:38:16 --> Language Class Initialized
INFO - 2018-12-03 20:38:16 --> Loader Class Initialized
INFO - 2018-12-03 20:38:16 --> Helper loaded: url_helper
INFO - 2018-12-03 20:38:16 --> Helper loaded: html_helper
INFO - 2018-12-03 20:38:16 --> Helper loaded: form_helper
INFO - 2018-12-03 20:38:16 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:38:16 --> Helper loaded: date_helper
INFO - 2018-12-03 20:38:16 --> Form Validation Class Initialized
INFO - 2018-12-03 20:38:16 --> Email Class Initialized
DEBUG - 2018-12-03 20:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:38:17 --> Pagination Class Initialized
INFO - 2018-12-03 20:38:17 --> Database Driver Class Initialized
INFO - 2018-12-03 20:38:17 --> Database Driver Class Initialized
INFO - 2018-12-03 20:38:17 --> Controller Class Initialized
INFO - 2018-12-03 20:38:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-12-03 20:38:17 --> Final output sent to browser
DEBUG - 2018-12-03 20:38:17 --> Total execution time: 0.8414
INFO - 2018-12-03 20:38:17 --> Config Class Initialized
INFO - 2018-12-03 20:38:17 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:38:17 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:38:17 --> Utf8 Class Initialized
INFO - 2018-12-03 20:38:17 --> URI Class Initialized
DEBUG - 2018-12-03 20:38:17 --> No URI present. Default controller set.
INFO - 2018-12-03 20:38:17 --> Router Class Initialized
INFO - 2018-12-03 20:38:17 --> Output Class Initialized
INFO - 2018-12-03 20:38:17 --> Security Class Initialized
DEBUG - 2018-12-03 20:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:38:17 --> Input Class Initialized
INFO - 2018-12-03 20:38:17 --> Language Class Initialized
INFO - 2018-12-03 20:38:17 --> Loader Class Initialized
INFO - 2018-12-03 20:38:17 --> Helper loaded: url_helper
INFO - 2018-12-03 20:38:17 --> Helper loaded: html_helper
INFO - 2018-12-03 20:38:17 --> Helper loaded: form_helper
INFO - 2018-12-03 20:38:17 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:38:17 --> Helper loaded: date_helper
INFO - 2018-12-03 20:38:17 --> Form Validation Class Initialized
INFO - 2018-12-03 20:38:17 --> Email Class Initialized
DEBUG - 2018-12-03 20:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:38:17 --> Pagination Class Initialized
INFO - 2018-12-03 20:38:17 --> Database Driver Class Initialized
INFO - 2018-12-03 20:38:17 --> Database Driver Class Initialized
INFO - 2018-12-03 20:38:17 --> Controller Class Initialized
INFO - 2018-12-03 20:38:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-12-03 20:38:17 --> Final output sent to browser
DEBUG - 2018-12-03 20:38:17 --> Total execution time: 0.0578
INFO - 2018-12-03 20:38:23 --> Config Class Initialized
INFO - 2018-12-03 20:38:23 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:38:23 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:38:23 --> Utf8 Class Initialized
INFO - 2018-12-03 20:38:23 --> URI Class Initialized
DEBUG - 2018-12-03 20:38:23 --> No URI present. Default controller set.
INFO - 2018-12-03 20:38:23 --> Router Class Initialized
INFO - 2018-12-03 20:38:23 --> Output Class Initialized
INFO - 2018-12-03 20:38:23 --> Security Class Initialized
DEBUG - 2018-12-03 20:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:38:23 --> Input Class Initialized
INFO - 2018-12-03 20:38:23 --> Language Class Initialized
INFO - 2018-12-03 20:38:23 --> Loader Class Initialized
INFO - 2018-12-03 20:38:23 --> Helper loaded: url_helper
INFO - 2018-12-03 20:38:23 --> Helper loaded: html_helper
INFO - 2018-12-03 20:38:23 --> Helper loaded: form_helper
INFO - 2018-12-03 20:38:23 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:38:23 --> Helper loaded: date_helper
INFO - 2018-12-03 20:38:23 --> Form Validation Class Initialized
INFO - 2018-12-03 20:38:23 --> Email Class Initialized
DEBUG - 2018-12-03 20:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:38:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:38:23 --> Pagination Class Initialized
INFO - 2018-12-03 20:38:23 --> Database Driver Class Initialized
INFO - 2018-12-03 20:38:23 --> Database Driver Class Initialized
INFO - 2018-12-03 20:38:23 --> Controller Class Initialized
INFO - 2018-12-03 20:38:23 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-12-03 20:38:23 --> Final output sent to browser
DEBUG - 2018-12-03 20:38:23 --> Total execution time: 0.0672
INFO - 2018-12-03 20:38:23 --> Config Class Initialized
INFO - 2018-12-03 20:38:23 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:38:23 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:38:23 --> Utf8 Class Initialized
INFO - 2018-12-03 20:38:23 --> URI Class Initialized
DEBUG - 2018-12-03 20:38:23 --> No URI present. Default controller set.
INFO - 2018-12-03 20:38:23 --> Router Class Initialized
INFO - 2018-12-03 20:38:23 --> Output Class Initialized
INFO - 2018-12-03 20:38:23 --> Security Class Initialized
DEBUG - 2018-12-03 20:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:38:23 --> Input Class Initialized
INFO - 2018-12-03 20:38:23 --> Language Class Initialized
INFO - 2018-12-03 20:38:23 --> Loader Class Initialized
INFO - 2018-12-03 20:38:23 --> Helper loaded: url_helper
INFO - 2018-12-03 20:38:23 --> Helper loaded: html_helper
INFO - 2018-12-03 20:38:23 --> Helper loaded: form_helper
INFO - 2018-12-03 20:38:23 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:38:23 --> Helper loaded: date_helper
INFO - 2018-12-03 20:38:23 --> Form Validation Class Initialized
INFO - 2018-12-03 20:38:23 --> Email Class Initialized
DEBUG - 2018-12-03 20:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:38:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:38:23 --> Pagination Class Initialized
INFO - 2018-12-03 20:38:23 --> Database Driver Class Initialized
INFO - 2018-12-03 20:38:23 --> Database Driver Class Initialized
INFO - 2018-12-03 20:38:23 --> Controller Class Initialized
INFO - 2018-12-03 20:38:24 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-12-03 20:38:24 --> Final output sent to browser
DEBUG - 2018-12-03 20:38:24 --> Total execution time: 0.0682
INFO - 2018-12-03 20:39:05 --> Config Class Initialized
INFO - 2018-12-03 20:39:05 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:39:05 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:39:05 --> Utf8 Class Initialized
INFO - 2018-12-03 20:39:05 --> URI Class Initialized
DEBUG - 2018-12-03 20:39:05 --> No URI present. Default controller set.
INFO - 2018-12-03 20:39:05 --> Router Class Initialized
INFO - 2018-12-03 20:39:05 --> Output Class Initialized
INFO - 2018-12-03 20:39:05 --> Security Class Initialized
DEBUG - 2018-12-03 20:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:39:05 --> Input Class Initialized
INFO - 2018-12-03 20:39:05 --> Language Class Initialized
INFO - 2018-12-03 20:39:05 --> Loader Class Initialized
INFO - 2018-12-03 20:39:05 --> Helper loaded: url_helper
INFO - 2018-12-03 20:39:05 --> Helper loaded: html_helper
INFO - 2018-12-03 20:39:05 --> Helper loaded: form_helper
INFO - 2018-12-03 20:39:05 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:39:05 --> Helper loaded: date_helper
INFO - 2018-12-03 20:39:05 --> Form Validation Class Initialized
INFO - 2018-12-03 20:39:05 --> Email Class Initialized
DEBUG - 2018-12-03 20:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:39:05 --> Pagination Class Initialized
INFO - 2018-12-03 20:39:05 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:05 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:05 --> Controller Class Initialized
INFO - 2018-12-03 20:39:05 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-12-03 20:39:05 --> Final output sent to browser
DEBUG - 2018-12-03 20:39:05 --> Total execution time: 0.0615
INFO - 2018-12-03 20:39:06 --> Config Class Initialized
INFO - 2018-12-03 20:39:06 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:39:06 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:39:06 --> Utf8 Class Initialized
INFO - 2018-12-03 20:39:06 --> URI Class Initialized
DEBUG - 2018-12-03 20:39:06 --> No URI present. Default controller set.
INFO - 2018-12-03 20:39:06 --> Router Class Initialized
INFO - 2018-12-03 20:39:06 --> Output Class Initialized
INFO - 2018-12-03 20:39:06 --> Security Class Initialized
DEBUG - 2018-12-03 20:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:39:06 --> Input Class Initialized
INFO - 2018-12-03 20:39:06 --> Language Class Initialized
INFO - 2018-12-03 20:39:06 --> Loader Class Initialized
INFO - 2018-12-03 20:39:06 --> Helper loaded: url_helper
INFO - 2018-12-03 20:39:06 --> Helper loaded: html_helper
INFO - 2018-12-03 20:39:06 --> Helper loaded: form_helper
INFO - 2018-12-03 20:39:06 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:39:06 --> Helper loaded: date_helper
INFO - 2018-12-03 20:39:06 --> Form Validation Class Initialized
INFO - 2018-12-03 20:39:06 --> Email Class Initialized
DEBUG - 2018-12-03 20:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:39:06 --> Pagination Class Initialized
INFO - 2018-12-03 20:39:06 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:06 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:06 --> Controller Class Initialized
INFO - 2018-12-03 20:39:06 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-12-03 20:39:06 --> Final output sent to browser
DEBUG - 2018-12-03 20:39:06 --> Total execution time: 0.0641
INFO - 2018-12-03 20:39:07 --> Config Class Initialized
INFO - 2018-12-03 20:39:07 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:39:07 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:39:07 --> Utf8 Class Initialized
INFO - 2018-12-03 20:39:07 --> URI Class Initialized
DEBUG - 2018-12-03 20:39:07 --> No URI present. Default controller set.
INFO - 2018-12-03 20:39:07 --> Router Class Initialized
INFO - 2018-12-03 20:39:07 --> Output Class Initialized
INFO - 2018-12-03 20:39:07 --> Security Class Initialized
DEBUG - 2018-12-03 20:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:39:07 --> Input Class Initialized
INFO - 2018-12-03 20:39:07 --> Language Class Initialized
INFO - 2018-12-03 20:39:07 --> Loader Class Initialized
INFO - 2018-12-03 20:39:07 --> Helper loaded: url_helper
INFO - 2018-12-03 20:39:07 --> Helper loaded: html_helper
INFO - 2018-12-03 20:39:07 --> Helper loaded: form_helper
INFO - 2018-12-03 20:39:07 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:39:07 --> Helper loaded: date_helper
INFO - 2018-12-03 20:39:07 --> Form Validation Class Initialized
INFO - 2018-12-03 20:39:07 --> Email Class Initialized
DEBUG - 2018-12-03 20:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:39:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:39:07 --> Pagination Class Initialized
INFO - 2018-12-03 20:39:07 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:07 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:07 --> Controller Class Initialized
INFO - 2018-12-03 20:39:07 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-12-03 20:39:07 --> Final output sent to browser
DEBUG - 2018-12-03 20:39:07 --> Total execution time: 0.0628
INFO - 2018-12-03 20:39:07 --> Config Class Initialized
INFO - 2018-12-03 20:39:07 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:39:07 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:39:07 --> Utf8 Class Initialized
INFO - 2018-12-03 20:39:07 --> URI Class Initialized
DEBUG - 2018-12-03 20:39:07 --> No URI present. Default controller set.
INFO - 2018-12-03 20:39:07 --> Router Class Initialized
INFO - 2018-12-03 20:39:07 --> Output Class Initialized
INFO - 2018-12-03 20:39:07 --> Security Class Initialized
DEBUG - 2018-12-03 20:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:39:07 --> Input Class Initialized
INFO - 2018-12-03 20:39:07 --> Language Class Initialized
INFO - 2018-12-03 20:39:07 --> Loader Class Initialized
INFO - 2018-12-03 20:39:07 --> Helper loaded: url_helper
INFO - 2018-12-03 20:39:07 --> Helper loaded: html_helper
INFO - 2018-12-03 20:39:07 --> Helper loaded: form_helper
INFO - 2018-12-03 20:39:07 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:39:07 --> Helper loaded: date_helper
INFO - 2018-12-03 20:39:07 --> Form Validation Class Initialized
INFO - 2018-12-03 20:39:07 --> Email Class Initialized
DEBUG - 2018-12-03 20:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:39:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:39:07 --> Pagination Class Initialized
INFO - 2018-12-03 20:39:07 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:07 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:07 --> Controller Class Initialized
INFO - 2018-12-03 20:39:07 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-12-03 20:39:07 --> Final output sent to browser
DEBUG - 2018-12-03 20:39:07 --> Total execution time: 0.1264
INFO - 2018-12-03 20:39:16 --> Config Class Initialized
INFO - 2018-12-03 20:39:16 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:39:16 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:39:16 --> Utf8 Class Initialized
INFO - 2018-12-03 20:39:16 --> URI Class Initialized
INFO - 2018-12-03 20:39:16 --> Router Class Initialized
INFO - 2018-12-03 20:39:16 --> Output Class Initialized
INFO - 2018-12-03 20:39:16 --> Security Class Initialized
DEBUG - 2018-12-03 20:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:39:16 --> Input Class Initialized
INFO - 2018-12-03 20:39:16 --> Language Class Initialized
INFO - 2018-12-03 20:39:16 --> Loader Class Initialized
INFO - 2018-12-03 20:39:16 --> Helper loaded: url_helper
INFO - 2018-12-03 20:39:16 --> Helper loaded: html_helper
INFO - 2018-12-03 20:39:16 --> Helper loaded: form_helper
INFO - 2018-12-03 20:39:16 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:39:16 --> Helper loaded: date_helper
INFO - 2018-12-03 20:39:16 --> Form Validation Class Initialized
INFO - 2018-12-03 20:39:16 --> Email Class Initialized
DEBUG - 2018-12-03 20:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:39:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:39:16 --> Pagination Class Initialized
INFO - 2018-12-03 20:39:16 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:16 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:16 --> Controller Class Initialized
INFO - 2018-12-03 20:39:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-03 20:39:16 --> Config Class Initialized
INFO - 2018-12-03 20:39:16 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:39:16 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:39:16 --> Utf8 Class Initialized
INFO - 2018-12-03 20:39:16 --> URI Class Initialized
INFO - 2018-12-03 20:39:16 --> Router Class Initialized
INFO - 2018-12-03 20:39:16 --> Output Class Initialized
INFO - 2018-12-03 20:39:16 --> Security Class Initialized
DEBUG - 2018-12-03 20:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:39:16 --> Input Class Initialized
INFO - 2018-12-03 20:39:16 --> Language Class Initialized
INFO - 2018-12-03 20:39:16 --> Loader Class Initialized
INFO - 2018-12-03 20:39:16 --> Helper loaded: url_helper
INFO - 2018-12-03 20:39:16 --> Helper loaded: html_helper
INFO - 2018-12-03 20:39:16 --> Helper loaded: form_helper
INFO - 2018-12-03 20:39:16 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:39:16 --> Helper loaded: date_helper
INFO - 2018-12-03 20:39:16 --> Form Validation Class Initialized
INFO - 2018-12-03 20:39:16 --> Email Class Initialized
DEBUG - 2018-12-03 20:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:39:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:39:16 --> Pagination Class Initialized
INFO - 2018-12-03 20:39:16 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:16 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:16 --> Controller Class Initialized
INFO - 2018-12-03 20:39:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-03 20:39:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-12-03 20:39:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-03 20:39:17 --> Final output sent to browser
DEBUG - 2018-12-03 20:39:17 --> Total execution time: 0.1667
INFO - 2018-12-03 20:39:17 --> Config Class Initialized
INFO - 2018-12-03 20:39:17 --> Hooks Class Initialized
INFO - 2018-12-03 20:39:17 --> Config Class Initialized
INFO - 2018-12-03 20:39:17 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:39:17 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:39:17 --> Utf8 Class Initialized
DEBUG - 2018-12-03 20:39:17 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:39:17 --> Utf8 Class Initialized
INFO - 2018-12-03 20:39:17 --> URI Class Initialized
INFO - 2018-12-03 20:39:17 --> URI Class Initialized
INFO - 2018-12-03 20:39:17 --> Router Class Initialized
INFO - 2018-12-03 20:39:17 --> Output Class Initialized
INFO - 2018-12-03 20:39:17 --> Security Class Initialized
DEBUG - 2018-12-03 20:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:39:17 --> Input Class Initialized
INFO - 2018-12-03 20:39:17 --> Language Class Initialized
INFO - 2018-12-03 20:39:17 --> Router Class Initialized
INFO - 2018-12-03 20:39:17 --> Output Class Initialized
INFO - 2018-12-03 20:39:17 --> Security Class Initialized
DEBUG - 2018-12-03 20:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:39:17 --> Loader Class Initialized
INFO - 2018-12-03 20:39:17 --> Input Class Initialized
INFO - 2018-12-03 20:39:17 --> Language Class Initialized
INFO - 2018-12-03 20:39:17 --> Helper loaded: url_helper
INFO - 2018-12-03 20:39:17 --> Helper loaded: html_helper
INFO - 2018-12-03 20:39:17 --> Helper loaded: form_helper
INFO - 2018-12-03 20:39:17 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:39:17 --> Loader Class Initialized
INFO - 2018-12-03 20:39:17 --> Helper loaded: date_helper
INFO - 2018-12-03 20:39:17 --> Form Validation Class Initialized
INFO - 2018-12-03 20:39:17 --> Helper loaded: url_helper
INFO - 2018-12-03 20:39:17 --> Helper loaded: html_helper
INFO - 2018-12-03 20:39:17 --> Helper loaded: form_helper
INFO - 2018-12-03 20:39:17 --> Email Class Initialized
INFO - 2018-12-03 20:39:17 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:39:17 --> Helper loaded: date_helper
DEBUG - 2018-12-03 20:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:39:17 --> Form Validation Class Initialized
INFO - 2018-12-03 20:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:39:17 --> Pagination Class Initialized
INFO - 2018-12-03 20:39:17 --> Email Class Initialized
DEBUG - 2018-12-03 20:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:39:17 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:17 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:17 --> Controller Class Initialized
INFO - 2018-12-03 20:39:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-03 20:39:17 --> Final output sent to browser
DEBUG - 2018-12-03 20:39:17 --> Total execution time: 0.1050
INFO - 2018-12-03 20:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:39:17 --> Pagination Class Initialized
INFO - 2018-12-03 20:39:17 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:17 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:17 --> Controller Class Initialized
INFO - 2018-12-03 20:39:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-03 20:39:17 --> Final output sent to browser
DEBUG - 2018-12-03 20:39:17 --> Total execution time: 0.1416
INFO - 2018-12-03 20:39:24 --> Config Class Initialized
INFO - 2018-12-03 20:39:24 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:39:24 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:39:24 --> Utf8 Class Initialized
INFO - 2018-12-03 20:39:24 --> URI Class Initialized
INFO - 2018-12-03 20:39:24 --> Router Class Initialized
INFO - 2018-12-03 20:39:24 --> Output Class Initialized
INFO - 2018-12-03 20:39:24 --> Security Class Initialized
DEBUG - 2018-12-03 20:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:39:24 --> Input Class Initialized
INFO - 2018-12-03 20:39:24 --> Language Class Initialized
INFO - 2018-12-03 20:39:24 --> Loader Class Initialized
INFO - 2018-12-03 20:39:24 --> Helper loaded: url_helper
INFO - 2018-12-03 20:39:24 --> Helper loaded: html_helper
INFO - 2018-12-03 20:39:24 --> Helper loaded: form_helper
INFO - 2018-12-03 20:39:24 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:39:24 --> Helper loaded: date_helper
INFO - 2018-12-03 20:39:24 --> Form Validation Class Initialized
INFO - 2018-12-03 20:39:24 --> Email Class Initialized
DEBUG - 2018-12-03 20:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:39:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:39:24 --> Pagination Class Initialized
INFO - 2018-12-03 20:39:24 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:24 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:24 --> Controller Class Initialized
DEBUG - 2018-12-03 20:39:24 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-12-03 20:39:24 --> Helper loaded: inflector_helper
INFO - 2018-12-03 20:39:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-12-03 20:39:24 --> Final output sent to browser
DEBUG - 2018-12-03 20:39:24 --> Total execution time: 0.1719
INFO - 2018-12-03 20:39:51 --> Config Class Initialized
INFO - 2018-12-03 20:39:51 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:39:51 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:39:51 --> Utf8 Class Initialized
INFO - 2018-12-03 20:39:51 --> URI Class Initialized
INFO - 2018-12-03 20:39:51 --> Router Class Initialized
INFO - 2018-12-03 20:39:51 --> Output Class Initialized
INFO - 2018-12-03 20:39:51 --> Security Class Initialized
DEBUG - 2018-12-03 20:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:39:51 --> Input Class Initialized
INFO - 2018-12-03 20:39:51 --> Language Class Initialized
INFO - 2018-12-03 20:39:51 --> Loader Class Initialized
INFO - 2018-12-03 20:39:51 --> Helper loaded: url_helper
INFO - 2018-12-03 20:39:51 --> Helper loaded: html_helper
INFO - 2018-12-03 20:39:51 --> Helper loaded: form_helper
INFO - 2018-12-03 20:39:51 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:39:51 --> Helper loaded: date_helper
INFO - 2018-12-03 20:39:51 --> Form Validation Class Initialized
INFO - 2018-12-03 20:39:51 --> Email Class Initialized
DEBUG - 2018-12-03 20:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:39:51 --> Pagination Class Initialized
INFO - 2018-12-03 20:39:51 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:51 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:51 --> Controller Class Initialized
INFO - 2018-12-03 20:39:51 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-03 20:39:51 --> Final output sent to browser
DEBUG - 2018-12-03 20:39:51 --> Total execution time: 0.0595
INFO - 2018-12-03 20:39:51 --> Config Class Initialized
INFO - 2018-12-03 20:39:51 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:39:51 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:39:51 --> Utf8 Class Initialized
INFO - 2018-12-03 20:39:51 --> URI Class Initialized
INFO - 2018-12-03 20:39:51 --> Router Class Initialized
INFO - 2018-12-03 20:39:51 --> Output Class Initialized
INFO - 2018-12-03 20:39:51 --> Security Class Initialized
DEBUG - 2018-12-03 20:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:39:51 --> Input Class Initialized
INFO - 2018-12-03 20:39:51 --> Language Class Initialized
INFO - 2018-12-03 20:39:51 --> Loader Class Initialized
INFO - 2018-12-03 20:39:51 --> Helper loaded: url_helper
INFO - 2018-12-03 20:39:51 --> Helper loaded: html_helper
INFO - 2018-12-03 20:39:51 --> Helper loaded: form_helper
INFO - 2018-12-03 20:39:51 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:39:51 --> Helper loaded: date_helper
INFO - 2018-12-03 20:39:51 --> Form Validation Class Initialized
INFO - 2018-12-03 20:39:51 --> Email Class Initialized
DEBUG - 2018-12-03 20:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:39:51 --> Pagination Class Initialized
INFO - 2018-12-03 20:39:51 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:51 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:51 --> Controller Class Initialized
INFO - 2018-12-03 20:39:51 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-03 20:39:51 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/report.php
INFO - 2018-12-03 20:39:51 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-03 20:39:51 --> Final output sent to browser
DEBUG - 2018-12-03 20:39:51 --> Total execution time: 0.1890
INFO - 2018-12-03 20:39:51 --> Config Class Initialized
INFO - 2018-12-03 20:39:51 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:39:51 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:39:51 --> Utf8 Class Initialized
INFO - 2018-12-03 20:39:51 --> URI Class Initialized
INFO - 2018-12-03 20:39:51 --> Router Class Initialized
INFO - 2018-12-03 20:39:51 --> Output Class Initialized
INFO - 2018-12-03 20:39:51 --> Security Class Initialized
DEBUG - 2018-12-03 20:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:39:51 --> Input Class Initialized
INFO - 2018-12-03 20:39:51 --> Language Class Initialized
INFO - 2018-12-03 20:39:51 --> Loader Class Initialized
INFO - 2018-12-03 20:39:51 --> Helper loaded: url_helper
INFO - 2018-12-03 20:39:51 --> Helper loaded: html_helper
INFO - 2018-12-03 20:39:51 --> Helper loaded: form_helper
INFO - 2018-12-03 20:39:51 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:39:51 --> Helper loaded: date_helper
INFO - 2018-12-03 20:39:51 --> Form Validation Class Initialized
INFO - 2018-12-03 20:39:51 --> Email Class Initialized
DEBUG - 2018-12-03 20:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:39:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:39:52 --> Pagination Class Initialized
INFO - 2018-12-03 20:39:52 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:52 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:52 --> Controller Class Initialized
INFO - 2018-12-03 20:39:52 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-03 20:39:52 --> Final output sent to browser
DEBUG - 2018-12-03 20:39:52 --> Total execution time: 0.0705
INFO - 2018-12-03 20:39:59 --> Config Class Initialized
INFO - 2018-12-03 20:39:59 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:39:59 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:39:59 --> Utf8 Class Initialized
INFO - 2018-12-03 20:39:59 --> URI Class Initialized
INFO - 2018-12-03 20:39:59 --> Router Class Initialized
INFO - 2018-12-03 20:39:59 --> Output Class Initialized
INFO - 2018-12-03 20:39:59 --> Security Class Initialized
DEBUG - 2018-12-03 20:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:39:59 --> Input Class Initialized
INFO - 2018-12-03 20:39:59 --> Language Class Initialized
INFO - 2018-12-03 20:39:59 --> Loader Class Initialized
INFO - 2018-12-03 20:39:59 --> Helper loaded: url_helper
INFO - 2018-12-03 20:39:59 --> Helper loaded: html_helper
INFO - 2018-12-03 20:39:59 --> Helper loaded: form_helper
INFO - 2018-12-03 20:39:59 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:39:59 --> Helper loaded: date_helper
INFO - 2018-12-03 20:39:59 --> Form Validation Class Initialized
INFO - 2018-12-03 20:39:59 --> Email Class Initialized
DEBUG - 2018-12-03 20:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:39:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:39:59 --> Pagination Class Initialized
INFO - 2018-12-03 20:39:59 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:59 --> Database Driver Class Initialized
INFO - 2018-12-03 20:39:59 --> Controller Class Initialized
INFO - 2018-12-03 20:39:59 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_print.php
INFO - 2018-12-03 20:39:59 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/prints/report_sales.php
INFO - 2018-12-03 20:39:59 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-03 20:39:59 --> Final output sent to browser
DEBUG - 2018-12-03 20:39:59 --> Total execution time: 0.2215
INFO - 2018-12-03 20:40:04 --> Config Class Initialized
INFO - 2018-12-03 20:40:04 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:40:04 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:40:04 --> Utf8 Class Initialized
INFO - 2018-12-03 20:40:04 --> URI Class Initialized
INFO - 2018-12-03 20:40:04 --> Router Class Initialized
INFO - 2018-12-03 20:40:04 --> Output Class Initialized
INFO - 2018-12-03 20:40:04 --> Security Class Initialized
DEBUG - 2018-12-03 20:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:40:04 --> Input Class Initialized
INFO - 2018-12-03 20:40:04 --> Language Class Initialized
INFO - 2018-12-03 20:40:04 --> Loader Class Initialized
INFO - 2018-12-03 20:40:04 --> Helper loaded: url_helper
INFO - 2018-12-03 20:40:04 --> Helper loaded: html_helper
INFO - 2018-12-03 20:40:04 --> Helper loaded: form_helper
INFO - 2018-12-03 20:40:04 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:40:04 --> Helper loaded: date_helper
INFO - 2018-12-03 20:40:04 --> Form Validation Class Initialized
INFO - 2018-12-03 20:40:04 --> Email Class Initialized
DEBUG - 2018-12-03 20:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:40:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:40:04 --> Pagination Class Initialized
INFO - 2018-12-03 20:40:04 --> Database Driver Class Initialized
INFO - 2018-12-03 20:40:04 --> Database Driver Class Initialized
INFO - 2018-12-03 20:40:04 --> Controller Class Initialized
INFO - 2018-12-03 20:40:04 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-03 20:40:04 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/report.php
INFO - 2018-12-03 20:40:04 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-03 20:40:04 --> Final output sent to browser
DEBUG - 2018-12-03 20:40:04 --> Total execution time: 0.0717
INFO - 2018-12-03 20:40:04 --> Config Class Initialized
INFO - 2018-12-03 20:40:04 --> Hooks Class Initialized
DEBUG - 2018-12-03 20:40:04 --> UTF-8 Support Enabled
INFO - 2018-12-03 20:40:04 --> Utf8 Class Initialized
INFO - 2018-12-03 20:40:04 --> URI Class Initialized
INFO - 2018-12-03 20:40:04 --> Router Class Initialized
INFO - 2018-12-03 20:40:04 --> Output Class Initialized
INFO - 2018-12-03 20:40:04 --> Security Class Initialized
DEBUG - 2018-12-03 20:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 20:40:04 --> Input Class Initialized
INFO - 2018-12-03 20:40:04 --> Language Class Initialized
INFO - 2018-12-03 20:40:04 --> Loader Class Initialized
INFO - 2018-12-03 20:40:04 --> Helper loaded: url_helper
INFO - 2018-12-03 20:40:04 --> Helper loaded: html_helper
INFO - 2018-12-03 20:40:04 --> Helper loaded: form_helper
INFO - 2018-12-03 20:40:04 --> Helper loaded: cookie_helper
INFO - 2018-12-03 20:40:04 --> Helper loaded: date_helper
INFO - 2018-12-03 20:40:04 --> Form Validation Class Initialized
INFO - 2018-12-03 20:40:04 --> Email Class Initialized
DEBUG - 2018-12-03 20:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 20:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 20:40:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 20:40:04 --> Pagination Class Initialized
INFO - 2018-12-03 20:40:04 --> Database Driver Class Initialized
INFO - 2018-12-03 20:40:04 --> Database Driver Class Initialized
INFO - 2018-12-03 20:40:04 --> Controller Class Initialized
INFO - 2018-12-03 20:40:04 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-03 20:40:04 --> Final output sent to browser
DEBUG - 2018-12-03 20:40:04 --> Total execution time: 0.0671
INFO - 2018-12-03 22:52:16 --> Config Class Initialized
INFO - 2018-12-03 22:52:16 --> Hooks Class Initialized
DEBUG - 2018-12-03 22:52:16 --> UTF-8 Support Enabled
INFO - 2018-12-03 22:52:16 --> Utf8 Class Initialized
INFO - 2018-12-03 22:52:16 --> URI Class Initialized
INFO - 2018-12-03 22:52:16 --> Router Class Initialized
INFO - 2018-12-03 22:52:16 --> Output Class Initialized
INFO - 2018-12-03 22:52:16 --> Security Class Initialized
DEBUG - 2018-12-03 22:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 22:52:16 --> Input Class Initialized
INFO - 2018-12-03 22:52:16 --> Language Class Initialized
INFO - 2018-12-03 22:52:16 --> Loader Class Initialized
INFO - 2018-12-03 22:52:16 --> Helper loaded: url_helper
INFO - 2018-12-03 22:52:16 --> Helper loaded: html_helper
INFO - 2018-12-03 22:52:16 --> Helper loaded: form_helper
INFO - 2018-12-03 22:52:16 --> Helper loaded: cookie_helper
INFO - 2018-12-03 22:52:16 --> Helper loaded: date_helper
INFO - 2018-12-03 22:52:16 --> Form Validation Class Initialized
INFO - 2018-12-03 22:52:16 --> Email Class Initialized
DEBUG - 2018-12-03 22:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 22:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 22:52:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 22:52:16 --> Pagination Class Initialized
INFO - 2018-12-03 22:52:16 --> Database Driver Class Initialized
INFO - 2018-12-03 22:52:16 --> Database Driver Class Initialized
INFO - 2018-12-03 22:52:16 --> Controller Class Initialized
INFO - 2018-12-03 22:52:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-03 22:52:16 --> Config Class Initialized
INFO - 2018-12-03 22:52:16 --> Hooks Class Initialized
DEBUG - 2018-12-03 22:52:16 --> UTF-8 Support Enabled
INFO - 2018-12-03 22:52:16 --> Utf8 Class Initialized
INFO - 2018-12-03 22:52:16 --> URI Class Initialized
INFO - 2018-12-03 22:52:16 --> Router Class Initialized
INFO - 2018-12-03 22:52:16 --> Output Class Initialized
INFO - 2018-12-03 22:52:16 --> Security Class Initialized
DEBUG - 2018-12-03 22:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 22:52:16 --> Input Class Initialized
INFO - 2018-12-03 22:52:16 --> Language Class Initialized
INFO - 2018-12-03 22:52:16 --> Loader Class Initialized
INFO - 2018-12-03 22:52:16 --> Helper loaded: url_helper
INFO - 2018-12-03 22:52:16 --> Helper loaded: html_helper
INFO - 2018-12-03 22:52:16 --> Helper loaded: form_helper
INFO - 2018-12-03 22:52:16 --> Helper loaded: cookie_helper
INFO - 2018-12-03 22:52:16 --> Helper loaded: date_helper
INFO - 2018-12-03 22:52:16 --> Form Validation Class Initialized
INFO - 2018-12-03 22:52:16 --> Email Class Initialized
DEBUG - 2018-12-03 22:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 22:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 22:52:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 22:52:16 --> Pagination Class Initialized
INFO - 2018-12-03 22:52:16 --> Database Driver Class Initialized
INFO - 2018-12-03 22:52:16 --> Database Driver Class Initialized
INFO - 2018-12-03 22:52:16 --> Controller Class Initialized
INFO - 2018-12-03 22:52:16 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-03 22:52:16 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-12-03 22:52:16 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-03 22:52:16 --> Final output sent to browser
DEBUG - 2018-12-03 22:52:16 --> Total execution time: 0.1745
INFO - 2018-12-03 22:52:17 --> Config Class Initialized
INFO - 2018-12-03 22:52:17 --> Hooks Class Initialized
DEBUG - 2018-12-03 22:52:17 --> UTF-8 Support Enabled
INFO - 2018-12-03 22:52:17 --> Utf8 Class Initialized
INFO - 2018-12-03 22:52:17 --> Config Class Initialized
INFO - 2018-12-03 22:52:17 --> Hooks Class Initialized
INFO - 2018-12-03 22:52:17 --> URI Class Initialized
INFO - 2018-12-03 22:52:17 --> Router Class Initialized
DEBUG - 2018-12-03 22:52:17 --> UTF-8 Support Enabled
INFO - 2018-12-03 22:52:17 --> Utf8 Class Initialized
INFO - 2018-12-03 22:52:17 --> Output Class Initialized
INFO - 2018-12-03 22:52:17 --> URI Class Initialized
INFO - 2018-12-03 22:52:17 --> Security Class Initialized
DEBUG - 2018-12-03 22:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 22:52:17 --> Input Class Initialized
INFO - 2018-12-03 22:52:17 --> Language Class Initialized
INFO - 2018-12-03 22:52:17 --> Router Class Initialized
INFO - 2018-12-03 22:52:17 --> Loader Class Initialized
INFO - 2018-12-03 22:52:17 --> Output Class Initialized
INFO - 2018-12-03 22:52:17 --> Helper loaded: url_helper
INFO - 2018-12-03 22:52:17 --> Helper loaded: html_helper
INFO - 2018-12-03 22:52:17 --> Security Class Initialized
INFO - 2018-12-03 22:52:17 --> Helper loaded: form_helper
INFO - 2018-12-03 22:52:17 --> Helper loaded: cookie_helper
DEBUG - 2018-12-03 22:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-03 22:52:17 --> Input Class Initialized
INFO - 2018-12-03 22:52:17 --> Helper loaded: date_helper
INFO - 2018-12-03 22:52:17 --> Language Class Initialized
INFO - 2018-12-03 22:52:17 --> Form Validation Class Initialized
INFO - 2018-12-03 22:52:17 --> Email Class Initialized
INFO - 2018-12-03 22:52:17 --> Loader Class Initialized
INFO - 2018-12-03 22:52:17 --> Helper loaded: url_helper
INFO - 2018-12-03 22:52:17 --> Helper loaded: html_helper
DEBUG - 2018-12-03 22:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 22:52:17 --> Helper loaded: form_helper
INFO - 2018-12-03 22:52:17 --> Helper loaded: cookie_helper
INFO - 2018-12-03 22:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 22:52:17 --> Helper loaded: date_helper
INFO - 2018-12-03 22:52:17 --> Form Validation Class Initialized
INFO - 2018-12-03 22:52:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 22:52:17 --> Pagination Class Initialized
INFO - 2018-12-03 22:52:17 --> Email Class Initialized
DEBUG - 2018-12-03 22:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-03 22:52:17 --> Database Driver Class Initialized
INFO - 2018-12-03 22:52:17 --> Database Driver Class Initialized
INFO - 2018-12-03 22:52:17 --> Controller Class Initialized
INFO - 2018-12-03 22:52:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-03 22:52:17 --> Final output sent to browser
DEBUG - 2018-12-03 22:52:17 --> Total execution time: 0.2043
INFO - 2018-12-03 22:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-03 22:52:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-03 22:52:17 --> Pagination Class Initialized
INFO - 2018-12-03 22:52:17 --> Database Driver Class Initialized
INFO - 2018-12-03 22:52:17 --> Database Driver Class Initialized
INFO - 2018-12-03 22:52:17 --> Controller Class Initialized
INFO - 2018-12-03 22:52:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-03 22:52:17 --> Final output sent to browser
DEBUG - 2018-12-03 22:52:17 --> Total execution time: 0.2683
