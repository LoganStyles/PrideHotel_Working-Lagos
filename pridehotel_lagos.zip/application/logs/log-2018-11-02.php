<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-02 04:41:46 --> Config Class Initialized
INFO - 2018-11-02 04:41:46 --> Hooks Class Initialized
DEBUG - 2018-11-02 04:41:46 --> UTF-8 Support Enabled
INFO - 2018-11-02 04:41:46 --> Utf8 Class Initialized
INFO - 2018-11-02 04:41:46 --> URI Class Initialized
DEBUG - 2018-11-02 04:41:46 --> No URI present. Default controller set.
INFO - 2018-11-02 04:41:46 --> Router Class Initialized
INFO - 2018-11-02 04:41:46 --> Output Class Initialized
INFO - 2018-11-02 04:41:46 --> Security Class Initialized
DEBUG - 2018-11-02 04:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 04:41:46 --> Input Class Initialized
INFO - 2018-11-02 04:41:46 --> Language Class Initialized
INFO - 2018-11-02 04:41:46 --> Loader Class Initialized
INFO - 2018-11-02 04:41:46 --> Helper loaded: url_helper
INFO - 2018-11-02 04:41:46 --> Helper loaded: html_helper
INFO - 2018-11-02 04:41:46 --> Helper loaded: form_helper
INFO - 2018-11-02 04:41:46 --> Helper loaded: cookie_helper
INFO - 2018-11-02 04:41:46 --> Helper loaded: date_helper
INFO - 2018-11-02 04:41:46 --> Form Validation Class Initialized
INFO - 2018-11-02 04:41:46 --> Email Class Initialized
DEBUG - 2018-11-02 04:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 04:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 04:41:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 04:41:46 --> Pagination Class Initialized
INFO - 2018-11-02 04:41:46 --> Database Driver Class Initialized
INFO - 2018-11-02 04:41:46 --> Database Driver Class Initialized
INFO - 2018-11-02 04:41:46 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-02 04:43:58 --> Config Class Initialized
INFO - 2018-11-02 04:43:58 --> Hooks Class Initialized
DEBUG - 2018-11-02 04:43:58 --> UTF-8 Support Enabled
INFO - 2018-11-02 04:43:58 --> Utf8 Class Initialized
INFO - 2018-11-02 04:43:58 --> URI Class Initialized
INFO - 2018-11-02 04:43:58 --> Router Class Initialized
INFO - 2018-11-02 04:43:58 --> Output Class Initialized
INFO - 2018-11-02 04:43:58 --> Security Class Initialized
DEBUG - 2018-11-02 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 04:43:58 --> Input Class Initialized
INFO - 2018-11-02 04:43:58 --> Language Class Initialized
INFO - 2018-11-02 04:43:58 --> Loader Class Initialized
INFO - 2018-11-02 04:43:58 --> Helper loaded: url_helper
INFO - 2018-11-02 04:43:58 --> Helper loaded: html_helper
INFO - 2018-11-02 04:43:58 --> Helper loaded: form_helper
INFO - 2018-11-02 04:43:58 --> Helper loaded: cookie_helper
INFO - 2018-11-02 04:43:58 --> Helper loaded: date_helper
INFO - 2018-11-02 04:43:58 --> Form Validation Class Initialized
INFO - 2018-11-02 04:43:58 --> Email Class Initialized
DEBUG - 2018-11-02 04:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 04:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 04:43:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 04:43:58 --> Pagination Class Initialized
INFO - 2018-11-02 04:43:58 --> Database Driver Class Initialized
INFO - 2018-11-02 04:43:58 --> Database Driver Class Initialized
INFO - 2018-11-02 04:43:58 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-02 04:47:36 --> Config Class Initialized
INFO - 2018-11-02 04:47:36 --> Hooks Class Initialized
DEBUG - 2018-11-02 04:47:36 --> UTF-8 Support Enabled
INFO - 2018-11-02 04:47:36 --> Utf8 Class Initialized
INFO - 2018-11-02 04:47:36 --> URI Class Initialized
DEBUG - 2018-11-02 04:47:36 --> No URI present. Default controller set.
INFO - 2018-11-02 04:47:36 --> Router Class Initialized
INFO - 2018-11-02 04:47:36 --> Output Class Initialized
INFO - 2018-11-02 04:47:36 --> Security Class Initialized
DEBUG - 2018-11-02 04:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 04:47:36 --> Input Class Initialized
INFO - 2018-11-02 04:47:36 --> Language Class Initialized
INFO - 2018-11-02 04:47:36 --> Loader Class Initialized
INFO - 2018-11-02 04:47:36 --> Helper loaded: url_helper
INFO - 2018-11-02 04:47:36 --> Helper loaded: html_helper
INFO - 2018-11-02 04:47:36 --> Helper loaded: form_helper
INFO - 2018-11-02 04:47:36 --> Helper loaded: cookie_helper
INFO - 2018-11-02 04:47:36 --> Helper loaded: date_helper
INFO - 2018-11-02 04:47:36 --> Form Validation Class Initialized
INFO - 2018-11-02 04:47:36 --> Email Class Initialized
DEBUG - 2018-11-02 04:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 04:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 04:47:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 04:47:36 --> Pagination Class Initialized
INFO - 2018-11-02 04:47:36 --> Database Driver Class Initialized
INFO - 2018-11-02 04:47:36 --> Database Driver Class Initialized
INFO - 2018-11-02 04:47:36 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-02 04:48:55 --> Config Class Initialized
INFO - 2018-11-02 04:48:55 --> Hooks Class Initialized
DEBUG - 2018-11-02 04:48:55 --> UTF-8 Support Enabled
INFO - 2018-11-02 04:48:55 --> Utf8 Class Initialized
INFO - 2018-11-02 04:48:55 --> URI Class Initialized
DEBUG - 2018-11-02 04:48:55 --> No URI present. Default controller set.
INFO - 2018-11-02 04:48:55 --> Router Class Initialized
INFO - 2018-11-02 04:48:55 --> Output Class Initialized
INFO - 2018-11-02 04:48:55 --> Security Class Initialized
DEBUG - 2018-11-02 04:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 04:48:55 --> Input Class Initialized
INFO - 2018-11-02 04:48:55 --> Language Class Initialized
INFO - 2018-11-02 04:48:55 --> Loader Class Initialized
INFO - 2018-11-02 04:48:55 --> Helper loaded: url_helper
INFO - 2018-11-02 04:48:55 --> Helper loaded: html_helper
INFO - 2018-11-02 04:48:55 --> Helper loaded: form_helper
INFO - 2018-11-02 04:48:55 --> Helper loaded: cookie_helper
INFO - 2018-11-02 04:48:55 --> Helper loaded: date_helper
INFO - 2018-11-02 04:48:55 --> Form Validation Class Initialized
INFO - 2018-11-02 04:48:55 --> Email Class Initialized
DEBUG - 2018-11-02 04:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 04:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 04:48:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 04:48:55 --> Pagination Class Initialized
INFO - 2018-11-02 04:48:55 --> Database Driver Class Initialized
INFO - 2018-11-02 04:48:55 --> Database Driver Class Initialized
INFO - 2018-11-02 04:48:55 --> Language file loaded: language/english/db_lang.php
INFO - 2018-11-02 04:51:28 --> Config Class Initialized
INFO - 2018-11-02 04:51:28 --> Hooks Class Initialized
DEBUG - 2018-11-02 04:51:28 --> UTF-8 Support Enabled
INFO - 2018-11-02 04:51:28 --> Utf8 Class Initialized
INFO - 2018-11-02 04:51:28 --> URI Class Initialized
DEBUG - 2018-11-02 04:51:28 --> No URI present. Default controller set.
INFO - 2018-11-02 04:51:28 --> Router Class Initialized
INFO - 2018-11-02 04:51:28 --> Output Class Initialized
INFO - 2018-11-02 04:51:28 --> Security Class Initialized
DEBUG - 2018-11-02 04:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 04:51:28 --> Input Class Initialized
INFO - 2018-11-02 04:51:28 --> Language Class Initialized
INFO - 2018-11-02 04:51:28 --> Loader Class Initialized
INFO - 2018-11-02 04:51:28 --> Helper loaded: url_helper
INFO - 2018-11-02 04:51:28 --> Helper loaded: html_helper
INFO - 2018-11-02 04:51:28 --> Helper loaded: form_helper
INFO - 2018-11-02 04:51:28 --> Helper loaded: cookie_helper
INFO - 2018-11-02 04:51:28 --> Helper loaded: date_helper
INFO - 2018-11-02 04:51:28 --> Form Validation Class Initialized
INFO - 2018-11-02 04:51:28 --> Email Class Initialized
DEBUG - 2018-11-02 04:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 04:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 04:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 04:51:28 --> Pagination Class Initialized
INFO - 2018-11-02 04:51:28 --> Database Driver Class Initialized
INFO - 2018-11-02 04:51:28 --> Database Driver Class Initialized
INFO - 2018-11-02 04:51:28 --> Controller Class Initialized
INFO - 2018-11-02 04:51:28 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-02 04:51:28 --> Final output sent to browser
DEBUG - 2018-11-02 04:51:28 --> Total execution time: 0.3803
INFO - 2018-11-02 04:51:29 --> Config Class Initialized
INFO - 2018-11-02 04:51:29 --> Hooks Class Initialized
DEBUG - 2018-11-02 04:51:29 --> UTF-8 Support Enabled
INFO - 2018-11-02 04:51:29 --> Utf8 Class Initialized
INFO - 2018-11-02 04:51:29 --> URI Class Initialized
DEBUG - 2018-11-02 04:51:29 --> No URI present. Default controller set.
INFO - 2018-11-02 04:51:29 --> Router Class Initialized
INFO - 2018-11-02 04:51:29 --> Output Class Initialized
INFO - 2018-11-02 04:51:29 --> Security Class Initialized
DEBUG - 2018-11-02 04:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 04:51:29 --> Input Class Initialized
INFO - 2018-11-02 04:51:29 --> Language Class Initialized
INFO - 2018-11-02 04:51:29 --> Loader Class Initialized
INFO - 2018-11-02 04:51:29 --> Helper loaded: url_helper
INFO - 2018-11-02 04:51:29 --> Helper loaded: html_helper
INFO - 2018-11-02 04:51:29 --> Helper loaded: form_helper
INFO - 2018-11-02 04:51:29 --> Helper loaded: cookie_helper
INFO - 2018-11-02 04:51:29 --> Helper loaded: date_helper
INFO - 2018-11-02 04:51:29 --> Form Validation Class Initialized
INFO - 2018-11-02 04:51:29 --> Email Class Initialized
DEBUG - 2018-11-02 04:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 04:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 04:51:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 04:51:29 --> Pagination Class Initialized
INFO - 2018-11-02 04:51:29 --> Database Driver Class Initialized
INFO - 2018-11-02 04:51:29 --> Database Driver Class Initialized
INFO - 2018-11-02 04:51:29 --> Controller Class Initialized
INFO - 2018-11-02 04:51:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-02 04:51:29 --> Final output sent to browser
DEBUG - 2018-11-02 04:51:29 --> Total execution time: 0.2606
INFO - 2018-11-02 05:03:58 --> Config Class Initialized
INFO - 2018-11-02 05:03:58 --> Hooks Class Initialized
DEBUG - 2018-11-02 05:03:58 --> UTF-8 Support Enabled
INFO - 2018-11-02 05:03:58 --> Utf8 Class Initialized
INFO - 2018-11-02 05:03:58 --> URI Class Initialized
INFO - 2018-11-02 05:03:58 --> Router Class Initialized
INFO - 2018-11-02 05:03:58 --> Output Class Initialized
INFO - 2018-11-02 05:03:58 --> Security Class Initialized
DEBUG - 2018-11-02 05:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 05:03:58 --> Input Class Initialized
INFO - 2018-11-02 05:03:58 --> Language Class Initialized
INFO - 2018-11-02 05:03:58 --> Loader Class Initialized
INFO - 2018-11-02 05:03:58 --> Helper loaded: url_helper
INFO - 2018-11-02 05:03:58 --> Helper loaded: html_helper
INFO - 2018-11-02 05:03:58 --> Helper loaded: form_helper
INFO - 2018-11-02 05:03:58 --> Helper loaded: cookie_helper
INFO - 2018-11-02 05:03:58 --> Helper loaded: date_helper
INFO - 2018-11-02 05:03:58 --> Form Validation Class Initialized
INFO - 2018-11-02 05:03:58 --> Email Class Initialized
DEBUG - 2018-11-02 05:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 05:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 05:03:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 05:03:58 --> Pagination Class Initialized
INFO - 2018-11-02 05:03:58 --> Database Driver Class Initialized
INFO - 2018-11-02 05:03:58 --> Database Driver Class Initialized
INFO - 2018-11-02 05:03:58 --> Controller Class Initialized
DEBUG - 2018-11-02 05:03:58 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-02 05:03:58 --> Helper loaded: inflector_helper
INFO - 2018-11-02 05:03:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-02 05:03:58 --> Final output sent to browser
DEBUG - 2018-11-02 05:03:58 --> Total execution time: 0.2884
INFO - 2018-11-02 05:04:51 --> Config Class Initialized
INFO - 2018-11-02 05:04:51 --> Hooks Class Initialized
DEBUG - 2018-11-02 05:04:51 --> UTF-8 Support Enabled
INFO - 2018-11-02 05:04:51 --> Utf8 Class Initialized
INFO - 2018-11-02 05:04:51 --> URI Class Initialized
INFO - 2018-11-02 05:04:51 --> Router Class Initialized
INFO - 2018-11-02 05:04:51 --> Output Class Initialized
INFO - 2018-11-02 05:04:51 --> Security Class Initialized
DEBUG - 2018-11-02 05:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 05:04:51 --> Input Class Initialized
INFO - 2018-11-02 05:04:51 --> Language Class Initialized
INFO - 2018-11-02 05:04:51 --> Loader Class Initialized
INFO - 2018-11-02 05:04:51 --> Helper loaded: url_helper
INFO - 2018-11-02 05:04:51 --> Helper loaded: html_helper
INFO - 2018-11-02 05:04:51 --> Helper loaded: form_helper
INFO - 2018-11-02 05:04:51 --> Helper loaded: cookie_helper
INFO - 2018-11-02 05:04:51 --> Helper loaded: date_helper
INFO - 2018-11-02 05:04:51 --> Form Validation Class Initialized
INFO - 2018-11-02 05:04:51 --> Email Class Initialized
DEBUG - 2018-11-02 05:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 05:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 05:04:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 05:04:51 --> Pagination Class Initialized
INFO - 2018-11-02 05:04:51 --> Database Driver Class Initialized
INFO - 2018-11-02 05:04:51 --> Database Driver Class Initialized
INFO - 2018-11-02 05:04:51 --> Controller Class Initialized
DEBUG - 2018-11-02 05:04:51 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-02 05:04:51 --> Helper loaded: inflector_helper
INFO - 2018-11-02 05:04:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-02 05:04:51 --> Final output sent to browser
DEBUG - 2018-11-02 05:04:51 --> Total execution time: 0.2499
INFO - 2018-11-02 09:29:20 --> Config Class Initialized
INFO - 2018-11-02 09:29:21 --> Hooks Class Initialized
DEBUG - 2018-11-02 09:29:21 --> UTF-8 Support Enabled
INFO - 2018-11-02 09:29:21 --> Utf8 Class Initialized
INFO - 2018-11-02 09:29:21 --> URI Class Initialized
DEBUG - 2018-11-02 09:29:22 --> No URI present. Default controller set.
INFO - 2018-11-02 09:29:22 --> Router Class Initialized
INFO - 2018-11-02 09:29:22 --> Output Class Initialized
INFO - 2018-11-02 09:29:22 --> Security Class Initialized
DEBUG - 2018-11-02 09:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 09:29:23 --> Input Class Initialized
INFO - 2018-11-02 09:29:23 --> Language Class Initialized
INFO - 2018-11-02 09:29:23 --> Loader Class Initialized
INFO - 2018-11-02 09:29:24 --> Helper loaded: url_helper
INFO - 2018-11-02 09:29:24 --> Helper loaded: html_helper
INFO - 2018-11-02 09:29:25 --> Helper loaded: form_helper
INFO - 2018-11-02 09:29:25 --> Helper loaded: cookie_helper
INFO - 2018-11-02 09:29:25 --> Helper loaded: date_helper
INFO - 2018-11-02 09:29:25 --> Form Validation Class Initialized
INFO - 2018-11-02 09:29:25 --> Email Class Initialized
DEBUG - 2018-11-02 09:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 09:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 09:29:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 09:29:26 --> Pagination Class Initialized
INFO - 2018-11-02 09:29:27 --> Database Driver Class Initialized
INFO - 2018-11-02 09:29:28 --> Database Driver Class Initialized
INFO - 2018-11-02 09:29:28 --> Controller Class Initialized
INFO - 2018-11-02 09:29:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-02 09:29:29 --> Final output sent to browser
DEBUG - 2018-11-02 09:29:29 --> Total execution time: 10.8358
INFO - 2018-11-02 09:36:16 --> Config Class Initialized
INFO - 2018-11-02 09:36:16 --> Hooks Class Initialized
DEBUG - 2018-11-02 09:36:16 --> UTF-8 Support Enabled
INFO - 2018-11-02 09:36:16 --> Utf8 Class Initialized
INFO - 2018-11-02 09:36:16 --> URI Class Initialized
INFO - 2018-11-02 09:36:16 --> Router Class Initialized
INFO - 2018-11-02 09:36:16 --> Output Class Initialized
INFO - 2018-11-02 09:36:16 --> Security Class Initialized
DEBUG - 2018-11-02 09:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 09:36:16 --> Input Class Initialized
INFO - 2018-11-02 09:36:16 --> Language Class Initialized
INFO - 2018-11-02 09:36:16 --> Loader Class Initialized
INFO - 2018-11-02 09:36:16 --> Helper loaded: url_helper
INFO - 2018-11-02 09:36:16 --> Helper loaded: html_helper
INFO - 2018-11-02 09:36:16 --> Helper loaded: form_helper
INFO - 2018-11-02 09:36:16 --> Helper loaded: cookie_helper
INFO - 2018-11-02 09:36:16 --> Helper loaded: date_helper
INFO - 2018-11-02 09:36:16 --> Form Validation Class Initialized
INFO - 2018-11-02 09:36:16 --> Email Class Initialized
DEBUG - 2018-11-02 09:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 09:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 09:36:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 09:36:16 --> Pagination Class Initialized
INFO - 2018-11-02 09:36:16 --> Database Driver Class Initialized
INFO - 2018-11-02 09:36:16 --> Database Driver Class Initialized
INFO - 2018-11-02 09:36:16 --> Controller Class Initialized
INFO - 2018-11-02 09:36:16 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-02 09:36:16 --> Final output sent to browser
DEBUG - 2018-11-02 09:36:16 --> Total execution time: 0.3837
INFO - 2018-11-02 09:36:17 --> Config Class Initialized
INFO - 2018-11-02 09:36:17 --> Hooks Class Initialized
DEBUG - 2018-11-02 09:36:17 --> UTF-8 Support Enabled
INFO - 2018-11-02 09:36:17 --> Utf8 Class Initialized
INFO - 2018-11-02 09:36:17 --> URI Class Initialized
INFO - 2018-11-02 09:36:17 --> Router Class Initialized
INFO - 2018-11-02 09:36:17 --> Output Class Initialized
INFO - 2018-11-02 09:36:17 --> Security Class Initialized
DEBUG - 2018-11-02 09:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 09:36:17 --> Input Class Initialized
INFO - 2018-11-02 09:36:17 --> Language Class Initialized
INFO - 2018-11-02 09:36:17 --> Loader Class Initialized
INFO - 2018-11-02 09:36:17 --> Helper loaded: url_helper
INFO - 2018-11-02 09:36:17 --> Helper loaded: html_helper
INFO - 2018-11-02 09:36:17 --> Helper loaded: form_helper
INFO - 2018-11-02 09:36:17 --> Helper loaded: cookie_helper
INFO - 2018-11-02 09:36:17 --> Helper loaded: date_helper
INFO - 2018-11-02 09:36:17 --> Form Validation Class Initialized
INFO - 2018-11-02 09:36:17 --> Email Class Initialized
DEBUG - 2018-11-02 09:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 09:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 09:36:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 09:36:17 --> Pagination Class Initialized
INFO - 2018-11-02 09:36:17 --> Database Driver Class Initialized
INFO - 2018-11-02 09:36:17 --> Database Driver Class Initialized
INFO - 2018-11-02 09:36:17 --> Controller Class Initialized
INFO - 2018-11-02 09:36:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-02 09:36:17 --> Final output sent to browser
DEBUG - 2018-11-02 09:36:17 --> Total execution time: 0.1118
INFO - 2018-11-02 09:37:02 --> Config Class Initialized
INFO - 2018-11-02 09:37:02 --> Hooks Class Initialized
DEBUG - 2018-11-02 09:37:02 --> UTF-8 Support Enabled
INFO - 2018-11-02 09:37:02 --> Utf8 Class Initialized
INFO - 2018-11-02 09:37:02 --> URI Class Initialized
DEBUG - 2018-11-02 09:37:02 --> No URI present. Default controller set.
INFO - 2018-11-02 09:37:02 --> Router Class Initialized
INFO - 2018-11-02 09:37:02 --> Output Class Initialized
INFO - 2018-11-02 09:37:02 --> Security Class Initialized
DEBUG - 2018-11-02 09:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 09:37:02 --> Input Class Initialized
INFO - 2018-11-02 09:37:02 --> Language Class Initialized
INFO - 2018-11-02 09:37:02 --> Loader Class Initialized
INFO - 2018-11-02 09:37:02 --> Helper loaded: url_helper
INFO - 2018-11-02 09:37:02 --> Helper loaded: html_helper
INFO - 2018-11-02 09:37:02 --> Helper loaded: form_helper
INFO - 2018-11-02 09:37:02 --> Helper loaded: cookie_helper
INFO - 2018-11-02 09:37:02 --> Helper loaded: date_helper
INFO - 2018-11-02 09:37:02 --> Form Validation Class Initialized
INFO - 2018-11-02 09:37:02 --> Email Class Initialized
DEBUG - 2018-11-02 09:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 09:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 09:37:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 09:37:02 --> Pagination Class Initialized
INFO - 2018-11-02 09:37:02 --> Database Driver Class Initialized
INFO - 2018-11-02 09:37:02 --> Database Driver Class Initialized
INFO - 2018-11-02 09:37:02 --> Controller Class Initialized
INFO - 2018-11-02 09:37:02 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-02 09:37:02 --> Final output sent to browser
DEBUG - 2018-11-02 09:37:02 --> Total execution time: 0.1477
INFO - 2018-11-02 09:37:11 --> Config Class Initialized
INFO - 2018-11-02 09:37:11 --> Hooks Class Initialized
DEBUG - 2018-11-02 09:37:11 --> UTF-8 Support Enabled
INFO - 2018-11-02 09:37:11 --> Utf8 Class Initialized
INFO - 2018-11-02 09:37:11 --> URI Class Initialized
INFO - 2018-11-02 09:37:11 --> Router Class Initialized
INFO - 2018-11-02 09:37:11 --> Output Class Initialized
INFO - 2018-11-02 09:37:11 --> Security Class Initialized
DEBUG - 2018-11-02 09:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 09:37:11 --> Input Class Initialized
INFO - 2018-11-02 09:37:11 --> Language Class Initialized
INFO - 2018-11-02 09:37:11 --> Loader Class Initialized
INFO - 2018-11-02 09:37:11 --> Helper loaded: url_helper
INFO - 2018-11-02 09:37:11 --> Helper loaded: html_helper
INFO - 2018-11-02 09:37:11 --> Helper loaded: form_helper
INFO - 2018-11-02 09:37:11 --> Helper loaded: cookie_helper
INFO - 2018-11-02 09:37:11 --> Helper loaded: date_helper
INFO - 2018-11-02 09:37:11 --> Form Validation Class Initialized
INFO - 2018-11-02 09:37:11 --> Email Class Initialized
DEBUG - 2018-11-02 09:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 09:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 09:37:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 09:37:11 --> Pagination Class Initialized
INFO - 2018-11-02 09:37:11 --> Database Driver Class Initialized
INFO - 2018-11-02 09:37:11 --> Database Driver Class Initialized
INFO - 2018-11-02 09:37:11 --> Controller Class Initialized
INFO - 2018-11-02 09:37:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-02 09:37:11 --> Final output sent to browser
DEBUG - 2018-11-02 09:37:11 --> Total execution time: 0.1462
INFO - 2018-11-02 09:37:52 --> Config Class Initialized
INFO - 2018-11-02 09:37:52 --> Hooks Class Initialized
DEBUG - 2018-11-02 09:37:52 --> UTF-8 Support Enabled
INFO - 2018-11-02 09:37:52 --> Utf8 Class Initialized
INFO - 2018-11-02 09:37:52 --> URI Class Initialized
INFO - 2018-11-02 09:37:52 --> Router Class Initialized
INFO - 2018-11-02 09:37:52 --> Output Class Initialized
INFO - 2018-11-02 09:37:52 --> Security Class Initialized
DEBUG - 2018-11-02 09:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 09:37:52 --> Input Class Initialized
INFO - 2018-11-02 09:37:52 --> Language Class Initialized
INFO - 2018-11-02 09:37:52 --> Loader Class Initialized
INFO - 2018-11-02 09:37:52 --> Helper loaded: url_helper
INFO - 2018-11-02 09:37:52 --> Helper loaded: html_helper
INFO - 2018-11-02 09:37:52 --> Helper loaded: form_helper
INFO - 2018-11-02 09:37:52 --> Helper loaded: cookie_helper
INFO - 2018-11-02 09:37:52 --> Helper loaded: date_helper
INFO - 2018-11-02 09:37:52 --> Form Validation Class Initialized
INFO - 2018-11-02 09:37:52 --> Email Class Initialized
DEBUG - 2018-11-02 09:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 09:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 09:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 09:37:52 --> Pagination Class Initialized
INFO - 2018-11-02 09:37:52 --> Database Driver Class Initialized
INFO - 2018-11-02 09:37:52 --> Database Driver Class Initialized
INFO - 2018-11-02 09:37:52 --> Controller Class Initialized
INFO - 2018-11-02 09:37:52 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-02 09:37:52 --> Final output sent to browser
DEBUG - 2018-11-02 09:37:52 --> Total execution time: 0.1372
INFO - 2018-11-02 09:38:03 --> Config Class Initialized
INFO - 2018-11-02 09:38:03 --> Hooks Class Initialized
DEBUG - 2018-11-02 09:38:03 --> UTF-8 Support Enabled
INFO - 2018-11-02 09:38:03 --> Utf8 Class Initialized
INFO - 2018-11-02 09:38:03 --> URI Class Initialized
INFO - 2018-11-02 09:38:03 --> Router Class Initialized
INFO - 2018-11-02 09:38:03 --> Output Class Initialized
INFO - 2018-11-02 09:38:03 --> Security Class Initialized
DEBUG - 2018-11-02 09:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 09:38:03 --> Input Class Initialized
INFO - 2018-11-02 09:38:03 --> Language Class Initialized
INFO - 2018-11-02 09:38:03 --> Loader Class Initialized
INFO - 2018-11-02 09:38:03 --> Helper loaded: url_helper
INFO - 2018-11-02 09:38:03 --> Helper loaded: html_helper
INFO - 2018-11-02 09:38:03 --> Helper loaded: form_helper
INFO - 2018-11-02 09:38:03 --> Helper loaded: cookie_helper
INFO - 2018-11-02 09:38:03 --> Helper loaded: date_helper
INFO - 2018-11-02 09:38:03 --> Form Validation Class Initialized
INFO - 2018-11-02 09:38:03 --> Email Class Initialized
DEBUG - 2018-11-02 09:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 09:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 09:38:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 09:38:03 --> Pagination Class Initialized
INFO - 2018-11-02 09:38:03 --> Database Driver Class Initialized
INFO - 2018-11-02 09:38:03 --> Database Driver Class Initialized
INFO - 2018-11-02 09:38:03 --> Controller Class Initialized
INFO - 2018-11-02 09:38:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-11-02 09:38:04 --> Config Class Initialized
INFO - 2018-11-02 09:38:04 --> Hooks Class Initialized
DEBUG - 2018-11-02 09:38:04 --> UTF-8 Support Enabled
INFO - 2018-11-02 09:38:04 --> Utf8 Class Initialized
INFO - 2018-11-02 09:38:04 --> URI Class Initialized
INFO - 2018-11-02 09:38:04 --> Router Class Initialized
INFO - 2018-11-02 09:38:04 --> Output Class Initialized
INFO - 2018-11-02 09:38:04 --> Security Class Initialized
DEBUG - 2018-11-02 09:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 09:38:04 --> Input Class Initialized
INFO - 2018-11-02 09:38:04 --> Language Class Initialized
INFO - 2018-11-02 09:38:04 --> Loader Class Initialized
INFO - 2018-11-02 09:38:04 --> Helper loaded: url_helper
INFO - 2018-11-02 09:38:04 --> Helper loaded: html_helper
INFO - 2018-11-02 09:38:04 --> Helper loaded: form_helper
INFO - 2018-11-02 09:38:04 --> Helper loaded: cookie_helper
INFO - 2018-11-02 09:38:04 --> Helper loaded: date_helper
INFO - 2018-11-02 09:38:04 --> Form Validation Class Initialized
INFO - 2018-11-02 09:38:04 --> Email Class Initialized
DEBUG - 2018-11-02 09:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 09:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 09:38:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 09:38:04 --> Pagination Class Initialized
INFO - 2018-11-02 09:38:04 --> Database Driver Class Initialized
INFO - 2018-11-02 09:38:04 --> Database Driver Class Initialized
INFO - 2018-11-02 09:38:04 --> Controller Class Initialized
INFO - 2018-11-02 09:38:04 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-02 09:38:04 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-11-02 09:38:04 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-02 09:38:04 --> Final output sent to browser
DEBUG - 2018-11-02 09:38:04 --> Total execution time: 0.1446
INFO - 2018-11-02 09:38:04 --> Config Class Initialized
INFO - 2018-11-02 09:38:04 --> Config Class Initialized
INFO - 2018-11-02 09:38:04 --> Hooks Class Initialized
INFO - 2018-11-02 09:38:04 --> Hooks Class Initialized
DEBUG - 2018-11-02 09:38:04 --> UTF-8 Support Enabled
DEBUG - 2018-11-02 09:38:04 --> UTF-8 Support Enabled
INFO - 2018-11-02 09:38:04 --> Utf8 Class Initialized
INFO - 2018-11-02 09:38:04 --> Utf8 Class Initialized
INFO - 2018-11-02 09:38:04 --> URI Class Initialized
INFO - 2018-11-02 09:38:04 --> URI Class Initialized
INFO - 2018-11-02 09:38:04 --> Router Class Initialized
INFO - 2018-11-02 09:38:04 --> Router Class Initialized
INFO - 2018-11-02 09:38:04 --> Output Class Initialized
INFO - 2018-11-02 09:38:04 --> Output Class Initialized
INFO - 2018-11-02 09:38:04 --> Security Class Initialized
INFO - 2018-11-02 09:38:04 --> Security Class Initialized
DEBUG - 2018-11-02 09:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-02 09:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 09:38:04 --> Input Class Initialized
INFO - 2018-11-02 09:38:04 --> Input Class Initialized
INFO - 2018-11-02 09:38:04 --> Language Class Initialized
INFO - 2018-11-02 09:38:04 --> Language Class Initialized
INFO - 2018-11-02 09:38:04 --> Loader Class Initialized
INFO - 2018-11-02 09:38:04 --> Loader Class Initialized
INFO - 2018-11-02 09:38:04 --> Helper loaded: url_helper
INFO - 2018-11-02 09:38:04 --> Helper loaded: url_helper
INFO - 2018-11-02 09:38:04 --> Helper loaded: html_helper
INFO - 2018-11-02 09:38:04 --> Helper loaded: html_helper
INFO - 2018-11-02 09:38:04 --> Helper loaded: form_helper
INFO - 2018-11-02 09:38:04 --> Helper loaded: form_helper
INFO - 2018-11-02 09:38:04 --> Helper loaded: cookie_helper
INFO - 2018-11-02 09:38:04 --> Helper loaded: cookie_helper
INFO - 2018-11-02 09:38:04 --> Helper loaded: date_helper
INFO - 2018-11-02 09:38:04 --> Helper loaded: date_helper
INFO - 2018-11-02 09:38:04 --> Form Validation Class Initialized
INFO - 2018-11-02 09:38:04 --> Form Validation Class Initialized
INFO - 2018-11-02 09:38:04 --> Email Class Initialized
INFO - 2018-11-02 09:38:04 --> Email Class Initialized
DEBUG - 2018-11-02 09:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-02 09:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 09:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 09:38:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 09:38:04 --> Pagination Class Initialized
INFO - 2018-11-02 09:38:04 --> Database Driver Class Initialized
INFO - 2018-11-02 09:38:04 --> Database Driver Class Initialized
INFO - 2018-11-02 09:38:04 --> Controller Class Initialized
INFO - 2018-11-02 09:38:04 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-02 09:38:04 --> Final output sent to browser
DEBUG - 2018-11-02 09:38:04 --> Total execution time: 0.1728
INFO - 2018-11-02 09:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 09:38:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 09:38:04 --> Pagination Class Initialized
INFO - 2018-11-02 09:38:04 --> Database Driver Class Initialized
INFO - 2018-11-02 09:38:04 --> Database Driver Class Initialized
INFO - 2018-11-02 09:38:04 --> Controller Class Initialized
INFO - 2018-11-02 09:38:04 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-02 09:38:04 --> Final output sent to browser
DEBUG - 2018-11-02 09:38:04 --> Total execution time: 0.2456
INFO - 2018-11-02 09:38:06 --> Config Class Initialized
INFO - 2018-11-02 09:38:06 --> Hooks Class Initialized
DEBUG - 2018-11-02 09:38:06 --> UTF-8 Support Enabled
INFO - 2018-11-02 09:38:06 --> Utf8 Class Initialized
INFO - 2018-11-02 09:38:06 --> URI Class Initialized
INFO - 2018-11-02 09:38:06 --> Router Class Initialized
INFO - 2018-11-02 09:38:06 --> Output Class Initialized
INFO - 2018-11-02 09:38:06 --> Security Class Initialized
DEBUG - 2018-11-02 09:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 09:38:06 --> Input Class Initialized
INFO - 2018-11-02 09:38:06 --> Language Class Initialized
INFO - 2018-11-02 09:38:06 --> Loader Class Initialized
INFO - 2018-11-02 09:38:06 --> Helper loaded: url_helper
INFO - 2018-11-02 09:38:06 --> Helper loaded: html_helper
INFO - 2018-11-02 09:38:06 --> Helper loaded: form_helper
INFO - 2018-11-02 09:38:06 --> Helper loaded: cookie_helper
INFO - 2018-11-02 09:38:06 --> Helper loaded: date_helper
INFO - 2018-11-02 09:38:06 --> Form Validation Class Initialized
INFO - 2018-11-02 09:38:06 --> Email Class Initialized
DEBUG - 2018-11-02 09:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 09:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 09:38:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 09:38:06 --> Pagination Class Initialized
INFO - 2018-11-02 09:38:06 --> Database Driver Class Initialized
INFO - 2018-11-02 09:38:06 --> Database Driver Class Initialized
INFO - 2018-11-02 09:38:07 --> Controller Class Initialized
INFO - 2018-11-02 09:38:07 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-02 09:38:07 --> Final output sent to browser
DEBUG - 2018-11-02 09:38:07 --> Total execution time: 0.1318
INFO - 2018-11-02 09:38:09 --> Config Class Initialized
INFO - 2018-11-02 09:38:09 --> Hooks Class Initialized
DEBUG - 2018-11-02 09:38:09 --> UTF-8 Support Enabled
INFO - 2018-11-02 09:38:09 --> Utf8 Class Initialized
INFO - 2018-11-02 09:38:09 --> URI Class Initialized
INFO - 2018-11-02 09:38:09 --> Router Class Initialized
INFO - 2018-11-02 09:38:09 --> Output Class Initialized
INFO - 2018-11-02 09:38:09 --> Security Class Initialized
DEBUG - 2018-11-02 09:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 09:38:09 --> Input Class Initialized
INFO - 2018-11-02 09:38:09 --> Language Class Initialized
INFO - 2018-11-02 09:38:09 --> Loader Class Initialized
INFO - 2018-11-02 09:38:09 --> Helper loaded: url_helper
INFO - 2018-11-02 09:38:09 --> Helper loaded: html_helper
INFO - 2018-11-02 09:38:09 --> Helper loaded: form_helper
INFO - 2018-11-02 09:38:09 --> Helper loaded: cookie_helper
INFO - 2018-11-02 09:38:09 --> Helper loaded: date_helper
INFO - 2018-11-02 09:38:09 --> Form Validation Class Initialized
INFO - 2018-11-02 09:38:09 --> Email Class Initialized
DEBUG - 2018-11-02 09:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 09:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 09:38:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 09:38:09 --> Pagination Class Initialized
INFO - 2018-11-02 09:38:09 --> Database Driver Class Initialized
INFO - 2018-11-02 09:38:09 --> Database Driver Class Initialized
INFO - 2018-11-02 09:38:09 --> Controller Class Initialized
INFO - 2018-11-02 09:38:09 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-02 09:38:09 --> Final output sent to browser
DEBUG - 2018-11-02 09:38:09 --> Total execution time: 0.1462
INFO - 2018-11-02 09:41:17 --> Config Class Initialized
INFO - 2018-11-02 09:41:17 --> Hooks Class Initialized
DEBUG - 2018-11-02 09:41:17 --> UTF-8 Support Enabled
INFO - 2018-11-02 09:41:17 --> Utf8 Class Initialized
INFO - 2018-11-02 09:41:17 --> URI Class Initialized
INFO - 2018-11-02 09:41:17 --> Router Class Initialized
INFO - 2018-11-02 09:41:17 --> Output Class Initialized
INFO - 2018-11-02 09:41:17 --> Security Class Initialized
DEBUG - 2018-11-02 09:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 09:41:17 --> Input Class Initialized
INFO - 2018-11-02 09:41:17 --> Language Class Initialized
INFO - 2018-11-02 09:41:17 --> Loader Class Initialized
INFO - 2018-11-02 09:41:17 --> Helper loaded: url_helper
INFO - 2018-11-02 09:41:17 --> Helper loaded: html_helper
INFO - 2018-11-02 09:41:17 --> Helper loaded: form_helper
INFO - 2018-11-02 09:41:17 --> Helper loaded: cookie_helper
INFO - 2018-11-02 09:41:17 --> Helper loaded: date_helper
INFO - 2018-11-02 09:41:17 --> Form Validation Class Initialized
INFO - 2018-11-02 09:41:17 --> Email Class Initialized
DEBUG - 2018-11-02 09:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 09:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 09:41:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 09:41:17 --> Pagination Class Initialized
INFO - 2018-11-02 09:41:17 --> Database Driver Class Initialized
INFO - 2018-11-02 09:41:17 --> Database Driver Class Initialized
INFO - 2018-11-02 09:41:17 --> Controller Class Initialized
INFO - 2018-11-02 09:41:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-02 09:41:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-11-02 09:41:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2018-11-02 09:41:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-02 09:41:17 --> Final output sent to browser
DEBUG - 2018-11-02 09:41:17 --> Total execution time: 0.2353
INFO - 2018-11-02 09:41:18 --> Config Class Initialized
INFO - 2018-11-02 09:41:18 --> Hooks Class Initialized
INFO - 2018-11-02 09:41:18 --> Config Class Initialized
INFO - 2018-11-02 09:41:18 --> Hooks Class Initialized
DEBUG - 2018-11-02 09:41:18 --> UTF-8 Support Enabled
INFO - 2018-11-02 09:41:18 --> Utf8 Class Initialized
DEBUG - 2018-11-02 09:41:18 --> UTF-8 Support Enabled
INFO - 2018-11-02 09:41:18 --> URI Class Initialized
INFO - 2018-11-02 09:41:18 --> Utf8 Class Initialized
INFO - 2018-11-02 09:41:18 --> URI Class Initialized
INFO - 2018-11-02 09:41:18 --> Router Class Initialized
INFO - 2018-11-02 09:41:18 --> Output Class Initialized
INFO - 2018-11-02 09:41:18 --> Security Class Initialized
INFO - 2018-11-02 09:41:18 --> Router Class Initialized
DEBUG - 2018-11-02 09:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 09:41:18 --> Output Class Initialized
INFO - 2018-11-02 09:41:18 --> Input Class Initialized
INFO - 2018-11-02 09:41:18 --> Language Class Initialized
INFO - 2018-11-02 09:41:18 --> Security Class Initialized
DEBUG - 2018-11-02 09:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 09:41:18 --> Loader Class Initialized
INFO - 2018-11-02 09:41:18 --> Input Class Initialized
INFO - 2018-11-02 09:41:18 --> Language Class Initialized
INFO - 2018-11-02 09:41:18 --> Helper loaded: url_helper
INFO - 2018-11-02 09:41:18 --> Helper loaded: html_helper
INFO - 2018-11-02 09:41:18 --> Loader Class Initialized
INFO - 2018-11-02 09:41:18 --> Helper loaded: form_helper
INFO - 2018-11-02 09:41:18 --> Helper loaded: url_helper
INFO - 2018-11-02 09:41:18 --> Helper loaded: cookie_helper
INFO - 2018-11-02 09:41:18 --> Helper loaded: html_helper
INFO - 2018-11-02 09:41:18 --> Helper loaded: date_helper
INFO - 2018-11-02 09:41:18 --> Helper loaded: form_helper
INFO - 2018-11-02 09:41:18 --> Form Validation Class Initialized
INFO - 2018-11-02 09:41:18 --> Helper loaded: cookie_helper
INFO - 2018-11-02 09:41:18 --> Email Class Initialized
INFO - 2018-11-02 09:41:18 --> Helper loaded: date_helper
INFO - 2018-11-02 09:41:18 --> Form Validation Class Initialized
DEBUG - 2018-11-02 09:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 09:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 09:41:18 --> Email Class Initialized
INFO - 2018-11-02 09:41:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 09:41:18 --> Pagination Class Initialized
DEBUG - 2018-11-02 09:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 09:41:18 --> Database Driver Class Initialized
INFO - 2018-11-02 09:41:18 --> Database Driver Class Initialized
INFO - 2018-11-02 09:41:18 --> Controller Class Initialized
INFO - 2018-11-02 09:41:18 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-02 09:41:18 --> Final output sent to browser
DEBUG - 2018-11-02 09:41:18 --> Total execution time: 0.1649
INFO - 2018-11-02 09:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 09:41:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 09:41:18 --> Pagination Class Initialized
INFO - 2018-11-02 09:41:18 --> Database Driver Class Initialized
INFO - 2018-11-02 09:41:18 --> Database Driver Class Initialized
INFO - 2018-11-02 09:41:18 --> Controller Class Initialized
INFO - 2018-11-02 09:41:18 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-02 09:41:18 --> Final output sent to browser
DEBUG - 2018-11-02 09:41:18 --> Total execution time: 0.2219
INFO - 2018-11-02 09:41:28 --> Config Class Initialized
INFO - 2018-11-02 09:41:28 --> Hooks Class Initialized
DEBUG - 2018-11-02 09:41:28 --> UTF-8 Support Enabled
INFO - 2018-11-02 09:41:28 --> Utf8 Class Initialized
INFO - 2018-11-02 09:41:28 --> URI Class Initialized
INFO - 2018-11-02 09:41:28 --> Router Class Initialized
INFO - 2018-11-02 09:41:28 --> Output Class Initialized
INFO - 2018-11-02 09:41:28 --> Security Class Initialized
DEBUG - 2018-11-02 09:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 09:41:28 --> Input Class Initialized
INFO - 2018-11-02 09:41:28 --> Language Class Initialized
INFO - 2018-11-02 09:41:28 --> Loader Class Initialized
INFO - 2018-11-02 09:41:28 --> Helper loaded: url_helper
INFO - 2018-11-02 09:41:28 --> Helper loaded: html_helper
INFO - 2018-11-02 09:41:28 --> Helper loaded: form_helper
INFO - 2018-11-02 09:41:28 --> Helper loaded: cookie_helper
INFO - 2018-11-02 09:41:28 --> Helper loaded: date_helper
INFO - 2018-11-02 09:41:28 --> Form Validation Class Initialized
INFO - 2018-11-02 09:41:28 --> Email Class Initialized
DEBUG - 2018-11-02 09:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 09:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 09:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 09:41:28 --> Pagination Class Initialized
INFO - 2018-11-02 09:41:28 --> Database Driver Class Initialized
INFO - 2018-11-02 09:41:28 --> Database Driver Class Initialized
INFO - 2018-11-02 09:41:28 --> Controller Class Initialized
DEBUG - 2018-11-02 09:41:28 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-02 09:41:28 --> Helper loaded: inflector_helper
INFO - 2018-11-02 09:41:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-02 09:41:28 --> Final output sent to browser
DEBUG - 2018-11-02 09:41:28 --> Total execution time: 0.2309
INFO - 2018-11-02 10:48:11 --> Config Class Initialized
INFO - 2018-11-02 10:48:11 --> Hooks Class Initialized
DEBUG - 2018-11-02 10:48:11 --> UTF-8 Support Enabled
INFO - 2018-11-02 10:48:11 --> Utf8 Class Initialized
INFO - 2018-11-02 10:48:11 --> URI Class Initialized
INFO - 2018-11-02 10:48:11 --> Router Class Initialized
INFO - 2018-11-02 10:48:11 --> Output Class Initialized
INFO - 2018-11-02 10:48:11 --> Security Class Initialized
DEBUG - 2018-11-02 10:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 10:48:11 --> Input Class Initialized
INFO - 2018-11-02 10:48:11 --> Language Class Initialized
INFO - 2018-11-02 10:48:11 --> Loader Class Initialized
INFO - 2018-11-02 10:48:11 --> Helper loaded: url_helper
INFO - 2018-11-02 10:48:11 --> Helper loaded: html_helper
INFO - 2018-11-02 10:48:11 --> Helper loaded: form_helper
INFO - 2018-11-02 10:48:11 --> Helper loaded: cookie_helper
INFO - 2018-11-02 10:48:11 --> Helper loaded: date_helper
INFO - 2018-11-02 10:48:11 --> Form Validation Class Initialized
INFO - 2018-11-02 10:48:11 --> Email Class Initialized
DEBUG - 2018-11-02 10:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 10:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 10:48:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 10:48:11 --> Pagination Class Initialized
INFO - 2018-11-02 10:48:11 --> Database Driver Class Initialized
INFO - 2018-11-02 10:48:11 --> Database Driver Class Initialized
INFO - 2018-11-02 10:48:11 --> Controller Class Initialized
INFO - 2018-11-02 10:48:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-02 10:48:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-11-02 10:48:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2018-11-02 10:48:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-02 10:48:11 --> Final output sent to browser
DEBUG - 2018-11-02 10:48:11 --> Total execution time: 0.1427
INFO - 2018-11-02 10:48:12 --> Config Class Initialized
INFO - 2018-11-02 10:48:12 --> Config Class Initialized
INFO - 2018-11-02 10:48:12 --> Hooks Class Initialized
INFO - 2018-11-02 10:48:12 --> Hooks Class Initialized
DEBUG - 2018-11-02 10:48:12 --> UTF-8 Support Enabled
DEBUG - 2018-11-02 10:48:12 --> UTF-8 Support Enabled
INFO - 2018-11-02 10:48:12 --> Utf8 Class Initialized
INFO - 2018-11-02 10:48:12 --> Utf8 Class Initialized
INFO - 2018-11-02 10:48:12 --> URI Class Initialized
INFO - 2018-11-02 10:48:12 --> URI Class Initialized
INFO - 2018-11-02 10:48:12 --> Router Class Initialized
INFO - 2018-11-02 10:48:12 --> Router Class Initialized
INFO - 2018-11-02 10:48:12 --> Output Class Initialized
INFO - 2018-11-02 10:48:12 --> Output Class Initialized
INFO - 2018-11-02 10:48:12 --> Security Class Initialized
INFO - 2018-11-02 10:48:12 --> Security Class Initialized
DEBUG - 2018-11-02 10:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-02 10:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 10:48:12 --> Input Class Initialized
INFO - 2018-11-02 10:48:12 --> Input Class Initialized
INFO - 2018-11-02 10:48:12 --> Language Class Initialized
INFO - 2018-11-02 10:48:12 --> Language Class Initialized
INFO - 2018-11-02 10:48:12 --> Loader Class Initialized
INFO - 2018-11-02 10:48:12 --> Loader Class Initialized
INFO - 2018-11-02 10:48:12 --> Helper loaded: url_helper
INFO - 2018-11-02 10:48:12 --> Helper loaded: url_helper
INFO - 2018-11-02 10:48:12 --> Helper loaded: html_helper
INFO - 2018-11-02 10:48:12 --> Helper loaded: html_helper
INFO - 2018-11-02 10:48:12 --> Helper loaded: form_helper
INFO - 2018-11-02 10:48:12 --> Helper loaded: form_helper
INFO - 2018-11-02 10:48:12 --> Helper loaded: cookie_helper
INFO - 2018-11-02 10:48:12 --> Helper loaded: cookie_helper
INFO - 2018-11-02 10:48:12 --> Helper loaded: date_helper
INFO - 2018-11-02 10:48:12 --> Helper loaded: date_helper
INFO - 2018-11-02 10:48:12 --> Form Validation Class Initialized
INFO - 2018-11-02 10:48:12 --> Form Validation Class Initialized
INFO - 2018-11-02 10:48:12 --> Email Class Initialized
INFO - 2018-11-02 10:48:12 --> Email Class Initialized
DEBUG - 2018-11-02 10:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-02 10:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 10:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 10:48:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 10:48:12 --> Pagination Class Initialized
INFO - 2018-11-02 10:48:12 --> Database Driver Class Initialized
INFO - 2018-11-02 10:48:12 --> Database Driver Class Initialized
INFO - 2018-11-02 10:48:12 --> Controller Class Initialized
INFO - 2018-11-02 10:48:12 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-02 10:48:12 --> Final output sent to browser
DEBUG - 2018-11-02 10:48:12 --> Total execution time: 0.1447
INFO - 2018-11-02 10:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 10:48:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 10:48:12 --> Pagination Class Initialized
INFO - 2018-11-02 10:48:12 --> Database Driver Class Initialized
INFO - 2018-11-02 10:48:12 --> Database Driver Class Initialized
INFO - 2018-11-02 10:48:12 --> Controller Class Initialized
INFO - 2018-11-02 10:48:12 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-02 10:48:12 --> Final output sent to browser
DEBUG - 2018-11-02 10:48:12 --> Total execution time: 0.1975
INFO - 2018-11-02 10:48:14 --> Config Class Initialized
INFO - 2018-11-02 10:48:14 --> Hooks Class Initialized
DEBUG - 2018-11-02 10:48:14 --> UTF-8 Support Enabled
INFO - 2018-11-02 10:48:14 --> Utf8 Class Initialized
INFO - 2018-11-02 10:48:14 --> URI Class Initialized
INFO - 2018-11-02 10:48:14 --> Router Class Initialized
INFO - 2018-11-02 10:48:14 --> Output Class Initialized
INFO - 2018-11-02 10:48:14 --> Security Class Initialized
DEBUG - 2018-11-02 10:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 10:48:14 --> Input Class Initialized
INFO - 2018-11-02 10:48:14 --> Language Class Initialized
INFO - 2018-11-02 10:48:14 --> Loader Class Initialized
INFO - 2018-11-02 10:48:14 --> Helper loaded: url_helper
INFO - 2018-11-02 10:48:14 --> Helper loaded: html_helper
INFO - 2018-11-02 10:48:14 --> Helper loaded: form_helper
INFO - 2018-11-02 10:48:14 --> Helper loaded: cookie_helper
INFO - 2018-11-02 10:48:14 --> Helper loaded: date_helper
INFO - 2018-11-02 10:48:14 --> Form Validation Class Initialized
INFO - 2018-11-02 10:48:14 --> Email Class Initialized
DEBUG - 2018-11-02 10:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 10:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 10:48:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 10:48:14 --> Pagination Class Initialized
INFO - 2018-11-02 10:48:14 --> Database Driver Class Initialized
INFO - 2018-11-02 10:48:14 --> Database Driver Class Initialized
INFO - 2018-11-02 10:48:14 --> Controller Class Initialized
INFO - 2018-11-02 10:48:14 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-02 10:48:14 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-11-02 10:48:14 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2018-11-02 10:48:14 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-02 10:48:14 --> Final output sent to browser
DEBUG - 2018-11-02 10:48:14 --> Total execution time: 0.1325
INFO - 2018-11-02 10:48:14 --> Config Class Initialized
INFO - 2018-11-02 10:48:14 --> Config Class Initialized
INFO - 2018-11-02 10:48:14 --> Hooks Class Initialized
INFO - 2018-11-02 10:48:14 --> Hooks Class Initialized
DEBUG - 2018-11-02 10:48:14 --> UTF-8 Support Enabled
INFO - 2018-11-02 10:48:14 --> Utf8 Class Initialized
DEBUG - 2018-11-02 10:48:14 --> UTF-8 Support Enabled
INFO - 2018-11-02 10:48:14 --> Utf8 Class Initialized
INFO - 2018-11-02 10:48:14 --> URI Class Initialized
INFO - 2018-11-02 10:48:14 --> URI Class Initialized
INFO - 2018-11-02 10:48:14 --> Router Class Initialized
INFO - 2018-11-02 10:48:14 --> Router Class Initialized
INFO - 2018-11-02 10:48:14 --> Output Class Initialized
INFO - 2018-11-02 10:48:14 --> Output Class Initialized
INFO - 2018-11-02 10:48:14 --> Security Class Initialized
INFO - 2018-11-02 10:48:14 --> Security Class Initialized
DEBUG - 2018-11-02 10:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 10:48:14 --> Input Class Initialized
DEBUG - 2018-11-02 10:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 10:48:15 --> Language Class Initialized
INFO - 2018-11-02 10:48:15 --> Input Class Initialized
INFO - 2018-11-02 10:48:15 --> Language Class Initialized
INFO - 2018-11-02 10:48:15 --> Loader Class Initialized
INFO - 2018-11-02 10:48:15 --> Loader Class Initialized
INFO - 2018-11-02 10:48:15 --> Helper loaded: url_helper
INFO - 2018-11-02 10:48:15 --> Helper loaded: url_helper
INFO - 2018-11-02 10:48:15 --> Helper loaded: html_helper
INFO - 2018-11-02 10:48:15 --> Helper loaded: html_helper
INFO - 2018-11-02 10:48:15 --> Helper loaded: form_helper
INFO - 2018-11-02 10:48:15 --> Helper loaded: form_helper
INFO - 2018-11-02 10:48:15 --> Helper loaded: cookie_helper
INFO - 2018-11-02 10:48:15 --> Helper loaded: cookie_helper
INFO - 2018-11-02 10:48:15 --> Helper loaded: date_helper
INFO - 2018-11-02 10:48:15 --> Helper loaded: date_helper
INFO - 2018-11-02 10:48:15 --> Form Validation Class Initialized
INFO - 2018-11-02 10:48:15 --> Form Validation Class Initialized
INFO - 2018-11-02 10:48:15 --> Email Class Initialized
INFO - 2018-11-02 10:48:15 --> Email Class Initialized
DEBUG - 2018-11-02 10:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-02 10:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 10:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 10:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 10:48:15 --> Pagination Class Initialized
INFO - 2018-11-02 10:48:15 --> Database Driver Class Initialized
INFO - 2018-11-02 10:48:15 --> Database Driver Class Initialized
INFO - 2018-11-02 10:48:15 --> Controller Class Initialized
INFO - 2018-11-02 10:48:15 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-02 10:48:15 --> Final output sent to browser
DEBUG - 2018-11-02 10:48:15 --> Total execution time: 0.1723
INFO - 2018-11-02 10:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 10:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 10:48:15 --> Pagination Class Initialized
INFO - 2018-11-02 10:48:15 --> Database Driver Class Initialized
INFO - 2018-11-02 10:48:15 --> Database Driver Class Initialized
INFO - 2018-11-02 10:48:15 --> Controller Class Initialized
INFO - 2018-11-02 10:48:15 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-02 10:48:15 --> Final output sent to browser
DEBUG - 2018-11-02 10:48:15 --> Total execution time: 0.2165
INFO - 2018-11-02 10:48:49 --> Config Class Initialized
INFO - 2018-11-02 10:48:49 --> Hooks Class Initialized
DEBUG - 2018-11-02 10:48:49 --> UTF-8 Support Enabled
INFO - 2018-11-02 10:48:49 --> Utf8 Class Initialized
INFO - 2018-11-02 10:48:49 --> URI Class Initialized
INFO - 2018-11-02 10:48:49 --> Router Class Initialized
INFO - 2018-11-02 10:48:49 --> Output Class Initialized
INFO - 2018-11-02 10:48:49 --> Security Class Initialized
DEBUG - 2018-11-02 10:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 10:48:49 --> Input Class Initialized
INFO - 2018-11-02 10:48:49 --> Language Class Initialized
INFO - 2018-11-02 10:48:49 --> Loader Class Initialized
INFO - 2018-11-02 10:48:49 --> Helper loaded: url_helper
INFO - 2018-11-02 10:48:49 --> Helper loaded: html_helper
INFO - 2018-11-02 10:48:49 --> Helper loaded: form_helper
INFO - 2018-11-02 10:48:49 --> Helper loaded: cookie_helper
INFO - 2018-11-02 10:48:49 --> Helper loaded: date_helper
INFO - 2018-11-02 10:48:49 --> Form Validation Class Initialized
INFO - 2018-11-02 10:48:49 --> Email Class Initialized
DEBUG - 2018-11-02 10:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 10:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 10:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 10:48:49 --> Pagination Class Initialized
INFO - 2018-11-02 10:48:49 --> Database Driver Class Initialized
INFO - 2018-11-02 10:48:49 --> Database Driver Class Initialized
INFO - 2018-11-02 10:48:49 --> Controller Class Initialized
DEBUG - 2018-11-02 10:48:49 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-02 10:48:49 --> Helper loaded: inflector_helper
INFO - 2018-11-02 10:48:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-02 10:48:49 --> Final output sent to browser
DEBUG - 2018-11-02 10:48:49 --> Total execution time: 0.1013
INFO - 2018-11-02 10:48:54 --> Config Class Initialized
INFO - 2018-11-02 10:48:54 --> Hooks Class Initialized
DEBUG - 2018-11-02 10:48:54 --> UTF-8 Support Enabled
INFO - 2018-11-02 10:48:54 --> Utf8 Class Initialized
INFO - 2018-11-02 10:48:54 --> URI Class Initialized
INFO - 2018-11-02 10:48:54 --> Router Class Initialized
INFO - 2018-11-02 10:48:54 --> Output Class Initialized
INFO - 2018-11-02 10:48:54 --> Security Class Initialized
DEBUG - 2018-11-02 10:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 10:48:54 --> Input Class Initialized
INFO - 2018-11-02 10:48:54 --> Language Class Initialized
INFO - 2018-11-02 10:48:54 --> Loader Class Initialized
INFO - 2018-11-02 10:48:54 --> Helper loaded: url_helper
INFO - 2018-11-02 10:48:54 --> Helper loaded: html_helper
INFO - 2018-11-02 10:48:54 --> Helper loaded: form_helper
INFO - 2018-11-02 10:48:54 --> Helper loaded: cookie_helper
INFO - 2018-11-02 10:48:54 --> Helper loaded: date_helper
INFO - 2018-11-02 10:48:54 --> Form Validation Class Initialized
INFO - 2018-11-02 10:48:54 --> Email Class Initialized
DEBUG - 2018-11-02 10:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 10:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 10:48:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 10:48:54 --> Pagination Class Initialized
INFO - 2018-11-02 10:48:54 --> Database Driver Class Initialized
INFO - 2018-11-02 10:48:54 --> Database Driver Class Initialized
INFO - 2018-11-02 10:48:54 --> Controller Class Initialized
DEBUG - 2018-11-02 10:48:54 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-02 10:48:54 --> Helper loaded: inflector_helper
INFO - 2018-11-02 10:48:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-02 10:48:54 --> Final output sent to browser
DEBUG - 2018-11-02 10:48:54 --> Total execution time: 0.1889
INFO - 2018-11-02 14:01:46 --> Config Class Initialized
INFO - 2018-11-02 14:01:46 --> Hooks Class Initialized
DEBUG - 2018-11-02 14:01:46 --> UTF-8 Support Enabled
INFO - 2018-11-02 14:01:46 --> Utf8 Class Initialized
INFO - 2018-11-02 14:01:46 --> URI Class Initialized
INFO - 2018-11-02 14:01:46 --> Router Class Initialized
INFO - 2018-11-02 14:01:46 --> Output Class Initialized
INFO - 2018-11-02 14:01:46 --> Security Class Initialized
DEBUG - 2018-11-02 14:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-02 14:01:46 --> Input Class Initialized
INFO - 2018-11-02 14:01:46 --> Language Class Initialized
INFO - 2018-11-02 14:01:46 --> Loader Class Initialized
INFO - 2018-11-02 14:01:46 --> Helper loaded: url_helper
INFO - 2018-11-02 14:01:46 --> Helper loaded: html_helper
INFO - 2018-11-02 14:01:46 --> Helper loaded: form_helper
INFO - 2018-11-02 14:01:46 --> Helper loaded: cookie_helper
INFO - 2018-11-02 14:01:46 --> Helper loaded: date_helper
INFO - 2018-11-02 14:01:46 --> Form Validation Class Initialized
INFO - 2018-11-02 14:01:46 --> Email Class Initialized
DEBUG - 2018-11-02 14:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-02 14:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-02 14:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-02 14:01:46 --> Pagination Class Initialized
INFO - 2018-11-02 14:01:46 --> Database Driver Class Initialized
INFO - 2018-11-02 14:01:46 --> Database Driver Class Initialized
INFO - 2018-11-02 14:01:46 --> Controller Class Initialized
