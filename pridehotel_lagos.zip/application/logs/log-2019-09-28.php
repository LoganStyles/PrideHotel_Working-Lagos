<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-28 06:19:17 --> Config Class Initialized
INFO - 2019-09-28 06:19:17 --> Hooks Class Initialized
DEBUG - 2019-09-28 06:19:17 --> UTF-8 Support Enabled
INFO - 2019-09-28 06:19:17 --> Utf8 Class Initialized
INFO - 2019-09-28 06:19:17 --> URI Class Initialized
INFO - 2019-09-28 06:19:17 --> Router Class Initialized
INFO - 2019-09-28 06:19:17 --> Output Class Initialized
INFO - 2019-09-28 06:19:17 --> Security Class Initialized
DEBUG - 2019-09-28 06:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-28 06:19:17 --> Input Class Initialized
INFO - 2019-09-28 06:19:17 --> Language Class Initialized
INFO - 2019-09-28 06:19:17 --> Loader Class Initialized
INFO - 2019-09-28 06:19:17 --> Helper loaded: url_helper
INFO - 2019-09-28 06:19:17 --> Helper loaded: html_helper
INFO - 2019-09-28 06:19:17 --> Helper loaded: form_helper
INFO - 2019-09-28 06:19:17 --> Helper loaded: cookie_helper
INFO - 2019-09-28 06:19:17 --> Helper loaded: date_helper
INFO - 2019-09-28 06:19:17 --> Form Validation Class Initialized
INFO - 2019-09-28 06:19:17 --> Email Class Initialized
DEBUG - 2019-09-28 06:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-28 06:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-28 06:19:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-28 06:19:18 --> Pagination Class Initialized
INFO - 2019-09-28 06:19:18 --> Database Driver Class Initialized
INFO - 2019-09-28 06:19:18 --> Database Driver Class Initialized
INFO - 2019-09-28 06:19:18 --> Controller Class Initialized
INFO - 2019-09-28 06:19:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-28 06:19:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-28 06:19:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-28 06:19:18 --> Final output sent to browser
DEBUG - 2019-09-28 06:19:18 --> Total execution time: 1.7861
INFO - 2019-09-28 06:19:20 --> Config Class Initialized
INFO - 2019-09-28 06:19:20 --> Hooks Class Initialized
DEBUG - 2019-09-28 06:19:20 --> UTF-8 Support Enabled
INFO - 2019-09-28 06:19:20 --> Utf8 Class Initialized
INFO - 2019-09-28 06:19:20 --> URI Class Initialized
INFO - 2019-09-28 06:19:20 --> Router Class Initialized
INFO - 2019-09-28 06:19:20 --> Output Class Initialized
INFO - 2019-09-28 06:19:20 --> Security Class Initialized
DEBUG - 2019-09-28 06:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-28 06:19:20 --> Input Class Initialized
INFO - 2019-09-28 06:19:20 --> Language Class Initialized
INFO - 2019-09-28 06:19:20 --> Loader Class Initialized
INFO - 2019-09-28 06:19:20 --> Helper loaded: url_helper
INFO - 2019-09-28 06:19:20 --> Helper loaded: html_helper
INFO - 2019-09-28 06:19:20 --> Helper loaded: form_helper
INFO - 2019-09-28 06:19:20 --> Helper loaded: cookie_helper
INFO - 2019-09-28 06:19:20 --> Helper loaded: date_helper
INFO - 2019-09-28 06:19:20 --> Form Validation Class Initialized
INFO - 2019-09-28 06:19:20 --> Email Class Initialized
DEBUG - 2019-09-28 06:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-28 06:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-28 06:19:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-28 06:19:20 --> Pagination Class Initialized
INFO - 2019-09-28 06:19:20 --> Database Driver Class Initialized
INFO - 2019-09-28 06:19:20 --> Database Driver Class Initialized
INFO - 2019-09-28 06:19:20 --> Controller Class Initialized
INFO - 2019-09-28 06:19:20 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-28 06:19:20 --> Final output sent to browser
DEBUG - 2019-09-28 06:19:20 --> Total execution time: 0.1698
INFO - 2019-09-28 07:44:02 --> Config Class Initialized
INFO - 2019-09-28 07:44:02 --> Hooks Class Initialized
DEBUG - 2019-09-28 07:44:02 --> UTF-8 Support Enabled
INFO - 2019-09-28 07:44:02 --> Utf8 Class Initialized
INFO - 2019-09-28 07:44:02 --> URI Class Initialized
INFO - 2019-09-28 07:44:02 --> Router Class Initialized
INFO - 2019-09-28 07:44:02 --> Output Class Initialized
INFO - 2019-09-28 07:44:02 --> Security Class Initialized
DEBUG - 2019-09-28 07:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-28 07:44:02 --> Input Class Initialized
INFO - 2019-09-28 07:44:02 --> Language Class Initialized
INFO - 2019-09-28 07:44:02 --> Loader Class Initialized
INFO - 2019-09-28 07:44:02 --> Helper loaded: url_helper
INFO - 2019-09-28 07:44:02 --> Helper loaded: html_helper
INFO - 2019-09-28 07:44:02 --> Helper loaded: form_helper
INFO - 2019-09-28 07:44:02 --> Helper loaded: cookie_helper
INFO - 2019-09-28 07:44:02 --> Helper loaded: date_helper
INFO - 2019-09-28 07:44:02 --> Form Validation Class Initialized
INFO - 2019-09-28 07:44:02 --> Email Class Initialized
DEBUG - 2019-09-28 07:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-28 07:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-28 07:44:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-28 07:44:02 --> Pagination Class Initialized
INFO - 2019-09-28 07:44:02 --> Database Driver Class Initialized
INFO - 2019-09-28 07:44:02 --> Database Driver Class Initialized
INFO - 2019-09-28 07:44:02 --> Controller Class Initialized
INFO - 2019-09-28 07:44:02 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-28 07:44:02 --> Final output sent to browser
DEBUG - 2019-09-28 07:44:02 --> Total execution time: 0.0727
INFO - 2019-09-28 07:44:11 --> Config Class Initialized
INFO - 2019-09-28 07:44:11 --> Hooks Class Initialized
DEBUG - 2019-09-28 07:44:11 --> UTF-8 Support Enabled
INFO - 2019-09-28 07:44:11 --> Utf8 Class Initialized
INFO - 2019-09-28 07:44:11 --> URI Class Initialized
INFO - 2019-09-28 07:44:11 --> Router Class Initialized
INFO - 2019-09-28 07:44:11 --> Output Class Initialized
INFO - 2019-09-28 07:44:11 --> Security Class Initialized
DEBUG - 2019-09-28 07:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-28 07:44:11 --> Input Class Initialized
INFO - 2019-09-28 07:44:11 --> Language Class Initialized
INFO - 2019-09-28 07:44:11 --> Loader Class Initialized
INFO - 2019-09-28 07:44:11 --> Helper loaded: url_helper
INFO - 2019-09-28 07:44:11 --> Helper loaded: html_helper
INFO - 2019-09-28 07:44:11 --> Helper loaded: form_helper
INFO - 2019-09-28 07:44:11 --> Helper loaded: cookie_helper
INFO - 2019-09-28 07:44:11 --> Helper loaded: date_helper
INFO - 2019-09-28 07:44:11 --> Form Validation Class Initialized
INFO - 2019-09-28 07:44:11 --> Email Class Initialized
DEBUG - 2019-09-28 07:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-28 07:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-28 07:44:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-28 07:44:11 --> Pagination Class Initialized
INFO - 2019-09-28 07:44:11 --> Database Driver Class Initialized
INFO - 2019-09-28 07:44:11 --> Database Driver Class Initialized
INFO - 2019-09-28 07:44:11 --> Controller Class Initialized
INFO - 2019-09-28 07:44:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-28 07:44:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report.php
INFO - 2019-09-28 07:44:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-28 07:44:11 --> Final output sent to browser
DEBUG - 2019-09-28 07:44:11 --> Total execution time: 0.2247
INFO - 2019-09-28 09:44:15 --> Config Class Initialized
INFO - 2019-09-28 09:44:15 --> Hooks Class Initialized
DEBUG - 2019-09-28 09:44:15 --> UTF-8 Support Enabled
INFO - 2019-09-28 09:44:15 --> Utf8 Class Initialized
INFO - 2019-09-28 09:44:15 --> URI Class Initialized
INFO - 2019-09-28 09:44:15 --> Router Class Initialized
INFO - 2019-09-28 09:44:15 --> Output Class Initialized
INFO - 2019-09-28 09:44:15 --> Security Class Initialized
DEBUG - 2019-09-28 09:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-28 09:44:15 --> Input Class Initialized
INFO - 2019-09-28 09:44:15 --> Language Class Initialized
INFO - 2019-09-28 09:44:15 --> Loader Class Initialized
INFO - 2019-09-28 09:44:15 --> Helper loaded: url_helper
INFO - 2019-09-28 09:44:15 --> Helper loaded: html_helper
INFO - 2019-09-28 09:44:15 --> Helper loaded: form_helper
INFO - 2019-09-28 09:44:15 --> Helper loaded: cookie_helper
INFO - 2019-09-28 09:44:15 --> Helper loaded: date_helper
INFO - 2019-09-28 09:44:15 --> Form Validation Class Initialized
INFO - 2019-09-28 09:44:15 --> Email Class Initialized
DEBUG - 2019-09-28 09:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-28 09:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-28 09:44:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-28 09:44:15 --> Pagination Class Initialized
INFO - 2019-09-28 09:44:15 --> Database Driver Class Initialized
INFO - 2019-09-28 09:44:15 --> Database Driver Class Initialized
INFO - 2019-09-28 09:44:15 --> Controller Class Initialized
INFO - 2019-09-28 09:44:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-28 09:44:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-28 09:44:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-28 09:44:15 --> Final output sent to browser
DEBUG - 2019-09-28 09:44:15 --> Total execution time: 0.0857
INFO - 2019-09-28 09:44:15 --> Config Class Initialized
INFO - 2019-09-28 09:44:15 --> Hooks Class Initialized
DEBUG - 2019-09-28 09:44:15 --> UTF-8 Support Enabled
INFO - 2019-09-28 09:44:15 --> Utf8 Class Initialized
INFO - 2019-09-28 09:44:15 --> URI Class Initialized
INFO - 2019-09-28 09:44:15 --> Router Class Initialized
INFO - 2019-09-28 09:44:15 --> Output Class Initialized
INFO - 2019-09-28 09:44:15 --> Security Class Initialized
DEBUG - 2019-09-28 09:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-28 09:44:15 --> Input Class Initialized
INFO - 2019-09-28 09:44:15 --> Language Class Initialized
INFO - 2019-09-28 09:44:15 --> Loader Class Initialized
INFO - 2019-09-28 09:44:15 --> Helper loaded: url_helper
INFO - 2019-09-28 09:44:15 --> Helper loaded: html_helper
INFO - 2019-09-28 09:44:15 --> Helper loaded: form_helper
INFO - 2019-09-28 09:44:15 --> Helper loaded: cookie_helper
INFO - 2019-09-28 09:44:15 --> Helper loaded: date_helper
INFO - 2019-09-28 09:44:15 --> Form Validation Class Initialized
INFO - 2019-09-28 09:44:15 --> Email Class Initialized
DEBUG - 2019-09-28 09:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-28 09:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-28 09:44:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-28 09:44:15 --> Pagination Class Initialized
INFO - 2019-09-28 09:44:15 --> Database Driver Class Initialized
INFO - 2019-09-28 09:44:15 --> Database Driver Class Initialized
INFO - 2019-09-28 09:44:15 --> Controller Class Initialized
INFO - 2019-09-28 09:44:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-28 09:44:15 --> Final output sent to browser
DEBUG - 2019-09-28 09:44:15 --> Total execution time: 0.0604
INFO - 2019-09-28 09:44:25 --> Config Class Initialized
INFO - 2019-09-28 09:44:25 --> Hooks Class Initialized
DEBUG - 2019-09-28 09:44:25 --> UTF-8 Support Enabled
INFO - 2019-09-28 09:44:25 --> Utf8 Class Initialized
INFO - 2019-09-28 09:44:25 --> URI Class Initialized
INFO - 2019-09-28 09:44:25 --> Router Class Initialized
INFO - 2019-09-28 09:44:25 --> Output Class Initialized
INFO - 2019-09-28 09:44:25 --> Security Class Initialized
DEBUG - 2019-09-28 09:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-28 09:44:25 --> Input Class Initialized
INFO - 2019-09-28 09:44:25 --> Language Class Initialized
INFO - 2019-09-28 09:44:25 --> Loader Class Initialized
INFO - 2019-09-28 09:44:25 --> Helper loaded: url_helper
INFO - 2019-09-28 09:44:25 --> Helper loaded: html_helper
INFO - 2019-09-28 09:44:25 --> Helper loaded: form_helper
INFO - 2019-09-28 09:44:25 --> Helper loaded: cookie_helper
INFO - 2019-09-28 09:44:25 --> Helper loaded: date_helper
INFO - 2019-09-28 09:44:25 --> Form Validation Class Initialized
INFO - 2019-09-28 09:44:25 --> Email Class Initialized
DEBUG - 2019-09-28 09:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-28 09:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-28 09:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-28 09:44:25 --> Pagination Class Initialized
INFO - 2019-09-28 09:44:25 --> Database Driver Class Initialized
INFO - 2019-09-28 09:44:25 --> Database Driver Class Initialized
INFO - 2019-09-28 09:44:25 --> Controller Class Initialized
INFO - 2019-09-28 09:44:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-28 09:44:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report_sales.php
INFO - 2019-09-28 09:44:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-28 09:44:25 --> Final output sent to browser
DEBUG - 2019-09-28 09:44:25 --> Total execution time: 0.0667
INFO - 2019-09-28 12:15:08 --> Config Class Initialized
INFO - 2019-09-28 12:15:08 --> Hooks Class Initialized
DEBUG - 2019-09-28 12:15:08 --> UTF-8 Support Enabled
INFO - 2019-09-28 12:15:08 --> Utf8 Class Initialized
INFO - 2019-09-28 12:15:08 --> URI Class Initialized
INFO - 2019-09-28 12:15:08 --> Router Class Initialized
INFO - 2019-09-28 12:15:08 --> Output Class Initialized
INFO - 2019-09-28 12:15:08 --> Security Class Initialized
DEBUG - 2019-09-28 12:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-28 12:15:08 --> Input Class Initialized
INFO - 2019-09-28 12:15:08 --> Language Class Initialized
INFO - 2019-09-28 12:15:08 --> Loader Class Initialized
INFO - 2019-09-28 12:15:08 --> Helper loaded: url_helper
INFO - 2019-09-28 12:15:08 --> Helper loaded: html_helper
INFO - 2019-09-28 12:15:08 --> Helper loaded: form_helper
INFO - 2019-09-28 12:15:08 --> Helper loaded: cookie_helper
INFO - 2019-09-28 12:15:08 --> Helper loaded: date_helper
INFO - 2019-09-28 12:15:08 --> Form Validation Class Initialized
INFO - 2019-09-28 12:15:08 --> Email Class Initialized
DEBUG - 2019-09-28 12:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-28 12:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-28 12:15:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-28 12:15:08 --> Pagination Class Initialized
INFO - 2019-09-28 12:15:08 --> Database Driver Class Initialized
INFO - 2019-09-28 12:15:08 --> Database Driver Class Initialized
INFO - 2019-09-28 12:15:08 --> Controller Class Initialized
INFO - 2019-09-28 12:15:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-28 12:15:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-28 12:15:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-28 12:15:08 --> Final output sent to browser
DEBUG - 2019-09-28 12:15:08 --> Total execution time: 0.0808
INFO - 2019-09-28 12:15:08 --> Config Class Initialized
INFO - 2019-09-28 12:15:08 --> Hooks Class Initialized
DEBUG - 2019-09-28 12:15:08 --> UTF-8 Support Enabled
INFO - 2019-09-28 12:15:08 --> Utf8 Class Initialized
INFO - 2019-09-28 12:15:08 --> URI Class Initialized
INFO - 2019-09-28 12:15:08 --> Router Class Initialized
INFO - 2019-09-28 12:15:08 --> Output Class Initialized
INFO - 2019-09-28 12:15:08 --> Security Class Initialized
DEBUG - 2019-09-28 12:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-28 12:15:08 --> Input Class Initialized
INFO - 2019-09-28 12:15:08 --> Language Class Initialized
INFO - 2019-09-28 12:15:08 --> Loader Class Initialized
INFO - 2019-09-28 12:15:08 --> Helper loaded: url_helper
INFO - 2019-09-28 12:15:08 --> Helper loaded: html_helper
INFO - 2019-09-28 12:15:08 --> Helper loaded: form_helper
INFO - 2019-09-28 12:15:08 --> Helper loaded: cookie_helper
INFO - 2019-09-28 12:15:08 --> Helper loaded: date_helper
INFO - 2019-09-28 12:15:08 --> Form Validation Class Initialized
INFO - 2019-09-28 12:15:08 --> Email Class Initialized
DEBUG - 2019-09-28 12:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-28 12:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-28 12:15:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-28 12:15:08 --> Pagination Class Initialized
INFO - 2019-09-28 12:15:08 --> Database Driver Class Initialized
INFO - 2019-09-28 12:15:08 --> Database Driver Class Initialized
INFO - 2019-09-28 12:15:08 --> Controller Class Initialized
INFO - 2019-09-28 12:15:08 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-28 12:15:08 --> Final output sent to browser
DEBUG - 2019-09-28 12:15:08 --> Total execution time: 0.0664
INFO - 2019-09-28 12:15:16 --> Config Class Initialized
INFO - 2019-09-28 12:15:16 --> Hooks Class Initialized
DEBUG - 2019-09-28 12:15:16 --> UTF-8 Support Enabled
INFO - 2019-09-28 12:15:16 --> Utf8 Class Initialized
INFO - 2019-09-28 12:15:16 --> URI Class Initialized
INFO - 2019-09-28 12:15:16 --> Router Class Initialized
INFO - 2019-09-28 12:15:16 --> Output Class Initialized
INFO - 2019-09-28 12:15:16 --> Security Class Initialized
DEBUG - 2019-09-28 12:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-28 12:15:16 --> Input Class Initialized
INFO - 2019-09-28 12:15:16 --> Language Class Initialized
INFO - 2019-09-28 12:15:16 --> Loader Class Initialized
INFO - 2019-09-28 12:15:16 --> Helper loaded: url_helper
INFO - 2019-09-28 12:15:16 --> Helper loaded: html_helper
INFO - 2019-09-28 12:15:16 --> Helper loaded: form_helper
INFO - 2019-09-28 12:15:16 --> Helper loaded: cookie_helper
INFO - 2019-09-28 12:15:16 --> Helper loaded: date_helper
INFO - 2019-09-28 12:15:16 --> Form Validation Class Initialized
INFO - 2019-09-28 12:15:16 --> Email Class Initialized
DEBUG - 2019-09-28 12:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-28 12:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-28 12:15:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-28 12:15:16 --> Pagination Class Initialized
INFO - 2019-09-28 12:15:16 --> Database Driver Class Initialized
INFO - 2019-09-28 12:15:16 --> Database Driver Class Initialized
INFO - 2019-09-28 12:15:16 --> Controller Class Initialized
INFO - 2019-09-28 12:15:16 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-28 12:15:16 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report_sales.php
INFO - 2019-09-28 12:15:16 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-28 12:15:16 --> Final output sent to browser
DEBUG - 2019-09-28 12:15:16 --> Total execution time: 0.0646
INFO - 2019-09-28 12:36:18 --> Config Class Initialized
INFO - 2019-09-28 12:36:18 --> Hooks Class Initialized
DEBUG - 2019-09-28 12:36:18 --> UTF-8 Support Enabled
INFO - 2019-09-28 12:36:18 --> Utf8 Class Initialized
INFO - 2019-09-28 12:36:18 --> URI Class Initialized
INFO - 2019-09-28 12:36:18 --> Router Class Initialized
INFO - 2019-09-28 12:36:18 --> Output Class Initialized
INFO - 2019-09-28 12:36:18 --> Security Class Initialized
DEBUG - 2019-09-28 12:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-28 12:36:18 --> Input Class Initialized
INFO - 2019-09-28 12:36:18 --> Language Class Initialized
INFO - 2019-09-28 12:36:18 --> Loader Class Initialized
INFO - 2019-09-28 12:36:18 --> Helper loaded: url_helper
INFO - 2019-09-28 12:36:18 --> Helper loaded: html_helper
INFO - 2019-09-28 12:36:18 --> Helper loaded: form_helper
INFO - 2019-09-28 12:36:18 --> Helper loaded: cookie_helper
INFO - 2019-09-28 12:36:18 --> Helper loaded: date_helper
INFO - 2019-09-28 12:36:18 --> Form Validation Class Initialized
INFO - 2019-09-28 12:36:18 --> Email Class Initialized
DEBUG - 2019-09-28 12:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-28 12:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-28 12:36:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-28 12:36:18 --> Pagination Class Initialized
INFO - 2019-09-28 12:36:18 --> Database Driver Class Initialized
INFO - 2019-09-28 12:36:18 --> Database Driver Class Initialized
INFO - 2019-09-28 12:36:18 --> Controller Class Initialized
INFO - 2019-09-28 12:36:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-28 12:36:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-28 12:36:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-28 12:36:18 --> Final output sent to browser
DEBUG - 2019-09-28 12:36:18 --> Total execution time: 0.0669
INFO - 2019-09-28 12:36:18 --> Config Class Initialized
INFO - 2019-09-28 12:36:18 --> Hooks Class Initialized
DEBUG - 2019-09-28 12:36:18 --> UTF-8 Support Enabled
INFO - 2019-09-28 12:36:18 --> Utf8 Class Initialized
INFO - 2019-09-28 12:36:18 --> URI Class Initialized
INFO - 2019-09-28 12:36:18 --> Router Class Initialized
INFO - 2019-09-28 12:36:18 --> Output Class Initialized
INFO - 2019-09-28 12:36:18 --> Security Class Initialized
DEBUG - 2019-09-28 12:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-28 12:36:18 --> Input Class Initialized
INFO - 2019-09-28 12:36:18 --> Language Class Initialized
INFO - 2019-09-28 12:36:18 --> Loader Class Initialized
INFO - 2019-09-28 12:36:18 --> Helper loaded: url_helper
INFO - 2019-09-28 12:36:18 --> Helper loaded: html_helper
INFO - 2019-09-28 12:36:18 --> Helper loaded: form_helper
INFO - 2019-09-28 12:36:18 --> Helper loaded: cookie_helper
INFO - 2019-09-28 12:36:18 --> Helper loaded: date_helper
INFO - 2019-09-28 12:36:18 --> Form Validation Class Initialized
INFO - 2019-09-28 12:36:18 --> Email Class Initialized
DEBUG - 2019-09-28 12:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-28 12:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-28 12:36:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-28 12:36:18 --> Pagination Class Initialized
INFO - 2019-09-28 12:36:18 --> Database Driver Class Initialized
INFO - 2019-09-28 12:36:18 --> Database Driver Class Initialized
INFO - 2019-09-28 12:36:18 --> Controller Class Initialized
INFO - 2019-09-28 12:36:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-28 12:36:18 --> Final output sent to browser
DEBUG - 2019-09-28 12:36:18 --> Total execution time: 0.0641
INFO - 2019-09-28 12:36:24 --> Config Class Initialized
INFO - 2019-09-28 12:36:24 --> Hooks Class Initialized
DEBUG - 2019-09-28 12:36:24 --> UTF-8 Support Enabled
INFO - 2019-09-28 12:36:24 --> Utf8 Class Initialized
INFO - 2019-09-28 12:36:24 --> URI Class Initialized
INFO - 2019-09-28 12:36:24 --> Router Class Initialized
INFO - 2019-09-28 12:36:24 --> Output Class Initialized
INFO - 2019-09-28 12:36:24 --> Security Class Initialized
DEBUG - 2019-09-28 12:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-28 12:36:24 --> Input Class Initialized
INFO - 2019-09-28 12:36:24 --> Language Class Initialized
INFO - 2019-09-28 12:36:24 --> Loader Class Initialized
INFO - 2019-09-28 12:36:24 --> Helper loaded: url_helper
INFO - 2019-09-28 12:36:24 --> Helper loaded: html_helper
INFO - 2019-09-28 12:36:24 --> Helper loaded: form_helper
INFO - 2019-09-28 12:36:24 --> Helper loaded: cookie_helper
INFO - 2019-09-28 12:36:24 --> Helper loaded: date_helper
INFO - 2019-09-28 12:36:24 --> Form Validation Class Initialized
INFO - 2019-09-28 12:36:24 --> Email Class Initialized
DEBUG - 2019-09-28 12:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-28 12:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-28 12:36:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-28 12:36:24 --> Pagination Class Initialized
INFO - 2019-09-28 12:36:24 --> Database Driver Class Initialized
INFO - 2019-09-28 12:36:24 --> Database Driver Class Initialized
INFO - 2019-09-28 12:36:24 --> Controller Class Initialized
INFO - 2019-09-28 12:36:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-28 12:36:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report_cashier.php
INFO - 2019-09-28 12:36:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-28 12:36:25 --> Final output sent to browser
DEBUG - 2019-09-28 12:36:25 --> Total execution time: 0.1048
INFO - 2019-09-28 12:45:30 --> Config Class Initialized
INFO - 2019-09-28 12:45:30 --> Hooks Class Initialized
DEBUG - 2019-09-28 12:45:30 --> UTF-8 Support Enabled
INFO - 2019-09-28 12:45:30 --> Utf8 Class Initialized
INFO - 2019-09-28 12:45:30 --> URI Class Initialized
INFO - 2019-09-28 12:45:30 --> Router Class Initialized
INFO - 2019-09-28 12:45:30 --> Output Class Initialized
INFO - 2019-09-28 12:45:30 --> Security Class Initialized
DEBUG - 2019-09-28 12:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-28 12:45:30 --> Input Class Initialized
INFO - 2019-09-28 12:45:30 --> Language Class Initialized
INFO - 2019-09-28 12:45:30 --> Loader Class Initialized
INFO - 2019-09-28 12:45:30 --> Helper loaded: url_helper
INFO - 2019-09-28 12:45:30 --> Helper loaded: html_helper
INFO - 2019-09-28 12:45:30 --> Helper loaded: form_helper
INFO - 2019-09-28 12:45:30 --> Helper loaded: cookie_helper
INFO - 2019-09-28 12:45:30 --> Helper loaded: date_helper
INFO - 2019-09-28 12:45:30 --> Form Validation Class Initialized
INFO - 2019-09-28 12:45:30 --> Email Class Initialized
DEBUG - 2019-09-28 12:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-28 12:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-28 12:45:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-28 12:45:30 --> Pagination Class Initialized
INFO - 2019-09-28 12:45:30 --> Database Driver Class Initialized
INFO - 2019-09-28 12:45:30 --> Database Driver Class Initialized
INFO - 2019-09-28 12:45:30 --> Controller Class Initialized
INFO - 2019-09-28 12:45:30 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-28 12:45:30 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-28 12:45:30 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-28 12:45:30 --> Final output sent to browser
DEBUG - 2019-09-28 12:45:30 --> Total execution time: 0.0593
INFO - 2019-09-28 12:45:30 --> Config Class Initialized
INFO - 2019-09-28 12:45:30 --> Hooks Class Initialized
DEBUG - 2019-09-28 12:45:30 --> UTF-8 Support Enabled
INFO - 2019-09-28 12:45:30 --> Utf8 Class Initialized
INFO - 2019-09-28 12:45:30 --> URI Class Initialized
INFO - 2019-09-28 12:45:30 --> Router Class Initialized
INFO - 2019-09-28 12:45:30 --> Output Class Initialized
INFO - 2019-09-28 12:45:30 --> Security Class Initialized
DEBUG - 2019-09-28 12:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-28 12:45:30 --> Input Class Initialized
INFO - 2019-09-28 12:45:30 --> Language Class Initialized
INFO - 2019-09-28 12:45:30 --> Loader Class Initialized
INFO - 2019-09-28 12:45:30 --> Helper loaded: url_helper
INFO - 2019-09-28 12:45:30 --> Helper loaded: html_helper
INFO - 2019-09-28 12:45:30 --> Helper loaded: form_helper
INFO - 2019-09-28 12:45:30 --> Helper loaded: cookie_helper
INFO - 2019-09-28 12:45:30 --> Helper loaded: date_helper
INFO - 2019-09-28 12:45:30 --> Form Validation Class Initialized
INFO - 2019-09-28 12:45:30 --> Email Class Initialized
DEBUG - 2019-09-28 12:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-28 12:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-28 12:45:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-28 12:45:30 --> Pagination Class Initialized
INFO - 2019-09-28 12:45:30 --> Database Driver Class Initialized
INFO - 2019-09-28 12:45:30 --> Database Driver Class Initialized
INFO - 2019-09-28 12:45:30 --> Controller Class Initialized
INFO - 2019-09-28 12:45:30 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-28 12:45:30 --> Final output sent to browser
DEBUG - 2019-09-28 12:45:30 --> Total execution time: 0.0609
INFO - 2019-09-28 12:57:43 --> Config Class Initialized
INFO - 2019-09-28 12:57:43 --> Hooks Class Initialized
DEBUG - 2019-09-28 12:57:43 --> UTF-8 Support Enabled
INFO - 2019-09-28 12:57:43 --> Utf8 Class Initialized
INFO - 2019-09-28 12:57:43 --> URI Class Initialized
INFO - 2019-09-28 12:57:43 --> Router Class Initialized
INFO - 2019-09-28 12:57:43 --> Output Class Initialized
INFO - 2019-09-28 12:57:43 --> Security Class Initialized
DEBUG - 2019-09-28 12:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-28 12:57:43 --> Input Class Initialized
INFO - 2019-09-28 12:57:43 --> Language Class Initialized
INFO - 2019-09-28 12:57:43 --> Loader Class Initialized
INFO - 2019-09-28 12:57:43 --> Helper loaded: url_helper
INFO - 2019-09-28 12:57:43 --> Helper loaded: html_helper
INFO - 2019-09-28 12:57:43 --> Helper loaded: form_helper
INFO - 2019-09-28 12:57:43 --> Helper loaded: cookie_helper
INFO - 2019-09-28 12:57:43 --> Helper loaded: date_helper
INFO - 2019-09-28 12:57:43 --> Form Validation Class Initialized
INFO - 2019-09-28 12:57:43 --> Email Class Initialized
DEBUG - 2019-09-28 12:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-28 12:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-28 12:57:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-28 12:57:43 --> Pagination Class Initialized
INFO - 2019-09-28 12:57:43 --> Database Driver Class Initialized
INFO - 2019-09-28 12:57:43 --> Database Driver Class Initialized
INFO - 2019-09-28 12:57:43 --> Controller Class Initialized
DEBUG - 2019-09-28 12:57:43 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-28 12:57:43 --> Helper loaded: inflector_helper
INFO - 2019-09-28 12:57:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-28 12:57:43 --> Final output sent to browser
DEBUG - 2019-09-28 12:57:43 --> Total execution time: 0.1438
