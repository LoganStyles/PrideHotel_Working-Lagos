<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-21 03:25:14 --> Config Class Initialized
INFO - 2018-11-21 03:25:14 --> Hooks Class Initialized
DEBUG - 2018-11-21 03:25:14 --> UTF-8 Support Enabled
INFO - 2018-11-21 03:25:14 --> Utf8 Class Initialized
INFO - 2018-11-21 03:25:14 --> URI Class Initialized
INFO - 2018-11-21 03:25:14 --> Router Class Initialized
INFO - 2018-11-21 03:25:14 --> Output Class Initialized
INFO - 2018-11-21 03:25:14 --> Security Class Initialized
DEBUG - 2018-11-21 03:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 03:25:14 --> Input Class Initialized
INFO - 2018-11-21 03:25:14 --> Language Class Initialized
INFO - 2018-11-21 03:25:14 --> Loader Class Initialized
INFO - 2018-11-21 03:25:14 --> Helper loaded: url_helper
INFO - 2018-11-21 03:25:14 --> Helper loaded: html_helper
INFO - 2018-11-21 03:25:14 --> Helper loaded: form_helper
INFO - 2018-11-21 03:25:14 --> Helper loaded: cookie_helper
INFO - 2018-11-21 03:25:14 --> Helper loaded: date_helper
INFO - 2018-11-21 03:25:14 --> Form Validation Class Initialized
INFO - 2018-11-21 03:25:14 --> Email Class Initialized
DEBUG - 2018-11-21 03:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 03:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 03:25:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 03:25:14 --> Pagination Class Initialized
INFO - 2018-11-21 03:25:14 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:14 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:15 --> Controller Class Initialized
INFO - 2018-11-21 03:25:15 --> Config Class Initialized
INFO - 2018-11-21 03:25:15 --> Hooks Class Initialized
DEBUG - 2018-11-21 03:25:15 --> UTF-8 Support Enabled
INFO - 2018-11-21 03:25:15 --> Utf8 Class Initialized
INFO - 2018-11-21 03:25:15 --> URI Class Initialized
INFO - 2018-11-21 03:25:15 --> Router Class Initialized
INFO - 2018-11-21 03:25:15 --> Output Class Initialized
INFO - 2018-11-21 03:25:15 --> Security Class Initialized
DEBUG - 2018-11-21 03:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 03:25:15 --> Input Class Initialized
INFO - 2018-11-21 03:25:15 --> Language Class Initialized
INFO - 2018-11-21 03:25:15 --> Loader Class Initialized
INFO - 2018-11-21 03:25:15 --> Helper loaded: url_helper
INFO - 2018-11-21 03:25:15 --> Helper loaded: html_helper
INFO - 2018-11-21 03:25:15 --> Helper loaded: form_helper
INFO - 2018-11-21 03:25:15 --> Helper loaded: cookie_helper
INFO - 2018-11-21 03:25:15 --> Helper loaded: date_helper
INFO - 2018-11-21 03:25:15 --> Form Validation Class Initialized
INFO - 2018-11-21 03:25:15 --> Email Class Initialized
DEBUG - 2018-11-21 03:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 03:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 03:25:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 03:25:15 --> Pagination Class Initialized
INFO - 2018-11-21 03:25:15 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:15 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:15 --> Controller Class Initialized
INFO - 2018-11-21 03:25:15 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-21 03:25:15 --> Final output sent to browser
DEBUG - 2018-11-21 03:25:15 --> Total execution time: 0.1489
INFO - 2018-11-21 03:25:30 --> Config Class Initialized
INFO - 2018-11-21 03:25:30 --> Hooks Class Initialized
DEBUG - 2018-11-21 03:25:30 --> UTF-8 Support Enabled
INFO - 2018-11-21 03:25:30 --> Utf8 Class Initialized
INFO - 2018-11-21 03:25:30 --> URI Class Initialized
INFO - 2018-11-21 03:25:30 --> Router Class Initialized
INFO - 2018-11-21 03:25:30 --> Output Class Initialized
INFO - 2018-11-21 03:25:30 --> Security Class Initialized
DEBUG - 2018-11-21 03:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 03:25:30 --> Input Class Initialized
INFO - 2018-11-21 03:25:30 --> Language Class Initialized
INFO - 2018-11-21 03:25:30 --> Loader Class Initialized
INFO - 2018-11-21 03:25:30 --> Helper loaded: url_helper
INFO - 2018-11-21 03:25:30 --> Helper loaded: html_helper
INFO - 2018-11-21 03:25:30 --> Helper loaded: form_helper
INFO - 2018-11-21 03:25:30 --> Helper loaded: cookie_helper
INFO - 2018-11-21 03:25:30 --> Helper loaded: date_helper
INFO - 2018-11-21 03:25:30 --> Form Validation Class Initialized
INFO - 2018-11-21 03:25:30 --> Email Class Initialized
DEBUG - 2018-11-21 03:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 03:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 03:25:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 03:25:30 --> Pagination Class Initialized
INFO - 2018-11-21 03:25:30 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:30 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:30 --> Controller Class Initialized
INFO - 2018-11-21 03:25:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-11-21 03:25:30 --> Config Class Initialized
INFO - 2018-11-21 03:25:30 --> Hooks Class Initialized
DEBUG - 2018-11-21 03:25:30 --> UTF-8 Support Enabled
INFO - 2018-11-21 03:25:30 --> Utf8 Class Initialized
INFO - 2018-11-21 03:25:30 --> URI Class Initialized
INFO - 2018-11-21 03:25:30 --> Router Class Initialized
INFO - 2018-11-21 03:25:30 --> Output Class Initialized
INFO - 2018-11-21 03:25:30 --> Security Class Initialized
DEBUG - 2018-11-21 03:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 03:25:30 --> Input Class Initialized
INFO - 2018-11-21 03:25:30 --> Language Class Initialized
INFO - 2018-11-21 03:25:30 --> Loader Class Initialized
INFO - 2018-11-21 03:25:30 --> Helper loaded: url_helper
INFO - 2018-11-21 03:25:30 --> Helper loaded: html_helper
INFO - 2018-11-21 03:25:30 --> Helper loaded: form_helper
INFO - 2018-11-21 03:25:30 --> Helper loaded: cookie_helper
INFO - 2018-11-21 03:25:30 --> Helper loaded: date_helper
INFO - 2018-11-21 03:25:30 --> Form Validation Class Initialized
INFO - 2018-11-21 03:25:31 --> Email Class Initialized
DEBUG - 2018-11-21 03:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 03:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 03:25:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 03:25:31 --> Pagination Class Initialized
INFO - 2018-11-21 03:25:31 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:31 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:31 --> Controller Class Initialized
INFO - 2018-11-21 03:25:31 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-21 03:25:31 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-11-21 03:25:31 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-21 03:25:31 --> Final output sent to browser
DEBUG - 2018-11-21 03:25:31 --> Total execution time: 0.3593
INFO - 2018-11-21 03:25:31 --> Config Class Initialized
INFO - 2018-11-21 03:25:31 --> Config Class Initialized
INFO - 2018-11-21 03:25:31 --> Hooks Class Initialized
INFO - 2018-11-21 03:25:31 --> Hooks Class Initialized
DEBUG - 2018-11-21 03:25:31 --> UTF-8 Support Enabled
DEBUG - 2018-11-21 03:25:31 --> UTF-8 Support Enabled
INFO - 2018-11-21 03:25:31 --> Utf8 Class Initialized
INFO - 2018-11-21 03:25:31 --> Utf8 Class Initialized
INFO - 2018-11-21 03:25:31 --> URI Class Initialized
INFO - 2018-11-21 03:25:31 --> URI Class Initialized
INFO - 2018-11-21 03:25:31 --> Router Class Initialized
INFO - 2018-11-21 03:25:31 --> Router Class Initialized
INFO - 2018-11-21 03:25:31 --> Output Class Initialized
INFO - 2018-11-21 03:25:31 --> Output Class Initialized
INFO - 2018-11-21 03:25:31 --> Security Class Initialized
INFO - 2018-11-21 03:25:31 --> Security Class Initialized
DEBUG - 2018-11-21 03:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 03:25:31 --> Input Class Initialized
DEBUG - 2018-11-21 03:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 03:25:31 --> Language Class Initialized
INFO - 2018-11-21 03:25:31 --> Input Class Initialized
INFO - 2018-11-21 03:25:31 --> Language Class Initialized
INFO - 2018-11-21 03:25:31 --> Loader Class Initialized
INFO - 2018-11-21 03:25:31 --> Loader Class Initialized
INFO - 2018-11-21 03:25:31 --> Helper loaded: url_helper
INFO - 2018-11-21 03:25:31 --> Helper loaded: url_helper
INFO - 2018-11-21 03:25:31 --> Helper loaded: html_helper
INFO - 2018-11-21 03:25:31 --> Helper loaded: html_helper
INFO - 2018-11-21 03:25:31 --> Helper loaded: form_helper
INFO - 2018-11-21 03:25:31 --> Helper loaded: form_helper
INFO - 2018-11-21 03:25:31 --> Helper loaded: cookie_helper
INFO - 2018-11-21 03:25:31 --> Helper loaded: cookie_helper
INFO - 2018-11-21 03:25:31 --> Helper loaded: date_helper
INFO - 2018-11-21 03:25:31 --> Helper loaded: date_helper
INFO - 2018-11-21 03:25:31 --> Form Validation Class Initialized
INFO - 2018-11-21 03:25:31 --> Form Validation Class Initialized
INFO - 2018-11-21 03:25:31 --> Email Class Initialized
INFO - 2018-11-21 03:25:31 --> Email Class Initialized
DEBUG - 2018-11-21 03:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-21 03:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 03:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 03:25:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 03:25:31 --> Pagination Class Initialized
INFO - 2018-11-21 03:25:31 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:31 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:31 --> Controller Class Initialized
INFO - 2018-11-21 03:25:31 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 03:25:31 --> Final output sent to browser
DEBUG - 2018-11-21 03:25:31 --> Total execution time: 0.2470
INFO - 2018-11-21 03:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 03:25:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 03:25:31 --> Pagination Class Initialized
INFO - 2018-11-21 03:25:31 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:31 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:31 --> Controller Class Initialized
INFO - 2018-11-21 03:25:31 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 03:25:31 --> Final output sent to browser
DEBUG - 2018-11-21 03:25:31 --> Total execution time: 0.3066
INFO - 2018-11-21 03:25:33 --> Config Class Initialized
INFO - 2018-11-21 03:25:33 --> Hooks Class Initialized
DEBUG - 2018-11-21 03:25:33 --> UTF-8 Support Enabled
INFO - 2018-11-21 03:25:33 --> Utf8 Class Initialized
INFO - 2018-11-21 03:25:33 --> URI Class Initialized
INFO - 2018-11-21 03:25:33 --> Router Class Initialized
INFO - 2018-11-21 03:25:33 --> Output Class Initialized
INFO - 2018-11-21 03:25:33 --> Security Class Initialized
DEBUG - 2018-11-21 03:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 03:25:33 --> Input Class Initialized
INFO - 2018-11-21 03:25:33 --> Language Class Initialized
INFO - 2018-11-21 03:25:33 --> Loader Class Initialized
INFO - 2018-11-21 03:25:33 --> Helper loaded: url_helper
INFO - 2018-11-21 03:25:33 --> Helper loaded: html_helper
INFO - 2018-11-21 03:25:33 --> Helper loaded: form_helper
INFO - 2018-11-21 03:25:33 --> Helper loaded: cookie_helper
INFO - 2018-11-21 03:25:33 --> Helper loaded: date_helper
INFO - 2018-11-21 03:25:33 --> Form Validation Class Initialized
INFO - 2018-11-21 03:25:33 --> Email Class Initialized
DEBUG - 2018-11-21 03:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 03:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 03:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 03:25:33 --> Pagination Class Initialized
INFO - 2018-11-21 03:25:33 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:33 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:33 --> Controller Class Initialized
INFO - 2018-11-21 03:25:33 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 03:25:33 --> Final output sent to browser
DEBUG - 2018-11-21 03:25:33 --> Total execution time: 0.1570
INFO - 2018-11-21 03:25:35 --> Config Class Initialized
INFO - 2018-11-21 03:25:35 --> Hooks Class Initialized
DEBUG - 2018-11-21 03:25:35 --> UTF-8 Support Enabled
INFO - 2018-11-21 03:25:35 --> Utf8 Class Initialized
INFO - 2018-11-21 03:25:35 --> URI Class Initialized
INFO - 2018-11-21 03:25:35 --> Router Class Initialized
INFO - 2018-11-21 03:25:35 --> Output Class Initialized
INFO - 2018-11-21 03:25:35 --> Security Class Initialized
DEBUG - 2018-11-21 03:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 03:25:35 --> Input Class Initialized
INFO - 2018-11-21 03:25:35 --> Language Class Initialized
INFO - 2018-11-21 03:25:35 --> Loader Class Initialized
INFO - 2018-11-21 03:25:35 --> Helper loaded: url_helper
INFO - 2018-11-21 03:25:35 --> Helper loaded: html_helper
INFO - 2018-11-21 03:25:35 --> Helper loaded: form_helper
INFO - 2018-11-21 03:25:35 --> Helper loaded: cookie_helper
INFO - 2018-11-21 03:25:35 --> Helper loaded: date_helper
INFO - 2018-11-21 03:25:35 --> Form Validation Class Initialized
INFO - 2018-11-21 03:25:35 --> Email Class Initialized
DEBUG - 2018-11-21 03:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 03:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 03:25:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 03:25:35 --> Pagination Class Initialized
INFO - 2018-11-21 03:25:35 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:35 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:35 --> Controller Class Initialized
INFO - 2018-11-21 03:25:35 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 03:25:35 --> Final output sent to browser
DEBUG - 2018-11-21 03:25:35 --> Total execution time: 0.1146
INFO - 2018-11-21 03:25:37 --> Config Class Initialized
INFO - 2018-11-21 03:25:37 --> Hooks Class Initialized
DEBUG - 2018-11-21 03:25:37 --> UTF-8 Support Enabled
INFO - 2018-11-21 03:25:37 --> Utf8 Class Initialized
INFO - 2018-11-21 03:25:37 --> URI Class Initialized
INFO - 2018-11-21 03:25:37 --> Router Class Initialized
INFO - 2018-11-21 03:25:37 --> Output Class Initialized
INFO - 2018-11-21 03:25:37 --> Security Class Initialized
DEBUG - 2018-11-21 03:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 03:25:37 --> Input Class Initialized
INFO - 2018-11-21 03:25:37 --> Language Class Initialized
INFO - 2018-11-21 03:25:37 --> Loader Class Initialized
INFO - 2018-11-21 03:25:37 --> Helper loaded: url_helper
INFO - 2018-11-21 03:25:37 --> Helper loaded: html_helper
INFO - 2018-11-21 03:25:37 --> Helper loaded: form_helper
INFO - 2018-11-21 03:25:37 --> Helper loaded: cookie_helper
INFO - 2018-11-21 03:25:37 --> Helper loaded: date_helper
INFO - 2018-11-21 03:25:37 --> Form Validation Class Initialized
INFO - 2018-11-21 03:25:37 --> Email Class Initialized
DEBUG - 2018-11-21 03:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 03:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 03:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 03:25:37 --> Pagination Class Initialized
INFO - 2018-11-21 03:25:37 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:37 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:37 --> Controller Class Initialized
INFO - 2018-11-21 03:25:37 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-21 03:25:37 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/account_class.php
INFO - 2018-11-21 03:25:37 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-21 03:25:37 --> Final output sent to browser
DEBUG - 2018-11-21 03:25:37 --> Total execution time: 0.1913
INFO - 2018-11-21 03:25:37 --> Config Class Initialized
INFO - 2018-11-21 03:25:37 --> Config Class Initialized
INFO - 2018-11-21 03:25:37 --> Hooks Class Initialized
INFO - 2018-11-21 03:25:37 --> Hooks Class Initialized
DEBUG - 2018-11-21 03:25:37 --> UTF-8 Support Enabled
INFO - 2018-11-21 03:25:37 --> Utf8 Class Initialized
DEBUG - 2018-11-21 03:25:37 --> UTF-8 Support Enabled
INFO - 2018-11-21 03:25:37 --> Utf8 Class Initialized
INFO - 2018-11-21 03:25:37 --> URI Class Initialized
INFO - 2018-11-21 03:25:37 --> URI Class Initialized
INFO - 2018-11-21 03:25:37 --> Router Class Initialized
INFO - 2018-11-21 03:25:37 --> Router Class Initialized
INFO - 2018-11-21 03:25:37 --> Output Class Initialized
INFO - 2018-11-21 03:25:37 --> Output Class Initialized
INFO - 2018-11-21 03:25:37 --> Security Class Initialized
INFO - 2018-11-21 03:25:37 --> Security Class Initialized
DEBUG - 2018-11-21 03:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-21 03:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 03:25:37 --> Input Class Initialized
INFO - 2018-11-21 03:25:37 --> Input Class Initialized
INFO - 2018-11-21 03:25:37 --> Language Class Initialized
INFO - 2018-11-21 03:25:37 --> Language Class Initialized
INFO - 2018-11-21 03:25:37 --> Loader Class Initialized
INFO - 2018-11-21 03:25:37 --> Loader Class Initialized
INFO - 2018-11-21 03:25:37 --> Helper loaded: url_helper
INFO - 2018-11-21 03:25:37 --> Helper loaded: url_helper
INFO - 2018-11-21 03:25:37 --> Helper loaded: html_helper
INFO - 2018-11-21 03:25:37 --> Helper loaded: html_helper
INFO - 2018-11-21 03:25:37 --> Helper loaded: form_helper
INFO - 2018-11-21 03:25:37 --> Helper loaded: form_helper
INFO - 2018-11-21 03:25:37 --> Helper loaded: cookie_helper
INFO - 2018-11-21 03:25:37 --> Helper loaded: cookie_helper
INFO - 2018-11-21 03:25:37 --> Helper loaded: date_helper
INFO - 2018-11-21 03:25:37 --> Helper loaded: date_helper
INFO - 2018-11-21 03:25:37 --> Form Validation Class Initialized
INFO - 2018-11-21 03:25:37 --> Form Validation Class Initialized
INFO - 2018-11-21 03:25:37 --> Email Class Initialized
INFO - 2018-11-21 03:25:37 --> Email Class Initialized
DEBUG - 2018-11-21 03:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-21 03:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 03:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 03:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 03:25:37 --> Pagination Class Initialized
INFO - 2018-11-21 03:25:37 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:37 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:37 --> Controller Class Initialized
INFO - 2018-11-21 03:25:37 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 03:25:37 --> Final output sent to browser
DEBUG - 2018-11-21 03:25:37 --> Total execution time: 0.1616
INFO - 2018-11-21 03:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 03:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 03:25:37 --> Pagination Class Initialized
INFO - 2018-11-21 03:25:37 --> Config Class Initialized
INFO - 2018-11-21 03:25:37 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:37 --> Hooks Class Initialized
INFO - 2018-11-21 03:25:37 --> Database Driver Class Initialized
DEBUG - 2018-11-21 03:25:37 --> UTF-8 Support Enabled
INFO - 2018-11-21 03:25:37 --> Utf8 Class Initialized
INFO - 2018-11-21 03:25:37 --> URI Class Initialized
INFO - 2018-11-21 03:25:37 --> Controller Class Initialized
INFO - 2018-11-21 03:25:37 --> Router Class Initialized
INFO - 2018-11-21 03:25:37 --> Output Class Initialized
INFO - 2018-11-21 03:25:37 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 03:25:37 --> Security Class Initialized
INFO - 2018-11-21 03:25:37 --> Final output sent to browser
DEBUG - 2018-11-21 03:25:37 --> Total execution time: 0.2394
DEBUG - 2018-11-21 03:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 03:25:37 --> Input Class Initialized
INFO - 2018-11-21 03:25:37 --> Language Class Initialized
INFO - 2018-11-21 03:25:37 --> Loader Class Initialized
INFO - 2018-11-21 03:25:37 --> Helper loaded: url_helper
INFO - 2018-11-21 03:25:37 --> Helper loaded: html_helper
INFO - 2018-11-21 03:25:37 --> Helper loaded: form_helper
INFO - 2018-11-21 03:25:37 --> Helper loaded: cookie_helper
INFO - 2018-11-21 03:25:37 --> Helper loaded: date_helper
INFO - 2018-11-21 03:25:37 --> Form Validation Class Initialized
INFO - 2018-11-21 03:25:37 --> Email Class Initialized
DEBUG - 2018-11-21 03:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 03:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 03:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 03:25:37 --> Pagination Class Initialized
INFO - 2018-11-21 03:25:37 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:37 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:37 --> Controller Class Initialized
INFO - 2018-11-21 03:25:37 --> Final output sent to browser
DEBUG - 2018-11-21 03:25:37 --> Total execution time: 0.1938
INFO - 2018-11-21 03:25:39 --> Config Class Initialized
INFO - 2018-11-21 03:25:39 --> Hooks Class Initialized
DEBUG - 2018-11-21 03:25:39 --> UTF-8 Support Enabled
INFO - 2018-11-21 03:25:39 --> Utf8 Class Initialized
INFO - 2018-11-21 03:25:39 --> URI Class Initialized
INFO - 2018-11-21 03:25:39 --> Router Class Initialized
INFO - 2018-11-21 03:25:39 --> Output Class Initialized
INFO - 2018-11-21 03:25:39 --> Security Class Initialized
DEBUG - 2018-11-21 03:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 03:25:39 --> Input Class Initialized
INFO - 2018-11-21 03:25:39 --> Language Class Initialized
INFO - 2018-11-21 03:25:39 --> Loader Class Initialized
INFO - 2018-11-21 03:25:39 --> Helper loaded: url_helper
INFO - 2018-11-21 03:25:39 --> Helper loaded: html_helper
INFO - 2018-11-21 03:25:39 --> Helper loaded: form_helper
INFO - 2018-11-21 03:25:39 --> Helper loaded: cookie_helper
INFO - 2018-11-21 03:25:39 --> Helper loaded: date_helper
INFO - 2018-11-21 03:25:39 --> Form Validation Class Initialized
INFO - 2018-11-21 03:25:39 --> Email Class Initialized
DEBUG - 2018-11-21 03:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 03:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 03:25:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 03:25:39 --> Pagination Class Initialized
INFO - 2018-11-21 03:25:39 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:39 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:39 --> Controller Class Initialized
INFO - 2018-11-21 03:25:39 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-21 03:25:39 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/account_type.php
INFO - 2018-11-21 03:25:39 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-21 03:25:39 --> Final output sent to browser
DEBUG - 2018-11-21 03:25:39 --> Total execution time: 0.1815
INFO - 2018-11-21 03:25:39 --> Config Class Initialized
INFO - 2018-11-21 03:25:39 --> Hooks Class Initialized
DEBUG - 2018-11-21 03:25:39 --> UTF-8 Support Enabled
INFO - 2018-11-21 03:25:39 --> Utf8 Class Initialized
INFO - 2018-11-21 03:25:39 --> URI Class Initialized
INFO - 2018-11-21 03:25:39 --> Config Class Initialized
INFO - 2018-11-21 03:25:39 --> Hooks Class Initialized
INFO - 2018-11-21 03:25:39 --> Router Class Initialized
INFO - 2018-11-21 03:25:39 --> Output Class Initialized
DEBUG - 2018-11-21 03:25:39 --> UTF-8 Support Enabled
INFO - 2018-11-21 03:25:39 --> Security Class Initialized
INFO - 2018-11-21 03:25:39 --> Utf8 Class Initialized
INFO - 2018-11-21 03:25:39 --> URI Class Initialized
DEBUG - 2018-11-21 03:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 03:25:39 --> Input Class Initialized
INFO - 2018-11-21 03:25:39 --> Router Class Initialized
INFO - 2018-11-21 03:25:39 --> Language Class Initialized
INFO - 2018-11-21 03:25:39 --> Output Class Initialized
INFO - 2018-11-21 03:25:39 --> Security Class Initialized
INFO - 2018-11-21 03:25:39 --> Loader Class Initialized
DEBUG - 2018-11-21 03:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 03:25:39 --> Helper loaded: url_helper
INFO - 2018-11-21 03:25:39 --> Input Class Initialized
INFO - 2018-11-21 03:25:39 --> Language Class Initialized
INFO - 2018-11-21 03:25:39 --> Helper loaded: html_helper
INFO - 2018-11-21 03:25:39 --> Helper loaded: form_helper
INFO - 2018-11-21 03:25:39 --> Helper loaded: cookie_helper
INFO - 2018-11-21 03:25:39 --> Helper loaded: date_helper
INFO - 2018-11-21 03:25:39 --> Loader Class Initialized
INFO - 2018-11-21 03:25:39 --> Form Validation Class Initialized
INFO - 2018-11-21 03:25:39 --> Helper loaded: url_helper
INFO - 2018-11-21 03:25:39 --> Email Class Initialized
INFO - 2018-11-21 03:25:39 --> Helper loaded: html_helper
DEBUG - 2018-11-21 03:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 03:25:39 --> Helper loaded: form_helper
INFO - 2018-11-21 03:25:39 --> Helper loaded: cookie_helper
INFO - 2018-11-21 03:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 03:25:39 --> Helper loaded: date_helper
INFO - 2018-11-21 03:25:39 --> Form Validation Class Initialized
INFO - 2018-11-21 03:25:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 03:25:39 --> Pagination Class Initialized
INFO - 2018-11-21 03:25:39 --> Email Class Initialized
DEBUG - 2018-11-21 03:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 03:25:39 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:39 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:39 --> Controller Class Initialized
INFO - 2018-11-21 03:25:39 --> Config Class Initialized
INFO - 2018-11-21 03:25:39 --> Hooks Class Initialized
INFO - 2018-11-21 03:25:39 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 03:25:39 --> Final output sent to browser
DEBUG - 2018-11-21 03:25:40 --> UTF-8 Support Enabled
DEBUG - 2018-11-21 03:25:40 --> Total execution time: 0.2388
INFO - 2018-11-21 03:25:40 --> Utf8 Class Initialized
INFO - 2018-11-21 03:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 03:25:40 --> URI Class Initialized
INFO - 2018-11-21 03:25:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 03:25:40 --> Pagination Class Initialized
INFO - 2018-11-21 03:25:40 --> Router Class Initialized
INFO - 2018-11-21 03:25:40 --> Output Class Initialized
INFO - 2018-11-21 03:25:40 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:40 --> Security Class Initialized
INFO - 2018-11-21 03:25:40 --> Database Driver Class Initialized
DEBUG - 2018-11-21 03:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 03:25:40 --> Input Class Initialized
INFO - 2018-11-21 03:25:40 --> Language Class Initialized
INFO - 2018-11-21 03:25:40 --> Controller Class Initialized
INFO - 2018-11-21 03:25:40 --> Loader Class Initialized
INFO - 2018-11-21 03:25:40 --> Helper loaded: url_helper
INFO - 2018-11-21 03:25:40 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 03:25:40 --> Final output sent to browser
INFO - 2018-11-21 03:25:40 --> Helper loaded: html_helper
DEBUG - 2018-11-21 03:25:40 --> Total execution time: 0.3308
INFO - 2018-11-21 03:25:40 --> Helper loaded: form_helper
INFO - 2018-11-21 03:25:40 --> Helper loaded: cookie_helper
INFO - 2018-11-21 03:25:40 --> Helper loaded: date_helper
INFO - 2018-11-21 03:25:40 --> Form Validation Class Initialized
INFO - 2018-11-21 03:25:40 --> Email Class Initialized
DEBUG - 2018-11-21 03:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 03:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 03:25:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 03:25:40 --> Pagination Class Initialized
INFO - 2018-11-21 03:25:40 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:40 --> Database Driver Class Initialized
INFO - 2018-11-21 03:25:40 --> Controller Class Initialized
INFO - 2018-11-21 03:25:40 --> Final output sent to browser
DEBUG - 2018-11-21 03:25:40 --> Total execution time: 0.2835
INFO - 2018-11-21 04:06:53 --> Config Class Initialized
INFO - 2018-11-21 04:06:53 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:06:53 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:06:53 --> Utf8 Class Initialized
INFO - 2018-11-21 04:06:53 --> URI Class Initialized
INFO - 2018-11-21 04:06:53 --> Router Class Initialized
INFO - 2018-11-21 04:06:53 --> Output Class Initialized
INFO - 2018-11-21 04:06:53 --> Security Class Initialized
DEBUG - 2018-11-21 04:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:06:53 --> Input Class Initialized
INFO - 2018-11-21 04:06:53 --> Language Class Initialized
INFO - 2018-11-21 04:06:53 --> Loader Class Initialized
INFO - 2018-11-21 04:06:53 --> Helper loaded: url_helper
INFO - 2018-11-21 04:06:53 --> Helper loaded: html_helper
INFO - 2018-11-21 04:06:53 --> Helper loaded: form_helper
INFO - 2018-11-21 04:06:53 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:06:53 --> Helper loaded: date_helper
INFO - 2018-11-21 04:06:53 --> Form Validation Class Initialized
INFO - 2018-11-21 04:06:53 --> Email Class Initialized
DEBUG - 2018-11-21 04:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:06:53 --> Pagination Class Initialized
INFO - 2018-11-21 04:06:53 --> Database Driver Class Initialized
INFO - 2018-11-21 04:06:53 --> Database Driver Class Initialized
INFO - 2018-11-21 04:06:53 --> Controller Class Initialized
INFO - 2018-11-21 04:06:53 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:06:53 --> Final output sent to browser
DEBUG - 2018-11-21 04:06:53 --> Total execution time: 0.1014
INFO - 2018-11-21 04:06:53 --> Config Class Initialized
INFO - 2018-11-21 04:06:53 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:06:53 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:06:53 --> Utf8 Class Initialized
INFO - 2018-11-21 04:06:53 --> URI Class Initialized
INFO - 2018-11-21 04:06:53 --> Router Class Initialized
INFO - 2018-11-21 04:06:53 --> Output Class Initialized
INFO - 2018-11-21 04:06:53 --> Security Class Initialized
DEBUG - 2018-11-21 04:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:06:53 --> Input Class Initialized
INFO - 2018-11-21 04:06:53 --> Language Class Initialized
INFO - 2018-11-21 04:06:53 --> Loader Class Initialized
INFO - 2018-11-21 04:06:53 --> Helper loaded: url_helper
INFO - 2018-11-21 04:06:53 --> Helper loaded: html_helper
INFO - 2018-11-21 04:06:53 --> Helper loaded: form_helper
INFO - 2018-11-21 04:06:53 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:06:53 --> Helper loaded: date_helper
INFO - 2018-11-21 04:06:53 --> Form Validation Class Initialized
INFO - 2018-11-21 04:06:53 --> Email Class Initialized
DEBUG - 2018-11-21 04:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:06:53 --> Pagination Class Initialized
INFO - 2018-11-21 04:06:53 --> Database Driver Class Initialized
INFO - 2018-11-21 04:06:53 --> Database Driver Class Initialized
INFO - 2018-11-21 04:06:53 --> Controller Class Initialized
INFO - 2018-11-21 04:06:53 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:06:53 --> Final output sent to browser
DEBUG - 2018-11-21 04:06:53 --> Total execution time: 0.1134
INFO - 2018-11-21 04:06:55 --> Config Class Initialized
INFO - 2018-11-21 04:06:55 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:06:55 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:06:55 --> Utf8 Class Initialized
INFO - 2018-11-21 04:06:55 --> URI Class Initialized
INFO - 2018-11-21 04:06:55 --> Router Class Initialized
INFO - 2018-11-21 04:06:55 --> Output Class Initialized
INFO - 2018-11-21 04:06:55 --> Security Class Initialized
DEBUG - 2018-11-21 04:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:06:55 --> Input Class Initialized
INFO - 2018-11-21 04:06:55 --> Language Class Initialized
INFO - 2018-11-21 04:06:55 --> Loader Class Initialized
INFO - 2018-11-21 04:06:55 --> Helper loaded: url_helper
INFO - 2018-11-21 04:06:55 --> Helper loaded: html_helper
INFO - 2018-11-21 04:06:55 --> Helper loaded: form_helper
INFO - 2018-11-21 04:06:55 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:06:55 --> Helper loaded: date_helper
INFO - 2018-11-21 04:06:55 --> Form Validation Class Initialized
INFO - 2018-11-21 04:06:55 --> Email Class Initialized
DEBUG - 2018-11-21 04:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:06:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:06:55 --> Pagination Class Initialized
INFO - 2018-11-21 04:06:55 --> Database Driver Class Initialized
INFO - 2018-11-21 04:06:55 --> Database Driver Class Initialized
INFO - 2018-11-21 04:06:55 --> Controller Class Initialized
INFO - 2018-11-21 04:06:55 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-21 04:06:55 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-11-21 04:06:55 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-21 04:06:55 --> Final output sent to browser
DEBUG - 2018-11-21 04:06:55 --> Total execution time: 0.1163
INFO - 2018-11-21 04:06:55 --> Config Class Initialized
INFO - 2018-11-21 04:06:55 --> Config Class Initialized
INFO - 2018-11-21 04:06:55 --> Hooks Class Initialized
INFO - 2018-11-21 04:06:55 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:06:55 --> UTF-8 Support Enabled
DEBUG - 2018-11-21 04:06:55 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:06:55 --> Utf8 Class Initialized
INFO - 2018-11-21 04:06:55 --> Utf8 Class Initialized
INFO - 2018-11-21 04:06:55 --> URI Class Initialized
INFO - 2018-11-21 04:06:55 --> URI Class Initialized
INFO - 2018-11-21 04:06:55 --> Router Class Initialized
INFO - 2018-11-21 04:06:55 --> Router Class Initialized
INFO - 2018-11-21 04:06:55 --> Output Class Initialized
INFO - 2018-11-21 04:06:55 --> Output Class Initialized
INFO - 2018-11-21 04:06:55 --> Security Class Initialized
INFO - 2018-11-21 04:06:55 --> Security Class Initialized
DEBUG - 2018-11-21 04:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-21 04:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:06:55 --> Input Class Initialized
INFO - 2018-11-21 04:06:55 --> Input Class Initialized
INFO - 2018-11-21 04:06:55 --> Language Class Initialized
INFO - 2018-11-21 04:06:55 --> Language Class Initialized
INFO - 2018-11-21 04:06:55 --> Loader Class Initialized
INFO - 2018-11-21 04:06:55 --> Loader Class Initialized
INFO - 2018-11-21 04:06:55 --> Helper loaded: url_helper
INFO - 2018-11-21 04:06:55 --> Helper loaded: url_helper
INFO - 2018-11-21 04:06:55 --> Helper loaded: html_helper
INFO - 2018-11-21 04:06:55 --> Helper loaded: html_helper
INFO - 2018-11-21 04:06:55 --> Helper loaded: form_helper
INFO - 2018-11-21 04:06:55 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:06:55 --> Helper loaded: form_helper
INFO - 2018-11-21 04:06:55 --> Helper loaded: date_helper
INFO - 2018-11-21 04:06:55 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:06:55 --> Form Validation Class Initialized
INFO - 2018-11-21 04:06:55 --> Helper loaded: date_helper
INFO - 2018-11-21 04:06:55 --> Email Class Initialized
INFO - 2018-11-21 04:06:55 --> Form Validation Class Initialized
DEBUG - 2018-11-21 04:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:06:55 --> Email Class Initialized
INFO - 2018-11-21 04:06:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-11-21 04:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:06:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:06:55 --> Pagination Class Initialized
INFO - 2018-11-21 04:06:55 --> Database Driver Class Initialized
INFO - 2018-11-21 04:06:55 --> Database Driver Class Initialized
INFO - 2018-11-21 04:06:55 --> Controller Class Initialized
INFO - 2018-11-21 04:06:55 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:06:55 --> Final output sent to browser
DEBUG - 2018-11-21 04:06:55 --> Total execution time: 0.1361
INFO - 2018-11-21 04:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:06:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:06:55 --> Pagination Class Initialized
INFO - 2018-11-21 04:06:55 --> Database Driver Class Initialized
INFO - 2018-11-21 04:06:55 --> Database Driver Class Initialized
INFO - 2018-11-21 04:06:55 --> Controller Class Initialized
INFO - 2018-11-21 04:06:55 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:06:55 --> Final output sent to browser
DEBUG - 2018-11-21 04:06:55 --> Total execution time: 0.1885
INFO - 2018-11-21 04:06:57 --> Config Class Initialized
INFO - 2018-11-21 04:06:57 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:06:57 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:06:57 --> Utf8 Class Initialized
INFO - 2018-11-21 04:06:57 --> URI Class Initialized
INFO - 2018-11-21 04:06:57 --> Router Class Initialized
INFO - 2018-11-21 04:06:57 --> Output Class Initialized
INFO - 2018-11-21 04:06:57 --> Security Class Initialized
DEBUG - 2018-11-21 04:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:06:57 --> Input Class Initialized
INFO - 2018-11-21 04:06:57 --> Language Class Initialized
INFO - 2018-11-21 04:06:57 --> Loader Class Initialized
INFO - 2018-11-21 04:06:57 --> Helper loaded: url_helper
INFO - 2018-11-21 04:06:57 --> Helper loaded: html_helper
INFO - 2018-11-21 04:06:57 --> Helper loaded: form_helper
INFO - 2018-11-21 04:06:57 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:06:57 --> Helper loaded: date_helper
INFO - 2018-11-21 04:06:57 --> Form Validation Class Initialized
INFO - 2018-11-21 04:06:57 --> Email Class Initialized
DEBUG - 2018-11-21 04:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:06:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:06:57 --> Pagination Class Initialized
INFO - 2018-11-21 04:06:57 --> Database Driver Class Initialized
INFO - 2018-11-21 04:06:57 --> Database Driver Class Initialized
INFO - 2018-11-21 04:06:57 --> Controller Class Initialized
INFO - 2018-11-21 04:06:57 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-21 04:06:57 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-11-21 04:06:57 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2018-11-21 04:06:57 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-21 04:06:57 --> Final output sent to browser
DEBUG - 2018-11-21 04:06:57 --> Total execution time: 0.2283
INFO - 2018-11-21 04:06:57 --> Config Class Initialized
INFO - 2018-11-21 04:06:57 --> Hooks Class Initialized
INFO - 2018-11-21 04:06:57 --> Config Class Initialized
INFO - 2018-11-21 04:06:57 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:06:57 --> UTF-8 Support Enabled
DEBUG - 2018-11-21 04:06:57 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:06:57 --> Utf8 Class Initialized
INFO - 2018-11-21 04:06:57 --> Utf8 Class Initialized
INFO - 2018-11-21 04:06:57 --> URI Class Initialized
INFO - 2018-11-21 04:06:57 --> URI Class Initialized
INFO - 2018-11-21 04:06:57 --> Router Class Initialized
INFO - 2018-11-21 04:06:57 --> Router Class Initialized
INFO - 2018-11-21 04:06:57 --> Output Class Initialized
INFO - 2018-11-21 04:06:57 --> Output Class Initialized
INFO - 2018-11-21 04:06:57 --> Security Class Initialized
INFO - 2018-11-21 04:06:57 --> Security Class Initialized
DEBUG - 2018-11-21 04:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-21 04:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:06:57 --> Input Class Initialized
INFO - 2018-11-21 04:06:57 --> Language Class Initialized
INFO - 2018-11-21 04:06:57 --> Input Class Initialized
INFO - 2018-11-21 04:06:57 --> Language Class Initialized
INFO - 2018-11-21 04:06:57 --> Loader Class Initialized
INFO - 2018-11-21 04:06:57 --> Helper loaded: url_helper
INFO - 2018-11-21 04:06:57 --> Loader Class Initialized
INFO - 2018-11-21 04:06:57 --> Helper loaded: html_helper
INFO - 2018-11-21 04:06:57 --> Helper loaded: form_helper
INFO - 2018-11-21 04:06:57 --> Helper loaded: url_helper
INFO - 2018-11-21 04:06:57 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:06:57 --> Helper loaded: html_helper
INFO - 2018-11-21 04:06:57 --> Helper loaded: date_helper
INFO - 2018-11-21 04:06:57 --> Helper loaded: form_helper
INFO - 2018-11-21 04:06:57 --> Form Validation Class Initialized
INFO - 2018-11-21 04:06:57 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:06:57 --> Email Class Initialized
INFO - 2018-11-21 04:06:57 --> Helper loaded: date_helper
INFO - 2018-11-21 04:06:57 --> Form Validation Class Initialized
DEBUG - 2018-11-21 04:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:06:57 --> Email Class Initialized
INFO - 2018-11-21 04:06:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:06:57 --> Pagination Class Initialized
DEBUG - 2018-11-21 04:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:06:58 --> Database Driver Class Initialized
INFO - 2018-11-21 04:06:58 --> Database Driver Class Initialized
INFO - 2018-11-21 04:06:58 --> Controller Class Initialized
INFO - 2018-11-21 04:06:58 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:06:58 --> Final output sent to browser
DEBUG - 2018-11-21 04:06:58 --> Total execution time: 0.2218
INFO - 2018-11-21 04:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:06:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:06:58 --> Pagination Class Initialized
INFO - 2018-11-21 04:06:58 --> Database Driver Class Initialized
INFO - 2018-11-21 04:06:58 --> Database Driver Class Initialized
INFO - 2018-11-21 04:06:58 --> Controller Class Initialized
INFO - 2018-11-21 04:06:58 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:06:58 --> Final output sent to browser
DEBUG - 2018-11-21 04:06:58 --> Total execution time: 0.2779
INFO - 2018-11-21 04:14:08 --> Config Class Initialized
INFO - 2018-11-21 04:14:08 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:14:08 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:14:08 --> Utf8 Class Initialized
INFO - 2018-11-21 04:14:08 --> URI Class Initialized
INFO - 2018-11-21 04:14:08 --> Router Class Initialized
INFO - 2018-11-21 04:14:08 --> Output Class Initialized
INFO - 2018-11-21 04:14:08 --> Security Class Initialized
DEBUG - 2018-11-21 04:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:14:08 --> Input Class Initialized
INFO - 2018-11-21 04:14:08 --> Language Class Initialized
INFO - 2018-11-21 04:14:08 --> Loader Class Initialized
INFO - 2018-11-21 04:14:08 --> Helper loaded: url_helper
INFO - 2018-11-21 04:14:08 --> Helper loaded: html_helper
INFO - 2018-11-21 04:14:08 --> Helper loaded: form_helper
INFO - 2018-11-21 04:14:08 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:14:08 --> Helper loaded: date_helper
INFO - 2018-11-21 04:14:08 --> Form Validation Class Initialized
INFO - 2018-11-21 04:14:08 --> Email Class Initialized
DEBUG - 2018-11-21 04:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:14:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:14:08 --> Pagination Class Initialized
INFO - 2018-11-21 04:14:08 --> Database Driver Class Initialized
INFO - 2018-11-21 04:14:08 --> Database Driver Class Initialized
INFO - 2018-11-21 04:14:08 --> Controller Class Initialized
DEBUG - 2018-11-21 04:14:08 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-21 04:14:08 --> Helper loaded: inflector_helper
INFO - 2018-11-21 04:14:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-21 04:14:08 --> Final output sent to browser
DEBUG - 2018-11-21 04:14:08 --> Total execution time: 0.1619
INFO - 2018-11-21 04:15:34 --> Config Class Initialized
INFO - 2018-11-21 04:15:34 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:15:34 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:15:34 --> Utf8 Class Initialized
INFO - 2018-11-21 04:15:34 --> URI Class Initialized
INFO - 2018-11-21 04:15:34 --> Router Class Initialized
INFO - 2018-11-21 04:15:34 --> Output Class Initialized
INFO - 2018-11-21 04:15:34 --> Security Class Initialized
DEBUG - 2018-11-21 04:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:15:34 --> Input Class Initialized
INFO - 2018-11-21 04:15:34 --> Language Class Initialized
INFO - 2018-11-21 04:15:34 --> Loader Class Initialized
INFO - 2018-11-21 04:15:34 --> Helper loaded: url_helper
INFO - 2018-11-21 04:15:34 --> Helper loaded: html_helper
INFO - 2018-11-21 04:15:34 --> Helper loaded: form_helper
INFO - 2018-11-21 04:15:34 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:15:34 --> Helper loaded: date_helper
INFO - 2018-11-21 04:15:34 --> Form Validation Class Initialized
INFO - 2018-11-21 04:15:34 --> Email Class Initialized
DEBUG - 2018-11-21 04:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:15:34 --> Pagination Class Initialized
INFO - 2018-11-21 04:15:34 --> Database Driver Class Initialized
INFO - 2018-11-21 04:15:34 --> Database Driver Class Initialized
INFO - 2018-11-21 04:15:34 --> Controller Class Initialized
DEBUG - 2018-11-21 04:15:34 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-21 04:15:34 --> Helper loaded: inflector_helper
INFO - 2018-11-21 04:15:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-21 04:15:34 --> Final output sent to browser
DEBUG - 2018-11-21 04:15:34 --> Total execution time: 0.1252
INFO - 2018-11-21 04:17:10 --> Config Class Initialized
INFO - 2018-11-21 04:17:10 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:17:10 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:17:10 --> Utf8 Class Initialized
INFO - 2018-11-21 04:17:10 --> URI Class Initialized
INFO - 2018-11-21 04:17:10 --> Router Class Initialized
INFO - 2018-11-21 04:17:10 --> Output Class Initialized
INFO - 2018-11-21 04:17:10 --> Security Class Initialized
DEBUG - 2018-11-21 04:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:17:10 --> Input Class Initialized
INFO - 2018-11-21 04:17:10 --> Language Class Initialized
INFO - 2018-11-21 04:17:10 --> Loader Class Initialized
INFO - 2018-11-21 04:17:10 --> Helper loaded: url_helper
INFO - 2018-11-21 04:17:10 --> Helper loaded: html_helper
INFO - 2018-11-21 04:17:10 --> Helper loaded: form_helper
INFO - 2018-11-21 04:17:10 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:17:10 --> Helper loaded: date_helper
INFO - 2018-11-21 04:17:10 --> Form Validation Class Initialized
INFO - 2018-11-21 04:17:10 --> Email Class Initialized
DEBUG - 2018-11-21 04:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:17:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:17:10 --> Pagination Class Initialized
INFO - 2018-11-21 04:17:10 --> Database Driver Class Initialized
INFO - 2018-11-21 04:17:10 --> Database Driver Class Initialized
INFO - 2018-11-21 04:17:10 --> Controller Class Initialized
DEBUG - 2018-11-21 04:17:10 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-21 04:17:10 --> Helper loaded: inflector_helper
INFO - 2018-11-21 04:17:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-21 04:17:10 --> Final output sent to browser
DEBUG - 2018-11-21 04:17:10 --> Total execution time: 0.1721
INFO - 2018-11-21 04:28:17 --> Config Class Initialized
INFO - 2018-11-21 04:28:17 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:28:17 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:28:17 --> Utf8 Class Initialized
INFO - 2018-11-21 04:28:17 --> URI Class Initialized
INFO - 2018-11-21 04:28:17 --> Router Class Initialized
INFO - 2018-11-21 04:28:17 --> Output Class Initialized
INFO - 2018-11-21 04:28:17 --> Security Class Initialized
DEBUG - 2018-11-21 04:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:28:17 --> Input Class Initialized
INFO - 2018-11-21 04:28:17 --> Language Class Initialized
INFO - 2018-11-21 04:28:17 --> Loader Class Initialized
INFO - 2018-11-21 04:28:17 --> Helper loaded: url_helper
INFO - 2018-11-21 04:28:17 --> Helper loaded: html_helper
INFO - 2018-11-21 04:28:17 --> Helper loaded: form_helper
INFO - 2018-11-21 04:28:17 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:28:17 --> Helper loaded: date_helper
INFO - 2018-11-21 04:28:17 --> Form Validation Class Initialized
INFO - 2018-11-21 04:28:17 --> Email Class Initialized
DEBUG - 2018-11-21 04:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:28:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:28:17 --> Pagination Class Initialized
INFO - 2018-11-21 04:28:17 --> Database Driver Class Initialized
INFO - 2018-11-21 04:28:17 --> Database Driver Class Initialized
INFO - 2018-11-21 04:28:17 --> Controller Class Initialized
INFO - 2018-11-21 04:28:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:28:17 --> Final output sent to browser
DEBUG - 2018-11-21 04:28:17 --> Total execution time: 0.1059
INFO - 2018-11-21 04:39:30 --> Config Class Initialized
INFO - 2018-11-21 04:39:30 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:39:30 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:39:30 --> Utf8 Class Initialized
INFO - 2018-11-21 04:39:30 --> URI Class Initialized
INFO - 2018-11-21 04:39:30 --> Router Class Initialized
INFO - 2018-11-21 04:39:30 --> Output Class Initialized
INFO - 2018-11-21 04:39:30 --> Security Class Initialized
DEBUG - 2018-11-21 04:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:39:30 --> Input Class Initialized
INFO - 2018-11-21 04:39:30 --> Language Class Initialized
INFO - 2018-11-21 04:39:30 --> Loader Class Initialized
INFO - 2018-11-21 04:39:30 --> Helper loaded: url_helper
INFO - 2018-11-21 04:39:30 --> Helper loaded: html_helper
INFO - 2018-11-21 04:39:30 --> Helper loaded: form_helper
INFO - 2018-11-21 04:39:30 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:39:30 --> Helper loaded: date_helper
INFO - 2018-11-21 04:39:30 --> Form Validation Class Initialized
INFO - 2018-11-21 04:39:30 --> Email Class Initialized
DEBUG - 2018-11-21 04:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:39:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:39:30 --> Pagination Class Initialized
INFO - 2018-11-21 04:39:31 --> Database Driver Class Initialized
INFO - 2018-11-21 04:39:31 --> Database Driver Class Initialized
INFO - 2018-11-21 04:39:31 --> Controller Class Initialized
DEBUG - 2018-11-21 04:39:31 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-21 04:39:31 --> Helper loaded: inflector_helper
INFO - 2018-11-21 04:39:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-21 04:39:31 --> Final output sent to browser
DEBUG - 2018-11-21 04:39:31 --> Total execution time: 0.1393
INFO - 2018-11-21 04:39:35 --> Config Class Initialized
INFO - 2018-11-21 04:39:35 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:39:35 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:39:35 --> Utf8 Class Initialized
INFO - 2018-11-21 04:39:35 --> URI Class Initialized
INFO - 2018-11-21 04:39:35 --> Router Class Initialized
INFO - 2018-11-21 04:39:35 --> Output Class Initialized
INFO - 2018-11-21 04:39:35 --> Security Class Initialized
DEBUG - 2018-11-21 04:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:39:35 --> Input Class Initialized
INFO - 2018-11-21 04:39:35 --> Language Class Initialized
INFO - 2018-11-21 04:39:35 --> Loader Class Initialized
INFO - 2018-11-21 04:39:35 --> Helper loaded: url_helper
INFO - 2018-11-21 04:39:35 --> Helper loaded: html_helper
INFO - 2018-11-21 04:39:35 --> Helper loaded: form_helper
INFO - 2018-11-21 04:39:35 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:39:35 --> Helper loaded: date_helper
INFO - 2018-11-21 04:39:35 --> Form Validation Class Initialized
INFO - 2018-11-21 04:39:35 --> Email Class Initialized
DEBUG - 2018-11-21 04:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:39:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:39:35 --> Pagination Class Initialized
INFO - 2018-11-21 04:39:35 --> Database Driver Class Initialized
INFO - 2018-11-21 04:39:35 --> Database Driver Class Initialized
INFO - 2018-11-21 04:39:35 --> Controller Class Initialized
DEBUG - 2018-11-21 04:39:35 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-11-21 04:39:35 --> Helper loaded: inflector_helper
INFO - 2018-11-21 04:39:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-11-21 04:39:35 --> Final output sent to browser
DEBUG - 2018-11-21 04:39:35 --> Total execution time: 0.1603
INFO - 2018-11-21 04:41:19 --> Config Class Initialized
INFO - 2018-11-21 04:41:19 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:41:19 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:41:19 --> Utf8 Class Initialized
INFO - 2018-11-21 04:41:19 --> URI Class Initialized
INFO - 2018-11-21 04:41:19 --> Router Class Initialized
INFO - 2018-11-21 04:41:19 --> Output Class Initialized
INFO - 2018-11-21 04:41:19 --> Security Class Initialized
DEBUG - 2018-11-21 04:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:41:19 --> Input Class Initialized
INFO - 2018-11-21 04:41:19 --> Language Class Initialized
INFO - 2018-11-21 04:41:19 --> Loader Class Initialized
INFO - 2018-11-21 04:41:19 --> Helper loaded: url_helper
INFO - 2018-11-21 04:41:19 --> Helper loaded: html_helper
INFO - 2018-11-21 04:41:19 --> Helper loaded: form_helper
INFO - 2018-11-21 04:41:19 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:41:19 --> Helper loaded: date_helper
INFO - 2018-11-21 04:41:19 --> Form Validation Class Initialized
INFO - 2018-11-21 04:41:19 --> Email Class Initialized
DEBUG - 2018-11-21 04:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:41:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:41:19 --> Pagination Class Initialized
INFO - 2018-11-21 04:41:19 --> Database Driver Class Initialized
INFO - 2018-11-21 04:41:19 --> Database Driver Class Initialized
INFO - 2018-11-21 04:41:19 --> Controller Class Initialized
INFO - 2018-11-21 04:41:19 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-21 04:41:19 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/folio.php
INFO - 2018-11-21 04:41:19 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-21 04:41:19 --> Final output sent to browser
DEBUG - 2018-11-21 04:41:19 --> Total execution time: 0.2615
INFO - 2018-11-21 04:41:19 --> Config Class Initialized
INFO - 2018-11-21 04:41:19 --> Config Class Initialized
INFO - 2018-11-21 04:41:19 --> Hooks Class Initialized
INFO - 2018-11-21 04:41:19 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:41:19 --> UTF-8 Support Enabled
DEBUG - 2018-11-21 04:41:19 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:41:19 --> Utf8 Class Initialized
INFO - 2018-11-21 04:41:19 --> Utf8 Class Initialized
INFO - 2018-11-21 04:41:19 --> URI Class Initialized
INFO - 2018-11-21 04:41:19 --> URI Class Initialized
INFO - 2018-11-21 04:41:19 --> Router Class Initialized
INFO - 2018-11-21 04:41:19 --> Router Class Initialized
INFO - 2018-11-21 04:41:19 --> Output Class Initialized
INFO - 2018-11-21 04:41:19 --> Output Class Initialized
INFO - 2018-11-21 04:41:19 --> Security Class Initialized
INFO - 2018-11-21 04:41:19 --> Security Class Initialized
DEBUG - 2018-11-21 04:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-21 04:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:41:19 --> Input Class Initialized
INFO - 2018-11-21 04:41:19 --> Input Class Initialized
INFO - 2018-11-21 04:41:19 --> Language Class Initialized
INFO - 2018-11-21 04:41:20 --> Language Class Initialized
INFO - 2018-11-21 04:41:20 --> Loader Class Initialized
INFO - 2018-11-21 04:41:20 --> Loader Class Initialized
INFO - 2018-11-21 04:41:20 --> Helper loaded: url_helper
INFO - 2018-11-21 04:41:20 --> Helper loaded: url_helper
INFO - 2018-11-21 04:41:20 --> Helper loaded: html_helper
INFO - 2018-11-21 04:41:20 --> Helper loaded: html_helper
INFO - 2018-11-21 04:41:20 --> Helper loaded: form_helper
INFO - 2018-11-21 04:41:20 --> Helper loaded: form_helper
INFO - 2018-11-21 04:41:20 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:41:20 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:41:20 --> Helper loaded: date_helper
INFO - 2018-11-21 04:41:20 --> Helper loaded: date_helper
INFO - 2018-11-21 04:41:20 --> Form Validation Class Initialized
INFO - 2018-11-21 04:41:20 --> Form Validation Class Initialized
INFO - 2018-11-21 04:41:20 --> Email Class Initialized
INFO - 2018-11-21 04:41:20 --> Email Class Initialized
DEBUG - 2018-11-21 04:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-21 04:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:41:20 --> Pagination Class Initialized
INFO - 2018-11-21 04:41:20 --> Database Driver Class Initialized
INFO - 2018-11-21 04:41:20 --> Database Driver Class Initialized
INFO - 2018-11-21 04:41:20 --> Controller Class Initialized
INFO - 2018-11-21 04:41:20 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:41:20 --> Final output sent to browser
DEBUG - 2018-11-21 04:41:20 --> Total execution time: 0.1918
INFO - 2018-11-21 04:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:41:20 --> Pagination Class Initialized
INFO - 2018-11-21 04:41:20 --> Database Driver Class Initialized
INFO - 2018-11-21 04:41:20 --> Database Driver Class Initialized
INFO - 2018-11-21 04:41:20 --> Controller Class Initialized
INFO - 2018-11-21 04:41:20 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:41:20 --> Final output sent to browser
DEBUG - 2018-11-21 04:41:20 --> Total execution time: 0.2595
INFO - 2018-11-21 04:44:58 --> Config Class Initialized
INFO - 2018-11-21 04:44:58 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:44:58 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:44:58 --> Utf8 Class Initialized
INFO - 2018-11-21 04:44:58 --> URI Class Initialized
INFO - 2018-11-21 04:44:58 --> Router Class Initialized
INFO - 2018-11-21 04:44:58 --> Output Class Initialized
INFO - 2018-11-21 04:44:58 --> Security Class Initialized
DEBUG - 2018-11-21 04:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:44:58 --> Input Class Initialized
INFO - 2018-11-21 04:44:58 --> Language Class Initialized
INFO - 2018-11-21 04:44:58 --> Loader Class Initialized
INFO - 2018-11-21 04:44:58 --> Helper loaded: url_helper
INFO - 2018-11-21 04:44:58 --> Helper loaded: html_helper
INFO - 2018-11-21 04:44:58 --> Helper loaded: form_helper
INFO - 2018-11-21 04:44:58 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:44:58 --> Helper loaded: date_helper
INFO - 2018-11-21 04:44:58 --> Form Validation Class Initialized
INFO - 2018-11-21 04:44:58 --> Email Class Initialized
DEBUG - 2018-11-21 04:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:44:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:44:58 --> Pagination Class Initialized
INFO - 2018-11-21 04:44:58 --> Database Driver Class Initialized
INFO - 2018-11-21 04:44:58 --> Database Driver Class Initialized
INFO - 2018-11-21 04:44:58 --> Controller Class Initialized
INFO - 2018-11-21 04:44:58 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:44:58 --> Final output sent to browser
DEBUG - 2018-11-21 04:44:58 --> Total execution time: 0.1251
INFO - 2018-11-21 04:44:59 --> Config Class Initialized
INFO - 2018-11-21 04:44:59 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:44:59 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:00 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:00 --> URI Class Initialized
INFO - 2018-11-21 04:45:00 --> Router Class Initialized
INFO - 2018-11-21 04:45:00 --> Output Class Initialized
INFO - 2018-11-21 04:45:00 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:00 --> Input Class Initialized
INFO - 2018-11-21 04:45:00 --> Language Class Initialized
INFO - 2018-11-21 04:45:00 --> Loader Class Initialized
INFO - 2018-11-21 04:45:00 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:00 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:00 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:00 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:00 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:00 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:00 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:00 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:00 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:00 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:00 --> Controller Class Initialized
INFO - 2018-11-21 04:45:00 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:45:00 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:00 --> Total execution time: 0.1247
INFO - 2018-11-21 04:45:01 --> Config Class Initialized
INFO - 2018-11-21 04:45:01 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:45:01 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:01 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:01 --> URI Class Initialized
INFO - 2018-11-21 04:45:01 --> Router Class Initialized
INFO - 2018-11-21 04:45:01 --> Output Class Initialized
INFO - 2018-11-21 04:45:01 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:01 --> Input Class Initialized
INFO - 2018-11-21 04:45:01 --> Language Class Initialized
INFO - 2018-11-21 04:45:01 --> Loader Class Initialized
INFO - 2018-11-21 04:45:01 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:01 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:01 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:01 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:01 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:01 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:01 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:01 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:01 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:01 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:01 --> Controller Class Initialized
INFO - 2018-11-21 04:45:01 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-21 04:45:01 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/account_type.php
INFO - 2018-11-21 04:45:01 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-21 04:45:01 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:01 --> Total execution time: 0.1462
INFO - 2018-11-21 04:45:01 --> Config Class Initialized
INFO - 2018-11-21 04:45:01 --> Config Class Initialized
INFO - 2018-11-21 04:45:01 --> Hooks Class Initialized
INFO - 2018-11-21 04:45:01 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:45:01 --> UTF-8 Support Enabled
DEBUG - 2018-11-21 04:45:01 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:01 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:01 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:01 --> URI Class Initialized
INFO - 2018-11-21 04:45:01 --> URI Class Initialized
INFO - 2018-11-21 04:45:01 --> Router Class Initialized
INFO - 2018-11-21 04:45:01 --> Router Class Initialized
INFO - 2018-11-21 04:45:01 --> Output Class Initialized
INFO - 2018-11-21 04:45:01 --> Output Class Initialized
INFO - 2018-11-21 04:45:01 --> Security Class Initialized
INFO - 2018-11-21 04:45:01 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:01 --> Input Class Initialized
DEBUG - 2018-11-21 04:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:01 --> Input Class Initialized
INFO - 2018-11-21 04:45:01 --> Language Class Initialized
INFO - 2018-11-21 04:45:01 --> Language Class Initialized
INFO - 2018-11-21 04:45:01 --> Loader Class Initialized
INFO - 2018-11-21 04:45:01 --> Loader Class Initialized
INFO - 2018-11-21 04:45:01 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:01 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:01 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:01 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:01 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:01 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:01 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:01 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:01 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:01 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:01 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:01 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:01 --> Email Class Initialized
INFO - 2018-11-21 04:45:01 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-21 04:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:01 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:01 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:01 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:01 --> Controller Class Initialized
INFO - 2018-11-21 04:45:01 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:45:01 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:01 --> Total execution time: 0.1460
INFO - 2018-11-21 04:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:01 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:01 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:01 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:01 --> Controller Class Initialized
INFO - 2018-11-21 04:45:01 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:45:01 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:01 --> Total execution time: 0.2057
INFO - 2018-11-21 04:45:01 --> Config Class Initialized
INFO - 2018-11-21 04:45:01 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:45:01 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:01 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:01 --> URI Class Initialized
INFO - 2018-11-21 04:45:01 --> Router Class Initialized
INFO - 2018-11-21 04:45:01 --> Output Class Initialized
INFO - 2018-11-21 04:45:01 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:01 --> Input Class Initialized
INFO - 2018-11-21 04:45:01 --> Language Class Initialized
INFO - 2018-11-21 04:45:01 --> Loader Class Initialized
INFO - 2018-11-21 04:45:01 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:01 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:01 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:01 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:01 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:01 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:02 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:02 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:02 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:02 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:02 --> Controller Class Initialized
INFO - 2018-11-21 04:45:02 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:02 --> Total execution time: 0.1262
INFO - 2018-11-21 04:45:07 --> Config Class Initialized
INFO - 2018-11-21 04:45:07 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:45:07 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:07 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:07 --> URI Class Initialized
INFO - 2018-11-21 04:45:07 --> Router Class Initialized
INFO - 2018-11-21 04:45:07 --> Output Class Initialized
INFO - 2018-11-21 04:45:07 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:07 --> Input Class Initialized
INFO - 2018-11-21 04:45:07 --> Language Class Initialized
INFO - 2018-11-21 04:45:07 --> Loader Class Initialized
INFO - 2018-11-21 04:45:07 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:07 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:07 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:07 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:07 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:07 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:07 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:07 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:07 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:07 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:07 --> Controller Class Initialized
INFO - 2018-11-21 04:45:07 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-21 04:45:07 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/account_payment.php
INFO - 2018-11-21 04:45:07 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-21 04:45:07 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:07 --> Total execution time: 0.1134
INFO - 2018-11-21 04:45:07 --> Config Class Initialized
INFO - 2018-11-21 04:45:07 --> Config Class Initialized
INFO - 2018-11-21 04:45:07 --> Hooks Class Initialized
INFO - 2018-11-21 04:45:07 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:45:07 --> UTF-8 Support Enabled
DEBUG - 2018-11-21 04:45:07 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:07 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:07 --> URI Class Initialized
INFO - 2018-11-21 04:45:07 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:07 --> URI Class Initialized
INFO - 2018-11-21 04:45:07 --> Router Class Initialized
INFO - 2018-11-21 04:45:07 --> Router Class Initialized
INFO - 2018-11-21 04:45:07 --> Output Class Initialized
INFO - 2018-11-21 04:45:07 --> Output Class Initialized
INFO - 2018-11-21 04:45:07 --> Security Class Initialized
INFO - 2018-11-21 04:45:07 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-21 04:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:07 --> Input Class Initialized
INFO - 2018-11-21 04:45:07 --> Input Class Initialized
INFO - 2018-11-21 04:45:07 --> Language Class Initialized
INFO - 2018-11-21 04:45:07 --> Language Class Initialized
INFO - 2018-11-21 04:45:07 --> Loader Class Initialized
INFO - 2018-11-21 04:45:07 --> Loader Class Initialized
INFO - 2018-11-21 04:45:07 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:07 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:07 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:07 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:07 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:07 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:07 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:07 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:07 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:07 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:07 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:07 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:07 --> Email Class Initialized
INFO - 2018-11-21 04:45:07 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-21 04:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:07 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:07 --> Config Class Initialized
INFO - 2018-11-21 04:45:07 --> Hooks Class Initialized
INFO - 2018-11-21 04:45:07 --> Database Driver Class Initialized
DEBUG - 2018-11-21 04:45:07 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:07 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:07 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:07 --> URI Class Initialized
INFO - 2018-11-21 04:45:07 --> Router Class Initialized
INFO - 2018-11-21 04:45:07 --> Controller Class Initialized
INFO - 2018-11-21 04:45:07 --> Output Class Initialized
INFO - 2018-11-21 04:45:08 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:08 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:45:08 --> Input Class Initialized
INFO - 2018-11-21 04:45:08 --> Language Class Initialized
INFO - 2018-11-21 04:45:08 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:08 --> Total execution time: 0.1809
INFO - 2018-11-21 04:45:08 --> Loader Class Initialized
INFO - 2018-11-21 04:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:08 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:08 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:08 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:08 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:08 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:08 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:08 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:08 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:08 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:08 --> Email Class Initialized
INFO - 2018-11-21 04:45:08 --> Controller Class Initialized
DEBUG - 2018-11-21 04:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:08 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:45:08 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:08 --> Total execution time: 0.2341
INFO - 2018-11-21 04:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:08 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:08 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:08 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:08 --> Controller Class Initialized
INFO - 2018-11-21 04:45:08 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:08 --> Total execution time: 0.1794
INFO - 2018-11-21 04:45:11 --> Config Class Initialized
INFO - 2018-11-21 04:45:11 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:45:11 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:11 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:11 --> URI Class Initialized
INFO - 2018-11-21 04:45:11 --> Router Class Initialized
INFO - 2018-11-21 04:45:11 --> Output Class Initialized
INFO - 2018-11-21 04:45:11 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:11 --> Input Class Initialized
INFO - 2018-11-21 04:45:11 --> Language Class Initialized
INFO - 2018-11-21 04:45:11 --> Loader Class Initialized
INFO - 2018-11-21 04:45:11 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:11 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:11 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:11 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:11 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:11 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:11 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:11 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:11 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:11 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:11 --> Controller Class Initialized
INFO - 2018-11-21 04:45:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-21 04:45:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/account_sale.php
INFO - 2018-11-21 04:45:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-21 04:45:11 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:11 --> Total execution time: 0.1206
INFO - 2018-11-21 04:45:11 --> Config Class Initialized
INFO - 2018-11-21 04:45:11 --> Config Class Initialized
INFO - 2018-11-21 04:45:11 --> Hooks Class Initialized
INFO - 2018-11-21 04:45:11 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:45:11 --> UTF-8 Support Enabled
DEBUG - 2018-11-21 04:45:11 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:11 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:11 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:11 --> URI Class Initialized
INFO - 2018-11-21 04:45:11 --> URI Class Initialized
INFO - 2018-11-21 04:45:11 --> Router Class Initialized
INFO - 2018-11-21 04:45:11 --> Router Class Initialized
INFO - 2018-11-21 04:45:11 --> Output Class Initialized
INFO - 2018-11-21 04:45:11 --> Output Class Initialized
INFO - 2018-11-21 04:45:11 --> Security Class Initialized
INFO - 2018-11-21 04:45:11 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-21 04:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:11 --> Input Class Initialized
INFO - 2018-11-21 04:45:11 --> Input Class Initialized
INFO - 2018-11-21 04:45:11 --> Language Class Initialized
INFO - 2018-11-21 04:45:11 --> Language Class Initialized
INFO - 2018-11-21 04:45:11 --> Loader Class Initialized
INFO - 2018-11-21 04:45:11 --> Loader Class Initialized
INFO - 2018-11-21 04:45:11 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:11 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:11 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:11 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:11 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:11 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:11 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:11 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:11 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:11 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:11 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:11 --> Config Class Initialized
INFO - 2018-11-21 04:45:11 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:11 --> Hooks Class Initialized
INFO - 2018-11-21 04:45:11 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:11 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:11 --> Email Class Initialized
INFO - 2018-11-21 04:45:11 --> Utf8 Class Initialized
DEBUG - 2018-11-21 04:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:11 --> URI Class Initialized
INFO - 2018-11-21 04:45:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-11-21 04:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:11 --> Router Class Initialized
INFO - 2018-11-21 04:45:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:11 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:11 --> Output Class Initialized
INFO - 2018-11-21 04:45:11 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:11 --> Input Class Initialized
INFO - 2018-11-21 04:45:11 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:11 --> Language Class Initialized
INFO - 2018-11-21 04:45:11 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:11 --> Loader Class Initialized
INFO - 2018-11-21 04:45:11 --> Controller Class Initialized
INFO - 2018-11-21 04:45:11 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:11 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:11 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:11 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:45:11 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:11 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:11 --> Total execution time: 0.1609
INFO - 2018-11-21 04:45:11 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:11 --> Email Class Initialized
INFO - 2018-11-21 04:45:11 --> Pagination Class Initialized
DEBUG - 2018-11-21 04:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:11 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:11 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:11 --> Controller Class Initialized
INFO - 2018-11-21 04:45:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:45:11 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:11 --> Total execution time: 0.2055
INFO - 2018-11-21 04:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:11 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:11 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:11 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:11 --> Controller Class Initialized
INFO - 2018-11-21 04:45:11 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:11 --> Total execution time: 0.1718
INFO - 2018-11-21 04:45:23 --> Config Class Initialized
INFO - 2018-11-21 04:45:23 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:45:23 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:23 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:23 --> URI Class Initialized
INFO - 2018-11-21 04:45:23 --> Router Class Initialized
INFO - 2018-11-21 04:45:23 --> Output Class Initialized
INFO - 2018-11-21 04:45:23 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:23 --> Input Class Initialized
INFO - 2018-11-21 04:45:23 --> Language Class Initialized
INFO - 2018-11-21 04:45:23 --> Loader Class Initialized
INFO - 2018-11-21 04:45:23 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:23 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:23 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:23 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:23 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:23 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:23 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:23 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:23 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:23 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:23 --> Controller Class Initialized
INFO - 2018-11-21 04:45:23 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-21 04:45:23 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/account_plu_group.php
INFO - 2018-11-21 04:45:23 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-21 04:45:23 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:23 --> Total execution time: 0.1119
INFO - 2018-11-21 04:45:23 --> Config Class Initialized
INFO - 2018-11-21 04:45:23 --> Config Class Initialized
INFO - 2018-11-21 04:45:23 --> Hooks Class Initialized
INFO - 2018-11-21 04:45:23 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:45:23 --> UTF-8 Support Enabled
DEBUG - 2018-11-21 04:45:23 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:23 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:23 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:23 --> URI Class Initialized
INFO - 2018-11-21 04:45:23 --> URI Class Initialized
INFO - 2018-11-21 04:45:23 --> Router Class Initialized
INFO - 2018-11-21 04:45:23 --> Router Class Initialized
INFO - 2018-11-21 04:45:23 --> Output Class Initialized
INFO - 2018-11-21 04:45:23 --> Output Class Initialized
INFO - 2018-11-21 04:45:23 --> Security Class Initialized
INFO - 2018-11-21 04:45:23 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-21 04:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:23 --> Input Class Initialized
INFO - 2018-11-21 04:45:23 --> Input Class Initialized
INFO - 2018-11-21 04:45:23 --> Language Class Initialized
INFO - 2018-11-21 04:45:23 --> Language Class Initialized
INFO - 2018-11-21 04:45:23 --> Loader Class Initialized
INFO - 2018-11-21 04:45:23 --> Loader Class Initialized
INFO - 2018-11-21 04:45:23 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:23 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:23 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:23 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:23 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:23 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:23 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:23 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:23 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:23 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:23 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:23 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:23 --> Email Class Initialized
INFO - 2018-11-21 04:45:23 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-11-21 04:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:23 --> Config Class Initialized
INFO - 2018-11-21 04:45:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:23 --> Hooks Class Initialized
INFO - 2018-11-21 04:45:23 --> Pagination Class Initialized
DEBUG - 2018-11-21 04:45:23 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:23 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:23 --> URI Class Initialized
INFO - 2018-11-21 04:45:23 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:23 --> Router Class Initialized
INFO - 2018-11-21 04:45:23 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:23 --> Output Class Initialized
INFO - 2018-11-21 04:45:23 --> Security Class Initialized
INFO - 2018-11-21 04:45:23 --> Controller Class Initialized
DEBUG - 2018-11-21 04:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:23 --> Input Class Initialized
INFO - 2018-11-21 04:45:23 --> Language Class Initialized
INFO - 2018-11-21 04:45:23 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:45:23 --> Final output sent to browser
INFO - 2018-11-21 04:45:23 --> Loader Class Initialized
DEBUG - 2018-11-21 04:45:23 --> Total execution time: 0.1533
INFO - 2018-11-21 04:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:23 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:23 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:23 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:23 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:23 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:23 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:23 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:23 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:23 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:23 --> Email Class Initialized
INFO - 2018-11-21 04:45:23 --> Controller Class Initialized
DEBUG - 2018-11-21 04:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:23 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:45:23 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:23 --> Total execution time: 0.2058
INFO - 2018-11-21 04:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:23 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:23 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:23 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:23 --> Controller Class Initialized
INFO - 2018-11-21 04:45:23 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:23 --> Total execution time: 0.1661
INFO - 2018-11-21 04:45:33 --> Config Class Initialized
INFO - 2018-11-21 04:45:33 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:45:33 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:33 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:33 --> URI Class Initialized
INFO - 2018-11-21 04:45:33 --> Router Class Initialized
INFO - 2018-11-21 04:45:33 --> Output Class Initialized
INFO - 2018-11-21 04:45:33 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:33 --> Input Class Initialized
INFO - 2018-11-21 04:45:33 --> Language Class Initialized
INFO - 2018-11-21 04:45:33 --> Loader Class Initialized
INFO - 2018-11-21 04:45:33 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:33 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:33 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:33 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:33 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:33 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:33 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:33 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:33 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:33 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:33 --> Controller Class Initialized
INFO - 2018-11-21 04:45:33 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-21 04:45:33 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/account_plu_number.php
INFO - 2018-11-21 04:45:33 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-21 04:45:33 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:33 --> Total execution time: 0.1482
INFO - 2018-11-21 04:45:34 --> Config Class Initialized
INFO - 2018-11-21 04:45:34 --> Config Class Initialized
INFO - 2018-11-21 04:45:34 --> Hooks Class Initialized
INFO - 2018-11-21 04:45:34 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:45:34 --> UTF-8 Support Enabled
DEBUG - 2018-11-21 04:45:34 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:34 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:34 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:34 --> URI Class Initialized
INFO - 2018-11-21 04:45:34 --> URI Class Initialized
INFO - 2018-11-21 04:45:34 --> Router Class Initialized
INFO - 2018-11-21 04:45:34 --> Router Class Initialized
INFO - 2018-11-21 04:45:34 --> Output Class Initialized
INFO - 2018-11-21 04:45:34 --> Output Class Initialized
INFO - 2018-11-21 04:45:34 --> Security Class Initialized
INFO - 2018-11-21 04:45:34 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-21 04:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:34 --> Input Class Initialized
INFO - 2018-11-21 04:45:34 --> Input Class Initialized
INFO - 2018-11-21 04:45:34 --> Language Class Initialized
INFO - 2018-11-21 04:45:34 --> Language Class Initialized
INFO - 2018-11-21 04:45:34 --> Loader Class Initialized
INFO - 2018-11-21 04:45:34 --> Loader Class Initialized
INFO - 2018-11-21 04:45:34 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:34 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:34 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:34 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:34 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:34 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:34 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:34 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:34 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:34 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:34 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:34 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:34 --> Email Class Initialized
INFO - 2018-11-21 04:45:34 --> Email Class Initialized
INFO - 2018-11-21 04:45:34 --> Config Class Initialized
INFO - 2018-11-21 04:45:34 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-21 04:45:34 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-11-21 04:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:34 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:34 --> URI Class Initialized
INFO - 2018-11-21 04:45:34 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:34 --> Router Class Initialized
INFO - 2018-11-21 04:45:34 --> Output Class Initialized
INFO - 2018-11-21 04:45:34 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:34 --> Security Class Initialized
INFO - 2018-11-21 04:45:34 --> Database Driver Class Initialized
DEBUG - 2018-11-21 04:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:34 --> Input Class Initialized
INFO - 2018-11-21 04:45:34 --> Language Class Initialized
INFO - 2018-11-21 04:45:34 --> Controller Class Initialized
INFO - 2018-11-21 04:45:34 --> Loader Class Initialized
INFO - 2018-11-21 04:45:34 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:34 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:45:34 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:34 --> Final output sent to browser
INFO - 2018-11-21 04:45:34 --> Helper loaded: form_helper
DEBUG - 2018-11-21 04:45:34 --> Total execution time: 0.1851
INFO - 2018-11-21 04:45:34 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:34 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:34 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:34 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:34 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:34 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:34 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:34 --> Controller Class Initialized
INFO - 2018-11-21 04:45:34 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:45:34 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:34 --> Total execution time: 0.2457
INFO - 2018-11-21 04:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:34 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:34 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:34 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:34 --> Controller Class Initialized
INFO - 2018-11-21 04:45:34 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:34 --> Total execution time: 0.1896
INFO - 2018-11-21 04:45:41 --> Config Class Initialized
INFO - 2018-11-21 04:45:41 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:45:41 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:41 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:41 --> URI Class Initialized
INFO - 2018-11-21 04:45:41 --> Router Class Initialized
INFO - 2018-11-21 04:45:41 --> Output Class Initialized
INFO - 2018-11-21 04:45:41 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:41 --> Input Class Initialized
INFO - 2018-11-21 04:45:41 --> Language Class Initialized
INFO - 2018-11-21 04:45:41 --> Loader Class Initialized
INFO - 2018-11-21 04:45:41 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:41 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:41 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:41 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:41 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:41 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:41 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:41 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:41 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:41 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:41 --> Controller Class Initialized
INFO - 2018-11-21 04:45:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-21 04:45:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/account_class.php
INFO - 2018-11-21 04:45:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-21 04:45:41 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:41 --> Total execution time: 0.1213
INFO - 2018-11-21 04:45:41 --> Config Class Initialized
INFO - 2018-11-21 04:45:41 --> Config Class Initialized
INFO - 2018-11-21 04:45:41 --> Hooks Class Initialized
INFO - 2018-11-21 04:45:41 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:45:41 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:41 --> Utf8 Class Initialized
DEBUG - 2018-11-21 04:45:41 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:41 --> URI Class Initialized
INFO - 2018-11-21 04:45:41 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:41 --> URI Class Initialized
INFO - 2018-11-21 04:45:41 --> Router Class Initialized
INFO - 2018-11-21 04:45:41 --> Router Class Initialized
INFO - 2018-11-21 04:45:41 --> Output Class Initialized
INFO - 2018-11-21 04:45:41 --> Output Class Initialized
INFO - 2018-11-21 04:45:41 --> Security Class Initialized
INFO - 2018-11-21 04:45:41 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-21 04:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:41 --> Input Class Initialized
INFO - 2018-11-21 04:45:41 --> Input Class Initialized
INFO - 2018-11-21 04:45:41 --> Language Class Initialized
INFO - 2018-11-21 04:45:41 --> Language Class Initialized
INFO - 2018-11-21 04:45:41 --> Loader Class Initialized
INFO - 2018-11-21 04:45:41 --> Loader Class Initialized
INFO - 2018-11-21 04:45:41 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:41 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:41 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:41 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:41 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:41 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:41 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:41 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:41 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:41 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:41 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:41 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:41 --> Email Class Initialized
INFO - 2018-11-21 04:45:41 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-21 04:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:41 --> Config Class Initialized
INFO - 2018-11-21 04:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:41 --> Hooks Class Initialized
INFO - 2018-11-21 04:45:41 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2018-11-21 04:45:41 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:41 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:41 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:41 --> URI Class Initialized
INFO - 2018-11-21 04:45:41 --> Router Class Initialized
INFO - 2018-11-21 04:45:41 --> Output Class Initialized
INFO - 2018-11-21 04:45:41 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:41 --> Security Class Initialized
INFO - 2018-11-21 04:45:41 --> Database Driver Class Initialized
DEBUG - 2018-11-21 04:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:41 --> Input Class Initialized
INFO - 2018-11-21 04:45:41 --> Language Class Initialized
INFO - 2018-11-21 04:45:41 --> Controller Class Initialized
INFO - 2018-11-21 04:45:41 --> Loader Class Initialized
INFO - 2018-11-21 04:45:41 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:45:41 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:41 --> Final output sent to browser
INFO - 2018-11-21 04:45:41 --> Helper loaded: form_helper
DEBUG - 2018-11-21 04:45:41 --> Total execution time: 0.1739
INFO - 2018-11-21 04:45:41 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:41 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:41 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:41 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:41 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:41 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:41 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:41 --> Controller Class Initialized
INFO - 2018-11-21 04:45:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:45:41 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:41 --> Total execution time: 0.2178
INFO - 2018-11-21 04:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:41 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:41 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:41 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:41 --> Controller Class Initialized
INFO - 2018-11-21 04:45:41 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:41 --> Total execution time: 0.1553
INFO - 2018-11-21 04:45:44 --> Config Class Initialized
INFO - 2018-11-21 04:45:44 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:45:44 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:44 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:44 --> URI Class Initialized
INFO - 2018-11-21 04:45:44 --> Router Class Initialized
INFO - 2018-11-21 04:45:44 --> Output Class Initialized
INFO - 2018-11-21 04:45:44 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:44 --> Input Class Initialized
INFO - 2018-11-21 04:45:44 --> Language Class Initialized
INFO - 2018-11-21 04:45:44 --> Loader Class Initialized
INFO - 2018-11-21 04:45:44 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:44 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:44 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:44 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:44 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:44 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:44 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:44 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:44 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:44 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:44 --> Controller Class Initialized
INFO - 2018-11-21 04:45:44 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-21 04:45:44 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/account_type.php
INFO - 2018-11-21 04:45:44 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-21 04:45:44 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:44 --> Total execution time: 0.1193
INFO - 2018-11-21 04:45:44 --> Config Class Initialized
INFO - 2018-11-21 04:45:44 --> Config Class Initialized
INFO - 2018-11-21 04:45:44 --> Hooks Class Initialized
INFO - 2018-11-21 04:45:44 --> Hooks Class Initialized
DEBUG - 2018-11-21 04:45:44 --> UTF-8 Support Enabled
DEBUG - 2018-11-21 04:45:44 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:44 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:44 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:44 --> URI Class Initialized
INFO - 2018-11-21 04:45:44 --> URI Class Initialized
INFO - 2018-11-21 04:45:44 --> Router Class Initialized
INFO - 2018-11-21 04:45:44 --> Router Class Initialized
INFO - 2018-11-21 04:45:44 --> Output Class Initialized
INFO - 2018-11-21 04:45:44 --> Output Class Initialized
INFO - 2018-11-21 04:45:44 --> Security Class Initialized
INFO - 2018-11-21 04:45:44 --> Security Class Initialized
DEBUG - 2018-11-21 04:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-21 04:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:44 --> Input Class Initialized
INFO - 2018-11-21 04:45:44 --> Input Class Initialized
INFO - 2018-11-21 04:45:44 --> Language Class Initialized
INFO - 2018-11-21 04:45:44 --> Language Class Initialized
INFO - 2018-11-21 04:45:44 --> Loader Class Initialized
INFO - 2018-11-21 04:45:44 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:44 --> Loader Class Initialized
INFO - 2018-11-21 04:45:44 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:44 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:44 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:44 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:44 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:44 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:44 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:44 --> Helper loaded: cookie_helper
INFO - 2018-11-21 04:45:44 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:44 --> Config Class Initialized
INFO - 2018-11-21 04:45:44 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:44 --> Hooks Class Initialized
INFO - 2018-11-21 04:45:44 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:44 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:44 --> UTF-8 Support Enabled
INFO - 2018-11-21 04:45:44 --> Utf8 Class Initialized
INFO - 2018-11-21 04:45:44 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-11-21 04:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:44 --> URI Class Initialized
INFO - 2018-11-21 04:45:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:44 --> Router Class Initialized
INFO - 2018-11-21 04:45:44 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:44 --> Output Class Initialized
INFO - 2018-11-21 04:45:44 --> Security Class Initialized
INFO - 2018-11-21 04:45:44 --> Database Driver Class Initialized
DEBUG - 2018-11-21 04:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 04:45:44 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:44 --> Input Class Initialized
INFO - 2018-11-21 04:45:44 --> Language Class Initialized
INFO - 2018-11-21 04:45:44 --> Controller Class Initialized
INFO - 2018-11-21 04:45:44 --> Loader Class Initialized
INFO - 2018-11-21 04:45:44 --> Helper loaded: url_helper
INFO - 2018-11-21 04:45:44 --> Helper loaded: html_helper
INFO - 2018-11-21 04:45:44 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:45:44 --> Helper loaded: form_helper
INFO - 2018-11-21 04:45:44 --> Final output sent to browser
INFO - 2018-11-21 04:45:44 --> Helper loaded: cookie_helper
DEBUG - 2018-11-21 04:45:44 --> Total execution time: 0.1690
INFO - 2018-11-21 04:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:44 --> Helper loaded: date_helper
INFO - 2018-11-21 04:45:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:44 --> Form Validation Class Initialized
INFO - 2018-11-21 04:45:44 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:44 --> Email Class Initialized
DEBUG - 2018-11-21 04:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 04:45:44 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:44 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:44 --> Controller Class Initialized
INFO - 2018-11-21 04:45:44 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 04:45:44 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:44 --> Total execution time: 0.2128
INFO - 2018-11-21 04:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 04:45:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 04:45:44 --> Pagination Class Initialized
INFO - 2018-11-21 04:45:44 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:44 --> Database Driver Class Initialized
INFO - 2018-11-21 04:45:44 --> Controller Class Initialized
INFO - 2018-11-21 04:45:44 --> Final output sent to browser
DEBUG - 2018-11-21 04:45:44 --> Total execution time: 0.1651
INFO - 2018-11-21 05:03:41 --> Config Class Initialized
INFO - 2018-11-21 05:03:41 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:03:41 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:03:41 --> Utf8 Class Initialized
INFO - 2018-11-21 05:03:41 --> URI Class Initialized
INFO - 2018-11-21 05:03:41 --> Router Class Initialized
INFO - 2018-11-21 05:03:41 --> Output Class Initialized
INFO - 2018-11-21 05:03:41 --> Security Class Initialized
DEBUG - 2018-11-21 05:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:03:41 --> Input Class Initialized
INFO - 2018-11-21 05:03:41 --> Language Class Initialized
INFO - 2018-11-21 05:03:41 --> Loader Class Initialized
INFO - 2018-11-21 05:03:41 --> Helper loaded: url_helper
INFO - 2018-11-21 05:03:41 --> Helper loaded: html_helper
INFO - 2018-11-21 05:03:41 --> Helper loaded: form_helper
INFO - 2018-11-21 05:03:41 --> Helper loaded: cookie_helper
INFO - 2018-11-21 05:03:41 --> Helper loaded: date_helper
INFO - 2018-11-21 05:03:41 --> Form Validation Class Initialized
INFO - 2018-11-21 05:03:41 --> Email Class Initialized
DEBUG - 2018-11-21 05:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:03:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:03:41 --> Pagination Class Initialized
INFO - 2018-11-21 05:03:41 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:41 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:41 --> Controller Class Initialized
INFO - 2018-11-21 05:03:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 05:03:41 --> Final output sent to browser
DEBUG - 2018-11-21 05:03:41 --> Total execution time: 0.1210
INFO - 2018-11-21 05:03:41 --> Config Class Initialized
INFO - 2018-11-21 05:03:41 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:03:41 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:03:41 --> Utf8 Class Initialized
INFO - 2018-11-21 05:03:41 --> URI Class Initialized
INFO - 2018-11-21 05:03:41 --> Router Class Initialized
INFO - 2018-11-21 05:03:41 --> Output Class Initialized
INFO - 2018-11-21 05:03:41 --> Security Class Initialized
DEBUG - 2018-11-21 05:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:03:41 --> Input Class Initialized
INFO - 2018-11-21 05:03:41 --> Language Class Initialized
INFO - 2018-11-21 05:03:41 --> Loader Class Initialized
INFO - 2018-11-21 05:03:41 --> Helper loaded: url_helper
INFO - 2018-11-21 05:03:41 --> Helper loaded: html_helper
INFO - 2018-11-21 05:03:41 --> Helper loaded: form_helper
INFO - 2018-11-21 05:03:41 --> Helper loaded: cookie_helper
INFO - 2018-11-21 05:03:41 --> Helper loaded: date_helper
INFO - 2018-11-21 05:03:41 --> Form Validation Class Initialized
INFO - 2018-11-21 05:03:41 --> Email Class Initialized
DEBUG - 2018-11-21 05:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:03:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:03:41 --> Pagination Class Initialized
INFO - 2018-11-21 05:03:41 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:41 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:41 --> Controller Class Initialized
INFO - 2018-11-21 05:03:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 05:03:41 --> Final output sent to browser
DEBUG - 2018-11-21 05:03:41 --> Total execution time: 0.1200
INFO - 2018-11-21 05:03:42 --> Config Class Initialized
INFO - 2018-11-21 05:03:42 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:03:42 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:03:42 --> Utf8 Class Initialized
INFO - 2018-11-21 05:03:42 --> URI Class Initialized
INFO - 2018-11-21 05:03:42 --> Router Class Initialized
INFO - 2018-11-21 05:03:42 --> Output Class Initialized
INFO - 2018-11-21 05:03:42 --> Security Class Initialized
DEBUG - 2018-11-21 05:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:03:42 --> Input Class Initialized
INFO - 2018-11-21 05:03:42 --> Language Class Initialized
INFO - 2018-11-21 05:03:42 --> Loader Class Initialized
INFO - 2018-11-21 05:03:42 --> Helper loaded: url_helper
INFO - 2018-11-21 05:03:42 --> Helper loaded: html_helper
INFO - 2018-11-21 05:03:42 --> Helper loaded: form_helper
INFO - 2018-11-21 05:03:42 --> Helper loaded: cookie_helper
INFO - 2018-11-21 05:03:42 --> Helper loaded: date_helper
INFO - 2018-11-21 05:03:42 --> Form Validation Class Initialized
INFO - 2018-11-21 05:03:42 --> Email Class Initialized
DEBUG - 2018-11-21 05:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:03:42 --> Pagination Class Initialized
INFO - 2018-11-21 05:03:42 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:42 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:42 --> Controller Class Initialized
INFO - 2018-11-21 05:03:42 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-21 05:03:42 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-11-21 05:03:42 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-21 05:03:42 --> Final output sent to browser
DEBUG - 2018-11-21 05:03:42 --> Total execution time: 0.1696
INFO - 2018-11-21 05:03:42 --> Config Class Initialized
INFO - 2018-11-21 05:03:42 --> Config Class Initialized
INFO - 2018-11-21 05:03:42 --> Hooks Class Initialized
INFO - 2018-11-21 05:03:42 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:03:42 --> UTF-8 Support Enabled
DEBUG - 2018-11-21 05:03:42 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:03:42 --> Utf8 Class Initialized
INFO - 2018-11-21 05:03:42 --> Utf8 Class Initialized
INFO - 2018-11-21 05:03:42 --> URI Class Initialized
INFO - 2018-11-21 05:03:42 --> URI Class Initialized
INFO - 2018-11-21 05:03:42 --> Router Class Initialized
INFO - 2018-11-21 05:03:42 --> Router Class Initialized
INFO - 2018-11-21 05:03:42 --> Output Class Initialized
INFO - 2018-11-21 05:03:42 --> Output Class Initialized
INFO - 2018-11-21 05:03:42 --> Security Class Initialized
INFO - 2018-11-21 05:03:42 --> Security Class Initialized
DEBUG - 2018-11-21 05:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-21 05:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:03:42 --> Input Class Initialized
INFO - 2018-11-21 05:03:42 --> Input Class Initialized
INFO - 2018-11-21 05:03:42 --> Language Class Initialized
INFO - 2018-11-21 05:03:42 --> Language Class Initialized
INFO - 2018-11-21 05:03:42 --> Loader Class Initialized
INFO - 2018-11-21 05:03:42 --> Loader Class Initialized
INFO - 2018-11-21 05:03:42 --> Helper loaded: url_helper
INFO - 2018-11-21 05:03:42 --> Helper loaded: url_helper
INFO - 2018-11-21 05:03:42 --> Helper loaded: html_helper
INFO - 2018-11-21 05:03:42 --> Helper loaded: html_helper
INFO - 2018-11-21 05:03:42 --> Helper loaded: form_helper
INFO - 2018-11-21 05:03:42 --> Helper loaded: form_helper
INFO - 2018-11-21 05:03:42 --> Helper loaded: cookie_helper
INFO - 2018-11-21 05:03:42 --> Helper loaded: cookie_helper
INFO - 2018-11-21 05:03:42 --> Helper loaded: date_helper
INFO - 2018-11-21 05:03:42 --> Helper loaded: date_helper
INFO - 2018-11-21 05:03:42 --> Form Validation Class Initialized
INFO - 2018-11-21 05:03:42 --> Form Validation Class Initialized
INFO - 2018-11-21 05:03:42 --> Email Class Initialized
INFO - 2018-11-21 05:03:42 --> Email Class Initialized
DEBUG - 2018-11-21 05:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-21 05:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:03:42 --> Pagination Class Initialized
INFO - 2018-11-21 05:03:42 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:42 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:42 --> Controller Class Initialized
INFO - 2018-11-21 05:03:42 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 05:03:42 --> Final output sent to browser
DEBUG - 2018-11-21 05:03:42 --> Total execution time: 0.1833
INFO - 2018-11-21 05:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:03:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:03:43 --> Pagination Class Initialized
INFO - 2018-11-21 05:03:43 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:43 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:43 --> Controller Class Initialized
INFO - 2018-11-21 05:03:43 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 05:03:43 --> Final output sent to browser
DEBUG - 2018-11-21 05:03:43 --> Total execution time: 0.2536
INFO - 2018-11-21 05:03:44 --> Config Class Initialized
INFO - 2018-11-21 05:03:44 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:03:44 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:03:44 --> Utf8 Class Initialized
INFO - 2018-11-21 05:03:44 --> URI Class Initialized
INFO - 2018-11-21 05:03:44 --> Router Class Initialized
INFO - 2018-11-21 05:03:44 --> Output Class Initialized
INFO - 2018-11-21 05:03:44 --> Security Class Initialized
DEBUG - 2018-11-21 05:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:03:44 --> Input Class Initialized
INFO - 2018-11-21 05:03:44 --> Language Class Initialized
INFO - 2018-11-21 05:03:44 --> Loader Class Initialized
INFO - 2018-11-21 05:03:44 --> Helper loaded: url_helper
INFO - 2018-11-21 05:03:44 --> Helper loaded: html_helper
INFO - 2018-11-21 05:03:44 --> Helper loaded: form_helper
INFO - 2018-11-21 05:03:44 --> Helper loaded: cookie_helper
INFO - 2018-11-21 05:03:44 --> Helper loaded: date_helper
INFO - 2018-11-21 05:03:44 --> Form Validation Class Initialized
INFO - 2018-11-21 05:03:44 --> Email Class Initialized
DEBUG - 2018-11-21 05:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:03:44 --> Pagination Class Initialized
INFO - 2018-11-21 05:03:44 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:44 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:44 --> Controller Class Initialized
INFO - 2018-11-21 05:03:44 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-21 05:03:44 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-11-21 05:03:44 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2018-11-21 05:03:44 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-21 05:03:44 --> Final output sent to browser
DEBUG - 2018-11-21 05:03:44 --> Total execution time: 0.2121
INFO - 2018-11-21 05:03:44 --> Config Class Initialized
INFO - 2018-11-21 05:03:44 --> Config Class Initialized
INFO - 2018-11-21 05:03:44 --> Hooks Class Initialized
INFO - 2018-11-21 05:03:44 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:03:44 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:03:44 --> Utf8 Class Initialized
DEBUG - 2018-11-21 05:03:44 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:03:44 --> Utf8 Class Initialized
INFO - 2018-11-21 05:03:44 --> URI Class Initialized
INFO - 2018-11-21 05:03:44 --> URI Class Initialized
INFO - 2018-11-21 05:03:44 --> Router Class Initialized
INFO - 2018-11-21 05:03:44 --> Router Class Initialized
INFO - 2018-11-21 05:03:44 --> Output Class Initialized
INFO - 2018-11-21 05:03:44 --> Output Class Initialized
INFO - 2018-11-21 05:03:44 --> Security Class Initialized
INFO - 2018-11-21 05:03:44 --> Security Class Initialized
DEBUG - 2018-11-21 05:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-21 05:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:03:44 --> Input Class Initialized
INFO - 2018-11-21 05:03:44 --> Input Class Initialized
INFO - 2018-11-21 05:03:44 --> Language Class Initialized
INFO - 2018-11-21 05:03:44 --> Language Class Initialized
INFO - 2018-11-21 05:03:44 --> Loader Class Initialized
INFO - 2018-11-21 05:03:44 --> Loader Class Initialized
INFO - 2018-11-21 05:03:44 --> Helper loaded: url_helper
INFO - 2018-11-21 05:03:44 --> Helper loaded: url_helper
INFO - 2018-11-21 05:03:44 --> Helper loaded: html_helper
INFO - 2018-11-21 05:03:44 --> Helper loaded: html_helper
INFO - 2018-11-21 05:03:44 --> Helper loaded: form_helper
INFO - 2018-11-21 05:03:44 --> Helper loaded: form_helper
INFO - 2018-11-21 05:03:44 --> Helper loaded: cookie_helper
INFO - 2018-11-21 05:03:44 --> Helper loaded: cookie_helper
INFO - 2018-11-21 05:03:44 --> Helper loaded: date_helper
INFO - 2018-11-21 05:03:44 --> Helper loaded: date_helper
INFO - 2018-11-21 05:03:44 --> Form Validation Class Initialized
INFO - 2018-11-21 05:03:44 --> Form Validation Class Initialized
INFO - 2018-11-21 05:03:44 --> Email Class Initialized
INFO - 2018-11-21 05:03:44 --> Email Class Initialized
DEBUG - 2018-11-21 05:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-21 05:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:03:44 --> Pagination Class Initialized
INFO - 2018-11-21 05:03:44 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:44 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:44 --> Controller Class Initialized
INFO - 2018-11-21 05:03:44 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 05:03:44 --> Final output sent to browser
DEBUG - 2018-11-21 05:03:44 --> Total execution time: 0.1841
INFO - 2018-11-21 05:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:03:44 --> Pagination Class Initialized
INFO - 2018-11-21 05:03:44 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:44 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:44 --> Controller Class Initialized
INFO - 2018-11-21 05:03:44 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 05:03:44 --> Final output sent to browser
DEBUG - 2018-11-21 05:03:44 --> Total execution time: 0.2519
INFO - 2018-11-21 05:03:46 --> Config Class Initialized
INFO - 2018-11-21 05:03:46 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:03:46 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:03:46 --> Utf8 Class Initialized
INFO - 2018-11-21 05:03:46 --> URI Class Initialized
INFO - 2018-11-21 05:03:46 --> Router Class Initialized
INFO - 2018-11-21 05:03:46 --> Output Class Initialized
INFO - 2018-11-21 05:03:46 --> Security Class Initialized
DEBUG - 2018-11-21 05:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:03:46 --> Input Class Initialized
INFO - 2018-11-21 05:03:46 --> Language Class Initialized
INFO - 2018-11-21 05:03:46 --> Loader Class Initialized
INFO - 2018-11-21 05:03:46 --> Helper loaded: url_helper
INFO - 2018-11-21 05:03:46 --> Helper loaded: html_helper
INFO - 2018-11-21 05:03:46 --> Helper loaded: form_helper
INFO - 2018-11-21 05:03:46 --> Helper loaded: cookie_helper
INFO - 2018-11-21 05:03:46 --> Helper loaded: date_helper
INFO - 2018-11-21 05:03:46 --> Form Validation Class Initialized
INFO - 2018-11-21 05:03:46 --> Email Class Initialized
DEBUG - 2018-11-21 05:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:03:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:03:46 --> Pagination Class Initialized
INFO - 2018-11-21 05:03:46 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:46 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:46 --> Controller Class Initialized
INFO - 2018-11-21 05:03:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-21 05:03:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/folio.php
INFO - 2018-11-21 05:03:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-21 05:03:46 --> Final output sent to browser
DEBUG - 2018-11-21 05:03:46 --> Total execution time: 0.1495
INFO - 2018-11-21 05:03:46 --> Config Class Initialized
INFO - 2018-11-21 05:03:46 --> Config Class Initialized
INFO - 2018-11-21 05:03:46 --> Hooks Class Initialized
INFO - 2018-11-21 05:03:46 --> Hooks Class Initialized
DEBUG - 2018-11-21 05:03:46 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:03:46 --> Utf8 Class Initialized
DEBUG - 2018-11-21 05:03:46 --> UTF-8 Support Enabled
INFO - 2018-11-21 05:03:46 --> Utf8 Class Initialized
INFO - 2018-11-21 05:03:46 --> URI Class Initialized
INFO - 2018-11-21 05:03:46 --> URI Class Initialized
INFO - 2018-11-21 05:03:46 --> Router Class Initialized
INFO - 2018-11-21 05:03:46 --> Router Class Initialized
INFO - 2018-11-21 05:03:46 --> Output Class Initialized
INFO - 2018-11-21 05:03:46 --> Output Class Initialized
INFO - 2018-11-21 05:03:46 --> Security Class Initialized
INFO - 2018-11-21 05:03:46 --> Security Class Initialized
DEBUG - 2018-11-21 05:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-21 05:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 05:03:46 --> Input Class Initialized
INFO - 2018-11-21 05:03:46 --> Input Class Initialized
INFO - 2018-11-21 05:03:46 --> Language Class Initialized
INFO - 2018-11-21 05:03:46 --> Language Class Initialized
INFO - 2018-11-21 05:03:46 --> Loader Class Initialized
INFO - 2018-11-21 05:03:46 --> Loader Class Initialized
INFO - 2018-11-21 05:03:46 --> Helper loaded: url_helper
INFO - 2018-11-21 05:03:46 --> Helper loaded: url_helper
INFO - 2018-11-21 05:03:46 --> Helper loaded: html_helper
INFO - 2018-11-21 05:03:46 --> Helper loaded: html_helper
INFO - 2018-11-21 05:03:46 --> Helper loaded: form_helper
INFO - 2018-11-21 05:03:46 --> Helper loaded: form_helper
INFO - 2018-11-21 05:03:46 --> Helper loaded: cookie_helper
INFO - 2018-11-21 05:03:46 --> Helper loaded: cookie_helper
INFO - 2018-11-21 05:03:46 --> Helper loaded: date_helper
INFO - 2018-11-21 05:03:46 --> Helper loaded: date_helper
INFO - 2018-11-21 05:03:46 --> Form Validation Class Initialized
INFO - 2018-11-21 05:03:46 --> Form Validation Class Initialized
INFO - 2018-11-21 05:03:46 --> Email Class Initialized
INFO - 2018-11-21 05:03:46 --> Email Class Initialized
DEBUG - 2018-11-21 05:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-21 05:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 05:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:03:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:03:46 --> Pagination Class Initialized
INFO - 2018-11-21 05:03:46 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:46 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:46 --> Controller Class Initialized
INFO - 2018-11-21 05:03:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 05:03:46 --> Final output sent to browser
DEBUG - 2018-11-21 05:03:46 --> Total execution time: 0.1693
INFO - 2018-11-21 05:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 05:03:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 05:03:46 --> Pagination Class Initialized
INFO - 2018-11-21 05:03:46 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:46 --> Database Driver Class Initialized
INFO - 2018-11-21 05:03:46 --> Controller Class Initialized
INFO - 2018-11-21 05:03:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-21 05:03:46 --> Final output sent to browser
DEBUG - 2018-11-21 05:03:46 --> Total execution time: 0.2437
INFO - 2018-11-21 08:36:54 --> Config Class Initialized
INFO - 2018-11-21 08:36:54 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:36:54 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:36:54 --> Utf8 Class Initialized
INFO - 2018-11-21 08:36:54 --> URI Class Initialized
INFO - 2018-11-21 08:36:54 --> Router Class Initialized
INFO - 2018-11-21 08:36:54 --> Output Class Initialized
INFO - 2018-11-21 08:36:54 --> Security Class Initialized
DEBUG - 2018-11-21 08:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:36:54 --> Input Class Initialized
INFO - 2018-11-21 08:36:54 --> Language Class Initialized
INFO - 2018-11-21 08:36:54 --> Loader Class Initialized
INFO - 2018-11-21 08:36:54 --> Helper loaded: url_helper
INFO - 2018-11-21 08:36:54 --> Helper loaded: html_helper
INFO - 2018-11-21 08:36:54 --> Helper loaded: form_helper
INFO - 2018-11-21 08:36:54 --> Helper loaded: cookie_helper
INFO - 2018-11-21 08:36:54 --> Helper loaded: date_helper
INFO - 2018-11-21 08:36:54 --> Form Validation Class Initialized
INFO - 2018-11-21 08:36:54 --> Email Class Initialized
DEBUG - 2018-11-21 08:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:36:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:36:54 --> Pagination Class Initialized
INFO - 2018-11-21 08:36:54 --> Database Driver Class Initialized
INFO - 2018-11-21 08:36:54 --> Database Driver Class Initialized
INFO - 2018-11-21 08:36:54 --> Controller Class Initialized
INFO - 2018-11-21 08:36:55 --> Config Class Initialized
INFO - 2018-11-21 08:36:55 --> Hooks Class Initialized
DEBUG - 2018-11-21 08:36:55 --> UTF-8 Support Enabled
INFO - 2018-11-21 08:36:55 --> Utf8 Class Initialized
INFO - 2018-11-21 08:36:55 --> URI Class Initialized
INFO - 2018-11-21 08:36:55 --> Router Class Initialized
INFO - 2018-11-21 08:36:55 --> Output Class Initialized
INFO - 2018-11-21 08:36:55 --> Security Class Initialized
DEBUG - 2018-11-21 08:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 08:36:55 --> Input Class Initialized
INFO - 2018-11-21 08:36:55 --> Language Class Initialized
INFO - 2018-11-21 08:36:55 --> Loader Class Initialized
INFO - 2018-11-21 08:36:55 --> Helper loaded: url_helper
INFO - 2018-11-21 08:36:55 --> Helper loaded: html_helper
INFO - 2018-11-21 08:36:55 --> Helper loaded: form_helper
INFO - 2018-11-21 08:36:55 --> Helper loaded: cookie_helper
INFO - 2018-11-21 08:36:55 --> Helper loaded: date_helper
INFO - 2018-11-21 08:36:55 --> Form Validation Class Initialized
INFO - 2018-11-21 08:36:55 --> Email Class Initialized
DEBUG - 2018-11-21 08:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 08:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 08:36:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 08:36:55 --> Pagination Class Initialized
INFO - 2018-11-21 08:36:55 --> Database Driver Class Initialized
INFO - 2018-11-21 08:36:55 --> Database Driver Class Initialized
INFO - 2018-11-21 08:36:55 --> Controller Class Initialized
INFO - 2018-11-21 08:36:55 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-21 08:36:55 --> Final output sent to browser
DEBUG - 2018-11-21 08:36:55 --> Total execution time: 0.1399
INFO - 2018-11-21 16:12:18 --> Config Class Initialized
INFO - 2018-11-21 16:12:19 --> Hooks Class Initialized
DEBUG - 2018-11-21 16:12:19 --> UTF-8 Support Enabled
INFO - 2018-11-21 16:12:19 --> Utf8 Class Initialized
INFO - 2018-11-21 16:12:19 --> URI Class Initialized
INFO - 2018-11-21 16:12:19 --> Router Class Initialized
INFO - 2018-11-21 16:12:20 --> Output Class Initialized
INFO - 2018-11-21 16:12:20 --> Security Class Initialized
DEBUG - 2018-11-21 16:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-21 16:12:20 --> Input Class Initialized
INFO - 2018-11-21 16:12:20 --> Language Class Initialized
INFO - 2018-11-21 16:12:20 --> Loader Class Initialized
INFO - 2018-11-21 16:12:20 --> Helper loaded: url_helper
INFO - 2018-11-21 16:12:20 --> Helper loaded: html_helper
INFO - 2018-11-21 16:12:20 --> Helper loaded: form_helper
INFO - 2018-11-21 16:12:20 --> Helper loaded: cookie_helper
INFO - 2018-11-21 16:12:20 --> Helper loaded: date_helper
INFO - 2018-11-21 16:12:21 --> Form Validation Class Initialized
INFO - 2018-11-21 16:12:21 --> Email Class Initialized
DEBUG - 2018-11-21 16:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-21 16:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-21 16:12:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-21 16:12:22 --> Pagination Class Initialized
INFO - 2018-11-21 16:12:23 --> Database Driver Class Initialized
INFO - 2018-11-21 16:12:23 --> Database Driver Class Initialized
INFO - 2018-11-21 16:12:25 --> Language file loaded: language/english/db_lang.php
