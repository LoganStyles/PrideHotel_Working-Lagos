<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-15 01:29:47 --> Config Class Initialized
INFO - 2019-09-15 01:29:47 --> Hooks Class Initialized
DEBUG - 2019-09-15 01:29:47 --> UTF-8 Support Enabled
INFO - 2019-09-15 01:29:47 --> Utf8 Class Initialized
INFO - 2019-09-15 01:29:47 --> URI Class Initialized
INFO - 2019-09-15 01:29:47 --> Router Class Initialized
INFO - 2019-09-15 01:29:47 --> Output Class Initialized
INFO - 2019-09-15 01:29:47 --> Security Class Initialized
DEBUG - 2019-09-15 01:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 01:29:47 --> Input Class Initialized
INFO - 2019-09-15 01:29:47 --> Language Class Initialized
INFO - 2019-09-15 01:29:47 --> Loader Class Initialized
INFO - 2019-09-15 01:29:47 --> Helper loaded: url_helper
INFO - 2019-09-15 01:29:47 --> Helper loaded: html_helper
INFO - 2019-09-15 01:29:47 --> Helper loaded: form_helper
INFO - 2019-09-15 01:29:47 --> Helper loaded: cookie_helper
INFO - 2019-09-15 01:29:47 --> Helper loaded: date_helper
INFO - 2019-09-15 01:29:47 --> Form Validation Class Initialized
INFO - 2019-09-15 01:29:47 --> Email Class Initialized
DEBUG - 2019-09-15 01:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 01:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 01:29:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 01:29:47 --> Pagination Class Initialized
INFO - 2019-09-15 01:29:47 --> Database Driver Class Initialized
INFO - 2019-09-15 01:29:47 --> Database Driver Class Initialized
INFO - 2019-09-15 01:29:47 --> Controller Class Initialized
DEBUG - 2019-09-15 01:29:47 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 01:29:47 --> Helper loaded: inflector_helper
INFO - 2019-09-15 01:29:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 01:30:51 --> Config Class Initialized
INFO - 2019-09-15 01:30:51 --> Hooks Class Initialized
DEBUG - 2019-09-15 01:30:51 --> UTF-8 Support Enabled
INFO - 2019-09-15 01:30:51 --> Utf8 Class Initialized
INFO - 2019-09-15 01:30:51 --> URI Class Initialized
INFO - 2019-09-15 01:30:51 --> Router Class Initialized
INFO - 2019-09-15 01:30:51 --> Output Class Initialized
INFO - 2019-09-15 01:30:51 --> Security Class Initialized
DEBUG - 2019-09-15 01:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 01:30:51 --> Input Class Initialized
INFO - 2019-09-15 01:30:51 --> Language Class Initialized
INFO - 2019-09-15 01:30:51 --> Loader Class Initialized
INFO - 2019-09-15 01:30:51 --> Helper loaded: url_helper
INFO - 2019-09-15 01:30:51 --> Helper loaded: html_helper
INFO - 2019-09-15 01:30:51 --> Helper loaded: form_helper
INFO - 2019-09-15 01:30:51 --> Helper loaded: cookie_helper
INFO - 2019-09-15 01:30:51 --> Helper loaded: date_helper
INFO - 2019-09-15 01:30:51 --> Form Validation Class Initialized
INFO - 2019-09-15 01:30:51 --> Email Class Initialized
DEBUG - 2019-09-15 01:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 01:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 01:30:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 01:30:51 --> Pagination Class Initialized
INFO - 2019-09-15 01:30:51 --> Database Driver Class Initialized
INFO - 2019-09-15 01:30:51 --> Database Driver Class Initialized
INFO - 2019-09-15 01:30:51 --> Controller Class Initialized
DEBUG - 2019-09-15 01:30:51 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 01:30:51 --> Helper loaded: inflector_helper
INFO - 2019-09-15 01:30:51 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-15 01:30:51 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 27
ERROR - 2019-09-15 01:30:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 29
INFO - 2019-09-15 01:30:51 --> Final output sent to browser
DEBUG - 2019-09-15 01:30:51 --> Total execution time: 0.0617
INFO - 2019-09-15 01:46:00 --> Config Class Initialized
INFO - 2019-09-15 01:46:00 --> Hooks Class Initialized
DEBUG - 2019-09-15 01:46:00 --> UTF-8 Support Enabled
INFO - 2019-09-15 01:46:00 --> Utf8 Class Initialized
INFO - 2019-09-15 01:46:00 --> URI Class Initialized
INFO - 2019-09-15 01:46:00 --> Router Class Initialized
INFO - 2019-09-15 01:46:00 --> Output Class Initialized
INFO - 2019-09-15 01:46:00 --> Security Class Initialized
DEBUG - 2019-09-15 01:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 01:46:00 --> Input Class Initialized
INFO - 2019-09-15 01:46:00 --> Language Class Initialized
INFO - 2019-09-15 01:46:00 --> Loader Class Initialized
INFO - 2019-09-15 01:46:00 --> Helper loaded: url_helper
INFO - 2019-09-15 01:46:00 --> Helper loaded: html_helper
INFO - 2019-09-15 01:46:00 --> Helper loaded: form_helper
INFO - 2019-09-15 01:46:00 --> Helper loaded: cookie_helper
INFO - 2019-09-15 01:46:00 --> Helper loaded: date_helper
INFO - 2019-09-15 01:46:00 --> Form Validation Class Initialized
INFO - 2019-09-15 01:46:00 --> Email Class Initialized
DEBUG - 2019-09-15 01:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 01:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 01:46:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 01:46:00 --> Pagination Class Initialized
INFO - 2019-09-15 01:46:00 --> Database Driver Class Initialized
INFO - 2019-09-15 01:46:00 --> Database Driver Class Initialized
INFO - 2019-09-15 01:46:00 --> Controller Class Initialized
DEBUG - 2019-09-15 01:46:00 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 01:46:00 --> Helper loaded: inflector_helper
INFO - 2019-09-15 01:46:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 01:46:00 --> Final output sent to browser
DEBUG - 2019-09-15 01:46:00 --> Total execution time: 0.2203
INFO - 2019-09-15 02:15:31 --> Config Class Initialized
INFO - 2019-09-15 02:15:31 --> Hooks Class Initialized
DEBUG - 2019-09-15 02:15:31 --> UTF-8 Support Enabled
INFO - 2019-09-15 02:15:31 --> Utf8 Class Initialized
INFO - 2019-09-15 02:15:31 --> URI Class Initialized
INFO - 2019-09-15 02:15:31 --> Router Class Initialized
INFO - 2019-09-15 02:15:31 --> Output Class Initialized
INFO - 2019-09-15 02:15:31 --> Security Class Initialized
DEBUG - 2019-09-15 02:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 02:15:31 --> Input Class Initialized
INFO - 2019-09-15 02:15:31 --> Language Class Initialized
INFO - 2019-09-15 02:15:31 --> Loader Class Initialized
INFO - 2019-09-15 02:15:31 --> Helper loaded: url_helper
INFO - 2019-09-15 02:15:31 --> Helper loaded: html_helper
INFO - 2019-09-15 02:15:31 --> Helper loaded: form_helper
INFO - 2019-09-15 02:15:31 --> Helper loaded: cookie_helper
INFO - 2019-09-15 02:15:31 --> Helper loaded: date_helper
INFO - 2019-09-15 02:15:31 --> Form Validation Class Initialized
INFO - 2019-09-15 02:15:31 --> Email Class Initialized
DEBUG - 2019-09-15 02:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 02:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 02:15:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 02:15:31 --> Pagination Class Initialized
INFO - 2019-09-15 02:15:31 --> Database Driver Class Initialized
INFO - 2019-09-15 02:15:31 --> Database Driver Class Initialized
INFO - 2019-09-15 02:15:31 --> Controller Class Initialized
DEBUG - 2019-09-15 02:15:31 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 02:15:31 --> Helper loaded: inflector_helper
INFO - 2019-09-15 02:15:31 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-15 02:15:31 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 27
ERROR - 2019-09-15 02:15:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 29
INFO - 2019-09-15 02:15:31 --> Final output sent to browser
DEBUG - 2019-09-15 02:15:31 --> Total execution time: 0.0635
INFO - 2019-09-15 03:18:54 --> Config Class Initialized
INFO - 2019-09-15 03:18:54 --> Hooks Class Initialized
DEBUG - 2019-09-15 03:18:54 --> UTF-8 Support Enabled
INFO - 2019-09-15 03:18:54 --> Utf8 Class Initialized
INFO - 2019-09-15 03:18:54 --> URI Class Initialized
INFO - 2019-09-15 03:18:54 --> Router Class Initialized
INFO - 2019-09-15 03:18:54 --> Output Class Initialized
INFO - 2019-09-15 03:18:54 --> Security Class Initialized
DEBUG - 2019-09-15 03:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 03:18:54 --> Input Class Initialized
INFO - 2019-09-15 03:18:54 --> Language Class Initialized
INFO - 2019-09-15 03:18:54 --> Loader Class Initialized
INFO - 2019-09-15 03:18:54 --> Helper loaded: url_helper
INFO - 2019-09-15 03:18:54 --> Helper loaded: html_helper
INFO - 2019-09-15 03:18:54 --> Helper loaded: form_helper
INFO - 2019-09-15 03:18:54 --> Helper loaded: cookie_helper
INFO - 2019-09-15 03:18:54 --> Helper loaded: date_helper
INFO - 2019-09-15 03:18:54 --> Form Validation Class Initialized
INFO - 2019-09-15 03:18:54 --> Email Class Initialized
DEBUG - 2019-09-15 03:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 03:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 03:18:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 03:18:54 --> Pagination Class Initialized
INFO - 2019-09-15 03:18:54 --> Database Driver Class Initialized
INFO - 2019-09-15 03:18:54 --> Database Driver Class Initialized
INFO - 2019-09-15 03:18:54 --> Controller Class Initialized
DEBUG - 2019-09-15 03:18:54 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 03:18:54 --> Helper loaded: inflector_helper
INFO - 2019-09-15 03:18:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 03:18:54 --> Final output sent to browser
DEBUG - 2019-09-15 03:18:54 --> Total execution time: 0.0632
INFO - 2019-09-15 03:20:16 --> Config Class Initialized
INFO - 2019-09-15 03:20:16 --> Hooks Class Initialized
DEBUG - 2019-09-15 03:20:16 --> UTF-8 Support Enabled
INFO - 2019-09-15 03:20:16 --> Utf8 Class Initialized
INFO - 2019-09-15 03:20:16 --> URI Class Initialized
INFO - 2019-09-15 03:20:16 --> Router Class Initialized
INFO - 2019-09-15 03:20:16 --> Output Class Initialized
INFO - 2019-09-15 03:20:16 --> Security Class Initialized
DEBUG - 2019-09-15 03:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 03:20:16 --> Input Class Initialized
INFO - 2019-09-15 03:20:16 --> Language Class Initialized
INFO - 2019-09-15 03:20:16 --> Loader Class Initialized
INFO - 2019-09-15 03:20:16 --> Helper loaded: url_helper
INFO - 2019-09-15 03:20:16 --> Helper loaded: html_helper
INFO - 2019-09-15 03:20:16 --> Helper loaded: form_helper
INFO - 2019-09-15 03:20:16 --> Helper loaded: cookie_helper
INFO - 2019-09-15 03:20:16 --> Helper loaded: date_helper
INFO - 2019-09-15 03:20:16 --> Form Validation Class Initialized
INFO - 2019-09-15 03:20:16 --> Email Class Initialized
DEBUG - 2019-09-15 03:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 03:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 03:20:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 03:20:16 --> Pagination Class Initialized
INFO - 2019-09-15 03:20:16 --> Database Driver Class Initialized
INFO - 2019-09-15 03:20:16 --> Database Driver Class Initialized
INFO - 2019-09-15 03:20:16 --> Controller Class Initialized
DEBUG - 2019-09-15 03:20:16 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 03:20:16 --> Helper loaded: inflector_helper
INFO - 2019-09-15 03:20:16 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-15 03:20:16 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 27
ERROR - 2019-09-15 03:20:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 29
INFO - 2019-09-15 03:20:16 --> Final output sent to browser
DEBUG - 2019-09-15 03:20:16 --> Total execution time: 0.1011
INFO - 2019-09-15 03:26:35 --> Config Class Initialized
INFO - 2019-09-15 03:26:35 --> Hooks Class Initialized
DEBUG - 2019-09-15 03:26:35 --> UTF-8 Support Enabled
INFO - 2019-09-15 03:26:35 --> Utf8 Class Initialized
INFO - 2019-09-15 03:26:35 --> URI Class Initialized
INFO - 2019-09-15 03:26:35 --> Router Class Initialized
INFO - 2019-09-15 03:26:35 --> Output Class Initialized
INFO - 2019-09-15 03:26:35 --> Security Class Initialized
DEBUG - 2019-09-15 03:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 03:26:35 --> Input Class Initialized
INFO - 2019-09-15 03:26:35 --> Language Class Initialized
INFO - 2019-09-15 03:26:35 --> Loader Class Initialized
INFO - 2019-09-15 03:26:35 --> Helper loaded: url_helper
INFO - 2019-09-15 03:26:35 --> Helper loaded: html_helper
INFO - 2019-09-15 03:26:35 --> Helper loaded: form_helper
INFO - 2019-09-15 03:26:35 --> Helper loaded: cookie_helper
INFO - 2019-09-15 03:26:35 --> Helper loaded: date_helper
INFO - 2019-09-15 03:26:35 --> Form Validation Class Initialized
INFO - 2019-09-15 03:26:35 --> Email Class Initialized
DEBUG - 2019-09-15 03:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 03:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 03:26:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 03:26:35 --> Pagination Class Initialized
INFO - 2019-09-15 03:26:35 --> Database Driver Class Initialized
INFO - 2019-09-15 03:26:35 --> Database Driver Class Initialized
INFO - 2019-09-15 03:26:35 --> Controller Class Initialized
DEBUG - 2019-09-15 03:26:35 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 03:26:35 --> Helper loaded: inflector_helper
INFO - 2019-09-15 03:26:35 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-15 03:26:35 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 27
ERROR - 2019-09-15 03:26:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 29
INFO - 2019-09-15 03:26:35 --> Final output sent to browser
DEBUG - 2019-09-15 03:26:35 --> Total execution time: 0.0566
INFO - 2019-09-15 03:27:21 --> Config Class Initialized
INFO - 2019-09-15 03:27:21 --> Hooks Class Initialized
DEBUG - 2019-09-15 03:27:21 --> UTF-8 Support Enabled
INFO - 2019-09-15 03:27:21 --> Utf8 Class Initialized
INFO - 2019-09-15 03:27:21 --> URI Class Initialized
INFO - 2019-09-15 03:27:21 --> Router Class Initialized
INFO - 2019-09-15 03:27:21 --> Output Class Initialized
INFO - 2019-09-15 03:27:21 --> Security Class Initialized
DEBUG - 2019-09-15 03:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 03:27:21 --> Input Class Initialized
INFO - 2019-09-15 03:27:21 --> Language Class Initialized
INFO - 2019-09-15 03:27:21 --> Loader Class Initialized
INFO - 2019-09-15 03:27:21 --> Helper loaded: url_helper
INFO - 2019-09-15 03:27:21 --> Helper loaded: html_helper
INFO - 2019-09-15 03:27:21 --> Helper loaded: form_helper
INFO - 2019-09-15 03:27:21 --> Helper loaded: cookie_helper
INFO - 2019-09-15 03:27:21 --> Helper loaded: date_helper
INFO - 2019-09-15 03:27:21 --> Form Validation Class Initialized
INFO - 2019-09-15 03:27:21 --> Email Class Initialized
DEBUG - 2019-09-15 03:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 03:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 03:27:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 03:27:21 --> Pagination Class Initialized
INFO - 2019-09-15 03:27:21 --> Database Driver Class Initialized
INFO - 2019-09-15 03:27:21 --> Database Driver Class Initialized
INFO - 2019-09-15 03:27:21 --> Controller Class Initialized
DEBUG - 2019-09-15 03:27:21 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 03:27:21 --> Helper loaded: inflector_helper
INFO - 2019-09-15 03:27:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 03:27:21 --> Final output sent to browser
DEBUG - 2019-09-15 03:27:21 --> Total execution time: 0.1647
INFO - 2019-09-15 03:27:43 --> Config Class Initialized
INFO - 2019-09-15 03:27:43 --> Hooks Class Initialized
DEBUG - 2019-09-15 03:27:43 --> UTF-8 Support Enabled
INFO - 2019-09-15 03:27:43 --> Utf8 Class Initialized
INFO - 2019-09-15 03:27:43 --> URI Class Initialized
INFO - 2019-09-15 03:27:43 --> Router Class Initialized
INFO - 2019-09-15 03:27:43 --> Output Class Initialized
INFO - 2019-09-15 03:27:43 --> Security Class Initialized
DEBUG - 2019-09-15 03:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 03:27:43 --> Input Class Initialized
INFO - 2019-09-15 03:27:43 --> Language Class Initialized
INFO - 2019-09-15 03:27:43 --> Loader Class Initialized
INFO - 2019-09-15 03:27:43 --> Helper loaded: url_helper
INFO - 2019-09-15 03:27:43 --> Helper loaded: html_helper
INFO - 2019-09-15 03:27:43 --> Helper loaded: form_helper
INFO - 2019-09-15 03:27:43 --> Helper loaded: cookie_helper
INFO - 2019-09-15 03:27:43 --> Helper loaded: date_helper
INFO - 2019-09-15 03:27:43 --> Form Validation Class Initialized
INFO - 2019-09-15 03:27:43 --> Email Class Initialized
DEBUG - 2019-09-15 03:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 03:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 03:27:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 03:27:43 --> Pagination Class Initialized
INFO - 2019-09-15 03:27:43 --> Database Driver Class Initialized
INFO - 2019-09-15 03:27:43 --> Database Driver Class Initialized
INFO - 2019-09-15 03:27:43 --> Controller Class Initialized
DEBUG - 2019-09-15 03:27:43 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 03:27:43 --> Helper loaded: inflector_helper
INFO - 2019-09-15 03:27:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 03:27:44 --> Final output sent to browser
DEBUG - 2019-09-15 03:27:44 --> Total execution time: 0.2158
INFO - 2019-09-15 03:35:43 --> Config Class Initialized
INFO - 2019-09-15 03:35:43 --> Hooks Class Initialized
DEBUG - 2019-09-15 03:35:43 --> UTF-8 Support Enabled
INFO - 2019-09-15 03:35:43 --> Utf8 Class Initialized
INFO - 2019-09-15 03:35:43 --> URI Class Initialized
INFO - 2019-09-15 03:35:43 --> Router Class Initialized
INFO - 2019-09-15 03:35:43 --> Output Class Initialized
INFO - 2019-09-15 03:35:43 --> Security Class Initialized
DEBUG - 2019-09-15 03:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 03:35:43 --> Input Class Initialized
INFO - 2019-09-15 03:35:43 --> Language Class Initialized
INFO - 2019-09-15 03:35:43 --> Loader Class Initialized
INFO - 2019-09-15 03:35:43 --> Helper loaded: url_helper
INFO - 2019-09-15 03:35:43 --> Helper loaded: html_helper
INFO - 2019-09-15 03:35:43 --> Helper loaded: form_helper
INFO - 2019-09-15 03:35:43 --> Helper loaded: cookie_helper
INFO - 2019-09-15 03:35:43 --> Helper loaded: date_helper
INFO - 2019-09-15 03:35:43 --> Form Validation Class Initialized
INFO - 2019-09-15 03:35:43 --> Email Class Initialized
DEBUG - 2019-09-15 03:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 03:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 03:35:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 03:35:43 --> Pagination Class Initialized
INFO - 2019-09-15 03:35:43 --> Database Driver Class Initialized
INFO - 2019-09-15 03:35:43 --> Database Driver Class Initialized
INFO - 2019-09-15 03:35:43 --> Controller Class Initialized
DEBUG - 2019-09-15 03:35:43 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 03:35:43 --> Helper loaded: inflector_helper
INFO - 2019-09-15 03:35:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 03:35:43 --> Final output sent to browser
DEBUG - 2019-09-15 03:35:43 --> Total execution time: 0.1357
INFO - 2019-09-15 03:42:06 --> Config Class Initialized
INFO - 2019-09-15 03:42:06 --> Hooks Class Initialized
DEBUG - 2019-09-15 03:42:06 --> UTF-8 Support Enabled
INFO - 2019-09-15 03:42:06 --> Utf8 Class Initialized
INFO - 2019-09-15 03:42:06 --> URI Class Initialized
INFO - 2019-09-15 03:42:06 --> Router Class Initialized
INFO - 2019-09-15 03:42:06 --> Output Class Initialized
INFO - 2019-09-15 03:42:06 --> Security Class Initialized
DEBUG - 2019-09-15 03:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 03:42:06 --> Input Class Initialized
INFO - 2019-09-15 03:42:06 --> Language Class Initialized
INFO - 2019-09-15 03:42:06 --> Loader Class Initialized
INFO - 2019-09-15 03:42:06 --> Helper loaded: url_helper
INFO - 2019-09-15 03:42:06 --> Helper loaded: html_helper
INFO - 2019-09-15 03:42:06 --> Helper loaded: form_helper
INFO - 2019-09-15 03:42:06 --> Helper loaded: cookie_helper
INFO - 2019-09-15 03:42:06 --> Helper loaded: date_helper
INFO - 2019-09-15 03:42:06 --> Form Validation Class Initialized
INFO - 2019-09-15 03:42:06 --> Email Class Initialized
DEBUG - 2019-09-15 03:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 03:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 03:42:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 03:42:06 --> Pagination Class Initialized
INFO - 2019-09-15 03:42:06 --> Database Driver Class Initialized
INFO - 2019-09-15 03:42:06 --> Database Driver Class Initialized
INFO - 2019-09-15 03:42:06 --> Controller Class Initialized
DEBUG - 2019-09-15 03:42:06 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 03:42:06 --> Helper loaded: inflector_helper
INFO - 2019-09-15 03:42:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 03:42:06 --> Final output sent to browser
DEBUG - 2019-09-15 03:42:06 --> Total execution time: 0.2183
INFO - 2019-09-15 03:43:11 --> Config Class Initialized
INFO - 2019-09-15 03:43:11 --> Hooks Class Initialized
DEBUG - 2019-09-15 03:43:11 --> UTF-8 Support Enabled
INFO - 2019-09-15 03:43:11 --> Utf8 Class Initialized
INFO - 2019-09-15 03:43:11 --> URI Class Initialized
INFO - 2019-09-15 03:43:11 --> Router Class Initialized
INFO - 2019-09-15 03:43:11 --> Output Class Initialized
INFO - 2019-09-15 03:43:11 --> Security Class Initialized
DEBUG - 2019-09-15 03:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 03:43:11 --> Input Class Initialized
INFO - 2019-09-15 03:43:11 --> Language Class Initialized
INFO - 2019-09-15 03:43:11 --> Loader Class Initialized
INFO - 2019-09-15 03:43:11 --> Helper loaded: url_helper
INFO - 2019-09-15 03:43:11 --> Helper loaded: html_helper
INFO - 2019-09-15 03:43:11 --> Helper loaded: form_helper
INFO - 2019-09-15 03:43:11 --> Helper loaded: cookie_helper
INFO - 2019-09-15 03:43:11 --> Helper loaded: date_helper
INFO - 2019-09-15 03:43:11 --> Form Validation Class Initialized
INFO - 2019-09-15 03:43:11 --> Email Class Initialized
DEBUG - 2019-09-15 03:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 03:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 03:43:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 03:43:11 --> Pagination Class Initialized
INFO - 2019-09-15 03:43:11 --> Database Driver Class Initialized
INFO - 2019-09-15 03:43:11 --> Database Driver Class Initialized
INFO - 2019-09-15 03:43:11 --> Controller Class Initialized
DEBUG - 2019-09-15 03:43:11 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 03:43:11 --> Helper loaded: inflector_helper
INFO - 2019-09-15 03:43:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 03:43:12 --> Final output sent to browser
DEBUG - 2019-09-15 03:43:12 --> Total execution time: 0.1493
INFO - 2019-09-15 03:44:59 --> Config Class Initialized
INFO - 2019-09-15 03:44:59 --> Hooks Class Initialized
DEBUG - 2019-09-15 03:44:59 --> UTF-8 Support Enabled
INFO - 2019-09-15 03:44:59 --> Utf8 Class Initialized
INFO - 2019-09-15 03:44:59 --> URI Class Initialized
INFO - 2019-09-15 03:44:59 --> Router Class Initialized
INFO - 2019-09-15 03:44:59 --> Output Class Initialized
INFO - 2019-09-15 03:44:59 --> Security Class Initialized
DEBUG - 2019-09-15 03:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 03:44:59 --> Input Class Initialized
INFO - 2019-09-15 03:44:59 --> Language Class Initialized
INFO - 2019-09-15 03:44:59 --> Loader Class Initialized
INFO - 2019-09-15 03:44:59 --> Helper loaded: url_helper
INFO - 2019-09-15 03:44:59 --> Helper loaded: html_helper
INFO - 2019-09-15 03:44:59 --> Helper loaded: form_helper
INFO - 2019-09-15 03:44:59 --> Helper loaded: cookie_helper
INFO - 2019-09-15 03:44:59 --> Helper loaded: date_helper
INFO - 2019-09-15 03:44:59 --> Form Validation Class Initialized
INFO - 2019-09-15 03:44:59 --> Email Class Initialized
DEBUG - 2019-09-15 03:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 03:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 03:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 03:44:59 --> Pagination Class Initialized
INFO - 2019-09-15 03:44:59 --> Database Driver Class Initialized
INFO - 2019-09-15 03:44:59 --> Database Driver Class Initialized
INFO - 2019-09-15 03:44:59 --> Controller Class Initialized
DEBUG - 2019-09-15 03:44:59 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 03:44:59 --> Helper loaded: inflector_helper
INFO - 2019-09-15 03:44:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 03:45:00 --> Final output sent to browser
DEBUG - 2019-09-15 03:45:00 --> Total execution time: 0.4545
INFO - 2019-09-15 03:46:09 --> Config Class Initialized
INFO - 2019-09-15 03:46:09 --> Hooks Class Initialized
DEBUG - 2019-09-15 03:46:09 --> UTF-8 Support Enabled
INFO - 2019-09-15 03:46:09 --> Utf8 Class Initialized
INFO - 2019-09-15 03:46:09 --> URI Class Initialized
INFO - 2019-09-15 03:46:09 --> Router Class Initialized
INFO - 2019-09-15 03:46:09 --> Output Class Initialized
INFO - 2019-09-15 03:46:09 --> Security Class Initialized
DEBUG - 2019-09-15 03:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 03:46:09 --> Input Class Initialized
INFO - 2019-09-15 03:46:09 --> Language Class Initialized
INFO - 2019-09-15 03:46:09 --> Loader Class Initialized
INFO - 2019-09-15 03:46:09 --> Helper loaded: url_helper
INFO - 2019-09-15 03:46:09 --> Helper loaded: html_helper
INFO - 2019-09-15 03:46:09 --> Helper loaded: form_helper
INFO - 2019-09-15 03:46:09 --> Helper loaded: cookie_helper
INFO - 2019-09-15 03:46:09 --> Helper loaded: date_helper
INFO - 2019-09-15 03:46:09 --> Form Validation Class Initialized
INFO - 2019-09-15 03:46:09 --> Email Class Initialized
DEBUG - 2019-09-15 03:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 03:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 03:46:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 03:46:09 --> Pagination Class Initialized
INFO - 2019-09-15 03:46:09 --> Database Driver Class Initialized
INFO - 2019-09-15 03:46:09 --> Database Driver Class Initialized
INFO - 2019-09-15 03:46:09 --> Controller Class Initialized
DEBUG - 2019-09-15 03:46:09 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 03:46:09 --> Helper loaded: inflector_helper
INFO - 2019-09-15 03:46:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 03:46:10 --> Final output sent to browser
DEBUG - 2019-09-15 03:46:10 --> Total execution time: 0.1773
INFO - 2019-09-15 03:50:34 --> Config Class Initialized
INFO - 2019-09-15 03:50:34 --> Hooks Class Initialized
DEBUG - 2019-09-15 03:50:34 --> UTF-8 Support Enabled
INFO - 2019-09-15 03:50:34 --> Utf8 Class Initialized
INFO - 2019-09-15 03:50:34 --> URI Class Initialized
INFO - 2019-09-15 03:50:34 --> Router Class Initialized
INFO - 2019-09-15 03:50:34 --> Output Class Initialized
INFO - 2019-09-15 03:50:34 --> Security Class Initialized
DEBUG - 2019-09-15 03:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 03:50:34 --> Input Class Initialized
INFO - 2019-09-15 03:50:34 --> Language Class Initialized
INFO - 2019-09-15 03:50:34 --> Loader Class Initialized
INFO - 2019-09-15 03:50:34 --> Helper loaded: url_helper
INFO - 2019-09-15 03:50:34 --> Helper loaded: html_helper
INFO - 2019-09-15 03:50:34 --> Helper loaded: form_helper
INFO - 2019-09-15 03:50:34 --> Helper loaded: cookie_helper
INFO - 2019-09-15 03:50:34 --> Helper loaded: date_helper
INFO - 2019-09-15 03:50:34 --> Form Validation Class Initialized
INFO - 2019-09-15 03:50:34 --> Email Class Initialized
DEBUG - 2019-09-15 03:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 03:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 03:50:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 03:50:34 --> Pagination Class Initialized
INFO - 2019-09-15 03:50:34 --> Database Driver Class Initialized
INFO - 2019-09-15 03:50:34 --> Database Driver Class Initialized
INFO - 2019-09-15 03:50:34 --> Controller Class Initialized
DEBUG - 2019-09-15 03:50:34 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 03:50:34 --> Helper loaded: inflector_helper
INFO - 2019-09-15 03:50:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 03:50:34 --> Final output sent to browser
DEBUG - 2019-09-15 03:50:34 --> Total execution time: 0.2292
INFO - 2019-09-15 04:07:11 --> Config Class Initialized
INFO - 2019-09-15 04:07:11 --> Hooks Class Initialized
DEBUG - 2019-09-15 04:07:11 --> UTF-8 Support Enabled
INFO - 2019-09-15 04:07:11 --> Utf8 Class Initialized
INFO - 2019-09-15 04:07:11 --> URI Class Initialized
INFO - 2019-09-15 04:07:11 --> Router Class Initialized
INFO - 2019-09-15 04:07:11 --> Output Class Initialized
INFO - 2019-09-15 04:07:11 --> Security Class Initialized
DEBUG - 2019-09-15 04:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 04:07:11 --> Input Class Initialized
INFO - 2019-09-15 04:07:11 --> Language Class Initialized
INFO - 2019-09-15 04:07:11 --> Loader Class Initialized
INFO - 2019-09-15 04:07:11 --> Helper loaded: url_helper
INFO - 2019-09-15 04:07:11 --> Helper loaded: html_helper
INFO - 2019-09-15 04:07:11 --> Helper loaded: form_helper
INFO - 2019-09-15 04:07:11 --> Helper loaded: cookie_helper
INFO - 2019-09-15 04:07:11 --> Helper loaded: date_helper
INFO - 2019-09-15 04:07:11 --> Form Validation Class Initialized
INFO - 2019-09-15 04:07:11 --> Email Class Initialized
DEBUG - 2019-09-15 04:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 04:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 04:07:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 04:07:11 --> Pagination Class Initialized
INFO - 2019-09-15 04:07:11 --> Database Driver Class Initialized
INFO - 2019-09-15 04:07:11 --> Database Driver Class Initialized
INFO - 2019-09-15 04:07:11 --> Controller Class Initialized
DEBUG - 2019-09-15 04:07:11 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 04:07:11 --> Helper loaded: inflector_helper
INFO - 2019-09-15 04:07:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 04:07:12 --> Final output sent to browser
DEBUG - 2019-09-15 04:07:12 --> Total execution time: 0.1770
INFO - 2019-09-15 07:12:37 --> Config Class Initialized
INFO - 2019-09-15 07:12:37 --> Hooks Class Initialized
DEBUG - 2019-09-15 07:12:37 --> UTF-8 Support Enabled
INFO - 2019-09-15 07:12:37 --> Utf8 Class Initialized
INFO - 2019-09-15 07:12:37 --> URI Class Initialized
INFO - 2019-09-15 07:12:37 --> Router Class Initialized
INFO - 2019-09-15 07:12:37 --> Output Class Initialized
INFO - 2019-09-15 07:12:37 --> Security Class Initialized
DEBUG - 2019-09-15 07:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 07:12:37 --> Input Class Initialized
INFO - 2019-09-15 07:12:37 --> Language Class Initialized
INFO - 2019-09-15 07:12:37 --> Loader Class Initialized
INFO - 2019-09-15 07:12:37 --> Helper loaded: url_helper
INFO - 2019-09-15 07:12:37 --> Helper loaded: html_helper
INFO - 2019-09-15 07:12:37 --> Helper loaded: form_helper
INFO - 2019-09-15 07:12:37 --> Helper loaded: cookie_helper
INFO - 2019-09-15 07:12:37 --> Helper loaded: date_helper
INFO - 2019-09-15 07:12:37 --> Form Validation Class Initialized
INFO - 2019-09-15 07:12:37 --> Email Class Initialized
DEBUG - 2019-09-15 07:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 07:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 07:12:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 07:12:37 --> Pagination Class Initialized
INFO - 2019-09-15 07:12:37 --> Database Driver Class Initialized
INFO - 2019-09-15 07:12:37 --> Database Driver Class Initialized
INFO - 2019-09-15 07:12:37 --> Controller Class Initialized
DEBUG - 2019-09-15 07:12:37 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 07:12:37 --> Helper loaded: inflector_helper
INFO - 2019-09-15 07:12:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 07:12:37 --> Final output sent to browser
DEBUG - 2019-09-15 07:12:37 --> Total execution time: 0.2075
INFO - 2019-09-15 07:17:05 --> Config Class Initialized
INFO - 2019-09-15 07:17:05 --> Hooks Class Initialized
DEBUG - 2019-09-15 07:17:05 --> UTF-8 Support Enabled
INFO - 2019-09-15 07:17:05 --> Utf8 Class Initialized
INFO - 2019-09-15 07:17:05 --> URI Class Initialized
INFO - 2019-09-15 07:17:05 --> Router Class Initialized
INFO - 2019-09-15 07:17:05 --> Output Class Initialized
INFO - 2019-09-15 07:17:05 --> Security Class Initialized
DEBUG - 2019-09-15 07:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 07:17:05 --> Input Class Initialized
INFO - 2019-09-15 07:17:05 --> Language Class Initialized
INFO - 2019-09-15 07:17:05 --> Loader Class Initialized
INFO - 2019-09-15 07:17:05 --> Helper loaded: url_helper
INFO - 2019-09-15 07:17:05 --> Helper loaded: html_helper
INFO - 2019-09-15 07:17:05 --> Helper loaded: form_helper
INFO - 2019-09-15 07:17:05 --> Helper loaded: cookie_helper
INFO - 2019-09-15 07:17:05 --> Helper loaded: date_helper
INFO - 2019-09-15 07:17:05 --> Form Validation Class Initialized
INFO - 2019-09-15 07:17:05 --> Email Class Initialized
DEBUG - 2019-09-15 07:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 07:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 07:17:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 07:17:05 --> Pagination Class Initialized
INFO - 2019-09-15 07:17:05 --> Database Driver Class Initialized
INFO - 2019-09-15 07:17:05 --> Database Driver Class Initialized
INFO - 2019-09-15 07:17:05 --> Controller Class Initialized
DEBUG - 2019-09-15 07:17:05 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 07:17:05 --> Helper loaded: inflector_helper
INFO - 2019-09-15 07:17:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 07:17:05 --> Final output sent to browser
DEBUG - 2019-09-15 07:17:05 --> Total execution time: 0.1389
INFO - 2019-09-15 13:16:11 --> Config Class Initialized
INFO - 2019-09-15 13:16:11 --> Hooks Class Initialized
DEBUG - 2019-09-15 13:16:11 --> UTF-8 Support Enabled
INFO - 2019-09-15 13:16:11 --> Utf8 Class Initialized
INFO - 2019-09-15 13:16:11 --> URI Class Initialized
INFO - 2019-09-15 13:16:11 --> Router Class Initialized
INFO - 2019-09-15 13:16:11 --> Output Class Initialized
INFO - 2019-09-15 13:16:11 --> Security Class Initialized
DEBUG - 2019-09-15 13:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 13:16:11 --> Input Class Initialized
INFO - 2019-09-15 13:16:11 --> Language Class Initialized
INFO - 2019-09-15 13:16:11 --> Loader Class Initialized
INFO - 2019-09-15 13:16:11 --> Helper loaded: url_helper
INFO - 2019-09-15 13:16:11 --> Helper loaded: html_helper
INFO - 2019-09-15 13:16:11 --> Helper loaded: form_helper
INFO - 2019-09-15 13:16:11 --> Helper loaded: cookie_helper
INFO - 2019-09-15 13:16:11 --> Helper loaded: date_helper
INFO - 2019-09-15 13:16:11 --> Form Validation Class Initialized
INFO - 2019-09-15 13:16:11 --> Email Class Initialized
DEBUG - 2019-09-15 13:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 13:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 13:16:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 13:16:11 --> Pagination Class Initialized
INFO - 2019-09-15 13:16:11 --> Database Driver Class Initialized
INFO - 2019-09-15 13:16:11 --> Database Driver Class Initialized
INFO - 2019-09-15 13:16:11 --> Controller Class Initialized
DEBUG - 2019-09-15 13:16:11 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 13:16:11 --> Helper loaded: inflector_helper
INFO - 2019-09-15 13:16:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 13:16:11 --> Final output sent to browser
DEBUG - 2019-09-15 13:16:11 --> Total execution time: 0.4225
INFO - 2019-09-15 13:16:12 --> Config Class Initialized
INFO - 2019-09-15 13:16:12 --> Hooks Class Initialized
DEBUG - 2019-09-15 13:16:12 --> UTF-8 Support Enabled
INFO - 2019-09-15 13:16:12 --> Utf8 Class Initialized
INFO - 2019-09-15 13:16:12 --> URI Class Initialized
INFO - 2019-09-15 13:16:12 --> Router Class Initialized
INFO - 2019-09-15 13:16:12 --> Output Class Initialized
INFO - 2019-09-15 13:16:12 --> Security Class Initialized
DEBUG - 2019-09-15 13:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 13:16:12 --> Input Class Initialized
INFO - 2019-09-15 13:16:12 --> Language Class Initialized
INFO - 2019-09-15 13:16:12 --> Loader Class Initialized
INFO - 2019-09-15 13:16:12 --> Helper loaded: url_helper
INFO - 2019-09-15 13:16:12 --> Helper loaded: html_helper
INFO - 2019-09-15 13:16:12 --> Helper loaded: form_helper
INFO - 2019-09-15 13:16:12 --> Helper loaded: cookie_helper
INFO - 2019-09-15 13:16:12 --> Helper loaded: date_helper
INFO - 2019-09-15 13:16:12 --> Form Validation Class Initialized
INFO - 2019-09-15 13:16:12 --> Email Class Initialized
DEBUG - 2019-09-15 13:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 13:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 13:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 13:16:12 --> Pagination Class Initialized
INFO - 2019-09-15 13:16:12 --> Database Driver Class Initialized
INFO - 2019-09-15 13:16:12 --> Database Driver Class Initialized
INFO - 2019-09-15 13:16:12 --> Controller Class Initialized
DEBUG - 2019-09-15 13:16:12 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 13:16:12 --> Helper loaded: inflector_helper
INFO - 2019-09-15 13:16:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 13:16:12 --> Final output sent to browser
DEBUG - 2019-09-15 13:16:12 --> Total execution time: 0.1314
INFO - 2019-09-15 13:21:55 --> Config Class Initialized
INFO - 2019-09-15 13:21:55 --> Hooks Class Initialized
DEBUG - 2019-09-15 13:21:55 --> UTF-8 Support Enabled
INFO - 2019-09-15 13:21:55 --> Utf8 Class Initialized
INFO - 2019-09-15 13:21:55 --> URI Class Initialized
INFO - 2019-09-15 13:21:55 --> Router Class Initialized
INFO - 2019-09-15 13:21:55 --> Output Class Initialized
INFO - 2019-09-15 13:21:55 --> Security Class Initialized
DEBUG - 2019-09-15 13:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 13:21:55 --> Input Class Initialized
INFO - 2019-09-15 13:21:55 --> Language Class Initialized
INFO - 2019-09-15 13:21:55 --> Loader Class Initialized
INFO - 2019-09-15 13:21:55 --> Helper loaded: url_helper
INFO - 2019-09-15 13:21:55 --> Helper loaded: html_helper
INFO - 2019-09-15 13:21:55 --> Helper loaded: form_helper
INFO - 2019-09-15 13:21:55 --> Helper loaded: cookie_helper
INFO - 2019-09-15 13:21:55 --> Helper loaded: date_helper
INFO - 2019-09-15 13:21:55 --> Form Validation Class Initialized
INFO - 2019-09-15 13:21:55 --> Email Class Initialized
DEBUG - 2019-09-15 13:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 13:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 13:21:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 13:21:55 --> Pagination Class Initialized
INFO - 2019-09-15 13:21:55 --> Database Driver Class Initialized
INFO - 2019-09-15 13:21:55 --> Database Driver Class Initialized
INFO - 2019-09-15 13:21:55 --> Controller Class Initialized
DEBUG - 2019-09-15 13:21:55 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 13:21:55 --> Helper loaded: inflector_helper
INFO - 2019-09-15 13:21:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 13:21:55 --> Final output sent to browser
DEBUG - 2019-09-15 13:21:55 --> Total execution time: 0.1325
INFO - 2019-09-15 13:46:56 --> Config Class Initialized
INFO - 2019-09-15 13:46:56 --> Hooks Class Initialized
DEBUG - 2019-09-15 13:46:56 --> UTF-8 Support Enabled
INFO - 2019-09-15 13:46:56 --> Utf8 Class Initialized
INFO - 2019-09-15 13:46:56 --> URI Class Initialized
INFO - 2019-09-15 13:46:56 --> Router Class Initialized
INFO - 2019-09-15 13:46:56 --> Output Class Initialized
INFO - 2019-09-15 13:46:56 --> Security Class Initialized
DEBUG - 2019-09-15 13:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 13:46:56 --> Input Class Initialized
INFO - 2019-09-15 13:46:56 --> Language Class Initialized
INFO - 2019-09-15 13:46:56 --> Loader Class Initialized
INFO - 2019-09-15 13:46:56 --> Helper loaded: url_helper
INFO - 2019-09-15 13:46:56 --> Helper loaded: html_helper
INFO - 2019-09-15 13:46:56 --> Helper loaded: form_helper
INFO - 2019-09-15 13:46:56 --> Helper loaded: cookie_helper
INFO - 2019-09-15 13:46:56 --> Helper loaded: date_helper
INFO - 2019-09-15 13:46:56 --> Form Validation Class Initialized
INFO - 2019-09-15 13:46:56 --> Email Class Initialized
DEBUG - 2019-09-15 13:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 13:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 13:46:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 13:46:56 --> Pagination Class Initialized
INFO - 2019-09-15 13:46:56 --> Database Driver Class Initialized
INFO - 2019-09-15 13:46:56 --> Database Driver Class Initialized
INFO - 2019-09-15 13:46:56 --> Controller Class Initialized
DEBUG - 2019-09-15 13:46:56 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 13:46:56 --> Helper loaded: inflector_helper
INFO - 2019-09-15 13:46:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 13:46:56 --> Final output sent to browser
DEBUG - 2019-09-15 13:46:56 --> Total execution time: 0.2596
INFO - 2019-09-15 13:47:50 --> Config Class Initialized
INFO - 2019-09-15 13:47:50 --> Hooks Class Initialized
DEBUG - 2019-09-15 13:47:50 --> UTF-8 Support Enabled
INFO - 2019-09-15 13:47:50 --> Utf8 Class Initialized
INFO - 2019-09-15 13:47:50 --> URI Class Initialized
INFO - 2019-09-15 13:47:50 --> Router Class Initialized
INFO - 2019-09-15 13:47:50 --> Output Class Initialized
INFO - 2019-09-15 13:47:50 --> Security Class Initialized
DEBUG - 2019-09-15 13:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 13:47:50 --> Input Class Initialized
INFO - 2019-09-15 13:47:50 --> Language Class Initialized
INFO - 2019-09-15 13:47:50 --> Loader Class Initialized
INFO - 2019-09-15 13:47:50 --> Helper loaded: url_helper
INFO - 2019-09-15 13:47:50 --> Helper loaded: html_helper
INFO - 2019-09-15 13:47:50 --> Helper loaded: form_helper
INFO - 2019-09-15 13:47:50 --> Helper loaded: cookie_helper
INFO - 2019-09-15 13:47:50 --> Helper loaded: date_helper
INFO - 2019-09-15 13:47:50 --> Form Validation Class Initialized
INFO - 2019-09-15 13:47:50 --> Email Class Initialized
DEBUG - 2019-09-15 13:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 13:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 13:47:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 13:47:51 --> Pagination Class Initialized
INFO - 2019-09-15 13:47:51 --> Database Driver Class Initialized
INFO - 2019-09-15 13:47:51 --> Database Driver Class Initialized
INFO - 2019-09-15 13:47:51 --> Controller Class Initialized
DEBUG - 2019-09-15 13:47:51 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 13:47:51 --> Helper loaded: inflector_helper
INFO - 2019-09-15 13:47:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 13:47:51 --> Final output sent to browser
DEBUG - 2019-09-15 13:47:51 --> Total execution time: 0.1417
INFO - 2019-09-15 13:48:26 --> Config Class Initialized
INFO - 2019-09-15 13:48:26 --> Hooks Class Initialized
DEBUG - 2019-09-15 13:48:26 --> UTF-8 Support Enabled
INFO - 2019-09-15 13:48:26 --> Utf8 Class Initialized
INFO - 2019-09-15 13:48:26 --> URI Class Initialized
INFO - 2019-09-15 13:48:26 --> Router Class Initialized
INFO - 2019-09-15 13:48:26 --> Output Class Initialized
INFO - 2019-09-15 13:48:26 --> Security Class Initialized
DEBUG - 2019-09-15 13:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 13:48:26 --> Input Class Initialized
INFO - 2019-09-15 13:48:26 --> Language Class Initialized
INFO - 2019-09-15 13:48:26 --> Loader Class Initialized
INFO - 2019-09-15 13:48:26 --> Helper loaded: url_helper
INFO - 2019-09-15 13:48:26 --> Helper loaded: html_helper
INFO - 2019-09-15 13:48:26 --> Helper loaded: form_helper
INFO - 2019-09-15 13:48:26 --> Helper loaded: cookie_helper
INFO - 2019-09-15 13:48:26 --> Helper loaded: date_helper
INFO - 2019-09-15 13:48:26 --> Form Validation Class Initialized
INFO - 2019-09-15 13:48:26 --> Email Class Initialized
DEBUG - 2019-09-15 13:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 13:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 13:48:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 13:48:26 --> Pagination Class Initialized
INFO - 2019-09-15 13:48:26 --> Database Driver Class Initialized
INFO - 2019-09-15 13:48:26 --> Database Driver Class Initialized
INFO - 2019-09-15 13:48:26 --> Controller Class Initialized
DEBUG - 2019-09-15 13:48:26 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 13:48:26 --> Helper loaded: inflector_helper
INFO - 2019-09-15 13:48:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 13:48:26 --> Final output sent to browser
DEBUG - 2019-09-15 13:48:26 --> Total execution time: 0.2276
INFO - 2019-09-15 13:50:31 --> Config Class Initialized
INFO - 2019-09-15 13:50:31 --> Hooks Class Initialized
DEBUG - 2019-09-15 13:50:31 --> UTF-8 Support Enabled
INFO - 2019-09-15 13:50:31 --> Utf8 Class Initialized
INFO - 2019-09-15 13:50:31 --> URI Class Initialized
INFO - 2019-09-15 13:50:31 --> Router Class Initialized
INFO - 2019-09-15 13:50:31 --> Output Class Initialized
INFO - 2019-09-15 13:50:31 --> Security Class Initialized
DEBUG - 2019-09-15 13:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 13:50:31 --> Input Class Initialized
INFO - 2019-09-15 13:50:31 --> Language Class Initialized
INFO - 2019-09-15 13:50:31 --> Loader Class Initialized
INFO - 2019-09-15 13:50:31 --> Helper loaded: url_helper
INFO - 2019-09-15 13:50:31 --> Helper loaded: html_helper
INFO - 2019-09-15 13:50:31 --> Helper loaded: form_helper
INFO - 2019-09-15 13:50:31 --> Helper loaded: cookie_helper
INFO - 2019-09-15 13:50:31 --> Helper loaded: date_helper
INFO - 2019-09-15 13:50:31 --> Form Validation Class Initialized
INFO - 2019-09-15 13:50:31 --> Email Class Initialized
DEBUG - 2019-09-15 13:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 13:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 13:50:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 13:50:31 --> Pagination Class Initialized
INFO - 2019-09-15 13:50:31 --> Database Driver Class Initialized
INFO - 2019-09-15 13:50:31 --> Database Driver Class Initialized
INFO - 2019-09-15 13:50:31 --> Controller Class Initialized
DEBUG - 2019-09-15 13:50:31 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 13:50:31 --> Helper loaded: inflector_helper
INFO - 2019-09-15 13:50:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 13:50:31 --> Final output sent to browser
DEBUG - 2019-09-15 13:50:31 --> Total execution time: 0.2523
INFO - 2019-09-15 14:32:14 --> Config Class Initialized
INFO - 2019-09-15 14:32:14 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:32:14 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:32:14 --> Utf8 Class Initialized
INFO - 2019-09-15 14:32:14 --> URI Class Initialized
INFO - 2019-09-15 14:32:14 --> Router Class Initialized
INFO - 2019-09-15 14:32:14 --> Output Class Initialized
INFO - 2019-09-15 14:32:14 --> Security Class Initialized
DEBUG - 2019-09-15 14:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:32:14 --> Input Class Initialized
INFO - 2019-09-15 14:32:14 --> Language Class Initialized
INFO - 2019-09-15 14:32:14 --> Loader Class Initialized
INFO - 2019-09-15 14:32:14 --> Helper loaded: url_helper
INFO - 2019-09-15 14:32:14 --> Helper loaded: html_helper
INFO - 2019-09-15 14:32:14 --> Helper loaded: form_helper
INFO - 2019-09-15 14:32:14 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:32:14 --> Helper loaded: date_helper
INFO - 2019-09-15 14:32:14 --> Form Validation Class Initialized
INFO - 2019-09-15 14:32:14 --> Email Class Initialized
DEBUG - 2019-09-15 14:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:32:14 --> Pagination Class Initialized
INFO - 2019-09-15 14:32:14 --> Database Driver Class Initialized
INFO - 2019-09-15 14:32:14 --> Database Driver Class Initialized
INFO - 2019-09-15 14:32:15 --> Controller Class Initialized
DEBUG - 2019-09-15 14:32:15 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:32:15 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:32:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:32:15 --> Final output sent to browser
DEBUG - 2019-09-15 14:32:15 --> Total execution time: 0.2078
INFO - 2019-09-15 14:32:15 --> Config Class Initialized
INFO - 2019-09-15 14:32:15 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:32:15 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:32:15 --> Utf8 Class Initialized
INFO - 2019-09-15 14:32:15 --> URI Class Initialized
INFO - 2019-09-15 14:32:15 --> Router Class Initialized
INFO - 2019-09-15 14:32:15 --> Output Class Initialized
INFO - 2019-09-15 14:32:15 --> Security Class Initialized
DEBUG - 2019-09-15 14:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:32:15 --> Input Class Initialized
INFO - 2019-09-15 14:32:15 --> Language Class Initialized
INFO - 2019-09-15 14:32:15 --> Loader Class Initialized
INFO - 2019-09-15 14:32:15 --> Helper loaded: url_helper
INFO - 2019-09-15 14:32:15 --> Helper loaded: html_helper
INFO - 2019-09-15 14:32:15 --> Helper loaded: form_helper
INFO - 2019-09-15 14:32:15 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:32:15 --> Helper loaded: date_helper
INFO - 2019-09-15 14:32:15 --> Form Validation Class Initialized
INFO - 2019-09-15 14:32:15 --> Email Class Initialized
DEBUG - 2019-09-15 14:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:32:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:32:15 --> Pagination Class Initialized
INFO - 2019-09-15 14:32:15 --> Database Driver Class Initialized
INFO - 2019-09-15 14:32:15 --> Database Driver Class Initialized
INFO - 2019-09-15 14:32:15 --> Controller Class Initialized
DEBUG - 2019-09-15 14:32:15 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:32:15 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:32:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:32:15 --> Final output sent to browser
DEBUG - 2019-09-15 14:32:15 --> Total execution time: 0.2647
INFO - 2019-09-15 14:32:15 --> Config Class Initialized
INFO - 2019-09-15 14:32:15 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:32:15 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:32:15 --> Utf8 Class Initialized
INFO - 2019-09-15 14:32:15 --> URI Class Initialized
INFO - 2019-09-15 14:32:15 --> Router Class Initialized
INFO - 2019-09-15 14:32:15 --> Output Class Initialized
INFO - 2019-09-15 14:32:15 --> Security Class Initialized
DEBUG - 2019-09-15 14:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:32:15 --> Input Class Initialized
INFO - 2019-09-15 14:32:15 --> Language Class Initialized
INFO - 2019-09-15 14:32:15 --> Loader Class Initialized
INFO - 2019-09-15 14:32:15 --> Helper loaded: url_helper
INFO - 2019-09-15 14:32:15 --> Helper loaded: html_helper
INFO - 2019-09-15 14:32:15 --> Helper loaded: form_helper
INFO - 2019-09-15 14:32:15 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:32:15 --> Helper loaded: date_helper
INFO - 2019-09-15 14:32:15 --> Form Validation Class Initialized
INFO - 2019-09-15 14:32:15 --> Email Class Initialized
DEBUG - 2019-09-15 14:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:32:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:32:15 --> Pagination Class Initialized
INFO - 2019-09-15 14:32:15 --> Database Driver Class Initialized
INFO - 2019-09-15 14:32:15 --> Database Driver Class Initialized
INFO - 2019-09-15 14:32:15 --> Controller Class Initialized
DEBUG - 2019-09-15 14:32:15 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:32:15 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:32:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:32:15 --> Final output sent to browser
DEBUG - 2019-09-15 14:32:15 --> Total execution time: 0.2274
INFO - 2019-09-15 14:32:15 --> Config Class Initialized
INFO - 2019-09-15 14:32:15 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:32:15 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:32:15 --> Utf8 Class Initialized
INFO - 2019-09-15 14:32:15 --> URI Class Initialized
INFO - 2019-09-15 14:32:15 --> Router Class Initialized
INFO - 2019-09-15 14:32:15 --> Output Class Initialized
INFO - 2019-09-15 14:32:15 --> Security Class Initialized
DEBUG - 2019-09-15 14:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:32:15 --> Input Class Initialized
INFO - 2019-09-15 14:32:15 --> Language Class Initialized
INFO - 2019-09-15 14:32:15 --> Loader Class Initialized
INFO - 2019-09-15 14:32:15 --> Helper loaded: url_helper
INFO - 2019-09-15 14:32:15 --> Helper loaded: html_helper
INFO - 2019-09-15 14:32:15 --> Helper loaded: form_helper
INFO - 2019-09-15 14:32:15 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:32:15 --> Helper loaded: date_helper
INFO - 2019-09-15 14:32:15 --> Form Validation Class Initialized
INFO - 2019-09-15 14:32:15 --> Email Class Initialized
DEBUG - 2019-09-15 14:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:32:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:32:15 --> Pagination Class Initialized
INFO - 2019-09-15 14:32:15 --> Database Driver Class Initialized
INFO - 2019-09-15 14:32:15 --> Database Driver Class Initialized
INFO - 2019-09-15 14:32:15 --> Controller Class Initialized
DEBUG - 2019-09-15 14:32:15 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:32:15 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:32:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:32:15 --> Final output sent to browser
DEBUG - 2019-09-15 14:32:15 --> Total execution time: 0.1077
INFO - 2019-09-15 14:34:17 --> Config Class Initialized
INFO - 2019-09-15 14:34:17 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:34:17 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:34:17 --> Utf8 Class Initialized
INFO - 2019-09-15 14:34:17 --> URI Class Initialized
INFO - 2019-09-15 14:34:17 --> Router Class Initialized
INFO - 2019-09-15 14:34:17 --> Output Class Initialized
INFO - 2019-09-15 14:34:17 --> Security Class Initialized
DEBUG - 2019-09-15 14:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:34:17 --> Input Class Initialized
INFO - 2019-09-15 14:34:17 --> Language Class Initialized
INFO - 2019-09-15 14:34:17 --> Loader Class Initialized
INFO - 2019-09-15 14:34:17 --> Helper loaded: url_helper
INFO - 2019-09-15 14:34:17 --> Helper loaded: html_helper
INFO - 2019-09-15 14:34:17 --> Helper loaded: form_helper
INFO - 2019-09-15 14:34:17 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:34:17 --> Helper loaded: date_helper
INFO - 2019-09-15 14:34:17 --> Form Validation Class Initialized
INFO - 2019-09-15 14:34:17 --> Email Class Initialized
DEBUG - 2019-09-15 14:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:34:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:34:17 --> Pagination Class Initialized
INFO - 2019-09-15 14:34:17 --> Database Driver Class Initialized
INFO - 2019-09-15 14:34:17 --> Database Driver Class Initialized
INFO - 2019-09-15 14:34:17 --> Controller Class Initialized
DEBUG - 2019-09-15 14:34:17 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:34:17 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:34:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:34:17 --> Final output sent to browser
DEBUG - 2019-09-15 14:34:17 --> Total execution time: 0.2072
INFO - 2019-09-15 14:34:18 --> Config Class Initialized
INFO - 2019-09-15 14:34:18 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:34:18 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:34:18 --> Utf8 Class Initialized
INFO - 2019-09-15 14:34:18 --> URI Class Initialized
INFO - 2019-09-15 14:34:18 --> Router Class Initialized
INFO - 2019-09-15 14:34:18 --> Output Class Initialized
INFO - 2019-09-15 14:34:18 --> Security Class Initialized
DEBUG - 2019-09-15 14:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:34:18 --> Input Class Initialized
INFO - 2019-09-15 14:34:18 --> Language Class Initialized
INFO - 2019-09-15 14:34:18 --> Loader Class Initialized
INFO - 2019-09-15 14:34:18 --> Helper loaded: url_helper
INFO - 2019-09-15 14:34:18 --> Helper loaded: html_helper
INFO - 2019-09-15 14:34:18 --> Helper loaded: form_helper
INFO - 2019-09-15 14:34:18 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:34:18 --> Helper loaded: date_helper
INFO - 2019-09-15 14:34:18 --> Form Validation Class Initialized
INFO - 2019-09-15 14:34:18 --> Email Class Initialized
DEBUG - 2019-09-15 14:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:34:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:34:18 --> Pagination Class Initialized
INFO - 2019-09-15 14:34:18 --> Database Driver Class Initialized
INFO - 2019-09-15 14:34:18 --> Database Driver Class Initialized
INFO - 2019-09-15 14:34:18 --> Controller Class Initialized
DEBUG - 2019-09-15 14:34:18 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:34:18 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:34:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:34:18 --> Final output sent to browser
DEBUG - 2019-09-15 14:34:18 --> Total execution time: 0.2850
INFO - 2019-09-15 14:36:18 --> Config Class Initialized
INFO - 2019-09-15 14:36:18 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:36:18 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:36:18 --> Utf8 Class Initialized
INFO - 2019-09-15 14:36:18 --> URI Class Initialized
INFO - 2019-09-15 14:36:18 --> Router Class Initialized
INFO - 2019-09-15 14:36:18 --> Output Class Initialized
INFO - 2019-09-15 14:36:18 --> Security Class Initialized
DEBUG - 2019-09-15 14:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:36:18 --> Input Class Initialized
INFO - 2019-09-15 14:36:18 --> Language Class Initialized
INFO - 2019-09-15 14:36:18 --> Loader Class Initialized
INFO - 2019-09-15 14:36:18 --> Helper loaded: url_helper
INFO - 2019-09-15 14:36:18 --> Helper loaded: html_helper
INFO - 2019-09-15 14:36:18 --> Helper loaded: form_helper
INFO - 2019-09-15 14:36:18 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:36:18 --> Helper loaded: date_helper
INFO - 2019-09-15 14:36:18 --> Form Validation Class Initialized
INFO - 2019-09-15 14:36:18 --> Email Class Initialized
DEBUG - 2019-09-15 14:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:36:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:36:18 --> Pagination Class Initialized
INFO - 2019-09-15 14:36:18 --> Database Driver Class Initialized
INFO - 2019-09-15 14:36:18 --> Database Driver Class Initialized
INFO - 2019-09-15 14:36:18 --> Controller Class Initialized
DEBUG - 2019-09-15 14:36:18 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:36:18 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:36:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:36:18 --> Final output sent to browser
DEBUG - 2019-09-15 14:36:18 --> Total execution time: 0.2478
INFO - 2019-09-15 14:36:18 --> Config Class Initialized
INFO - 2019-09-15 14:36:18 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:36:18 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:36:18 --> Utf8 Class Initialized
INFO - 2019-09-15 14:36:18 --> URI Class Initialized
INFO - 2019-09-15 14:36:18 --> Router Class Initialized
INFO - 2019-09-15 14:36:18 --> Output Class Initialized
INFO - 2019-09-15 14:36:18 --> Security Class Initialized
DEBUG - 2019-09-15 14:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:36:18 --> Input Class Initialized
INFO - 2019-09-15 14:36:18 --> Language Class Initialized
INFO - 2019-09-15 14:36:18 --> Loader Class Initialized
INFO - 2019-09-15 14:36:18 --> Helper loaded: url_helper
INFO - 2019-09-15 14:36:18 --> Helper loaded: html_helper
INFO - 2019-09-15 14:36:18 --> Helper loaded: form_helper
INFO - 2019-09-15 14:36:18 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:36:18 --> Helper loaded: date_helper
INFO - 2019-09-15 14:36:18 --> Form Validation Class Initialized
INFO - 2019-09-15 14:36:18 --> Email Class Initialized
DEBUG - 2019-09-15 14:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:36:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:36:18 --> Pagination Class Initialized
INFO - 2019-09-15 14:36:18 --> Database Driver Class Initialized
INFO - 2019-09-15 14:36:18 --> Database Driver Class Initialized
INFO - 2019-09-15 14:36:18 --> Controller Class Initialized
DEBUG - 2019-09-15 14:36:18 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:36:18 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:36:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:36:18 --> Final output sent to browser
DEBUG - 2019-09-15 14:36:18 --> Total execution time: 0.2101
INFO - 2019-09-15 14:38:15 --> Config Class Initialized
INFO - 2019-09-15 14:38:15 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:38:15 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:38:15 --> Utf8 Class Initialized
INFO - 2019-09-15 14:38:15 --> URI Class Initialized
INFO - 2019-09-15 14:38:15 --> Router Class Initialized
INFO - 2019-09-15 14:38:15 --> Output Class Initialized
INFO - 2019-09-15 14:38:15 --> Security Class Initialized
DEBUG - 2019-09-15 14:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:38:15 --> Input Class Initialized
INFO - 2019-09-15 14:38:15 --> Language Class Initialized
INFO - 2019-09-15 14:38:15 --> Loader Class Initialized
INFO - 2019-09-15 14:38:15 --> Helper loaded: url_helper
INFO - 2019-09-15 14:38:15 --> Helper loaded: html_helper
INFO - 2019-09-15 14:38:15 --> Helper loaded: form_helper
INFO - 2019-09-15 14:38:15 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:38:15 --> Helper loaded: date_helper
INFO - 2019-09-15 14:38:15 --> Form Validation Class Initialized
INFO - 2019-09-15 14:38:15 --> Email Class Initialized
DEBUG - 2019-09-15 14:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:38:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:38:15 --> Pagination Class Initialized
INFO - 2019-09-15 14:38:15 --> Database Driver Class Initialized
INFO - 2019-09-15 14:38:15 --> Database Driver Class Initialized
INFO - 2019-09-15 14:38:15 --> Controller Class Initialized
DEBUG - 2019-09-15 14:38:15 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:38:15 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:38:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:38:15 --> Final output sent to browser
DEBUG - 2019-09-15 14:38:15 --> Total execution time: 0.1310
INFO - 2019-09-15 14:39:52 --> Config Class Initialized
INFO - 2019-09-15 14:39:52 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:39:52 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:39:52 --> Utf8 Class Initialized
INFO - 2019-09-15 14:39:52 --> URI Class Initialized
INFO - 2019-09-15 14:39:52 --> Router Class Initialized
INFO - 2019-09-15 14:39:52 --> Output Class Initialized
INFO - 2019-09-15 14:39:52 --> Security Class Initialized
DEBUG - 2019-09-15 14:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:39:52 --> Input Class Initialized
INFO - 2019-09-15 14:39:52 --> Language Class Initialized
INFO - 2019-09-15 14:39:52 --> Loader Class Initialized
INFO - 2019-09-15 14:39:52 --> Helper loaded: url_helper
INFO - 2019-09-15 14:39:52 --> Helper loaded: html_helper
INFO - 2019-09-15 14:39:52 --> Helper loaded: form_helper
INFO - 2019-09-15 14:39:52 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:39:52 --> Helper loaded: date_helper
INFO - 2019-09-15 14:39:52 --> Form Validation Class Initialized
INFO - 2019-09-15 14:39:52 --> Email Class Initialized
DEBUG - 2019-09-15 14:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:39:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:39:52 --> Pagination Class Initialized
INFO - 2019-09-15 14:39:52 --> Database Driver Class Initialized
INFO - 2019-09-15 14:39:52 --> Database Driver Class Initialized
INFO - 2019-09-15 14:39:52 --> Controller Class Initialized
DEBUG - 2019-09-15 14:39:52 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:39:52 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:39:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:39:52 --> Final output sent to browser
DEBUG - 2019-09-15 14:39:52 --> Total execution time: 0.1650
INFO - 2019-09-15 14:39:52 --> Config Class Initialized
INFO - 2019-09-15 14:39:52 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:39:52 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:39:52 --> Utf8 Class Initialized
INFO - 2019-09-15 14:39:52 --> URI Class Initialized
INFO - 2019-09-15 14:39:52 --> Router Class Initialized
INFO - 2019-09-15 14:39:52 --> Output Class Initialized
INFO - 2019-09-15 14:39:53 --> Security Class Initialized
DEBUG - 2019-09-15 14:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:39:53 --> Input Class Initialized
INFO - 2019-09-15 14:39:53 --> Language Class Initialized
INFO - 2019-09-15 14:39:53 --> Loader Class Initialized
INFO - 2019-09-15 14:39:53 --> Helper loaded: url_helper
INFO - 2019-09-15 14:39:53 --> Helper loaded: html_helper
INFO - 2019-09-15 14:39:53 --> Helper loaded: form_helper
INFO - 2019-09-15 14:39:53 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:39:53 --> Helper loaded: date_helper
INFO - 2019-09-15 14:39:53 --> Form Validation Class Initialized
INFO - 2019-09-15 14:39:53 --> Email Class Initialized
DEBUG - 2019-09-15 14:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:39:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:39:53 --> Pagination Class Initialized
INFO - 2019-09-15 14:39:53 --> Database Driver Class Initialized
INFO - 2019-09-15 14:39:53 --> Database Driver Class Initialized
INFO - 2019-09-15 14:39:53 --> Controller Class Initialized
DEBUG - 2019-09-15 14:39:53 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:39:53 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:39:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:39:53 --> Final output sent to browser
DEBUG - 2019-09-15 14:39:53 --> Total execution time: 0.3735
INFO - 2019-09-15 14:39:53 --> Config Class Initialized
INFO - 2019-09-15 14:39:53 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:39:53 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:39:53 --> Utf8 Class Initialized
INFO - 2019-09-15 14:39:53 --> URI Class Initialized
INFO - 2019-09-15 14:39:53 --> Router Class Initialized
INFO - 2019-09-15 14:39:53 --> Output Class Initialized
INFO - 2019-09-15 14:39:53 --> Security Class Initialized
DEBUG - 2019-09-15 14:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:39:53 --> Input Class Initialized
INFO - 2019-09-15 14:39:53 --> Language Class Initialized
INFO - 2019-09-15 14:39:53 --> Loader Class Initialized
INFO - 2019-09-15 14:39:53 --> Helper loaded: url_helper
INFO - 2019-09-15 14:39:53 --> Helper loaded: html_helper
INFO - 2019-09-15 14:39:53 --> Helper loaded: form_helper
INFO - 2019-09-15 14:39:53 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:39:53 --> Helper loaded: date_helper
INFO - 2019-09-15 14:39:53 --> Form Validation Class Initialized
INFO - 2019-09-15 14:39:53 --> Email Class Initialized
DEBUG - 2019-09-15 14:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:39:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:39:53 --> Pagination Class Initialized
INFO - 2019-09-15 14:39:53 --> Database Driver Class Initialized
INFO - 2019-09-15 14:39:53 --> Database Driver Class Initialized
INFO - 2019-09-15 14:39:53 --> Controller Class Initialized
DEBUG - 2019-09-15 14:39:53 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:39:53 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:39:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:39:53 --> Final output sent to browser
DEBUG - 2019-09-15 14:39:53 --> Total execution time: 0.1879
INFO - 2019-09-15 14:43:28 --> Config Class Initialized
INFO - 2019-09-15 14:43:28 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:43:28 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:43:28 --> Utf8 Class Initialized
INFO - 2019-09-15 14:43:28 --> URI Class Initialized
INFO - 2019-09-15 14:43:28 --> Router Class Initialized
INFO - 2019-09-15 14:43:28 --> Output Class Initialized
INFO - 2019-09-15 14:43:28 --> Security Class Initialized
DEBUG - 2019-09-15 14:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:43:28 --> Input Class Initialized
INFO - 2019-09-15 14:43:28 --> Language Class Initialized
INFO - 2019-09-15 14:43:28 --> Loader Class Initialized
INFO - 2019-09-15 14:43:28 --> Helper loaded: url_helper
INFO - 2019-09-15 14:43:28 --> Helper loaded: html_helper
INFO - 2019-09-15 14:43:28 --> Helper loaded: form_helper
INFO - 2019-09-15 14:43:28 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:43:28 --> Helper loaded: date_helper
INFO - 2019-09-15 14:43:28 --> Form Validation Class Initialized
INFO - 2019-09-15 14:43:28 --> Email Class Initialized
DEBUG - 2019-09-15 14:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:43:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:43:28 --> Pagination Class Initialized
INFO - 2019-09-15 14:43:28 --> Database Driver Class Initialized
INFO - 2019-09-15 14:43:28 --> Database Driver Class Initialized
INFO - 2019-09-15 14:43:28 --> Controller Class Initialized
DEBUG - 2019-09-15 14:43:28 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:43:28 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:43:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:43:28 --> Final output sent to browser
DEBUG - 2019-09-15 14:43:28 --> Total execution time: 0.2268
INFO - 2019-09-15 14:43:28 --> Config Class Initialized
INFO - 2019-09-15 14:43:28 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:43:28 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:43:28 --> Utf8 Class Initialized
INFO - 2019-09-15 14:43:28 --> URI Class Initialized
INFO - 2019-09-15 14:43:28 --> Router Class Initialized
INFO - 2019-09-15 14:43:28 --> Output Class Initialized
INFO - 2019-09-15 14:43:28 --> Security Class Initialized
DEBUG - 2019-09-15 14:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:43:28 --> Input Class Initialized
INFO - 2019-09-15 14:43:28 --> Language Class Initialized
INFO - 2019-09-15 14:43:28 --> Loader Class Initialized
INFO - 2019-09-15 14:43:29 --> Helper loaded: url_helper
INFO - 2019-09-15 14:43:29 --> Helper loaded: html_helper
INFO - 2019-09-15 14:43:29 --> Helper loaded: form_helper
INFO - 2019-09-15 14:43:29 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:43:29 --> Helper loaded: date_helper
INFO - 2019-09-15 14:43:29 --> Form Validation Class Initialized
INFO - 2019-09-15 14:43:29 --> Email Class Initialized
DEBUG - 2019-09-15 14:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:43:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:43:29 --> Pagination Class Initialized
INFO - 2019-09-15 14:43:29 --> Database Driver Class Initialized
INFO - 2019-09-15 14:43:29 --> Database Driver Class Initialized
INFO - 2019-09-15 14:43:29 --> Controller Class Initialized
DEBUG - 2019-09-15 14:43:29 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:43:29 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:43:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:43:29 --> Final output sent to browser
DEBUG - 2019-09-15 14:43:29 --> Total execution time: 0.2071
INFO - 2019-09-15 14:43:29 --> Config Class Initialized
INFO - 2019-09-15 14:43:29 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:43:29 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:43:29 --> Utf8 Class Initialized
INFO - 2019-09-15 14:43:29 --> URI Class Initialized
INFO - 2019-09-15 14:43:29 --> Router Class Initialized
INFO - 2019-09-15 14:43:29 --> Output Class Initialized
INFO - 2019-09-15 14:43:29 --> Security Class Initialized
DEBUG - 2019-09-15 14:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:43:29 --> Input Class Initialized
INFO - 2019-09-15 14:43:29 --> Language Class Initialized
INFO - 2019-09-15 14:43:29 --> Loader Class Initialized
INFO - 2019-09-15 14:43:29 --> Helper loaded: url_helper
INFO - 2019-09-15 14:43:29 --> Helper loaded: html_helper
INFO - 2019-09-15 14:43:29 --> Helper loaded: form_helper
INFO - 2019-09-15 14:43:29 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:43:29 --> Helper loaded: date_helper
INFO - 2019-09-15 14:43:29 --> Form Validation Class Initialized
INFO - 2019-09-15 14:43:29 --> Email Class Initialized
DEBUG - 2019-09-15 14:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:43:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:43:29 --> Pagination Class Initialized
INFO - 2019-09-15 14:43:29 --> Database Driver Class Initialized
INFO - 2019-09-15 14:43:29 --> Database Driver Class Initialized
INFO - 2019-09-15 14:43:29 --> Controller Class Initialized
DEBUG - 2019-09-15 14:43:29 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:43:29 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:43:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:43:29 --> Final output sent to browser
DEBUG - 2019-09-15 14:43:29 --> Total execution time: 0.2455
INFO - 2019-09-15 14:45:09 --> Config Class Initialized
INFO - 2019-09-15 14:45:09 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:45:09 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:45:09 --> Utf8 Class Initialized
INFO - 2019-09-15 14:45:09 --> URI Class Initialized
INFO - 2019-09-15 14:45:09 --> Router Class Initialized
INFO - 2019-09-15 14:45:09 --> Output Class Initialized
INFO - 2019-09-15 14:45:09 --> Security Class Initialized
DEBUG - 2019-09-15 14:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:45:09 --> Input Class Initialized
INFO - 2019-09-15 14:45:09 --> Language Class Initialized
INFO - 2019-09-15 14:45:09 --> Loader Class Initialized
INFO - 2019-09-15 14:45:09 --> Helper loaded: url_helper
INFO - 2019-09-15 14:45:09 --> Helper loaded: html_helper
INFO - 2019-09-15 14:45:09 --> Helper loaded: form_helper
INFO - 2019-09-15 14:45:09 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:45:09 --> Helper loaded: date_helper
INFO - 2019-09-15 14:45:09 --> Form Validation Class Initialized
INFO - 2019-09-15 14:45:09 --> Email Class Initialized
DEBUG - 2019-09-15 14:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:45:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:45:09 --> Pagination Class Initialized
INFO - 2019-09-15 14:45:09 --> Database Driver Class Initialized
INFO - 2019-09-15 14:45:09 --> Database Driver Class Initialized
INFO - 2019-09-15 14:45:09 --> Controller Class Initialized
DEBUG - 2019-09-15 14:45:09 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:45:09 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:45:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:45:09 --> Final output sent to browser
DEBUG - 2019-09-15 14:45:09 --> Total execution time: 0.2004
INFO - 2019-09-15 14:45:29 --> Config Class Initialized
INFO - 2019-09-15 14:45:29 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:45:29 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:45:29 --> Utf8 Class Initialized
INFO - 2019-09-15 14:45:29 --> URI Class Initialized
INFO - 2019-09-15 14:45:29 --> Router Class Initialized
INFO - 2019-09-15 14:45:29 --> Output Class Initialized
INFO - 2019-09-15 14:45:29 --> Security Class Initialized
DEBUG - 2019-09-15 14:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:45:29 --> Input Class Initialized
INFO - 2019-09-15 14:45:29 --> Language Class Initialized
INFO - 2019-09-15 14:45:29 --> Loader Class Initialized
INFO - 2019-09-15 14:45:29 --> Helper loaded: url_helper
INFO - 2019-09-15 14:45:29 --> Helper loaded: html_helper
INFO - 2019-09-15 14:45:29 --> Helper loaded: form_helper
INFO - 2019-09-15 14:45:29 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:45:29 --> Helper loaded: date_helper
INFO - 2019-09-15 14:45:29 --> Form Validation Class Initialized
INFO - 2019-09-15 14:45:29 --> Email Class Initialized
DEBUG - 2019-09-15 14:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:45:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:45:29 --> Pagination Class Initialized
INFO - 2019-09-15 14:45:29 --> Database Driver Class Initialized
INFO - 2019-09-15 14:45:29 --> Database Driver Class Initialized
INFO - 2019-09-15 14:45:29 --> Controller Class Initialized
DEBUG - 2019-09-15 14:45:29 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:45:29 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:45:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:45:29 --> Final output sent to browser
DEBUG - 2019-09-15 14:45:29 --> Total execution time: 0.1616
INFO - 2019-09-15 14:47:26 --> Config Class Initialized
INFO - 2019-09-15 14:47:26 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:47:26 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:47:26 --> Utf8 Class Initialized
INFO - 2019-09-15 14:47:26 --> URI Class Initialized
INFO - 2019-09-15 14:47:26 --> Router Class Initialized
INFO - 2019-09-15 14:47:26 --> Output Class Initialized
INFO - 2019-09-15 14:47:26 --> Security Class Initialized
DEBUG - 2019-09-15 14:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:47:26 --> Input Class Initialized
INFO - 2019-09-15 14:47:26 --> Language Class Initialized
INFO - 2019-09-15 14:47:26 --> Loader Class Initialized
INFO - 2019-09-15 14:47:26 --> Helper loaded: url_helper
INFO - 2019-09-15 14:47:26 --> Helper loaded: html_helper
INFO - 2019-09-15 14:47:26 --> Helper loaded: form_helper
INFO - 2019-09-15 14:47:26 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:47:26 --> Helper loaded: date_helper
INFO - 2019-09-15 14:47:26 --> Form Validation Class Initialized
INFO - 2019-09-15 14:47:26 --> Email Class Initialized
DEBUG - 2019-09-15 14:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:47:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:47:26 --> Pagination Class Initialized
INFO - 2019-09-15 14:47:26 --> Database Driver Class Initialized
INFO - 2019-09-15 14:47:26 --> Database Driver Class Initialized
INFO - 2019-09-15 14:47:26 --> Controller Class Initialized
DEBUG - 2019-09-15 14:47:26 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:47:26 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:47:26 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-15 14:47:26 --> Severity: Warning --> Illegal string offset 'reservation_id' C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 75
ERROR - 2019-09-15 14:47:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.`00,"type":"reservationprice","price_room":30000`.`00,"price_extra":0`.`00,"pri' at line 1 - Invalid query: UPDATE `reservationpriceitems` SET `[{"reservation_id":"000000000001","price_rate":1,"folio_room":"BILL1","folio_extra":"BILL1","folio_other":"BILL1","weekday":15000`.`00,"weekend":15000`.`00,"holiday":15000`.`00,"type":"reservationprice","price_room":30000`.`00,"price_extra":0`.`00,"price_total":30000`.`00,"invoice":"none","comp_nights":0,"comp_visits":"no","auto_deposit":"no","block_pos":"no","deleted":"0","charge_from_date":"2019-08-28T00:00:00"},{"reservation_id":"000000000002","price_rate":4,"folio_room":"BILL1","folio_extra":"BILL1","folio_other":"BILL1","weekday":25000`.`00,"weekend":25000`.`00,"holiday":25000`.`00,"type":"reservationprice","price_room":75000`.`00,"price_extra":0`.`00,"price_total":75000`.`00,"invoice":"none","comp_nights":0,"comp_visits":"no","auto_deposit":"no","block_pos":"no","deleted":"0","charge_from_date":"0001-01-01T00:00:00"},{"reservation_id":"000000000004","price_rate":4,"folio_room":"BILL1","folio_extra":"BILL1","folio_other":"BILL1","weekday":25000`.`00,"weekend":25000`.`00,"holiday":25000`.`00,"type":"reservationprice","price_room":25000`.`00,"price_extra":0`.`00,"price_total":25000`.`00,"invoice":"none","comp_nights":0,"comp_visits":"no","auto_deposit":"no","block_pos":"no","deleted":"0","charge_from_date":"0001-01-01T00:00:00"},{"reservation_id":"000000000007","price_rate":4,"folio_room":"BILL1","folio_extra":"BILL1","folio_other":"BILL1","weekday":25000`.`00,"weekend":25000`.`00,"holiday":25000`.`00,"type":"reservationprice","price_room":25000`.`00,"price_extra":0`.`00,"price_total":25000`.`00,"invoice":"none","comp_nights":0,"comp_visits":"no","auto_deposit":"no","block_pos":"no","deleted":"0","charge_from_date":"0001-01-01T00:00:00"}]` = ''
WHERE `reservation_id` = '['
INFO - 2019-09-15 14:47:26 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-15 14:50:46 --> Config Class Initialized
INFO - 2019-09-15 14:50:46 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:50:46 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:50:46 --> Utf8 Class Initialized
INFO - 2019-09-15 14:50:46 --> URI Class Initialized
INFO - 2019-09-15 14:50:46 --> Router Class Initialized
INFO - 2019-09-15 14:50:46 --> Output Class Initialized
INFO - 2019-09-15 14:50:46 --> Security Class Initialized
DEBUG - 2019-09-15 14:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:50:46 --> Input Class Initialized
INFO - 2019-09-15 14:50:46 --> Language Class Initialized
INFO - 2019-09-15 14:50:46 --> Loader Class Initialized
INFO - 2019-09-15 14:50:46 --> Helper loaded: url_helper
INFO - 2019-09-15 14:50:46 --> Helper loaded: html_helper
INFO - 2019-09-15 14:50:46 --> Helper loaded: form_helper
INFO - 2019-09-15 14:50:46 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:50:46 --> Helper loaded: date_helper
INFO - 2019-09-15 14:50:46 --> Form Validation Class Initialized
INFO - 2019-09-15 14:50:46 --> Email Class Initialized
DEBUG - 2019-09-15 14:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:50:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:50:46 --> Pagination Class Initialized
INFO - 2019-09-15 14:50:46 --> Database Driver Class Initialized
INFO - 2019-09-15 14:50:46 --> Database Driver Class Initialized
INFO - 2019-09-15 14:50:46 --> Controller Class Initialized
DEBUG - 2019-09-15 14:50:46 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:50:46 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:50:46 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-15 14:50:46 --> Query error: Unknown column 'date_modified' in 'field list' - Invalid query: UPDATE `reservationpriceitems` SET `reservation_id` = '000000000001', `date_modified` = '2019-09-09', `description` = 'description', `plu_group` = '12', `plu` = '300', `price` = 10000, `debit` = 0, `credit` = 10000, `pak` = '', `account_number` = 13, `links` = '', `qty` = '', `signature_created` = 'maz', `reference` = '', `charge` = 'POS1', `audit` = '', `action` = '', `reason` = '', `terminal` = '001', `status` = 'active'
WHERE `reservation_id` = '000000000001'
INFO - 2019-09-15 14:50:46 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-15 14:51:49 --> Config Class Initialized
INFO - 2019-09-15 14:51:49 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:51:49 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:51:49 --> Utf8 Class Initialized
INFO - 2019-09-15 14:51:49 --> URI Class Initialized
INFO - 2019-09-15 14:51:49 --> Router Class Initialized
INFO - 2019-09-15 14:51:49 --> Output Class Initialized
INFO - 2019-09-15 14:51:49 --> Security Class Initialized
DEBUG - 2019-09-15 14:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:51:49 --> Input Class Initialized
INFO - 2019-09-15 14:51:49 --> Language Class Initialized
INFO - 2019-09-15 14:51:49 --> Loader Class Initialized
INFO - 2019-09-15 14:51:49 --> Helper loaded: url_helper
INFO - 2019-09-15 14:51:49 --> Helper loaded: html_helper
INFO - 2019-09-15 14:51:49 --> Helper loaded: form_helper
INFO - 2019-09-15 14:51:49 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:51:49 --> Helper loaded: date_helper
INFO - 2019-09-15 14:51:49 --> Form Validation Class Initialized
INFO - 2019-09-15 14:51:49 --> Email Class Initialized
DEBUG - 2019-09-15 14:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:51:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:51:49 --> Pagination Class Initialized
INFO - 2019-09-15 14:51:49 --> Database Driver Class Initialized
INFO - 2019-09-15 14:51:49 --> Database Driver Class Initialized
INFO - 2019-09-15 14:51:49 --> Controller Class Initialized
DEBUG - 2019-09-15 14:51:49 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:51:49 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:51:49 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-15 14:51:49 --> Query error: Unknown column 'description' in 'field list' - Invalid query: UPDATE `reservationpriceitems` SET `reservation_id` = '000000000001', `description` = 'description', `plu_group` = '12', `plu` = '300', `price` = 10000, `debit` = 0, `credit` = 10000, `pak` = '', `account_number` = 13, `links` = '', `qty` = '', `signature_created` = 'maz', `reference` = '', `charge` = 'POS1', `audit` = '', `action` = '', `reason` = '', `terminal` = '001', `status` = 'active'
WHERE `reservation_id` = '000000000001'
INFO - 2019-09-15 14:51:49 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-15 14:54:19 --> Config Class Initialized
INFO - 2019-09-15 14:54:19 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:54:19 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:54:19 --> Utf8 Class Initialized
INFO - 2019-09-15 14:54:19 --> URI Class Initialized
INFO - 2019-09-15 14:54:19 --> Router Class Initialized
INFO - 2019-09-15 14:54:19 --> Output Class Initialized
INFO - 2019-09-15 14:54:19 --> Security Class Initialized
DEBUG - 2019-09-15 14:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:54:19 --> Input Class Initialized
INFO - 2019-09-15 14:54:19 --> Language Class Initialized
INFO - 2019-09-15 14:54:19 --> Loader Class Initialized
INFO - 2019-09-15 14:54:19 --> Helper loaded: url_helper
INFO - 2019-09-15 14:54:19 --> Helper loaded: html_helper
INFO - 2019-09-15 14:54:19 --> Helper loaded: form_helper
INFO - 2019-09-15 14:54:19 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:54:19 --> Helper loaded: date_helper
INFO - 2019-09-15 14:54:19 --> Form Validation Class Initialized
INFO - 2019-09-15 14:54:19 --> Email Class Initialized
DEBUG - 2019-09-15 14:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:54:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:54:19 --> Pagination Class Initialized
INFO - 2019-09-15 14:54:19 --> Database Driver Class Initialized
INFO - 2019-09-15 14:54:19 --> Database Driver Class Initialized
INFO - 2019-09-15 14:54:19 --> Controller Class Initialized
DEBUG - 2019-09-15 14:54:19 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:54:19 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:54:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:54:19 --> Final output sent to browser
DEBUG - 2019-09-15 14:54:19 --> Total execution time: 0.1475
INFO - 2019-09-15 14:54:19 --> Config Class Initialized
INFO - 2019-09-15 14:54:19 --> Hooks Class Initialized
DEBUG - 2019-09-15 14:54:19 --> UTF-8 Support Enabled
INFO - 2019-09-15 14:54:19 --> Utf8 Class Initialized
INFO - 2019-09-15 14:54:19 --> URI Class Initialized
INFO - 2019-09-15 14:54:19 --> Router Class Initialized
INFO - 2019-09-15 14:54:19 --> Output Class Initialized
INFO - 2019-09-15 14:54:19 --> Security Class Initialized
DEBUG - 2019-09-15 14:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 14:54:19 --> Input Class Initialized
INFO - 2019-09-15 14:54:19 --> Language Class Initialized
INFO - 2019-09-15 14:54:19 --> Loader Class Initialized
INFO - 2019-09-15 14:54:19 --> Helper loaded: url_helper
INFO - 2019-09-15 14:54:19 --> Helper loaded: html_helper
INFO - 2019-09-15 14:54:19 --> Helper loaded: form_helper
INFO - 2019-09-15 14:54:19 --> Helper loaded: cookie_helper
INFO - 2019-09-15 14:54:19 --> Helper loaded: date_helper
INFO - 2019-09-15 14:54:19 --> Form Validation Class Initialized
INFO - 2019-09-15 14:54:19 --> Email Class Initialized
DEBUG - 2019-09-15 14:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 14:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 14:54:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 14:54:19 --> Pagination Class Initialized
INFO - 2019-09-15 14:54:19 --> Database Driver Class Initialized
INFO - 2019-09-15 14:54:19 --> Database Driver Class Initialized
INFO - 2019-09-15 14:54:19 --> Controller Class Initialized
DEBUG - 2019-09-15 14:54:19 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 14:54:19 --> Helper loaded: inflector_helper
INFO - 2019-09-15 14:54:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 14:54:19 --> Final output sent to browser
DEBUG - 2019-09-15 14:54:19 --> Total execution time: 0.3696
INFO - 2019-09-15 15:03:32 --> Config Class Initialized
INFO - 2019-09-15 15:03:32 --> Hooks Class Initialized
DEBUG - 2019-09-15 15:03:32 --> UTF-8 Support Enabled
INFO - 2019-09-15 15:03:32 --> Utf8 Class Initialized
INFO - 2019-09-15 15:03:32 --> URI Class Initialized
INFO - 2019-09-15 15:03:32 --> Router Class Initialized
INFO - 2019-09-15 15:03:32 --> Output Class Initialized
INFO - 2019-09-15 15:03:32 --> Security Class Initialized
DEBUG - 2019-09-15 15:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 15:03:32 --> Input Class Initialized
INFO - 2019-09-15 15:03:32 --> Language Class Initialized
INFO - 2019-09-15 15:03:32 --> Loader Class Initialized
INFO - 2019-09-15 15:03:32 --> Helper loaded: url_helper
INFO - 2019-09-15 15:03:32 --> Helper loaded: html_helper
INFO - 2019-09-15 15:03:32 --> Helper loaded: form_helper
INFO - 2019-09-15 15:03:32 --> Helper loaded: cookie_helper
INFO - 2019-09-15 15:03:32 --> Helper loaded: date_helper
INFO - 2019-09-15 15:03:32 --> Form Validation Class Initialized
INFO - 2019-09-15 15:03:32 --> Email Class Initialized
DEBUG - 2019-09-15 15:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 15:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 15:03:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 15:03:32 --> Pagination Class Initialized
INFO - 2019-09-15 15:03:32 --> Database Driver Class Initialized
INFO - 2019-09-15 15:03:32 --> Database Driver Class Initialized
INFO - 2019-09-15 15:03:32 --> Controller Class Initialized
DEBUG - 2019-09-15 15:03:32 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 15:03:32 --> Helper loaded: inflector_helper
INFO - 2019-09-15 15:03:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 15:03:32 --> Final output sent to browser
DEBUG - 2019-09-15 15:03:32 --> Total execution time: 0.2167
INFO - 2019-09-15 15:05:47 --> Config Class Initialized
INFO - 2019-09-15 15:05:47 --> Hooks Class Initialized
DEBUG - 2019-09-15 15:05:47 --> UTF-8 Support Enabled
INFO - 2019-09-15 15:05:47 --> Utf8 Class Initialized
INFO - 2019-09-15 15:05:47 --> URI Class Initialized
INFO - 2019-09-15 15:05:47 --> Router Class Initialized
INFO - 2019-09-15 15:05:47 --> Output Class Initialized
INFO - 2019-09-15 15:05:47 --> Security Class Initialized
DEBUG - 2019-09-15 15:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 15:05:47 --> Input Class Initialized
INFO - 2019-09-15 15:05:47 --> Language Class Initialized
INFO - 2019-09-15 15:05:47 --> Loader Class Initialized
INFO - 2019-09-15 15:05:47 --> Helper loaded: url_helper
INFO - 2019-09-15 15:05:47 --> Helper loaded: html_helper
INFO - 2019-09-15 15:05:47 --> Helper loaded: form_helper
INFO - 2019-09-15 15:05:47 --> Helper loaded: cookie_helper
INFO - 2019-09-15 15:05:47 --> Helper loaded: date_helper
INFO - 2019-09-15 15:05:47 --> Form Validation Class Initialized
INFO - 2019-09-15 15:05:47 --> Email Class Initialized
DEBUG - 2019-09-15 15:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 15:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 15:05:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 15:05:47 --> Pagination Class Initialized
INFO - 2019-09-15 15:05:48 --> Database Driver Class Initialized
INFO - 2019-09-15 15:05:48 --> Database Driver Class Initialized
INFO - 2019-09-15 15:05:48 --> Controller Class Initialized
DEBUG - 2019-09-15 15:05:48 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 15:05:48 --> Helper loaded: inflector_helper
INFO - 2019-09-15 15:05:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 15:05:48 --> Final output sent to browser
DEBUG - 2019-09-15 15:05:48 --> Total execution time: 0.1772
INFO - 2019-09-15 15:05:48 --> Config Class Initialized
INFO - 2019-09-15 15:05:48 --> Hooks Class Initialized
DEBUG - 2019-09-15 15:05:48 --> UTF-8 Support Enabled
INFO - 2019-09-15 15:05:48 --> Utf8 Class Initialized
INFO - 2019-09-15 15:05:48 --> URI Class Initialized
INFO - 2019-09-15 15:05:48 --> Router Class Initialized
INFO - 2019-09-15 15:05:48 --> Output Class Initialized
INFO - 2019-09-15 15:05:48 --> Security Class Initialized
DEBUG - 2019-09-15 15:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 15:05:48 --> Input Class Initialized
INFO - 2019-09-15 15:05:48 --> Language Class Initialized
INFO - 2019-09-15 15:05:48 --> Loader Class Initialized
INFO - 2019-09-15 15:05:48 --> Helper loaded: url_helper
INFO - 2019-09-15 15:05:48 --> Helper loaded: html_helper
INFO - 2019-09-15 15:05:48 --> Helper loaded: form_helper
INFO - 2019-09-15 15:05:48 --> Helper loaded: cookie_helper
INFO - 2019-09-15 15:05:48 --> Helper loaded: date_helper
INFO - 2019-09-15 15:05:48 --> Form Validation Class Initialized
INFO - 2019-09-15 15:05:48 --> Email Class Initialized
DEBUG - 2019-09-15 15:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 15:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 15:05:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 15:05:48 --> Pagination Class Initialized
INFO - 2019-09-15 15:05:48 --> Database Driver Class Initialized
INFO - 2019-09-15 15:05:48 --> Database Driver Class Initialized
INFO - 2019-09-15 15:05:48 --> Controller Class Initialized
DEBUG - 2019-09-15 15:05:48 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 15:05:48 --> Helper loaded: inflector_helper
INFO - 2019-09-15 15:05:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 15:05:48 --> Final output sent to browser
DEBUG - 2019-09-15 15:05:48 --> Total execution time: 0.1957
INFO - 2019-09-15 15:05:48 --> Config Class Initialized
INFO - 2019-09-15 15:05:48 --> Hooks Class Initialized
DEBUG - 2019-09-15 15:05:48 --> UTF-8 Support Enabled
INFO - 2019-09-15 15:05:48 --> Utf8 Class Initialized
INFO - 2019-09-15 15:05:48 --> URI Class Initialized
INFO - 2019-09-15 15:05:48 --> Router Class Initialized
INFO - 2019-09-15 15:05:48 --> Output Class Initialized
INFO - 2019-09-15 15:05:48 --> Security Class Initialized
DEBUG - 2019-09-15 15:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 15:05:48 --> Input Class Initialized
INFO - 2019-09-15 15:05:48 --> Language Class Initialized
INFO - 2019-09-15 15:05:48 --> Loader Class Initialized
INFO - 2019-09-15 15:05:48 --> Helper loaded: url_helper
INFO - 2019-09-15 15:05:48 --> Helper loaded: html_helper
INFO - 2019-09-15 15:05:48 --> Helper loaded: form_helper
INFO - 2019-09-15 15:05:48 --> Helper loaded: cookie_helper
INFO - 2019-09-15 15:05:48 --> Helper loaded: date_helper
INFO - 2019-09-15 15:05:48 --> Form Validation Class Initialized
INFO - 2019-09-15 15:05:48 --> Email Class Initialized
DEBUG - 2019-09-15 15:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 15:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 15:05:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 15:05:48 --> Pagination Class Initialized
INFO - 2019-09-15 15:05:48 --> Database Driver Class Initialized
INFO - 2019-09-15 15:05:48 --> Database Driver Class Initialized
INFO - 2019-09-15 15:05:48 --> Controller Class Initialized
DEBUG - 2019-09-15 15:05:48 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 15:05:48 --> Helper loaded: inflector_helper
INFO - 2019-09-15 15:05:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 15:05:48 --> Final output sent to browser
DEBUG - 2019-09-15 15:05:48 --> Total execution time: 0.2546
INFO - 2019-09-15 16:51:37 --> Config Class Initialized
INFO - 2019-09-15 16:51:37 --> Hooks Class Initialized
DEBUG - 2019-09-15 16:51:37 --> UTF-8 Support Enabled
INFO - 2019-09-15 16:51:37 --> Utf8 Class Initialized
INFO - 2019-09-15 16:51:37 --> URI Class Initialized
INFO - 2019-09-15 16:51:37 --> Router Class Initialized
INFO - 2019-09-15 16:51:37 --> Output Class Initialized
INFO - 2019-09-15 16:51:37 --> Security Class Initialized
DEBUG - 2019-09-15 16:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 16:51:37 --> Input Class Initialized
INFO - 2019-09-15 16:51:37 --> Language Class Initialized
INFO - 2019-09-15 16:51:37 --> Loader Class Initialized
INFO - 2019-09-15 16:51:37 --> Helper loaded: url_helper
INFO - 2019-09-15 16:51:37 --> Helper loaded: html_helper
INFO - 2019-09-15 16:51:37 --> Helper loaded: form_helper
INFO - 2019-09-15 16:51:37 --> Helper loaded: cookie_helper
INFO - 2019-09-15 16:51:37 --> Helper loaded: date_helper
INFO - 2019-09-15 16:51:37 --> Form Validation Class Initialized
INFO - 2019-09-15 16:51:37 --> Email Class Initialized
DEBUG - 2019-09-15 16:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 16:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 16:51:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 16:51:37 --> Pagination Class Initialized
INFO - 2019-09-15 16:51:37 --> Database Driver Class Initialized
INFO - 2019-09-15 16:51:37 --> Database Driver Class Initialized
INFO - 2019-09-15 16:51:37 --> Controller Class Initialized
DEBUG - 2019-09-15 16:51:37 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 16:51:37 --> Helper loaded: inflector_helper
INFO - 2019-09-15 16:51:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 16:51:37 --> Final output sent to browser
DEBUG - 2019-09-15 16:51:37 --> Total execution time: 0.1216
INFO - 2019-09-15 16:51:37 --> Config Class Initialized
INFO - 2019-09-15 16:51:37 --> Hooks Class Initialized
DEBUG - 2019-09-15 16:51:37 --> UTF-8 Support Enabled
INFO - 2019-09-15 16:51:37 --> Utf8 Class Initialized
INFO - 2019-09-15 16:51:37 --> URI Class Initialized
INFO - 2019-09-15 16:51:37 --> Router Class Initialized
INFO - 2019-09-15 16:51:37 --> Output Class Initialized
INFO - 2019-09-15 16:51:37 --> Security Class Initialized
DEBUG - 2019-09-15 16:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 16:51:37 --> Input Class Initialized
INFO - 2019-09-15 16:51:37 --> Language Class Initialized
INFO - 2019-09-15 16:51:37 --> Loader Class Initialized
INFO - 2019-09-15 16:51:37 --> Helper loaded: url_helper
INFO - 2019-09-15 16:51:37 --> Helper loaded: html_helper
INFO - 2019-09-15 16:51:37 --> Helper loaded: form_helper
INFO - 2019-09-15 16:51:37 --> Helper loaded: cookie_helper
INFO - 2019-09-15 16:51:37 --> Helper loaded: date_helper
INFO - 2019-09-15 16:51:37 --> Form Validation Class Initialized
INFO - 2019-09-15 16:51:37 --> Email Class Initialized
DEBUG - 2019-09-15 16:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 16:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 16:51:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 16:51:37 --> Pagination Class Initialized
INFO - 2019-09-15 16:51:37 --> Database Driver Class Initialized
INFO - 2019-09-15 16:51:37 --> Database Driver Class Initialized
INFO - 2019-09-15 16:51:37 --> Controller Class Initialized
DEBUG - 2019-09-15 16:51:37 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 16:51:37 --> Helper loaded: inflector_helper
INFO - 2019-09-15 16:51:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 16:51:37 --> Final output sent to browser
DEBUG - 2019-09-15 16:51:37 --> Total execution time: 0.0697
INFO - 2019-09-15 16:51:37 --> Config Class Initialized
INFO - 2019-09-15 16:51:37 --> Hooks Class Initialized
DEBUG - 2019-09-15 16:51:37 --> UTF-8 Support Enabled
INFO - 2019-09-15 16:51:37 --> Utf8 Class Initialized
INFO - 2019-09-15 16:51:37 --> URI Class Initialized
INFO - 2019-09-15 16:51:37 --> Router Class Initialized
INFO - 2019-09-15 16:51:37 --> Output Class Initialized
INFO - 2019-09-15 16:51:37 --> Security Class Initialized
DEBUG - 2019-09-15 16:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 16:51:37 --> Input Class Initialized
INFO - 2019-09-15 16:51:37 --> Language Class Initialized
INFO - 2019-09-15 16:51:37 --> Loader Class Initialized
INFO - 2019-09-15 16:51:37 --> Helper loaded: url_helper
INFO - 2019-09-15 16:51:37 --> Helper loaded: html_helper
INFO - 2019-09-15 16:51:37 --> Helper loaded: form_helper
INFO - 2019-09-15 16:51:37 --> Helper loaded: cookie_helper
INFO - 2019-09-15 16:51:37 --> Helper loaded: date_helper
INFO - 2019-09-15 16:51:37 --> Form Validation Class Initialized
INFO - 2019-09-15 16:51:37 --> Email Class Initialized
DEBUG - 2019-09-15 16:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 16:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 16:51:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 16:51:37 --> Pagination Class Initialized
INFO - 2019-09-15 16:51:37 --> Database Driver Class Initialized
INFO - 2019-09-15 16:51:37 --> Database Driver Class Initialized
INFO - 2019-09-15 16:51:37 --> Controller Class Initialized
DEBUG - 2019-09-15 16:51:37 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 16:51:37 --> Helper loaded: inflector_helper
INFO - 2019-09-15 16:51:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 16:51:37 --> Final output sent to browser
DEBUG - 2019-09-15 16:51:37 --> Total execution time: 0.0674
INFO - 2019-09-15 16:51:37 --> Config Class Initialized
INFO - 2019-09-15 16:51:37 --> Hooks Class Initialized
DEBUG - 2019-09-15 16:51:37 --> UTF-8 Support Enabled
INFO - 2019-09-15 16:51:37 --> Utf8 Class Initialized
INFO - 2019-09-15 16:51:37 --> URI Class Initialized
INFO - 2019-09-15 16:51:37 --> Router Class Initialized
INFO - 2019-09-15 16:51:37 --> Output Class Initialized
INFO - 2019-09-15 16:51:37 --> Security Class Initialized
DEBUG - 2019-09-15 16:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 16:51:37 --> Input Class Initialized
INFO - 2019-09-15 16:51:37 --> Language Class Initialized
INFO - 2019-09-15 16:51:37 --> Loader Class Initialized
INFO - 2019-09-15 16:51:37 --> Helper loaded: url_helper
INFO - 2019-09-15 16:51:37 --> Helper loaded: html_helper
INFO - 2019-09-15 16:51:37 --> Helper loaded: form_helper
INFO - 2019-09-15 16:51:37 --> Helper loaded: cookie_helper
INFO - 2019-09-15 16:51:37 --> Helper loaded: date_helper
INFO - 2019-09-15 16:51:37 --> Form Validation Class Initialized
INFO - 2019-09-15 16:51:37 --> Email Class Initialized
DEBUG - 2019-09-15 16:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 16:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 16:51:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 16:51:37 --> Pagination Class Initialized
INFO - 2019-09-15 16:51:37 --> Database Driver Class Initialized
INFO - 2019-09-15 16:51:37 --> Database Driver Class Initialized
INFO - 2019-09-15 16:51:37 --> Controller Class Initialized
DEBUG - 2019-09-15 16:51:37 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 16:51:37 --> Helper loaded: inflector_helper
INFO - 2019-09-15 16:51:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 16:51:37 --> Final output sent to browser
DEBUG - 2019-09-15 16:51:37 --> Total execution time: 0.4044
INFO - 2019-09-15 16:57:02 --> Config Class Initialized
INFO - 2019-09-15 16:57:02 --> Hooks Class Initialized
DEBUG - 2019-09-15 16:57:02 --> UTF-8 Support Enabled
INFO - 2019-09-15 16:57:02 --> Utf8 Class Initialized
INFO - 2019-09-15 16:57:02 --> URI Class Initialized
INFO - 2019-09-15 16:57:02 --> Router Class Initialized
INFO - 2019-09-15 16:57:02 --> Output Class Initialized
INFO - 2019-09-15 16:57:02 --> Security Class Initialized
DEBUG - 2019-09-15 16:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 16:57:02 --> Input Class Initialized
INFO - 2019-09-15 16:57:02 --> Language Class Initialized
INFO - 2019-09-15 16:57:02 --> Loader Class Initialized
INFO - 2019-09-15 16:57:02 --> Helper loaded: url_helper
INFO - 2019-09-15 16:57:02 --> Helper loaded: html_helper
INFO - 2019-09-15 16:57:02 --> Helper loaded: form_helper
INFO - 2019-09-15 16:57:02 --> Helper loaded: cookie_helper
INFO - 2019-09-15 16:57:02 --> Helper loaded: date_helper
INFO - 2019-09-15 16:57:02 --> Form Validation Class Initialized
INFO - 2019-09-15 16:57:02 --> Email Class Initialized
DEBUG - 2019-09-15 16:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 16:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 16:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 16:57:02 --> Pagination Class Initialized
INFO - 2019-09-15 16:57:02 --> Database Driver Class Initialized
INFO - 2019-09-15 16:57:02 --> Database Driver Class Initialized
INFO - 2019-09-15 16:57:02 --> Controller Class Initialized
DEBUG - 2019-09-15 16:57:02 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 16:57:02 --> Helper loaded: inflector_helper
INFO - 2019-09-15 16:57:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 16:57:02 --> Final output sent to browser
DEBUG - 2019-09-15 16:57:02 --> Total execution time: 0.0588
INFO - 2019-09-15 16:57:02 --> Config Class Initialized
INFO - 2019-09-15 16:57:02 --> Hooks Class Initialized
DEBUG - 2019-09-15 16:57:02 --> UTF-8 Support Enabled
INFO - 2019-09-15 16:57:02 --> Utf8 Class Initialized
INFO - 2019-09-15 16:57:02 --> URI Class Initialized
INFO - 2019-09-15 16:57:02 --> Router Class Initialized
INFO - 2019-09-15 16:57:02 --> Output Class Initialized
INFO - 2019-09-15 16:57:02 --> Security Class Initialized
DEBUG - 2019-09-15 16:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 16:57:02 --> Input Class Initialized
INFO - 2019-09-15 16:57:02 --> Language Class Initialized
INFO - 2019-09-15 16:57:02 --> Loader Class Initialized
INFO - 2019-09-15 16:57:02 --> Helper loaded: url_helper
INFO - 2019-09-15 16:57:02 --> Helper loaded: html_helper
INFO - 2019-09-15 16:57:02 --> Helper loaded: form_helper
INFO - 2019-09-15 16:57:02 --> Helper loaded: cookie_helper
INFO - 2019-09-15 16:57:02 --> Helper loaded: date_helper
INFO - 2019-09-15 16:57:02 --> Form Validation Class Initialized
INFO - 2019-09-15 16:57:02 --> Email Class Initialized
DEBUG - 2019-09-15 16:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 16:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 16:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 16:57:02 --> Pagination Class Initialized
INFO - 2019-09-15 16:57:02 --> Database Driver Class Initialized
INFO - 2019-09-15 16:57:02 --> Database Driver Class Initialized
INFO - 2019-09-15 16:57:02 --> Controller Class Initialized
DEBUG - 2019-09-15 16:57:02 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 16:57:02 --> Helper loaded: inflector_helper
INFO - 2019-09-15 16:57:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 16:57:02 --> Final output sent to browser
DEBUG - 2019-09-15 16:57:02 --> Total execution time: 0.0659
INFO - 2019-09-15 16:57:02 --> Config Class Initialized
INFO - 2019-09-15 16:57:02 --> Hooks Class Initialized
DEBUG - 2019-09-15 16:57:02 --> UTF-8 Support Enabled
INFO - 2019-09-15 16:57:02 --> Utf8 Class Initialized
INFO - 2019-09-15 16:57:02 --> URI Class Initialized
INFO - 2019-09-15 16:57:02 --> Router Class Initialized
INFO - 2019-09-15 16:57:02 --> Output Class Initialized
INFO - 2019-09-15 16:57:02 --> Security Class Initialized
DEBUG - 2019-09-15 16:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 16:57:02 --> Input Class Initialized
INFO - 2019-09-15 16:57:02 --> Language Class Initialized
INFO - 2019-09-15 16:57:02 --> Loader Class Initialized
INFO - 2019-09-15 16:57:02 --> Helper loaded: url_helper
INFO - 2019-09-15 16:57:02 --> Helper loaded: html_helper
INFO - 2019-09-15 16:57:02 --> Helper loaded: form_helper
INFO - 2019-09-15 16:57:02 --> Helper loaded: cookie_helper
INFO - 2019-09-15 16:57:02 --> Helper loaded: date_helper
INFO - 2019-09-15 16:57:02 --> Form Validation Class Initialized
INFO - 2019-09-15 16:57:02 --> Email Class Initialized
DEBUG - 2019-09-15 16:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 16:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 16:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 16:57:02 --> Pagination Class Initialized
INFO - 2019-09-15 16:57:02 --> Database Driver Class Initialized
INFO - 2019-09-15 16:57:02 --> Database Driver Class Initialized
INFO - 2019-09-15 16:57:02 --> Controller Class Initialized
DEBUG - 2019-09-15 16:57:02 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 16:57:02 --> Helper loaded: inflector_helper
INFO - 2019-09-15 16:57:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 16:57:02 --> Final output sent to browser
DEBUG - 2019-09-15 16:57:02 --> Total execution time: 0.0619
INFO - 2019-09-15 16:57:02 --> Config Class Initialized
INFO - 2019-09-15 16:57:02 --> Hooks Class Initialized
DEBUG - 2019-09-15 16:57:02 --> UTF-8 Support Enabled
INFO - 2019-09-15 16:57:02 --> Utf8 Class Initialized
INFO - 2019-09-15 16:57:02 --> URI Class Initialized
INFO - 2019-09-15 16:57:02 --> Router Class Initialized
INFO - 2019-09-15 16:57:02 --> Output Class Initialized
INFO - 2019-09-15 16:57:02 --> Security Class Initialized
DEBUG - 2019-09-15 16:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 16:57:02 --> Input Class Initialized
INFO - 2019-09-15 16:57:02 --> Language Class Initialized
INFO - 2019-09-15 16:57:02 --> Loader Class Initialized
INFO - 2019-09-15 16:57:02 --> Helper loaded: url_helper
INFO - 2019-09-15 16:57:02 --> Helper loaded: html_helper
INFO - 2019-09-15 16:57:02 --> Helper loaded: form_helper
INFO - 2019-09-15 16:57:02 --> Helper loaded: cookie_helper
INFO - 2019-09-15 16:57:02 --> Helper loaded: date_helper
INFO - 2019-09-15 16:57:02 --> Form Validation Class Initialized
INFO - 2019-09-15 16:57:02 --> Email Class Initialized
DEBUG - 2019-09-15 16:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 16:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 16:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 16:57:02 --> Pagination Class Initialized
INFO - 2019-09-15 16:57:02 --> Database Driver Class Initialized
INFO - 2019-09-15 16:57:02 --> Database Driver Class Initialized
INFO - 2019-09-15 16:57:02 --> Controller Class Initialized
DEBUG - 2019-09-15 16:57:02 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 16:57:02 --> Helper loaded: inflector_helper
INFO - 2019-09-15 16:57:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 16:57:03 --> Final output sent to browser
DEBUG - 2019-09-15 16:57:03 --> Total execution time: 0.7636
INFO - 2019-09-15 16:59:01 --> Config Class Initialized
INFO - 2019-09-15 16:59:01 --> Hooks Class Initialized
DEBUG - 2019-09-15 16:59:01 --> UTF-8 Support Enabled
INFO - 2019-09-15 16:59:01 --> Utf8 Class Initialized
INFO - 2019-09-15 16:59:01 --> URI Class Initialized
INFO - 2019-09-15 16:59:01 --> Router Class Initialized
INFO - 2019-09-15 16:59:01 --> Output Class Initialized
INFO - 2019-09-15 16:59:01 --> Security Class Initialized
DEBUG - 2019-09-15 16:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 16:59:01 --> Input Class Initialized
INFO - 2019-09-15 16:59:01 --> Language Class Initialized
INFO - 2019-09-15 16:59:01 --> Loader Class Initialized
INFO - 2019-09-15 16:59:01 --> Helper loaded: url_helper
INFO - 2019-09-15 16:59:01 --> Helper loaded: html_helper
INFO - 2019-09-15 16:59:01 --> Helper loaded: form_helper
INFO - 2019-09-15 16:59:01 --> Helper loaded: cookie_helper
INFO - 2019-09-15 16:59:01 --> Helper loaded: date_helper
INFO - 2019-09-15 16:59:01 --> Form Validation Class Initialized
INFO - 2019-09-15 16:59:01 --> Email Class Initialized
DEBUG - 2019-09-15 16:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 16:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 16:59:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 16:59:01 --> Pagination Class Initialized
INFO - 2019-09-15 16:59:01 --> Database Driver Class Initialized
INFO - 2019-09-15 16:59:01 --> Database Driver Class Initialized
INFO - 2019-09-15 16:59:01 --> Controller Class Initialized
DEBUG - 2019-09-15 16:59:01 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 16:59:01 --> Helper loaded: inflector_helper
INFO - 2019-09-15 16:59:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 16:59:01 --> Final output sent to browser
DEBUG - 2019-09-15 16:59:01 --> Total execution time: 0.0623
INFO - 2019-09-15 16:59:01 --> Config Class Initialized
INFO - 2019-09-15 16:59:01 --> Hooks Class Initialized
DEBUG - 2019-09-15 16:59:01 --> UTF-8 Support Enabled
INFO - 2019-09-15 16:59:01 --> Utf8 Class Initialized
INFO - 2019-09-15 16:59:01 --> URI Class Initialized
INFO - 2019-09-15 16:59:01 --> Router Class Initialized
INFO - 2019-09-15 16:59:01 --> Output Class Initialized
INFO - 2019-09-15 16:59:01 --> Security Class Initialized
DEBUG - 2019-09-15 16:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 16:59:01 --> Input Class Initialized
INFO - 2019-09-15 16:59:01 --> Language Class Initialized
INFO - 2019-09-15 16:59:01 --> Loader Class Initialized
INFO - 2019-09-15 16:59:01 --> Helper loaded: url_helper
INFO - 2019-09-15 16:59:01 --> Helper loaded: html_helper
INFO - 2019-09-15 16:59:01 --> Helper loaded: form_helper
INFO - 2019-09-15 16:59:01 --> Helper loaded: cookie_helper
INFO - 2019-09-15 16:59:01 --> Helper loaded: date_helper
INFO - 2019-09-15 16:59:01 --> Form Validation Class Initialized
INFO - 2019-09-15 16:59:01 --> Email Class Initialized
DEBUG - 2019-09-15 16:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 16:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 16:59:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 16:59:01 --> Pagination Class Initialized
INFO - 2019-09-15 16:59:01 --> Database Driver Class Initialized
INFO - 2019-09-15 16:59:01 --> Database Driver Class Initialized
INFO - 2019-09-15 16:59:01 --> Controller Class Initialized
DEBUG - 2019-09-15 16:59:01 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 16:59:01 --> Helper loaded: inflector_helper
INFO - 2019-09-15 16:59:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 16:59:01 --> Final output sent to browser
DEBUG - 2019-09-15 16:59:01 --> Total execution time: 0.0604
INFO - 2019-09-15 16:59:01 --> Config Class Initialized
INFO - 2019-09-15 16:59:01 --> Hooks Class Initialized
DEBUG - 2019-09-15 16:59:01 --> UTF-8 Support Enabled
INFO - 2019-09-15 16:59:01 --> Utf8 Class Initialized
INFO - 2019-09-15 16:59:01 --> URI Class Initialized
INFO - 2019-09-15 16:59:01 --> Router Class Initialized
INFO - 2019-09-15 16:59:01 --> Output Class Initialized
INFO - 2019-09-15 16:59:01 --> Security Class Initialized
DEBUG - 2019-09-15 16:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 16:59:01 --> Input Class Initialized
INFO - 2019-09-15 16:59:01 --> Language Class Initialized
INFO - 2019-09-15 16:59:01 --> Loader Class Initialized
INFO - 2019-09-15 16:59:01 --> Helper loaded: url_helper
INFO - 2019-09-15 16:59:01 --> Helper loaded: html_helper
INFO - 2019-09-15 16:59:01 --> Helper loaded: form_helper
INFO - 2019-09-15 16:59:01 --> Helper loaded: cookie_helper
INFO - 2019-09-15 16:59:01 --> Helper loaded: date_helper
INFO - 2019-09-15 16:59:01 --> Form Validation Class Initialized
INFO - 2019-09-15 16:59:01 --> Email Class Initialized
DEBUG - 2019-09-15 16:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 16:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 16:59:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 16:59:01 --> Pagination Class Initialized
INFO - 2019-09-15 16:59:01 --> Database Driver Class Initialized
INFO - 2019-09-15 16:59:01 --> Database Driver Class Initialized
INFO - 2019-09-15 16:59:01 --> Controller Class Initialized
DEBUG - 2019-09-15 16:59:01 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 16:59:01 --> Helper loaded: inflector_helper
INFO - 2019-09-15 16:59:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 16:59:01 --> Final output sent to browser
DEBUG - 2019-09-15 16:59:01 --> Total execution time: 0.0677
INFO - 2019-09-15 16:59:01 --> Config Class Initialized
INFO - 2019-09-15 16:59:01 --> Hooks Class Initialized
DEBUG - 2019-09-15 16:59:01 --> UTF-8 Support Enabled
INFO - 2019-09-15 16:59:01 --> Utf8 Class Initialized
INFO - 2019-09-15 16:59:01 --> URI Class Initialized
INFO - 2019-09-15 16:59:01 --> Router Class Initialized
INFO - 2019-09-15 16:59:01 --> Output Class Initialized
INFO - 2019-09-15 16:59:01 --> Security Class Initialized
DEBUG - 2019-09-15 16:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 16:59:01 --> Input Class Initialized
INFO - 2019-09-15 16:59:01 --> Language Class Initialized
INFO - 2019-09-15 16:59:01 --> Loader Class Initialized
INFO - 2019-09-15 16:59:01 --> Helper loaded: url_helper
INFO - 2019-09-15 16:59:01 --> Helper loaded: html_helper
INFO - 2019-09-15 16:59:01 --> Helper loaded: form_helper
INFO - 2019-09-15 16:59:01 --> Helper loaded: cookie_helper
INFO - 2019-09-15 16:59:01 --> Helper loaded: date_helper
INFO - 2019-09-15 16:59:01 --> Form Validation Class Initialized
INFO - 2019-09-15 16:59:01 --> Email Class Initialized
DEBUG - 2019-09-15 16:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 16:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 16:59:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 16:59:01 --> Pagination Class Initialized
INFO - 2019-09-15 16:59:01 --> Database Driver Class Initialized
INFO - 2019-09-15 16:59:01 --> Database Driver Class Initialized
INFO - 2019-09-15 16:59:01 --> Controller Class Initialized
DEBUG - 2019-09-15 16:59:01 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 16:59:01 --> Helper loaded: inflector_helper
INFO - 2019-09-15 16:59:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 16:59:02 --> Final output sent to browser
DEBUG - 2019-09-15 16:59:02 --> Total execution time: 0.4211
INFO - 2019-09-15 17:00:46 --> Config Class Initialized
INFO - 2019-09-15 17:00:46 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:00:46 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:00:46 --> Utf8 Class Initialized
INFO - 2019-09-15 17:00:46 --> URI Class Initialized
INFO - 2019-09-15 17:00:46 --> Router Class Initialized
INFO - 2019-09-15 17:00:46 --> Output Class Initialized
INFO - 2019-09-15 17:00:46 --> Security Class Initialized
DEBUG - 2019-09-15 17:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:00:46 --> Input Class Initialized
INFO - 2019-09-15 17:00:46 --> Language Class Initialized
INFO - 2019-09-15 17:00:46 --> Loader Class Initialized
INFO - 2019-09-15 17:00:46 --> Helper loaded: url_helper
INFO - 2019-09-15 17:00:46 --> Helper loaded: html_helper
INFO - 2019-09-15 17:00:46 --> Helper loaded: form_helper
INFO - 2019-09-15 17:00:46 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:00:46 --> Helper loaded: date_helper
INFO - 2019-09-15 17:00:46 --> Form Validation Class Initialized
INFO - 2019-09-15 17:00:46 --> Email Class Initialized
DEBUG - 2019-09-15 17:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:00:46 --> Pagination Class Initialized
INFO - 2019-09-15 17:00:46 --> Database Driver Class Initialized
INFO - 2019-09-15 17:00:46 --> Database Driver Class Initialized
INFO - 2019-09-15 17:00:46 --> Controller Class Initialized
DEBUG - 2019-09-15 17:00:46 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:00:46 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:00:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:00:46 --> Final output sent to browser
DEBUG - 2019-09-15 17:00:46 --> Total execution time: 0.1288
INFO - 2019-09-15 17:00:46 --> Config Class Initialized
INFO - 2019-09-15 17:00:46 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:00:46 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:00:46 --> Utf8 Class Initialized
INFO - 2019-09-15 17:00:46 --> URI Class Initialized
INFO - 2019-09-15 17:00:46 --> Router Class Initialized
INFO - 2019-09-15 17:00:46 --> Output Class Initialized
INFO - 2019-09-15 17:00:46 --> Security Class Initialized
DEBUG - 2019-09-15 17:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:00:46 --> Input Class Initialized
INFO - 2019-09-15 17:00:46 --> Language Class Initialized
INFO - 2019-09-15 17:00:46 --> Loader Class Initialized
INFO - 2019-09-15 17:00:46 --> Helper loaded: url_helper
INFO - 2019-09-15 17:00:46 --> Helper loaded: html_helper
INFO - 2019-09-15 17:00:46 --> Helper loaded: form_helper
INFO - 2019-09-15 17:00:46 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:00:46 --> Helper loaded: date_helper
INFO - 2019-09-15 17:00:46 --> Form Validation Class Initialized
INFO - 2019-09-15 17:00:46 --> Email Class Initialized
DEBUG - 2019-09-15 17:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:00:46 --> Pagination Class Initialized
INFO - 2019-09-15 17:00:46 --> Database Driver Class Initialized
INFO - 2019-09-15 17:00:46 --> Database Driver Class Initialized
INFO - 2019-09-15 17:00:46 --> Controller Class Initialized
DEBUG - 2019-09-15 17:00:46 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:00:46 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:00:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:00:46 --> Final output sent to browser
DEBUG - 2019-09-15 17:00:46 --> Total execution time: 0.0979
INFO - 2019-09-15 17:00:46 --> Config Class Initialized
INFO - 2019-09-15 17:00:46 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:00:46 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:00:46 --> Utf8 Class Initialized
INFO - 2019-09-15 17:00:46 --> URI Class Initialized
INFO - 2019-09-15 17:00:46 --> Router Class Initialized
INFO - 2019-09-15 17:00:46 --> Output Class Initialized
INFO - 2019-09-15 17:00:46 --> Security Class Initialized
DEBUG - 2019-09-15 17:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:00:46 --> Input Class Initialized
INFO - 2019-09-15 17:00:46 --> Language Class Initialized
INFO - 2019-09-15 17:00:46 --> Loader Class Initialized
INFO - 2019-09-15 17:00:46 --> Helper loaded: url_helper
INFO - 2019-09-15 17:00:46 --> Helper loaded: html_helper
INFO - 2019-09-15 17:00:46 --> Helper loaded: form_helper
INFO - 2019-09-15 17:00:46 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:00:47 --> Helper loaded: date_helper
INFO - 2019-09-15 17:00:47 --> Form Validation Class Initialized
INFO - 2019-09-15 17:00:47 --> Email Class Initialized
DEBUG - 2019-09-15 17:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:00:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:00:47 --> Pagination Class Initialized
INFO - 2019-09-15 17:00:47 --> Database Driver Class Initialized
INFO - 2019-09-15 17:00:47 --> Database Driver Class Initialized
INFO - 2019-09-15 17:00:47 --> Controller Class Initialized
DEBUG - 2019-09-15 17:00:47 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:00:47 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:00:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:00:47 --> Final output sent to browser
DEBUG - 2019-09-15 17:00:47 --> Total execution time: 0.0610
INFO - 2019-09-15 17:00:47 --> Config Class Initialized
INFO - 2019-09-15 17:00:47 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:00:47 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:00:47 --> Utf8 Class Initialized
INFO - 2019-09-15 17:00:47 --> URI Class Initialized
INFO - 2019-09-15 17:00:47 --> Router Class Initialized
INFO - 2019-09-15 17:00:47 --> Output Class Initialized
INFO - 2019-09-15 17:00:47 --> Security Class Initialized
DEBUG - 2019-09-15 17:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:00:47 --> Input Class Initialized
INFO - 2019-09-15 17:00:47 --> Language Class Initialized
INFO - 2019-09-15 17:00:47 --> Loader Class Initialized
INFO - 2019-09-15 17:00:47 --> Helper loaded: url_helper
INFO - 2019-09-15 17:00:47 --> Helper loaded: html_helper
INFO - 2019-09-15 17:00:47 --> Helper loaded: form_helper
INFO - 2019-09-15 17:00:47 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:00:47 --> Helper loaded: date_helper
INFO - 2019-09-15 17:00:47 --> Form Validation Class Initialized
INFO - 2019-09-15 17:00:47 --> Email Class Initialized
DEBUG - 2019-09-15 17:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:00:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:00:47 --> Pagination Class Initialized
INFO - 2019-09-15 17:00:47 --> Database Driver Class Initialized
INFO - 2019-09-15 17:00:47 --> Database Driver Class Initialized
INFO - 2019-09-15 17:00:47 --> Controller Class Initialized
DEBUG - 2019-09-15 17:00:47 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:00:47 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:00:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:00:47 --> Final output sent to browser
DEBUG - 2019-09-15 17:00:47 --> Total execution time: 0.4596
INFO - 2019-09-15 17:11:57 --> Config Class Initialized
INFO - 2019-09-15 17:11:57 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:11:57 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:11:57 --> Utf8 Class Initialized
INFO - 2019-09-15 17:11:57 --> URI Class Initialized
INFO - 2019-09-15 17:11:57 --> Router Class Initialized
INFO - 2019-09-15 17:11:57 --> Output Class Initialized
INFO - 2019-09-15 17:11:57 --> Security Class Initialized
DEBUG - 2019-09-15 17:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:11:57 --> Input Class Initialized
INFO - 2019-09-15 17:11:57 --> Language Class Initialized
INFO - 2019-09-15 17:11:57 --> Loader Class Initialized
INFO - 2019-09-15 17:11:57 --> Helper loaded: url_helper
INFO - 2019-09-15 17:11:57 --> Helper loaded: html_helper
INFO - 2019-09-15 17:11:57 --> Helper loaded: form_helper
INFO - 2019-09-15 17:11:57 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:11:57 --> Helper loaded: date_helper
INFO - 2019-09-15 17:11:57 --> Form Validation Class Initialized
INFO - 2019-09-15 17:11:57 --> Email Class Initialized
DEBUG - 2019-09-15 17:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:11:57 --> Pagination Class Initialized
INFO - 2019-09-15 17:11:57 --> Database Driver Class Initialized
INFO - 2019-09-15 17:11:57 --> Database Driver Class Initialized
INFO - 2019-09-15 17:11:57 --> Controller Class Initialized
DEBUG - 2019-09-15 17:11:57 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:11:57 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:11:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:11:57 --> Final output sent to browser
DEBUG - 2019-09-15 17:11:57 --> Total execution time: 0.0678
INFO - 2019-09-15 17:11:57 --> Config Class Initialized
INFO - 2019-09-15 17:11:57 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:11:57 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:11:57 --> Utf8 Class Initialized
INFO - 2019-09-15 17:11:57 --> URI Class Initialized
INFO - 2019-09-15 17:11:57 --> Router Class Initialized
INFO - 2019-09-15 17:11:57 --> Output Class Initialized
INFO - 2019-09-15 17:11:57 --> Security Class Initialized
DEBUG - 2019-09-15 17:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:11:57 --> Input Class Initialized
INFO - 2019-09-15 17:11:57 --> Language Class Initialized
INFO - 2019-09-15 17:11:57 --> Loader Class Initialized
INFO - 2019-09-15 17:11:57 --> Helper loaded: url_helper
INFO - 2019-09-15 17:11:57 --> Helper loaded: html_helper
INFO - 2019-09-15 17:11:57 --> Helper loaded: form_helper
INFO - 2019-09-15 17:11:57 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:11:57 --> Helper loaded: date_helper
INFO - 2019-09-15 17:11:57 --> Form Validation Class Initialized
INFO - 2019-09-15 17:11:57 --> Email Class Initialized
DEBUG - 2019-09-15 17:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:11:57 --> Pagination Class Initialized
INFO - 2019-09-15 17:11:57 --> Database Driver Class Initialized
INFO - 2019-09-15 17:11:57 --> Database Driver Class Initialized
INFO - 2019-09-15 17:11:57 --> Controller Class Initialized
DEBUG - 2019-09-15 17:11:57 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:11:57 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:11:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:11:57 --> Final output sent to browser
DEBUG - 2019-09-15 17:11:57 --> Total execution time: 0.0649
INFO - 2019-09-15 17:11:57 --> Config Class Initialized
INFO - 2019-09-15 17:11:57 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:11:57 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:11:57 --> Utf8 Class Initialized
INFO - 2019-09-15 17:11:57 --> URI Class Initialized
INFO - 2019-09-15 17:11:57 --> Router Class Initialized
INFO - 2019-09-15 17:11:57 --> Output Class Initialized
INFO - 2019-09-15 17:11:57 --> Security Class Initialized
DEBUG - 2019-09-15 17:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:11:57 --> Input Class Initialized
INFO - 2019-09-15 17:11:57 --> Language Class Initialized
INFO - 2019-09-15 17:11:57 --> Loader Class Initialized
INFO - 2019-09-15 17:11:57 --> Helper loaded: url_helper
INFO - 2019-09-15 17:11:57 --> Helper loaded: html_helper
INFO - 2019-09-15 17:11:57 --> Helper loaded: form_helper
INFO - 2019-09-15 17:11:57 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:11:57 --> Helper loaded: date_helper
INFO - 2019-09-15 17:11:57 --> Form Validation Class Initialized
INFO - 2019-09-15 17:11:57 --> Email Class Initialized
DEBUG - 2019-09-15 17:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:11:57 --> Pagination Class Initialized
INFO - 2019-09-15 17:11:57 --> Database Driver Class Initialized
INFO - 2019-09-15 17:11:57 --> Database Driver Class Initialized
INFO - 2019-09-15 17:11:57 --> Controller Class Initialized
DEBUG - 2019-09-15 17:11:57 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:11:57 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:11:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:11:57 --> Final output sent to browser
DEBUG - 2019-09-15 17:11:57 --> Total execution time: 0.0591
INFO - 2019-09-15 17:11:57 --> Config Class Initialized
INFO - 2019-09-15 17:11:57 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:11:57 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:11:57 --> Utf8 Class Initialized
INFO - 2019-09-15 17:11:57 --> URI Class Initialized
INFO - 2019-09-15 17:11:57 --> Router Class Initialized
INFO - 2019-09-15 17:11:57 --> Output Class Initialized
INFO - 2019-09-15 17:11:57 --> Security Class Initialized
DEBUG - 2019-09-15 17:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:11:57 --> Input Class Initialized
INFO - 2019-09-15 17:11:57 --> Language Class Initialized
INFO - 2019-09-15 17:11:57 --> Loader Class Initialized
INFO - 2019-09-15 17:11:57 --> Helper loaded: url_helper
INFO - 2019-09-15 17:11:57 --> Helper loaded: html_helper
INFO - 2019-09-15 17:11:57 --> Helper loaded: form_helper
INFO - 2019-09-15 17:11:57 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:11:57 --> Helper loaded: date_helper
INFO - 2019-09-15 17:11:57 --> Form Validation Class Initialized
INFO - 2019-09-15 17:11:57 --> Email Class Initialized
DEBUG - 2019-09-15 17:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:11:57 --> Pagination Class Initialized
INFO - 2019-09-15 17:11:57 --> Database Driver Class Initialized
INFO - 2019-09-15 17:11:57 --> Database Driver Class Initialized
INFO - 2019-09-15 17:11:57 --> Controller Class Initialized
DEBUG - 2019-09-15 17:11:57 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:11:57 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:11:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:11:57 --> Final output sent to browser
DEBUG - 2019-09-15 17:11:57 --> Total execution time: 0.1587
INFO - 2019-09-15 17:14:55 --> Config Class Initialized
INFO - 2019-09-15 17:14:55 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:14:55 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:14:55 --> Utf8 Class Initialized
INFO - 2019-09-15 17:14:55 --> URI Class Initialized
INFO - 2019-09-15 17:14:55 --> Router Class Initialized
INFO - 2019-09-15 17:14:55 --> Output Class Initialized
INFO - 2019-09-15 17:14:55 --> Security Class Initialized
DEBUG - 2019-09-15 17:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:14:55 --> Input Class Initialized
INFO - 2019-09-15 17:14:55 --> Language Class Initialized
INFO - 2019-09-15 17:14:55 --> Loader Class Initialized
INFO - 2019-09-15 17:14:55 --> Helper loaded: url_helper
INFO - 2019-09-15 17:14:55 --> Helper loaded: html_helper
INFO - 2019-09-15 17:14:55 --> Helper loaded: form_helper
INFO - 2019-09-15 17:14:55 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:14:55 --> Helper loaded: date_helper
INFO - 2019-09-15 17:14:55 --> Form Validation Class Initialized
INFO - 2019-09-15 17:14:55 --> Email Class Initialized
DEBUG - 2019-09-15 17:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:14:55 --> Pagination Class Initialized
INFO - 2019-09-15 17:14:55 --> Database Driver Class Initialized
INFO - 2019-09-15 17:14:55 --> Database Driver Class Initialized
INFO - 2019-09-15 17:14:55 --> Controller Class Initialized
DEBUG - 2019-09-15 17:14:55 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:14:55 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:14:55 --> Language file loaded: language/english/rest_controller_lang.php
ERROR - 2019-09-15 17:14:55 --> Severity: Notice --> Undefined index: ID C:\wamp64\www\pridehotel_lagos\application\models\LocalUpdater_model.php 74
INFO - 2019-09-15 17:14:55 --> Final output sent to browser
DEBUG - 2019-09-15 17:14:55 --> Total execution time: 0.0644
INFO - 2019-09-15 17:15:31 --> Config Class Initialized
INFO - 2019-09-15 17:15:31 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:15:31 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:15:31 --> Utf8 Class Initialized
INFO - 2019-09-15 17:15:31 --> URI Class Initialized
INFO - 2019-09-15 17:15:31 --> Router Class Initialized
INFO - 2019-09-15 17:15:31 --> Output Class Initialized
INFO - 2019-09-15 17:15:31 --> Security Class Initialized
DEBUG - 2019-09-15 17:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:15:31 --> Input Class Initialized
INFO - 2019-09-15 17:15:31 --> Language Class Initialized
INFO - 2019-09-15 17:15:31 --> Loader Class Initialized
INFO - 2019-09-15 17:15:31 --> Helper loaded: url_helper
INFO - 2019-09-15 17:15:31 --> Helper loaded: html_helper
INFO - 2019-09-15 17:15:31 --> Helper loaded: form_helper
INFO - 2019-09-15 17:15:31 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:15:31 --> Helper loaded: date_helper
INFO - 2019-09-15 17:15:31 --> Form Validation Class Initialized
INFO - 2019-09-15 17:15:31 --> Email Class Initialized
DEBUG - 2019-09-15 17:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:15:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:15:31 --> Pagination Class Initialized
INFO - 2019-09-15 17:15:31 --> Database Driver Class Initialized
INFO - 2019-09-15 17:15:31 --> Database Driver Class Initialized
INFO - 2019-09-15 17:15:31 --> Controller Class Initialized
DEBUG - 2019-09-15 17:15:31 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:15:31 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:15:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:15:31 --> Final output sent to browser
DEBUG - 2019-09-15 17:15:31 --> Total execution time: 0.1199
INFO - 2019-09-15 17:24:21 --> Config Class Initialized
INFO - 2019-09-15 17:24:21 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:24:21 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:24:21 --> Utf8 Class Initialized
INFO - 2019-09-15 17:24:21 --> URI Class Initialized
INFO - 2019-09-15 17:24:21 --> Router Class Initialized
INFO - 2019-09-15 17:24:21 --> Output Class Initialized
INFO - 2019-09-15 17:24:21 --> Security Class Initialized
DEBUG - 2019-09-15 17:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:24:21 --> Input Class Initialized
INFO - 2019-09-15 17:24:21 --> Language Class Initialized
INFO - 2019-09-15 17:24:21 --> Loader Class Initialized
INFO - 2019-09-15 17:24:21 --> Helper loaded: url_helper
INFO - 2019-09-15 17:24:21 --> Helper loaded: html_helper
INFO - 2019-09-15 17:24:21 --> Helper loaded: form_helper
INFO - 2019-09-15 17:24:21 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:24:21 --> Helper loaded: date_helper
INFO - 2019-09-15 17:24:21 --> Form Validation Class Initialized
INFO - 2019-09-15 17:24:21 --> Email Class Initialized
DEBUG - 2019-09-15 17:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:24:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:24:21 --> Pagination Class Initialized
INFO - 2019-09-15 17:24:21 --> Database Driver Class Initialized
INFO - 2019-09-15 17:24:21 --> Database Driver Class Initialized
INFO - 2019-09-15 17:24:21 --> Controller Class Initialized
DEBUG - 2019-09-15 17:24:21 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:24:21 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:24:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:24:22 --> Final output sent to browser
DEBUG - 2019-09-15 17:24:22 --> Total execution time: 0.0719
INFO - 2019-09-15 17:24:22 --> Config Class Initialized
INFO - 2019-09-15 17:24:22 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:24:22 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:24:22 --> Utf8 Class Initialized
INFO - 2019-09-15 17:24:22 --> URI Class Initialized
INFO - 2019-09-15 17:24:22 --> Router Class Initialized
INFO - 2019-09-15 17:24:22 --> Output Class Initialized
INFO - 2019-09-15 17:24:22 --> Security Class Initialized
DEBUG - 2019-09-15 17:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:24:22 --> Input Class Initialized
INFO - 2019-09-15 17:24:22 --> Language Class Initialized
INFO - 2019-09-15 17:24:22 --> Loader Class Initialized
INFO - 2019-09-15 17:24:22 --> Helper loaded: url_helper
INFO - 2019-09-15 17:24:22 --> Helper loaded: html_helper
INFO - 2019-09-15 17:24:22 --> Helper loaded: form_helper
INFO - 2019-09-15 17:24:22 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:24:22 --> Helper loaded: date_helper
INFO - 2019-09-15 17:24:22 --> Form Validation Class Initialized
INFO - 2019-09-15 17:24:22 --> Email Class Initialized
DEBUG - 2019-09-15 17:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:24:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:24:22 --> Pagination Class Initialized
INFO - 2019-09-15 17:24:22 --> Database Driver Class Initialized
INFO - 2019-09-15 17:24:22 --> Database Driver Class Initialized
INFO - 2019-09-15 17:24:22 --> Controller Class Initialized
DEBUG - 2019-09-15 17:24:22 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:24:22 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:24:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:24:22 --> Final output sent to browser
DEBUG - 2019-09-15 17:24:22 --> Total execution time: 0.0624
INFO - 2019-09-15 17:24:22 --> Config Class Initialized
INFO - 2019-09-15 17:24:22 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:24:22 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:24:22 --> Utf8 Class Initialized
INFO - 2019-09-15 17:24:22 --> URI Class Initialized
INFO - 2019-09-15 17:24:22 --> Router Class Initialized
INFO - 2019-09-15 17:24:22 --> Output Class Initialized
INFO - 2019-09-15 17:24:22 --> Security Class Initialized
DEBUG - 2019-09-15 17:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:24:22 --> Input Class Initialized
INFO - 2019-09-15 17:24:22 --> Language Class Initialized
INFO - 2019-09-15 17:24:22 --> Loader Class Initialized
INFO - 2019-09-15 17:24:22 --> Helper loaded: url_helper
INFO - 2019-09-15 17:24:22 --> Helper loaded: html_helper
INFO - 2019-09-15 17:24:22 --> Helper loaded: form_helper
INFO - 2019-09-15 17:24:22 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:24:22 --> Helper loaded: date_helper
INFO - 2019-09-15 17:24:22 --> Form Validation Class Initialized
INFO - 2019-09-15 17:24:22 --> Email Class Initialized
DEBUG - 2019-09-15 17:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:24:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:24:22 --> Pagination Class Initialized
INFO - 2019-09-15 17:24:22 --> Database Driver Class Initialized
INFO - 2019-09-15 17:24:22 --> Database Driver Class Initialized
INFO - 2019-09-15 17:24:22 --> Controller Class Initialized
DEBUG - 2019-09-15 17:24:22 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:24:22 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:24:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:24:22 --> Final output sent to browser
DEBUG - 2019-09-15 17:24:22 --> Total execution time: 0.0617
INFO - 2019-09-15 17:24:22 --> Config Class Initialized
INFO - 2019-09-15 17:24:22 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:24:22 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:24:22 --> Utf8 Class Initialized
INFO - 2019-09-15 17:24:22 --> URI Class Initialized
INFO - 2019-09-15 17:24:22 --> Router Class Initialized
INFO - 2019-09-15 17:24:22 --> Output Class Initialized
INFO - 2019-09-15 17:24:22 --> Security Class Initialized
DEBUG - 2019-09-15 17:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:24:22 --> Input Class Initialized
INFO - 2019-09-15 17:24:22 --> Language Class Initialized
INFO - 2019-09-15 17:24:22 --> Loader Class Initialized
INFO - 2019-09-15 17:24:22 --> Helper loaded: url_helper
INFO - 2019-09-15 17:24:22 --> Helper loaded: html_helper
INFO - 2019-09-15 17:24:22 --> Helper loaded: form_helper
INFO - 2019-09-15 17:24:22 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:24:22 --> Helper loaded: date_helper
INFO - 2019-09-15 17:24:22 --> Form Validation Class Initialized
INFO - 2019-09-15 17:24:22 --> Email Class Initialized
DEBUG - 2019-09-15 17:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:24:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:24:22 --> Pagination Class Initialized
INFO - 2019-09-15 17:24:22 --> Database Driver Class Initialized
INFO - 2019-09-15 17:24:22 --> Database Driver Class Initialized
INFO - 2019-09-15 17:24:22 --> Controller Class Initialized
DEBUG - 2019-09-15 17:24:22 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:24:22 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:24:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:24:22 --> Final output sent to browser
DEBUG - 2019-09-15 17:24:22 --> Total execution time: 0.2320
INFO - 2019-09-15 17:24:39 --> Config Class Initialized
INFO - 2019-09-15 17:24:39 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:24:39 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:24:39 --> Utf8 Class Initialized
INFO - 2019-09-15 17:24:39 --> URI Class Initialized
INFO - 2019-09-15 17:24:39 --> Router Class Initialized
INFO - 2019-09-15 17:24:39 --> Output Class Initialized
INFO - 2019-09-15 17:24:39 --> Security Class Initialized
DEBUG - 2019-09-15 17:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:24:39 --> Input Class Initialized
INFO - 2019-09-15 17:24:39 --> Language Class Initialized
INFO - 2019-09-15 17:24:39 --> Loader Class Initialized
INFO - 2019-09-15 17:24:39 --> Helper loaded: url_helper
INFO - 2019-09-15 17:24:39 --> Helper loaded: html_helper
INFO - 2019-09-15 17:24:39 --> Helper loaded: form_helper
INFO - 2019-09-15 17:24:39 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:24:39 --> Helper loaded: date_helper
INFO - 2019-09-15 17:24:39 --> Form Validation Class Initialized
INFO - 2019-09-15 17:24:39 --> Email Class Initialized
DEBUG - 2019-09-15 17:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:24:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:24:39 --> Pagination Class Initialized
INFO - 2019-09-15 17:24:39 --> Database Driver Class Initialized
INFO - 2019-09-15 17:24:39 --> Database Driver Class Initialized
INFO - 2019-09-15 17:24:39 --> Controller Class Initialized
DEBUG - 2019-09-15 17:24:39 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:24:39 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:24:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:24:39 --> Final output sent to browser
DEBUG - 2019-09-15 17:24:39 --> Total execution time: 0.0700
INFO - 2019-09-15 17:24:39 --> Config Class Initialized
INFO - 2019-09-15 17:24:39 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:24:39 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:24:39 --> Utf8 Class Initialized
INFO - 2019-09-15 17:24:39 --> URI Class Initialized
INFO - 2019-09-15 17:24:39 --> Router Class Initialized
INFO - 2019-09-15 17:24:39 --> Output Class Initialized
INFO - 2019-09-15 17:24:39 --> Security Class Initialized
DEBUG - 2019-09-15 17:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:24:39 --> Input Class Initialized
INFO - 2019-09-15 17:24:39 --> Language Class Initialized
INFO - 2019-09-15 17:24:39 --> Loader Class Initialized
INFO - 2019-09-15 17:24:39 --> Helper loaded: url_helper
INFO - 2019-09-15 17:24:39 --> Helper loaded: html_helper
INFO - 2019-09-15 17:24:39 --> Helper loaded: form_helper
INFO - 2019-09-15 17:24:39 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:24:39 --> Helper loaded: date_helper
INFO - 2019-09-15 17:24:39 --> Form Validation Class Initialized
INFO - 2019-09-15 17:24:39 --> Email Class Initialized
DEBUG - 2019-09-15 17:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:24:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:24:39 --> Pagination Class Initialized
INFO - 2019-09-15 17:24:39 --> Database Driver Class Initialized
INFO - 2019-09-15 17:24:39 --> Database Driver Class Initialized
INFO - 2019-09-15 17:24:39 --> Controller Class Initialized
DEBUG - 2019-09-15 17:24:39 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:24:39 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:24:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:24:39 --> Final output sent to browser
DEBUG - 2019-09-15 17:24:39 --> Total execution time: 0.0617
INFO - 2019-09-15 17:24:39 --> Config Class Initialized
INFO - 2019-09-15 17:24:39 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:24:39 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:24:39 --> Utf8 Class Initialized
INFO - 2019-09-15 17:24:39 --> URI Class Initialized
INFO - 2019-09-15 17:24:39 --> Router Class Initialized
INFO - 2019-09-15 17:24:39 --> Output Class Initialized
INFO - 2019-09-15 17:24:39 --> Security Class Initialized
DEBUG - 2019-09-15 17:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:24:39 --> Input Class Initialized
INFO - 2019-09-15 17:24:39 --> Language Class Initialized
INFO - 2019-09-15 17:24:39 --> Loader Class Initialized
INFO - 2019-09-15 17:24:39 --> Helper loaded: url_helper
INFO - 2019-09-15 17:24:39 --> Helper loaded: html_helper
INFO - 2019-09-15 17:24:39 --> Helper loaded: form_helper
INFO - 2019-09-15 17:24:39 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:24:39 --> Helper loaded: date_helper
INFO - 2019-09-15 17:24:39 --> Form Validation Class Initialized
INFO - 2019-09-15 17:24:39 --> Email Class Initialized
DEBUG - 2019-09-15 17:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:24:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:24:39 --> Pagination Class Initialized
INFO - 2019-09-15 17:24:39 --> Database Driver Class Initialized
INFO - 2019-09-15 17:24:39 --> Database Driver Class Initialized
INFO - 2019-09-15 17:24:39 --> Controller Class Initialized
DEBUG - 2019-09-15 17:24:39 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:24:39 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:24:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:24:39 --> Final output sent to browser
DEBUG - 2019-09-15 17:24:39 --> Total execution time: 0.0613
INFO - 2019-09-15 17:24:39 --> Config Class Initialized
INFO - 2019-09-15 17:24:39 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:24:39 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:24:39 --> Utf8 Class Initialized
INFO - 2019-09-15 17:24:39 --> URI Class Initialized
INFO - 2019-09-15 17:24:39 --> Router Class Initialized
INFO - 2019-09-15 17:24:39 --> Output Class Initialized
INFO - 2019-09-15 17:24:39 --> Security Class Initialized
DEBUG - 2019-09-15 17:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:24:39 --> Input Class Initialized
INFO - 2019-09-15 17:24:39 --> Language Class Initialized
INFO - 2019-09-15 17:24:39 --> Loader Class Initialized
INFO - 2019-09-15 17:24:39 --> Helper loaded: url_helper
INFO - 2019-09-15 17:24:39 --> Helper loaded: html_helper
INFO - 2019-09-15 17:24:39 --> Helper loaded: form_helper
INFO - 2019-09-15 17:24:39 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:24:39 --> Helper loaded: date_helper
INFO - 2019-09-15 17:24:39 --> Form Validation Class Initialized
INFO - 2019-09-15 17:24:39 --> Email Class Initialized
DEBUG - 2019-09-15 17:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:24:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:24:39 --> Pagination Class Initialized
INFO - 2019-09-15 17:24:39 --> Database Driver Class Initialized
INFO - 2019-09-15 17:24:39 --> Database Driver Class Initialized
INFO - 2019-09-15 17:24:39 --> Controller Class Initialized
DEBUG - 2019-09-15 17:24:39 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:24:39 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:24:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:24:39 --> Final output sent to browser
DEBUG - 2019-09-15 17:24:39 --> Total execution time: 0.2260
INFO - 2019-09-15 17:25:37 --> Config Class Initialized
INFO - 2019-09-15 17:25:37 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:25:37 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:25:37 --> Utf8 Class Initialized
INFO - 2019-09-15 17:25:37 --> URI Class Initialized
INFO - 2019-09-15 17:25:37 --> Router Class Initialized
INFO - 2019-09-15 17:25:37 --> Output Class Initialized
INFO - 2019-09-15 17:25:37 --> Security Class Initialized
DEBUG - 2019-09-15 17:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:25:37 --> Input Class Initialized
INFO - 2019-09-15 17:25:37 --> Language Class Initialized
INFO - 2019-09-15 17:25:37 --> Loader Class Initialized
INFO - 2019-09-15 17:25:37 --> Helper loaded: url_helper
INFO - 2019-09-15 17:25:37 --> Helper loaded: html_helper
INFO - 2019-09-15 17:25:37 --> Helper loaded: form_helper
INFO - 2019-09-15 17:25:37 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:25:37 --> Helper loaded: date_helper
INFO - 2019-09-15 17:25:37 --> Form Validation Class Initialized
INFO - 2019-09-15 17:25:37 --> Email Class Initialized
DEBUG - 2019-09-15 17:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:25:37 --> Pagination Class Initialized
INFO - 2019-09-15 17:25:37 --> Database Driver Class Initialized
INFO - 2019-09-15 17:25:37 --> Database Driver Class Initialized
INFO - 2019-09-15 17:25:37 --> Controller Class Initialized
DEBUG - 2019-09-15 17:25:37 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:25:37 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:25:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:25:37 --> Final output sent to browser
DEBUG - 2019-09-15 17:25:37 --> Total execution time: 0.0628
INFO - 2019-09-15 17:25:37 --> Config Class Initialized
INFO - 2019-09-15 17:25:37 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:25:37 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:25:37 --> Utf8 Class Initialized
INFO - 2019-09-15 17:25:37 --> URI Class Initialized
INFO - 2019-09-15 17:25:37 --> Router Class Initialized
INFO - 2019-09-15 17:25:37 --> Output Class Initialized
INFO - 2019-09-15 17:25:37 --> Security Class Initialized
DEBUG - 2019-09-15 17:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:25:37 --> Input Class Initialized
INFO - 2019-09-15 17:25:37 --> Language Class Initialized
INFO - 2019-09-15 17:25:37 --> Loader Class Initialized
INFO - 2019-09-15 17:25:37 --> Helper loaded: url_helper
INFO - 2019-09-15 17:25:37 --> Helper loaded: html_helper
INFO - 2019-09-15 17:25:37 --> Helper loaded: form_helper
INFO - 2019-09-15 17:25:37 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:25:37 --> Helper loaded: date_helper
INFO - 2019-09-15 17:25:37 --> Form Validation Class Initialized
INFO - 2019-09-15 17:25:37 --> Email Class Initialized
DEBUG - 2019-09-15 17:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:25:37 --> Pagination Class Initialized
INFO - 2019-09-15 17:25:37 --> Database Driver Class Initialized
INFO - 2019-09-15 17:25:37 --> Database Driver Class Initialized
INFO - 2019-09-15 17:25:37 --> Controller Class Initialized
DEBUG - 2019-09-15 17:25:37 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:25:37 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:25:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:25:37 --> Final output sent to browser
DEBUG - 2019-09-15 17:25:37 --> Total execution time: 0.0565
INFO - 2019-09-15 17:25:37 --> Config Class Initialized
INFO - 2019-09-15 17:25:37 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:25:37 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:25:37 --> Utf8 Class Initialized
INFO - 2019-09-15 17:25:37 --> URI Class Initialized
INFO - 2019-09-15 17:25:37 --> Router Class Initialized
INFO - 2019-09-15 17:25:37 --> Output Class Initialized
INFO - 2019-09-15 17:25:37 --> Security Class Initialized
DEBUG - 2019-09-15 17:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:25:37 --> Input Class Initialized
INFO - 2019-09-15 17:25:37 --> Language Class Initialized
INFO - 2019-09-15 17:25:37 --> Loader Class Initialized
INFO - 2019-09-15 17:25:37 --> Helper loaded: url_helper
INFO - 2019-09-15 17:25:37 --> Helper loaded: html_helper
INFO - 2019-09-15 17:25:37 --> Helper loaded: form_helper
INFO - 2019-09-15 17:25:37 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:25:37 --> Helper loaded: date_helper
INFO - 2019-09-15 17:25:37 --> Form Validation Class Initialized
INFO - 2019-09-15 17:25:37 --> Email Class Initialized
DEBUG - 2019-09-15 17:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:25:37 --> Pagination Class Initialized
INFO - 2019-09-15 17:25:37 --> Database Driver Class Initialized
INFO - 2019-09-15 17:25:37 --> Database Driver Class Initialized
INFO - 2019-09-15 17:25:37 --> Controller Class Initialized
DEBUG - 2019-09-15 17:25:37 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:25:37 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:25:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:25:37 --> Final output sent to browser
DEBUG - 2019-09-15 17:25:37 --> Total execution time: 0.0882
INFO - 2019-09-15 17:26:29 --> Config Class Initialized
INFO - 2019-09-15 17:26:29 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:26:29 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:26:29 --> Utf8 Class Initialized
INFO - 2019-09-15 17:26:29 --> URI Class Initialized
INFO - 2019-09-15 17:26:29 --> Router Class Initialized
INFO - 2019-09-15 17:26:29 --> Output Class Initialized
INFO - 2019-09-15 17:26:29 --> Security Class Initialized
DEBUG - 2019-09-15 17:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:26:29 --> Input Class Initialized
INFO - 2019-09-15 17:26:29 --> Language Class Initialized
INFO - 2019-09-15 17:26:29 --> Loader Class Initialized
INFO - 2019-09-15 17:26:29 --> Helper loaded: url_helper
INFO - 2019-09-15 17:26:29 --> Helper loaded: html_helper
INFO - 2019-09-15 17:26:29 --> Helper loaded: form_helper
INFO - 2019-09-15 17:26:29 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:26:29 --> Helper loaded: date_helper
INFO - 2019-09-15 17:26:29 --> Form Validation Class Initialized
INFO - 2019-09-15 17:26:29 --> Email Class Initialized
DEBUG - 2019-09-15 17:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:26:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:26:29 --> Pagination Class Initialized
INFO - 2019-09-15 17:26:29 --> Database Driver Class Initialized
INFO - 2019-09-15 17:26:29 --> Database Driver Class Initialized
INFO - 2019-09-15 17:26:29 --> Controller Class Initialized
DEBUG - 2019-09-15 17:26:29 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:26:29 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:26:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:26:29 --> Final output sent to browser
DEBUG - 2019-09-15 17:26:29 --> Total execution time: 0.2353
INFO - 2019-09-15 17:30:19 --> Config Class Initialized
INFO - 2019-09-15 17:30:19 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:30:19 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:30:19 --> Utf8 Class Initialized
INFO - 2019-09-15 17:30:19 --> URI Class Initialized
INFO - 2019-09-15 17:30:19 --> Router Class Initialized
INFO - 2019-09-15 17:30:19 --> Output Class Initialized
INFO - 2019-09-15 17:30:19 --> Security Class Initialized
DEBUG - 2019-09-15 17:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:30:19 --> Input Class Initialized
INFO - 2019-09-15 17:30:19 --> Language Class Initialized
INFO - 2019-09-15 17:30:19 --> Loader Class Initialized
INFO - 2019-09-15 17:30:19 --> Helper loaded: url_helper
INFO - 2019-09-15 17:30:19 --> Helper loaded: html_helper
INFO - 2019-09-15 17:30:19 --> Helper loaded: form_helper
INFO - 2019-09-15 17:30:19 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:30:19 --> Helper loaded: date_helper
INFO - 2019-09-15 17:30:19 --> Form Validation Class Initialized
INFO - 2019-09-15 17:30:19 --> Email Class Initialized
DEBUG - 2019-09-15 17:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:30:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:30:19 --> Pagination Class Initialized
INFO - 2019-09-15 17:30:19 --> Database Driver Class Initialized
INFO - 2019-09-15 17:30:19 --> Database Driver Class Initialized
INFO - 2019-09-15 17:30:19 --> Controller Class Initialized
DEBUG - 2019-09-15 17:30:19 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:30:19 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:30:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:30:19 --> Final output sent to browser
DEBUG - 2019-09-15 17:30:19 --> Total execution time: 0.0611
INFO - 2019-09-15 17:30:19 --> Config Class Initialized
INFO - 2019-09-15 17:30:19 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:30:19 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:30:19 --> Utf8 Class Initialized
INFO - 2019-09-15 17:30:19 --> URI Class Initialized
INFO - 2019-09-15 17:30:19 --> Router Class Initialized
INFO - 2019-09-15 17:30:19 --> Output Class Initialized
INFO - 2019-09-15 17:30:19 --> Security Class Initialized
DEBUG - 2019-09-15 17:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:30:19 --> Input Class Initialized
INFO - 2019-09-15 17:30:19 --> Language Class Initialized
INFO - 2019-09-15 17:30:19 --> Loader Class Initialized
INFO - 2019-09-15 17:30:19 --> Helper loaded: url_helper
INFO - 2019-09-15 17:30:19 --> Helper loaded: html_helper
INFO - 2019-09-15 17:30:19 --> Helper loaded: form_helper
INFO - 2019-09-15 17:30:19 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:30:19 --> Helper loaded: date_helper
INFO - 2019-09-15 17:30:19 --> Form Validation Class Initialized
INFO - 2019-09-15 17:30:19 --> Email Class Initialized
DEBUG - 2019-09-15 17:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:30:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:30:19 --> Pagination Class Initialized
INFO - 2019-09-15 17:30:19 --> Database Driver Class Initialized
INFO - 2019-09-15 17:30:19 --> Database Driver Class Initialized
INFO - 2019-09-15 17:30:19 --> Controller Class Initialized
DEBUG - 2019-09-15 17:30:19 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:30:19 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:30:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:30:19 --> Final output sent to browser
DEBUG - 2019-09-15 17:30:19 --> Total execution time: 0.0593
INFO - 2019-09-15 17:30:20 --> Config Class Initialized
INFO - 2019-09-15 17:30:20 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:30:20 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:30:20 --> Utf8 Class Initialized
INFO - 2019-09-15 17:30:20 --> URI Class Initialized
INFO - 2019-09-15 17:30:20 --> Router Class Initialized
INFO - 2019-09-15 17:30:20 --> Output Class Initialized
INFO - 2019-09-15 17:30:20 --> Security Class Initialized
DEBUG - 2019-09-15 17:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:30:20 --> Input Class Initialized
INFO - 2019-09-15 17:30:20 --> Language Class Initialized
INFO - 2019-09-15 17:30:20 --> Loader Class Initialized
INFO - 2019-09-15 17:30:20 --> Helper loaded: url_helper
INFO - 2019-09-15 17:30:20 --> Helper loaded: html_helper
INFO - 2019-09-15 17:30:20 --> Helper loaded: form_helper
INFO - 2019-09-15 17:30:20 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:30:20 --> Helper loaded: date_helper
INFO - 2019-09-15 17:30:20 --> Form Validation Class Initialized
INFO - 2019-09-15 17:30:20 --> Email Class Initialized
DEBUG - 2019-09-15 17:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:30:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:30:20 --> Pagination Class Initialized
INFO - 2019-09-15 17:30:20 --> Database Driver Class Initialized
INFO - 2019-09-15 17:30:20 --> Database Driver Class Initialized
INFO - 2019-09-15 17:30:20 --> Controller Class Initialized
DEBUG - 2019-09-15 17:30:20 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:30:20 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:30:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:30:20 --> Final output sent to browser
DEBUG - 2019-09-15 17:30:20 --> Total execution time: 0.0662
INFO - 2019-09-15 17:30:20 --> Config Class Initialized
INFO - 2019-09-15 17:30:20 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:30:20 --> UTF-8 Support Enabled
INFO - 2019-09-15 17:30:20 --> Utf8 Class Initialized
INFO - 2019-09-15 17:30:20 --> URI Class Initialized
INFO - 2019-09-15 17:30:20 --> Router Class Initialized
INFO - 2019-09-15 17:30:20 --> Output Class Initialized
INFO - 2019-09-15 17:30:20 --> Security Class Initialized
DEBUG - 2019-09-15 17:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 17:30:20 --> Input Class Initialized
INFO - 2019-09-15 17:30:20 --> Language Class Initialized
INFO - 2019-09-15 17:30:20 --> Loader Class Initialized
INFO - 2019-09-15 17:30:20 --> Helper loaded: url_helper
INFO - 2019-09-15 17:30:20 --> Helper loaded: html_helper
INFO - 2019-09-15 17:30:20 --> Helper loaded: form_helper
INFO - 2019-09-15 17:30:20 --> Helper loaded: cookie_helper
INFO - 2019-09-15 17:30:20 --> Helper loaded: date_helper
INFO - 2019-09-15 17:30:20 --> Form Validation Class Initialized
INFO - 2019-09-15 17:30:20 --> Email Class Initialized
DEBUG - 2019-09-15 17:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 17:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 17:30:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 17:30:20 --> Pagination Class Initialized
INFO - 2019-09-15 17:30:20 --> Database Driver Class Initialized
INFO - 2019-09-15 17:30:20 --> Database Driver Class Initialized
INFO - 2019-09-15 17:30:20 --> Controller Class Initialized
DEBUG - 2019-09-15 17:30:20 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 17:30:20 --> Helper loaded: inflector_helper
INFO - 2019-09-15 17:30:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 17:30:20 --> Final output sent to browser
DEBUG - 2019-09-15 17:30:20 --> Total execution time: 0.1944
INFO - 2019-09-15 19:52:12 --> Config Class Initialized
INFO - 2019-09-15 19:52:12 --> Hooks Class Initialized
DEBUG - 2019-09-15 19:52:12 --> UTF-8 Support Enabled
INFO - 2019-09-15 19:52:12 --> Utf8 Class Initialized
INFO - 2019-09-15 19:52:12 --> URI Class Initialized
INFO - 2019-09-15 19:52:12 --> Router Class Initialized
INFO - 2019-09-15 19:52:13 --> Output Class Initialized
INFO - 2019-09-15 19:52:13 --> Security Class Initialized
DEBUG - 2019-09-15 19:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 19:52:13 --> Input Class Initialized
INFO - 2019-09-15 19:52:13 --> Language Class Initialized
INFO - 2019-09-15 19:52:13 --> Loader Class Initialized
INFO - 2019-09-15 19:52:13 --> Helper loaded: url_helper
INFO - 2019-09-15 19:52:14 --> Helper loaded: html_helper
INFO - 2019-09-15 19:52:14 --> Helper loaded: form_helper
INFO - 2019-09-15 19:52:14 --> Helper loaded: cookie_helper
INFO - 2019-09-15 19:52:14 --> Helper loaded: date_helper
INFO - 2019-09-15 19:52:14 --> Form Validation Class Initialized
INFO - 2019-09-15 19:52:14 --> Email Class Initialized
DEBUG - 2019-09-15 19:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 19:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 19:52:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 19:52:16 --> Pagination Class Initialized
INFO - 2019-09-15 19:52:16 --> Database Driver Class Initialized
INFO - 2019-09-15 19:52:16 --> Database Driver Class Initialized
INFO - 2019-09-15 19:52:17 --> Controller Class Initialized
ERROR - 2019-09-15 19:52:17 --> Query error: Table 'pridehotel_online_reports.siteitems' doesn't exist - Invalid query: SELECT * from siteitems where 1=1 order by ID 
INFO - 2019-09-15 19:52:17 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-15 19:52:17 --> Config Class Initialized
INFO - 2019-09-15 19:52:17 --> Hooks Class Initialized
DEBUG - 2019-09-15 19:52:17 --> UTF-8 Support Enabled
INFO - 2019-09-15 19:52:17 --> Utf8 Class Initialized
INFO - 2019-09-15 19:52:17 --> URI Class Initialized
INFO - 2019-09-15 19:52:17 --> Router Class Initialized
INFO - 2019-09-15 19:52:17 --> Output Class Initialized
INFO - 2019-09-15 19:52:17 --> Security Class Initialized
DEBUG - 2019-09-15 19:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 19:52:17 --> Input Class Initialized
INFO - 2019-09-15 19:52:17 --> Language Class Initialized
INFO - 2019-09-15 19:52:17 --> Loader Class Initialized
INFO - 2019-09-15 19:52:17 --> Helper loaded: url_helper
INFO - 2019-09-15 19:52:17 --> Helper loaded: html_helper
INFO - 2019-09-15 19:52:17 --> Helper loaded: form_helper
INFO - 2019-09-15 19:52:17 --> Helper loaded: cookie_helper
INFO - 2019-09-15 19:52:17 --> Helper loaded: date_helper
INFO - 2019-09-15 19:52:17 --> Form Validation Class Initialized
INFO - 2019-09-15 19:52:17 --> Email Class Initialized
DEBUG - 2019-09-15 19:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 19:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 19:52:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 19:52:17 --> Pagination Class Initialized
INFO - 2019-09-15 19:52:17 --> Database Driver Class Initialized
INFO - 2019-09-15 19:52:17 --> Database Driver Class Initialized
INFO - 2019-09-15 19:52:17 --> Controller Class Initialized
ERROR - 2019-09-15 19:52:17 --> Query error: Table 'pridehotel_online_reports.siteitems' doesn't exist - Invalid query: SELECT * from siteitems where 1=1 order by ID 
INFO - 2019-09-15 19:52:17 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-15 21:18:50 --> Config Class Initialized
INFO - 2019-09-15 21:18:50 --> Hooks Class Initialized
DEBUG - 2019-09-15 21:18:50 --> UTF-8 Support Enabled
INFO - 2019-09-15 21:18:50 --> Utf8 Class Initialized
INFO - 2019-09-15 21:18:50 --> URI Class Initialized
INFO - 2019-09-15 21:18:50 --> Router Class Initialized
INFO - 2019-09-15 21:18:50 --> Output Class Initialized
INFO - 2019-09-15 21:18:50 --> Security Class Initialized
DEBUG - 2019-09-15 21:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 21:18:50 --> Input Class Initialized
INFO - 2019-09-15 21:18:50 --> Language Class Initialized
INFO - 2019-09-15 21:18:50 --> Loader Class Initialized
INFO - 2019-09-15 21:18:50 --> Helper loaded: url_helper
INFO - 2019-09-15 21:18:50 --> Helper loaded: html_helper
INFO - 2019-09-15 21:18:50 --> Helper loaded: form_helper
INFO - 2019-09-15 21:18:50 --> Helper loaded: cookie_helper
INFO - 2019-09-15 21:18:50 --> Helper loaded: date_helper
INFO - 2019-09-15 21:18:50 --> Form Validation Class Initialized
INFO - 2019-09-15 21:18:50 --> Email Class Initialized
DEBUG - 2019-09-15 21:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 21:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 21:18:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 21:18:50 --> Pagination Class Initialized
INFO - 2019-09-15 21:18:50 --> Database Driver Class Initialized
INFO - 2019-09-15 21:18:50 --> Database Driver Class Initialized
INFO - 2019-09-15 21:18:50 --> Controller Class Initialized
INFO - 2019-09-15 21:18:50 --> Config Class Initialized
INFO - 2019-09-15 21:18:50 --> Hooks Class Initialized
DEBUG - 2019-09-15 21:18:50 --> UTF-8 Support Enabled
INFO - 2019-09-15 21:18:50 --> Utf8 Class Initialized
INFO - 2019-09-15 21:18:50 --> URI Class Initialized
INFO - 2019-09-15 21:18:50 --> Router Class Initialized
INFO - 2019-09-15 21:18:50 --> Output Class Initialized
INFO - 2019-09-15 21:18:50 --> Security Class Initialized
DEBUG - 2019-09-15 21:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 21:18:50 --> Input Class Initialized
INFO - 2019-09-15 21:18:50 --> Language Class Initialized
INFO - 2019-09-15 21:18:50 --> Loader Class Initialized
INFO - 2019-09-15 21:18:50 --> Helper loaded: url_helper
INFO - 2019-09-15 21:18:50 --> Helper loaded: html_helper
INFO - 2019-09-15 21:18:50 --> Helper loaded: form_helper
INFO - 2019-09-15 21:18:50 --> Helper loaded: cookie_helper
INFO - 2019-09-15 21:18:50 --> Helper loaded: date_helper
INFO - 2019-09-15 21:18:50 --> Form Validation Class Initialized
INFO - 2019-09-15 21:18:50 --> Email Class Initialized
DEBUG - 2019-09-15 21:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 21:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 21:18:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 21:18:50 --> Pagination Class Initialized
INFO - 2019-09-15 21:18:50 --> Database Driver Class Initialized
INFO - 2019-09-15 21:18:50 --> Database Driver Class Initialized
INFO - 2019-09-15 21:18:50 --> Controller Class Initialized
INFO - 2019-09-15 21:18:50 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-15 21:18:50 --> Final output sent to browser
DEBUG - 2019-09-15 21:18:50 --> Total execution time: 0.0474
INFO - 2019-09-15 21:18:51 --> Config Class Initialized
INFO - 2019-09-15 21:18:51 --> Hooks Class Initialized
DEBUG - 2019-09-15 21:18:51 --> UTF-8 Support Enabled
INFO - 2019-09-15 21:18:51 --> Utf8 Class Initialized
INFO - 2019-09-15 21:18:51 --> URI Class Initialized
INFO - 2019-09-15 21:18:51 --> Router Class Initialized
INFO - 2019-09-15 21:18:51 --> Output Class Initialized
INFO - 2019-09-15 21:18:51 --> Security Class Initialized
DEBUG - 2019-09-15 21:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 21:18:51 --> Input Class Initialized
INFO - 2019-09-15 21:18:51 --> Language Class Initialized
INFO - 2019-09-15 21:18:51 --> Loader Class Initialized
INFO - 2019-09-15 21:18:51 --> Helper loaded: url_helper
INFO - 2019-09-15 21:18:51 --> Helper loaded: html_helper
INFO - 2019-09-15 21:18:51 --> Helper loaded: form_helper
INFO - 2019-09-15 21:18:51 --> Helper loaded: cookie_helper
INFO - 2019-09-15 21:18:51 --> Helper loaded: date_helper
INFO - 2019-09-15 21:18:51 --> Form Validation Class Initialized
INFO - 2019-09-15 21:18:51 --> Email Class Initialized
DEBUG - 2019-09-15 21:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 21:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 21:18:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 21:18:51 --> Pagination Class Initialized
INFO - 2019-09-15 21:18:51 --> Database Driver Class Initialized
INFO - 2019-09-15 21:18:51 --> Database Driver Class Initialized
INFO - 2019-09-15 21:18:51 --> Controller Class Initialized
INFO - 2019-09-15 21:18:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-09-15 21:18:51 --> Final output sent to browser
DEBUG - 2019-09-15 21:18:51 --> Total execution time: 0.0534
INFO - 2019-09-15 21:19:01 --> Config Class Initialized
INFO - 2019-09-15 21:19:01 --> Hooks Class Initialized
DEBUG - 2019-09-15 21:19:01 --> UTF-8 Support Enabled
INFO - 2019-09-15 21:19:01 --> Utf8 Class Initialized
INFO - 2019-09-15 21:19:01 --> URI Class Initialized
INFO - 2019-09-15 21:19:01 --> Router Class Initialized
INFO - 2019-09-15 21:19:01 --> Output Class Initialized
INFO - 2019-09-15 21:19:01 --> Security Class Initialized
DEBUG - 2019-09-15 21:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 21:19:01 --> Input Class Initialized
INFO - 2019-09-15 21:19:01 --> Language Class Initialized
INFO - 2019-09-15 21:19:01 --> Loader Class Initialized
INFO - 2019-09-15 21:19:01 --> Helper loaded: url_helper
INFO - 2019-09-15 21:19:01 --> Helper loaded: html_helper
INFO - 2019-09-15 21:19:01 --> Helper loaded: form_helper
INFO - 2019-09-15 21:19:01 --> Helper loaded: cookie_helper
INFO - 2019-09-15 21:19:01 --> Helper loaded: date_helper
INFO - 2019-09-15 21:19:01 --> Form Validation Class Initialized
INFO - 2019-09-15 21:19:01 --> Email Class Initialized
DEBUG - 2019-09-15 21:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 21:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 21:19:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 21:19:01 --> Pagination Class Initialized
INFO - 2019-09-15 21:19:01 --> Database Driver Class Initialized
INFO - 2019-09-15 21:19:01 --> Database Driver Class Initialized
INFO - 2019-09-15 21:19:01 --> Controller Class Initialized
INFO - 2019-09-15 21:19:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-15 21:19:02 --> Config Class Initialized
INFO - 2019-09-15 21:19:02 --> Hooks Class Initialized
DEBUG - 2019-09-15 21:19:02 --> UTF-8 Support Enabled
INFO - 2019-09-15 21:19:02 --> Utf8 Class Initialized
INFO - 2019-09-15 21:19:02 --> URI Class Initialized
INFO - 2019-09-15 21:19:02 --> Router Class Initialized
INFO - 2019-09-15 21:19:02 --> Output Class Initialized
INFO - 2019-09-15 21:19:02 --> Security Class Initialized
DEBUG - 2019-09-15 21:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 21:19:02 --> Input Class Initialized
INFO - 2019-09-15 21:19:02 --> Language Class Initialized
INFO - 2019-09-15 21:19:02 --> Loader Class Initialized
INFO - 2019-09-15 21:19:02 --> Helper loaded: url_helper
INFO - 2019-09-15 21:19:02 --> Helper loaded: html_helper
INFO - 2019-09-15 21:19:02 --> Helper loaded: form_helper
INFO - 2019-09-15 21:19:02 --> Helper loaded: cookie_helper
INFO - 2019-09-15 21:19:02 --> Helper loaded: date_helper
INFO - 2019-09-15 21:19:02 --> Form Validation Class Initialized
INFO - 2019-09-15 21:19:02 --> Email Class Initialized
DEBUG - 2019-09-15 21:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 21:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 21:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 21:19:02 --> Pagination Class Initialized
INFO - 2019-09-15 21:19:02 --> Database Driver Class Initialized
INFO - 2019-09-15 21:19:02 --> Database Driver Class Initialized
INFO - 2019-09-15 21:19:02 --> Controller Class Initialized
INFO - 2019-09-15 21:19:02 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-15 21:19:02 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-15 21:19:02 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-15 21:19:02 --> Final output sent to browser
DEBUG - 2019-09-15 21:19:02 --> Total execution time: 0.1590
INFO - 2019-09-15 21:19:02 --> Config Class Initialized
INFO - 2019-09-15 21:19:02 --> Hooks Class Initialized
DEBUG - 2019-09-15 21:19:02 --> UTF-8 Support Enabled
INFO - 2019-09-15 21:19:02 --> Utf8 Class Initialized
INFO - 2019-09-15 21:19:02 --> URI Class Initialized
INFO - 2019-09-15 21:19:02 --> Router Class Initialized
INFO - 2019-09-15 21:19:02 --> Output Class Initialized
INFO - 2019-09-15 21:19:02 --> Security Class Initialized
DEBUG - 2019-09-15 21:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 21:19:02 --> Input Class Initialized
INFO - 2019-09-15 21:19:02 --> Language Class Initialized
INFO - 2019-09-15 21:19:02 --> Loader Class Initialized
INFO - 2019-09-15 21:19:02 --> Helper loaded: url_helper
INFO - 2019-09-15 21:19:02 --> Helper loaded: html_helper
INFO - 2019-09-15 21:19:02 --> Helper loaded: form_helper
INFO - 2019-09-15 21:19:02 --> Helper loaded: cookie_helper
INFO - 2019-09-15 21:19:02 --> Helper loaded: date_helper
INFO - 2019-09-15 21:19:02 --> Form Validation Class Initialized
INFO - 2019-09-15 21:19:02 --> Email Class Initialized
DEBUG - 2019-09-15 21:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 21:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 21:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 21:19:02 --> Pagination Class Initialized
INFO - 2019-09-15 21:19:03 --> Database Driver Class Initialized
INFO - 2019-09-15 21:19:03 --> Database Driver Class Initialized
INFO - 2019-09-15 21:19:03 --> Controller Class Initialized
INFO - 2019-09-15 21:19:03 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-15 21:19:03 --> Final output sent to browser
DEBUG - 2019-09-15 21:19:03 --> Total execution time: 0.3052
INFO - 2019-09-15 21:19:03 --> Config Class Initialized
INFO - 2019-09-15 21:19:03 --> Hooks Class Initialized
DEBUG - 2019-09-15 21:19:03 --> UTF-8 Support Enabled
INFO - 2019-09-15 21:19:03 --> Utf8 Class Initialized
INFO - 2019-09-15 21:19:03 --> URI Class Initialized
INFO - 2019-09-15 21:19:03 --> Router Class Initialized
INFO - 2019-09-15 21:19:03 --> Output Class Initialized
INFO - 2019-09-15 21:19:03 --> Security Class Initialized
DEBUG - 2019-09-15 21:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 21:19:03 --> Input Class Initialized
INFO - 2019-09-15 21:19:03 --> Language Class Initialized
INFO - 2019-09-15 21:19:03 --> Loader Class Initialized
INFO - 2019-09-15 21:19:03 --> Helper loaded: url_helper
INFO - 2019-09-15 21:19:03 --> Helper loaded: html_helper
INFO - 2019-09-15 21:19:03 --> Helper loaded: form_helper
INFO - 2019-09-15 21:19:03 --> Helper loaded: cookie_helper
INFO - 2019-09-15 21:19:03 --> Helper loaded: date_helper
INFO - 2019-09-15 21:19:03 --> Form Validation Class Initialized
INFO - 2019-09-15 21:19:03 --> Email Class Initialized
DEBUG - 2019-09-15 21:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 21:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 21:19:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 21:19:03 --> Pagination Class Initialized
INFO - 2019-09-15 21:19:03 --> Database Driver Class Initialized
INFO - 2019-09-15 21:19:03 --> Database Driver Class Initialized
INFO - 2019-09-15 21:19:03 --> Controller Class Initialized
INFO - 2019-09-15 21:19:03 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-15 21:19:03 --> Final output sent to browser
DEBUG - 2019-09-15 21:19:03 --> Total execution time: 0.0597
INFO - 2019-09-15 21:19:04 --> Config Class Initialized
INFO - 2019-09-15 21:19:04 --> Hooks Class Initialized
DEBUG - 2019-09-15 21:19:04 --> UTF-8 Support Enabled
INFO - 2019-09-15 21:19:04 --> Utf8 Class Initialized
INFO - 2019-09-15 21:19:04 --> URI Class Initialized
INFO - 2019-09-15 21:19:04 --> Router Class Initialized
INFO - 2019-09-15 21:19:04 --> Output Class Initialized
INFO - 2019-09-15 21:19:04 --> Security Class Initialized
DEBUG - 2019-09-15 21:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 21:19:04 --> Input Class Initialized
INFO - 2019-09-15 21:19:04 --> Language Class Initialized
INFO - 2019-09-15 21:19:04 --> Loader Class Initialized
INFO - 2019-09-15 21:19:04 --> Helper loaded: url_helper
INFO - 2019-09-15 21:19:04 --> Helper loaded: html_helper
INFO - 2019-09-15 21:19:04 --> Helper loaded: form_helper
INFO - 2019-09-15 21:19:04 --> Helper loaded: cookie_helper
INFO - 2019-09-15 21:19:04 --> Helper loaded: date_helper
INFO - 2019-09-15 21:19:04 --> Form Validation Class Initialized
INFO - 2019-09-15 21:19:04 --> Email Class Initialized
DEBUG - 2019-09-15 21:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 21:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 21:19:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 21:19:04 --> Pagination Class Initialized
INFO - 2019-09-15 21:19:04 --> Database Driver Class Initialized
INFO - 2019-09-15 21:19:04 --> Database Driver Class Initialized
INFO - 2019-09-15 21:19:04 --> Controller Class Initialized
INFO - 2019-09-15 21:19:04 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-15 21:19:04 --> Final output sent to browser
DEBUG - 2019-09-15 21:19:04 --> Total execution time: 0.0631
INFO - 2019-09-15 21:19:05 --> Config Class Initialized
INFO - 2019-09-15 21:19:05 --> Hooks Class Initialized
DEBUG - 2019-09-15 21:19:05 --> UTF-8 Support Enabled
INFO - 2019-09-15 21:19:05 --> Utf8 Class Initialized
INFO - 2019-09-15 21:19:05 --> URI Class Initialized
INFO - 2019-09-15 21:19:05 --> Router Class Initialized
INFO - 2019-09-15 21:19:05 --> Output Class Initialized
INFO - 2019-09-15 21:19:05 --> Security Class Initialized
DEBUG - 2019-09-15 21:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 21:19:05 --> Input Class Initialized
INFO - 2019-09-15 21:19:05 --> Language Class Initialized
INFO - 2019-09-15 21:19:05 --> Loader Class Initialized
INFO - 2019-09-15 21:19:05 --> Helper loaded: url_helper
INFO - 2019-09-15 21:19:05 --> Helper loaded: html_helper
INFO - 2019-09-15 21:19:05 --> Helper loaded: form_helper
INFO - 2019-09-15 21:19:05 --> Helper loaded: cookie_helper
INFO - 2019-09-15 21:19:05 --> Helper loaded: date_helper
INFO - 2019-09-15 21:19:05 --> Form Validation Class Initialized
INFO - 2019-09-15 21:19:05 --> Email Class Initialized
DEBUG - 2019-09-15 21:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 21:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 21:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 21:19:05 --> Pagination Class Initialized
INFO - 2019-09-15 21:19:05 --> Database Driver Class Initialized
INFO - 2019-09-15 21:19:05 --> Database Driver Class Initialized
INFO - 2019-09-15 21:19:05 --> Controller Class Initialized
INFO - 2019-09-15 21:19:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-15 21:19:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-15 21:19:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-15 21:19:05 --> Final output sent to browser
DEBUG - 2019-09-15 21:19:05 --> Total execution time: 0.1123
INFO - 2019-09-15 21:19:05 --> Config Class Initialized
INFO - 2019-09-15 21:19:05 --> Hooks Class Initialized
DEBUG - 2019-09-15 21:19:05 --> UTF-8 Support Enabled
INFO - 2019-09-15 21:19:05 --> Utf8 Class Initialized
INFO - 2019-09-15 21:19:05 --> URI Class Initialized
INFO - 2019-09-15 21:19:05 --> Router Class Initialized
INFO - 2019-09-15 21:19:05 --> Output Class Initialized
INFO - 2019-09-15 21:19:05 --> Security Class Initialized
DEBUG - 2019-09-15 21:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 21:19:05 --> Input Class Initialized
INFO - 2019-09-15 21:19:05 --> Language Class Initialized
INFO - 2019-09-15 21:19:05 --> Loader Class Initialized
INFO - 2019-09-15 21:19:05 --> Helper loaded: url_helper
INFO - 2019-09-15 21:19:05 --> Helper loaded: html_helper
INFO - 2019-09-15 21:19:05 --> Helper loaded: form_helper
INFO - 2019-09-15 21:19:05 --> Helper loaded: cookie_helper
INFO - 2019-09-15 21:19:05 --> Helper loaded: date_helper
INFO - 2019-09-15 21:19:05 --> Form Validation Class Initialized
INFO - 2019-09-15 21:19:05 --> Email Class Initialized
DEBUG - 2019-09-15 21:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 21:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 21:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 21:19:05 --> Pagination Class Initialized
INFO - 2019-09-15 21:19:05 --> Database Driver Class Initialized
INFO - 2019-09-15 21:19:05 --> Database Driver Class Initialized
INFO - 2019-09-15 21:19:05 --> Controller Class Initialized
INFO - 2019-09-15 21:19:06 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-15 21:19:06 --> Final output sent to browser
DEBUG - 2019-09-15 21:19:06 --> Total execution time: 0.0940
INFO - 2019-09-15 21:19:10 --> Config Class Initialized
INFO - 2019-09-15 21:19:10 --> Hooks Class Initialized
DEBUG - 2019-09-15 21:19:10 --> UTF-8 Support Enabled
INFO - 2019-09-15 21:19:10 --> Utf8 Class Initialized
INFO - 2019-09-15 21:19:10 --> URI Class Initialized
INFO - 2019-09-15 21:19:10 --> Router Class Initialized
INFO - 2019-09-15 21:19:10 --> Output Class Initialized
INFO - 2019-09-15 21:19:10 --> Security Class Initialized
DEBUG - 2019-09-15 21:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 21:19:10 --> Input Class Initialized
INFO - 2019-09-15 21:19:10 --> Language Class Initialized
INFO - 2019-09-15 21:19:10 --> Loader Class Initialized
INFO - 2019-09-15 21:19:10 --> Helper loaded: url_helper
INFO - 2019-09-15 21:19:10 --> Helper loaded: html_helper
INFO - 2019-09-15 21:19:10 --> Helper loaded: form_helper
INFO - 2019-09-15 21:19:10 --> Helper loaded: cookie_helper
INFO - 2019-09-15 21:19:10 --> Helper loaded: date_helper
INFO - 2019-09-15 21:19:10 --> Form Validation Class Initialized
INFO - 2019-09-15 21:19:10 --> Email Class Initialized
DEBUG - 2019-09-15 21:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 21:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 21:19:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 21:19:10 --> Pagination Class Initialized
INFO - 2019-09-15 21:19:10 --> Database Driver Class Initialized
INFO - 2019-09-15 21:19:10 --> Database Driver Class Initialized
INFO - 2019-09-15 21:19:10 --> Controller Class Initialized
INFO - 2019-09-15 21:21:35 --> Config Class Initialized
INFO - 2019-09-15 21:21:35 --> Hooks Class Initialized
DEBUG - 2019-09-15 21:21:35 --> UTF-8 Support Enabled
INFO - 2019-09-15 21:21:35 --> Utf8 Class Initialized
INFO - 2019-09-15 21:21:35 --> URI Class Initialized
INFO - 2019-09-15 21:21:35 --> Router Class Initialized
INFO - 2019-09-15 21:21:35 --> Output Class Initialized
INFO - 2019-09-15 21:21:35 --> Security Class Initialized
DEBUG - 2019-09-15 21:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 21:21:35 --> Input Class Initialized
INFO - 2019-09-15 21:21:35 --> Language Class Initialized
INFO - 2019-09-15 21:21:35 --> Loader Class Initialized
INFO - 2019-09-15 21:21:35 --> Helper loaded: url_helper
INFO - 2019-09-15 21:21:35 --> Helper loaded: html_helper
INFO - 2019-09-15 21:21:35 --> Helper loaded: form_helper
INFO - 2019-09-15 21:21:35 --> Helper loaded: cookie_helper
INFO - 2019-09-15 21:21:35 --> Helper loaded: date_helper
INFO - 2019-09-15 21:21:35 --> Form Validation Class Initialized
INFO - 2019-09-15 21:21:35 --> Email Class Initialized
DEBUG - 2019-09-15 21:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 21:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 21:21:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 21:21:35 --> Pagination Class Initialized
INFO - 2019-09-15 21:21:35 --> Database Driver Class Initialized
INFO - 2019-09-15 21:21:35 --> Database Driver Class Initialized
INFO - 2019-09-15 21:21:35 --> Controller Class Initialized
INFO - 2019-09-15 21:21:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-15 21:21:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report.php
INFO - 2019-09-15 21:21:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-15 21:21:36 --> Final output sent to browser
DEBUG - 2019-09-15 21:21:36 --> Total execution time: 0.0896
INFO - 2019-09-15 21:22:05 --> Config Class Initialized
INFO - 2019-09-15 21:22:05 --> Hooks Class Initialized
DEBUG - 2019-09-15 21:22:05 --> UTF-8 Support Enabled
INFO - 2019-09-15 21:22:05 --> Utf8 Class Initialized
INFO - 2019-09-15 21:22:05 --> URI Class Initialized
INFO - 2019-09-15 21:22:05 --> Router Class Initialized
INFO - 2019-09-15 21:22:05 --> Output Class Initialized
INFO - 2019-09-15 21:22:05 --> Security Class Initialized
DEBUG - 2019-09-15 21:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 21:22:05 --> Input Class Initialized
INFO - 2019-09-15 21:22:05 --> Language Class Initialized
INFO - 2019-09-15 21:22:05 --> Loader Class Initialized
INFO - 2019-09-15 21:22:05 --> Helper loaded: url_helper
INFO - 2019-09-15 21:22:05 --> Helper loaded: html_helper
INFO - 2019-09-15 21:22:05 --> Helper loaded: form_helper
INFO - 2019-09-15 21:22:05 --> Helper loaded: cookie_helper
INFO - 2019-09-15 21:22:05 --> Helper loaded: date_helper
INFO - 2019-09-15 21:22:06 --> Form Validation Class Initialized
INFO - 2019-09-15 21:22:06 --> Email Class Initialized
DEBUG - 2019-09-15 21:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 21:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 21:22:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 21:22:06 --> Pagination Class Initialized
INFO - 2019-09-15 21:22:06 --> Database Driver Class Initialized
INFO - 2019-09-15 21:22:06 --> Database Driver Class Initialized
INFO - 2019-09-15 21:22:06 --> Controller Class Initialized
INFO - 2019-09-15 23:33:56 --> Config Class Initialized
INFO - 2019-09-15 23:33:56 --> Hooks Class Initialized
DEBUG - 2019-09-15 23:33:56 --> UTF-8 Support Enabled
INFO - 2019-09-15 23:33:56 --> Utf8 Class Initialized
INFO - 2019-09-15 23:33:56 --> URI Class Initialized
INFO - 2019-09-15 23:33:56 --> Router Class Initialized
INFO - 2019-09-15 23:33:56 --> Output Class Initialized
INFO - 2019-09-15 23:33:56 --> Security Class Initialized
DEBUG - 2019-09-15 23:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 23:33:56 --> Input Class Initialized
INFO - 2019-09-15 23:33:56 --> Language Class Initialized
INFO - 2019-09-15 23:33:56 --> Loader Class Initialized
INFO - 2019-09-15 23:33:56 --> Helper loaded: url_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: html_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: form_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: cookie_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: date_helper
INFO - 2019-09-15 23:33:56 --> Form Validation Class Initialized
INFO - 2019-09-15 23:33:56 --> Email Class Initialized
DEBUG - 2019-09-15 23:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 23:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 23:33:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 23:33:56 --> Pagination Class Initialized
INFO - 2019-09-15 23:33:56 --> Database Driver Class Initialized
INFO - 2019-09-15 23:33:56 --> Database Driver Class Initialized
INFO - 2019-09-15 23:33:56 --> Controller Class Initialized
DEBUG - 2019-09-15 23:33:56 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 23:33:56 --> Helper loaded: inflector_helper
INFO - 2019-09-15 23:33:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 23:33:56 --> Final output sent to browser
DEBUG - 2019-09-15 23:33:56 --> Total execution time: 0.1963
INFO - 2019-09-15 23:33:56 --> Config Class Initialized
INFO - 2019-09-15 23:33:56 --> Hooks Class Initialized
DEBUG - 2019-09-15 23:33:56 --> UTF-8 Support Enabled
INFO - 2019-09-15 23:33:56 --> Utf8 Class Initialized
INFO - 2019-09-15 23:33:56 --> URI Class Initialized
INFO - 2019-09-15 23:33:56 --> Router Class Initialized
INFO - 2019-09-15 23:33:56 --> Output Class Initialized
INFO - 2019-09-15 23:33:56 --> Security Class Initialized
DEBUG - 2019-09-15 23:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 23:33:56 --> Input Class Initialized
INFO - 2019-09-15 23:33:56 --> Language Class Initialized
INFO - 2019-09-15 23:33:56 --> Loader Class Initialized
INFO - 2019-09-15 23:33:56 --> Helper loaded: url_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: html_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: form_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: cookie_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: date_helper
INFO - 2019-09-15 23:33:56 --> Form Validation Class Initialized
INFO - 2019-09-15 23:33:56 --> Email Class Initialized
DEBUG - 2019-09-15 23:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 23:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 23:33:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 23:33:56 --> Pagination Class Initialized
INFO - 2019-09-15 23:33:56 --> Database Driver Class Initialized
INFO - 2019-09-15 23:33:56 --> Database Driver Class Initialized
INFO - 2019-09-15 23:33:56 --> Controller Class Initialized
DEBUG - 2019-09-15 23:33:56 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 23:33:56 --> Helper loaded: inflector_helper
INFO - 2019-09-15 23:33:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 23:33:56 --> Final output sent to browser
DEBUG - 2019-09-15 23:33:56 --> Total execution time: 0.0950
INFO - 2019-09-15 23:33:56 --> Config Class Initialized
INFO - 2019-09-15 23:33:56 --> Hooks Class Initialized
DEBUG - 2019-09-15 23:33:56 --> UTF-8 Support Enabled
INFO - 2019-09-15 23:33:56 --> Utf8 Class Initialized
INFO - 2019-09-15 23:33:56 --> URI Class Initialized
INFO - 2019-09-15 23:33:56 --> Router Class Initialized
INFO - 2019-09-15 23:33:56 --> Output Class Initialized
INFO - 2019-09-15 23:33:56 --> Security Class Initialized
DEBUG - 2019-09-15 23:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 23:33:56 --> Input Class Initialized
INFO - 2019-09-15 23:33:56 --> Language Class Initialized
INFO - 2019-09-15 23:33:56 --> Loader Class Initialized
INFO - 2019-09-15 23:33:56 --> Helper loaded: url_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: html_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: form_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: cookie_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: date_helper
INFO - 2019-09-15 23:33:56 --> Form Validation Class Initialized
INFO - 2019-09-15 23:33:56 --> Email Class Initialized
DEBUG - 2019-09-15 23:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 23:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 23:33:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 23:33:56 --> Pagination Class Initialized
INFO - 2019-09-15 23:33:56 --> Database Driver Class Initialized
INFO - 2019-09-15 23:33:56 --> Database Driver Class Initialized
INFO - 2019-09-15 23:33:56 --> Controller Class Initialized
DEBUG - 2019-09-15 23:33:56 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 23:33:56 --> Helper loaded: inflector_helper
INFO - 2019-09-15 23:33:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 23:33:56 --> Final output sent to browser
DEBUG - 2019-09-15 23:33:56 --> Total execution time: 0.2347
INFO - 2019-09-15 23:33:56 --> Config Class Initialized
INFO - 2019-09-15 23:33:56 --> Hooks Class Initialized
DEBUG - 2019-09-15 23:33:56 --> UTF-8 Support Enabled
INFO - 2019-09-15 23:33:56 --> Utf8 Class Initialized
INFO - 2019-09-15 23:33:56 --> URI Class Initialized
INFO - 2019-09-15 23:33:56 --> Router Class Initialized
INFO - 2019-09-15 23:33:56 --> Output Class Initialized
INFO - 2019-09-15 23:33:56 --> Security Class Initialized
DEBUG - 2019-09-15 23:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 23:33:56 --> Input Class Initialized
INFO - 2019-09-15 23:33:56 --> Language Class Initialized
INFO - 2019-09-15 23:33:56 --> Loader Class Initialized
INFO - 2019-09-15 23:33:56 --> Helper loaded: url_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: html_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: form_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: cookie_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: date_helper
INFO - 2019-09-15 23:33:56 --> Form Validation Class Initialized
INFO - 2019-09-15 23:33:56 --> Email Class Initialized
DEBUG - 2019-09-15 23:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 23:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 23:33:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 23:33:56 --> Pagination Class Initialized
INFO - 2019-09-15 23:33:56 --> Database Driver Class Initialized
INFO - 2019-09-15 23:33:56 --> Database Driver Class Initialized
INFO - 2019-09-15 23:33:56 --> Controller Class Initialized
DEBUG - 2019-09-15 23:33:56 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 23:33:56 --> Helper loaded: inflector_helper
INFO - 2019-09-15 23:33:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 23:33:56 --> Final output sent to browser
DEBUG - 2019-09-15 23:33:56 --> Total execution time: 0.1083
INFO - 2019-09-15 23:33:56 --> Config Class Initialized
INFO - 2019-09-15 23:33:56 --> Hooks Class Initialized
DEBUG - 2019-09-15 23:33:56 --> UTF-8 Support Enabled
INFO - 2019-09-15 23:33:56 --> Utf8 Class Initialized
INFO - 2019-09-15 23:33:56 --> URI Class Initialized
INFO - 2019-09-15 23:33:56 --> Router Class Initialized
INFO - 2019-09-15 23:33:56 --> Output Class Initialized
INFO - 2019-09-15 23:33:56 --> Security Class Initialized
DEBUG - 2019-09-15 23:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 23:33:56 --> Input Class Initialized
INFO - 2019-09-15 23:33:56 --> Language Class Initialized
INFO - 2019-09-15 23:33:56 --> Loader Class Initialized
INFO - 2019-09-15 23:33:56 --> Helper loaded: url_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: html_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: form_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: cookie_helper
INFO - 2019-09-15 23:33:56 --> Helper loaded: date_helper
INFO - 2019-09-15 23:33:56 --> Form Validation Class Initialized
INFO - 2019-09-15 23:33:56 --> Email Class Initialized
DEBUG - 2019-09-15 23:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 23:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 23:33:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 23:33:56 --> Pagination Class Initialized
INFO - 2019-09-15 23:33:56 --> Database Driver Class Initialized
INFO - 2019-09-15 23:33:56 --> Database Driver Class Initialized
INFO - 2019-09-15 23:33:56 --> Controller Class Initialized
DEBUG - 2019-09-15 23:33:56 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 23:33:56 --> Helper loaded: inflector_helper
INFO - 2019-09-15 23:33:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 23:33:56 --> Final output sent to browser
DEBUG - 2019-09-15 23:33:56 --> Total execution time: 0.0419
INFO - 2019-09-15 23:36:13 --> Config Class Initialized
INFO - 2019-09-15 23:36:13 --> Hooks Class Initialized
DEBUG - 2019-09-15 23:36:13 --> UTF-8 Support Enabled
INFO - 2019-09-15 23:36:13 --> Utf8 Class Initialized
INFO - 2019-09-15 23:36:13 --> URI Class Initialized
INFO - 2019-09-15 23:36:13 --> Router Class Initialized
INFO - 2019-09-15 23:36:13 --> Output Class Initialized
INFO - 2019-09-15 23:36:13 --> Security Class Initialized
DEBUG - 2019-09-15 23:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 23:36:13 --> Input Class Initialized
INFO - 2019-09-15 23:36:13 --> Language Class Initialized
INFO - 2019-09-15 23:36:13 --> Loader Class Initialized
INFO - 2019-09-15 23:36:13 --> Helper loaded: url_helper
INFO - 2019-09-15 23:36:13 --> Helper loaded: html_helper
INFO - 2019-09-15 23:36:13 --> Helper loaded: form_helper
INFO - 2019-09-15 23:36:13 --> Helper loaded: cookie_helper
INFO - 2019-09-15 23:36:13 --> Helper loaded: date_helper
INFO - 2019-09-15 23:36:13 --> Form Validation Class Initialized
INFO - 2019-09-15 23:36:13 --> Email Class Initialized
DEBUG - 2019-09-15 23:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 23:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 23:36:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 23:36:13 --> Pagination Class Initialized
INFO - 2019-09-15 23:36:13 --> Database Driver Class Initialized
INFO - 2019-09-15 23:36:13 --> Database Driver Class Initialized
INFO - 2019-09-15 23:36:13 --> Controller Class Initialized
DEBUG - 2019-09-15 23:36:13 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 23:36:13 --> Helper loaded: inflector_helper
INFO - 2019-09-15 23:36:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 23:36:13 --> Final output sent to browser
DEBUG - 2019-09-15 23:36:13 --> Total execution time: 0.0794
INFO - 2019-09-15 23:36:45 --> Config Class Initialized
INFO - 2019-09-15 23:36:45 --> Hooks Class Initialized
DEBUG - 2019-09-15 23:36:45 --> UTF-8 Support Enabled
INFO - 2019-09-15 23:36:45 --> Utf8 Class Initialized
INFO - 2019-09-15 23:36:45 --> URI Class Initialized
INFO - 2019-09-15 23:36:45 --> Router Class Initialized
INFO - 2019-09-15 23:36:45 --> Output Class Initialized
INFO - 2019-09-15 23:36:45 --> Security Class Initialized
DEBUG - 2019-09-15 23:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 23:36:45 --> Input Class Initialized
INFO - 2019-09-15 23:36:45 --> Language Class Initialized
INFO - 2019-09-15 23:36:45 --> Loader Class Initialized
INFO - 2019-09-15 23:36:45 --> Helper loaded: url_helper
INFO - 2019-09-15 23:36:45 --> Helper loaded: html_helper
INFO - 2019-09-15 23:36:45 --> Helper loaded: form_helper
INFO - 2019-09-15 23:36:45 --> Helper loaded: cookie_helper
INFO - 2019-09-15 23:36:45 --> Helper loaded: date_helper
INFO - 2019-09-15 23:36:45 --> Form Validation Class Initialized
INFO - 2019-09-15 23:36:45 --> Email Class Initialized
DEBUG - 2019-09-15 23:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 23:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 23:36:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 23:36:45 --> Pagination Class Initialized
INFO - 2019-09-15 23:36:45 --> Database Driver Class Initialized
INFO - 2019-09-15 23:36:45 --> Database Driver Class Initialized
INFO - 2019-09-15 23:36:45 --> Controller Class Initialized
DEBUG - 2019-09-15 23:36:45 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 23:36:45 --> Helper loaded: inflector_helper
INFO - 2019-09-15 23:36:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 23:36:45 --> Final output sent to browser
DEBUG - 2019-09-15 23:36:45 --> Total execution time: 0.0442
INFO - 2019-09-15 23:37:13 --> Config Class Initialized
INFO - 2019-09-15 23:37:13 --> Hooks Class Initialized
DEBUG - 2019-09-15 23:37:13 --> UTF-8 Support Enabled
INFO - 2019-09-15 23:37:13 --> Utf8 Class Initialized
INFO - 2019-09-15 23:37:13 --> URI Class Initialized
INFO - 2019-09-15 23:37:13 --> Router Class Initialized
INFO - 2019-09-15 23:37:13 --> Output Class Initialized
INFO - 2019-09-15 23:37:13 --> Security Class Initialized
DEBUG - 2019-09-15 23:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 23:37:13 --> Input Class Initialized
INFO - 2019-09-15 23:37:13 --> Language Class Initialized
INFO - 2019-09-15 23:37:13 --> Loader Class Initialized
INFO - 2019-09-15 23:37:13 --> Helper loaded: url_helper
INFO - 2019-09-15 23:37:13 --> Helper loaded: html_helper
INFO - 2019-09-15 23:37:13 --> Helper loaded: form_helper
INFO - 2019-09-15 23:37:13 --> Helper loaded: cookie_helper
INFO - 2019-09-15 23:37:13 --> Helper loaded: date_helper
INFO - 2019-09-15 23:37:13 --> Form Validation Class Initialized
INFO - 2019-09-15 23:37:13 --> Email Class Initialized
DEBUG - 2019-09-15 23:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 23:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 23:37:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 23:37:13 --> Pagination Class Initialized
INFO - 2019-09-15 23:37:13 --> Database Driver Class Initialized
INFO - 2019-09-15 23:37:13 --> Database Driver Class Initialized
INFO - 2019-09-15 23:37:13 --> Controller Class Initialized
DEBUG - 2019-09-15 23:37:13 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 23:37:13 --> Helper loaded: inflector_helper
INFO - 2019-09-15 23:37:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 23:37:13 --> Final output sent to browser
DEBUG - 2019-09-15 23:37:13 --> Total execution time: 0.0592
INFO - 2019-09-15 23:38:47 --> Config Class Initialized
INFO - 2019-09-15 23:38:47 --> Hooks Class Initialized
DEBUG - 2019-09-15 23:38:47 --> UTF-8 Support Enabled
INFO - 2019-09-15 23:38:47 --> Utf8 Class Initialized
INFO - 2019-09-15 23:38:47 --> URI Class Initialized
INFO - 2019-09-15 23:38:47 --> Router Class Initialized
INFO - 2019-09-15 23:38:47 --> Output Class Initialized
INFO - 2019-09-15 23:38:47 --> Security Class Initialized
DEBUG - 2019-09-15 23:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-15 23:38:47 --> Input Class Initialized
INFO - 2019-09-15 23:38:47 --> Language Class Initialized
INFO - 2019-09-15 23:38:47 --> Loader Class Initialized
INFO - 2019-09-15 23:38:47 --> Helper loaded: url_helper
INFO - 2019-09-15 23:38:47 --> Helper loaded: html_helper
INFO - 2019-09-15 23:38:47 --> Helper loaded: form_helper
INFO - 2019-09-15 23:38:47 --> Helper loaded: cookie_helper
INFO - 2019-09-15 23:38:47 --> Helper loaded: date_helper
INFO - 2019-09-15 23:38:47 --> Form Validation Class Initialized
INFO - 2019-09-15 23:38:47 --> Email Class Initialized
DEBUG - 2019-09-15 23:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-15 23:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-15 23:38:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-15 23:38:47 --> Pagination Class Initialized
INFO - 2019-09-15 23:38:47 --> Database Driver Class Initialized
INFO - 2019-09-15 23:38:47 --> Database Driver Class Initialized
INFO - 2019-09-15 23:38:47 --> Controller Class Initialized
DEBUG - 2019-09-15 23:38:47 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-15 23:38:47 --> Helper loaded: inflector_helper
INFO - 2019-09-15 23:38:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-15 23:38:47 --> Final output sent to browser
DEBUG - 2019-09-15 23:38:47 --> Total execution time: 0.0456
