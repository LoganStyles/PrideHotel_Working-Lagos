<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-12-04 07:59:14 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-12-04 07:59:14 --> Config Class Initialized
INFO - 2018-12-04 07:59:14 --> Hooks Class Initialized
INFO - 2018-12-04 07:59:14 --> Hooks Class Initialized
DEBUG - 2018-12-04 07:59:14 --> UTF-8 Support Enabled
DEBUG - 2018-12-04 07:59:14 --> UTF-8 Support Enabled
INFO - 2018-12-04 07:59:14 --> Utf8 Class Initialized
INFO - 2018-12-04 07:59:14 --> Utf8 Class Initialized
INFO - 2018-12-04 07:59:14 --> URI Class Initialized
INFO - 2018-12-04 07:59:14 --> URI Class Initialized
INFO - 2018-12-04 07:59:14 --> Router Class Initialized
INFO - 2018-12-04 07:59:14 --> Router Class Initialized
INFO - 2018-12-04 07:59:14 --> Output Class Initialized
INFO - 2018-12-04 07:59:14 --> Output Class Initialized
INFO - 2018-12-04 07:59:14 --> Security Class Initialized
INFO - 2018-12-04 07:59:14 --> Security Class Initialized
DEBUG - 2018-12-04 07:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-12-04 07:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-04 07:59:14 --> Input Class Initialized
INFO - 2018-12-04 07:59:14 --> Input Class Initialized
INFO - 2018-12-04 07:59:14 --> Language Class Initialized
INFO - 2018-12-04 07:59:14 --> Language Class Initialized
INFO - 2018-12-04 07:59:14 --> Loader Class Initialized
INFO - 2018-12-04 07:59:14 --> Loader Class Initialized
INFO - 2018-12-04 07:59:14 --> Helper loaded: url_helper
INFO - 2018-12-04 07:59:14 --> Helper loaded: url_helper
INFO - 2018-12-04 07:59:14 --> Helper loaded: html_helper
INFO - 2018-12-04 07:59:14 --> Helper loaded: html_helper
INFO - 2018-12-04 07:59:14 --> Helper loaded: form_helper
INFO - 2018-12-04 07:59:14 --> Helper loaded: form_helper
INFO - 2018-12-04 07:59:14 --> Helper loaded: cookie_helper
INFO - 2018-12-04 07:59:14 --> Helper loaded: cookie_helper
INFO - 2018-12-04 07:59:14 --> Helper loaded: date_helper
INFO - 2018-12-04 07:59:14 --> Helper loaded: date_helper
INFO - 2018-12-04 07:59:14 --> Form Validation Class Initialized
INFO - 2018-12-04 07:59:14 --> Form Validation Class Initialized
INFO - 2018-12-04 07:59:14 --> Email Class Initialized
INFO - 2018-12-04 07:59:14 --> Email Class Initialized
DEBUG - 2018-12-04 07:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-12-04 07:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-04 07:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-04 07:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-04 07:59:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-04 07:59:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-04 07:59:14 --> Pagination Class Initialized
INFO - 2018-12-04 07:59:14 --> Pagination Class Initialized
INFO - 2018-12-04 07:59:14 --> Database Driver Class Initialized
INFO - 2018-12-04 07:59:14 --> Database Driver Class Initialized
INFO - 2018-12-04 07:59:14 --> Database Driver Class Initialized
INFO - 2018-12-04 07:59:14 --> Database Driver Class Initialized
INFO - 2018-12-04 07:59:14 --> Controller Class Initialized
INFO - 2018-12-04 07:59:14 --> Controller Class Initialized
INFO - 2018-12-04 07:59:14 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-04 07:59:14 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-04 07:59:14 --> Final output sent to browser
INFO - 2018-12-04 07:59:14 --> Final output sent to browser
DEBUG - 2018-12-04 07:59:14 --> Total execution time: 0.6033
DEBUG - 2018-12-04 07:59:14 --> Total execution time: 0.6033
INFO - 2018-12-04 10:00:13 --> Config Class Initialized
INFO - 2018-12-04 10:00:13 --> Hooks Class Initialized
DEBUG - 2018-12-04 10:00:14 --> UTF-8 Support Enabled
INFO - 2018-12-04 10:00:14 --> Utf8 Class Initialized
INFO - 2018-12-04 10:00:14 --> URI Class Initialized
INFO - 2018-12-04 10:00:14 --> Router Class Initialized
INFO - 2018-12-04 10:00:14 --> Output Class Initialized
INFO - 2018-12-04 10:00:14 --> Security Class Initialized
DEBUG - 2018-12-04 10:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-04 10:00:14 --> Input Class Initialized
INFO - 2018-12-04 10:00:14 --> Language Class Initialized
INFO - 2018-12-04 10:00:14 --> Loader Class Initialized
INFO - 2018-12-04 10:00:14 --> Helper loaded: url_helper
INFO - 2018-12-04 10:00:14 --> Helper loaded: html_helper
INFO - 2018-12-04 10:00:14 --> Helper loaded: form_helper
INFO - 2018-12-04 10:00:14 --> Helper loaded: cookie_helper
INFO - 2018-12-04 10:00:14 --> Helper loaded: date_helper
INFO - 2018-12-04 10:00:14 --> Form Validation Class Initialized
INFO - 2018-12-04 10:00:14 --> Email Class Initialized
DEBUG - 2018-12-04 10:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-04 10:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-04 10:00:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-04 10:00:14 --> Pagination Class Initialized
INFO - 2018-12-04 10:00:14 --> Database Driver Class Initialized
INFO - 2018-12-04 10:00:14 --> Database Driver Class Initialized
INFO - 2018-12-04 10:00:14 --> Controller Class Initialized
INFO - 2018-12-04 10:00:14 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-12-04 10:00:14 --> Final output sent to browser
DEBUG - 2018-12-04 10:00:14 --> Total execution time: 1.0321
INFO - 2018-12-04 10:00:19 --> Config Class Initialized
INFO - 2018-12-04 10:00:19 --> Hooks Class Initialized
DEBUG - 2018-12-04 10:00:19 --> UTF-8 Support Enabled
INFO - 2018-12-04 10:00:19 --> Utf8 Class Initialized
INFO - 2018-12-04 10:00:19 --> URI Class Initialized
INFO - 2018-12-04 10:00:19 --> Router Class Initialized
INFO - 2018-12-04 10:00:19 --> Output Class Initialized
INFO - 2018-12-04 10:00:19 --> Security Class Initialized
DEBUG - 2018-12-04 10:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-04 10:00:19 --> Input Class Initialized
INFO - 2018-12-04 10:00:19 --> Language Class Initialized
INFO - 2018-12-04 10:00:19 --> Loader Class Initialized
INFO - 2018-12-04 10:00:19 --> Helper loaded: url_helper
INFO - 2018-12-04 10:00:19 --> Helper loaded: html_helper
INFO - 2018-12-04 10:00:19 --> Helper loaded: form_helper
INFO - 2018-12-04 10:00:19 --> Helper loaded: cookie_helper
INFO - 2018-12-04 10:00:19 --> Helper loaded: date_helper
INFO - 2018-12-04 10:00:19 --> Form Validation Class Initialized
INFO - 2018-12-04 10:00:19 --> Email Class Initialized
DEBUG - 2018-12-04 10:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-04 10:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-04 10:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-04 10:00:19 --> Pagination Class Initialized
INFO - 2018-12-04 10:00:19 --> Database Driver Class Initialized
INFO - 2018-12-04 10:00:19 --> Database Driver Class Initialized
INFO - 2018-12-04 10:00:19 --> Controller Class Initialized
INFO - 2018-12-04 10:00:20 --> Config Class Initialized
INFO - 2018-12-04 10:00:20 --> Hooks Class Initialized
DEBUG - 2018-12-04 10:00:20 --> UTF-8 Support Enabled
INFO - 2018-12-04 10:00:20 --> Utf8 Class Initialized
INFO - 2018-12-04 10:00:20 --> URI Class Initialized
INFO - 2018-12-04 10:00:20 --> Router Class Initialized
INFO - 2018-12-04 10:00:20 --> Output Class Initialized
INFO - 2018-12-04 10:00:20 --> Security Class Initialized
DEBUG - 2018-12-04 10:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-04 10:00:20 --> Input Class Initialized
INFO - 2018-12-04 10:00:20 --> Language Class Initialized
INFO - 2018-12-04 10:00:20 --> Loader Class Initialized
INFO - 2018-12-04 10:00:20 --> Helper loaded: url_helper
INFO - 2018-12-04 10:00:20 --> Helper loaded: html_helper
INFO - 2018-12-04 10:00:20 --> Helper loaded: form_helper
INFO - 2018-12-04 10:00:20 --> Helper loaded: cookie_helper
INFO - 2018-12-04 10:00:20 --> Helper loaded: date_helper
INFO - 2018-12-04 10:00:20 --> Form Validation Class Initialized
INFO - 2018-12-04 10:00:20 --> Email Class Initialized
DEBUG - 2018-12-04 10:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-04 10:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-04 10:00:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-04 10:00:20 --> Pagination Class Initialized
INFO - 2018-12-04 10:00:20 --> Database Driver Class Initialized
INFO - 2018-12-04 10:00:20 --> Database Driver Class Initialized
INFO - 2018-12-04 10:00:20 --> Controller Class Initialized
INFO - 2018-12-04 10:00:20 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-12-04 10:00:20 --> Final output sent to browser
DEBUG - 2018-12-04 10:00:20 --> Total execution time: 0.1105
INFO - 2018-12-04 19:55:59 --> Config Class Initialized
INFO - 2018-12-04 19:55:59 --> Hooks Class Initialized
DEBUG - 2018-12-04 19:55:59 --> UTF-8 Support Enabled
INFO - 2018-12-04 19:55:59 --> Utf8 Class Initialized
INFO - 2018-12-04 19:55:59 --> URI Class Initialized
INFO - 2018-12-04 19:55:59 --> Router Class Initialized
INFO - 2018-12-04 19:55:59 --> Output Class Initialized
INFO - 2018-12-04 19:55:59 --> Security Class Initialized
DEBUG - 2018-12-04 19:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-04 19:55:59 --> Input Class Initialized
INFO - 2018-12-04 19:55:59 --> Language Class Initialized
INFO - 2018-12-04 19:55:59 --> Loader Class Initialized
INFO - 2018-12-04 19:55:59 --> Helper loaded: url_helper
INFO - 2018-12-04 19:55:59 --> Helper loaded: html_helper
INFO - 2018-12-04 19:55:59 --> Helper loaded: form_helper
INFO - 2018-12-04 19:55:59 --> Helper loaded: cookie_helper
INFO - 2018-12-04 19:55:59 --> Helper loaded: date_helper
INFO - 2018-12-04 19:55:59 --> Form Validation Class Initialized
INFO - 2018-12-04 19:55:59 --> Email Class Initialized
DEBUG - 2018-12-04 19:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-04 19:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-04 19:55:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-04 19:55:59 --> Pagination Class Initialized
INFO - 2018-12-04 19:55:59 --> Database Driver Class Initialized
INFO - 2018-12-04 19:55:59 --> Database Driver Class Initialized
INFO - 2018-12-04 19:55:59 --> Controller Class Initialized
INFO - 2018-12-04 19:55:59 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-04 19:55:59 --> Final output sent to browser
DEBUG - 2018-12-04 19:55:59 --> Total execution time: 0.0665
INFO - 2018-12-04 19:55:59 --> Config Class Initialized
INFO - 2018-12-04 19:55:59 --> Hooks Class Initialized
DEBUG - 2018-12-04 19:55:59 --> UTF-8 Support Enabled
INFO - 2018-12-04 19:55:59 --> Utf8 Class Initialized
INFO - 2018-12-04 19:55:59 --> URI Class Initialized
INFO - 2018-12-04 19:55:59 --> Router Class Initialized
INFO - 2018-12-04 19:55:59 --> Output Class Initialized
INFO - 2018-12-04 19:55:59 --> Security Class Initialized
DEBUG - 2018-12-04 19:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-04 19:55:59 --> Input Class Initialized
INFO - 2018-12-04 19:55:59 --> Language Class Initialized
INFO - 2018-12-04 19:55:59 --> Loader Class Initialized
INFO - 2018-12-04 19:55:59 --> Helper loaded: url_helper
INFO - 2018-12-04 19:55:59 --> Helper loaded: html_helper
INFO - 2018-12-04 19:55:59 --> Helper loaded: form_helper
INFO - 2018-12-04 19:55:59 --> Helper loaded: cookie_helper
INFO - 2018-12-04 19:55:59 --> Helper loaded: date_helper
INFO - 2018-12-04 19:56:00 --> Form Validation Class Initialized
INFO - 2018-12-04 19:56:00 --> Email Class Initialized
DEBUG - 2018-12-04 19:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-04 19:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-04 19:56:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-04 19:56:00 --> Pagination Class Initialized
INFO - 2018-12-04 19:56:00 --> Database Driver Class Initialized
INFO - 2018-12-04 19:56:00 --> Database Driver Class Initialized
INFO - 2018-12-04 19:56:00 --> Controller Class Initialized
INFO - 2018-12-04 19:56:00 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-04 19:56:00 --> Final output sent to browser
DEBUG - 2018-12-04 19:56:00 --> Total execution time: 0.0582
INFO - 2018-12-04 19:56:04 --> Config Class Initialized
INFO - 2018-12-04 19:56:04 --> Hooks Class Initialized
DEBUG - 2018-12-04 19:56:04 --> UTF-8 Support Enabled
INFO - 2018-12-04 19:56:04 --> Utf8 Class Initialized
INFO - 2018-12-04 19:56:04 --> URI Class Initialized
INFO - 2018-12-04 19:56:04 --> Router Class Initialized
INFO - 2018-12-04 19:56:04 --> Output Class Initialized
INFO - 2018-12-04 19:56:04 --> Security Class Initialized
DEBUG - 2018-12-04 19:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-04 19:56:04 --> Input Class Initialized
INFO - 2018-12-04 19:56:04 --> Language Class Initialized
INFO - 2018-12-04 19:56:04 --> Loader Class Initialized
INFO - 2018-12-04 19:56:04 --> Helper loaded: url_helper
INFO - 2018-12-04 19:56:04 --> Helper loaded: html_helper
INFO - 2018-12-04 19:56:04 --> Helper loaded: form_helper
INFO - 2018-12-04 19:56:04 --> Helper loaded: cookie_helper
INFO - 2018-12-04 19:56:04 --> Helper loaded: date_helper
INFO - 2018-12-04 19:56:04 --> Form Validation Class Initialized
INFO - 2018-12-04 19:56:04 --> Email Class Initialized
DEBUG - 2018-12-04 19:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-04 19:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-04 19:56:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-04 19:56:04 --> Pagination Class Initialized
INFO - 2018-12-04 19:56:04 --> Database Driver Class Initialized
INFO - 2018-12-04 19:56:04 --> Database Driver Class Initialized
INFO - 2018-12-04 19:56:04 --> Controller Class Initialized
INFO - 2018-12-04 19:56:04 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-04 19:56:04 --> Final output sent to browser
DEBUG - 2018-12-04 19:56:04 --> Total execution time: 0.0616
INFO - 2018-12-04 19:56:04 --> Config Class Initialized
INFO - 2018-12-04 19:56:04 --> Hooks Class Initialized
DEBUG - 2018-12-04 19:56:04 --> UTF-8 Support Enabled
INFO - 2018-12-04 19:56:04 --> Utf8 Class Initialized
INFO - 2018-12-04 19:56:04 --> URI Class Initialized
INFO - 2018-12-04 19:56:04 --> Router Class Initialized
INFO - 2018-12-04 19:56:04 --> Output Class Initialized
INFO - 2018-12-04 19:56:04 --> Security Class Initialized
DEBUG - 2018-12-04 19:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-04 19:56:04 --> Input Class Initialized
INFO - 2018-12-04 19:56:04 --> Language Class Initialized
INFO - 2018-12-04 19:56:04 --> Loader Class Initialized
INFO - 2018-12-04 19:56:04 --> Helper loaded: url_helper
INFO - 2018-12-04 19:56:04 --> Helper loaded: html_helper
INFO - 2018-12-04 19:56:04 --> Helper loaded: form_helper
INFO - 2018-12-04 19:56:04 --> Helper loaded: cookie_helper
INFO - 2018-12-04 19:56:04 --> Helper loaded: date_helper
INFO - 2018-12-04 19:56:04 --> Form Validation Class Initialized
INFO - 2018-12-04 19:56:04 --> Email Class Initialized
DEBUG - 2018-12-04 19:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-04 19:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-04 19:56:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-04 19:56:04 --> Pagination Class Initialized
INFO - 2018-12-04 19:56:04 --> Database Driver Class Initialized
INFO - 2018-12-04 19:56:04 --> Database Driver Class Initialized
INFO - 2018-12-04 19:56:04 --> Controller Class Initialized
INFO - 2018-12-04 19:56:04 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-04 19:56:04 --> Final output sent to browser
DEBUG - 2018-12-04 19:56:04 --> Total execution time: 0.0626
INFO - 2018-12-04 20:00:50 --> Config Class Initialized
INFO - 2018-12-04 20:00:50 --> Hooks Class Initialized
DEBUG - 2018-12-04 20:00:50 --> UTF-8 Support Enabled
INFO - 2018-12-04 20:00:50 --> Utf8 Class Initialized
INFO - 2018-12-04 20:00:50 --> URI Class Initialized
INFO - 2018-12-04 20:00:50 --> Router Class Initialized
INFO - 2018-12-04 20:00:50 --> Output Class Initialized
INFO - 2018-12-04 20:00:50 --> Security Class Initialized
DEBUG - 2018-12-04 20:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-04 20:00:50 --> Input Class Initialized
INFO - 2018-12-04 20:00:50 --> Language Class Initialized
INFO - 2018-12-04 20:00:50 --> Loader Class Initialized
INFO - 2018-12-04 20:00:50 --> Helper loaded: url_helper
INFO - 2018-12-04 20:00:50 --> Helper loaded: html_helper
INFO - 2018-12-04 20:00:50 --> Helper loaded: form_helper
INFO - 2018-12-04 20:00:50 --> Helper loaded: cookie_helper
INFO - 2018-12-04 20:00:50 --> Helper loaded: date_helper
INFO - 2018-12-04 20:00:50 --> Form Validation Class Initialized
INFO - 2018-12-04 20:00:50 --> Email Class Initialized
DEBUG - 2018-12-04 20:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-04 20:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-04 20:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-04 20:00:50 --> Pagination Class Initialized
INFO - 2018-12-04 20:00:50 --> Database Driver Class Initialized
INFO - 2018-12-04 20:00:50 --> Database Driver Class Initialized
INFO - 2018-12-04 20:00:50 --> Controller Class Initialized
DEBUG - 2018-12-04 20:00:50 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-12-04 20:00:50 --> Helper loaded: inflector_helper
INFO - 2018-12-04 20:00:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-12-04 20:00:50 --> Final output sent to browser
DEBUG - 2018-12-04 20:00:50 --> Total execution time: 0.0679
