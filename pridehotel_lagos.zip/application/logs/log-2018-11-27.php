<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-27 18:04:53 --> Config Class Initialized
INFO - 2018-11-27 18:04:53 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:04:53 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:04:53 --> Utf8 Class Initialized
INFO - 2018-11-27 18:04:53 --> URI Class Initialized
DEBUG - 2018-11-27 18:04:53 --> No URI present. Default controller set.
INFO - 2018-11-27 18:04:53 --> Router Class Initialized
INFO - 2018-11-27 18:04:53 --> Output Class Initialized
INFO - 2018-11-27 18:04:53 --> Security Class Initialized
DEBUG - 2018-11-27 18:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:04:53 --> Input Class Initialized
INFO - 2018-11-27 18:04:53 --> Language Class Initialized
INFO - 2018-11-27 18:04:54 --> Loader Class Initialized
INFO - 2018-11-27 18:04:54 --> Helper loaded: url_helper
INFO - 2018-11-27 18:04:54 --> Helper loaded: html_helper
INFO - 2018-11-27 18:04:54 --> Helper loaded: form_helper
INFO - 2018-11-27 18:04:54 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:04:54 --> Helper loaded: date_helper
INFO - 2018-11-27 18:04:54 --> Form Validation Class Initialized
INFO - 2018-11-27 18:04:54 --> Email Class Initialized
DEBUG - 2018-11-27 18:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:04:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:04:54 --> Pagination Class Initialized
INFO - 2018-11-27 18:04:54 --> Database Driver Class Initialized
INFO - 2018-11-27 18:04:54 --> Database Driver Class Initialized
INFO - 2018-11-27 18:04:54 --> Controller Class Initialized
INFO - 2018-11-27 18:04:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-27 18:04:54 --> Final output sent to browser
DEBUG - 2018-11-27 18:04:54 --> Total execution time: 0.1576
INFO - 2018-11-27 18:04:55 --> Config Class Initialized
INFO - 2018-11-27 18:04:55 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:04:55 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:04:55 --> Utf8 Class Initialized
INFO - 2018-11-27 18:04:55 --> URI Class Initialized
DEBUG - 2018-11-27 18:04:55 --> No URI present. Default controller set.
INFO - 2018-11-27 18:04:55 --> Router Class Initialized
INFO - 2018-11-27 18:04:55 --> Output Class Initialized
INFO - 2018-11-27 18:04:55 --> Security Class Initialized
DEBUG - 2018-11-27 18:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:04:55 --> Input Class Initialized
INFO - 2018-11-27 18:04:55 --> Language Class Initialized
INFO - 2018-11-27 18:04:55 --> Loader Class Initialized
INFO - 2018-11-27 18:04:55 --> Helper loaded: url_helper
INFO - 2018-11-27 18:04:55 --> Helper loaded: html_helper
INFO - 2018-11-27 18:04:55 --> Helper loaded: form_helper
INFO - 2018-11-27 18:04:55 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:04:55 --> Helper loaded: date_helper
INFO - 2018-11-27 18:04:55 --> Form Validation Class Initialized
INFO - 2018-11-27 18:04:55 --> Email Class Initialized
DEBUG - 2018-11-27 18:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:04:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:04:55 --> Pagination Class Initialized
INFO - 2018-11-27 18:04:55 --> Database Driver Class Initialized
INFO - 2018-11-27 18:04:55 --> Database Driver Class Initialized
INFO - 2018-11-27 18:04:55 --> Controller Class Initialized
INFO - 2018-11-27 18:04:55 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-27 18:04:55 --> Final output sent to browser
DEBUG - 2018-11-27 18:04:55 --> Total execution time: 0.0910
INFO - 2018-11-27 18:05:21 --> Config Class Initialized
INFO - 2018-11-27 18:05:21 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:05:21 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:05:21 --> Utf8 Class Initialized
INFO - 2018-11-27 18:05:21 --> URI Class Initialized
DEBUG - 2018-11-27 18:05:21 --> No URI present. Default controller set.
INFO - 2018-11-27 18:05:21 --> Router Class Initialized
INFO - 2018-11-27 18:05:21 --> Output Class Initialized
INFO - 2018-11-27 18:05:21 --> Security Class Initialized
DEBUG - 2018-11-27 18:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:05:21 --> Input Class Initialized
INFO - 2018-11-27 18:05:21 --> Language Class Initialized
INFO - 2018-11-27 18:05:21 --> Loader Class Initialized
INFO - 2018-11-27 18:05:21 --> Helper loaded: url_helper
INFO - 2018-11-27 18:05:21 --> Helper loaded: html_helper
INFO - 2018-11-27 18:05:21 --> Helper loaded: form_helper
INFO - 2018-11-27 18:05:21 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:05:21 --> Helper loaded: date_helper
INFO - 2018-11-27 18:05:21 --> Form Validation Class Initialized
INFO - 2018-11-27 18:05:21 --> Email Class Initialized
DEBUG - 2018-11-27 18:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:05:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:05:21 --> Pagination Class Initialized
INFO - 2018-11-27 18:05:21 --> Database Driver Class Initialized
INFO - 2018-11-27 18:05:21 --> Database Driver Class Initialized
INFO - 2018-11-27 18:05:21 --> Controller Class Initialized
INFO - 2018-11-27 18:05:21 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-27 18:05:21 --> Final output sent to browser
DEBUG - 2018-11-27 18:05:21 --> Total execution time: 0.1447
INFO - 2018-11-27 18:05:22 --> Config Class Initialized
INFO - 2018-11-27 18:05:22 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:05:22 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:05:22 --> Utf8 Class Initialized
INFO - 2018-11-27 18:05:22 --> URI Class Initialized
DEBUG - 2018-11-27 18:05:22 --> No URI present. Default controller set.
INFO - 2018-11-27 18:05:22 --> Router Class Initialized
INFO - 2018-11-27 18:05:22 --> Output Class Initialized
INFO - 2018-11-27 18:05:22 --> Security Class Initialized
DEBUG - 2018-11-27 18:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:05:22 --> Input Class Initialized
INFO - 2018-11-27 18:05:22 --> Language Class Initialized
INFO - 2018-11-27 18:05:22 --> Loader Class Initialized
INFO - 2018-11-27 18:05:22 --> Helper loaded: url_helper
INFO - 2018-11-27 18:05:22 --> Helper loaded: html_helper
INFO - 2018-11-27 18:05:22 --> Helper loaded: form_helper
INFO - 2018-11-27 18:05:22 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:05:22 --> Helper loaded: date_helper
INFO - 2018-11-27 18:05:22 --> Form Validation Class Initialized
INFO - 2018-11-27 18:05:22 --> Email Class Initialized
DEBUG - 2018-11-27 18:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:05:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:05:22 --> Pagination Class Initialized
INFO - 2018-11-27 18:05:22 --> Database Driver Class Initialized
INFO - 2018-11-27 18:05:22 --> Database Driver Class Initialized
INFO - 2018-11-27 18:05:22 --> Controller Class Initialized
INFO - 2018-11-27 18:05:22 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-27 18:05:22 --> Final output sent to browser
DEBUG - 2018-11-27 18:05:22 --> Total execution time: 0.0987
INFO - 2018-11-27 18:05:31 --> Config Class Initialized
INFO - 2018-11-27 18:05:31 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:05:31 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:05:31 --> Utf8 Class Initialized
INFO - 2018-11-27 18:05:31 --> URI Class Initialized
INFO - 2018-11-27 18:05:31 --> Router Class Initialized
INFO - 2018-11-27 18:05:31 --> Output Class Initialized
INFO - 2018-11-27 18:05:31 --> Security Class Initialized
DEBUG - 2018-11-27 18:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:05:31 --> Input Class Initialized
INFO - 2018-11-27 18:05:31 --> Language Class Initialized
INFO - 2018-11-27 18:05:31 --> Loader Class Initialized
INFO - 2018-11-27 18:05:31 --> Helper loaded: url_helper
INFO - 2018-11-27 18:05:31 --> Helper loaded: html_helper
INFO - 2018-11-27 18:05:31 --> Helper loaded: form_helper
INFO - 2018-11-27 18:05:31 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:05:31 --> Helper loaded: date_helper
INFO - 2018-11-27 18:05:31 --> Form Validation Class Initialized
INFO - 2018-11-27 18:05:31 --> Email Class Initialized
DEBUG - 2018-11-27 18:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:05:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:05:31 --> Pagination Class Initialized
INFO - 2018-11-27 18:05:31 --> Database Driver Class Initialized
INFO - 2018-11-27 18:05:31 --> Database Driver Class Initialized
INFO - 2018-11-27 18:05:31 --> Controller Class Initialized
INFO - 2018-11-27 18:05:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-11-27 18:05:31 --> Config Class Initialized
INFO - 2018-11-27 18:05:31 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:05:31 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:05:31 --> Utf8 Class Initialized
INFO - 2018-11-27 18:05:31 --> URI Class Initialized
INFO - 2018-11-27 18:05:31 --> Router Class Initialized
INFO - 2018-11-27 18:05:31 --> Output Class Initialized
INFO - 2018-11-27 18:05:31 --> Security Class Initialized
DEBUG - 2018-11-27 18:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:05:31 --> Input Class Initialized
INFO - 2018-11-27 18:05:31 --> Language Class Initialized
INFO - 2018-11-27 18:05:31 --> Loader Class Initialized
INFO - 2018-11-27 18:05:31 --> Helper loaded: url_helper
INFO - 2018-11-27 18:05:31 --> Helper loaded: html_helper
INFO - 2018-11-27 18:05:31 --> Helper loaded: form_helper
INFO - 2018-11-27 18:05:31 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:05:31 --> Helper loaded: date_helper
INFO - 2018-11-27 18:05:31 --> Form Validation Class Initialized
INFO - 2018-11-27 18:05:31 --> Email Class Initialized
DEBUG - 2018-11-27 18:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:05:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:05:31 --> Pagination Class Initialized
INFO - 2018-11-27 18:05:31 --> Database Driver Class Initialized
INFO - 2018-11-27 18:05:31 --> Database Driver Class Initialized
INFO - 2018-11-27 18:05:31 --> Controller Class Initialized
INFO - 2018-11-27 18:05:31 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-27 18:05:31 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-11-27 18:05:31 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-27 18:05:31 --> Final output sent to browser
DEBUG - 2018-11-27 18:05:31 --> Total execution time: 0.1571
INFO - 2018-11-27 18:05:31 --> Config Class Initialized
INFO - 2018-11-27 18:05:31 --> Config Class Initialized
INFO - 2018-11-27 18:05:31 --> Hooks Class Initialized
INFO - 2018-11-27 18:05:31 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:05:31 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:05:31 --> Utf8 Class Initialized
DEBUG - 2018-11-27 18:05:31 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:05:31 --> URI Class Initialized
INFO - 2018-11-27 18:05:31 --> Utf8 Class Initialized
INFO - 2018-11-27 18:05:31 --> URI Class Initialized
INFO - 2018-11-27 18:05:31 --> Router Class Initialized
INFO - 2018-11-27 18:05:31 --> Output Class Initialized
INFO - 2018-11-27 18:05:32 --> Router Class Initialized
INFO - 2018-11-27 18:05:32 --> Security Class Initialized
INFO - 2018-11-27 18:05:32 --> Output Class Initialized
DEBUG - 2018-11-27 18:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:05:32 --> Security Class Initialized
INFO - 2018-11-27 18:05:32 --> Input Class Initialized
INFO - 2018-11-27 18:05:32 --> Language Class Initialized
DEBUG - 2018-11-27 18:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:05:32 --> Input Class Initialized
INFO - 2018-11-27 18:05:32 --> Language Class Initialized
INFO - 2018-11-27 18:05:32 --> Loader Class Initialized
INFO - 2018-11-27 18:05:32 --> Helper loaded: url_helper
INFO - 2018-11-27 18:05:32 --> Loader Class Initialized
INFO - 2018-11-27 18:05:32 --> Helper loaded: html_helper
INFO - 2018-11-27 18:05:32 --> Helper loaded: url_helper
INFO - 2018-11-27 18:05:32 --> Helper loaded: form_helper
INFO - 2018-11-27 18:05:32 --> Helper loaded: html_helper
INFO - 2018-11-27 18:05:32 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:05:32 --> Helper loaded: form_helper
INFO - 2018-11-27 18:05:32 --> Helper loaded: date_helper
INFO - 2018-11-27 18:05:32 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:05:32 --> Form Validation Class Initialized
INFO - 2018-11-27 18:05:32 --> Helper loaded: date_helper
INFO - 2018-11-27 18:05:32 --> Form Validation Class Initialized
INFO - 2018-11-27 18:05:32 --> Email Class Initialized
INFO - 2018-11-27 18:05:32 --> Email Class Initialized
DEBUG - 2018-11-27 18:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:05:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-11-27 18:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:05:32 --> Pagination Class Initialized
INFO - 2018-11-27 18:05:32 --> Database Driver Class Initialized
INFO - 2018-11-27 18:05:32 --> Database Driver Class Initialized
INFO - 2018-11-27 18:05:32 --> Controller Class Initialized
INFO - 2018-11-27 18:05:32 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:05:32 --> Final output sent to browser
DEBUG - 2018-11-27 18:05:32 --> Total execution time: 0.1654
INFO - 2018-11-27 18:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:05:32 --> Pagination Class Initialized
INFO - 2018-11-27 18:05:32 --> Database Driver Class Initialized
INFO - 2018-11-27 18:05:32 --> Database Driver Class Initialized
INFO - 2018-11-27 18:05:32 --> Controller Class Initialized
INFO - 2018-11-27 18:05:32 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:05:32 --> Final output sent to browser
DEBUG - 2018-11-27 18:05:32 --> Total execution time: 0.2292
INFO - 2018-11-27 18:05:44 --> Config Class Initialized
INFO - 2018-11-27 18:05:44 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:05:44 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:05:44 --> Utf8 Class Initialized
INFO - 2018-11-27 18:05:44 --> URI Class Initialized
INFO - 2018-11-27 18:05:44 --> Router Class Initialized
INFO - 2018-11-27 18:05:44 --> Output Class Initialized
INFO - 2018-11-27 18:05:44 --> Security Class Initialized
DEBUG - 2018-11-27 18:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:05:44 --> Input Class Initialized
INFO - 2018-11-27 18:05:44 --> Language Class Initialized
INFO - 2018-11-27 18:05:44 --> Loader Class Initialized
INFO - 2018-11-27 18:05:44 --> Helper loaded: url_helper
INFO - 2018-11-27 18:05:44 --> Helper loaded: html_helper
INFO - 2018-11-27 18:05:44 --> Helper loaded: form_helper
INFO - 2018-11-27 18:05:44 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:05:44 --> Helper loaded: date_helper
INFO - 2018-11-27 18:05:44 --> Form Validation Class Initialized
INFO - 2018-11-27 18:05:44 --> Email Class Initialized
DEBUG - 2018-11-27 18:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:05:44 --> Pagination Class Initialized
INFO - 2018-11-27 18:05:44 --> Database Driver Class Initialized
INFO - 2018-11-27 18:05:44 --> Database Driver Class Initialized
INFO - 2018-11-27 18:05:44 --> Controller Class Initialized
INFO - 2018-11-27 18:05:44 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:05:44 --> Final output sent to browser
DEBUG - 2018-11-27 18:05:44 --> Total execution time: 0.1051
INFO - 2018-11-27 18:05:46 --> Config Class Initialized
INFO - 2018-11-27 18:05:46 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:05:46 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:05:46 --> Utf8 Class Initialized
INFO - 2018-11-27 18:05:46 --> URI Class Initialized
INFO - 2018-11-27 18:05:46 --> Router Class Initialized
INFO - 2018-11-27 18:05:46 --> Output Class Initialized
INFO - 2018-11-27 18:05:46 --> Security Class Initialized
DEBUG - 2018-11-27 18:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:05:46 --> Input Class Initialized
INFO - 2018-11-27 18:05:46 --> Language Class Initialized
INFO - 2018-11-27 18:05:46 --> Loader Class Initialized
INFO - 2018-11-27 18:05:46 --> Helper loaded: url_helper
INFO - 2018-11-27 18:05:46 --> Helper loaded: html_helper
INFO - 2018-11-27 18:05:46 --> Helper loaded: form_helper
INFO - 2018-11-27 18:05:46 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:05:46 --> Helper loaded: date_helper
INFO - 2018-11-27 18:05:46 --> Form Validation Class Initialized
INFO - 2018-11-27 18:05:46 --> Email Class Initialized
DEBUG - 2018-11-27 18:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:05:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:05:46 --> Pagination Class Initialized
INFO - 2018-11-27 18:05:46 --> Database Driver Class Initialized
INFO - 2018-11-27 18:05:46 --> Database Driver Class Initialized
INFO - 2018-11-27 18:05:46 --> Controller Class Initialized
INFO - 2018-11-27 18:05:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:05:46 --> Final output sent to browser
DEBUG - 2018-11-27 18:05:46 --> Total execution time: 0.1138
INFO - 2018-11-27 18:06:47 --> Config Class Initialized
INFO - 2018-11-27 18:06:47 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:06:47 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:06:47 --> Utf8 Class Initialized
INFO - 2018-11-27 18:06:47 --> URI Class Initialized
INFO - 2018-11-27 18:06:47 --> Router Class Initialized
INFO - 2018-11-27 18:06:47 --> Output Class Initialized
INFO - 2018-11-27 18:06:47 --> Security Class Initialized
DEBUG - 2018-11-27 18:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:06:47 --> Input Class Initialized
INFO - 2018-11-27 18:06:47 --> Language Class Initialized
INFO - 2018-11-27 18:06:47 --> Loader Class Initialized
INFO - 2018-11-27 18:06:47 --> Helper loaded: url_helper
INFO - 2018-11-27 18:06:47 --> Helper loaded: html_helper
INFO - 2018-11-27 18:06:47 --> Helper loaded: form_helper
INFO - 2018-11-27 18:06:47 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:06:47 --> Helper loaded: date_helper
INFO - 2018-11-27 18:06:47 --> Form Validation Class Initialized
INFO - 2018-11-27 18:06:47 --> Email Class Initialized
DEBUG - 2018-11-27 18:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:06:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:06:47 --> Pagination Class Initialized
INFO - 2018-11-27 18:06:47 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:47 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:47 --> Controller Class Initialized
INFO - 2018-11-27 18:06:47 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-27 18:06:47 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/room.php
INFO - 2018-11-27 18:06:47 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-27 18:06:47 --> Final output sent to browser
DEBUG - 2018-11-27 18:06:47 --> Total execution time: 0.1189
INFO - 2018-11-27 18:06:47 --> Config Class Initialized
INFO - 2018-11-27 18:06:47 --> Config Class Initialized
INFO - 2018-11-27 18:06:47 --> Hooks Class Initialized
INFO - 2018-11-27 18:06:47 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:06:47 --> UTF-8 Support Enabled
DEBUG - 2018-11-27 18:06:47 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:06:47 --> Utf8 Class Initialized
INFO - 2018-11-27 18:06:47 --> Utf8 Class Initialized
INFO - 2018-11-27 18:06:47 --> URI Class Initialized
INFO - 2018-11-27 18:06:47 --> URI Class Initialized
INFO - 2018-11-27 18:06:47 --> Router Class Initialized
INFO - 2018-11-27 18:06:47 --> Router Class Initialized
INFO - 2018-11-27 18:06:47 --> Output Class Initialized
INFO - 2018-11-27 18:06:47 --> Output Class Initialized
INFO - 2018-11-27 18:06:47 --> Security Class Initialized
INFO - 2018-11-27 18:06:47 --> Security Class Initialized
DEBUG - 2018-11-27 18:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-27 18:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:06:47 --> Input Class Initialized
INFO - 2018-11-27 18:06:47 --> Input Class Initialized
INFO - 2018-11-27 18:06:47 --> Language Class Initialized
INFO - 2018-11-27 18:06:47 --> Language Class Initialized
INFO - 2018-11-27 18:06:47 --> Loader Class Initialized
INFO - 2018-11-27 18:06:47 --> Loader Class Initialized
INFO - 2018-11-27 18:06:47 --> Helper loaded: url_helper
INFO - 2018-11-27 18:06:47 --> Helper loaded: url_helper
INFO - 2018-11-27 18:06:47 --> Helper loaded: html_helper
INFO - 2018-11-27 18:06:47 --> Helper loaded: html_helper
INFO - 2018-11-27 18:06:47 --> Helper loaded: form_helper
INFO - 2018-11-27 18:06:47 --> Helper loaded: form_helper
INFO - 2018-11-27 18:06:47 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:06:47 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:06:47 --> Helper loaded: date_helper
INFO - 2018-11-27 18:06:47 --> Helper loaded: date_helper
INFO - 2018-11-27 18:06:47 --> Form Validation Class Initialized
INFO - 2018-11-27 18:06:47 --> Form Validation Class Initialized
INFO - 2018-11-27 18:06:47 --> Email Class Initialized
INFO - 2018-11-27 18:06:47 --> Email Class Initialized
DEBUG - 2018-11-27 18:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-27 18:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:06:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:06:47 --> Pagination Class Initialized
INFO - 2018-11-27 18:06:47 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:47 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:47 --> Controller Class Initialized
INFO - 2018-11-27 18:06:47 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:06:47 --> Final output sent to browser
DEBUG - 2018-11-27 18:06:47 --> Total execution time: 0.1481
INFO - 2018-11-27 18:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:06:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:06:47 --> Pagination Class Initialized
INFO - 2018-11-27 18:06:47 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:47 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:47 --> Controller Class Initialized
INFO - 2018-11-27 18:06:48 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:06:48 --> Final output sent to browser
DEBUG - 2018-11-27 18:06:48 --> Total execution time: 0.2095
INFO - 2018-11-27 18:06:48 --> Config Class Initialized
INFO - 2018-11-27 18:06:48 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:06:48 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:06:48 --> Utf8 Class Initialized
INFO - 2018-11-27 18:06:48 --> URI Class Initialized
INFO - 2018-11-27 18:06:48 --> Router Class Initialized
INFO - 2018-11-27 18:06:48 --> Output Class Initialized
INFO - 2018-11-27 18:06:48 --> Security Class Initialized
DEBUG - 2018-11-27 18:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:06:48 --> Input Class Initialized
INFO - 2018-11-27 18:06:48 --> Language Class Initialized
INFO - 2018-11-27 18:06:48 --> Loader Class Initialized
INFO - 2018-11-27 18:06:48 --> Helper loaded: url_helper
INFO - 2018-11-27 18:06:48 --> Helper loaded: html_helper
INFO - 2018-11-27 18:06:48 --> Helper loaded: form_helper
INFO - 2018-11-27 18:06:48 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:06:48 --> Helper loaded: date_helper
INFO - 2018-11-27 18:06:48 --> Form Validation Class Initialized
INFO - 2018-11-27 18:06:48 --> Email Class Initialized
DEBUG - 2018-11-27 18:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:06:48 --> Pagination Class Initialized
INFO - 2018-11-27 18:06:48 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:48 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:48 --> Controller Class Initialized
INFO - 2018-11-27 18:06:48 --> Final output sent to browser
DEBUG - 2018-11-27 18:06:48 --> Total execution time: 0.2046
INFO - 2018-11-27 18:06:52 --> Config Class Initialized
INFO - 2018-11-27 18:06:52 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:06:52 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:06:52 --> Utf8 Class Initialized
INFO - 2018-11-27 18:06:52 --> URI Class Initialized
INFO - 2018-11-27 18:06:52 --> Router Class Initialized
INFO - 2018-11-27 18:06:52 --> Output Class Initialized
INFO - 2018-11-27 18:06:52 --> Security Class Initialized
DEBUG - 2018-11-27 18:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:06:52 --> Input Class Initialized
INFO - 2018-11-27 18:06:52 --> Language Class Initialized
INFO - 2018-11-27 18:06:52 --> Loader Class Initialized
INFO - 2018-11-27 18:06:52 --> Helper loaded: url_helper
INFO - 2018-11-27 18:06:52 --> Helper loaded: html_helper
INFO - 2018-11-27 18:06:52 --> Helper loaded: form_helper
INFO - 2018-11-27 18:06:52 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:06:52 --> Helper loaded: date_helper
INFO - 2018-11-27 18:06:52 --> Form Validation Class Initialized
INFO - 2018-11-27 18:06:52 --> Email Class Initialized
DEBUG - 2018-11-27 18:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:06:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:06:52 --> Pagination Class Initialized
INFO - 2018-11-27 18:06:52 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:52 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:52 --> Controller Class Initialized
INFO - 2018-11-27 18:06:52 --> Final output sent to browser
DEBUG - 2018-11-27 18:06:52 --> Total execution time: 0.1074
INFO - 2018-11-27 18:06:54 --> Config Class Initialized
INFO - 2018-11-27 18:06:54 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:06:54 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:06:54 --> Utf8 Class Initialized
INFO - 2018-11-27 18:06:54 --> URI Class Initialized
INFO - 2018-11-27 18:06:54 --> Router Class Initialized
INFO - 2018-11-27 18:06:54 --> Output Class Initialized
INFO - 2018-11-27 18:06:54 --> Security Class Initialized
DEBUG - 2018-11-27 18:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:06:54 --> Input Class Initialized
INFO - 2018-11-27 18:06:54 --> Language Class Initialized
INFO - 2018-11-27 18:06:54 --> Loader Class Initialized
INFO - 2018-11-27 18:06:54 --> Helper loaded: url_helper
INFO - 2018-11-27 18:06:54 --> Helper loaded: html_helper
INFO - 2018-11-27 18:06:54 --> Helper loaded: form_helper
INFO - 2018-11-27 18:06:54 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:06:54 --> Helper loaded: date_helper
INFO - 2018-11-27 18:06:54 --> Form Validation Class Initialized
INFO - 2018-11-27 18:06:54 --> Email Class Initialized
DEBUG - 2018-11-27 18:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:06:54 --> Pagination Class Initialized
INFO - 2018-11-27 18:06:54 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:54 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:54 --> Controller Class Initialized
INFO - 2018-11-27 18:06:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-27 18:06:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/room.php
INFO - 2018-11-27 18:06:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-27 18:06:54 --> Final output sent to browser
DEBUG - 2018-11-27 18:06:54 --> Total execution time: 0.1239
INFO - 2018-11-27 18:06:54 --> Config Class Initialized
INFO - 2018-11-27 18:06:54 --> Config Class Initialized
INFO - 2018-11-27 18:06:54 --> Hooks Class Initialized
INFO - 2018-11-27 18:06:54 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:06:54 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:06:54 --> Utf8 Class Initialized
DEBUG - 2018-11-27 18:06:54 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:06:54 --> URI Class Initialized
INFO - 2018-11-27 18:06:54 --> Utf8 Class Initialized
INFO - 2018-11-27 18:06:54 --> URI Class Initialized
INFO - 2018-11-27 18:06:54 --> Router Class Initialized
INFO - 2018-11-27 18:06:54 --> Router Class Initialized
INFO - 2018-11-27 18:06:54 --> Output Class Initialized
INFO - 2018-11-27 18:06:54 --> Output Class Initialized
INFO - 2018-11-27 18:06:54 --> Security Class Initialized
INFO - 2018-11-27 18:06:54 --> Security Class Initialized
DEBUG - 2018-11-27 18:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-27 18:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:06:54 --> Input Class Initialized
INFO - 2018-11-27 18:06:54 --> Input Class Initialized
INFO - 2018-11-27 18:06:54 --> Language Class Initialized
INFO - 2018-11-27 18:06:54 --> Language Class Initialized
INFO - 2018-11-27 18:06:54 --> Loader Class Initialized
INFO - 2018-11-27 18:06:54 --> Loader Class Initialized
INFO - 2018-11-27 18:06:54 --> Helper loaded: url_helper
INFO - 2018-11-27 18:06:54 --> Helper loaded: url_helper
INFO - 2018-11-27 18:06:54 --> Helper loaded: html_helper
INFO - 2018-11-27 18:06:54 --> Helper loaded: html_helper
INFO - 2018-11-27 18:06:54 --> Helper loaded: form_helper
INFO - 2018-11-27 18:06:54 --> Helper loaded: form_helper
INFO - 2018-11-27 18:06:54 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:06:54 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:06:54 --> Helper loaded: date_helper
INFO - 2018-11-27 18:06:54 --> Helper loaded: date_helper
INFO - 2018-11-27 18:06:54 --> Form Validation Class Initialized
INFO - 2018-11-27 18:06:54 --> Form Validation Class Initialized
INFO - 2018-11-27 18:06:54 --> Email Class Initialized
INFO - 2018-11-27 18:06:54 --> Email Class Initialized
DEBUG - 2018-11-27 18:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-27 18:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:06:54 --> Pagination Class Initialized
INFO - 2018-11-27 18:06:54 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:54 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:54 --> Controller Class Initialized
INFO - 2018-11-27 18:06:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:06:54 --> Final output sent to browser
DEBUG - 2018-11-27 18:06:54 --> Total execution time: 0.1780
INFO - 2018-11-27 18:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:06:54 --> Pagination Class Initialized
INFO - 2018-11-27 18:06:54 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:54 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:54 --> Config Class Initialized
INFO - 2018-11-27 18:06:54 --> Controller Class Initialized
INFO - 2018-11-27 18:06:54 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:06:54 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:06:54 --> Utf8 Class Initialized
INFO - 2018-11-27 18:06:54 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:06:54 --> URI Class Initialized
INFO - 2018-11-27 18:06:54 --> Final output sent to browser
DEBUG - 2018-11-27 18:06:54 --> Total execution time: 0.2460
INFO - 2018-11-27 18:06:54 --> Router Class Initialized
INFO - 2018-11-27 18:06:54 --> Output Class Initialized
INFO - 2018-11-27 18:06:54 --> Security Class Initialized
DEBUG - 2018-11-27 18:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:06:54 --> Input Class Initialized
INFO - 2018-11-27 18:06:55 --> Language Class Initialized
INFO - 2018-11-27 18:06:55 --> Loader Class Initialized
INFO - 2018-11-27 18:06:55 --> Helper loaded: url_helper
INFO - 2018-11-27 18:06:55 --> Helper loaded: html_helper
INFO - 2018-11-27 18:06:55 --> Helper loaded: form_helper
INFO - 2018-11-27 18:06:55 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:06:55 --> Helper loaded: date_helper
INFO - 2018-11-27 18:06:55 --> Form Validation Class Initialized
INFO - 2018-11-27 18:06:55 --> Email Class Initialized
DEBUG - 2018-11-27 18:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:06:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:06:55 --> Pagination Class Initialized
INFO - 2018-11-27 18:06:55 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:55 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:55 --> Controller Class Initialized
INFO - 2018-11-27 18:06:55 --> Final output sent to browser
DEBUG - 2018-11-27 18:06:55 --> Total execution time: 0.1757
INFO - 2018-11-27 18:06:55 --> Config Class Initialized
INFO - 2018-11-27 18:06:55 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:06:55 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:06:55 --> Utf8 Class Initialized
INFO - 2018-11-27 18:06:55 --> URI Class Initialized
INFO - 2018-11-27 18:06:55 --> Router Class Initialized
INFO - 2018-11-27 18:06:55 --> Output Class Initialized
INFO - 2018-11-27 18:06:55 --> Security Class Initialized
DEBUG - 2018-11-27 18:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:06:55 --> Input Class Initialized
INFO - 2018-11-27 18:06:55 --> Language Class Initialized
INFO - 2018-11-27 18:06:55 --> Loader Class Initialized
INFO - 2018-11-27 18:06:55 --> Helper loaded: url_helper
INFO - 2018-11-27 18:06:55 --> Helper loaded: html_helper
INFO - 2018-11-27 18:06:55 --> Helper loaded: form_helper
INFO - 2018-11-27 18:06:55 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:06:55 --> Helper loaded: date_helper
INFO - 2018-11-27 18:06:55 --> Form Validation Class Initialized
INFO - 2018-11-27 18:06:55 --> Email Class Initialized
DEBUG - 2018-11-27 18:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:06:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:06:55 --> Pagination Class Initialized
INFO - 2018-11-27 18:06:55 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:55 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:55 --> Controller Class Initialized
INFO - 2018-11-27 18:06:55 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:06:55 --> Final output sent to browser
DEBUG - 2018-11-27 18:06:55 --> Total execution time: 0.1217
INFO - 2018-11-27 18:06:56 --> Config Class Initialized
INFO - 2018-11-27 18:06:56 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:06:56 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:06:56 --> Utf8 Class Initialized
INFO - 2018-11-27 18:06:56 --> URI Class Initialized
INFO - 2018-11-27 18:06:56 --> Router Class Initialized
INFO - 2018-11-27 18:06:56 --> Output Class Initialized
INFO - 2018-11-27 18:06:56 --> Security Class Initialized
DEBUG - 2018-11-27 18:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:06:56 --> Input Class Initialized
INFO - 2018-11-27 18:06:56 --> Language Class Initialized
INFO - 2018-11-27 18:06:56 --> Loader Class Initialized
INFO - 2018-11-27 18:06:56 --> Helper loaded: url_helper
INFO - 2018-11-27 18:06:56 --> Helper loaded: html_helper
INFO - 2018-11-27 18:06:56 --> Helper loaded: form_helper
INFO - 2018-11-27 18:06:56 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:06:56 --> Helper loaded: date_helper
INFO - 2018-11-27 18:06:56 --> Form Validation Class Initialized
INFO - 2018-11-27 18:06:56 --> Email Class Initialized
DEBUG - 2018-11-27 18:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:06:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:06:56 --> Pagination Class Initialized
INFO - 2018-11-27 18:06:56 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:56 --> Database Driver Class Initialized
INFO - 2018-11-27 18:06:56 --> Controller Class Initialized
INFO - 2018-11-27 18:06:56 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:06:56 --> Final output sent to browser
DEBUG - 2018-11-27 18:06:56 --> Total execution time: 0.2033
INFO - 2018-11-27 18:07:00 --> Config Class Initialized
INFO - 2018-11-27 18:07:00 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:07:00 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:07:00 --> Utf8 Class Initialized
INFO - 2018-11-27 18:07:00 --> URI Class Initialized
INFO - 2018-11-27 18:07:00 --> Router Class Initialized
INFO - 2018-11-27 18:07:00 --> Output Class Initialized
INFO - 2018-11-27 18:07:00 --> Security Class Initialized
DEBUG - 2018-11-27 18:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:07:00 --> Input Class Initialized
INFO - 2018-11-27 18:07:00 --> Language Class Initialized
INFO - 2018-11-27 18:07:00 --> Loader Class Initialized
INFO - 2018-11-27 18:07:00 --> Helper loaded: url_helper
INFO - 2018-11-27 18:07:00 --> Helper loaded: html_helper
INFO - 2018-11-27 18:07:00 --> Helper loaded: form_helper
INFO - 2018-11-27 18:07:00 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:07:00 --> Helper loaded: date_helper
INFO - 2018-11-27 18:07:00 --> Form Validation Class Initialized
INFO - 2018-11-27 18:07:00 --> Email Class Initialized
DEBUG - 2018-11-27 18:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:07:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:07:00 --> Pagination Class Initialized
INFO - 2018-11-27 18:07:00 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:00 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:00 --> Controller Class Initialized
INFO - 2018-11-27 18:07:00 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-27 18:07:00 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/housekeeping.php
INFO - 2018-11-27 18:07:00 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-27 18:07:00 --> Final output sent to browser
DEBUG - 2018-11-27 18:07:00 --> Total execution time: 0.1216
INFO - 2018-11-27 18:07:00 --> Config Class Initialized
INFO - 2018-11-27 18:07:00 --> Config Class Initialized
INFO - 2018-11-27 18:07:00 --> Hooks Class Initialized
INFO - 2018-11-27 18:07:00 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:07:00 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:07:00 --> Utf8 Class Initialized
DEBUG - 2018-11-27 18:07:00 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:07:00 --> URI Class Initialized
INFO - 2018-11-27 18:07:00 --> Utf8 Class Initialized
INFO - 2018-11-27 18:07:00 --> URI Class Initialized
INFO - 2018-11-27 18:07:00 --> Router Class Initialized
INFO - 2018-11-27 18:07:00 --> Router Class Initialized
INFO - 2018-11-27 18:07:00 --> Output Class Initialized
INFO - 2018-11-27 18:07:00 --> Output Class Initialized
INFO - 2018-11-27 18:07:00 --> Security Class Initialized
INFO - 2018-11-27 18:07:00 --> Security Class Initialized
DEBUG - 2018-11-27 18:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-27 18:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:07:00 --> Input Class Initialized
INFO - 2018-11-27 18:07:00 --> Input Class Initialized
INFO - 2018-11-27 18:07:00 --> Language Class Initialized
INFO - 2018-11-27 18:07:00 --> Language Class Initialized
INFO - 2018-11-27 18:07:00 --> Loader Class Initialized
INFO - 2018-11-27 18:07:00 --> Loader Class Initialized
INFO - 2018-11-27 18:07:00 --> Helper loaded: url_helper
INFO - 2018-11-27 18:07:00 --> Helper loaded: url_helper
INFO - 2018-11-27 18:07:00 --> Helper loaded: html_helper
INFO - 2018-11-27 18:07:00 --> Helper loaded: html_helper
INFO - 2018-11-27 18:07:00 --> Helper loaded: form_helper
INFO - 2018-11-27 18:07:00 --> Helper loaded: form_helper
INFO - 2018-11-27 18:07:00 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:07:00 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:07:00 --> Helper loaded: date_helper
INFO - 2018-11-27 18:07:00 --> Helper loaded: date_helper
INFO - 2018-11-27 18:07:00 --> Form Validation Class Initialized
INFO - 2018-11-27 18:07:00 --> Form Validation Class Initialized
INFO - 2018-11-27 18:07:00 --> Email Class Initialized
INFO - 2018-11-27 18:07:00 --> Email Class Initialized
DEBUG - 2018-11-27 18:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-27 18:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:07:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:07:00 --> Pagination Class Initialized
INFO - 2018-11-27 18:07:00 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:00 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:00 --> Controller Class Initialized
INFO - 2018-11-27 18:07:00 --> Config Class Initialized
INFO - 2018-11-27 18:07:00 --> Hooks Class Initialized
INFO - 2018-11-27 18:07:00 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:07:00 --> Final output sent to browser
DEBUG - 2018-11-27 18:07:00 --> UTF-8 Support Enabled
DEBUG - 2018-11-27 18:07:00 --> Total execution time: 0.1635
INFO - 2018-11-27 18:07:00 --> Utf8 Class Initialized
INFO - 2018-11-27 18:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:07:00 --> URI Class Initialized
INFO - 2018-11-27 18:07:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:07:00 --> Pagination Class Initialized
INFO - 2018-11-27 18:07:00 --> Router Class Initialized
INFO - 2018-11-27 18:07:00 --> Output Class Initialized
INFO - 2018-11-27 18:07:00 --> Security Class Initialized
INFO - 2018-11-27 18:07:00 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:00 --> Database Driver Class Initialized
DEBUG - 2018-11-27 18:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:07:00 --> Controller Class Initialized
INFO - 2018-11-27 18:07:00 --> Input Class Initialized
INFO - 2018-11-27 18:07:00 --> Language Class Initialized
INFO - 2018-11-27 18:07:00 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:07:00 --> Final output sent to browser
DEBUG - 2018-11-27 18:07:00 --> Total execution time: 0.2523
INFO - 2018-11-27 18:07:00 --> Loader Class Initialized
INFO - 2018-11-27 18:07:00 --> Helper loaded: url_helper
INFO - 2018-11-27 18:07:00 --> Helper loaded: html_helper
INFO - 2018-11-27 18:07:00 --> Helper loaded: form_helper
INFO - 2018-11-27 18:07:00 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:07:00 --> Helper loaded: date_helper
INFO - 2018-11-27 18:07:00 --> Form Validation Class Initialized
INFO - 2018-11-27 18:07:00 --> Email Class Initialized
DEBUG - 2018-11-27 18:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:07:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:07:00 --> Pagination Class Initialized
INFO - 2018-11-27 18:07:00 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:00 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:00 --> Controller Class Initialized
INFO - 2018-11-27 18:07:00 --> Final output sent to browser
DEBUG - 2018-11-27 18:07:00 --> Total execution time: 0.2200
INFO - 2018-11-27 18:07:04 --> Config Class Initialized
INFO - 2018-11-27 18:07:04 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:07:04 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:07:04 --> Utf8 Class Initialized
INFO - 2018-11-27 18:07:04 --> URI Class Initialized
INFO - 2018-11-27 18:07:04 --> Router Class Initialized
INFO - 2018-11-27 18:07:04 --> Output Class Initialized
INFO - 2018-11-27 18:07:04 --> Security Class Initialized
DEBUG - 2018-11-27 18:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:07:04 --> Input Class Initialized
INFO - 2018-11-27 18:07:04 --> Language Class Initialized
INFO - 2018-11-27 18:07:04 --> Loader Class Initialized
INFO - 2018-11-27 18:07:04 --> Helper loaded: url_helper
INFO - 2018-11-27 18:07:04 --> Helper loaded: html_helper
INFO - 2018-11-27 18:07:04 --> Helper loaded: form_helper
INFO - 2018-11-27 18:07:04 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:07:04 --> Helper loaded: date_helper
INFO - 2018-11-27 18:07:04 --> Form Validation Class Initialized
INFO - 2018-11-27 18:07:04 --> Email Class Initialized
DEBUG - 2018-11-27 18:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:07:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:07:04 --> Pagination Class Initialized
INFO - 2018-11-27 18:07:04 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:04 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:04 --> Controller Class Initialized
INFO - 2018-11-27 18:07:04 --> Config Class Initialized
INFO - 2018-11-27 18:07:04 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:07:04 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:07:04 --> Utf8 Class Initialized
INFO - 2018-11-27 18:07:04 --> URI Class Initialized
INFO - 2018-11-27 18:07:04 --> Router Class Initialized
INFO - 2018-11-27 18:07:04 --> Output Class Initialized
INFO - 2018-11-27 18:07:04 --> Security Class Initialized
DEBUG - 2018-11-27 18:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:07:04 --> Input Class Initialized
INFO - 2018-11-27 18:07:04 --> Language Class Initialized
INFO - 2018-11-27 18:07:04 --> Loader Class Initialized
INFO - 2018-11-27 18:07:04 --> Helper loaded: url_helper
INFO - 2018-11-27 18:07:04 --> Helper loaded: html_helper
INFO - 2018-11-27 18:07:04 --> Helper loaded: form_helper
INFO - 2018-11-27 18:07:04 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:07:04 --> Helper loaded: date_helper
INFO - 2018-11-27 18:07:04 --> Form Validation Class Initialized
INFO - 2018-11-27 18:07:04 --> Email Class Initialized
DEBUG - 2018-11-27 18:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:07:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:07:04 --> Pagination Class Initialized
INFO - 2018-11-27 18:07:04 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:04 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:04 --> Controller Class Initialized
INFO - 2018-11-27 18:07:05 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-27 18:07:05 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/housekeeping.php
INFO - 2018-11-27 18:07:05 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-27 18:07:05 --> Final output sent to browser
DEBUG - 2018-11-27 18:07:05 --> Total execution time: 0.1558
INFO - 2018-11-27 18:07:05 --> Config Class Initialized
INFO - 2018-11-27 18:07:05 --> Config Class Initialized
INFO - 2018-11-27 18:07:05 --> Hooks Class Initialized
INFO - 2018-11-27 18:07:05 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:07:05 --> UTF-8 Support Enabled
DEBUG - 2018-11-27 18:07:05 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:07:05 --> Utf8 Class Initialized
INFO - 2018-11-27 18:07:05 --> Utf8 Class Initialized
INFO - 2018-11-27 18:07:05 --> URI Class Initialized
INFO - 2018-11-27 18:07:05 --> URI Class Initialized
INFO - 2018-11-27 18:07:05 --> Router Class Initialized
INFO - 2018-11-27 18:07:05 --> Router Class Initialized
INFO - 2018-11-27 18:07:05 --> Output Class Initialized
INFO - 2018-11-27 18:07:05 --> Output Class Initialized
INFO - 2018-11-27 18:07:05 --> Security Class Initialized
INFO - 2018-11-27 18:07:05 --> Security Class Initialized
DEBUG - 2018-11-27 18:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:07:05 --> Input Class Initialized
DEBUG - 2018-11-27 18:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:07:05 --> Language Class Initialized
INFO - 2018-11-27 18:07:05 --> Input Class Initialized
INFO - 2018-11-27 18:07:05 --> Language Class Initialized
INFO - 2018-11-27 18:07:05 --> Loader Class Initialized
INFO - 2018-11-27 18:07:05 --> Helper loaded: url_helper
INFO - 2018-11-27 18:07:05 --> Helper loaded: html_helper
INFO - 2018-11-27 18:07:05 --> Loader Class Initialized
INFO - 2018-11-27 18:07:05 --> Helper loaded: form_helper
INFO - 2018-11-27 18:07:05 --> Helper loaded: url_helper
INFO - 2018-11-27 18:07:05 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:07:05 --> Helper loaded: html_helper
INFO - 2018-11-27 18:07:05 --> Helper loaded: date_helper
INFO - 2018-11-27 18:07:05 --> Helper loaded: form_helper
INFO - 2018-11-27 18:07:05 --> Form Validation Class Initialized
INFO - 2018-11-27 18:07:05 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:07:05 --> Email Class Initialized
INFO - 2018-11-27 18:07:05 --> Helper loaded: date_helper
DEBUG - 2018-11-27 18:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:07:05 --> Form Validation Class Initialized
INFO - 2018-11-27 18:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:07:05 --> Email Class Initialized
INFO - 2018-11-27 18:07:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:07:05 --> Pagination Class Initialized
DEBUG - 2018-11-27 18:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:07:05 --> Config Class Initialized
INFO - 2018-11-27 18:07:05 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:05 --> Hooks Class Initialized
INFO - 2018-11-27 18:07:05 --> Database Driver Class Initialized
DEBUG - 2018-11-27 18:07:05 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:07:05 --> Utf8 Class Initialized
INFO - 2018-11-27 18:07:05 --> Controller Class Initialized
INFO - 2018-11-27 18:07:05 --> URI Class Initialized
INFO - 2018-11-27 18:07:05 --> Router Class Initialized
INFO - 2018-11-27 18:07:05 --> Output Class Initialized
INFO - 2018-11-27 18:07:05 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:07:05 --> Final output sent to browser
INFO - 2018-11-27 18:07:05 --> Security Class Initialized
DEBUG - 2018-11-27 18:07:05 --> Total execution time: 0.1664
DEBUG - 2018-11-27 18:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:07:05 --> Input Class Initialized
INFO - 2018-11-27 18:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:07:05 --> Language Class Initialized
INFO - 2018-11-27 18:07:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:07:05 --> Pagination Class Initialized
INFO - 2018-11-27 18:07:05 --> Loader Class Initialized
INFO - 2018-11-27 18:07:05 --> Helper loaded: url_helper
INFO - 2018-11-27 18:07:05 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:05 --> Helper loaded: html_helper
INFO - 2018-11-27 18:07:05 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:05 --> Helper loaded: form_helper
INFO - 2018-11-27 18:07:05 --> Controller Class Initialized
INFO - 2018-11-27 18:07:05 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:07:05 --> Helper loaded: date_helper
INFO - 2018-11-27 18:07:05 --> Form Validation Class Initialized
INFO - 2018-11-27 18:07:05 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:07:05 --> Final output sent to browser
INFO - 2018-11-27 18:07:05 --> Email Class Initialized
DEBUG - 2018-11-27 18:07:05 --> Total execution time: 0.2431
DEBUG - 2018-11-27 18:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:07:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:07:05 --> Pagination Class Initialized
INFO - 2018-11-27 18:07:05 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:05 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:05 --> Controller Class Initialized
INFO - 2018-11-27 18:07:05 --> Final output sent to browser
DEBUG - 2018-11-27 18:07:05 --> Total execution time: 0.1767
INFO - 2018-11-27 18:07:44 --> Config Class Initialized
INFO - 2018-11-27 18:07:44 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:07:44 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:07:44 --> Utf8 Class Initialized
INFO - 2018-11-27 18:07:44 --> URI Class Initialized
INFO - 2018-11-27 18:07:44 --> Router Class Initialized
INFO - 2018-11-27 18:07:44 --> Output Class Initialized
INFO - 2018-11-27 18:07:44 --> Security Class Initialized
DEBUG - 2018-11-27 18:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:07:44 --> Input Class Initialized
INFO - 2018-11-27 18:07:44 --> Language Class Initialized
INFO - 2018-11-27 18:07:44 --> Loader Class Initialized
INFO - 2018-11-27 18:07:44 --> Helper loaded: url_helper
INFO - 2018-11-27 18:07:44 --> Helper loaded: html_helper
INFO - 2018-11-27 18:07:44 --> Helper loaded: form_helper
INFO - 2018-11-27 18:07:44 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:07:44 --> Helper loaded: date_helper
INFO - 2018-11-27 18:07:44 --> Form Validation Class Initialized
INFO - 2018-11-27 18:07:44 --> Email Class Initialized
DEBUG - 2018-11-27 18:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:07:44 --> Pagination Class Initialized
INFO - 2018-11-27 18:07:44 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:44 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:44 --> Controller Class Initialized
INFO - 2018-11-27 18:07:44 --> Config Class Initialized
INFO - 2018-11-27 18:07:44 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:07:44 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:07:44 --> Utf8 Class Initialized
INFO - 2018-11-27 18:07:44 --> URI Class Initialized
INFO - 2018-11-27 18:07:44 --> Router Class Initialized
INFO - 2018-11-27 18:07:44 --> Output Class Initialized
INFO - 2018-11-27 18:07:44 --> Security Class Initialized
DEBUG - 2018-11-27 18:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:07:44 --> Input Class Initialized
INFO - 2018-11-27 18:07:44 --> Language Class Initialized
INFO - 2018-11-27 18:07:44 --> Loader Class Initialized
INFO - 2018-11-27 18:07:44 --> Helper loaded: url_helper
INFO - 2018-11-27 18:07:44 --> Helper loaded: html_helper
INFO - 2018-11-27 18:07:44 --> Helper loaded: form_helper
INFO - 2018-11-27 18:07:44 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:07:44 --> Helper loaded: date_helper
INFO - 2018-11-27 18:07:44 --> Form Validation Class Initialized
INFO - 2018-11-27 18:07:44 --> Email Class Initialized
DEBUG - 2018-11-27 18:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:07:44 --> Pagination Class Initialized
INFO - 2018-11-27 18:07:44 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:44 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:44 --> Controller Class Initialized
INFO - 2018-11-27 18:07:44 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-27 18:07:44 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/housekeeping.php
INFO - 2018-11-27 18:07:44 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-27 18:07:44 --> Final output sent to browser
DEBUG - 2018-11-27 18:07:44 --> Total execution time: 0.1282
INFO - 2018-11-27 18:07:44 --> Config Class Initialized
INFO - 2018-11-27 18:07:44 --> Config Class Initialized
INFO - 2018-11-27 18:07:44 --> Hooks Class Initialized
INFO - 2018-11-27 18:07:44 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:07:44 --> UTF-8 Support Enabled
DEBUG - 2018-11-27 18:07:44 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:07:44 --> Utf8 Class Initialized
INFO - 2018-11-27 18:07:44 --> Utf8 Class Initialized
INFO - 2018-11-27 18:07:44 --> URI Class Initialized
INFO - 2018-11-27 18:07:44 --> URI Class Initialized
INFO - 2018-11-27 18:07:44 --> Router Class Initialized
INFO - 2018-11-27 18:07:44 --> Router Class Initialized
INFO - 2018-11-27 18:07:44 --> Output Class Initialized
INFO - 2018-11-27 18:07:44 --> Output Class Initialized
INFO - 2018-11-27 18:07:44 --> Security Class Initialized
INFO - 2018-11-27 18:07:44 --> Security Class Initialized
DEBUG - 2018-11-27 18:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-27 18:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:07:44 --> Input Class Initialized
INFO - 2018-11-27 18:07:44 --> Input Class Initialized
INFO - 2018-11-27 18:07:44 --> Language Class Initialized
INFO - 2018-11-27 18:07:44 --> Language Class Initialized
INFO - 2018-11-27 18:07:44 --> Loader Class Initialized
INFO - 2018-11-27 18:07:44 --> Loader Class Initialized
INFO - 2018-11-27 18:07:44 --> Helper loaded: url_helper
INFO - 2018-11-27 18:07:44 --> Helper loaded: url_helper
INFO - 2018-11-27 18:07:44 --> Helper loaded: html_helper
INFO - 2018-11-27 18:07:44 --> Helper loaded: html_helper
INFO - 2018-11-27 18:07:44 --> Helper loaded: form_helper
INFO - 2018-11-27 18:07:44 --> Helper loaded: form_helper
INFO - 2018-11-27 18:07:44 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:07:44 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:07:44 --> Helper loaded: date_helper
INFO - 2018-11-27 18:07:44 --> Helper loaded: date_helper
INFO - 2018-11-27 18:07:44 --> Form Validation Class Initialized
INFO - 2018-11-27 18:07:44 --> Form Validation Class Initialized
INFO - 2018-11-27 18:07:44 --> Email Class Initialized
INFO - 2018-11-27 18:07:44 --> Email Class Initialized
DEBUG - 2018-11-27 18:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-27 18:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:07:44 --> Pagination Class Initialized
INFO - 2018-11-27 18:07:44 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:44 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:44 --> Controller Class Initialized
INFO - 2018-11-27 18:07:45 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:07:45 --> Final output sent to browser
DEBUG - 2018-11-27 18:07:45 --> Total execution time: 0.1660
INFO - 2018-11-27 18:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:07:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:07:45 --> Pagination Class Initialized
INFO - 2018-11-27 18:07:45 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:45 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:45 --> Controller Class Initialized
INFO - 2018-11-27 18:07:45 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:07:45 --> Final output sent to browser
DEBUG - 2018-11-27 18:07:45 --> Total execution time: 0.2277
INFO - 2018-11-27 18:07:45 --> Config Class Initialized
INFO - 2018-11-27 18:07:45 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:07:45 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:07:45 --> Utf8 Class Initialized
INFO - 2018-11-27 18:07:45 --> URI Class Initialized
INFO - 2018-11-27 18:07:45 --> Router Class Initialized
INFO - 2018-11-27 18:07:45 --> Output Class Initialized
INFO - 2018-11-27 18:07:45 --> Security Class Initialized
DEBUG - 2018-11-27 18:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:07:45 --> Input Class Initialized
INFO - 2018-11-27 18:07:45 --> Language Class Initialized
INFO - 2018-11-27 18:07:45 --> Loader Class Initialized
INFO - 2018-11-27 18:07:45 --> Helper loaded: url_helper
INFO - 2018-11-27 18:07:45 --> Helper loaded: html_helper
INFO - 2018-11-27 18:07:45 --> Helper loaded: form_helper
INFO - 2018-11-27 18:07:45 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:07:45 --> Helper loaded: date_helper
INFO - 2018-11-27 18:07:45 --> Form Validation Class Initialized
INFO - 2018-11-27 18:07:45 --> Email Class Initialized
DEBUG - 2018-11-27 18:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:07:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:07:45 --> Pagination Class Initialized
INFO - 2018-11-27 18:07:45 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:45 --> Database Driver Class Initialized
INFO - 2018-11-27 18:07:45 --> Controller Class Initialized
INFO - 2018-11-27 18:07:45 --> Final output sent to browser
DEBUG - 2018-11-27 18:07:45 --> Total execution time: 0.1558
INFO - 2018-11-27 18:09:52 --> Config Class Initialized
INFO - 2018-11-27 18:09:52 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:09:52 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:09:52 --> Utf8 Class Initialized
INFO - 2018-11-27 18:09:52 --> URI Class Initialized
INFO - 2018-11-27 18:09:52 --> Router Class Initialized
INFO - 2018-11-27 18:09:52 --> Output Class Initialized
INFO - 2018-11-27 18:09:52 --> Security Class Initialized
DEBUG - 2018-11-27 18:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:09:52 --> Input Class Initialized
INFO - 2018-11-27 18:09:52 --> Language Class Initialized
INFO - 2018-11-27 18:09:52 --> Loader Class Initialized
INFO - 2018-11-27 18:09:52 --> Helper loaded: url_helper
INFO - 2018-11-27 18:09:52 --> Helper loaded: html_helper
INFO - 2018-11-27 18:09:52 --> Helper loaded: form_helper
INFO - 2018-11-27 18:09:52 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:09:52 --> Helper loaded: date_helper
INFO - 2018-11-27 18:09:52 --> Form Validation Class Initialized
INFO - 2018-11-27 18:09:52 --> Email Class Initialized
DEBUG - 2018-11-27 18:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:09:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:09:52 --> Pagination Class Initialized
INFO - 2018-11-27 18:09:52 --> Database Driver Class Initialized
INFO - 2018-11-27 18:09:52 --> Database Driver Class Initialized
INFO - 2018-11-27 18:09:52 --> Controller Class Initialized
INFO - 2018-11-27 18:09:52 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:09:52 --> Final output sent to browser
DEBUG - 2018-11-27 18:09:52 --> Total execution time: 0.1128
INFO - 2018-11-27 18:09:52 --> Config Class Initialized
INFO - 2018-11-27 18:09:52 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:09:52 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:09:52 --> Utf8 Class Initialized
INFO - 2018-11-27 18:09:52 --> URI Class Initialized
INFO - 2018-11-27 18:09:52 --> Router Class Initialized
INFO - 2018-11-27 18:09:52 --> Output Class Initialized
INFO - 2018-11-27 18:09:52 --> Security Class Initialized
DEBUG - 2018-11-27 18:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:09:52 --> Input Class Initialized
INFO - 2018-11-27 18:09:52 --> Language Class Initialized
INFO - 2018-11-27 18:09:52 --> Loader Class Initialized
INFO - 2018-11-27 18:09:52 --> Helper loaded: url_helper
INFO - 2018-11-27 18:09:52 --> Helper loaded: html_helper
INFO - 2018-11-27 18:09:52 --> Helper loaded: form_helper
INFO - 2018-11-27 18:09:52 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:09:52 --> Helper loaded: date_helper
INFO - 2018-11-27 18:09:52 --> Form Validation Class Initialized
INFO - 2018-11-27 18:09:52 --> Email Class Initialized
DEBUG - 2018-11-27 18:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:09:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:09:52 --> Pagination Class Initialized
INFO - 2018-11-27 18:09:52 --> Database Driver Class Initialized
INFO - 2018-11-27 18:09:52 --> Database Driver Class Initialized
INFO - 2018-11-27 18:09:52 --> Controller Class Initialized
INFO - 2018-11-27 18:09:52 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:09:52 --> Final output sent to browser
DEBUG - 2018-11-27 18:09:52 --> Total execution time: 0.1215
INFO - 2018-11-27 18:17:16 --> Config Class Initialized
INFO - 2018-11-27 18:17:16 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:17:16 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:17:16 --> Utf8 Class Initialized
INFO - 2018-11-27 18:17:16 --> URI Class Initialized
INFO - 2018-11-27 18:17:16 --> Router Class Initialized
INFO - 2018-11-27 18:17:16 --> Output Class Initialized
INFO - 2018-11-27 18:17:16 --> Security Class Initialized
DEBUG - 2018-11-27 18:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:17:16 --> Input Class Initialized
INFO - 2018-11-27 18:17:16 --> Language Class Initialized
INFO - 2018-11-27 18:17:16 --> Loader Class Initialized
INFO - 2018-11-27 18:17:16 --> Helper loaded: url_helper
INFO - 2018-11-27 18:17:16 --> Helper loaded: html_helper
INFO - 2018-11-27 18:17:16 --> Helper loaded: form_helper
INFO - 2018-11-27 18:17:16 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:17:16 --> Helper loaded: date_helper
INFO - 2018-11-27 18:17:16 --> Form Validation Class Initialized
INFO - 2018-11-27 18:17:16 --> Email Class Initialized
DEBUG - 2018-11-27 18:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:17:16 --> Pagination Class Initialized
INFO - 2018-11-27 18:17:16 --> Database Driver Class Initialized
INFO - 2018-11-27 18:17:16 --> Database Driver Class Initialized
INFO - 2018-11-27 18:17:16 --> Controller Class Initialized
INFO - 2018-11-27 18:17:16 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-27 18:17:16 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/housekeeping.php
INFO - 2018-11-27 18:17:16 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-27 18:17:16 --> Final output sent to browser
DEBUG - 2018-11-27 18:17:16 --> Total execution time: 0.1265
INFO - 2018-11-27 18:17:16 --> Config Class Initialized
INFO - 2018-11-27 18:17:16 --> Hooks Class Initialized
INFO - 2018-11-27 18:17:16 --> Config Class Initialized
INFO - 2018-11-27 18:17:16 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:17:16 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:17:16 --> Utf8 Class Initialized
DEBUG - 2018-11-27 18:17:16 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:17:16 --> URI Class Initialized
INFO - 2018-11-27 18:17:16 --> Utf8 Class Initialized
INFO - 2018-11-27 18:17:16 --> URI Class Initialized
INFO - 2018-11-27 18:17:16 --> Router Class Initialized
INFO - 2018-11-27 18:17:16 --> Router Class Initialized
INFO - 2018-11-27 18:17:16 --> Output Class Initialized
INFO - 2018-11-27 18:17:16 --> Output Class Initialized
INFO - 2018-11-27 18:17:16 --> Security Class Initialized
INFO - 2018-11-27 18:17:16 --> Security Class Initialized
DEBUG - 2018-11-27 18:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:17:16 --> Input Class Initialized
DEBUG - 2018-11-27 18:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:17:16 --> Language Class Initialized
INFO - 2018-11-27 18:17:16 --> Input Class Initialized
INFO - 2018-11-27 18:17:16 --> Language Class Initialized
INFO - 2018-11-27 18:17:16 --> Loader Class Initialized
INFO - 2018-11-27 18:17:16 --> Loader Class Initialized
INFO - 2018-11-27 18:17:16 --> Helper loaded: url_helper
INFO - 2018-11-27 18:17:16 --> Helper loaded: url_helper
INFO - 2018-11-27 18:17:16 --> Helper loaded: html_helper
INFO - 2018-11-27 18:17:16 --> Helper loaded: html_helper
INFO - 2018-11-27 18:17:16 --> Helper loaded: form_helper
INFO - 2018-11-27 18:17:16 --> Helper loaded: form_helper
INFO - 2018-11-27 18:17:16 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:17:16 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:17:16 --> Helper loaded: date_helper
INFO - 2018-11-27 18:17:16 --> Helper loaded: date_helper
INFO - 2018-11-27 18:17:16 --> Form Validation Class Initialized
INFO - 2018-11-27 18:17:16 --> Form Validation Class Initialized
INFO - 2018-11-27 18:17:16 --> Email Class Initialized
INFO - 2018-11-27 18:17:16 --> Email Class Initialized
DEBUG - 2018-11-27 18:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-11-27 18:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:17:16 --> Pagination Class Initialized
INFO - 2018-11-27 18:17:16 --> Database Driver Class Initialized
INFO - 2018-11-27 18:17:16 --> Database Driver Class Initialized
INFO - 2018-11-27 18:17:16 --> Controller Class Initialized
INFO - 2018-11-27 18:17:16 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:17:16 --> Final output sent to browser
DEBUG - 2018-11-27 18:17:16 --> Total execution time: 0.1749
INFO - 2018-11-27 18:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:17:16 --> Pagination Class Initialized
INFO - 2018-11-27 18:17:16 --> Database Driver Class Initialized
INFO - 2018-11-27 18:17:16 --> Database Driver Class Initialized
INFO - 2018-11-27 18:17:16 --> Controller Class Initialized
INFO - 2018-11-27 18:17:16 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:17:16 --> Final output sent to browser
DEBUG - 2018-11-27 18:17:16 --> Total execution time: 0.2354
INFO - 2018-11-27 18:17:16 --> Config Class Initialized
INFO - 2018-11-27 18:17:16 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:17:16 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:17:16 --> Utf8 Class Initialized
INFO - 2018-11-27 18:17:16 --> URI Class Initialized
INFO - 2018-11-27 18:17:16 --> Router Class Initialized
INFO - 2018-11-27 18:17:16 --> Output Class Initialized
INFO - 2018-11-27 18:17:16 --> Security Class Initialized
DEBUG - 2018-11-27 18:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:17:16 --> Input Class Initialized
INFO - 2018-11-27 18:17:16 --> Language Class Initialized
INFO - 2018-11-27 18:17:16 --> Loader Class Initialized
INFO - 2018-11-27 18:17:16 --> Helper loaded: url_helper
INFO - 2018-11-27 18:17:16 --> Helper loaded: html_helper
INFO - 2018-11-27 18:17:16 --> Helper loaded: form_helper
INFO - 2018-11-27 18:17:16 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:17:16 --> Helper loaded: date_helper
INFO - 2018-11-27 18:17:16 --> Form Validation Class Initialized
INFO - 2018-11-27 18:17:17 --> Email Class Initialized
DEBUG - 2018-11-27 18:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:17:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:17:17 --> Pagination Class Initialized
INFO - 2018-11-27 18:17:17 --> Database Driver Class Initialized
INFO - 2018-11-27 18:17:17 --> Database Driver Class Initialized
INFO - 2018-11-27 18:17:17 --> Controller Class Initialized
INFO - 2018-11-27 18:17:17 --> Final output sent to browser
DEBUG - 2018-11-27 18:17:17 --> Total execution time: 0.1692
INFO - 2018-11-27 18:17:18 --> Config Class Initialized
INFO - 2018-11-27 18:17:18 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:17:18 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:17:18 --> Utf8 Class Initialized
INFO - 2018-11-27 18:17:18 --> URI Class Initialized
INFO - 2018-11-27 18:17:18 --> Config Class Initialized
INFO - 2018-11-27 18:17:18 --> Hooks Class Initialized
INFO - 2018-11-27 18:17:18 --> Router Class Initialized
DEBUG - 2018-11-27 18:17:18 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:17:18 --> Utf8 Class Initialized
INFO - 2018-11-27 18:17:18 --> Output Class Initialized
INFO - 2018-11-27 18:17:18 --> URI Class Initialized
INFO - 2018-11-27 18:17:18 --> Security Class Initialized
DEBUG - 2018-11-27 18:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:17:18 --> Router Class Initialized
INFO - 2018-11-27 18:17:18 --> Input Class Initialized
INFO - 2018-11-27 18:17:18 --> Language Class Initialized
INFO - 2018-11-27 18:17:18 --> Output Class Initialized
INFO - 2018-11-27 18:17:18 --> Security Class Initialized
INFO - 2018-11-27 18:17:18 --> Loader Class Initialized
DEBUG - 2018-11-27 18:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:17:18 --> Input Class Initialized
INFO - 2018-11-27 18:17:18 --> Helper loaded: url_helper
INFO - 2018-11-27 18:17:18 --> Language Class Initialized
INFO - 2018-11-27 18:17:18 --> Helper loaded: html_helper
INFO - 2018-11-27 18:17:18 --> Helper loaded: form_helper
INFO - 2018-11-27 18:17:18 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:17:18 --> Loader Class Initialized
INFO - 2018-11-27 18:17:18 --> Helper loaded: date_helper
INFO - 2018-11-27 18:17:18 --> Helper loaded: url_helper
INFO - 2018-11-27 18:17:18 --> Form Validation Class Initialized
INFO - 2018-11-27 18:17:18 --> Helper loaded: html_helper
INFO - 2018-11-27 18:17:18 --> Email Class Initialized
INFO - 2018-11-27 18:17:18 --> Helper loaded: form_helper
INFO - 2018-11-27 18:17:18 --> Helper loaded: cookie_helper
DEBUG - 2018-11-27 18:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:17:18 --> Helper loaded: date_helper
INFO - 2018-11-27 18:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:17:18 --> Form Validation Class Initialized
INFO - 2018-11-27 18:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:17:18 --> Pagination Class Initialized
INFO - 2018-11-27 18:17:18 --> Email Class Initialized
DEBUG - 2018-11-27 18:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:17:18 --> Database Driver Class Initialized
INFO - 2018-11-27 18:17:18 --> Database Driver Class Initialized
INFO - 2018-11-27 18:17:18 --> Controller Class Initialized
INFO - 2018-11-27 18:17:18 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:17:18 --> Final output sent to browser
DEBUG - 2018-11-27 18:17:18 --> Total execution time: 0.1360
INFO - 2018-11-27 18:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:17:18 --> Pagination Class Initialized
INFO - 2018-11-27 18:17:18 --> Database Driver Class Initialized
INFO - 2018-11-27 18:17:18 --> Database Driver Class Initialized
INFO - 2018-11-27 18:17:18 --> Controller Class Initialized
INFO - 2018-11-27 18:17:18 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:17:18 --> Final output sent to browser
DEBUG - 2018-11-27 18:17:18 --> Total execution time: 0.1641
INFO - 2018-11-27 18:22:34 --> Config Class Initialized
INFO - 2018-11-27 18:22:34 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:22:34 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:22:34 --> Utf8 Class Initialized
INFO - 2018-11-27 18:22:34 --> URI Class Initialized
INFO - 2018-11-27 18:22:34 --> Router Class Initialized
INFO - 2018-11-27 18:22:34 --> Output Class Initialized
INFO - 2018-11-27 18:22:34 --> Security Class Initialized
DEBUG - 2018-11-27 18:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:22:34 --> Input Class Initialized
INFO - 2018-11-27 18:22:34 --> Language Class Initialized
INFO - 2018-11-27 18:22:34 --> Loader Class Initialized
INFO - 2018-11-27 18:22:34 --> Helper loaded: url_helper
INFO - 2018-11-27 18:22:34 --> Helper loaded: html_helper
INFO - 2018-11-27 18:22:34 --> Helper loaded: form_helper
INFO - 2018-11-27 18:22:34 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:22:34 --> Helper loaded: date_helper
INFO - 2018-11-27 18:22:34 --> Form Validation Class Initialized
INFO - 2018-11-27 18:22:34 --> Email Class Initialized
DEBUG - 2018-11-27 18:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:22:34 --> Pagination Class Initialized
INFO - 2018-11-27 18:22:34 --> Database Driver Class Initialized
INFO - 2018-11-27 18:22:34 --> Database Driver Class Initialized
INFO - 2018-11-27 18:22:34 --> Controller Class Initialized
INFO - 2018-11-27 18:22:34 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-11-27 18:22:34 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/housekeeping.php
INFO - 2018-11-27 18:22:34 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-11-27 18:22:34 --> Final output sent to browser
DEBUG - 2018-11-27 18:22:34 --> Total execution time: 0.1175
INFO - 2018-11-27 18:22:34 --> Config Class Initialized
INFO - 2018-11-27 18:22:34 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:22:34 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:22:34 --> Utf8 Class Initialized
INFO - 2018-11-27 18:22:34 --> Config Class Initialized
INFO - 2018-11-27 18:22:34 --> URI Class Initialized
INFO - 2018-11-27 18:22:34 --> Hooks Class Initialized
INFO - 2018-11-27 18:22:34 --> Router Class Initialized
DEBUG - 2018-11-27 18:22:34 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:22:34 --> Output Class Initialized
INFO - 2018-11-27 18:22:34 --> Utf8 Class Initialized
INFO - 2018-11-27 18:22:34 --> URI Class Initialized
INFO - 2018-11-27 18:22:34 --> Security Class Initialized
INFO - 2018-11-27 18:22:34 --> Router Class Initialized
DEBUG - 2018-11-27 18:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:22:34 --> Output Class Initialized
INFO - 2018-11-27 18:22:34 --> Input Class Initialized
INFO - 2018-11-27 18:22:34 --> Language Class Initialized
INFO - 2018-11-27 18:22:34 --> Security Class Initialized
DEBUG - 2018-11-27 18:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:22:34 --> Input Class Initialized
INFO - 2018-11-27 18:22:34 --> Loader Class Initialized
INFO - 2018-11-27 18:22:34 --> Language Class Initialized
INFO - 2018-11-27 18:22:34 --> Helper loaded: url_helper
INFO - 2018-11-27 18:22:34 --> Helper loaded: html_helper
INFO - 2018-11-27 18:22:34 --> Helper loaded: form_helper
INFO - 2018-11-27 18:22:34 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:22:34 --> Helper loaded: date_helper
INFO - 2018-11-27 18:22:34 --> Loader Class Initialized
INFO - 2018-11-27 18:22:34 --> Form Validation Class Initialized
INFO - 2018-11-27 18:22:34 --> Helper loaded: url_helper
INFO - 2018-11-27 18:22:34 --> Helper loaded: html_helper
INFO - 2018-11-27 18:22:34 --> Email Class Initialized
INFO - 2018-11-27 18:22:34 --> Helper loaded: form_helper
INFO - 2018-11-27 18:22:34 --> Helper loaded: cookie_helper
DEBUG - 2018-11-27 18:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:22:34 --> Helper loaded: date_helper
INFO - 2018-11-27 18:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:22:34 --> Form Validation Class Initialized
INFO - 2018-11-27 18:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:22:34 --> Pagination Class Initialized
INFO - 2018-11-27 18:22:34 --> Email Class Initialized
DEBUG - 2018-11-27 18:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:22:34 --> Database Driver Class Initialized
INFO - 2018-11-27 18:22:34 --> Database Driver Class Initialized
INFO - 2018-11-27 18:22:34 --> Controller Class Initialized
INFO - 2018-11-27 18:22:34 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:22:34 --> Final output sent to browser
DEBUG - 2018-11-27 18:22:34 --> Total execution time: 0.1810
INFO - 2018-11-27 18:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:22:34 --> Pagination Class Initialized
INFO - 2018-11-27 18:22:34 --> Database Driver Class Initialized
INFO - 2018-11-27 18:22:34 --> Database Driver Class Initialized
INFO - 2018-11-27 18:22:34 --> Controller Class Initialized
INFO - 2018-11-27 18:22:34 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-11-27 18:22:34 --> Final output sent to browser
DEBUG - 2018-11-27 18:22:34 --> Total execution time: 0.2339
INFO - 2018-11-27 18:22:34 --> Config Class Initialized
INFO - 2018-11-27 18:22:34 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:22:34 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:22:34 --> Utf8 Class Initialized
INFO - 2018-11-27 18:22:34 --> URI Class Initialized
INFO - 2018-11-27 18:22:34 --> Router Class Initialized
INFO - 2018-11-27 18:22:34 --> Output Class Initialized
INFO - 2018-11-27 18:22:34 --> Security Class Initialized
DEBUG - 2018-11-27 18:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:22:34 --> Input Class Initialized
INFO - 2018-11-27 18:22:34 --> Language Class Initialized
INFO - 2018-11-27 18:22:34 --> Loader Class Initialized
INFO - 2018-11-27 18:22:34 --> Helper loaded: url_helper
INFO - 2018-11-27 18:22:34 --> Helper loaded: html_helper
INFO - 2018-11-27 18:22:34 --> Helper loaded: form_helper
INFO - 2018-11-27 18:22:34 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:22:34 --> Helper loaded: date_helper
INFO - 2018-11-27 18:22:34 --> Form Validation Class Initialized
INFO - 2018-11-27 18:22:34 --> Email Class Initialized
DEBUG - 2018-11-27 18:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:22:35 --> Pagination Class Initialized
INFO - 2018-11-27 18:22:35 --> Database Driver Class Initialized
INFO - 2018-11-27 18:22:35 --> Database Driver Class Initialized
INFO - 2018-11-27 18:22:35 --> Controller Class Initialized
INFO - 2018-11-27 18:22:35 --> Final output sent to browser
DEBUG - 2018-11-27 18:22:35 --> Total execution time: 0.1724
INFO - 2018-11-27 18:22:37 --> Config Class Initialized
INFO - 2018-11-27 18:22:37 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:22:37 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:22:37 --> Utf8 Class Initialized
INFO - 2018-11-27 18:22:37 --> URI Class Initialized
INFO - 2018-11-27 18:22:37 --> Router Class Initialized
INFO - 2018-11-27 18:22:37 --> Output Class Initialized
INFO - 2018-11-27 18:22:37 --> Security Class Initialized
DEBUG - 2018-11-27 18:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:22:37 --> Input Class Initialized
INFO - 2018-11-27 18:22:37 --> Language Class Initialized
INFO - 2018-11-27 18:22:37 --> Loader Class Initialized
INFO - 2018-11-27 18:22:37 --> Helper loaded: url_helper
INFO - 2018-11-27 18:22:37 --> Helper loaded: html_helper
INFO - 2018-11-27 18:22:37 --> Helper loaded: form_helper
INFO - 2018-11-27 18:22:37 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:22:37 --> Helper loaded: date_helper
INFO - 2018-11-27 18:22:37 --> Form Validation Class Initialized
INFO - 2018-11-27 18:22:37 --> Email Class Initialized
DEBUG - 2018-11-27 18:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:22:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:22:37 --> Pagination Class Initialized
INFO - 2018-11-27 18:22:37 --> Database Driver Class Initialized
INFO - 2018-11-27 18:22:37 --> Database Driver Class Initialized
INFO - 2018-11-27 18:22:37 --> Controller Class Initialized
INFO - 2018-11-27 18:22:37 --> Config Class Initialized
INFO - 2018-11-27 18:22:37 --> Hooks Class Initialized
DEBUG - 2018-11-27 18:22:37 --> UTF-8 Support Enabled
INFO - 2018-11-27 18:22:37 --> Utf8 Class Initialized
INFO - 2018-11-27 18:22:37 --> URI Class Initialized
INFO - 2018-11-27 18:22:37 --> Router Class Initialized
INFO - 2018-11-27 18:22:37 --> Output Class Initialized
INFO - 2018-11-27 18:22:37 --> Security Class Initialized
DEBUG - 2018-11-27 18:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-27 18:22:37 --> Input Class Initialized
INFO - 2018-11-27 18:22:37 --> Language Class Initialized
INFO - 2018-11-27 18:22:37 --> Loader Class Initialized
INFO - 2018-11-27 18:22:37 --> Helper loaded: url_helper
INFO - 2018-11-27 18:22:37 --> Helper loaded: html_helper
INFO - 2018-11-27 18:22:37 --> Helper loaded: form_helper
INFO - 2018-11-27 18:22:37 --> Helper loaded: cookie_helper
INFO - 2018-11-27 18:22:37 --> Helper loaded: date_helper
INFO - 2018-11-27 18:22:37 --> Form Validation Class Initialized
INFO - 2018-11-27 18:22:37 --> Email Class Initialized
DEBUG - 2018-11-27 18:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-27 18:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-27 18:22:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-27 18:22:37 --> Pagination Class Initialized
INFO - 2018-11-27 18:22:37 --> Database Driver Class Initialized
INFO - 2018-11-27 18:22:37 --> Database Driver Class Initialized
INFO - 2018-11-27 18:22:37 --> Controller Class Initialized
INFO - 2018-11-27 18:22:37 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-27 18:22:37 --> Final output sent to browser
DEBUG - 2018-11-27 18:22:37 --> Total execution time: 0.1255
