<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-01-10 14:16:59 --> Config Class Initialized
INFO - 2019-01-10 14:16:59 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:16:59 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:16:59 --> Utf8 Class Initialized
INFO - 2019-01-10 14:16:59 --> URI Class Initialized
DEBUG - 2019-01-10 14:16:59 --> No URI present. Default controller set.
INFO - 2019-01-10 14:16:59 --> Router Class Initialized
INFO - 2019-01-10 14:16:59 --> Output Class Initialized
INFO - 2019-01-10 14:16:59 --> Security Class Initialized
DEBUG - 2019-01-10 14:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:16:59 --> Input Class Initialized
INFO - 2019-01-10 14:16:59 --> Language Class Initialized
INFO - 2019-01-10 14:16:59 --> Loader Class Initialized
INFO - 2019-01-10 14:16:59 --> Helper loaded: url_helper
INFO - 2019-01-10 14:16:59 --> Helper loaded: html_helper
INFO - 2019-01-10 14:16:59 --> Helper loaded: form_helper
INFO - 2019-01-10 14:16:59 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:16:59 --> Helper loaded: date_helper
INFO - 2019-01-10 14:16:59 --> Form Validation Class Initialized
INFO - 2019-01-10 14:16:59 --> Email Class Initialized
DEBUG - 2019-01-10 14:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:16:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:16:59 --> Pagination Class Initialized
INFO - 2019-01-10 14:16:59 --> Database Driver Class Initialized
INFO - 2019-01-10 14:16:59 --> Database Driver Class Initialized
INFO - 2019-01-10 14:17:01 --> Controller Class Initialized
INFO - 2019-01-10 14:17:02 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-01-10 14:17:02 --> Final output sent to browser
DEBUG - 2019-01-10 14:17:02 --> Total execution time: 3.3939
INFO - 2019-01-10 14:17:03 --> Config Class Initialized
INFO - 2019-01-10 14:17:03 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:17:03 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:17:03 --> Utf8 Class Initialized
INFO - 2019-01-10 14:17:03 --> URI Class Initialized
DEBUG - 2019-01-10 14:17:03 --> No URI present. Default controller set.
INFO - 2019-01-10 14:17:03 --> Router Class Initialized
INFO - 2019-01-10 14:17:03 --> Output Class Initialized
INFO - 2019-01-10 14:17:03 --> Security Class Initialized
DEBUG - 2019-01-10 14:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:17:03 --> Input Class Initialized
INFO - 2019-01-10 14:17:03 --> Language Class Initialized
INFO - 2019-01-10 14:17:03 --> Loader Class Initialized
INFO - 2019-01-10 14:17:03 --> Helper loaded: url_helper
INFO - 2019-01-10 14:17:03 --> Helper loaded: html_helper
INFO - 2019-01-10 14:17:03 --> Helper loaded: form_helper
INFO - 2019-01-10 14:17:03 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:17:03 --> Helper loaded: date_helper
INFO - 2019-01-10 14:17:03 --> Form Validation Class Initialized
INFO - 2019-01-10 14:17:03 --> Email Class Initialized
DEBUG - 2019-01-10 14:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:17:03 --> Pagination Class Initialized
INFO - 2019-01-10 14:17:03 --> Database Driver Class Initialized
INFO - 2019-01-10 14:17:03 --> Database Driver Class Initialized
INFO - 2019-01-10 14:17:03 --> Controller Class Initialized
INFO - 2019-01-10 14:17:03 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-01-10 14:17:03 --> Final output sent to browser
DEBUG - 2019-01-10 14:17:03 --> Total execution time: 0.2572
INFO - 2019-01-10 14:21:07 --> Config Class Initialized
INFO - 2019-01-10 14:21:07 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:21:07 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:21:07 --> Utf8 Class Initialized
INFO - 2019-01-10 14:21:07 --> URI Class Initialized
INFO - 2019-01-10 14:21:07 --> Router Class Initialized
INFO - 2019-01-10 14:21:07 --> Output Class Initialized
INFO - 2019-01-10 14:21:07 --> Security Class Initialized
DEBUG - 2019-01-10 14:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:21:07 --> Input Class Initialized
INFO - 2019-01-10 14:21:07 --> Language Class Initialized
INFO - 2019-01-10 14:21:07 --> Loader Class Initialized
INFO - 2019-01-10 14:21:07 --> Helper loaded: url_helper
INFO - 2019-01-10 14:21:07 --> Helper loaded: html_helper
INFO - 2019-01-10 14:21:07 --> Helper loaded: form_helper
INFO - 2019-01-10 14:21:07 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:21:07 --> Helper loaded: date_helper
INFO - 2019-01-10 14:21:07 --> Form Validation Class Initialized
INFO - 2019-01-10 14:21:07 --> Email Class Initialized
DEBUG - 2019-01-10 14:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:21:07 --> Pagination Class Initialized
INFO - 2019-01-10 14:21:07 --> Database Driver Class Initialized
INFO - 2019-01-10 14:21:07 --> Database Driver Class Initialized
INFO - 2019-01-10 14:21:07 --> Controller Class Initialized
INFO - 2019-01-10 14:21:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-01-10 14:21:08 --> Config Class Initialized
INFO - 2019-01-10 14:21:08 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:21:08 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:21:08 --> Utf8 Class Initialized
INFO - 2019-01-10 14:21:08 --> URI Class Initialized
INFO - 2019-01-10 14:21:08 --> Router Class Initialized
INFO - 2019-01-10 14:21:08 --> Output Class Initialized
INFO - 2019-01-10 14:21:08 --> Security Class Initialized
DEBUG - 2019-01-10 14:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:21:08 --> Input Class Initialized
INFO - 2019-01-10 14:21:08 --> Language Class Initialized
INFO - 2019-01-10 14:21:08 --> Loader Class Initialized
INFO - 2019-01-10 14:21:08 --> Helper loaded: url_helper
INFO - 2019-01-10 14:21:08 --> Helper loaded: html_helper
INFO - 2019-01-10 14:21:08 --> Helper loaded: form_helper
INFO - 2019-01-10 14:21:08 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:21:08 --> Helper loaded: date_helper
INFO - 2019-01-10 14:21:08 --> Form Validation Class Initialized
INFO - 2019-01-10 14:21:08 --> Email Class Initialized
DEBUG - 2019-01-10 14:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:21:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:21:08 --> Pagination Class Initialized
INFO - 2019-01-10 14:21:08 --> Database Driver Class Initialized
INFO - 2019-01-10 14:21:08 --> Database Driver Class Initialized
INFO - 2019-01-10 14:21:08 --> Controller Class Initialized
INFO - 2019-01-10 14:21:08 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-01-10 14:21:08 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-01-10 14:21:08 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-01-10 14:21:08 --> Final output sent to browser
DEBUG - 2019-01-10 14:21:08 --> Total execution time: 0.3287
INFO - 2019-01-10 14:21:11 --> Config Class Initialized
INFO - 2019-01-10 14:21:11 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:21:11 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:21:11 --> Utf8 Class Initialized
INFO - 2019-01-10 14:21:11 --> URI Class Initialized
INFO - 2019-01-10 14:21:11 --> Router Class Initialized
INFO - 2019-01-10 14:21:11 --> Output Class Initialized
INFO - 2019-01-10 14:21:11 --> Security Class Initialized
DEBUG - 2019-01-10 14:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:21:11 --> Input Class Initialized
INFO - 2019-01-10 14:21:11 --> Language Class Initialized
INFO - 2019-01-10 14:21:11 --> Loader Class Initialized
INFO - 2019-01-10 14:21:11 --> Helper loaded: url_helper
INFO - 2019-01-10 14:21:11 --> Helper loaded: html_helper
INFO - 2019-01-10 14:21:11 --> Helper loaded: form_helper
INFO - 2019-01-10 14:21:11 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:21:11 --> Helper loaded: date_helper
INFO - 2019-01-10 14:21:11 --> Form Validation Class Initialized
INFO - 2019-01-10 14:21:11 --> Email Class Initialized
INFO - 2019-01-10 14:21:11 --> Config Class Initialized
DEBUG - 2019-01-10 14:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:21:11 --> Hooks Class Initialized
INFO - 2019-01-10 14:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:21:11 --> Pagination Class Initialized
DEBUG - 2019-01-10 14:21:11 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:21:11 --> Utf8 Class Initialized
INFO - 2019-01-10 14:21:11 --> URI Class Initialized
INFO - 2019-01-10 14:21:11 --> Router Class Initialized
INFO - 2019-01-10 14:21:11 --> Output Class Initialized
INFO - 2019-01-10 14:21:11 --> Security Class Initialized
DEBUG - 2019-01-10 14:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:21:11 --> Input Class Initialized
INFO - 2019-01-10 14:21:11 --> Language Class Initialized
INFO - 2019-01-10 14:21:11 --> Database Driver Class Initialized
INFO - 2019-01-10 14:21:11 --> Database Driver Class Initialized
INFO - 2019-01-10 14:21:11 --> Loader Class Initialized
INFO - 2019-01-10 14:21:11 --> Controller Class Initialized
INFO - 2019-01-10 14:21:11 --> Helper loaded: url_helper
INFO - 2019-01-10 14:21:11 --> Helper loaded: html_helper
INFO - 2019-01-10 14:21:11 --> Helper loaded: form_helper
INFO - 2019-01-10 14:21:11 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:21:11 --> Helper loaded: date_helper
INFO - 2019-01-10 14:21:11 --> Form Validation Class Initialized
INFO - 2019-01-10 14:21:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-10 14:21:11 --> Final output sent to browser
DEBUG - 2019-01-10 14:21:11 --> Total execution time: 0.1615
INFO - 2019-01-10 14:21:11 --> Email Class Initialized
DEBUG - 2019-01-10 14:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:21:11 --> Pagination Class Initialized
INFO - 2019-01-10 14:21:11 --> Database Driver Class Initialized
INFO - 2019-01-10 14:21:11 --> Database Driver Class Initialized
INFO - 2019-01-10 14:21:11 --> Controller Class Initialized
INFO - 2019-01-10 14:21:11 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-10 14:21:11 --> Final output sent to browser
DEBUG - 2019-01-10 14:21:11 --> Total execution time: 0.1803
INFO - 2019-01-10 14:21:28 --> Config Class Initialized
INFO - 2019-01-10 14:21:28 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:21:28 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:21:28 --> Utf8 Class Initialized
INFO - 2019-01-10 14:21:28 --> URI Class Initialized
INFO - 2019-01-10 14:21:28 --> Router Class Initialized
INFO - 2019-01-10 14:21:28 --> Output Class Initialized
INFO - 2019-01-10 14:21:28 --> Security Class Initialized
DEBUG - 2019-01-10 14:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:21:28 --> Input Class Initialized
INFO - 2019-01-10 14:21:28 --> Language Class Initialized
INFO - 2019-01-10 14:21:29 --> Loader Class Initialized
INFO - 2019-01-10 14:21:29 --> Helper loaded: url_helper
INFO - 2019-01-10 14:21:29 --> Helper loaded: html_helper
INFO - 2019-01-10 14:21:29 --> Helper loaded: form_helper
INFO - 2019-01-10 14:21:29 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:21:29 --> Helper loaded: date_helper
INFO - 2019-01-10 14:21:29 --> Form Validation Class Initialized
INFO - 2019-01-10 14:21:29 --> Email Class Initialized
DEBUG - 2019-01-10 14:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:21:29 --> Pagination Class Initialized
INFO - 2019-01-10 14:21:29 --> Database Driver Class Initialized
INFO - 2019-01-10 14:21:29 --> Database Driver Class Initialized
INFO - 2019-01-10 14:21:29 --> Controller Class Initialized
INFO - 2019-01-10 14:21:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-01-10 14:21:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation_group.php
INFO - 2019-01-10 14:21:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-01-10 14:21:29 --> Final output sent to browser
DEBUG - 2019-01-10 14:21:29 --> Total execution time: 0.2175
INFO - 2019-01-10 14:21:29 --> Config Class Initialized
INFO - 2019-01-10 14:21:29 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:21:29 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:21:29 --> Utf8 Class Initialized
INFO - 2019-01-10 14:21:29 --> URI Class Initialized
INFO - 2019-01-10 14:21:29 --> Router Class Initialized
INFO - 2019-01-10 14:21:29 --> Output Class Initialized
INFO - 2019-01-10 14:21:29 --> Security Class Initialized
INFO - 2019-01-10 14:21:29 --> Config Class Initialized
INFO - 2019-01-10 14:21:29 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:21:29 --> Input Class Initialized
INFO - 2019-01-10 14:21:29 --> Language Class Initialized
DEBUG - 2019-01-10 14:21:29 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:21:29 --> Utf8 Class Initialized
INFO - 2019-01-10 14:21:29 --> URI Class Initialized
INFO - 2019-01-10 14:21:29 --> Loader Class Initialized
INFO - 2019-01-10 14:21:29 --> Router Class Initialized
INFO - 2019-01-10 14:21:29 --> Helper loaded: url_helper
INFO - 2019-01-10 14:21:29 --> Output Class Initialized
INFO - 2019-01-10 14:21:29 --> Helper loaded: html_helper
INFO - 2019-01-10 14:21:29 --> Security Class Initialized
INFO - 2019-01-10 14:21:29 --> Helper loaded: form_helper
DEBUG - 2019-01-10 14:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:21:29 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:21:29 --> Input Class Initialized
INFO - 2019-01-10 14:21:29 --> Language Class Initialized
INFO - 2019-01-10 14:21:29 --> Helper loaded: date_helper
INFO - 2019-01-10 14:21:29 --> Form Validation Class Initialized
INFO - 2019-01-10 14:21:29 --> Email Class Initialized
DEBUG - 2019-01-10 14:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:21:29 --> Pagination Class Initialized
INFO - 2019-01-10 14:21:29 --> Loader Class Initialized
INFO - 2019-01-10 14:21:29 --> Helper loaded: url_helper
INFO - 2019-01-10 14:21:29 --> Helper loaded: html_helper
INFO - 2019-01-10 14:21:29 --> Database Driver Class Initialized
INFO - 2019-01-10 14:21:29 --> Database Driver Class Initialized
INFO - 2019-01-10 14:21:29 --> Helper loaded: form_helper
INFO - 2019-01-10 14:21:29 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:21:29 --> Controller Class Initialized
INFO - 2019-01-10 14:21:29 --> Helper loaded: date_helper
INFO - 2019-01-10 14:21:29 --> Form Validation Class Initialized
INFO - 2019-01-10 14:21:29 --> Email Class Initialized
INFO - 2019-01-10 14:21:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
DEBUG - 2019-01-10 14:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:21:29 --> Final output sent to browser
DEBUG - 2019-01-10 14:21:29 --> Total execution time: 0.0934
INFO - 2019-01-10 14:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:21:29 --> Pagination Class Initialized
INFO - 2019-01-10 14:21:29 --> Database Driver Class Initialized
INFO - 2019-01-10 14:21:29 --> Database Driver Class Initialized
INFO - 2019-01-10 14:21:29 --> Controller Class Initialized
INFO - 2019-01-10 14:21:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-10 14:21:29 --> Final output sent to browser
DEBUG - 2019-01-10 14:21:29 --> Total execution time: 0.1781
INFO - 2019-01-10 14:22:37 --> Config Class Initialized
INFO - 2019-01-10 14:22:37 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:22:37 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:22:37 --> Utf8 Class Initialized
INFO - 2019-01-10 14:22:37 --> URI Class Initialized
INFO - 2019-01-10 14:22:37 --> Router Class Initialized
INFO - 2019-01-10 14:22:37 --> Output Class Initialized
INFO - 2019-01-10 14:22:37 --> Security Class Initialized
DEBUG - 2019-01-10 14:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:22:37 --> Input Class Initialized
INFO - 2019-01-10 14:22:37 --> Language Class Initialized
INFO - 2019-01-10 14:22:37 --> Loader Class Initialized
INFO - 2019-01-10 14:22:37 --> Helper loaded: url_helper
INFO - 2019-01-10 14:22:37 --> Helper loaded: html_helper
INFO - 2019-01-10 14:22:37 --> Helper loaded: form_helper
INFO - 2019-01-10 14:22:37 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:22:37 --> Helper loaded: date_helper
INFO - 2019-01-10 14:22:37 --> Form Validation Class Initialized
INFO - 2019-01-10 14:22:37 --> Email Class Initialized
DEBUG - 2019-01-10 14:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:22:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:22:37 --> Pagination Class Initialized
INFO - 2019-01-10 14:22:37 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:37 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:37 --> Controller Class Initialized
INFO - 2019-01-10 14:22:37 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-10 14:22:37 --> Final output sent to browser
DEBUG - 2019-01-10 14:22:37 --> Total execution time: 0.0883
INFO - 2019-01-10 14:22:39 --> Config Class Initialized
INFO - 2019-01-10 14:22:39 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:22:39 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:22:39 --> Utf8 Class Initialized
INFO - 2019-01-10 14:22:39 --> URI Class Initialized
INFO - 2019-01-10 14:22:39 --> Router Class Initialized
INFO - 2019-01-10 14:22:39 --> Output Class Initialized
INFO - 2019-01-10 14:22:39 --> Security Class Initialized
DEBUG - 2019-01-10 14:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:22:39 --> Input Class Initialized
INFO - 2019-01-10 14:22:39 --> Language Class Initialized
INFO - 2019-01-10 14:22:39 --> Loader Class Initialized
INFO - 2019-01-10 14:22:39 --> Helper loaded: url_helper
INFO - 2019-01-10 14:22:39 --> Helper loaded: html_helper
INFO - 2019-01-10 14:22:39 --> Helper loaded: form_helper
INFO - 2019-01-10 14:22:39 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:22:39 --> Helper loaded: date_helper
INFO - 2019-01-10 14:22:39 --> Form Validation Class Initialized
INFO - 2019-01-10 14:22:39 --> Email Class Initialized
DEBUG - 2019-01-10 14:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:22:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:22:39 --> Pagination Class Initialized
INFO - 2019-01-10 14:22:39 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:39 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:39 --> Controller Class Initialized
INFO - 2019-01-10 14:22:39 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-10 14:22:39 --> Final output sent to browser
DEBUG - 2019-01-10 14:22:39 --> Total execution time: 0.1183
INFO - 2019-01-10 14:22:43 --> Config Class Initialized
INFO - 2019-01-10 14:22:43 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:22:43 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:22:43 --> Utf8 Class Initialized
INFO - 2019-01-10 14:22:43 --> URI Class Initialized
INFO - 2019-01-10 14:22:43 --> Router Class Initialized
INFO - 2019-01-10 14:22:43 --> Output Class Initialized
INFO - 2019-01-10 14:22:43 --> Security Class Initialized
DEBUG - 2019-01-10 14:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:22:43 --> Input Class Initialized
INFO - 2019-01-10 14:22:43 --> Language Class Initialized
INFO - 2019-01-10 14:22:43 --> Loader Class Initialized
INFO - 2019-01-10 14:22:43 --> Helper loaded: url_helper
INFO - 2019-01-10 14:22:43 --> Helper loaded: html_helper
INFO - 2019-01-10 14:22:43 --> Helper loaded: form_helper
INFO - 2019-01-10 14:22:43 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:22:43 --> Helper loaded: date_helper
INFO - 2019-01-10 14:22:43 --> Form Validation Class Initialized
INFO - 2019-01-10 14:22:43 --> Email Class Initialized
DEBUG - 2019-01-10 14:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:22:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:22:43 --> Pagination Class Initialized
INFO - 2019-01-10 14:22:43 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:43 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:43 --> Controller Class Initialized
INFO - 2019-01-10 14:22:43 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-01-10 14:22:43 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/nightaudit.php
INFO - 2019-01-10 14:22:43 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-01-10 14:22:43 --> Final output sent to browser
DEBUG - 2019-01-10 14:22:43 --> Total execution time: 0.2107
INFO - 2019-01-10 14:22:43 --> Config Class Initialized
INFO - 2019-01-10 14:22:43 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:22:43 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:22:43 --> Utf8 Class Initialized
INFO - 2019-01-10 14:22:43 --> URI Class Initialized
INFO - 2019-01-10 14:22:43 --> Router Class Initialized
INFO - 2019-01-10 14:22:43 --> Output Class Initialized
INFO - 2019-01-10 14:22:43 --> Security Class Initialized
DEBUG - 2019-01-10 14:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:22:43 --> Input Class Initialized
INFO - 2019-01-10 14:22:43 --> Language Class Initialized
INFO - 2019-01-10 14:22:43 --> Loader Class Initialized
INFO - 2019-01-10 14:22:43 --> Helper loaded: url_helper
INFO - 2019-01-10 14:22:43 --> Helper loaded: html_helper
INFO - 2019-01-10 14:22:43 --> Helper loaded: form_helper
INFO - 2019-01-10 14:22:43 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:22:43 --> Helper loaded: date_helper
INFO - 2019-01-10 14:22:43 --> Form Validation Class Initialized
INFO - 2019-01-10 14:22:43 --> Email Class Initialized
DEBUG - 2019-01-10 14:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:22:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:22:43 --> Pagination Class Initialized
INFO - 2019-01-10 14:22:43 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:43 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:43 --> Controller Class Initialized
INFO - 2019-01-10 14:22:43 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-10 14:22:43 --> Final output sent to browser
DEBUG - 2019-01-10 14:22:43 --> Total execution time: 0.0984
INFO - 2019-01-10 14:22:43 --> Config Class Initialized
INFO - 2019-01-10 14:22:43 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:22:43 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:22:43 --> Utf8 Class Initialized
INFO - 2019-01-10 14:22:43 --> URI Class Initialized
INFO - 2019-01-10 14:22:43 --> Router Class Initialized
INFO - 2019-01-10 14:22:43 --> Output Class Initialized
INFO - 2019-01-10 14:22:43 --> Security Class Initialized
DEBUG - 2019-01-10 14:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:22:43 --> Input Class Initialized
INFO - 2019-01-10 14:22:43 --> Language Class Initialized
INFO - 2019-01-10 14:22:43 --> Loader Class Initialized
INFO - 2019-01-10 14:22:43 --> Helper loaded: url_helper
INFO - 2019-01-10 14:22:43 --> Helper loaded: html_helper
INFO - 2019-01-10 14:22:43 --> Helper loaded: form_helper
INFO - 2019-01-10 14:22:43 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:22:43 --> Helper loaded: date_helper
INFO - 2019-01-10 14:22:43 --> Form Validation Class Initialized
INFO - 2019-01-10 14:22:43 --> Email Class Initialized
DEBUG - 2019-01-10 14:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:22:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:22:43 --> Pagination Class Initialized
INFO - 2019-01-10 14:22:43 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:43 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:43 --> Controller Class Initialized
INFO - 2019-01-10 14:22:43 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-10 14:22:43 --> Final output sent to browser
DEBUG - 2019-01-10 14:22:43 --> Total execution time: 0.0926
INFO - 2019-01-10 14:22:47 --> Config Class Initialized
INFO - 2019-01-10 14:22:47 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:22:47 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:22:47 --> Utf8 Class Initialized
INFO - 2019-01-10 14:22:47 --> URI Class Initialized
INFO - 2019-01-10 14:22:47 --> Router Class Initialized
INFO - 2019-01-10 14:22:47 --> Output Class Initialized
INFO - 2019-01-10 14:22:47 --> Security Class Initialized
DEBUG - 2019-01-10 14:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:22:47 --> Input Class Initialized
INFO - 2019-01-10 14:22:47 --> Language Class Initialized
INFO - 2019-01-10 14:22:47 --> Loader Class Initialized
INFO - 2019-01-10 14:22:47 --> Helper loaded: url_helper
INFO - 2019-01-10 14:22:47 --> Helper loaded: html_helper
INFO - 2019-01-10 14:22:47 --> Helper loaded: form_helper
INFO - 2019-01-10 14:22:47 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:22:47 --> Helper loaded: date_helper
INFO - 2019-01-10 14:22:47 --> Form Validation Class Initialized
INFO - 2019-01-10 14:22:47 --> Email Class Initialized
DEBUG - 2019-01-10 14:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:22:47 --> Pagination Class Initialized
INFO - 2019-01-10 14:22:47 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:47 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:47 --> Controller Class Initialized
INFO - 2019-01-10 14:22:47 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-01-10 14:22:47 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/terminals.php
INFO - 2019-01-10 14:22:47 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-01-10 14:22:47 --> Final output sent to browser
DEBUG - 2019-01-10 14:22:47 --> Total execution time: 0.1144
INFO - 2019-01-10 14:22:47 --> Config Class Initialized
INFO - 2019-01-10 14:22:47 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:22:47 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:22:47 --> Utf8 Class Initialized
INFO - 2019-01-10 14:22:47 --> URI Class Initialized
INFO - 2019-01-10 14:22:47 --> Router Class Initialized
INFO - 2019-01-10 14:22:47 --> Output Class Initialized
INFO - 2019-01-10 14:22:47 --> Security Class Initialized
DEBUG - 2019-01-10 14:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:22:47 --> Input Class Initialized
INFO - 2019-01-10 14:22:47 --> Language Class Initialized
INFO - 2019-01-10 14:22:47 --> Loader Class Initialized
INFO - 2019-01-10 14:22:47 --> Helper loaded: url_helper
INFO - 2019-01-10 14:22:47 --> Helper loaded: html_helper
INFO - 2019-01-10 14:22:47 --> Helper loaded: form_helper
INFO - 2019-01-10 14:22:47 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:22:47 --> Helper loaded: date_helper
INFO - 2019-01-10 14:22:47 --> Form Validation Class Initialized
INFO - 2019-01-10 14:22:47 --> Email Class Initialized
DEBUG - 2019-01-10 14:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:22:47 --> Pagination Class Initialized
INFO - 2019-01-10 14:22:47 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:47 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:47 --> Controller Class Initialized
INFO - 2019-01-10 14:22:47 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-10 14:22:47 --> Final output sent to browser
DEBUG - 2019-01-10 14:22:47 --> Total execution time: 0.0938
INFO - 2019-01-10 14:22:47 --> Config Class Initialized
INFO - 2019-01-10 14:22:47 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:22:47 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:22:47 --> Utf8 Class Initialized
INFO - 2019-01-10 14:22:47 --> URI Class Initialized
INFO - 2019-01-10 14:22:47 --> Router Class Initialized
INFO - 2019-01-10 14:22:47 --> Output Class Initialized
INFO - 2019-01-10 14:22:47 --> Security Class Initialized
DEBUG - 2019-01-10 14:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:22:47 --> Input Class Initialized
INFO - 2019-01-10 14:22:47 --> Language Class Initialized
INFO - 2019-01-10 14:22:47 --> Loader Class Initialized
INFO - 2019-01-10 14:22:47 --> Helper loaded: url_helper
INFO - 2019-01-10 14:22:47 --> Helper loaded: html_helper
INFO - 2019-01-10 14:22:47 --> Helper loaded: form_helper
INFO - 2019-01-10 14:22:47 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:22:47 --> Helper loaded: date_helper
INFO - 2019-01-10 14:22:47 --> Form Validation Class Initialized
INFO - 2019-01-10 14:22:47 --> Email Class Initialized
DEBUG - 2019-01-10 14:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:22:47 --> Pagination Class Initialized
INFO - 2019-01-10 14:22:47 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:47 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:47 --> Controller Class Initialized
INFO - 2019-01-10 14:22:47 --> Final output sent to browser
DEBUG - 2019-01-10 14:22:47 --> Total execution time: 0.1960
INFO - 2019-01-10 14:22:48 --> Config Class Initialized
INFO - 2019-01-10 14:22:48 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:22:48 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:22:48 --> Utf8 Class Initialized
INFO - 2019-01-10 14:22:48 --> URI Class Initialized
INFO - 2019-01-10 14:22:48 --> Router Class Initialized
INFO - 2019-01-10 14:22:48 --> Output Class Initialized
INFO - 2019-01-10 14:22:48 --> Security Class Initialized
DEBUG - 2019-01-10 14:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:22:48 --> Input Class Initialized
INFO - 2019-01-10 14:22:48 --> Language Class Initialized
INFO - 2019-01-10 14:22:48 --> Loader Class Initialized
INFO - 2019-01-10 14:22:48 --> Helper loaded: url_helper
INFO - 2019-01-10 14:22:48 --> Helper loaded: html_helper
INFO - 2019-01-10 14:22:48 --> Helper loaded: form_helper
INFO - 2019-01-10 14:22:48 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:22:48 --> Helper loaded: date_helper
INFO - 2019-01-10 14:22:48 --> Form Validation Class Initialized
INFO - 2019-01-10 14:22:48 --> Email Class Initialized
DEBUG - 2019-01-10 14:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:22:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:22:48 --> Pagination Class Initialized
INFO - 2019-01-10 14:22:48 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:48 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:48 --> Controller Class Initialized
INFO - 2019-01-10 14:22:48 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-10 14:22:48 --> Final output sent to browser
DEBUG - 2019-01-10 14:22:48 --> Total execution time: 0.1059
INFO - 2019-01-10 14:22:49 --> Config Class Initialized
INFO - 2019-01-10 14:22:49 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:22:49 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:22:49 --> Utf8 Class Initialized
INFO - 2019-01-10 14:22:49 --> URI Class Initialized
INFO - 2019-01-10 14:22:49 --> Router Class Initialized
INFO - 2019-01-10 14:22:49 --> Output Class Initialized
INFO - 2019-01-10 14:22:49 --> Security Class Initialized
DEBUG - 2019-01-10 14:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:22:49 --> Input Class Initialized
INFO - 2019-01-10 14:22:49 --> Language Class Initialized
INFO - 2019-01-10 14:22:49 --> Loader Class Initialized
INFO - 2019-01-10 14:22:49 --> Helper loaded: url_helper
INFO - 2019-01-10 14:22:49 --> Helper loaded: html_helper
INFO - 2019-01-10 14:22:49 --> Helper loaded: form_helper
INFO - 2019-01-10 14:22:49 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:22:49 --> Helper loaded: date_helper
INFO - 2019-01-10 14:22:49 --> Form Validation Class Initialized
INFO - 2019-01-10 14:22:49 --> Email Class Initialized
DEBUG - 2019-01-10 14:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:22:49 --> Pagination Class Initialized
INFO - 2019-01-10 14:22:49 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:49 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:49 --> Controller Class Initialized
INFO - 2019-01-10 14:22:49 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-10 14:22:49 --> Final output sent to browser
DEBUG - 2019-01-10 14:22:49 --> Total execution time: 0.0973
INFO - 2019-01-10 14:22:50 --> Config Class Initialized
INFO - 2019-01-10 14:22:50 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:22:50 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:22:50 --> Utf8 Class Initialized
INFO - 2019-01-10 14:22:50 --> URI Class Initialized
INFO - 2019-01-10 14:22:50 --> Router Class Initialized
INFO - 2019-01-10 14:22:50 --> Output Class Initialized
INFO - 2019-01-10 14:22:50 --> Security Class Initialized
DEBUG - 2019-01-10 14:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:22:50 --> Input Class Initialized
INFO - 2019-01-10 14:22:50 --> Language Class Initialized
INFO - 2019-01-10 14:22:50 --> Loader Class Initialized
INFO - 2019-01-10 14:22:50 --> Helper loaded: url_helper
INFO - 2019-01-10 14:22:50 --> Helper loaded: html_helper
INFO - 2019-01-10 14:22:50 --> Helper loaded: form_helper
INFO - 2019-01-10 14:22:50 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:22:50 --> Helper loaded: date_helper
INFO - 2019-01-10 14:22:50 --> Form Validation Class Initialized
INFO - 2019-01-10 14:22:50 --> Email Class Initialized
DEBUG - 2019-01-10 14:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:22:50 --> Pagination Class Initialized
INFO - 2019-01-10 14:22:50 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:50 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:50 --> Controller Class Initialized
INFO - 2019-01-10 14:22:50 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-10 14:22:50 --> Final output sent to browser
DEBUG - 2019-01-10 14:22:50 --> Total execution time: 0.0927
INFO - 2019-01-10 14:22:51 --> Config Class Initialized
INFO - 2019-01-10 14:22:51 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:22:51 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:22:51 --> Utf8 Class Initialized
INFO - 2019-01-10 14:22:51 --> URI Class Initialized
INFO - 2019-01-10 14:22:51 --> Router Class Initialized
INFO - 2019-01-10 14:22:51 --> Output Class Initialized
INFO - 2019-01-10 14:22:51 --> Security Class Initialized
DEBUG - 2019-01-10 14:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:22:51 --> Input Class Initialized
INFO - 2019-01-10 14:22:51 --> Language Class Initialized
INFO - 2019-01-10 14:22:51 --> Loader Class Initialized
INFO - 2019-01-10 14:22:51 --> Helper loaded: url_helper
INFO - 2019-01-10 14:22:51 --> Helper loaded: html_helper
INFO - 2019-01-10 14:22:51 --> Helper loaded: form_helper
INFO - 2019-01-10 14:22:51 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:22:51 --> Helper loaded: date_helper
INFO - 2019-01-10 14:22:51 --> Form Validation Class Initialized
INFO - 2019-01-10 14:22:51 --> Email Class Initialized
DEBUG - 2019-01-10 14:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:22:51 --> Pagination Class Initialized
INFO - 2019-01-10 14:22:51 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:51 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:51 --> Controller Class Initialized
INFO - 2019-01-10 14:22:51 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-01-10 14:22:51 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-01-10 14:22:51 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-01-10 14:22:51 --> Final output sent to browser
DEBUG - 2019-01-10 14:22:51 --> Total execution time: 0.4657
INFO - 2019-01-10 14:22:51 --> Config Class Initialized
INFO - 2019-01-10 14:22:51 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:22:51 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:22:51 --> Utf8 Class Initialized
INFO - 2019-01-10 14:22:51 --> URI Class Initialized
INFO - 2019-01-10 14:22:51 --> Router Class Initialized
INFO - 2019-01-10 14:22:51 --> Output Class Initialized
INFO - 2019-01-10 14:22:51 --> Security Class Initialized
DEBUG - 2019-01-10 14:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:22:51 --> Input Class Initialized
INFO - 2019-01-10 14:22:51 --> Language Class Initialized
INFO - 2019-01-10 14:22:51 --> Loader Class Initialized
INFO - 2019-01-10 14:22:51 --> Helper loaded: url_helper
INFO - 2019-01-10 14:22:51 --> Helper loaded: html_helper
INFO - 2019-01-10 14:22:51 --> Helper loaded: form_helper
INFO - 2019-01-10 14:22:51 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:22:51 --> Helper loaded: date_helper
INFO - 2019-01-10 14:22:51 --> Form Validation Class Initialized
INFO - 2019-01-10 14:22:51 --> Email Class Initialized
DEBUG - 2019-01-10 14:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:22:51 --> Pagination Class Initialized
INFO - 2019-01-10 14:22:51 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:51 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:51 --> Controller Class Initialized
INFO - 2019-01-10 14:22:51 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-10 14:22:51 --> Final output sent to browser
DEBUG - 2019-01-10 14:22:51 --> Total execution time: 0.1032
INFO - 2019-01-10 14:22:51 --> Config Class Initialized
INFO - 2019-01-10 14:22:51 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:22:51 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:22:51 --> Utf8 Class Initialized
INFO - 2019-01-10 14:22:51 --> URI Class Initialized
INFO - 2019-01-10 14:22:51 --> Router Class Initialized
INFO - 2019-01-10 14:22:51 --> Output Class Initialized
INFO - 2019-01-10 14:22:51 --> Security Class Initialized
DEBUG - 2019-01-10 14:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:22:51 --> Input Class Initialized
INFO - 2019-01-10 14:22:51 --> Language Class Initialized
INFO - 2019-01-10 14:22:51 --> Loader Class Initialized
INFO - 2019-01-10 14:22:51 --> Helper loaded: url_helper
INFO - 2019-01-10 14:22:51 --> Helper loaded: html_helper
INFO - 2019-01-10 14:22:51 --> Helper loaded: form_helper
INFO - 2019-01-10 14:22:51 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:22:51 --> Helper loaded: date_helper
INFO - 2019-01-10 14:22:51 --> Form Validation Class Initialized
INFO - 2019-01-10 14:22:51 --> Email Class Initialized
DEBUG - 2019-01-10 14:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:22:51 --> Pagination Class Initialized
INFO - 2019-01-10 14:22:51 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:51 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:51 --> Controller Class Initialized
INFO - 2019-01-10 14:22:51 --> Final output sent to browser
DEBUG - 2019-01-10 14:22:51 --> Total execution time: 0.1023
INFO - 2019-01-10 14:22:59 --> Config Class Initialized
INFO - 2019-01-10 14:22:59 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:22:59 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:22:59 --> Utf8 Class Initialized
INFO - 2019-01-10 14:22:59 --> URI Class Initialized
INFO - 2019-01-10 14:22:59 --> Router Class Initialized
INFO - 2019-01-10 14:22:59 --> Output Class Initialized
INFO - 2019-01-10 14:22:59 --> Security Class Initialized
DEBUG - 2019-01-10 14:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:22:59 --> Input Class Initialized
INFO - 2019-01-10 14:22:59 --> Language Class Initialized
INFO - 2019-01-10 14:22:59 --> Loader Class Initialized
INFO - 2019-01-10 14:22:59 --> Helper loaded: url_helper
INFO - 2019-01-10 14:22:59 --> Helper loaded: html_helper
INFO - 2019-01-10 14:22:59 --> Helper loaded: form_helper
INFO - 2019-01-10 14:22:59 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:22:59 --> Helper loaded: date_helper
INFO - 2019-01-10 14:22:59 --> Form Validation Class Initialized
INFO - 2019-01-10 14:22:59 --> Email Class Initialized
DEBUG - 2019-01-10 14:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:22:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:22:59 --> Pagination Class Initialized
INFO - 2019-01-10 14:22:59 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:59 --> Database Driver Class Initialized
INFO - 2019-01-10 14:22:59 --> Controller Class Initialized
INFO - 2019-01-10 14:22:59 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-10 14:22:59 --> Final output sent to browser
DEBUG - 2019-01-10 14:22:59 --> Total execution time: 0.0883
INFO - 2019-01-10 14:35:18 --> Config Class Initialized
INFO - 2019-01-10 14:35:18 --> Hooks Class Initialized
DEBUG - 2019-01-10 14:35:19 --> UTF-8 Support Enabled
INFO - 2019-01-10 14:35:20 --> Utf8 Class Initialized
INFO - 2019-01-10 14:35:20 --> URI Class Initialized
DEBUG - 2019-01-10 14:35:20 --> No URI present. Default controller set.
INFO - 2019-01-10 14:35:20 --> Router Class Initialized
INFO - 2019-01-10 14:35:21 --> Output Class Initialized
INFO - 2019-01-10 14:35:21 --> Security Class Initialized
DEBUG - 2019-01-10 14:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-10 14:35:22 --> Input Class Initialized
INFO - 2019-01-10 14:35:22 --> Language Class Initialized
INFO - 2019-01-10 14:35:24 --> Loader Class Initialized
INFO - 2019-01-10 14:35:26 --> Helper loaded: url_helper
INFO - 2019-01-10 14:35:26 --> Helper loaded: html_helper
INFO - 2019-01-10 14:35:26 --> Helper loaded: form_helper
INFO - 2019-01-10 14:35:26 --> Helper loaded: cookie_helper
INFO - 2019-01-10 14:35:26 --> Helper loaded: date_helper
INFO - 2019-01-10 14:35:26 --> Form Validation Class Initialized
INFO - 2019-01-10 14:35:27 --> Email Class Initialized
DEBUG - 2019-01-10 14:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-10 14:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-10 14:35:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-10 14:35:30 --> Pagination Class Initialized
INFO - 2019-01-10 14:35:32 --> Database Driver Class Initialized
INFO - 2019-01-10 14:35:32 --> Database Driver Class Initialized
INFO - 2019-01-10 14:35:35 --> Language file loaded: language/english/db_lang.php
