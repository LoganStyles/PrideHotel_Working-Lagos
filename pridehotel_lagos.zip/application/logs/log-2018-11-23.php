<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-23 17:47:11 --> Config Class Initialized
INFO - 2018-11-23 17:47:11 --> Hooks Class Initialized
DEBUG - 2018-11-23 17:47:12 --> UTF-8 Support Enabled
INFO - 2018-11-23 17:47:12 --> Utf8 Class Initialized
INFO - 2018-11-23 17:47:12 --> URI Class Initialized
INFO - 2018-11-23 17:47:12 --> Router Class Initialized
INFO - 2018-11-23 17:47:12 --> Output Class Initialized
INFO - 2018-11-23 17:47:12 --> Security Class Initialized
DEBUG - 2018-11-23 17:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-23 17:47:12 --> Input Class Initialized
INFO - 2018-11-23 17:47:12 --> Language Class Initialized
INFO - 2018-11-23 17:47:13 --> Loader Class Initialized
INFO - 2018-11-23 17:47:13 --> Helper loaded: url_helper
INFO - 2018-11-23 17:47:13 --> Helper loaded: html_helper
INFO - 2018-11-23 17:47:13 --> Helper loaded: form_helper
INFO - 2018-11-23 17:47:13 --> Helper loaded: cookie_helper
INFO - 2018-11-23 17:47:13 --> Helper loaded: date_helper
INFO - 2018-11-23 17:47:13 --> Form Validation Class Initialized
INFO - 2018-11-23 17:47:13 --> Email Class Initialized
DEBUG - 2018-11-23 17:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-23 17:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-23 17:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-23 17:47:13 --> Pagination Class Initialized
INFO - 2018-11-23 17:47:14 --> Database Driver Class Initialized
INFO - 2018-11-23 17:47:14 --> Database Driver Class Initialized
INFO - 2018-11-23 17:47:15 --> Controller Class Initialized
INFO - 2018-11-23 17:47:15 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-23 17:47:15 --> Final output sent to browser
DEBUG - 2018-11-23 17:47:15 --> Total execution time: 4.7981
