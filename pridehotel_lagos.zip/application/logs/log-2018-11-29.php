<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-11-29 19:38:28 --> Config Class Initialized
INFO - 2018-11-29 19:38:28 --> Hooks Class Initialized
DEBUG - 2018-11-29 19:38:28 --> UTF-8 Support Enabled
INFO - 2018-11-29 19:38:28 --> Utf8 Class Initialized
INFO - 2018-11-29 19:38:28 --> URI Class Initialized
DEBUG - 2018-11-29 19:38:28 --> No URI present. Default controller set.
INFO - 2018-11-29 19:38:28 --> Router Class Initialized
INFO - 2018-11-29 19:38:28 --> Output Class Initialized
INFO - 2018-11-29 19:38:28 --> Security Class Initialized
DEBUG - 2018-11-29 19:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-11-29 19:38:28 --> Input Class Initialized
INFO - 2018-11-29 19:38:28 --> Language Class Initialized
INFO - 2018-11-29 19:38:29 --> Loader Class Initialized
INFO - 2018-11-29 19:38:29 --> Helper loaded: url_helper
INFO - 2018-11-29 19:38:29 --> Helper loaded: html_helper
INFO - 2018-11-29 19:38:29 --> Helper loaded: form_helper
INFO - 2018-11-29 19:38:29 --> Helper loaded: cookie_helper
INFO - 2018-11-29 19:38:29 --> Helper loaded: date_helper
INFO - 2018-11-29 19:38:29 --> Form Validation Class Initialized
INFO - 2018-11-29 19:38:29 --> Email Class Initialized
DEBUG - 2018-11-29 19:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-11-29 19:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-11-29 19:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-11-29 19:38:29 --> Pagination Class Initialized
INFO - 2018-11-29 19:38:29 --> Database Driver Class Initialized
INFO - 2018-11-29 19:38:29 --> Database Driver Class Initialized
INFO - 2018-11-29 19:38:29 --> Controller Class Initialized
INFO - 2018-11-29 19:38:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-11-29 19:38:29 --> Final output sent to browser
DEBUG - 2018-11-29 19:38:29 --> Total execution time: 1.1665
