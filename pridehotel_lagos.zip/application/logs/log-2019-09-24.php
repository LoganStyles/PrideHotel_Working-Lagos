<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-24 07:32:00 --> Config Class Initialized
INFO - 2019-09-24 07:32:00 --> Hooks Class Initialized
DEBUG - 2019-09-24 07:32:00 --> UTF-8 Support Enabled
INFO - 2019-09-24 07:32:00 --> Utf8 Class Initialized
INFO - 2019-09-24 07:32:00 --> URI Class Initialized
INFO - 2019-09-24 07:32:00 --> Router Class Initialized
INFO - 2019-09-24 07:32:00 --> Output Class Initialized
INFO - 2019-09-24 07:32:00 --> Security Class Initialized
DEBUG - 2019-09-24 07:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-24 07:32:00 --> Input Class Initialized
INFO - 2019-09-24 07:32:00 --> Language Class Initialized
INFO - 2019-09-24 07:32:01 --> Loader Class Initialized
INFO - 2019-09-24 07:32:01 --> Helper loaded: url_helper
INFO - 2019-09-24 07:32:01 --> Helper loaded: html_helper
INFO - 2019-09-24 07:32:01 --> Helper loaded: form_helper
INFO - 2019-09-24 07:32:01 --> Helper loaded: cookie_helper
INFO - 2019-09-24 07:32:01 --> Helper loaded: date_helper
INFO - 2019-09-24 07:32:01 --> Form Validation Class Initialized
INFO - 2019-09-24 07:32:01 --> Email Class Initialized
DEBUG - 2019-09-24 07:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-24 07:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-24 07:32:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-24 07:32:02 --> Pagination Class Initialized
INFO - 2019-09-24 07:32:02 --> Database Driver Class Initialized
INFO - 2019-09-24 07:32:02 --> Database Driver Class Initialized
INFO - 2019-09-24 07:32:03 --> Controller Class Initialized
DEBUG - 2019-09-24 07:32:03 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-24 07:32:03 --> Helper loaded: inflector_helper
INFO - 2019-09-24 07:32:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-24 07:32:03 --> Final output sent to browser
DEBUG - 2019-09-24 07:32:03 --> Total execution time: 3.1711
