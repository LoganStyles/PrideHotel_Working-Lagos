<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-29 16:16:36 --> Config Class Initialized
INFO - 2019-09-29 16:16:36 --> Hooks Class Initialized
DEBUG - 2019-09-29 16:16:36 --> UTF-8 Support Enabled
INFO - 2019-09-29 16:16:36 --> Utf8 Class Initialized
INFO - 2019-09-29 16:16:36 --> URI Class Initialized
INFO - 2019-09-29 16:16:36 --> Router Class Initialized
INFO - 2019-09-29 16:16:36 --> Output Class Initialized
INFO - 2019-09-29 16:16:36 --> Security Class Initialized
DEBUG - 2019-09-29 16:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-29 16:16:36 --> Input Class Initialized
INFO - 2019-09-29 16:16:36 --> Language Class Initialized
INFO - 2019-09-29 16:16:36 --> Loader Class Initialized
INFO - 2019-09-29 16:16:36 --> Helper loaded: url_helper
INFO - 2019-09-29 16:16:36 --> Helper loaded: html_helper
INFO - 2019-09-29 16:16:36 --> Helper loaded: form_helper
INFO - 2019-09-29 16:16:36 --> Helper loaded: cookie_helper
INFO - 2019-09-29 16:16:36 --> Helper loaded: date_helper
INFO - 2019-09-29 16:16:36 --> Form Validation Class Initialized
INFO - 2019-09-29 16:16:36 --> Email Class Initialized
DEBUG - 2019-09-29 16:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-29 16:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-29 16:16:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-29 16:16:36 --> Pagination Class Initialized
INFO - 2019-09-29 16:16:36 --> Database Driver Class Initialized
INFO - 2019-09-29 16:16:36 --> Database Driver Class Initialized
INFO - 2019-09-29 16:16:36 --> Controller Class Initialized
DEBUG - 2019-09-29 16:16:36 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-29 16:16:36 --> Helper loaded: inflector_helper
INFO - 2019-09-29 16:16:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-29 16:16:36 --> Final output sent to browser
DEBUG - 2019-09-29 16:16:36 --> Total execution time: 1.0155
INFO - 2019-09-29 16:58:57 --> Config Class Initialized
INFO - 2019-09-29 16:58:57 --> Hooks Class Initialized
DEBUG - 2019-09-29 16:58:57 --> UTF-8 Support Enabled
INFO - 2019-09-29 16:58:57 --> Utf8 Class Initialized
INFO - 2019-09-29 16:58:57 --> URI Class Initialized
INFO - 2019-09-29 16:58:57 --> Router Class Initialized
INFO - 2019-09-29 16:58:57 --> Output Class Initialized
INFO - 2019-09-29 16:58:57 --> Security Class Initialized
DEBUG - 2019-09-29 16:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-29 16:58:57 --> Input Class Initialized
INFO - 2019-09-29 16:58:57 --> Language Class Initialized
INFO - 2019-09-29 16:58:57 --> Loader Class Initialized
INFO - 2019-09-29 16:58:57 --> Helper loaded: url_helper
INFO - 2019-09-29 16:58:57 --> Helper loaded: html_helper
INFO - 2019-09-29 16:58:57 --> Helper loaded: form_helper
INFO - 2019-09-29 16:58:57 --> Helper loaded: cookie_helper
INFO - 2019-09-29 16:58:57 --> Helper loaded: date_helper
INFO - 2019-09-29 16:58:57 --> Form Validation Class Initialized
INFO - 2019-09-29 16:58:57 --> Email Class Initialized
DEBUG - 2019-09-29 16:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-29 16:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-29 16:58:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-29 16:58:57 --> Pagination Class Initialized
INFO - 2019-09-29 16:58:57 --> Database Driver Class Initialized
INFO - 2019-09-29 16:58:57 --> Database Driver Class Initialized
INFO - 2019-09-29 16:58:57 --> Controller Class Initialized
DEBUG - 2019-09-29 16:58:57 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-29 16:58:57 --> Helper loaded: inflector_helper
INFO - 2019-09-29 16:58:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-29 16:58:57 --> Final output sent to browser
DEBUG - 2019-09-29 16:58:57 --> Total execution time: 0.1958
INFO - 2019-09-29 17:34:51 --> Config Class Initialized
INFO - 2019-09-29 17:34:51 --> Hooks Class Initialized
DEBUG - 2019-09-29 17:34:51 --> UTF-8 Support Enabled
INFO - 2019-09-29 17:34:51 --> Utf8 Class Initialized
INFO - 2019-09-29 17:34:51 --> URI Class Initialized
INFO - 2019-09-29 17:34:51 --> Router Class Initialized
INFO - 2019-09-29 17:34:51 --> Output Class Initialized
INFO - 2019-09-29 17:34:51 --> Security Class Initialized
DEBUG - 2019-09-29 17:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-29 17:34:51 --> Input Class Initialized
INFO - 2019-09-29 17:34:51 --> Language Class Initialized
INFO - 2019-09-29 17:34:51 --> Loader Class Initialized
INFO - 2019-09-29 17:34:51 --> Helper loaded: url_helper
INFO - 2019-09-29 17:34:51 --> Helper loaded: html_helper
INFO - 2019-09-29 17:34:51 --> Helper loaded: form_helper
INFO - 2019-09-29 17:34:51 --> Helper loaded: cookie_helper
INFO - 2019-09-29 17:34:51 --> Helper loaded: date_helper
INFO - 2019-09-29 17:34:51 --> Form Validation Class Initialized
INFO - 2019-09-29 17:34:51 --> Email Class Initialized
DEBUG - 2019-09-29 17:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-29 17:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-29 17:34:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-29 17:34:51 --> Pagination Class Initialized
INFO - 2019-09-29 17:34:51 --> Database Driver Class Initialized
INFO - 2019-09-29 17:34:51 --> Database Driver Class Initialized
INFO - 2019-09-29 17:34:51 --> Controller Class Initialized
DEBUG - 2019-09-29 17:34:51 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-29 17:34:51 --> Helper loaded: inflector_helper
INFO - 2019-09-29 17:34:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-29 17:34:51 --> Final output sent to browser
DEBUG - 2019-09-29 17:34:51 --> Total execution time: 0.0611
INFO - 2019-09-29 20:23:17 --> Config Class Initialized
INFO - 2019-09-29 20:23:17 --> Hooks Class Initialized
DEBUG - 2019-09-29 20:23:17 --> UTF-8 Support Enabled
INFO - 2019-09-29 20:23:17 --> Utf8 Class Initialized
INFO - 2019-09-29 20:23:17 --> URI Class Initialized
INFO - 2019-09-29 20:23:17 --> Router Class Initialized
INFO - 2019-09-29 20:23:17 --> Output Class Initialized
INFO - 2019-09-29 20:23:17 --> Security Class Initialized
DEBUG - 2019-09-29 20:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-29 20:23:17 --> Input Class Initialized
INFO - 2019-09-29 20:23:17 --> Language Class Initialized
INFO - 2019-09-29 20:23:17 --> Loader Class Initialized
INFO - 2019-09-29 20:23:17 --> Helper loaded: url_helper
INFO - 2019-09-29 20:23:17 --> Helper loaded: html_helper
INFO - 2019-09-29 20:23:17 --> Helper loaded: form_helper
INFO - 2019-09-29 20:23:17 --> Helper loaded: cookie_helper
INFO - 2019-09-29 20:23:17 --> Helper loaded: date_helper
INFO - 2019-09-29 20:23:17 --> Form Validation Class Initialized
INFO - 2019-09-29 20:23:17 --> Email Class Initialized
DEBUG - 2019-09-29 20:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-29 20:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-29 20:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-29 20:23:17 --> Pagination Class Initialized
INFO - 2019-09-29 20:23:17 --> Database Driver Class Initialized
INFO - 2019-09-29 20:23:17 --> Database Driver Class Initialized
INFO - 2019-09-29 20:23:17 --> Controller Class Initialized
DEBUG - 2019-09-29 20:23:17 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-29 20:23:17 --> Helper loaded: inflector_helper
INFO - 2019-09-29 20:23:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-29 20:23:17 --> Final output sent to browser
DEBUG - 2019-09-29 20:23:17 --> Total execution time: 0.0897
