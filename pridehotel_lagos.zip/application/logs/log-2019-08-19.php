<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-08-19 09:35:18 --> Config Class Initialized
INFO - 2019-08-19 09:35:18 --> Hooks Class Initialized
DEBUG - 2019-08-19 09:35:18 --> UTF-8 Support Enabled
INFO - 2019-08-19 09:35:18 --> Utf8 Class Initialized
INFO - 2019-08-19 09:35:18 --> URI Class Initialized
DEBUG - 2019-08-19 09:35:18 --> No URI present. Default controller set.
INFO - 2019-08-19 09:35:18 --> Router Class Initialized
INFO - 2019-08-19 09:35:18 --> Output Class Initialized
INFO - 2019-08-19 09:35:18 --> Security Class Initialized
DEBUG - 2019-08-19 09:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 09:35:18 --> Input Class Initialized
INFO - 2019-08-19 09:35:18 --> Language Class Initialized
INFO - 2019-08-19 09:35:18 --> Loader Class Initialized
INFO - 2019-08-19 09:35:18 --> Helper loaded: url_helper
INFO - 2019-08-19 09:35:18 --> Helper loaded: html_helper
INFO - 2019-08-19 09:35:18 --> Helper loaded: form_helper
INFO - 2019-08-19 09:35:18 --> Helper loaded: cookie_helper
INFO - 2019-08-19 09:35:18 --> Helper loaded: date_helper
INFO - 2019-08-19 09:35:18 --> Form Validation Class Initialized
INFO - 2019-08-19 09:35:18 --> Email Class Initialized
DEBUG - 2019-08-19 09:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 09:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 09:35:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 09:35:19 --> Pagination Class Initialized
INFO - 2019-08-19 09:35:19 --> Database Driver Class Initialized
INFO - 2019-08-19 09:35:19 --> Database Driver Class Initialized
INFO - 2019-08-19 09:35:19 --> Controller Class Initialized
INFO - 2019-08-19 09:35:20 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 09:35:20 --> Final output sent to browser
DEBUG - 2019-08-19 09:35:20 --> Total execution time: 1.6868
INFO - 2019-08-19 09:35:21 --> Config Class Initialized
INFO - 2019-08-19 09:35:21 --> Hooks Class Initialized
DEBUG - 2019-08-19 09:35:21 --> UTF-8 Support Enabled
INFO - 2019-08-19 09:35:21 --> Utf8 Class Initialized
INFO - 2019-08-19 09:35:21 --> URI Class Initialized
DEBUG - 2019-08-19 09:35:21 --> No URI present. Default controller set.
INFO - 2019-08-19 09:35:21 --> Router Class Initialized
INFO - 2019-08-19 09:35:21 --> Output Class Initialized
INFO - 2019-08-19 09:35:21 --> Security Class Initialized
DEBUG - 2019-08-19 09:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 09:35:21 --> Input Class Initialized
INFO - 2019-08-19 09:35:21 --> Language Class Initialized
INFO - 2019-08-19 09:35:21 --> Loader Class Initialized
INFO - 2019-08-19 09:35:21 --> Helper loaded: url_helper
INFO - 2019-08-19 09:35:21 --> Helper loaded: html_helper
INFO - 2019-08-19 09:35:21 --> Helper loaded: form_helper
INFO - 2019-08-19 09:35:21 --> Helper loaded: cookie_helper
INFO - 2019-08-19 09:35:21 --> Helper loaded: date_helper
INFO - 2019-08-19 09:35:21 --> Form Validation Class Initialized
INFO - 2019-08-19 09:35:21 --> Email Class Initialized
DEBUG - 2019-08-19 09:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 09:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 09:35:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 09:35:21 --> Pagination Class Initialized
INFO - 2019-08-19 09:35:21 --> Database Driver Class Initialized
INFO - 2019-08-19 09:35:21 --> Database Driver Class Initialized
INFO - 2019-08-19 09:35:21 --> Controller Class Initialized
INFO - 2019-08-19 09:35:21 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 09:35:21 --> Final output sent to browser
DEBUG - 2019-08-19 09:35:21 --> Total execution time: 0.0775
INFO - 2019-08-19 10:40:00 --> Config Class Initialized
INFO - 2019-08-19 10:40:00 --> Hooks Class Initialized
DEBUG - 2019-08-19 10:40:00 --> UTF-8 Support Enabled
INFO - 2019-08-19 10:40:00 --> Utf8 Class Initialized
INFO - 2019-08-19 10:40:00 --> URI Class Initialized
INFO - 2019-08-19 10:40:00 --> Router Class Initialized
INFO - 2019-08-19 10:40:00 --> Output Class Initialized
INFO - 2019-08-19 10:40:00 --> Security Class Initialized
DEBUG - 2019-08-19 10:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 10:40:00 --> Input Class Initialized
INFO - 2019-08-19 10:40:00 --> Language Class Initialized
INFO - 2019-08-19 10:40:00 --> Loader Class Initialized
INFO - 2019-08-19 10:40:00 --> Helper loaded: url_helper
INFO - 2019-08-19 10:40:00 --> Helper loaded: html_helper
INFO - 2019-08-19 10:40:00 --> Helper loaded: form_helper
INFO - 2019-08-19 10:40:00 --> Helper loaded: cookie_helper
INFO - 2019-08-19 10:40:00 --> Helper loaded: date_helper
INFO - 2019-08-19 10:40:00 --> Form Validation Class Initialized
INFO - 2019-08-19 10:40:00 --> Email Class Initialized
DEBUG - 2019-08-19 10:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 10:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 10:40:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 10:40:00 --> Pagination Class Initialized
INFO - 2019-08-19 10:40:00 --> Database Driver Class Initialized
INFO - 2019-08-19 10:40:00 --> Database Driver Class Initialized
INFO - 2019-08-19 10:40:00 --> Controller Class Initialized
INFO - 2019-08-19 10:40:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 10:40:00 --> Config Class Initialized
INFO - 2019-08-19 10:40:00 --> Hooks Class Initialized
DEBUG - 2019-08-19 10:40:00 --> UTF-8 Support Enabled
INFO - 2019-08-19 10:40:00 --> Utf8 Class Initialized
INFO - 2019-08-19 10:40:00 --> URI Class Initialized
INFO - 2019-08-19 10:40:00 --> Router Class Initialized
INFO - 2019-08-19 10:40:00 --> Output Class Initialized
INFO - 2019-08-19 10:40:00 --> Security Class Initialized
DEBUG - 2019-08-19 10:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 10:40:00 --> Input Class Initialized
INFO - 2019-08-19 10:40:00 --> Language Class Initialized
INFO - 2019-08-19 10:40:00 --> Loader Class Initialized
INFO - 2019-08-19 10:40:00 --> Helper loaded: url_helper
INFO - 2019-08-19 10:40:00 --> Helper loaded: html_helper
INFO - 2019-08-19 10:40:00 --> Helper loaded: form_helper
INFO - 2019-08-19 10:40:00 --> Helper loaded: cookie_helper
INFO - 2019-08-19 10:40:00 --> Helper loaded: date_helper
INFO - 2019-08-19 10:40:00 --> Form Validation Class Initialized
INFO - 2019-08-19 10:40:00 --> Email Class Initialized
DEBUG - 2019-08-19 10:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 10:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 10:40:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 10:40:00 --> Pagination Class Initialized
INFO - 2019-08-19 10:40:00 --> Database Driver Class Initialized
INFO - 2019-08-19 10:40:00 --> Database Driver Class Initialized
INFO - 2019-08-19 10:40:00 --> Controller Class Initialized
INFO - 2019-08-19 10:40:00 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 10:40:00 --> Final output sent to browser
DEBUG - 2019-08-19 10:40:00 --> Total execution time: 0.0495
INFO - 2019-08-19 10:52:39 --> Config Class Initialized
INFO - 2019-08-19 10:52:39 --> Hooks Class Initialized
DEBUG - 2019-08-19 10:52:39 --> UTF-8 Support Enabled
INFO - 2019-08-19 10:52:39 --> Utf8 Class Initialized
INFO - 2019-08-19 10:52:39 --> URI Class Initialized
INFO - 2019-08-19 10:52:39 --> Router Class Initialized
INFO - 2019-08-19 10:52:39 --> Output Class Initialized
INFO - 2019-08-19 10:52:39 --> Security Class Initialized
DEBUG - 2019-08-19 10:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 10:52:39 --> Input Class Initialized
INFO - 2019-08-19 10:52:39 --> Language Class Initialized
INFO - 2019-08-19 10:52:39 --> Loader Class Initialized
INFO - 2019-08-19 10:52:39 --> Helper loaded: url_helper
INFO - 2019-08-19 10:52:39 --> Helper loaded: html_helper
INFO - 2019-08-19 10:52:39 --> Helper loaded: form_helper
INFO - 2019-08-19 10:52:39 --> Helper loaded: cookie_helper
INFO - 2019-08-19 10:52:39 --> Helper loaded: date_helper
INFO - 2019-08-19 10:52:39 --> Form Validation Class Initialized
INFO - 2019-08-19 10:52:39 --> Email Class Initialized
DEBUG - 2019-08-19 10:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 10:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 10:52:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 10:52:39 --> Pagination Class Initialized
INFO - 2019-08-19 10:52:39 --> Database Driver Class Initialized
INFO - 2019-08-19 10:52:39 --> Database Driver Class Initialized
INFO - 2019-08-19 10:52:39 --> Controller Class Initialized
INFO - 2019-08-19 10:52:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 10:52:39 --> Config Class Initialized
INFO - 2019-08-19 10:52:39 --> Hooks Class Initialized
DEBUG - 2019-08-19 10:52:39 --> UTF-8 Support Enabled
INFO - 2019-08-19 10:52:39 --> Utf8 Class Initialized
INFO - 2019-08-19 10:52:39 --> URI Class Initialized
INFO - 2019-08-19 10:52:39 --> Router Class Initialized
INFO - 2019-08-19 10:52:39 --> Output Class Initialized
INFO - 2019-08-19 10:52:39 --> Security Class Initialized
DEBUG - 2019-08-19 10:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 10:52:39 --> Input Class Initialized
INFO - 2019-08-19 10:52:39 --> Language Class Initialized
INFO - 2019-08-19 10:52:39 --> Loader Class Initialized
INFO - 2019-08-19 10:52:39 --> Helper loaded: url_helper
INFO - 2019-08-19 10:52:39 --> Helper loaded: html_helper
INFO - 2019-08-19 10:52:39 --> Helper loaded: form_helper
INFO - 2019-08-19 10:52:39 --> Helper loaded: cookie_helper
INFO - 2019-08-19 10:52:39 --> Helper loaded: date_helper
INFO - 2019-08-19 10:52:39 --> Form Validation Class Initialized
INFO - 2019-08-19 10:52:39 --> Email Class Initialized
DEBUG - 2019-08-19 10:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 10:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 10:52:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 10:52:39 --> Pagination Class Initialized
INFO - 2019-08-19 10:52:39 --> Database Driver Class Initialized
INFO - 2019-08-19 10:52:39 --> Database Driver Class Initialized
INFO - 2019-08-19 10:52:39 --> Controller Class Initialized
INFO - 2019-08-19 10:52:39 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 10:52:39 --> Final output sent to browser
DEBUG - 2019-08-19 10:52:39 --> Total execution time: 0.0495
INFO - 2019-08-19 11:05:06 --> Config Class Initialized
INFO - 2019-08-19 11:05:06 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:05:06 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:05:06 --> Utf8 Class Initialized
INFO - 2019-08-19 11:05:06 --> URI Class Initialized
INFO - 2019-08-19 11:05:06 --> Router Class Initialized
INFO - 2019-08-19 11:05:06 --> Output Class Initialized
INFO - 2019-08-19 11:05:06 --> Security Class Initialized
DEBUG - 2019-08-19 11:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:05:06 --> Input Class Initialized
INFO - 2019-08-19 11:05:06 --> Language Class Initialized
INFO - 2019-08-19 11:05:06 --> Loader Class Initialized
INFO - 2019-08-19 11:05:06 --> Helper loaded: url_helper
INFO - 2019-08-19 11:05:06 --> Helper loaded: html_helper
INFO - 2019-08-19 11:05:06 --> Helper loaded: form_helper
INFO - 2019-08-19 11:05:06 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:05:06 --> Helper loaded: date_helper
INFO - 2019-08-19 11:05:06 --> Form Validation Class Initialized
INFO - 2019-08-19 11:05:06 --> Email Class Initialized
DEBUG - 2019-08-19 11:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:05:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:05:06 --> Pagination Class Initialized
INFO - 2019-08-19 11:05:06 --> Database Driver Class Initialized
INFO - 2019-08-19 11:05:06 --> Database Driver Class Initialized
INFO - 2019-08-19 11:05:06 --> Controller Class Initialized
INFO - 2019-08-19 11:05:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 11:08:19 --> Config Class Initialized
INFO - 2019-08-19 11:08:19 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:08:19 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:08:19 --> Utf8 Class Initialized
INFO - 2019-08-19 11:08:19 --> URI Class Initialized
INFO - 2019-08-19 11:08:19 --> Router Class Initialized
INFO - 2019-08-19 11:08:19 --> Output Class Initialized
INFO - 2019-08-19 11:08:19 --> Security Class Initialized
DEBUG - 2019-08-19 11:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:08:19 --> Input Class Initialized
INFO - 2019-08-19 11:08:19 --> Language Class Initialized
INFO - 2019-08-19 11:08:19 --> Loader Class Initialized
INFO - 2019-08-19 11:08:19 --> Helper loaded: url_helper
INFO - 2019-08-19 11:08:19 --> Helper loaded: html_helper
INFO - 2019-08-19 11:08:19 --> Helper loaded: form_helper
INFO - 2019-08-19 11:08:19 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:08:19 --> Helper loaded: date_helper
INFO - 2019-08-19 11:08:19 --> Form Validation Class Initialized
INFO - 2019-08-19 11:08:19 --> Email Class Initialized
DEBUG - 2019-08-19 11:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:08:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:08:19 --> Pagination Class Initialized
INFO - 2019-08-19 11:08:19 --> Database Driver Class Initialized
INFO - 2019-08-19 11:08:19 --> Database Driver Class Initialized
INFO - 2019-08-19 11:08:19 --> Controller Class Initialized
INFO - 2019-08-19 11:08:19 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 11:08:19 --> Final output sent to browser
DEBUG - 2019-08-19 11:08:19 --> Total execution time: 0.0609
INFO - 2019-08-19 11:08:34 --> Config Class Initialized
INFO - 2019-08-19 11:08:34 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:08:34 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:08:34 --> Utf8 Class Initialized
INFO - 2019-08-19 11:08:34 --> URI Class Initialized
INFO - 2019-08-19 11:08:34 --> Router Class Initialized
INFO - 2019-08-19 11:08:34 --> Output Class Initialized
INFO - 2019-08-19 11:08:34 --> Security Class Initialized
DEBUG - 2019-08-19 11:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:08:34 --> Input Class Initialized
INFO - 2019-08-19 11:08:34 --> Language Class Initialized
INFO - 2019-08-19 11:08:34 --> Loader Class Initialized
INFO - 2019-08-19 11:08:34 --> Helper loaded: url_helper
INFO - 2019-08-19 11:08:34 --> Helper loaded: html_helper
INFO - 2019-08-19 11:08:34 --> Helper loaded: form_helper
INFO - 2019-08-19 11:08:34 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:08:34 --> Helper loaded: date_helper
INFO - 2019-08-19 11:08:34 --> Form Validation Class Initialized
INFO - 2019-08-19 11:08:34 --> Email Class Initialized
DEBUG - 2019-08-19 11:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:08:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:08:34 --> Pagination Class Initialized
INFO - 2019-08-19 11:08:34 --> Database Driver Class Initialized
INFO - 2019-08-19 11:08:34 --> Database Driver Class Initialized
INFO - 2019-08-19 11:08:34 --> Controller Class Initialized
INFO - 2019-08-19 11:08:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 11:09:37 --> Config Class Initialized
INFO - 2019-08-19 11:09:37 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:09:37 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:09:37 --> Utf8 Class Initialized
INFO - 2019-08-19 11:09:37 --> URI Class Initialized
INFO - 2019-08-19 11:09:37 --> Router Class Initialized
INFO - 2019-08-19 11:09:37 --> Output Class Initialized
INFO - 2019-08-19 11:09:37 --> Security Class Initialized
DEBUG - 2019-08-19 11:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:09:37 --> Input Class Initialized
INFO - 2019-08-19 11:09:37 --> Language Class Initialized
INFO - 2019-08-19 11:09:37 --> Loader Class Initialized
INFO - 2019-08-19 11:09:37 --> Helper loaded: url_helper
INFO - 2019-08-19 11:09:37 --> Helper loaded: html_helper
INFO - 2019-08-19 11:09:37 --> Helper loaded: form_helper
INFO - 2019-08-19 11:09:37 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:09:37 --> Helper loaded: date_helper
INFO - 2019-08-19 11:09:37 --> Form Validation Class Initialized
INFO - 2019-08-19 11:09:37 --> Email Class Initialized
DEBUG - 2019-08-19 11:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:09:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:09:37 --> Pagination Class Initialized
INFO - 2019-08-19 11:09:37 --> Database Driver Class Initialized
INFO - 2019-08-19 11:09:37 --> Database Driver Class Initialized
INFO - 2019-08-19 11:09:37 --> Controller Class Initialized
INFO - 2019-08-19 11:09:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 11:11:00 --> Config Class Initialized
INFO - 2019-08-19 11:11:00 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:11:00 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:11:00 --> Utf8 Class Initialized
INFO - 2019-08-19 11:11:00 --> URI Class Initialized
INFO - 2019-08-19 11:11:00 --> Router Class Initialized
INFO - 2019-08-19 11:11:00 --> Output Class Initialized
INFO - 2019-08-19 11:11:00 --> Security Class Initialized
DEBUG - 2019-08-19 11:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:11:00 --> Input Class Initialized
INFO - 2019-08-19 11:11:00 --> Language Class Initialized
INFO - 2019-08-19 11:11:00 --> Loader Class Initialized
INFO - 2019-08-19 11:11:00 --> Helper loaded: url_helper
INFO - 2019-08-19 11:11:00 --> Helper loaded: html_helper
INFO - 2019-08-19 11:11:00 --> Helper loaded: form_helper
INFO - 2019-08-19 11:11:00 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:11:00 --> Helper loaded: date_helper
INFO - 2019-08-19 11:11:00 --> Form Validation Class Initialized
INFO - 2019-08-19 11:11:00 --> Email Class Initialized
DEBUG - 2019-08-19 11:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:11:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:11:00 --> Pagination Class Initialized
INFO - 2019-08-19 11:11:00 --> Database Driver Class Initialized
INFO - 2019-08-19 11:11:00 --> Database Driver Class Initialized
INFO - 2019-08-19 11:11:00 --> Controller Class Initialized
INFO - 2019-08-19 11:11:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 11:11:54 --> Config Class Initialized
INFO - 2019-08-19 11:11:54 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:11:54 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:11:54 --> Utf8 Class Initialized
INFO - 2019-08-19 11:11:54 --> URI Class Initialized
INFO - 2019-08-19 11:11:54 --> Router Class Initialized
INFO - 2019-08-19 11:11:54 --> Output Class Initialized
INFO - 2019-08-19 11:11:54 --> Security Class Initialized
DEBUG - 2019-08-19 11:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:11:54 --> Input Class Initialized
INFO - 2019-08-19 11:11:54 --> Language Class Initialized
INFO - 2019-08-19 11:11:54 --> Loader Class Initialized
INFO - 2019-08-19 11:11:54 --> Helper loaded: url_helper
INFO - 2019-08-19 11:11:54 --> Helper loaded: html_helper
INFO - 2019-08-19 11:11:54 --> Helper loaded: form_helper
INFO - 2019-08-19 11:11:54 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:11:54 --> Helper loaded: date_helper
INFO - 2019-08-19 11:11:54 --> Form Validation Class Initialized
INFO - 2019-08-19 11:11:54 --> Email Class Initialized
DEBUG - 2019-08-19 11:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:11:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:11:54 --> Pagination Class Initialized
INFO - 2019-08-19 11:11:54 --> Database Driver Class Initialized
INFO - 2019-08-19 11:11:54 --> Database Driver Class Initialized
INFO - 2019-08-19 11:11:54 --> Controller Class Initialized
INFO - 2019-08-19 11:11:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 11:13:22 --> Config Class Initialized
INFO - 2019-08-19 11:13:22 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:13:22 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:13:22 --> Utf8 Class Initialized
INFO - 2019-08-19 11:13:22 --> URI Class Initialized
INFO - 2019-08-19 11:13:22 --> Router Class Initialized
INFO - 2019-08-19 11:13:22 --> Output Class Initialized
INFO - 2019-08-19 11:13:22 --> Security Class Initialized
DEBUG - 2019-08-19 11:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:13:22 --> Input Class Initialized
INFO - 2019-08-19 11:13:22 --> Language Class Initialized
INFO - 2019-08-19 11:13:22 --> Loader Class Initialized
INFO - 2019-08-19 11:13:22 --> Helper loaded: url_helper
INFO - 2019-08-19 11:13:22 --> Helper loaded: html_helper
INFO - 2019-08-19 11:13:22 --> Helper loaded: form_helper
INFO - 2019-08-19 11:13:22 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:13:22 --> Helper loaded: date_helper
INFO - 2019-08-19 11:13:22 --> Form Validation Class Initialized
INFO - 2019-08-19 11:13:22 --> Email Class Initialized
DEBUG - 2019-08-19 11:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:13:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:13:22 --> Pagination Class Initialized
INFO - 2019-08-19 11:13:22 --> Database Driver Class Initialized
INFO - 2019-08-19 11:13:22 --> Database Driver Class Initialized
INFO - 2019-08-19 11:13:22 --> Controller Class Initialized
INFO - 2019-08-19 11:13:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 11:14:52 --> Config Class Initialized
INFO - 2019-08-19 11:14:52 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:14:52 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:14:52 --> Utf8 Class Initialized
INFO - 2019-08-19 11:14:52 --> URI Class Initialized
INFO - 2019-08-19 11:14:52 --> Router Class Initialized
INFO - 2019-08-19 11:14:52 --> Output Class Initialized
INFO - 2019-08-19 11:14:52 --> Security Class Initialized
DEBUG - 2019-08-19 11:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:14:52 --> Input Class Initialized
INFO - 2019-08-19 11:14:52 --> Language Class Initialized
INFO - 2019-08-19 11:14:52 --> Loader Class Initialized
INFO - 2019-08-19 11:14:52 --> Helper loaded: url_helper
INFO - 2019-08-19 11:14:52 --> Helper loaded: html_helper
INFO - 2019-08-19 11:14:52 --> Helper loaded: form_helper
INFO - 2019-08-19 11:14:52 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:14:52 --> Helper loaded: date_helper
INFO - 2019-08-19 11:14:52 --> Form Validation Class Initialized
INFO - 2019-08-19 11:14:52 --> Email Class Initialized
DEBUG - 2019-08-19 11:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:14:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:14:52 --> Pagination Class Initialized
INFO - 2019-08-19 11:14:52 --> Database Driver Class Initialized
INFO - 2019-08-19 11:14:52 --> Database Driver Class Initialized
INFO - 2019-08-19 11:14:52 --> Controller Class Initialized
INFO - 2019-08-19 11:14:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 11:15:41 --> Config Class Initialized
INFO - 2019-08-19 11:15:41 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:15:41 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:15:41 --> Utf8 Class Initialized
INFO - 2019-08-19 11:15:41 --> URI Class Initialized
INFO - 2019-08-19 11:15:41 --> Router Class Initialized
INFO - 2019-08-19 11:15:41 --> Output Class Initialized
INFO - 2019-08-19 11:15:41 --> Security Class Initialized
DEBUG - 2019-08-19 11:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:15:41 --> Input Class Initialized
INFO - 2019-08-19 11:15:41 --> Language Class Initialized
INFO - 2019-08-19 11:15:41 --> Loader Class Initialized
INFO - 2019-08-19 11:15:41 --> Helper loaded: url_helper
INFO - 2019-08-19 11:15:41 --> Helper loaded: html_helper
INFO - 2019-08-19 11:15:41 --> Helper loaded: form_helper
INFO - 2019-08-19 11:15:41 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:15:41 --> Helper loaded: date_helper
INFO - 2019-08-19 11:15:41 --> Form Validation Class Initialized
INFO - 2019-08-19 11:15:41 --> Email Class Initialized
DEBUG - 2019-08-19 11:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:15:41 --> Pagination Class Initialized
INFO - 2019-08-19 11:15:41 --> Database Driver Class Initialized
INFO - 2019-08-19 11:15:41 --> Database Driver Class Initialized
INFO - 2019-08-19 11:15:41 --> Controller Class Initialized
INFO - 2019-08-19 11:15:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 11:16:33 --> Config Class Initialized
INFO - 2019-08-19 11:16:33 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:16:33 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:16:33 --> Utf8 Class Initialized
INFO - 2019-08-19 11:16:33 --> URI Class Initialized
INFO - 2019-08-19 11:16:33 --> Router Class Initialized
INFO - 2019-08-19 11:16:33 --> Output Class Initialized
INFO - 2019-08-19 11:16:33 --> Security Class Initialized
DEBUG - 2019-08-19 11:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:16:33 --> Input Class Initialized
INFO - 2019-08-19 11:16:33 --> Language Class Initialized
INFO - 2019-08-19 11:16:33 --> Loader Class Initialized
INFO - 2019-08-19 11:16:33 --> Helper loaded: url_helper
INFO - 2019-08-19 11:16:33 --> Helper loaded: html_helper
INFO - 2019-08-19 11:16:33 --> Helper loaded: form_helper
INFO - 2019-08-19 11:16:33 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:16:33 --> Helper loaded: date_helper
INFO - 2019-08-19 11:16:33 --> Form Validation Class Initialized
INFO - 2019-08-19 11:16:33 --> Email Class Initialized
DEBUG - 2019-08-19 11:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:16:33 --> Pagination Class Initialized
INFO - 2019-08-19 11:16:33 --> Database Driver Class Initialized
INFO - 2019-08-19 11:16:33 --> Database Driver Class Initialized
INFO - 2019-08-19 11:16:33 --> Controller Class Initialized
INFO - 2019-08-19 11:16:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 11:16:34 --> Config Class Initialized
INFO - 2019-08-19 11:16:34 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:16:34 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:16:34 --> Utf8 Class Initialized
INFO - 2019-08-19 11:16:34 --> URI Class Initialized
INFO - 2019-08-19 11:16:34 --> Router Class Initialized
INFO - 2019-08-19 11:16:34 --> Output Class Initialized
INFO - 2019-08-19 11:16:34 --> Security Class Initialized
DEBUG - 2019-08-19 11:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:16:34 --> Input Class Initialized
INFO - 2019-08-19 11:16:34 --> Language Class Initialized
INFO - 2019-08-19 11:16:34 --> Loader Class Initialized
INFO - 2019-08-19 11:16:34 --> Helper loaded: url_helper
INFO - 2019-08-19 11:16:34 --> Helper loaded: html_helper
INFO - 2019-08-19 11:16:34 --> Helper loaded: form_helper
INFO - 2019-08-19 11:16:34 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:16:34 --> Helper loaded: date_helper
INFO - 2019-08-19 11:16:34 --> Form Validation Class Initialized
INFO - 2019-08-19 11:16:34 --> Email Class Initialized
DEBUG - 2019-08-19 11:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:16:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:16:34 --> Pagination Class Initialized
INFO - 2019-08-19 11:16:34 --> Database Driver Class Initialized
INFO - 2019-08-19 11:16:34 --> Database Driver Class Initialized
INFO - 2019-08-19 11:16:34 --> Controller Class Initialized
INFO - 2019-08-19 11:17:27 --> Config Class Initialized
INFO - 2019-08-19 11:17:27 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:17:27 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:17:27 --> Utf8 Class Initialized
INFO - 2019-08-19 11:17:27 --> URI Class Initialized
INFO - 2019-08-19 11:17:27 --> Router Class Initialized
INFO - 2019-08-19 11:17:27 --> Output Class Initialized
INFO - 2019-08-19 11:17:27 --> Security Class Initialized
DEBUG - 2019-08-19 11:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:17:27 --> Input Class Initialized
INFO - 2019-08-19 11:17:27 --> Language Class Initialized
INFO - 2019-08-19 11:17:27 --> Loader Class Initialized
INFO - 2019-08-19 11:17:27 --> Helper loaded: url_helper
INFO - 2019-08-19 11:17:27 --> Helper loaded: html_helper
INFO - 2019-08-19 11:17:27 --> Helper loaded: form_helper
INFO - 2019-08-19 11:17:27 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:17:27 --> Helper loaded: date_helper
INFO - 2019-08-19 11:17:27 --> Form Validation Class Initialized
INFO - 2019-08-19 11:17:27 --> Email Class Initialized
DEBUG - 2019-08-19 11:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:17:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:17:27 --> Pagination Class Initialized
INFO - 2019-08-19 11:17:27 --> Database Driver Class Initialized
INFO - 2019-08-19 11:17:27 --> Database Driver Class Initialized
INFO - 2019-08-19 11:17:27 --> Controller Class Initialized
INFO - 2019-08-19 11:19:21 --> Config Class Initialized
INFO - 2019-08-19 11:19:21 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:19:21 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:19:21 --> Utf8 Class Initialized
INFO - 2019-08-19 11:19:21 --> URI Class Initialized
INFO - 2019-08-19 11:19:21 --> Router Class Initialized
INFO - 2019-08-19 11:19:21 --> Output Class Initialized
INFO - 2019-08-19 11:19:21 --> Security Class Initialized
DEBUG - 2019-08-19 11:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:19:21 --> Input Class Initialized
INFO - 2019-08-19 11:19:21 --> Language Class Initialized
INFO - 2019-08-19 11:19:21 --> Loader Class Initialized
INFO - 2019-08-19 11:19:21 --> Helper loaded: url_helper
INFO - 2019-08-19 11:19:21 --> Helper loaded: html_helper
INFO - 2019-08-19 11:19:21 --> Helper loaded: form_helper
INFO - 2019-08-19 11:19:21 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:19:21 --> Helper loaded: date_helper
INFO - 2019-08-19 11:19:21 --> Form Validation Class Initialized
INFO - 2019-08-19 11:19:21 --> Email Class Initialized
DEBUG - 2019-08-19 11:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:19:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:19:21 --> Pagination Class Initialized
INFO - 2019-08-19 11:19:22 --> Database Driver Class Initialized
INFO - 2019-08-19 11:19:22 --> Database Driver Class Initialized
INFO - 2019-08-19 11:19:22 --> Controller Class Initialized
INFO - 2019-08-19 11:26:18 --> Config Class Initialized
INFO - 2019-08-19 11:26:18 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:26:18 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:26:18 --> Utf8 Class Initialized
INFO - 2019-08-19 11:26:18 --> URI Class Initialized
INFO - 2019-08-19 11:26:18 --> Router Class Initialized
INFO - 2019-08-19 11:26:18 --> Output Class Initialized
INFO - 2019-08-19 11:26:18 --> Security Class Initialized
DEBUG - 2019-08-19 11:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:26:18 --> Input Class Initialized
INFO - 2019-08-19 11:26:18 --> Language Class Initialized
INFO - 2019-08-19 11:26:18 --> Loader Class Initialized
INFO - 2019-08-19 11:26:18 --> Helper loaded: url_helper
INFO - 2019-08-19 11:26:18 --> Helper loaded: html_helper
INFO - 2019-08-19 11:26:18 --> Helper loaded: form_helper
INFO - 2019-08-19 11:26:18 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:26:18 --> Helper loaded: date_helper
INFO - 2019-08-19 11:26:18 --> Form Validation Class Initialized
INFO - 2019-08-19 11:26:18 --> Email Class Initialized
DEBUG - 2019-08-19 11:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:26:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:26:18 --> Pagination Class Initialized
INFO - 2019-08-19 11:26:18 --> Database Driver Class Initialized
INFO - 2019-08-19 11:26:18 --> Database Driver Class Initialized
INFO - 2019-08-19 11:26:18 --> Controller Class Initialized
INFO - 2019-08-19 11:26:20 --> Config Class Initialized
INFO - 2019-08-19 11:26:20 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:26:20 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:26:20 --> Utf8 Class Initialized
INFO - 2019-08-19 11:26:20 --> URI Class Initialized
INFO - 2019-08-19 11:26:20 --> Router Class Initialized
INFO - 2019-08-19 11:26:20 --> Output Class Initialized
INFO - 2019-08-19 11:26:20 --> Security Class Initialized
DEBUG - 2019-08-19 11:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:26:20 --> Input Class Initialized
INFO - 2019-08-19 11:26:20 --> Language Class Initialized
INFO - 2019-08-19 11:26:20 --> Loader Class Initialized
INFO - 2019-08-19 11:26:20 --> Helper loaded: url_helper
INFO - 2019-08-19 11:26:20 --> Helper loaded: html_helper
INFO - 2019-08-19 11:26:20 --> Helper loaded: form_helper
INFO - 2019-08-19 11:26:20 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:26:20 --> Helper loaded: date_helper
INFO - 2019-08-19 11:26:20 --> Form Validation Class Initialized
INFO - 2019-08-19 11:26:20 --> Email Class Initialized
DEBUG - 2019-08-19 11:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:26:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:26:20 --> Pagination Class Initialized
INFO - 2019-08-19 11:26:20 --> Database Driver Class Initialized
INFO - 2019-08-19 11:26:20 --> Database Driver Class Initialized
INFO - 2019-08-19 11:26:20 --> Controller Class Initialized
INFO - 2019-08-19 11:26:56 --> Config Class Initialized
INFO - 2019-08-19 11:26:56 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:26:56 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:26:56 --> Utf8 Class Initialized
INFO - 2019-08-19 11:26:56 --> URI Class Initialized
INFO - 2019-08-19 11:26:56 --> Router Class Initialized
INFO - 2019-08-19 11:26:56 --> Output Class Initialized
INFO - 2019-08-19 11:26:56 --> Security Class Initialized
DEBUG - 2019-08-19 11:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:26:56 --> Input Class Initialized
INFO - 2019-08-19 11:26:56 --> Language Class Initialized
INFO - 2019-08-19 11:26:56 --> Loader Class Initialized
INFO - 2019-08-19 11:26:56 --> Helper loaded: url_helper
INFO - 2019-08-19 11:26:56 --> Helper loaded: html_helper
INFO - 2019-08-19 11:26:56 --> Helper loaded: form_helper
INFO - 2019-08-19 11:26:56 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:26:56 --> Helper loaded: date_helper
INFO - 2019-08-19 11:26:56 --> Form Validation Class Initialized
INFO - 2019-08-19 11:26:56 --> Email Class Initialized
DEBUG - 2019-08-19 11:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:26:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:26:56 --> Pagination Class Initialized
INFO - 2019-08-19 11:26:56 --> Database Driver Class Initialized
INFO - 2019-08-19 11:26:56 --> Database Driver Class Initialized
INFO - 2019-08-19 11:26:56 --> Controller Class Initialized
INFO - 2019-08-19 11:27:10 --> Config Class Initialized
INFO - 2019-08-19 11:27:10 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:27:10 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:27:10 --> Utf8 Class Initialized
INFO - 2019-08-19 11:27:10 --> URI Class Initialized
INFO - 2019-08-19 11:27:10 --> Router Class Initialized
INFO - 2019-08-19 11:27:10 --> Output Class Initialized
INFO - 2019-08-19 11:27:10 --> Security Class Initialized
DEBUG - 2019-08-19 11:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:27:10 --> Input Class Initialized
INFO - 2019-08-19 11:27:10 --> Language Class Initialized
INFO - 2019-08-19 11:27:10 --> Loader Class Initialized
INFO - 2019-08-19 11:27:10 --> Helper loaded: url_helper
INFO - 2019-08-19 11:27:10 --> Helper loaded: html_helper
INFO - 2019-08-19 11:27:10 --> Helper loaded: form_helper
INFO - 2019-08-19 11:27:10 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:27:10 --> Helper loaded: date_helper
INFO - 2019-08-19 11:27:10 --> Form Validation Class Initialized
INFO - 2019-08-19 11:27:10 --> Email Class Initialized
DEBUG - 2019-08-19 11:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:27:10 --> Pagination Class Initialized
INFO - 2019-08-19 11:27:10 --> Database Driver Class Initialized
INFO - 2019-08-19 11:27:10 --> Database Driver Class Initialized
INFO - 2019-08-19 11:27:10 --> Controller Class Initialized
INFO - 2019-08-19 11:27:10 --> Config Class Initialized
INFO - 2019-08-19 11:27:10 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:27:10 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:27:10 --> Utf8 Class Initialized
INFO - 2019-08-19 11:27:10 --> URI Class Initialized
INFO - 2019-08-19 11:27:10 --> Router Class Initialized
INFO - 2019-08-19 11:27:10 --> Output Class Initialized
INFO - 2019-08-19 11:27:10 --> Security Class Initialized
DEBUG - 2019-08-19 11:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:27:10 --> Input Class Initialized
INFO - 2019-08-19 11:27:10 --> Language Class Initialized
INFO - 2019-08-19 11:27:10 --> Loader Class Initialized
INFO - 2019-08-19 11:27:10 --> Helper loaded: url_helper
INFO - 2019-08-19 11:27:10 --> Helper loaded: html_helper
INFO - 2019-08-19 11:27:10 --> Helper loaded: form_helper
INFO - 2019-08-19 11:27:10 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:27:10 --> Helper loaded: date_helper
INFO - 2019-08-19 11:27:10 --> Form Validation Class Initialized
INFO - 2019-08-19 11:27:10 --> Email Class Initialized
DEBUG - 2019-08-19 11:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:27:10 --> Pagination Class Initialized
INFO - 2019-08-19 11:27:10 --> Database Driver Class Initialized
INFO - 2019-08-19 11:27:10 --> Database Driver Class Initialized
INFO - 2019-08-19 11:27:10 --> Controller Class Initialized
INFO - 2019-08-19 11:27:35 --> Config Class Initialized
INFO - 2019-08-19 11:27:35 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:27:35 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:27:35 --> Utf8 Class Initialized
INFO - 2019-08-19 11:27:35 --> URI Class Initialized
INFO - 2019-08-19 11:27:35 --> Router Class Initialized
INFO - 2019-08-19 11:27:35 --> Output Class Initialized
INFO - 2019-08-19 11:27:35 --> Security Class Initialized
DEBUG - 2019-08-19 11:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:27:35 --> Input Class Initialized
INFO - 2019-08-19 11:27:35 --> Language Class Initialized
INFO - 2019-08-19 11:27:35 --> Loader Class Initialized
INFO - 2019-08-19 11:27:35 --> Helper loaded: url_helper
INFO - 2019-08-19 11:27:35 --> Helper loaded: html_helper
INFO - 2019-08-19 11:27:35 --> Helper loaded: form_helper
INFO - 2019-08-19 11:27:35 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:27:35 --> Helper loaded: date_helper
INFO - 2019-08-19 11:27:35 --> Form Validation Class Initialized
INFO - 2019-08-19 11:27:35 --> Email Class Initialized
DEBUG - 2019-08-19 11:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:27:35 --> Pagination Class Initialized
INFO - 2019-08-19 11:27:35 --> Database Driver Class Initialized
INFO - 2019-08-19 11:27:35 --> Database Driver Class Initialized
INFO - 2019-08-19 11:27:35 --> Controller Class Initialized
INFO - 2019-08-19 11:27:35 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 11:27:35 --> Final output sent to browser
DEBUG - 2019-08-19 11:27:35 --> Total execution time: 0.0503
INFO - 2019-08-19 11:30:03 --> Config Class Initialized
INFO - 2019-08-19 11:30:03 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:30:03 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:30:03 --> Utf8 Class Initialized
INFO - 2019-08-19 11:30:03 --> URI Class Initialized
INFO - 2019-08-19 11:30:03 --> Router Class Initialized
INFO - 2019-08-19 11:30:03 --> Output Class Initialized
INFO - 2019-08-19 11:30:03 --> Security Class Initialized
DEBUG - 2019-08-19 11:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:30:03 --> Input Class Initialized
INFO - 2019-08-19 11:30:03 --> Language Class Initialized
INFO - 2019-08-19 11:30:03 --> Loader Class Initialized
INFO - 2019-08-19 11:30:03 --> Helper loaded: url_helper
INFO - 2019-08-19 11:30:03 --> Helper loaded: html_helper
INFO - 2019-08-19 11:30:03 --> Helper loaded: form_helper
INFO - 2019-08-19 11:30:03 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:30:03 --> Helper loaded: date_helper
INFO - 2019-08-19 11:30:03 --> Form Validation Class Initialized
INFO - 2019-08-19 11:30:03 --> Email Class Initialized
DEBUG - 2019-08-19 11:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:30:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:30:03 --> Pagination Class Initialized
INFO - 2019-08-19 11:30:03 --> Database Driver Class Initialized
INFO - 2019-08-19 11:30:03 --> Database Driver Class Initialized
INFO - 2019-08-19 11:30:16 --> Controller Class Initialized
INFO - 2019-08-19 11:30:16 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 11:30:16 --> Final output sent to browser
DEBUG - 2019-08-19 11:30:16 --> Total execution time: 13.3902
INFO - 2019-08-19 11:30:16 --> Config Class Initialized
INFO - 2019-08-19 11:30:16 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:30:16 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:30:16 --> Utf8 Class Initialized
INFO - 2019-08-19 11:30:16 --> URI Class Initialized
INFO - 2019-08-19 11:30:16 --> Router Class Initialized
INFO - 2019-08-19 11:30:16 --> Output Class Initialized
INFO - 2019-08-19 11:30:16 --> Security Class Initialized
DEBUG - 2019-08-19 11:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:30:16 --> Input Class Initialized
INFO - 2019-08-19 11:30:16 --> Language Class Initialized
INFO - 2019-08-19 11:30:16 --> Loader Class Initialized
INFO - 2019-08-19 11:30:16 --> Helper loaded: url_helper
INFO - 2019-08-19 11:30:16 --> Helper loaded: html_helper
INFO - 2019-08-19 11:30:16 --> Helper loaded: form_helper
INFO - 2019-08-19 11:30:16 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:30:16 --> Helper loaded: date_helper
INFO - 2019-08-19 11:30:16 --> Form Validation Class Initialized
INFO - 2019-08-19 11:30:16 --> Email Class Initialized
DEBUG - 2019-08-19 11:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:30:16 --> Pagination Class Initialized
INFO - 2019-08-19 11:30:16 --> Database Driver Class Initialized
INFO - 2019-08-19 11:30:16 --> Database Driver Class Initialized
INFO - 2019-08-19 11:30:16 --> Controller Class Initialized
INFO - 2019-08-19 11:30:16 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 11:30:16 --> Final output sent to browser
DEBUG - 2019-08-19 11:30:16 --> Total execution time: 0.0554
INFO - 2019-08-19 11:30:26 --> Config Class Initialized
INFO - 2019-08-19 11:30:26 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:30:26 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:30:26 --> Utf8 Class Initialized
INFO - 2019-08-19 11:30:26 --> URI Class Initialized
INFO - 2019-08-19 11:30:26 --> Router Class Initialized
INFO - 2019-08-19 11:30:26 --> Output Class Initialized
INFO - 2019-08-19 11:30:26 --> Security Class Initialized
DEBUG - 2019-08-19 11:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:30:26 --> Input Class Initialized
INFO - 2019-08-19 11:30:26 --> Language Class Initialized
INFO - 2019-08-19 11:30:26 --> Loader Class Initialized
INFO - 2019-08-19 11:30:26 --> Helper loaded: url_helper
INFO - 2019-08-19 11:30:26 --> Helper loaded: html_helper
INFO - 2019-08-19 11:30:26 --> Helper loaded: form_helper
INFO - 2019-08-19 11:30:26 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:30:26 --> Helper loaded: date_helper
INFO - 2019-08-19 11:30:26 --> Form Validation Class Initialized
INFO - 2019-08-19 11:30:26 --> Email Class Initialized
DEBUG - 2019-08-19 11:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:30:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:30:26 --> Pagination Class Initialized
INFO - 2019-08-19 11:30:26 --> Database Driver Class Initialized
INFO - 2019-08-19 11:30:26 --> Database Driver Class Initialized
INFO - 2019-08-19 11:30:26 --> Controller Class Initialized
INFO - 2019-08-19 11:30:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 11:35:23 --> Config Class Initialized
INFO - 2019-08-19 11:35:23 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:35:23 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:35:23 --> Utf8 Class Initialized
INFO - 2019-08-19 11:35:23 --> URI Class Initialized
INFO - 2019-08-19 11:35:23 --> Router Class Initialized
INFO - 2019-08-19 11:35:23 --> Output Class Initialized
INFO - 2019-08-19 11:35:23 --> Security Class Initialized
DEBUG - 2019-08-19 11:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:35:23 --> Input Class Initialized
INFO - 2019-08-19 11:35:23 --> Language Class Initialized
INFO - 2019-08-19 11:35:23 --> Loader Class Initialized
INFO - 2019-08-19 11:35:23 --> Helper loaded: url_helper
INFO - 2019-08-19 11:35:23 --> Helper loaded: html_helper
INFO - 2019-08-19 11:35:23 --> Helper loaded: form_helper
INFO - 2019-08-19 11:35:23 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:35:23 --> Helper loaded: date_helper
INFO - 2019-08-19 11:35:23 --> Form Validation Class Initialized
INFO - 2019-08-19 11:35:23 --> Email Class Initialized
DEBUG - 2019-08-19 11:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:35:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:35:23 --> Pagination Class Initialized
INFO - 2019-08-19 11:35:23 --> Database Driver Class Initialized
INFO - 2019-08-19 11:35:23 --> Database Driver Class Initialized
INFO - 2019-08-19 11:35:23 --> Controller Class Initialized
INFO - 2019-08-19 11:35:23 --> Config Class Initialized
INFO - 2019-08-19 11:35:23 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:35:23 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:35:23 --> Utf8 Class Initialized
INFO - 2019-08-19 11:35:23 --> URI Class Initialized
INFO - 2019-08-19 11:35:23 --> Router Class Initialized
INFO - 2019-08-19 11:35:23 --> Output Class Initialized
INFO - 2019-08-19 11:35:23 --> Security Class Initialized
DEBUG - 2019-08-19 11:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:35:23 --> Input Class Initialized
INFO - 2019-08-19 11:35:23 --> Language Class Initialized
INFO - 2019-08-19 11:35:23 --> Loader Class Initialized
INFO - 2019-08-19 11:35:23 --> Helper loaded: url_helper
INFO - 2019-08-19 11:35:23 --> Helper loaded: html_helper
INFO - 2019-08-19 11:35:23 --> Helper loaded: form_helper
INFO - 2019-08-19 11:35:23 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:35:23 --> Helper loaded: date_helper
INFO - 2019-08-19 11:35:23 --> Form Validation Class Initialized
INFO - 2019-08-19 11:35:23 --> Email Class Initialized
DEBUG - 2019-08-19 11:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:35:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:35:23 --> Pagination Class Initialized
INFO - 2019-08-19 11:35:23 --> Database Driver Class Initialized
INFO - 2019-08-19 11:35:23 --> Database Driver Class Initialized
INFO - 2019-08-19 11:35:23 --> Controller Class Initialized
INFO - 2019-08-19 11:35:30 --> Config Class Initialized
INFO - 2019-08-19 11:35:30 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:35:30 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:35:30 --> Utf8 Class Initialized
INFO - 2019-08-19 11:35:30 --> URI Class Initialized
INFO - 2019-08-19 11:35:30 --> Router Class Initialized
INFO - 2019-08-19 11:35:30 --> Output Class Initialized
INFO - 2019-08-19 11:35:30 --> Security Class Initialized
DEBUG - 2019-08-19 11:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:35:30 --> Input Class Initialized
INFO - 2019-08-19 11:35:30 --> Language Class Initialized
INFO - 2019-08-19 11:35:30 --> Loader Class Initialized
INFO - 2019-08-19 11:35:30 --> Helper loaded: url_helper
INFO - 2019-08-19 11:35:30 --> Helper loaded: html_helper
INFO - 2019-08-19 11:35:30 --> Helper loaded: form_helper
INFO - 2019-08-19 11:35:30 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:35:30 --> Helper loaded: date_helper
INFO - 2019-08-19 11:35:30 --> Form Validation Class Initialized
INFO - 2019-08-19 11:35:30 --> Email Class Initialized
DEBUG - 2019-08-19 11:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:35:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:35:30 --> Pagination Class Initialized
INFO - 2019-08-19 11:35:30 --> Database Driver Class Initialized
INFO - 2019-08-19 11:35:30 --> Database Driver Class Initialized
INFO - 2019-08-19 11:35:30 --> Controller Class Initialized
INFO - 2019-08-19 11:35:30 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 11:35:30 --> Final output sent to browser
DEBUG - 2019-08-19 11:35:30 --> Total execution time: 0.0570
INFO - 2019-08-19 11:35:40 --> Config Class Initialized
INFO - 2019-08-19 11:35:40 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:35:40 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:35:40 --> Utf8 Class Initialized
INFO - 2019-08-19 11:35:40 --> URI Class Initialized
INFO - 2019-08-19 11:35:40 --> Router Class Initialized
INFO - 2019-08-19 11:35:40 --> Output Class Initialized
INFO - 2019-08-19 11:35:40 --> Security Class Initialized
DEBUG - 2019-08-19 11:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:35:40 --> Input Class Initialized
INFO - 2019-08-19 11:35:40 --> Language Class Initialized
INFO - 2019-08-19 11:35:40 --> Loader Class Initialized
INFO - 2019-08-19 11:35:40 --> Helper loaded: url_helper
INFO - 2019-08-19 11:35:40 --> Helper loaded: html_helper
INFO - 2019-08-19 11:35:40 --> Helper loaded: form_helper
INFO - 2019-08-19 11:35:40 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:35:40 --> Helper loaded: date_helper
INFO - 2019-08-19 11:35:40 --> Form Validation Class Initialized
INFO - 2019-08-19 11:35:40 --> Email Class Initialized
DEBUG - 2019-08-19 11:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:35:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:35:40 --> Pagination Class Initialized
INFO - 2019-08-19 11:35:40 --> Database Driver Class Initialized
INFO - 2019-08-19 11:35:40 --> Database Driver Class Initialized
INFO - 2019-08-19 11:35:40 --> Controller Class Initialized
INFO - 2019-08-19 11:35:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 11:37:24 --> Config Class Initialized
INFO - 2019-08-19 11:37:24 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:37:24 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:37:24 --> Utf8 Class Initialized
INFO - 2019-08-19 11:37:24 --> URI Class Initialized
INFO - 2019-08-19 11:37:24 --> Router Class Initialized
INFO - 2019-08-19 11:37:24 --> Output Class Initialized
INFO - 2019-08-19 11:37:24 --> Security Class Initialized
DEBUG - 2019-08-19 11:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:37:24 --> Input Class Initialized
INFO - 2019-08-19 11:37:24 --> Language Class Initialized
INFO - 2019-08-19 11:37:24 --> Loader Class Initialized
INFO - 2019-08-19 11:37:24 --> Helper loaded: url_helper
INFO - 2019-08-19 11:37:24 --> Helper loaded: html_helper
INFO - 2019-08-19 11:37:24 --> Helper loaded: form_helper
INFO - 2019-08-19 11:37:24 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:37:24 --> Helper loaded: date_helper
INFO - 2019-08-19 11:37:24 --> Form Validation Class Initialized
INFO - 2019-08-19 11:37:24 --> Email Class Initialized
DEBUG - 2019-08-19 11:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:37:24 --> Pagination Class Initialized
INFO - 2019-08-19 11:37:24 --> Database Driver Class Initialized
INFO - 2019-08-19 11:37:24 --> Database Driver Class Initialized
INFO - 2019-08-19 11:37:24 --> Controller Class Initialized
INFO - 2019-08-19 11:37:24 --> Config Class Initialized
INFO - 2019-08-19 11:37:24 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:37:24 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:37:24 --> Utf8 Class Initialized
INFO - 2019-08-19 11:37:24 --> URI Class Initialized
INFO - 2019-08-19 11:37:24 --> Router Class Initialized
INFO - 2019-08-19 11:37:24 --> Output Class Initialized
INFO - 2019-08-19 11:37:24 --> Security Class Initialized
DEBUG - 2019-08-19 11:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:37:24 --> Input Class Initialized
INFO - 2019-08-19 11:37:24 --> Language Class Initialized
INFO - 2019-08-19 11:37:24 --> Loader Class Initialized
INFO - 2019-08-19 11:37:24 --> Helper loaded: url_helper
INFO - 2019-08-19 11:37:24 --> Helper loaded: html_helper
INFO - 2019-08-19 11:37:24 --> Helper loaded: form_helper
INFO - 2019-08-19 11:37:24 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:37:24 --> Helper loaded: date_helper
INFO - 2019-08-19 11:37:24 --> Form Validation Class Initialized
INFO - 2019-08-19 11:37:24 --> Email Class Initialized
DEBUG - 2019-08-19 11:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:37:24 --> Pagination Class Initialized
INFO - 2019-08-19 11:37:24 --> Database Driver Class Initialized
INFO - 2019-08-19 11:37:24 --> Database Driver Class Initialized
INFO - 2019-08-19 11:37:24 --> Controller Class Initialized
INFO - 2019-08-19 11:37:24 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 11:37:24 --> Final output sent to browser
DEBUG - 2019-08-19 11:37:24 --> Total execution time: 0.0592
INFO - 2019-08-19 11:37:33 --> Config Class Initialized
INFO - 2019-08-19 11:37:33 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:37:33 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:37:33 --> Utf8 Class Initialized
INFO - 2019-08-19 11:37:33 --> URI Class Initialized
INFO - 2019-08-19 11:37:33 --> Router Class Initialized
INFO - 2019-08-19 11:37:33 --> Output Class Initialized
INFO - 2019-08-19 11:37:33 --> Security Class Initialized
DEBUG - 2019-08-19 11:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:37:33 --> Input Class Initialized
INFO - 2019-08-19 11:37:33 --> Language Class Initialized
INFO - 2019-08-19 11:37:33 --> Loader Class Initialized
INFO - 2019-08-19 11:37:33 --> Helper loaded: url_helper
INFO - 2019-08-19 11:37:33 --> Helper loaded: html_helper
INFO - 2019-08-19 11:37:33 --> Helper loaded: form_helper
INFO - 2019-08-19 11:37:33 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:37:33 --> Helper loaded: date_helper
INFO - 2019-08-19 11:37:33 --> Form Validation Class Initialized
INFO - 2019-08-19 11:37:33 --> Email Class Initialized
DEBUG - 2019-08-19 11:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:37:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:37:33 --> Pagination Class Initialized
INFO - 2019-08-19 11:37:33 --> Database Driver Class Initialized
INFO - 2019-08-19 11:37:33 --> Database Driver Class Initialized
INFO - 2019-08-19 11:37:33 --> Controller Class Initialized
INFO - 2019-08-19 11:37:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 11:37:34 --> Config Class Initialized
INFO - 2019-08-19 11:37:34 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:37:34 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:37:34 --> Utf8 Class Initialized
INFO - 2019-08-19 11:37:34 --> URI Class Initialized
INFO - 2019-08-19 11:37:34 --> Router Class Initialized
INFO - 2019-08-19 11:37:34 --> Output Class Initialized
INFO - 2019-08-19 11:37:34 --> Security Class Initialized
DEBUG - 2019-08-19 11:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:37:34 --> Input Class Initialized
INFO - 2019-08-19 11:37:34 --> Language Class Initialized
INFO - 2019-08-19 11:37:34 --> Loader Class Initialized
INFO - 2019-08-19 11:37:34 --> Helper loaded: url_helper
INFO - 2019-08-19 11:37:34 --> Helper loaded: html_helper
INFO - 2019-08-19 11:37:34 --> Helper loaded: form_helper
INFO - 2019-08-19 11:37:34 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:37:34 --> Helper loaded: date_helper
INFO - 2019-08-19 11:37:34 --> Form Validation Class Initialized
INFO - 2019-08-19 11:37:34 --> Email Class Initialized
DEBUG - 2019-08-19 11:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:37:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:37:34 --> Pagination Class Initialized
INFO - 2019-08-19 11:37:34 --> Database Driver Class Initialized
INFO - 2019-08-19 11:37:34 --> Database Driver Class Initialized
INFO - 2019-08-19 11:37:34 --> Controller Class Initialized
INFO - 2019-08-19 11:37:34 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 11:37:34 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-19 11:37:34 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 11:37:34 --> Final output sent to browser
DEBUG - 2019-08-19 11:37:34 --> Total execution time: 0.6716
INFO - 2019-08-19 11:37:35 --> Config Class Initialized
INFO - 2019-08-19 11:37:35 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:37:35 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:37:35 --> Utf8 Class Initialized
INFO - 2019-08-19 11:37:35 --> URI Class Initialized
INFO - 2019-08-19 11:37:35 --> Router Class Initialized
INFO - 2019-08-19 11:37:35 --> Output Class Initialized
INFO - 2019-08-19 11:37:35 --> Security Class Initialized
DEBUG - 2019-08-19 11:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:37:35 --> Input Class Initialized
INFO - 2019-08-19 11:37:35 --> Language Class Initialized
INFO - 2019-08-19 11:37:35 --> Loader Class Initialized
INFO - 2019-08-19 11:37:35 --> Helper loaded: url_helper
INFO - 2019-08-19 11:37:35 --> Helper loaded: html_helper
INFO - 2019-08-19 11:37:35 --> Helper loaded: form_helper
INFO - 2019-08-19 11:37:35 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:37:35 --> Helper loaded: date_helper
INFO - 2019-08-19 11:37:35 --> Form Validation Class Initialized
INFO - 2019-08-19 11:37:35 --> Email Class Initialized
DEBUG - 2019-08-19 11:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:37:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:37:35 --> Pagination Class Initialized
INFO - 2019-08-19 11:37:35 --> Database Driver Class Initialized
INFO - 2019-08-19 11:37:35 --> Database Driver Class Initialized
INFO - 2019-08-19 11:37:35 --> Controller Class Initialized
INFO - 2019-08-19 11:37:35 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 11:37:35 --> Final output sent to browser
DEBUG - 2019-08-19 11:37:35 --> Total execution time: 0.2013
INFO - 2019-08-19 11:37:35 --> Config Class Initialized
INFO - 2019-08-19 11:37:35 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:37:35 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:37:35 --> Utf8 Class Initialized
INFO - 2019-08-19 11:37:35 --> URI Class Initialized
INFO - 2019-08-19 11:37:35 --> Router Class Initialized
INFO - 2019-08-19 11:37:35 --> Output Class Initialized
INFO - 2019-08-19 11:37:35 --> Security Class Initialized
DEBUG - 2019-08-19 11:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:37:35 --> Input Class Initialized
INFO - 2019-08-19 11:37:35 --> Language Class Initialized
INFO - 2019-08-19 11:37:35 --> Loader Class Initialized
INFO - 2019-08-19 11:37:35 --> Helper loaded: url_helper
INFO - 2019-08-19 11:37:35 --> Helper loaded: html_helper
INFO - 2019-08-19 11:37:35 --> Helper loaded: form_helper
INFO - 2019-08-19 11:37:35 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:37:35 --> Helper loaded: date_helper
INFO - 2019-08-19 11:37:35 --> Form Validation Class Initialized
INFO - 2019-08-19 11:37:35 --> Email Class Initialized
DEBUG - 2019-08-19 11:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:37:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:37:35 --> Pagination Class Initialized
INFO - 2019-08-19 11:37:35 --> Database Driver Class Initialized
INFO - 2019-08-19 11:37:35 --> Database Driver Class Initialized
INFO - 2019-08-19 11:37:35 --> Controller Class Initialized
INFO - 2019-08-19 11:37:35 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 11:37:35 --> Final output sent to browser
DEBUG - 2019-08-19 11:37:35 --> Total execution time: 0.0997
INFO - 2019-08-19 11:37:41 --> Config Class Initialized
INFO - 2019-08-19 11:37:41 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:37:41 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:37:41 --> Utf8 Class Initialized
INFO - 2019-08-19 11:37:41 --> URI Class Initialized
INFO - 2019-08-19 11:37:41 --> Router Class Initialized
INFO - 2019-08-19 11:37:41 --> Output Class Initialized
INFO - 2019-08-19 11:37:41 --> Security Class Initialized
DEBUG - 2019-08-19 11:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:37:41 --> Input Class Initialized
INFO - 2019-08-19 11:37:41 --> Language Class Initialized
INFO - 2019-08-19 11:37:41 --> Loader Class Initialized
INFO - 2019-08-19 11:37:41 --> Helper loaded: url_helper
INFO - 2019-08-19 11:37:41 --> Helper loaded: html_helper
INFO - 2019-08-19 11:37:41 --> Helper loaded: form_helper
INFO - 2019-08-19 11:37:41 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:37:41 --> Helper loaded: date_helper
INFO - 2019-08-19 11:37:41 --> Form Validation Class Initialized
INFO - 2019-08-19 11:37:41 --> Email Class Initialized
DEBUG - 2019-08-19 11:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:37:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:37:41 --> Pagination Class Initialized
INFO - 2019-08-19 11:37:41 --> Database Driver Class Initialized
INFO - 2019-08-19 11:37:41 --> Database Driver Class Initialized
INFO - 2019-08-19 11:37:41 --> Controller Class Initialized
INFO - 2019-08-19 11:37:41 --> Config Class Initialized
INFO - 2019-08-19 11:37:41 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:37:41 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:37:41 --> Utf8 Class Initialized
INFO - 2019-08-19 11:37:41 --> URI Class Initialized
INFO - 2019-08-19 11:37:41 --> Router Class Initialized
INFO - 2019-08-19 11:37:41 --> Output Class Initialized
INFO - 2019-08-19 11:37:41 --> Security Class Initialized
DEBUG - 2019-08-19 11:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:37:41 --> Input Class Initialized
INFO - 2019-08-19 11:37:41 --> Language Class Initialized
INFO - 2019-08-19 11:37:41 --> Loader Class Initialized
INFO - 2019-08-19 11:37:41 --> Helper loaded: url_helper
INFO - 2019-08-19 11:37:41 --> Helper loaded: html_helper
INFO - 2019-08-19 11:37:41 --> Helper loaded: form_helper
INFO - 2019-08-19 11:37:41 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:37:41 --> Helper loaded: date_helper
INFO - 2019-08-19 11:37:41 --> Form Validation Class Initialized
INFO - 2019-08-19 11:37:41 --> Email Class Initialized
DEBUG - 2019-08-19 11:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:37:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:37:41 --> Pagination Class Initialized
INFO - 2019-08-19 11:37:41 --> Database Driver Class Initialized
INFO - 2019-08-19 11:37:41 --> Database Driver Class Initialized
INFO - 2019-08-19 11:37:41 --> Controller Class Initialized
INFO - 2019-08-19 11:37:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 11:37:41 --> Final output sent to browser
DEBUG - 2019-08-19 11:37:41 --> Total execution time: 0.0642
INFO - 2019-08-19 11:38:28 --> Config Class Initialized
INFO - 2019-08-19 11:38:28 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:38:28 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:38:28 --> Utf8 Class Initialized
INFO - 2019-08-19 11:38:28 --> URI Class Initialized
INFO - 2019-08-19 11:38:28 --> Router Class Initialized
INFO - 2019-08-19 11:38:28 --> Output Class Initialized
INFO - 2019-08-19 11:38:28 --> Security Class Initialized
DEBUG - 2019-08-19 11:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:38:28 --> Input Class Initialized
INFO - 2019-08-19 11:38:28 --> Language Class Initialized
INFO - 2019-08-19 11:38:28 --> Loader Class Initialized
INFO - 2019-08-19 11:38:28 --> Helper loaded: url_helper
INFO - 2019-08-19 11:38:28 --> Helper loaded: html_helper
INFO - 2019-08-19 11:38:28 --> Helper loaded: form_helper
INFO - 2019-08-19 11:38:28 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:38:28 --> Helper loaded: date_helper
INFO - 2019-08-19 11:38:28 --> Form Validation Class Initialized
INFO - 2019-08-19 11:38:28 --> Email Class Initialized
DEBUG - 2019-08-19 11:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:38:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:38:28 --> Pagination Class Initialized
INFO - 2019-08-19 11:38:28 --> Database Driver Class Initialized
INFO - 2019-08-19 11:38:28 --> Database Driver Class Initialized
INFO - 2019-08-19 11:38:28 --> Controller Class Initialized
INFO - 2019-08-19 11:38:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 11:38:29 --> Final output sent to browser
DEBUG - 2019-08-19 11:38:29 --> Total execution time: 0.4534
INFO - 2019-08-19 11:38:29 --> Config Class Initialized
INFO - 2019-08-19 11:38:29 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:38:29 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:38:29 --> Utf8 Class Initialized
INFO - 2019-08-19 11:38:29 --> URI Class Initialized
INFO - 2019-08-19 11:38:29 --> Router Class Initialized
INFO - 2019-08-19 11:38:29 --> Output Class Initialized
INFO - 2019-08-19 11:38:29 --> Security Class Initialized
DEBUG - 2019-08-19 11:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:38:29 --> Input Class Initialized
INFO - 2019-08-19 11:38:29 --> Language Class Initialized
INFO - 2019-08-19 11:38:29 --> Loader Class Initialized
INFO - 2019-08-19 11:38:29 --> Helper loaded: url_helper
INFO - 2019-08-19 11:38:29 --> Helper loaded: html_helper
INFO - 2019-08-19 11:38:29 --> Helper loaded: form_helper
INFO - 2019-08-19 11:38:29 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:38:29 --> Helper loaded: date_helper
INFO - 2019-08-19 11:38:29 --> Form Validation Class Initialized
INFO - 2019-08-19 11:38:29 --> Email Class Initialized
DEBUG - 2019-08-19 11:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:38:29 --> Pagination Class Initialized
INFO - 2019-08-19 11:38:29 --> Database Driver Class Initialized
INFO - 2019-08-19 11:38:29 --> Database Driver Class Initialized
INFO - 2019-08-19 11:38:29 --> Controller Class Initialized
INFO - 2019-08-19 11:38:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 11:38:29 --> Final output sent to browser
DEBUG - 2019-08-19 11:38:29 --> Total execution time: 0.0531
INFO - 2019-08-19 11:38:40 --> Config Class Initialized
INFO - 2019-08-19 11:38:40 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:38:40 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:38:40 --> Utf8 Class Initialized
INFO - 2019-08-19 11:38:40 --> URI Class Initialized
INFO - 2019-08-19 11:38:40 --> Router Class Initialized
INFO - 2019-08-19 11:38:40 --> Output Class Initialized
INFO - 2019-08-19 11:38:40 --> Security Class Initialized
DEBUG - 2019-08-19 11:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:38:40 --> Input Class Initialized
INFO - 2019-08-19 11:38:40 --> Language Class Initialized
INFO - 2019-08-19 11:38:40 --> Loader Class Initialized
INFO - 2019-08-19 11:38:40 --> Helper loaded: url_helper
INFO - 2019-08-19 11:38:40 --> Helper loaded: html_helper
INFO - 2019-08-19 11:38:40 --> Helper loaded: form_helper
INFO - 2019-08-19 11:38:40 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:38:40 --> Helper loaded: date_helper
INFO - 2019-08-19 11:38:40 --> Form Validation Class Initialized
INFO - 2019-08-19 11:38:40 --> Email Class Initialized
DEBUG - 2019-08-19 11:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:38:40 --> Pagination Class Initialized
INFO - 2019-08-19 11:38:40 --> Database Driver Class Initialized
INFO - 2019-08-19 11:38:40 --> Database Driver Class Initialized
INFO - 2019-08-19 11:38:40 --> Controller Class Initialized
INFO - 2019-08-19 11:38:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 11:38:40 --> Config Class Initialized
INFO - 2019-08-19 11:38:40 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:38:40 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:38:40 --> Utf8 Class Initialized
INFO - 2019-08-19 11:38:40 --> URI Class Initialized
INFO - 2019-08-19 11:38:40 --> Router Class Initialized
INFO - 2019-08-19 11:38:40 --> Output Class Initialized
INFO - 2019-08-19 11:38:40 --> Security Class Initialized
DEBUG - 2019-08-19 11:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:38:40 --> Input Class Initialized
INFO - 2019-08-19 11:38:40 --> Language Class Initialized
INFO - 2019-08-19 11:38:40 --> Loader Class Initialized
INFO - 2019-08-19 11:38:40 --> Helper loaded: url_helper
INFO - 2019-08-19 11:38:40 --> Helper loaded: html_helper
INFO - 2019-08-19 11:38:40 --> Helper loaded: form_helper
INFO - 2019-08-19 11:38:40 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:38:40 --> Helper loaded: date_helper
INFO - 2019-08-19 11:38:40 --> Form Validation Class Initialized
INFO - 2019-08-19 11:38:40 --> Email Class Initialized
DEBUG - 2019-08-19 11:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:38:40 --> Pagination Class Initialized
INFO - 2019-08-19 11:38:40 --> Database Driver Class Initialized
INFO - 2019-08-19 11:38:40 --> Database Driver Class Initialized
INFO - 2019-08-19 11:38:40 --> Controller Class Initialized
INFO - 2019-08-19 11:38:40 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 11:38:40 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-19 11:38:40 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 11:38:40 --> Final output sent to browser
DEBUG - 2019-08-19 11:38:40 --> Total execution time: 0.1650
INFO - 2019-08-19 11:38:41 --> Config Class Initialized
INFO - 2019-08-19 11:38:41 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:38:41 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:38:41 --> Utf8 Class Initialized
INFO - 2019-08-19 11:38:41 --> URI Class Initialized
INFO - 2019-08-19 11:38:41 --> Router Class Initialized
INFO - 2019-08-19 11:38:41 --> Output Class Initialized
INFO - 2019-08-19 11:38:41 --> Security Class Initialized
DEBUG - 2019-08-19 11:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:38:41 --> Input Class Initialized
INFO - 2019-08-19 11:38:41 --> Language Class Initialized
INFO - 2019-08-19 11:38:41 --> Loader Class Initialized
INFO - 2019-08-19 11:38:41 --> Helper loaded: url_helper
INFO - 2019-08-19 11:38:41 --> Helper loaded: html_helper
INFO - 2019-08-19 11:38:41 --> Helper loaded: form_helper
INFO - 2019-08-19 11:38:41 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:38:41 --> Helper loaded: date_helper
INFO - 2019-08-19 11:38:41 --> Form Validation Class Initialized
INFO - 2019-08-19 11:38:41 --> Email Class Initialized
DEBUG - 2019-08-19 11:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:38:41 --> Pagination Class Initialized
INFO - 2019-08-19 11:38:41 --> Database Driver Class Initialized
INFO - 2019-08-19 11:38:41 --> Database Driver Class Initialized
INFO - 2019-08-19 11:38:41 --> Controller Class Initialized
INFO - 2019-08-19 11:38:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 11:38:41 --> Final output sent to browser
DEBUG - 2019-08-19 11:38:41 --> Total execution time: 0.1027
INFO - 2019-08-19 11:38:41 --> Config Class Initialized
INFO - 2019-08-19 11:38:41 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:38:41 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:38:41 --> Utf8 Class Initialized
INFO - 2019-08-19 11:38:41 --> URI Class Initialized
INFO - 2019-08-19 11:38:41 --> Router Class Initialized
INFO - 2019-08-19 11:38:41 --> Output Class Initialized
INFO - 2019-08-19 11:38:41 --> Security Class Initialized
DEBUG - 2019-08-19 11:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:38:41 --> Input Class Initialized
INFO - 2019-08-19 11:38:41 --> Language Class Initialized
INFO - 2019-08-19 11:38:41 --> Loader Class Initialized
INFO - 2019-08-19 11:38:41 --> Helper loaded: url_helper
INFO - 2019-08-19 11:38:41 --> Helper loaded: html_helper
INFO - 2019-08-19 11:38:41 --> Helper loaded: form_helper
INFO - 2019-08-19 11:38:41 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:38:41 --> Helper loaded: date_helper
INFO - 2019-08-19 11:38:41 --> Form Validation Class Initialized
INFO - 2019-08-19 11:38:41 --> Email Class Initialized
DEBUG - 2019-08-19 11:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:38:41 --> Pagination Class Initialized
INFO - 2019-08-19 11:38:41 --> Database Driver Class Initialized
INFO - 2019-08-19 11:38:41 --> Database Driver Class Initialized
INFO - 2019-08-19 11:38:41 --> Controller Class Initialized
INFO - 2019-08-19 11:38:41 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 11:38:41 --> Final output sent to browser
DEBUG - 2019-08-19 11:38:41 --> Total execution time: 0.0913
INFO - 2019-08-19 11:39:22 --> Config Class Initialized
INFO - 2019-08-19 11:39:22 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:39:22 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:39:22 --> Utf8 Class Initialized
INFO - 2019-08-19 11:39:22 --> URI Class Initialized
INFO - 2019-08-19 11:39:22 --> Router Class Initialized
INFO - 2019-08-19 11:39:22 --> Output Class Initialized
INFO - 2019-08-19 11:39:22 --> Security Class Initialized
DEBUG - 2019-08-19 11:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:39:22 --> Input Class Initialized
INFO - 2019-08-19 11:39:22 --> Language Class Initialized
INFO - 2019-08-19 11:39:22 --> Loader Class Initialized
INFO - 2019-08-19 11:39:22 --> Helper loaded: url_helper
INFO - 2019-08-19 11:39:22 --> Helper loaded: html_helper
INFO - 2019-08-19 11:39:22 --> Helper loaded: form_helper
INFO - 2019-08-19 11:39:22 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:39:22 --> Helper loaded: date_helper
INFO - 2019-08-19 11:39:22 --> Form Validation Class Initialized
INFO - 2019-08-19 11:39:22 --> Email Class Initialized
DEBUG - 2019-08-19 11:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:39:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:39:22 --> Pagination Class Initialized
INFO - 2019-08-19 11:39:22 --> Database Driver Class Initialized
INFO - 2019-08-19 11:39:22 --> Database Driver Class Initialized
INFO - 2019-08-19 11:39:22 --> Controller Class Initialized
INFO - 2019-08-19 11:39:22 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 11:39:22 --> Final output sent to browser
DEBUG - 2019-08-19 11:39:22 --> Total execution time: 0.0609
INFO - 2019-08-19 11:39:22 --> Config Class Initialized
INFO - 2019-08-19 11:39:22 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:39:22 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:39:22 --> Utf8 Class Initialized
INFO - 2019-08-19 11:39:22 --> URI Class Initialized
INFO - 2019-08-19 11:39:22 --> Router Class Initialized
INFO - 2019-08-19 11:39:22 --> Output Class Initialized
INFO - 2019-08-19 11:39:22 --> Security Class Initialized
DEBUG - 2019-08-19 11:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:39:22 --> Input Class Initialized
INFO - 2019-08-19 11:39:22 --> Language Class Initialized
INFO - 2019-08-19 11:39:22 --> Loader Class Initialized
INFO - 2019-08-19 11:39:22 --> Helper loaded: url_helper
INFO - 2019-08-19 11:39:22 --> Helper loaded: html_helper
INFO - 2019-08-19 11:39:22 --> Helper loaded: form_helper
INFO - 2019-08-19 11:39:22 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:39:22 --> Helper loaded: date_helper
INFO - 2019-08-19 11:39:22 --> Form Validation Class Initialized
INFO - 2019-08-19 11:39:22 --> Email Class Initialized
DEBUG - 2019-08-19 11:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:39:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:39:22 --> Pagination Class Initialized
INFO - 2019-08-19 11:39:22 --> Database Driver Class Initialized
INFO - 2019-08-19 11:39:22 --> Database Driver Class Initialized
INFO - 2019-08-19 11:39:22 --> Controller Class Initialized
INFO - 2019-08-19 11:39:22 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 11:39:22 --> Final output sent to browser
DEBUG - 2019-08-19 11:39:22 --> Total execution time: 0.0588
INFO - 2019-08-19 11:39:30 --> Config Class Initialized
INFO - 2019-08-19 11:39:30 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:39:30 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:39:30 --> Utf8 Class Initialized
INFO - 2019-08-19 11:39:30 --> URI Class Initialized
INFO - 2019-08-19 11:39:30 --> Router Class Initialized
INFO - 2019-08-19 11:39:30 --> Output Class Initialized
INFO - 2019-08-19 11:39:30 --> Security Class Initialized
DEBUG - 2019-08-19 11:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:39:30 --> Input Class Initialized
INFO - 2019-08-19 11:39:30 --> Language Class Initialized
INFO - 2019-08-19 11:39:30 --> Loader Class Initialized
INFO - 2019-08-19 11:39:30 --> Helper loaded: url_helper
INFO - 2019-08-19 11:39:30 --> Helper loaded: html_helper
INFO - 2019-08-19 11:39:30 --> Helper loaded: form_helper
INFO - 2019-08-19 11:39:30 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:39:30 --> Helper loaded: date_helper
INFO - 2019-08-19 11:39:30 --> Form Validation Class Initialized
INFO - 2019-08-19 11:39:30 --> Email Class Initialized
DEBUG - 2019-08-19 11:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:39:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:39:30 --> Pagination Class Initialized
INFO - 2019-08-19 11:39:30 --> Database Driver Class Initialized
INFO - 2019-08-19 11:39:30 --> Database Driver Class Initialized
INFO - 2019-08-19 11:39:30 --> Controller Class Initialized
INFO - 2019-08-19 11:39:30 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 11:39:30 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/site.php
INFO - 2019-08-19 11:39:30 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 11:39:30 --> Final output sent to browser
DEBUG - 2019-08-19 11:39:30 --> Total execution time: 0.1260
INFO - 2019-08-19 11:39:30 --> Config Class Initialized
INFO - 2019-08-19 11:39:30 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:39:30 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:39:30 --> Utf8 Class Initialized
INFO - 2019-08-19 11:39:30 --> URI Class Initialized
INFO - 2019-08-19 11:39:30 --> Router Class Initialized
INFO - 2019-08-19 11:39:30 --> Output Class Initialized
INFO - 2019-08-19 11:39:30 --> Security Class Initialized
DEBUG - 2019-08-19 11:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:39:30 --> Input Class Initialized
INFO - 2019-08-19 11:39:30 --> Language Class Initialized
INFO - 2019-08-19 11:39:30 --> Loader Class Initialized
INFO - 2019-08-19 11:39:30 --> Helper loaded: url_helper
INFO - 2019-08-19 11:39:30 --> Helper loaded: html_helper
INFO - 2019-08-19 11:39:30 --> Helper loaded: form_helper
INFO - 2019-08-19 11:39:30 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:39:30 --> Helper loaded: date_helper
INFO - 2019-08-19 11:39:30 --> Form Validation Class Initialized
INFO - 2019-08-19 11:39:30 --> Email Class Initialized
DEBUG - 2019-08-19 11:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:39:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:39:30 --> Pagination Class Initialized
INFO - 2019-08-19 11:39:30 --> Database Driver Class Initialized
INFO - 2019-08-19 11:39:30 --> Database Driver Class Initialized
INFO - 2019-08-19 11:39:30 --> Controller Class Initialized
INFO - 2019-08-19 11:39:30 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 11:39:30 --> Final output sent to browser
DEBUG - 2019-08-19 11:39:30 --> Total execution time: 0.0664
INFO - 2019-08-19 11:39:30 --> Config Class Initialized
INFO - 2019-08-19 11:39:30 --> Hooks Class Initialized
DEBUG - 2019-08-19 11:39:30 --> UTF-8 Support Enabled
INFO - 2019-08-19 11:39:30 --> Utf8 Class Initialized
INFO - 2019-08-19 11:39:30 --> URI Class Initialized
INFO - 2019-08-19 11:39:30 --> Router Class Initialized
INFO - 2019-08-19 11:39:30 --> Output Class Initialized
INFO - 2019-08-19 11:39:30 --> Security Class Initialized
DEBUG - 2019-08-19 11:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 11:39:30 --> Input Class Initialized
INFO - 2019-08-19 11:39:30 --> Language Class Initialized
INFO - 2019-08-19 11:39:30 --> Loader Class Initialized
INFO - 2019-08-19 11:39:30 --> Helper loaded: url_helper
INFO - 2019-08-19 11:39:30 --> Helper loaded: html_helper
INFO - 2019-08-19 11:39:30 --> Helper loaded: form_helper
INFO - 2019-08-19 11:39:30 --> Helper loaded: cookie_helper
INFO - 2019-08-19 11:39:30 --> Helper loaded: date_helper
INFO - 2019-08-19 11:39:30 --> Form Validation Class Initialized
INFO - 2019-08-19 11:39:30 --> Email Class Initialized
DEBUG - 2019-08-19 11:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 11:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 11:39:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 11:39:30 --> Pagination Class Initialized
INFO - 2019-08-19 11:39:30 --> Database Driver Class Initialized
INFO - 2019-08-19 11:39:30 --> Database Driver Class Initialized
INFO - 2019-08-19 11:39:30 --> Controller Class Initialized
INFO - 2019-08-19 11:39:30 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 11:39:30 --> Final output sent to browser
DEBUG - 2019-08-19 11:39:30 --> Total execution time: 0.1013
INFO - 2019-08-19 13:56:58 --> Config Class Initialized
INFO - 2019-08-19 13:56:58 --> Hooks Class Initialized
DEBUG - 2019-08-19 13:56:58 --> UTF-8 Support Enabled
INFO - 2019-08-19 13:56:58 --> Utf8 Class Initialized
INFO - 2019-08-19 13:56:58 --> URI Class Initialized
INFO - 2019-08-19 13:56:58 --> Router Class Initialized
INFO - 2019-08-19 13:56:58 --> Output Class Initialized
INFO - 2019-08-19 13:56:58 --> Security Class Initialized
DEBUG - 2019-08-19 13:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 13:56:58 --> Input Class Initialized
INFO - 2019-08-19 13:56:58 --> Language Class Initialized
INFO - 2019-08-19 13:56:58 --> Loader Class Initialized
INFO - 2019-08-19 13:56:58 --> Helper loaded: url_helper
INFO - 2019-08-19 13:56:58 --> Helper loaded: html_helper
INFO - 2019-08-19 13:56:58 --> Helper loaded: form_helper
INFO - 2019-08-19 13:56:58 --> Helper loaded: cookie_helper
INFO - 2019-08-19 13:56:58 --> Helper loaded: date_helper
INFO - 2019-08-19 13:56:58 --> Form Validation Class Initialized
INFO - 2019-08-19 13:56:58 --> Email Class Initialized
DEBUG - 2019-08-19 13:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 13:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 13:56:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 13:56:58 --> Pagination Class Initialized
INFO - 2019-08-19 13:56:58 --> Database Driver Class Initialized
INFO - 2019-08-19 13:56:58 --> Database Driver Class Initialized
INFO - 2019-08-19 13:56:58 --> Controller Class Initialized
INFO - 2019-08-19 13:56:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 13:56:58 --> Final output sent to browser
DEBUG - 2019-08-19 13:56:58 --> Total execution time: 0.1560
INFO - 2019-08-19 13:57:41 --> Config Class Initialized
INFO - 2019-08-19 13:57:41 --> Hooks Class Initialized
DEBUG - 2019-08-19 13:57:41 --> UTF-8 Support Enabled
INFO - 2019-08-19 13:57:41 --> Utf8 Class Initialized
INFO - 2019-08-19 13:57:41 --> URI Class Initialized
INFO - 2019-08-19 13:57:41 --> Router Class Initialized
INFO - 2019-08-19 13:57:41 --> Output Class Initialized
INFO - 2019-08-19 13:57:41 --> Security Class Initialized
DEBUG - 2019-08-19 13:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 13:57:41 --> Input Class Initialized
INFO - 2019-08-19 13:57:41 --> Language Class Initialized
INFO - 2019-08-19 13:57:41 --> Loader Class Initialized
INFO - 2019-08-19 13:57:41 --> Helper loaded: url_helper
INFO - 2019-08-19 13:57:41 --> Helper loaded: html_helper
INFO - 2019-08-19 13:57:41 --> Helper loaded: form_helper
INFO - 2019-08-19 13:57:41 --> Helper loaded: cookie_helper
INFO - 2019-08-19 13:57:41 --> Helper loaded: date_helper
INFO - 2019-08-19 13:57:41 --> Form Validation Class Initialized
INFO - 2019-08-19 13:57:41 --> Email Class Initialized
DEBUG - 2019-08-19 13:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 13:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 13:57:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 13:57:41 --> Pagination Class Initialized
INFO - 2019-08-19 13:57:41 --> Database Driver Class Initialized
INFO - 2019-08-19 13:57:41 --> Database Driver Class Initialized
INFO - 2019-08-19 13:57:41 --> Controller Class Initialized
INFO - 2019-08-19 13:57:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 13:57:42 --> Config Class Initialized
INFO - 2019-08-19 13:57:42 --> Hooks Class Initialized
DEBUG - 2019-08-19 13:57:42 --> UTF-8 Support Enabled
INFO - 2019-08-19 13:57:42 --> Utf8 Class Initialized
INFO - 2019-08-19 13:57:42 --> URI Class Initialized
INFO - 2019-08-19 13:57:42 --> Router Class Initialized
INFO - 2019-08-19 13:57:42 --> Output Class Initialized
INFO - 2019-08-19 13:57:42 --> Security Class Initialized
DEBUG - 2019-08-19 13:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 13:57:42 --> Input Class Initialized
INFO - 2019-08-19 13:57:42 --> Language Class Initialized
INFO - 2019-08-19 13:57:42 --> Loader Class Initialized
INFO - 2019-08-19 13:57:42 --> Helper loaded: url_helper
INFO - 2019-08-19 13:57:42 --> Helper loaded: html_helper
INFO - 2019-08-19 13:57:42 --> Helper loaded: form_helper
INFO - 2019-08-19 13:57:42 --> Helper loaded: cookie_helper
INFO - 2019-08-19 13:57:42 --> Helper loaded: date_helper
INFO - 2019-08-19 13:57:42 --> Form Validation Class Initialized
INFO - 2019-08-19 13:57:42 --> Email Class Initialized
DEBUG - 2019-08-19 13:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 13:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 13:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 13:57:42 --> Pagination Class Initialized
INFO - 2019-08-19 13:57:42 --> Database Driver Class Initialized
INFO - 2019-08-19 13:57:42 --> Database Driver Class Initialized
INFO - 2019-08-19 13:57:42 --> Controller Class Initialized
INFO - 2019-08-19 13:57:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 13:57:42 --> Final output sent to browser
DEBUG - 2019-08-19 13:57:42 --> Total execution time: 0.1872
INFO - 2019-08-19 13:59:30 --> Config Class Initialized
INFO - 2019-08-19 13:59:30 --> Hooks Class Initialized
DEBUG - 2019-08-19 13:59:30 --> UTF-8 Support Enabled
INFO - 2019-08-19 13:59:30 --> Utf8 Class Initialized
INFO - 2019-08-19 13:59:30 --> URI Class Initialized
INFO - 2019-08-19 13:59:30 --> Router Class Initialized
INFO - 2019-08-19 13:59:30 --> Output Class Initialized
INFO - 2019-08-19 13:59:30 --> Security Class Initialized
DEBUG - 2019-08-19 13:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 13:59:30 --> Input Class Initialized
INFO - 2019-08-19 13:59:30 --> Language Class Initialized
INFO - 2019-08-19 13:59:30 --> Loader Class Initialized
INFO - 2019-08-19 13:59:30 --> Helper loaded: url_helper
INFO - 2019-08-19 13:59:30 --> Helper loaded: html_helper
INFO - 2019-08-19 13:59:30 --> Helper loaded: form_helper
INFO - 2019-08-19 13:59:30 --> Helper loaded: cookie_helper
INFO - 2019-08-19 13:59:30 --> Helper loaded: date_helper
INFO - 2019-08-19 13:59:30 --> Form Validation Class Initialized
INFO - 2019-08-19 13:59:30 --> Email Class Initialized
DEBUG - 2019-08-19 13:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 13:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 13:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 13:59:30 --> Pagination Class Initialized
INFO - 2019-08-19 13:59:30 --> Database Driver Class Initialized
INFO - 2019-08-19 13:59:30 --> Database Driver Class Initialized
INFO - 2019-08-19 13:59:30 --> Controller Class Initialized
INFO - 2019-08-19 13:59:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 13:59:30 --> Config Class Initialized
INFO - 2019-08-19 13:59:30 --> Hooks Class Initialized
DEBUG - 2019-08-19 13:59:30 --> UTF-8 Support Enabled
INFO - 2019-08-19 13:59:30 --> Utf8 Class Initialized
INFO - 2019-08-19 13:59:30 --> URI Class Initialized
INFO - 2019-08-19 13:59:30 --> Router Class Initialized
INFO - 2019-08-19 13:59:30 --> Output Class Initialized
INFO - 2019-08-19 13:59:30 --> Security Class Initialized
DEBUG - 2019-08-19 13:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 13:59:30 --> Input Class Initialized
INFO - 2019-08-19 13:59:30 --> Language Class Initialized
INFO - 2019-08-19 13:59:30 --> Loader Class Initialized
INFO - 2019-08-19 13:59:30 --> Helper loaded: url_helper
INFO - 2019-08-19 13:59:30 --> Helper loaded: html_helper
INFO - 2019-08-19 13:59:30 --> Helper loaded: form_helper
INFO - 2019-08-19 13:59:30 --> Helper loaded: cookie_helper
INFO - 2019-08-19 13:59:30 --> Helper loaded: date_helper
INFO - 2019-08-19 13:59:30 --> Form Validation Class Initialized
INFO - 2019-08-19 13:59:30 --> Email Class Initialized
DEBUG - 2019-08-19 13:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 13:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 13:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 13:59:30 --> Pagination Class Initialized
INFO - 2019-08-19 13:59:30 --> Database Driver Class Initialized
INFO - 2019-08-19 13:59:30 --> Database Driver Class Initialized
INFO - 2019-08-19 13:59:30 --> Controller Class Initialized
INFO - 2019-08-19 13:59:30 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 13:59:30 --> Final output sent to browser
DEBUG - 2019-08-19 13:59:30 --> Total execution time: 0.2028
INFO - 2019-08-19 14:02:28 --> Config Class Initialized
INFO - 2019-08-19 14:02:28 --> Hooks Class Initialized
DEBUG - 2019-08-19 14:02:28 --> UTF-8 Support Enabled
INFO - 2019-08-19 14:02:28 --> Utf8 Class Initialized
INFO - 2019-08-19 14:02:28 --> URI Class Initialized
INFO - 2019-08-19 14:02:28 --> Router Class Initialized
INFO - 2019-08-19 14:02:28 --> Output Class Initialized
INFO - 2019-08-19 14:02:28 --> Security Class Initialized
DEBUG - 2019-08-19 14:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 14:02:28 --> Input Class Initialized
INFO - 2019-08-19 14:02:28 --> Language Class Initialized
INFO - 2019-08-19 14:02:28 --> Loader Class Initialized
INFO - 2019-08-19 14:02:28 --> Helper loaded: url_helper
INFO - 2019-08-19 14:02:28 --> Helper loaded: html_helper
INFO - 2019-08-19 14:02:28 --> Helper loaded: form_helper
INFO - 2019-08-19 14:02:28 --> Helper loaded: cookie_helper
INFO - 2019-08-19 14:02:28 --> Helper loaded: date_helper
INFO - 2019-08-19 14:02:28 --> Form Validation Class Initialized
INFO - 2019-08-19 14:02:28 --> Email Class Initialized
DEBUG - 2019-08-19 14:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 14:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 14:02:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 14:02:28 --> Pagination Class Initialized
INFO - 2019-08-19 14:02:28 --> Database Driver Class Initialized
INFO - 2019-08-19 14:02:28 --> Database Driver Class Initialized
INFO - 2019-08-19 14:02:28 --> Controller Class Initialized
INFO - 2019-08-19 14:02:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 14:02:28 --> Config Class Initialized
INFO - 2019-08-19 14:02:28 --> Hooks Class Initialized
DEBUG - 2019-08-19 14:02:28 --> UTF-8 Support Enabled
INFO - 2019-08-19 14:02:28 --> Utf8 Class Initialized
INFO - 2019-08-19 14:02:28 --> URI Class Initialized
INFO - 2019-08-19 14:02:28 --> Router Class Initialized
INFO - 2019-08-19 14:02:28 --> Output Class Initialized
INFO - 2019-08-19 14:02:28 --> Security Class Initialized
DEBUG - 2019-08-19 14:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 14:02:28 --> Input Class Initialized
INFO - 2019-08-19 14:02:28 --> Language Class Initialized
INFO - 2019-08-19 14:02:28 --> Loader Class Initialized
INFO - 2019-08-19 14:02:28 --> Helper loaded: url_helper
INFO - 2019-08-19 14:02:28 --> Helper loaded: html_helper
INFO - 2019-08-19 14:02:28 --> Helper loaded: form_helper
INFO - 2019-08-19 14:02:28 --> Helper loaded: cookie_helper
INFO - 2019-08-19 14:02:28 --> Helper loaded: date_helper
INFO - 2019-08-19 14:02:28 --> Form Validation Class Initialized
INFO - 2019-08-19 14:02:28 --> Email Class Initialized
DEBUG - 2019-08-19 14:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 14:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 14:02:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 14:02:28 --> Pagination Class Initialized
INFO - 2019-08-19 14:02:28 --> Database Driver Class Initialized
INFO - 2019-08-19 14:02:28 --> Database Driver Class Initialized
INFO - 2019-08-19 14:02:28 --> Controller Class Initialized
INFO - 2019-08-19 14:02:28 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 14:02:28 --> Final output sent to browser
DEBUG - 2019-08-19 14:02:28 --> Total execution time: 0.1560
INFO - 2019-08-19 14:19:16 --> Config Class Initialized
INFO - 2019-08-19 14:19:16 --> Hooks Class Initialized
DEBUG - 2019-08-19 14:19:16 --> UTF-8 Support Enabled
INFO - 2019-08-19 14:19:16 --> Utf8 Class Initialized
INFO - 2019-08-19 14:19:16 --> URI Class Initialized
INFO - 2019-08-19 14:19:16 --> Router Class Initialized
INFO - 2019-08-19 14:19:16 --> Output Class Initialized
INFO - 2019-08-19 14:19:16 --> Security Class Initialized
DEBUG - 2019-08-19 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 14:19:16 --> Input Class Initialized
INFO - 2019-08-19 14:19:16 --> Language Class Initialized
INFO - 2019-08-19 14:19:16 --> Loader Class Initialized
INFO - 2019-08-19 14:19:16 --> Helper loaded: url_helper
INFO - 2019-08-19 14:19:16 --> Helper loaded: html_helper
INFO - 2019-08-19 14:19:16 --> Helper loaded: form_helper
INFO - 2019-08-19 14:19:16 --> Helper loaded: cookie_helper
INFO - 2019-08-19 14:19:16 --> Helper loaded: date_helper
INFO - 2019-08-19 14:19:16 --> Form Validation Class Initialized
INFO - 2019-08-19 14:19:16 --> Email Class Initialized
DEBUG - 2019-08-19 14:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 14:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 14:19:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 14:19:16 --> Pagination Class Initialized
INFO - 2019-08-19 14:19:16 --> Database Driver Class Initialized
INFO - 2019-08-19 14:19:16 --> Database Driver Class Initialized
INFO - 2019-08-19 14:19:16 --> Controller Class Initialized
INFO - 2019-08-19 14:19:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 14:19:16 --> Config Class Initialized
INFO - 2019-08-19 14:19:16 --> Hooks Class Initialized
DEBUG - 2019-08-19 14:19:16 --> UTF-8 Support Enabled
INFO - 2019-08-19 14:19:16 --> Utf8 Class Initialized
INFO - 2019-08-19 14:19:16 --> URI Class Initialized
INFO - 2019-08-19 14:19:16 --> Router Class Initialized
INFO - 2019-08-19 14:19:16 --> Output Class Initialized
INFO - 2019-08-19 14:19:16 --> Security Class Initialized
DEBUG - 2019-08-19 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 14:19:16 --> Input Class Initialized
INFO - 2019-08-19 14:19:16 --> Language Class Initialized
INFO - 2019-08-19 14:19:16 --> Loader Class Initialized
INFO - 2019-08-19 14:19:16 --> Helper loaded: url_helper
INFO - 2019-08-19 14:19:16 --> Helper loaded: html_helper
INFO - 2019-08-19 14:19:16 --> Helper loaded: form_helper
INFO - 2019-08-19 14:19:16 --> Helper loaded: cookie_helper
INFO - 2019-08-19 14:19:16 --> Helper loaded: date_helper
INFO - 2019-08-19 14:19:16 --> Form Validation Class Initialized
INFO - 2019-08-19 14:19:16 --> Email Class Initialized
DEBUG - 2019-08-19 14:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 14:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 14:19:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 14:19:16 --> Pagination Class Initialized
INFO - 2019-08-19 14:19:16 --> Database Driver Class Initialized
INFO - 2019-08-19 14:19:16 --> Database Driver Class Initialized
INFO - 2019-08-19 14:19:16 --> Controller Class Initialized
INFO - 2019-08-19 14:19:16 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 14:19:16 --> Final output sent to browser
DEBUG - 2019-08-19 14:19:16 --> Total execution time: 0.1990
INFO - 2019-08-19 14:32:55 --> Config Class Initialized
INFO - 2019-08-19 14:32:55 --> Hooks Class Initialized
DEBUG - 2019-08-19 14:32:55 --> UTF-8 Support Enabled
INFO - 2019-08-19 14:32:55 --> Utf8 Class Initialized
INFO - 2019-08-19 14:32:55 --> URI Class Initialized
INFO - 2019-08-19 14:32:55 --> Router Class Initialized
INFO - 2019-08-19 14:32:55 --> Output Class Initialized
INFO - 2019-08-19 14:32:55 --> Security Class Initialized
DEBUG - 2019-08-19 14:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 14:32:55 --> Input Class Initialized
INFO - 2019-08-19 14:32:55 --> Language Class Initialized
INFO - 2019-08-19 14:32:55 --> Loader Class Initialized
INFO - 2019-08-19 14:32:55 --> Helper loaded: url_helper
INFO - 2019-08-19 14:32:55 --> Helper loaded: html_helper
INFO - 2019-08-19 14:32:55 --> Helper loaded: form_helper
INFO - 2019-08-19 14:32:55 --> Helper loaded: cookie_helper
INFO - 2019-08-19 14:32:55 --> Helper loaded: date_helper
INFO - 2019-08-19 14:32:55 --> Form Validation Class Initialized
INFO - 2019-08-19 14:32:55 --> Email Class Initialized
DEBUG - 2019-08-19 14:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 14:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 14:32:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 14:32:55 --> Pagination Class Initialized
INFO - 2019-08-19 14:32:55 --> Database Driver Class Initialized
INFO - 2019-08-19 14:32:55 --> Database Driver Class Initialized
INFO - 2019-08-19 14:32:56 --> Controller Class Initialized
INFO - 2019-08-19 14:32:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 14:32:56 --> Config Class Initialized
INFO - 2019-08-19 14:32:56 --> Hooks Class Initialized
DEBUG - 2019-08-19 14:32:56 --> UTF-8 Support Enabled
INFO - 2019-08-19 14:32:56 --> Utf8 Class Initialized
INFO - 2019-08-19 14:32:56 --> URI Class Initialized
INFO - 2019-08-19 14:32:56 --> Router Class Initialized
INFO - 2019-08-19 14:32:56 --> Output Class Initialized
INFO - 2019-08-19 14:32:56 --> Security Class Initialized
DEBUG - 2019-08-19 14:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 14:32:56 --> Input Class Initialized
INFO - 2019-08-19 14:32:56 --> Language Class Initialized
INFO - 2019-08-19 14:32:56 --> Loader Class Initialized
INFO - 2019-08-19 14:32:56 --> Helper loaded: url_helper
INFO - 2019-08-19 14:32:56 --> Helper loaded: html_helper
INFO - 2019-08-19 14:32:56 --> Helper loaded: form_helper
INFO - 2019-08-19 14:32:56 --> Helper loaded: cookie_helper
INFO - 2019-08-19 14:32:56 --> Helper loaded: date_helper
INFO - 2019-08-19 14:32:56 --> Form Validation Class Initialized
INFO - 2019-08-19 14:32:56 --> Email Class Initialized
DEBUG - 2019-08-19 14:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 14:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 14:32:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 14:32:56 --> Pagination Class Initialized
INFO - 2019-08-19 14:32:56 --> Database Driver Class Initialized
INFO - 2019-08-19 14:32:56 --> Database Driver Class Initialized
INFO - 2019-08-19 14:32:56 --> Controller Class Initialized
INFO - 2019-08-19 14:32:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-19 14:32:56 --> Final output sent to browser
DEBUG - 2019-08-19 14:32:56 --> Total execution time: 0.1860
INFO - 2019-08-19 15:05:42 --> Config Class Initialized
INFO - 2019-08-19 15:05:42 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:05:42 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:05:42 --> Utf8 Class Initialized
INFO - 2019-08-19 15:05:42 --> URI Class Initialized
INFO - 2019-08-19 15:05:42 --> Router Class Initialized
INFO - 2019-08-19 15:05:42 --> Output Class Initialized
INFO - 2019-08-19 15:05:42 --> Security Class Initialized
DEBUG - 2019-08-19 15:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:05:42 --> Input Class Initialized
INFO - 2019-08-19 15:05:42 --> Language Class Initialized
INFO - 2019-08-19 15:05:42 --> Loader Class Initialized
INFO - 2019-08-19 15:05:42 --> Helper loaded: url_helper
INFO - 2019-08-19 15:05:42 --> Helper loaded: html_helper
INFO - 2019-08-19 15:05:42 --> Helper loaded: form_helper
INFO - 2019-08-19 15:05:42 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:05:42 --> Helper loaded: date_helper
INFO - 2019-08-19 15:05:42 --> Form Validation Class Initialized
INFO - 2019-08-19 15:05:42 --> Email Class Initialized
DEBUG - 2019-08-19 15:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:05:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:05:42 --> Pagination Class Initialized
INFO - 2019-08-19 15:05:42 --> Database Driver Class Initialized
INFO - 2019-08-19 15:05:42 --> Database Driver Class Initialized
INFO - 2019-08-19 15:05:42 --> Controller Class Initialized
INFO - 2019-08-19 15:05:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 15:05:42 --> Config Class Initialized
INFO - 2019-08-19 15:05:42 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:05:42 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:05:42 --> Utf8 Class Initialized
INFO - 2019-08-19 15:05:42 --> URI Class Initialized
INFO - 2019-08-19 15:05:42 --> Router Class Initialized
INFO - 2019-08-19 15:05:42 --> Output Class Initialized
INFO - 2019-08-19 15:05:42 --> Security Class Initialized
DEBUG - 2019-08-19 15:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:05:42 --> Input Class Initialized
INFO - 2019-08-19 15:05:42 --> Language Class Initialized
INFO - 2019-08-19 15:05:42 --> Loader Class Initialized
INFO - 2019-08-19 15:05:42 --> Helper loaded: url_helper
INFO - 2019-08-19 15:05:42 --> Helper loaded: html_helper
INFO - 2019-08-19 15:05:42 --> Helper loaded: form_helper
INFO - 2019-08-19 15:05:42 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:05:42 --> Helper loaded: date_helper
INFO - 2019-08-19 15:05:42 --> Form Validation Class Initialized
INFO - 2019-08-19 15:05:42 --> Email Class Initialized
DEBUG - 2019-08-19 15:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:05:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:05:42 --> Pagination Class Initialized
INFO - 2019-08-19 15:05:42 --> Database Driver Class Initialized
INFO - 2019-08-19 15:05:42 --> Database Driver Class Initialized
INFO - 2019-08-19 15:05:42 --> Controller Class Initialized
INFO - 2019-08-19 15:05:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 15:05:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-19 15:05:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 15:05:43 --> Final output sent to browser
DEBUG - 2019-08-19 15:05:43 --> Total execution time: 0.4050
INFO - 2019-08-19 15:06:25 --> Config Class Initialized
INFO - 2019-08-19 15:06:25 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:06:25 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:06:25 --> Utf8 Class Initialized
INFO - 2019-08-19 15:06:25 --> URI Class Initialized
INFO - 2019-08-19 15:06:25 --> Router Class Initialized
INFO - 2019-08-19 15:06:25 --> Output Class Initialized
INFO - 2019-08-19 15:06:25 --> Security Class Initialized
DEBUG - 2019-08-19 15:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:06:25 --> Input Class Initialized
INFO - 2019-08-19 15:06:25 --> Language Class Initialized
INFO - 2019-08-19 15:06:25 --> Loader Class Initialized
INFO - 2019-08-19 15:06:25 --> Config Class Initialized
INFO - 2019-08-19 15:06:25 --> Hooks Class Initialized
INFO - 2019-08-19 15:06:25 --> Helper loaded: url_helper
INFO - 2019-08-19 15:06:25 --> Helper loaded: html_helper
DEBUG - 2019-08-19 15:06:25 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:06:25 --> Utf8 Class Initialized
INFO - 2019-08-19 15:06:25 --> Helper loaded: form_helper
INFO - 2019-08-19 15:06:25 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:06:25 --> URI Class Initialized
INFO - 2019-08-19 15:06:25 --> Helper loaded: date_helper
INFO - 2019-08-19 15:06:25 --> Form Validation Class Initialized
INFO - 2019-08-19 15:06:25 --> Email Class Initialized
INFO - 2019-08-19 15:06:25 --> Router Class Initialized
INFO - 2019-08-19 15:06:25 --> Output Class Initialized
INFO - 2019-08-19 15:06:25 --> Security Class Initialized
DEBUG - 2019-08-19 15:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-19 15:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:06:25 --> Input Class Initialized
INFO - 2019-08-19 15:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:06:25 --> Language Class Initialized
INFO - 2019-08-19 15:06:25 --> Loader Class Initialized
INFO - 2019-08-19 15:06:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:06:25 --> Pagination Class Initialized
INFO - 2019-08-19 15:06:25 --> Helper loaded: url_helper
INFO - 2019-08-19 15:06:25 --> Helper loaded: html_helper
INFO - 2019-08-19 15:06:25 --> Helper loaded: form_helper
INFO - 2019-08-19 15:06:25 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:06:25 --> Helper loaded: date_helper
INFO - 2019-08-19 15:06:25 --> Form Validation Class Initialized
INFO - 2019-08-19 15:06:25 --> Email Class Initialized
DEBUG - 2019-08-19 15:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:06:25 --> Database Driver Class Initialized
INFO - 2019-08-19 15:06:25 --> Database Driver Class Initialized
INFO - 2019-08-19 15:06:25 --> Controller Class Initialized
INFO - 2019-08-19 15:06:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 15:06:25 --> Final output sent to browser
DEBUG - 2019-08-19 15:06:25 --> Total execution time: 0.3250
INFO - 2019-08-19 15:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:06:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:06:25 --> Pagination Class Initialized
INFO - 2019-08-19 15:06:25 --> Database Driver Class Initialized
INFO - 2019-08-19 15:06:25 --> Database Driver Class Initialized
INFO - 2019-08-19 15:06:25 --> Controller Class Initialized
INFO - 2019-08-19 15:06:26 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 15:06:26 --> Final output sent to browser
DEBUG - 2019-08-19 15:06:26 --> Total execution time: 0.3340
INFO - 2019-08-19 15:07:28 --> Config Class Initialized
INFO - 2019-08-19 15:07:28 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:07:28 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:07:28 --> Utf8 Class Initialized
INFO - 2019-08-19 15:07:28 --> URI Class Initialized
INFO - 2019-08-19 15:07:28 --> Router Class Initialized
INFO - 2019-08-19 15:07:28 --> Output Class Initialized
INFO - 2019-08-19 15:07:28 --> Security Class Initialized
DEBUG - 2019-08-19 15:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:07:28 --> Input Class Initialized
INFO - 2019-08-19 15:07:28 --> Language Class Initialized
INFO - 2019-08-19 15:07:28 --> Loader Class Initialized
INFO - 2019-08-19 15:07:28 --> Helper loaded: url_helper
INFO - 2019-08-19 15:07:28 --> Helper loaded: html_helper
INFO - 2019-08-19 15:07:28 --> Helper loaded: form_helper
INFO - 2019-08-19 15:07:28 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:07:28 --> Helper loaded: date_helper
INFO - 2019-08-19 15:07:28 --> Form Validation Class Initialized
INFO - 2019-08-19 15:07:28 --> Email Class Initialized
DEBUG - 2019-08-19 15:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:07:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:07:28 --> Pagination Class Initialized
INFO - 2019-08-19 15:07:28 --> Database Driver Class Initialized
INFO - 2019-08-19 15:07:28 --> Database Driver Class Initialized
INFO - 2019-08-19 15:07:28 --> Controller Class Initialized
INFO - 2019-08-19 15:07:28 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 15:07:28 --> Final output sent to browser
DEBUG - 2019-08-19 15:07:28 --> Total execution time: 0.3550
INFO - 2019-08-19 15:07:29 --> Config Class Initialized
INFO - 2019-08-19 15:07:29 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:07:29 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:07:29 --> Utf8 Class Initialized
INFO - 2019-08-19 15:07:29 --> URI Class Initialized
INFO - 2019-08-19 15:07:29 --> Router Class Initialized
INFO - 2019-08-19 15:07:29 --> Output Class Initialized
INFO - 2019-08-19 15:07:29 --> Security Class Initialized
DEBUG - 2019-08-19 15:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:07:29 --> Input Class Initialized
INFO - 2019-08-19 15:07:29 --> Language Class Initialized
INFO - 2019-08-19 15:07:29 --> Loader Class Initialized
INFO - 2019-08-19 15:07:29 --> Helper loaded: url_helper
INFO - 2019-08-19 15:07:29 --> Helper loaded: html_helper
INFO - 2019-08-19 15:07:29 --> Helper loaded: form_helper
INFO - 2019-08-19 15:07:29 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:07:29 --> Helper loaded: date_helper
INFO - 2019-08-19 15:07:29 --> Form Validation Class Initialized
INFO - 2019-08-19 15:07:29 --> Email Class Initialized
DEBUG - 2019-08-19 15:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:07:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:07:29 --> Pagination Class Initialized
INFO - 2019-08-19 15:07:29 --> Database Driver Class Initialized
INFO - 2019-08-19 15:07:29 --> Database Driver Class Initialized
INFO - 2019-08-19 15:07:29 --> Controller Class Initialized
INFO - 2019-08-19 15:07:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 15:07:29 --> Final output sent to browser
DEBUG - 2019-08-19 15:07:29 --> Total execution time: 0.2070
INFO - 2019-08-19 15:14:59 --> Config Class Initialized
INFO - 2019-08-19 15:14:59 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:14:59 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:14:59 --> Utf8 Class Initialized
INFO - 2019-08-19 15:14:59 --> URI Class Initialized
INFO - 2019-08-19 15:14:59 --> Router Class Initialized
INFO - 2019-08-19 15:14:59 --> Output Class Initialized
INFO - 2019-08-19 15:14:59 --> Security Class Initialized
DEBUG - 2019-08-19 15:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:14:59 --> Input Class Initialized
INFO - 2019-08-19 15:14:59 --> Language Class Initialized
INFO - 2019-08-19 15:14:59 --> Loader Class Initialized
INFO - 2019-08-19 15:14:59 --> Helper loaded: url_helper
INFO - 2019-08-19 15:14:59 --> Helper loaded: html_helper
INFO - 2019-08-19 15:14:59 --> Helper loaded: form_helper
INFO - 2019-08-19 15:14:59 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:14:59 --> Helper loaded: date_helper
INFO - 2019-08-19 15:14:59 --> Form Validation Class Initialized
INFO - 2019-08-19 15:14:59 --> Email Class Initialized
DEBUG - 2019-08-19 15:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:14:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:14:59 --> Pagination Class Initialized
INFO - 2019-08-19 15:14:59 --> Database Driver Class Initialized
INFO - 2019-08-19 15:14:59 --> Database Driver Class Initialized
INFO - 2019-08-19 15:14:59 --> Controller Class Initialized
INFO - 2019-08-19 15:15:00 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 15:15:00 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-19 15:15:00 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-19 15:15:00 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 15:15:00 --> Final output sent to browser
DEBUG - 2019-08-19 15:15:00 --> Total execution time: 0.5570
INFO - 2019-08-19 15:15:20 --> Config Class Initialized
INFO - 2019-08-19 15:15:20 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:15:20 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:15:20 --> Utf8 Class Initialized
INFO - 2019-08-19 15:15:20 --> URI Class Initialized
INFO - 2019-08-19 15:15:20 --> Router Class Initialized
INFO - 2019-08-19 15:15:20 --> Output Class Initialized
INFO - 2019-08-19 15:15:20 --> Security Class Initialized
DEBUG - 2019-08-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:15:20 --> Input Class Initialized
INFO - 2019-08-19 15:15:20 --> Language Class Initialized
INFO - 2019-08-19 15:15:20 --> Loader Class Initialized
INFO - 2019-08-19 15:15:20 --> Config Class Initialized
INFO - 2019-08-19 15:15:20 --> Hooks Class Initialized
INFO - 2019-08-19 15:15:20 --> Helper loaded: url_helper
DEBUG - 2019-08-19 15:15:20 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:15:20 --> Utf8 Class Initialized
INFO - 2019-08-19 15:15:20 --> Helper loaded: html_helper
INFO - 2019-08-19 15:15:20 --> URI Class Initialized
INFO - 2019-08-19 15:15:20 --> Helper loaded: form_helper
INFO - 2019-08-19 15:15:20 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:15:20 --> Helper loaded: date_helper
INFO - 2019-08-19 15:15:20 --> Form Validation Class Initialized
INFO - 2019-08-19 15:15:20 --> Email Class Initialized
INFO - 2019-08-19 15:15:20 --> Router Class Initialized
INFO - 2019-08-19 15:15:20 --> Output Class Initialized
INFO - 2019-08-19 15:15:20 --> Security Class Initialized
DEBUG - 2019-08-19 15:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:15:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-08-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:15:20 --> Input Class Initialized
INFO - 2019-08-19 15:15:20 --> Language Class Initialized
INFO - 2019-08-19 15:15:20 --> Loader Class Initialized
INFO - 2019-08-19 15:15:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:15:20 --> Pagination Class Initialized
INFO - 2019-08-19 15:15:20 --> Helper loaded: url_helper
INFO - 2019-08-19 15:15:20 --> Helper loaded: html_helper
INFO - 2019-08-19 15:15:20 --> Database Driver Class Initialized
INFO - 2019-08-19 15:15:20 --> Helper loaded: form_helper
INFO - 2019-08-19 15:15:20 --> Database Driver Class Initialized
INFO - 2019-08-19 15:15:20 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:15:20 --> Helper loaded: date_helper
INFO - 2019-08-19 15:15:20 --> Form Validation Class Initialized
INFO - 2019-08-19 15:15:20 --> Email Class Initialized
DEBUG - 2019-08-19 15:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:15:20 --> Controller Class Initialized
INFO - 2019-08-19 15:15:20 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 15:15:20 --> Final output sent to browser
DEBUG - 2019-08-19 15:15:20 --> Total execution time: 0.4860
INFO - 2019-08-19 15:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:15:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:15:20 --> Pagination Class Initialized
INFO - 2019-08-19 15:15:20 --> Database Driver Class Initialized
INFO - 2019-08-19 15:15:20 --> Database Driver Class Initialized
INFO - 2019-08-19 15:15:20 --> Controller Class Initialized
INFO - 2019-08-19 15:15:20 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 15:15:20 --> Final output sent to browser
DEBUG - 2019-08-19 15:15:20 --> Total execution time: 0.6020
INFO - 2019-08-19 15:52:06 --> Config Class Initialized
INFO - 2019-08-19 15:52:06 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:52:06 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:52:06 --> Utf8 Class Initialized
INFO - 2019-08-19 15:52:06 --> URI Class Initialized
INFO - 2019-08-19 15:52:06 --> Router Class Initialized
INFO - 2019-08-19 15:52:06 --> Output Class Initialized
INFO - 2019-08-19 15:52:06 --> Security Class Initialized
DEBUG - 2019-08-19 15:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:52:06 --> Input Class Initialized
INFO - 2019-08-19 15:52:06 --> Language Class Initialized
INFO - 2019-08-19 15:52:06 --> Loader Class Initialized
INFO - 2019-08-19 15:52:06 --> Helper loaded: url_helper
INFO - 2019-08-19 15:52:06 --> Helper loaded: html_helper
INFO - 2019-08-19 15:52:06 --> Helper loaded: form_helper
INFO - 2019-08-19 15:52:06 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:52:06 --> Helper loaded: date_helper
INFO - 2019-08-19 15:52:06 --> Form Validation Class Initialized
INFO - 2019-08-19 15:52:07 --> Email Class Initialized
DEBUG - 2019-08-19 15:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:52:07 --> Pagination Class Initialized
INFO - 2019-08-19 15:52:07 --> Database Driver Class Initialized
INFO - 2019-08-19 15:52:07 --> Database Driver Class Initialized
INFO - 2019-08-19 15:52:07 --> Controller Class Initialized
INFO - 2019-08-19 15:52:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 15:52:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_class.php
INFO - 2019-08-19 15:52:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 15:52:07 --> Final output sent to browser
DEBUG - 2019-08-19 15:52:07 --> Total execution time: 0.3530
INFO - 2019-08-19 15:52:49 --> Config Class Initialized
INFO - 2019-08-19 15:52:49 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:52:49 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:52:49 --> Utf8 Class Initialized
INFO - 2019-08-19 15:52:49 --> Config Class Initialized
INFO - 2019-08-19 15:52:49 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:52:49 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:52:49 --> Utf8 Class Initialized
INFO - 2019-08-19 15:52:49 --> URI Class Initialized
INFO - 2019-08-19 15:52:49 --> URI Class Initialized
INFO - 2019-08-19 15:52:49 --> Router Class Initialized
INFO - 2019-08-19 15:52:49 --> Output Class Initialized
INFO - 2019-08-19 15:52:49 --> Security Class Initialized
DEBUG - 2019-08-19 15:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:52:49 --> Input Class Initialized
INFO - 2019-08-19 15:52:49 --> Language Class Initialized
INFO - 2019-08-19 15:52:49 --> Router Class Initialized
INFO - 2019-08-19 15:52:49 --> Output Class Initialized
INFO - 2019-08-19 15:52:49 --> Security Class Initialized
DEBUG - 2019-08-19 15:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:52:49 --> Input Class Initialized
INFO - 2019-08-19 15:52:49 --> Language Class Initialized
INFO - 2019-08-19 15:52:49 --> Loader Class Initialized
INFO - 2019-08-19 15:52:49 --> Helper loaded: url_helper
INFO - 2019-08-19 15:52:49 --> Helper loaded: html_helper
INFO - 2019-08-19 15:52:49 --> Helper loaded: form_helper
INFO - 2019-08-19 15:52:49 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:52:49 --> Helper loaded: date_helper
INFO - 2019-08-19 15:52:49 --> Form Validation Class Initialized
INFO - 2019-08-19 15:52:49 --> Loader Class Initialized
INFO - 2019-08-19 15:52:49 --> Email Class Initialized
INFO - 2019-08-19 15:52:49 --> Helper loaded: url_helper
INFO - 2019-08-19 15:52:49 --> Helper loaded: html_helper
DEBUG - 2019-08-19 15:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:52:49 --> Helper loaded: form_helper
INFO - 2019-08-19 15:52:49 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:52:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:52:49 --> Pagination Class Initialized
INFO - 2019-08-19 15:52:49 --> Helper loaded: date_helper
INFO - 2019-08-19 15:52:49 --> Form Validation Class Initialized
INFO - 2019-08-19 15:52:49 --> Email Class Initialized
DEBUG - 2019-08-19 15:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:52:49 --> Database Driver Class Initialized
INFO - 2019-08-19 15:52:49 --> Database Driver Class Initialized
INFO - 2019-08-19 15:52:49 --> Controller Class Initialized
INFO - 2019-08-19 15:52:49 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 15:52:49 --> Final output sent to browser
DEBUG - 2019-08-19 15:52:49 --> Total execution time: 0.2610
INFO - 2019-08-19 15:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:52:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:52:49 --> Pagination Class Initialized
INFO - 2019-08-19 15:52:49 --> Database Driver Class Initialized
INFO - 2019-08-19 15:52:49 --> Database Driver Class Initialized
INFO - 2019-08-19 15:52:49 --> Controller Class Initialized
INFO - 2019-08-19 15:52:49 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 15:52:49 --> Final output sent to browser
DEBUG - 2019-08-19 15:52:50 --> Total execution time: 0.3380
INFO - 2019-08-19 15:52:50 --> Config Class Initialized
INFO - 2019-08-19 15:52:50 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:52:50 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:52:50 --> Utf8 Class Initialized
INFO - 2019-08-19 15:52:50 --> URI Class Initialized
INFO - 2019-08-19 15:52:50 --> Router Class Initialized
INFO - 2019-08-19 15:52:50 --> Output Class Initialized
INFO - 2019-08-19 15:52:50 --> Security Class Initialized
DEBUG - 2019-08-19 15:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:52:50 --> Input Class Initialized
INFO - 2019-08-19 15:52:50 --> Language Class Initialized
INFO - 2019-08-19 15:52:50 --> Loader Class Initialized
INFO - 2019-08-19 15:52:50 --> Helper loaded: url_helper
INFO - 2019-08-19 15:52:50 --> Helper loaded: html_helper
INFO - 2019-08-19 15:52:50 --> Helper loaded: form_helper
INFO - 2019-08-19 15:52:50 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:52:50 --> Helper loaded: date_helper
INFO - 2019-08-19 15:52:50 --> Form Validation Class Initialized
INFO - 2019-08-19 15:52:50 --> Email Class Initialized
DEBUG - 2019-08-19 15:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:52:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:52:50 --> Pagination Class Initialized
INFO - 2019-08-19 15:52:50 --> Database Driver Class Initialized
INFO - 2019-08-19 15:52:50 --> Database Driver Class Initialized
INFO - 2019-08-19 15:52:50 --> Controller Class Initialized
INFO - 2019-08-19 15:52:50 --> Final output sent to browser
DEBUG - 2019-08-19 15:52:50 --> Total execution time: 0.2810
INFO - 2019-08-19 15:52:59 --> Config Class Initialized
INFO - 2019-08-19 15:52:59 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:52:59 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:52:59 --> Utf8 Class Initialized
INFO - 2019-08-19 15:52:59 --> URI Class Initialized
INFO - 2019-08-19 15:52:59 --> Router Class Initialized
INFO - 2019-08-19 15:52:59 --> Output Class Initialized
INFO - 2019-08-19 15:52:59 --> Security Class Initialized
DEBUG - 2019-08-19 15:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:52:59 --> Input Class Initialized
INFO - 2019-08-19 15:52:59 --> Language Class Initialized
INFO - 2019-08-19 15:52:59 --> Loader Class Initialized
INFO - 2019-08-19 15:52:59 --> Helper loaded: url_helper
INFO - 2019-08-19 15:52:59 --> Helper loaded: html_helper
INFO - 2019-08-19 15:52:59 --> Helper loaded: form_helper
INFO - 2019-08-19 15:52:59 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:52:59 --> Helper loaded: date_helper
INFO - 2019-08-19 15:52:59 --> Form Validation Class Initialized
INFO - 2019-08-19 15:52:59 --> Email Class Initialized
DEBUG - 2019-08-19 15:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:52:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:52:59 --> Pagination Class Initialized
INFO - 2019-08-19 15:52:59 --> Database Driver Class Initialized
INFO - 2019-08-19 15:52:59 --> Database Driver Class Initialized
INFO - 2019-08-19 15:52:59 --> Controller Class Initialized
INFO - 2019-08-19 15:52:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 15:52:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomtype.php
INFO - 2019-08-19 15:52:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 15:52:59 --> Final output sent to browser
DEBUG - 2019-08-19 15:52:59 --> Total execution time: 0.2470
INFO - 2019-08-19 15:53:31 --> Config Class Initialized
INFO - 2019-08-19 15:53:31 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:53:31 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:53:31 --> Utf8 Class Initialized
INFO - 2019-08-19 15:53:31 --> URI Class Initialized
INFO - 2019-08-19 15:53:32 --> Router Class Initialized
INFO - 2019-08-19 15:53:32 --> Output Class Initialized
INFO - 2019-08-19 15:53:32 --> Security Class Initialized
DEBUG - 2019-08-19 15:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:53:32 --> Input Class Initialized
INFO - 2019-08-19 15:53:32 --> Language Class Initialized
INFO - 2019-08-19 15:53:32 --> Config Class Initialized
INFO - 2019-08-19 15:53:32 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:53:32 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:53:32 --> Utf8 Class Initialized
INFO - 2019-08-19 15:53:32 --> Loader Class Initialized
INFO - 2019-08-19 15:53:32 --> Helper loaded: url_helper
INFO - 2019-08-19 15:53:32 --> Helper loaded: html_helper
INFO - 2019-08-19 15:53:32 --> Helper loaded: form_helper
INFO - 2019-08-19 15:53:32 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:53:32 --> Helper loaded: date_helper
INFO - 2019-08-19 15:53:32 --> Form Validation Class Initialized
INFO - 2019-08-19 15:53:32 --> Email Class Initialized
INFO - 2019-08-19 15:53:32 --> URI Class Initialized
INFO - 2019-08-19 15:53:32 --> Router Class Initialized
INFO - 2019-08-19 15:53:32 --> Output Class Initialized
INFO - 2019-08-19 15:53:32 --> Security Class Initialized
DEBUG - 2019-08-19 15:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:53:32 --> Input Class Initialized
INFO - 2019-08-19 15:53:32 --> Language Class Initialized
DEBUG - 2019-08-19 15:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:53:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:53:32 --> Pagination Class Initialized
INFO - 2019-08-19 15:53:32 --> Loader Class Initialized
INFO - 2019-08-19 15:53:32 --> Helper loaded: url_helper
INFO - 2019-08-19 15:53:32 --> Helper loaded: html_helper
INFO - 2019-08-19 15:53:32 --> Helper loaded: form_helper
INFO - 2019-08-19 15:53:32 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:53:32 --> Helper loaded: date_helper
INFO - 2019-08-19 15:53:32 --> Form Validation Class Initialized
INFO - 2019-08-19 15:53:32 --> Database Driver Class Initialized
INFO - 2019-08-19 15:53:32 --> Database Driver Class Initialized
INFO - 2019-08-19 15:53:32 --> Email Class Initialized
DEBUG - 2019-08-19 15:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:53:32 --> Controller Class Initialized
INFO - 2019-08-19 15:53:32 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 15:53:32 --> Final output sent to browser
DEBUG - 2019-08-19 15:53:32 --> Total execution time: 0.3280
INFO - 2019-08-19 15:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:53:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:53:32 --> Pagination Class Initialized
INFO - 2019-08-19 15:53:32 --> Database Driver Class Initialized
INFO - 2019-08-19 15:53:32 --> Database Driver Class Initialized
INFO - 2019-08-19 15:53:32 --> Controller Class Initialized
INFO - 2019-08-19 15:53:32 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 15:53:32 --> Final output sent to browser
DEBUG - 2019-08-19 15:53:32 --> Total execution time: 0.3730
INFO - 2019-08-19 15:53:33 --> Config Class Initialized
INFO - 2019-08-19 15:53:33 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:53:33 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:53:33 --> Utf8 Class Initialized
INFO - 2019-08-19 15:53:33 --> URI Class Initialized
INFO - 2019-08-19 15:53:33 --> Router Class Initialized
INFO - 2019-08-19 15:53:33 --> Output Class Initialized
INFO - 2019-08-19 15:53:33 --> Security Class Initialized
DEBUG - 2019-08-19 15:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:53:33 --> Input Class Initialized
INFO - 2019-08-19 15:53:33 --> Language Class Initialized
INFO - 2019-08-19 15:53:33 --> Loader Class Initialized
INFO - 2019-08-19 15:53:33 --> Helper loaded: url_helper
INFO - 2019-08-19 15:53:33 --> Helper loaded: html_helper
INFO - 2019-08-19 15:53:33 --> Helper loaded: form_helper
INFO - 2019-08-19 15:53:33 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:53:33 --> Helper loaded: date_helper
INFO - 2019-08-19 15:53:33 --> Form Validation Class Initialized
INFO - 2019-08-19 15:53:33 --> Email Class Initialized
DEBUG - 2019-08-19 15:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:53:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:53:33 --> Pagination Class Initialized
INFO - 2019-08-19 15:53:33 --> Database Driver Class Initialized
INFO - 2019-08-19 15:53:33 --> Database Driver Class Initialized
INFO - 2019-08-19 15:53:33 --> Controller Class Initialized
INFO - 2019-08-19 15:53:33 --> Final output sent to browser
DEBUG - 2019-08-19 15:53:33 --> Total execution time: 0.3530
INFO - 2019-08-19 15:54:01 --> Config Class Initialized
INFO - 2019-08-19 15:54:01 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:54:01 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:54:01 --> Utf8 Class Initialized
INFO - 2019-08-19 15:54:01 --> URI Class Initialized
INFO - 2019-08-19 15:54:01 --> Router Class Initialized
INFO - 2019-08-19 15:54:01 --> Output Class Initialized
INFO - 2019-08-19 15:54:01 --> Security Class Initialized
DEBUG - 2019-08-19 15:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:54:01 --> Input Class Initialized
INFO - 2019-08-19 15:54:01 --> Language Class Initialized
INFO - 2019-08-19 15:54:01 --> Loader Class Initialized
INFO - 2019-08-19 15:54:01 --> Helper loaded: url_helper
INFO - 2019-08-19 15:54:01 --> Helper loaded: html_helper
INFO - 2019-08-19 15:54:01 --> Helper loaded: form_helper
INFO - 2019-08-19 15:54:01 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:54:01 --> Helper loaded: date_helper
INFO - 2019-08-19 15:54:01 --> Form Validation Class Initialized
INFO - 2019-08-19 15:54:01 --> Email Class Initialized
DEBUG - 2019-08-19 15:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:54:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:54:01 --> Pagination Class Initialized
INFO - 2019-08-19 15:54:01 --> Database Driver Class Initialized
INFO - 2019-08-19 15:54:01 --> Database Driver Class Initialized
INFO - 2019-08-19 15:54:01 --> Controller Class Initialized
INFO - 2019-08-19 15:54:01 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 15:54:01 --> Final output sent to browser
DEBUG - 2019-08-19 15:54:01 --> Total execution time: 0.3300
INFO - 2019-08-19 15:54:04 --> Config Class Initialized
INFO - 2019-08-19 15:54:04 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:54:04 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:54:04 --> Utf8 Class Initialized
INFO - 2019-08-19 15:54:04 --> URI Class Initialized
INFO - 2019-08-19 15:54:04 --> Router Class Initialized
INFO - 2019-08-19 15:54:04 --> Output Class Initialized
INFO - 2019-08-19 15:54:04 --> Security Class Initialized
DEBUG - 2019-08-19 15:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:54:04 --> Input Class Initialized
INFO - 2019-08-19 15:54:04 --> Language Class Initialized
INFO - 2019-08-19 15:54:04 --> Loader Class Initialized
INFO - 2019-08-19 15:54:04 --> Helper loaded: url_helper
INFO - 2019-08-19 15:54:04 --> Helper loaded: html_helper
INFO - 2019-08-19 15:54:04 --> Helper loaded: form_helper
INFO - 2019-08-19 15:54:04 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:54:05 --> Helper loaded: date_helper
INFO - 2019-08-19 15:54:05 --> Form Validation Class Initialized
INFO - 2019-08-19 15:54:05 --> Email Class Initialized
DEBUG - 2019-08-19 15:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:54:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:54:05 --> Pagination Class Initialized
INFO - 2019-08-19 15:54:05 --> Database Driver Class Initialized
INFO - 2019-08-19 15:54:05 --> Database Driver Class Initialized
INFO - 2019-08-19 15:54:05 --> Controller Class Initialized
INFO - 2019-08-19 15:54:05 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 15:54:05 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/site.php
INFO - 2019-08-19 15:54:05 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 15:54:05 --> Final output sent to browser
DEBUG - 2019-08-19 15:54:05 --> Total execution time: 0.2130
INFO - 2019-08-19 15:54:47 --> Config Class Initialized
INFO - 2019-08-19 15:54:47 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:54:47 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:54:47 --> Utf8 Class Initialized
INFO - 2019-08-19 15:54:47 --> Config Class Initialized
INFO - 2019-08-19 15:54:47 --> Hooks Class Initialized
INFO - 2019-08-19 15:54:47 --> URI Class Initialized
INFO - 2019-08-19 15:54:47 --> Router Class Initialized
INFO - 2019-08-19 15:54:47 --> Output Class Initialized
INFO - 2019-08-19 15:54:47 --> Security Class Initialized
DEBUG - 2019-08-19 15:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:54:47 --> Input Class Initialized
DEBUG - 2019-08-19 15:54:47 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:54:47 --> Utf8 Class Initialized
INFO - 2019-08-19 15:54:47 --> URI Class Initialized
INFO - 2019-08-19 15:54:47 --> Router Class Initialized
INFO - 2019-08-19 15:54:47 --> Output Class Initialized
INFO - 2019-08-19 15:54:47 --> Security Class Initialized
DEBUG - 2019-08-19 15:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:54:47 --> Input Class Initialized
INFO - 2019-08-19 15:54:47 --> Language Class Initialized
INFO - 2019-08-19 15:54:47 --> Language Class Initialized
INFO - 2019-08-19 15:54:47 --> Loader Class Initialized
INFO - 2019-08-19 15:54:47 --> Helper loaded: url_helper
INFO - 2019-08-19 15:54:47 --> Helper loaded: html_helper
INFO - 2019-08-19 15:54:47 --> Helper loaded: form_helper
INFO - 2019-08-19 15:54:47 --> Loader Class Initialized
INFO - 2019-08-19 15:54:47 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:54:47 --> Helper loaded: url_helper
INFO - 2019-08-19 15:54:47 --> Helper loaded: html_helper
INFO - 2019-08-19 15:54:47 --> Helper loaded: date_helper
INFO - 2019-08-19 15:54:47 --> Helper loaded: form_helper
INFO - 2019-08-19 15:54:47 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:54:47 --> Helper loaded: date_helper
INFO - 2019-08-19 15:54:47 --> Form Validation Class Initialized
INFO - 2019-08-19 15:54:47 --> Form Validation Class Initialized
INFO - 2019-08-19 15:54:47 --> Email Class Initialized
INFO - 2019-08-19 15:54:47 --> Email Class Initialized
DEBUG - 2019-08-19 15:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:54:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-08-19 15:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:54:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:54:47 --> Pagination Class Initialized
INFO - 2019-08-19 15:54:47 --> Database Driver Class Initialized
INFO - 2019-08-19 15:54:47 --> Database Driver Class Initialized
INFO - 2019-08-19 15:54:47 --> Controller Class Initialized
INFO - 2019-08-19 15:54:47 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 15:54:47 --> Final output sent to browser
DEBUG - 2019-08-19 15:54:47 --> Total execution time: 0.3860
INFO - 2019-08-19 15:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:54:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:54:47 --> Pagination Class Initialized
INFO - 2019-08-19 15:54:47 --> Database Driver Class Initialized
INFO - 2019-08-19 15:54:47 --> Database Driver Class Initialized
INFO - 2019-08-19 15:54:47 --> Controller Class Initialized
INFO - 2019-08-19 15:54:47 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 15:54:47 --> Final output sent to browser
DEBUG - 2019-08-19 15:54:47 --> Total execution time: 0.4490
INFO - 2019-08-19 15:59:18 --> Config Class Initialized
INFO - 2019-08-19 15:59:18 --> Hooks Class Initialized
DEBUG - 2019-08-19 15:59:18 --> UTF-8 Support Enabled
INFO - 2019-08-19 15:59:18 --> Utf8 Class Initialized
INFO - 2019-08-19 15:59:18 --> URI Class Initialized
INFO - 2019-08-19 15:59:18 --> Router Class Initialized
INFO - 2019-08-19 15:59:18 --> Output Class Initialized
INFO - 2019-08-19 15:59:18 --> Security Class Initialized
DEBUG - 2019-08-19 15:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 15:59:18 --> Input Class Initialized
INFO - 2019-08-19 15:59:18 --> Language Class Initialized
INFO - 2019-08-19 15:59:18 --> Loader Class Initialized
INFO - 2019-08-19 15:59:18 --> Helper loaded: url_helper
INFO - 2019-08-19 15:59:18 --> Helper loaded: html_helper
INFO - 2019-08-19 15:59:18 --> Helper loaded: form_helper
INFO - 2019-08-19 15:59:18 --> Helper loaded: cookie_helper
INFO - 2019-08-19 15:59:18 --> Helper loaded: date_helper
INFO - 2019-08-19 15:59:18 --> Form Validation Class Initialized
INFO - 2019-08-19 15:59:18 --> Email Class Initialized
DEBUG - 2019-08-19 15:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 15:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 15:59:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 15:59:18 --> Pagination Class Initialized
INFO - 2019-08-19 15:59:18 --> Database Driver Class Initialized
INFO - 2019-08-19 15:59:18 --> Database Driver Class Initialized
INFO - 2019-08-19 15:59:18 --> Controller Class Initialized
INFO - 2019-08-19 15:59:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 15:59:18 --> Final output sent to browser
DEBUG - 2019-08-19 15:59:18 --> Total execution time: 0.2780
INFO - 2019-08-19 16:02:07 --> Config Class Initialized
INFO - 2019-08-19 16:02:07 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:02:07 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:02:07 --> Utf8 Class Initialized
INFO - 2019-08-19 16:02:07 --> URI Class Initialized
INFO - 2019-08-19 16:02:07 --> Router Class Initialized
INFO - 2019-08-19 16:02:07 --> Output Class Initialized
INFO - 2019-08-19 16:02:07 --> Security Class Initialized
DEBUG - 2019-08-19 16:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:02:07 --> Input Class Initialized
INFO - 2019-08-19 16:02:07 --> Language Class Initialized
INFO - 2019-08-19 16:02:07 --> Loader Class Initialized
INFO - 2019-08-19 16:02:07 --> Helper loaded: url_helper
INFO - 2019-08-19 16:02:07 --> Helper loaded: html_helper
INFO - 2019-08-19 16:02:07 --> Helper loaded: form_helper
INFO - 2019-08-19 16:02:07 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:02:07 --> Helper loaded: date_helper
INFO - 2019-08-19 16:02:07 --> Form Validation Class Initialized
INFO - 2019-08-19 16:02:07 --> Email Class Initialized
DEBUG - 2019-08-19 16:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:02:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:02:07 --> Pagination Class Initialized
INFO - 2019-08-19 16:02:07 --> Database Driver Class Initialized
INFO - 2019-08-19 16:02:07 --> Database Driver Class Initialized
INFO - 2019-08-19 16:02:07 --> Controller Class Initialized
INFO - 2019-08-19 16:02:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 16:02:07 --> Config Class Initialized
INFO - 2019-08-19 16:02:07 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:02:07 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:02:07 --> Utf8 Class Initialized
INFO - 2019-08-19 16:02:07 --> URI Class Initialized
INFO - 2019-08-19 16:02:07 --> Router Class Initialized
INFO - 2019-08-19 16:02:07 --> Output Class Initialized
INFO - 2019-08-19 16:02:07 --> Security Class Initialized
DEBUG - 2019-08-19 16:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:02:07 --> Input Class Initialized
INFO - 2019-08-19 16:02:07 --> Language Class Initialized
INFO - 2019-08-19 16:02:07 --> Loader Class Initialized
INFO - 2019-08-19 16:02:07 --> Helper loaded: url_helper
INFO - 2019-08-19 16:02:07 --> Helper loaded: html_helper
INFO - 2019-08-19 16:02:07 --> Helper loaded: form_helper
INFO - 2019-08-19 16:02:07 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:02:07 --> Helper loaded: date_helper
INFO - 2019-08-19 16:02:07 --> Form Validation Class Initialized
INFO - 2019-08-19 16:02:07 --> Email Class Initialized
DEBUG - 2019-08-19 16:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:02:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:02:07 --> Pagination Class Initialized
INFO - 2019-08-19 16:02:07 --> Database Driver Class Initialized
INFO - 2019-08-19 16:02:07 --> Database Driver Class Initialized
INFO - 2019-08-19 16:02:07 --> Controller Class Initialized
INFO - 2019-08-19 16:02:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:02:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/site.php
INFO - 2019-08-19 16:02:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:02:07 --> Final output sent to browser
DEBUG - 2019-08-19 16:02:07 --> Total execution time: 0.2040
INFO - 2019-08-19 16:02:46 --> Config Class Initialized
INFO - 2019-08-19 16:02:46 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:02:46 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:02:46 --> Utf8 Class Initialized
INFO - 2019-08-19 16:02:46 --> URI Class Initialized
INFO - 2019-08-19 16:02:46 --> Router Class Initialized
INFO - 2019-08-19 16:02:46 --> Output Class Initialized
INFO - 2019-08-19 16:02:46 --> Security Class Initialized
DEBUG - 2019-08-19 16:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:02:46 --> Input Class Initialized
INFO - 2019-08-19 16:02:46 --> Language Class Initialized
INFO - 2019-08-19 16:02:46 --> Loader Class Initialized
INFO - 2019-08-19 16:02:46 --> Helper loaded: url_helper
INFO - 2019-08-19 16:02:46 --> Helper loaded: html_helper
INFO - 2019-08-19 16:02:46 --> Helper loaded: form_helper
INFO - 2019-08-19 16:02:46 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:02:46 --> Helper loaded: date_helper
INFO - 2019-08-19 16:02:46 --> Config Class Initialized
INFO - 2019-08-19 16:02:46 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:02:46 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:02:46 --> Utf8 Class Initialized
INFO - 2019-08-19 16:02:46 --> URI Class Initialized
INFO - 2019-08-19 16:02:46 --> Form Validation Class Initialized
INFO - 2019-08-19 16:02:46 --> Router Class Initialized
INFO - 2019-08-19 16:02:46 --> Email Class Initialized
DEBUG - 2019-08-19 16:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:02:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:02:46 --> Pagination Class Initialized
INFO - 2019-08-19 16:02:46 --> Output Class Initialized
INFO - 2019-08-19 16:02:46 --> Security Class Initialized
DEBUG - 2019-08-19 16:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:02:46 --> Input Class Initialized
INFO - 2019-08-19 16:02:46 --> Language Class Initialized
INFO - 2019-08-19 16:02:46 --> Database Driver Class Initialized
INFO - 2019-08-19 16:02:46 --> Database Driver Class Initialized
INFO - 2019-08-19 16:02:46 --> Loader Class Initialized
INFO - 2019-08-19 16:02:46 --> Helper loaded: url_helper
INFO - 2019-08-19 16:02:46 --> Helper loaded: html_helper
INFO - 2019-08-19 16:02:46 --> Helper loaded: form_helper
INFO - 2019-08-19 16:02:46 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:02:46 --> Helper loaded: date_helper
INFO - 2019-08-19 16:02:46 --> Form Validation Class Initialized
INFO - 2019-08-19 16:02:46 --> Email Class Initialized
DEBUG - 2019-08-19 16:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:02:46 --> Controller Class Initialized
INFO - 2019-08-19 16:02:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:02:46 --> Final output sent to browser
DEBUG - 2019-08-19 16:02:46 --> Total execution time: 0.2800
INFO - 2019-08-19 16:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:02:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:02:46 --> Pagination Class Initialized
INFO - 2019-08-19 16:02:46 --> Database Driver Class Initialized
INFO - 2019-08-19 16:02:46 --> Database Driver Class Initialized
INFO - 2019-08-19 16:02:46 --> Controller Class Initialized
INFO - 2019-08-19 16:02:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:02:46 --> Final output sent to browser
DEBUG - 2019-08-19 16:02:46 --> Total execution time: 0.2710
INFO - 2019-08-19 16:22:56 --> Config Class Initialized
INFO - 2019-08-19 16:22:56 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:22:56 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:22:56 --> Utf8 Class Initialized
INFO - 2019-08-19 16:22:56 --> URI Class Initialized
INFO - 2019-08-19 16:22:56 --> Router Class Initialized
INFO - 2019-08-19 16:22:56 --> Output Class Initialized
INFO - 2019-08-19 16:22:56 --> Security Class Initialized
DEBUG - 2019-08-19 16:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:22:56 --> Input Class Initialized
INFO - 2019-08-19 16:22:56 --> Language Class Initialized
INFO - 2019-08-19 16:22:56 --> Loader Class Initialized
INFO - 2019-08-19 16:22:56 --> Helper loaded: url_helper
INFO - 2019-08-19 16:22:56 --> Helper loaded: html_helper
INFO - 2019-08-19 16:22:56 --> Helper loaded: form_helper
INFO - 2019-08-19 16:22:56 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:22:56 --> Helper loaded: date_helper
INFO - 2019-08-19 16:22:56 --> Form Validation Class Initialized
INFO - 2019-08-19 16:22:56 --> Email Class Initialized
DEBUG - 2019-08-19 16:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:22:56 --> Pagination Class Initialized
INFO - 2019-08-19 16:22:56 --> Database Driver Class Initialized
INFO - 2019-08-19 16:22:56 --> Database Driver Class Initialized
INFO - 2019-08-19 16:22:56 --> Controller Class Initialized
INFO - 2019-08-19 16:22:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 16:22:59 --> Config Class Initialized
INFO - 2019-08-19 16:22:59 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:22:59 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:22:59 --> Utf8 Class Initialized
INFO - 2019-08-19 16:22:59 --> URI Class Initialized
INFO - 2019-08-19 16:22:59 --> Router Class Initialized
INFO - 2019-08-19 16:22:59 --> Output Class Initialized
INFO - 2019-08-19 16:22:59 --> Security Class Initialized
DEBUG - 2019-08-19 16:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:22:59 --> Input Class Initialized
INFO - 2019-08-19 16:22:59 --> Language Class Initialized
INFO - 2019-08-19 16:22:59 --> Loader Class Initialized
INFO - 2019-08-19 16:22:59 --> Helper loaded: url_helper
INFO - 2019-08-19 16:22:59 --> Helper loaded: html_helper
INFO - 2019-08-19 16:22:59 --> Helper loaded: form_helper
INFO - 2019-08-19 16:22:59 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:22:59 --> Helper loaded: date_helper
INFO - 2019-08-19 16:22:59 --> Form Validation Class Initialized
INFO - 2019-08-19 16:22:59 --> Email Class Initialized
DEBUG - 2019-08-19 16:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:22:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:22:59 --> Pagination Class Initialized
INFO - 2019-08-19 16:22:59 --> Database Driver Class Initialized
INFO - 2019-08-19 16:22:59 --> Database Driver Class Initialized
INFO - 2019-08-19 16:22:59 --> Controller Class Initialized
INFO - 2019-08-19 16:22:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:22:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/site.php
INFO - 2019-08-19 16:22:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:22:59 --> Final output sent to browser
DEBUG - 2019-08-19 16:22:59 --> Total execution time: 0.2040
INFO - 2019-08-19 16:23:39 --> Config Class Initialized
INFO - 2019-08-19 16:23:39 --> Hooks Class Initialized
INFO - 2019-08-19 16:23:39 --> Config Class Initialized
INFO - 2019-08-19 16:23:39 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:23:39 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:23:39 --> Utf8 Class Initialized
INFO - 2019-08-19 16:23:39 --> URI Class Initialized
DEBUG - 2019-08-19 16:23:39 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:23:39 --> Utf8 Class Initialized
INFO - 2019-08-19 16:23:39 --> URI Class Initialized
INFO - 2019-08-19 16:23:39 --> Router Class Initialized
INFO - 2019-08-19 16:23:39 --> Output Class Initialized
INFO - 2019-08-19 16:23:39 --> Router Class Initialized
INFO - 2019-08-19 16:23:39 --> Security Class Initialized
INFO - 2019-08-19 16:23:39 --> Output Class Initialized
DEBUG - 2019-08-19 16:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:23:39 --> Input Class Initialized
INFO - 2019-08-19 16:23:39 --> Language Class Initialized
INFO - 2019-08-19 16:23:39 --> Security Class Initialized
DEBUG - 2019-08-19 16:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:23:39 --> Input Class Initialized
INFO - 2019-08-19 16:23:39 --> Language Class Initialized
INFO - 2019-08-19 16:23:39 --> Loader Class Initialized
INFO - 2019-08-19 16:23:39 --> Helper loaded: url_helper
INFO - 2019-08-19 16:23:39 --> Loader Class Initialized
INFO - 2019-08-19 16:23:39 --> Helper loaded: url_helper
INFO - 2019-08-19 16:23:39 --> Helper loaded: html_helper
INFO - 2019-08-19 16:23:39 --> Helper loaded: html_helper
INFO - 2019-08-19 16:23:39 --> Helper loaded: form_helper
INFO - 2019-08-19 16:23:39 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:23:39 --> Helper loaded: form_helper
INFO - 2019-08-19 16:23:39 --> Helper loaded: date_helper
INFO - 2019-08-19 16:23:39 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:23:39 --> Helper loaded: date_helper
INFO - 2019-08-19 16:23:39 --> Form Validation Class Initialized
INFO - 2019-08-19 16:23:39 --> Form Validation Class Initialized
INFO - 2019-08-19 16:23:39 --> Email Class Initialized
DEBUG - 2019-08-19 16:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:23:39 --> Email Class Initialized
INFO - 2019-08-19 16:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:23:39 --> Pagination Class Initialized
DEBUG - 2019-08-19 16:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:23:39 --> Database Driver Class Initialized
INFO - 2019-08-19 16:23:39 --> Database Driver Class Initialized
INFO - 2019-08-19 16:23:39 --> Controller Class Initialized
INFO - 2019-08-19 16:23:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:23:39 --> Final output sent to browser
DEBUG - 2019-08-19 16:23:39 --> Total execution time: 0.1880
INFO - 2019-08-19 16:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:23:39 --> Pagination Class Initialized
INFO - 2019-08-19 16:23:39 --> Database Driver Class Initialized
INFO - 2019-08-19 16:23:39 --> Database Driver Class Initialized
INFO - 2019-08-19 16:23:39 --> Controller Class Initialized
INFO - 2019-08-19 16:23:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:23:39 --> Final output sent to browser
DEBUG - 2019-08-19 16:23:39 --> Total execution time: 0.2730
INFO - 2019-08-19 16:41:27 --> Config Class Initialized
INFO - 2019-08-19 16:41:27 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:41:27 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:41:27 --> Utf8 Class Initialized
INFO - 2019-08-19 16:41:27 --> URI Class Initialized
INFO - 2019-08-19 16:41:27 --> Router Class Initialized
INFO - 2019-08-19 16:41:27 --> Output Class Initialized
INFO - 2019-08-19 16:41:27 --> Security Class Initialized
DEBUG - 2019-08-19 16:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:41:27 --> Input Class Initialized
INFO - 2019-08-19 16:41:27 --> Language Class Initialized
INFO - 2019-08-19 16:41:27 --> Config Class Initialized
INFO - 2019-08-19 16:41:27 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:41:27 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:41:27 --> Utf8 Class Initialized
INFO - 2019-08-19 16:41:27 --> URI Class Initialized
INFO - 2019-08-19 16:41:27 --> Router Class Initialized
INFO - 2019-08-19 16:41:27 --> Output Class Initialized
INFO - 2019-08-19 16:41:27 --> Security Class Initialized
DEBUG - 2019-08-19 16:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:41:27 --> Input Class Initialized
INFO - 2019-08-19 16:41:27 --> Loader Class Initialized
INFO - 2019-08-19 16:41:27 --> Language Class Initialized
INFO - 2019-08-19 16:41:27 --> Helper loaded: url_helper
INFO - 2019-08-19 16:41:27 --> Helper loaded: html_helper
INFO - 2019-08-19 16:41:27 --> Helper loaded: form_helper
INFO - 2019-08-19 16:41:27 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:41:27 --> Helper loaded: date_helper
INFO - 2019-08-19 16:41:27 --> Form Validation Class Initialized
INFO - 2019-08-19 16:41:27 --> Loader Class Initialized
INFO - 2019-08-19 16:41:27 --> Helper loaded: url_helper
INFO - 2019-08-19 16:41:27 --> Email Class Initialized
INFO - 2019-08-19 16:41:27 --> Helper loaded: html_helper
INFO - 2019-08-19 16:41:27 --> Helper loaded: form_helper
INFO - 2019-08-19 16:41:27 --> Helper loaded: cookie_helper
DEBUG - 2019-08-19 16:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:41:27 --> Helper loaded: date_helper
INFO - 2019-08-19 16:41:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:41:27 --> Pagination Class Initialized
INFO - 2019-08-19 16:41:27 --> Form Validation Class Initialized
INFO - 2019-08-19 16:41:27 --> Email Class Initialized
DEBUG - 2019-08-19 16:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:41:27 --> Database Driver Class Initialized
INFO - 2019-08-19 16:41:27 --> Database Driver Class Initialized
INFO - 2019-08-19 16:41:27 --> Controller Class Initialized
INFO - 2019-08-19 16:41:27 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:41:27 --> Final output sent to browser
DEBUG - 2019-08-19 16:41:27 --> Total execution time: 0.3500
INFO - 2019-08-19 16:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:41:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:41:27 --> Pagination Class Initialized
INFO - 2019-08-19 16:41:27 --> Database Driver Class Initialized
INFO - 2019-08-19 16:41:27 --> Database Driver Class Initialized
INFO - 2019-08-19 16:41:27 --> Controller Class Initialized
INFO - 2019-08-19 16:41:27 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:41:27 --> Final output sent to browser
DEBUG - 2019-08-19 16:41:27 --> Total execution time: 0.3870
INFO - 2019-08-19 16:42:02 --> Config Class Initialized
INFO - 2019-08-19 16:42:02 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:42:02 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:42:02 --> Utf8 Class Initialized
INFO - 2019-08-19 16:42:02 --> URI Class Initialized
INFO - 2019-08-19 16:42:02 --> Router Class Initialized
INFO - 2019-08-19 16:42:02 --> Output Class Initialized
INFO - 2019-08-19 16:42:02 --> Security Class Initialized
DEBUG - 2019-08-19 16:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:42:02 --> Input Class Initialized
INFO - 2019-08-19 16:42:02 --> Language Class Initialized
INFO - 2019-08-19 16:42:02 --> Loader Class Initialized
INFO - 2019-08-19 16:42:02 --> Helper loaded: url_helper
INFO - 2019-08-19 16:42:02 --> Helper loaded: html_helper
INFO - 2019-08-19 16:42:02 --> Helper loaded: form_helper
INFO - 2019-08-19 16:42:02 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:42:02 --> Helper loaded: date_helper
INFO - 2019-08-19 16:42:02 --> Form Validation Class Initialized
INFO - 2019-08-19 16:42:02 --> Email Class Initialized
DEBUG - 2019-08-19 16:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:42:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:42:02 --> Pagination Class Initialized
INFO - 2019-08-19 16:42:02 --> Database Driver Class Initialized
INFO - 2019-08-19 16:42:02 --> Database Driver Class Initialized
INFO - 2019-08-19 16:42:02 --> Controller Class Initialized
INFO - 2019-08-19 16:42:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:42:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_class.php
INFO - 2019-08-19 16:42:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:42:02 --> Final output sent to browser
DEBUG - 2019-08-19 16:42:02 --> Total execution time: 0.1680
INFO - 2019-08-19 16:42:45 --> Config Class Initialized
INFO - 2019-08-19 16:42:45 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:42:45 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:42:45 --> Utf8 Class Initialized
INFO - 2019-08-19 16:42:45 --> URI Class Initialized
INFO - 2019-08-19 16:42:45 --> Router Class Initialized
INFO - 2019-08-19 16:42:45 --> Output Class Initialized
INFO - 2019-08-19 16:42:45 --> Security Class Initialized
DEBUG - 2019-08-19 16:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:42:45 --> Input Class Initialized
INFO - 2019-08-19 16:42:45 --> Language Class Initialized
INFO - 2019-08-19 16:42:45 --> Loader Class Initialized
INFO - 2019-08-19 16:42:45 --> Helper loaded: url_helper
INFO - 2019-08-19 16:42:45 --> Helper loaded: html_helper
INFO - 2019-08-19 16:42:45 --> Helper loaded: form_helper
INFO - 2019-08-19 16:42:45 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:42:45 --> Helper loaded: date_helper
INFO - 2019-08-19 16:42:45 --> Form Validation Class Initialized
INFO - 2019-08-19 16:42:45 --> Email Class Initialized
DEBUG - 2019-08-19 16:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:42:45 --> Pagination Class Initialized
INFO - 2019-08-19 16:42:45 --> Database Driver Class Initialized
INFO - 2019-08-19 16:42:45 --> Database Driver Class Initialized
INFO - 2019-08-19 16:42:45 --> Config Class Initialized
INFO - 2019-08-19 16:42:45 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:42:45 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:42:45 --> Utf8 Class Initialized
INFO - 2019-08-19 16:42:45 --> URI Class Initialized
INFO - 2019-08-19 16:42:45 --> Router Class Initialized
INFO - 2019-08-19 16:42:45 --> Output Class Initialized
INFO - 2019-08-19 16:42:45 --> Security Class Initialized
DEBUG - 2019-08-19 16:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:42:45 --> Input Class Initialized
INFO - 2019-08-19 16:42:45 --> Language Class Initialized
INFO - 2019-08-19 16:42:45 --> Loader Class Initialized
INFO - 2019-08-19 16:42:45 --> Helper loaded: url_helper
INFO - 2019-08-19 16:42:45 --> Helper loaded: html_helper
INFO - 2019-08-19 16:42:45 --> Helper loaded: form_helper
INFO - 2019-08-19 16:42:45 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:42:45 --> Helper loaded: date_helper
INFO - 2019-08-19 16:42:45 --> Form Validation Class Initialized
INFO - 2019-08-19 16:42:45 --> Email Class Initialized
DEBUG - 2019-08-19 16:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:42:45 --> Controller Class Initialized
INFO - 2019-08-19 16:42:45 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:42:45 --> Final output sent to browser
DEBUG - 2019-08-19 16:42:45 --> Total execution time: 0.3160
INFO - 2019-08-19 16:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:42:45 --> Pagination Class Initialized
INFO - 2019-08-19 16:42:45 --> Database Driver Class Initialized
INFO - 2019-08-19 16:42:45 --> Database Driver Class Initialized
INFO - 2019-08-19 16:42:45 --> Controller Class Initialized
INFO - 2019-08-19 16:42:45 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:42:45 --> Final output sent to browser
DEBUG - 2019-08-19 16:42:45 --> Total execution time: 0.2840
INFO - 2019-08-19 16:42:45 --> Config Class Initialized
INFO - 2019-08-19 16:42:45 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:42:45 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:42:45 --> Utf8 Class Initialized
INFO - 2019-08-19 16:42:45 --> URI Class Initialized
INFO - 2019-08-19 16:42:45 --> Router Class Initialized
INFO - 2019-08-19 16:42:45 --> Output Class Initialized
INFO - 2019-08-19 16:42:45 --> Security Class Initialized
DEBUG - 2019-08-19 16:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:42:45 --> Input Class Initialized
INFO - 2019-08-19 16:42:45 --> Language Class Initialized
INFO - 2019-08-19 16:42:45 --> Loader Class Initialized
INFO - 2019-08-19 16:42:45 --> Helper loaded: url_helper
INFO - 2019-08-19 16:42:45 --> Helper loaded: html_helper
INFO - 2019-08-19 16:42:45 --> Helper loaded: form_helper
INFO - 2019-08-19 16:42:45 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:42:45 --> Helper loaded: date_helper
INFO - 2019-08-19 16:42:45 --> Form Validation Class Initialized
INFO - 2019-08-19 16:42:46 --> Email Class Initialized
DEBUG - 2019-08-19 16:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:42:46 --> Pagination Class Initialized
INFO - 2019-08-19 16:42:46 --> Database Driver Class Initialized
INFO - 2019-08-19 16:42:46 --> Database Driver Class Initialized
INFO - 2019-08-19 16:42:46 --> Controller Class Initialized
INFO - 2019-08-19 16:42:46 --> Final output sent to browser
DEBUG - 2019-08-19 16:42:46 --> Total execution time: 0.2490
INFO - 2019-08-19 16:42:47 --> Config Class Initialized
INFO - 2019-08-19 16:42:47 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:42:47 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:42:47 --> Utf8 Class Initialized
INFO - 2019-08-19 16:42:47 --> URI Class Initialized
INFO - 2019-08-19 16:42:47 --> Router Class Initialized
INFO - 2019-08-19 16:42:47 --> Output Class Initialized
INFO - 2019-08-19 16:42:47 --> Security Class Initialized
DEBUG - 2019-08-19 16:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:42:47 --> Input Class Initialized
INFO - 2019-08-19 16:42:47 --> Language Class Initialized
INFO - 2019-08-19 16:42:47 --> Loader Class Initialized
INFO - 2019-08-19 16:42:47 --> Helper loaded: url_helper
INFO - 2019-08-19 16:42:47 --> Helper loaded: html_helper
INFO - 2019-08-19 16:42:47 --> Helper loaded: form_helper
INFO - 2019-08-19 16:42:47 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:42:47 --> Helper loaded: date_helper
INFO - 2019-08-19 16:42:47 --> Form Validation Class Initialized
INFO - 2019-08-19 16:42:47 --> Email Class Initialized
DEBUG - 2019-08-19 16:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:42:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:42:47 --> Pagination Class Initialized
INFO - 2019-08-19 16:42:47 --> Database Driver Class Initialized
INFO - 2019-08-19 16:42:47 --> Database Driver Class Initialized
INFO - 2019-08-19 16:42:47 --> Controller Class Initialized
INFO - 2019-08-19 16:42:47 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:42:47 --> Final output sent to browser
DEBUG - 2019-08-19 16:42:47 --> Total execution time: 0.2250
INFO - 2019-08-19 16:42:59 --> Config Class Initialized
INFO - 2019-08-19 16:42:59 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:42:59 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:42:59 --> Utf8 Class Initialized
INFO - 2019-08-19 16:42:59 --> URI Class Initialized
INFO - 2019-08-19 16:42:59 --> Router Class Initialized
INFO - 2019-08-19 16:42:59 --> Output Class Initialized
INFO - 2019-08-19 16:42:59 --> Security Class Initialized
DEBUG - 2019-08-19 16:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:42:59 --> Input Class Initialized
INFO - 2019-08-19 16:42:59 --> Language Class Initialized
INFO - 2019-08-19 16:42:59 --> Loader Class Initialized
INFO - 2019-08-19 16:42:59 --> Helper loaded: url_helper
INFO - 2019-08-19 16:42:59 --> Helper loaded: html_helper
INFO - 2019-08-19 16:42:59 --> Helper loaded: form_helper
INFO - 2019-08-19 16:42:59 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:42:59 --> Helper loaded: date_helper
INFO - 2019-08-19 16:42:59 --> Form Validation Class Initialized
INFO - 2019-08-19 16:42:59 --> Email Class Initialized
DEBUG - 2019-08-19 16:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:42:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:42:59 --> Pagination Class Initialized
INFO - 2019-08-19 16:42:59 --> Database Driver Class Initialized
INFO - 2019-08-19 16:42:59 --> Database Driver Class Initialized
INFO - 2019-08-19 16:42:59 --> Controller Class Initialized
INFO - 2019-08-19 16:42:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:42:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomtype.php
INFO - 2019-08-19 16:42:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:42:59 --> Final output sent to browser
DEBUG - 2019-08-19 16:42:59 --> Total execution time: 0.1840
INFO - 2019-08-19 16:43:27 --> Config Class Initialized
INFO - 2019-08-19 16:43:27 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:43:27 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:43:27 --> Utf8 Class Initialized
INFO - 2019-08-19 16:43:27 --> URI Class Initialized
INFO - 2019-08-19 16:43:27 --> Router Class Initialized
INFO - 2019-08-19 16:43:27 --> Output Class Initialized
INFO - 2019-08-19 16:43:27 --> Security Class Initialized
DEBUG - 2019-08-19 16:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:43:27 --> Input Class Initialized
INFO - 2019-08-19 16:43:27 --> Language Class Initialized
INFO - 2019-08-19 16:43:27 --> Loader Class Initialized
INFO - 2019-08-19 16:43:27 --> Helper loaded: url_helper
INFO - 2019-08-19 16:43:27 --> Helper loaded: html_helper
INFO - 2019-08-19 16:43:27 --> Helper loaded: form_helper
INFO - 2019-08-19 16:43:27 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:43:27 --> Helper loaded: date_helper
INFO - 2019-08-19 16:43:27 --> Form Validation Class Initialized
INFO - 2019-08-19 16:43:27 --> Email Class Initialized
DEBUG - 2019-08-19 16:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:43:27 --> Pagination Class Initialized
INFO - 2019-08-19 16:43:27 --> Database Driver Class Initialized
INFO - 2019-08-19 16:43:27 --> Database Driver Class Initialized
INFO - 2019-08-19 16:43:27 --> Config Class Initialized
INFO - 2019-08-19 16:43:27 --> Hooks Class Initialized
INFO - 2019-08-19 16:43:27 --> Controller Class Initialized
DEBUG - 2019-08-19 16:43:27 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:43:27 --> Utf8 Class Initialized
INFO - 2019-08-19 16:43:27 --> URI Class Initialized
INFO - 2019-08-19 16:43:27 --> Router Class Initialized
INFO - 2019-08-19 16:43:27 --> Output Class Initialized
INFO - 2019-08-19 16:43:27 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:43:27 --> Final output sent to browser
INFO - 2019-08-19 16:43:27 --> Security Class Initialized
DEBUG - 2019-08-19 16:43:27 --> Total execution time: 0.2010
DEBUG - 2019-08-19 16:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:43:27 --> Input Class Initialized
INFO - 2019-08-19 16:43:27 --> Language Class Initialized
INFO - 2019-08-19 16:43:27 --> Loader Class Initialized
INFO - 2019-08-19 16:43:27 --> Helper loaded: url_helper
INFO - 2019-08-19 16:43:27 --> Helper loaded: html_helper
INFO - 2019-08-19 16:43:27 --> Helper loaded: form_helper
INFO - 2019-08-19 16:43:27 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:43:27 --> Helper loaded: date_helper
INFO - 2019-08-19 16:43:27 --> Form Validation Class Initialized
INFO - 2019-08-19 16:43:27 --> Email Class Initialized
DEBUG - 2019-08-19 16:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:43:27 --> Pagination Class Initialized
INFO - 2019-08-19 16:43:27 --> Database Driver Class Initialized
INFO - 2019-08-19 16:43:27 --> Database Driver Class Initialized
INFO - 2019-08-19 16:43:27 --> Controller Class Initialized
INFO - 2019-08-19 16:43:27 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:43:27 --> Final output sent to browser
DEBUG - 2019-08-19 16:43:27 --> Total execution time: 0.2290
INFO - 2019-08-19 16:43:28 --> Config Class Initialized
INFO - 2019-08-19 16:43:28 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:43:28 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:43:28 --> Utf8 Class Initialized
INFO - 2019-08-19 16:43:28 --> URI Class Initialized
INFO - 2019-08-19 16:43:28 --> Router Class Initialized
INFO - 2019-08-19 16:43:28 --> Output Class Initialized
INFO - 2019-08-19 16:43:28 --> Security Class Initialized
DEBUG - 2019-08-19 16:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:43:28 --> Input Class Initialized
INFO - 2019-08-19 16:43:28 --> Language Class Initialized
INFO - 2019-08-19 16:43:28 --> Loader Class Initialized
INFO - 2019-08-19 16:43:28 --> Helper loaded: url_helper
INFO - 2019-08-19 16:43:28 --> Helper loaded: html_helper
INFO - 2019-08-19 16:43:28 --> Helper loaded: form_helper
INFO - 2019-08-19 16:43:28 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:43:28 --> Helper loaded: date_helper
INFO - 2019-08-19 16:43:28 --> Form Validation Class Initialized
INFO - 2019-08-19 16:43:28 --> Email Class Initialized
DEBUG - 2019-08-19 16:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:43:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:43:28 --> Pagination Class Initialized
INFO - 2019-08-19 16:43:28 --> Database Driver Class Initialized
INFO - 2019-08-19 16:43:28 --> Database Driver Class Initialized
INFO - 2019-08-19 16:43:28 --> Controller Class Initialized
INFO - 2019-08-19 16:43:28 --> Final output sent to browser
DEBUG - 2019-08-19 16:43:28 --> Total execution time: 0.2770
INFO - 2019-08-19 16:43:47 --> Config Class Initialized
INFO - 2019-08-19 16:43:47 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:43:47 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:43:47 --> Utf8 Class Initialized
INFO - 2019-08-19 16:43:47 --> URI Class Initialized
INFO - 2019-08-19 16:43:47 --> Router Class Initialized
INFO - 2019-08-19 16:43:47 --> Output Class Initialized
INFO - 2019-08-19 16:43:47 --> Security Class Initialized
DEBUG - 2019-08-19 16:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:43:47 --> Input Class Initialized
INFO - 2019-08-19 16:43:47 --> Language Class Initialized
INFO - 2019-08-19 16:43:47 --> Loader Class Initialized
INFO - 2019-08-19 16:43:47 --> Helper loaded: url_helper
INFO - 2019-08-19 16:43:47 --> Helper loaded: html_helper
INFO - 2019-08-19 16:43:47 --> Helper loaded: form_helper
INFO - 2019-08-19 16:43:47 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:43:47 --> Helper loaded: date_helper
INFO - 2019-08-19 16:43:47 --> Form Validation Class Initialized
INFO - 2019-08-19 16:43:47 --> Email Class Initialized
DEBUG - 2019-08-19 16:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:43:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:43:47 --> Pagination Class Initialized
INFO - 2019-08-19 16:43:48 --> Database Driver Class Initialized
INFO - 2019-08-19 16:43:48 --> Database Driver Class Initialized
INFO - 2019-08-19 16:43:48 --> Controller Class Initialized
INFO - 2019-08-19 16:43:48 --> Final output sent to browser
DEBUG - 2019-08-19 16:43:48 --> Total execution time: 0.2140
INFO - 2019-08-19 16:44:36 --> Config Class Initialized
INFO - 2019-08-19 16:44:36 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:44:36 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:44:36 --> Utf8 Class Initialized
INFO - 2019-08-19 16:44:36 --> URI Class Initialized
INFO - 2019-08-19 16:44:36 --> Router Class Initialized
INFO - 2019-08-19 16:44:36 --> Output Class Initialized
INFO - 2019-08-19 16:44:36 --> Security Class Initialized
DEBUG - 2019-08-19 16:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:44:36 --> Input Class Initialized
INFO - 2019-08-19 16:44:36 --> Language Class Initialized
INFO - 2019-08-19 16:44:36 --> Loader Class Initialized
INFO - 2019-08-19 16:44:36 --> Helper loaded: url_helper
INFO - 2019-08-19 16:44:36 --> Helper loaded: html_helper
INFO - 2019-08-19 16:44:36 --> Helper loaded: form_helper
INFO - 2019-08-19 16:44:36 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:44:36 --> Helper loaded: date_helper
INFO - 2019-08-19 16:44:36 --> Form Validation Class Initialized
INFO - 2019-08-19 16:44:36 --> Email Class Initialized
DEBUG - 2019-08-19 16:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:44:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:44:36 --> Pagination Class Initialized
INFO - 2019-08-19 16:44:36 --> Database Driver Class Initialized
INFO - 2019-08-19 16:44:36 --> Database Driver Class Initialized
INFO - 2019-08-19 16:44:36 --> Controller Class Initialized
INFO - 2019-08-19 16:44:36 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:44:36 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomtype.php
INFO - 2019-08-19 16:44:37 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:44:37 --> Final output sent to browser
DEBUG - 2019-08-19 16:44:37 --> Total execution time: 0.2620
INFO - 2019-08-19 16:45:21 --> Config Class Initialized
INFO - 2019-08-19 16:45:21 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:45:21 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:45:21 --> Utf8 Class Initialized
INFO - 2019-08-19 16:45:21 --> URI Class Initialized
INFO - 2019-08-19 16:45:21 --> Config Class Initialized
INFO - 2019-08-19 16:45:21 --> Router Class Initialized
INFO - 2019-08-19 16:45:21 --> Output Class Initialized
INFO - 2019-08-19 16:45:21 --> Hooks Class Initialized
INFO - 2019-08-19 16:45:21 --> Security Class Initialized
DEBUG - 2019-08-19 16:45:21 --> UTF-8 Support Enabled
DEBUG - 2019-08-19 16:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:45:21 --> Utf8 Class Initialized
INFO - 2019-08-19 16:45:21 --> Input Class Initialized
INFO - 2019-08-19 16:45:21 --> Language Class Initialized
INFO - 2019-08-19 16:45:21 --> URI Class Initialized
INFO - 2019-08-19 16:45:21 --> Router Class Initialized
INFO - 2019-08-19 16:45:21 --> Output Class Initialized
INFO - 2019-08-19 16:45:21 --> Loader Class Initialized
INFO - 2019-08-19 16:45:21 --> Security Class Initialized
INFO - 2019-08-19 16:45:21 --> Helper loaded: url_helper
DEBUG - 2019-08-19 16:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:45:21 --> Helper loaded: html_helper
INFO - 2019-08-19 16:45:21 --> Input Class Initialized
INFO - 2019-08-19 16:45:21 --> Helper loaded: form_helper
INFO - 2019-08-19 16:45:21 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:45:21 --> Helper loaded: date_helper
INFO - 2019-08-19 16:45:21 --> Form Validation Class Initialized
INFO - 2019-08-19 16:45:21 --> Email Class Initialized
INFO - 2019-08-19 16:45:21 --> Config Class Initialized
INFO - 2019-08-19 16:45:21 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:45:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-08-19 16:45:21 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:45:21 --> Utf8 Class Initialized
INFO - 2019-08-19 16:45:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:45:21 --> URI Class Initialized
INFO - 2019-08-19 16:45:21 --> Language Class Initialized
INFO - 2019-08-19 16:45:21 --> Pagination Class Initialized
INFO - 2019-08-19 16:45:21 --> Loader Class Initialized
INFO - 2019-08-19 16:45:21 --> Helper loaded: url_helper
INFO - 2019-08-19 16:45:21 --> Helper loaded: html_helper
INFO - 2019-08-19 16:45:21 --> Helper loaded: form_helper
INFO - 2019-08-19 16:45:21 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:45:21 --> Helper loaded: date_helper
INFO - 2019-08-19 16:45:21 --> Database Driver Class Initialized
INFO - 2019-08-19 16:45:21 --> Database Driver Class Initialized
INFO - 2019-08-19 16:45:21 --> Form Validation Class Initialized
INFO - 2019-08-19 16:45:21 --> Router Class Initialized
INFO - 2019-08-19 16:45:21 --> Email Class Initialized
INFO - 2019-08-19 16:45:21 --> Output Class Initialized
DEBUG - 2019-08-19 16:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:45:21 --> Security Class Initialized
INFO - 2019-08-19 16:45:21 --> Controller Class Initialized
DEBUG - 2019-08-19 16:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:45:21 --> Input Class Initialized
INFO - 2019-08-19 16:45:21 --> Language Class Initialized
INFO - 2019-08-19 16:45:21 --> Final output sent to browser
DEBUG - 2019-08-19 16:45:21 --> Total execution time: 0.2742
INFO - 2019-08-19 16:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:45:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:45:21 --> Pagination Class Initialized
INFO - 2019-08-19 16:45:21 --> Loader Class Initialized
INFO - 2019-08-19 16:45:21 --> Database Driver Class Initialized
INFO - 2019-08-19 16:45:22 --> Helper loaded: url_helper
INFO - 2019-08-19 16:45:22 --> Helper loaded: html_helper
INFO - 2019-08-19 16:45:22 --> Helper loaded: form_helper
INFO - 2019-08-19 16:45:22 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:45:22 --> Helper loaded: date_helper
INFO - 2019-08-19 16:45:22 --> Form Validation Class Initialized
INFO - 2019-08-19 16:45:22 --> Email Class Initialized
DEBUG - 2019-08-19 16:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:45:22 --> Database Driver Class Initialized
INFO - 2019-08-19 16:45:22 --> Controller Class Initialized
INFO - 2019-08-19 16:45:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:45:22 --> Final output sent to browser
DEBUG - 2019-08-19 16:45:22 --> Total execution time: 0.4268
INFO - 2019-08-19 16:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:45:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:45:22 --> Pagination Class Initialized
INFO - 2019-08-19 16:45:22 --> Database Driver Class Initialized
INFO - 2019-08-19 16:45:22 --> Database Driver Class Initialized
INFO - 2019-08-19 16:45:22 --> Controller Class Initialized
INFO - 2019-08-19 16:45:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:45:22 --> Final output sent to browser
DEBUG - 2019-08-19 16:45:22 --> Total execution time: 0.4504
INFO - 2019-08-19 16:45:33 --> Config Class Initialized
INFO - 2019-08-19 16:45:33 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:45:33 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:45:33 --> Utf8 Class Initialized
INFO - 2019-08-19 16:45:33 --> URI Class Initialized
INFO - 2019-08-19 16:45:33 --> Router Class Initialized
INFO - 2019-08-19 16:45:33 --> Output Class Initialized
INFO - 2019-08-19 16:45:33 --> Security Class Initialized
DEBUG - 2019-08-19 16:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:45:33 --> Input Class Initialized
INFO - 2019-08-19 16:45:33 --> Language Class Initialized
INFO - 2019-08-19 16:45:33 --> Loader Class Initialized
INFO - 2019-08-19 16:45:33 --> Helper loaded: url_helper
INFO - 2019-08-19 16:45:33 --> Helper loaded: html_helper
INFO - 2019-08-19 16:45:33 --> Helper loaded: form_helper
INFO - 2019-08-19 16:45:33 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:45:33 --> Helper loaded: date_helper
INFO - 2019-08-19 16:45:33 --> Form Validation Class Initialized
INFO - 2019-08-19 16:45:33 --> Email Class Initialized
DEBUG - 2019-08-19 16:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:45:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:45:33 --> Pagination Class Initialized
INFO - 2019-08-19 16:45:33 --> Database Driver Class Initialized
INFO - 2019-08-19 16:45:33 --> Database Driver Class Initialized
INFO - 2019-08-19 16:45:33 --> Controller Class Initialized
INFO - 2019-08-19 16:45:33 --> Config Class Initialized
INFO - 2019-08-19 16:45:33 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:45:33 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:45:33 --> Utf8 Class Initialized
INFO - 2019-08-19 16:45:33 --> URI Class Initialized
INFO - 2019-08-19 16:45:33 --> Router Class Initialized
INFO - 2019-08-19 16:45:33 --> Output Class Initialized
INFO - 2019-08-19 16:45:33 --> Security Class Initialized
DEBUG - 2019-08-19 16:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:45:33 --> Input Class Initialized
INFO - 2019-08-19 16:45:33 --> Language Class Initialized
INFO - 2019-08-19 16:45:33 --> Loader Class Initialized
INFO - 2019-08-19 16:45:33 --> Helper loaded: url_helper
INFO - 2019-08-19 16:45:33 --> Helper loaded: html_helper
INFO - 2019-08-19 16:45:33 --> Helper loaded: form_helper
INFO - 2019-08-19 16:45:33 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:45:33 --> Helper loaded: date_helper
INFO - 2019-08-19 16:45:33 --> Form Validation Class Initialized
INFO - 2019-08-19 16:45:33 --> Email Class Initialized
DEBUG - 2019-08-19 16:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:45:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:45:33 --> Pagination Class Initialized
INFO - 2019-08-19 16:45:33 --> Database Driver Class Initialized
INFO - 2019-08-19 16:45:33 --> Database Driver Class Initialized
INFO - 2019-08-19 16:45:33 --> Controller Class Initialized
INFO - 2019-08-19 16:45:33 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:45:33 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomtype.php
INFO - 2019-08-19 16:45:33 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:45:33 --> Final output sent to browser
DEBUG - 2019-08-19 16:45:33 --> Total execution time: 0.1890
INFO - 2019-08-19 16:46:15 --> Config Class Initialized
INFO - 2019-08-19 16:46:15 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:46:15 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:46:15 --> Utf8 Class Initialized
INFO - 2019-08-19 16:46:15 --> URI Class Initialized
INFO - 2019-08-19 16:46:15 --> Config Class Initialized
INFO - 2019-08-19 16:46:15 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:46:15 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:46:15 --> Utf8 Class Initialized
INFO - 2019-08-19 16:46:15 --> URI Class Initialized
INFO - 2019-08-19 16:46:15 --> Router Class Initialized
INFO - 2019-08-19 16:46:15 --> Router Class Initialized
INFO - 2019-08-19 16:46:15 --> Output Class Initialized
INFO - 2019-08-19 16:46:15 --> Security Class Initialized
DEBUG - 2019-08-19 16:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:46:15 --> Input Class Initialized
INFO - 2019-08-19 16:46:15 --> Language Class Initialized
INFO - 2019-08-19 16:46:15 --> Output Class Initialized
INFO - 2019-08-19 16:46:15 --> Security Class Initialized
DEBUG - 2019-08-19 16:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:46:15 --> Input Class Initialized
INFO - 2019-08-19 16:46:15 --> Language Class Initialized
INFO - 2019-08-19 16:46:16 --> Loader Class Initialized
INFO - 2019-08-19 16:46:16 --> Loader Class Initialized
INFO - 2019-08-19 16:46:16 --> Helper loaded: url_helper
INFO - 2019-08-19 16:46:16 --> Helper loaded: html_helper
INFO - 2019-08-19 16:46:16 --> Helper loaded: form_helper
INFO - 2019-08-19 16:46:16 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:46:16 --> Helper loaded: date_helper
INFO - 2019-08-19 16:46:16 --> Form Validation Class Initialized
INFO - 2019-08-19 16:46:16 --> Helper loaded: url_helper
INFO - 2019-08-19 16:46:16 --> Helper loaded: html_helper
INFO - 2019-08-19 16:46:16 --> Helper loaded: form_helper
INFO - 2019-08-19 16:46:16 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:46:16 --> Helper loaded: date_helper
INFO - 2019-08-19 16:46:16 --> Form Validation Class Initialized
INFO - 2019-08-19 16:46:16 --> Email Class Initialized
INFO - 2019-08-19 16:46:16 --> Email Class Initialized
DEBUG - 2019-08-19 16:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:46:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:46:16 --> Pagination Class Initialized
DEBUG - 2019-08-19 16:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:46:16 --> Database Driver Class Initialized
INFO - 2019-08-19 16:46:16 --> Database Driver Class Initialized
INFO - 2019-08-19 16:46:16 --> Controller Class Initialized
INFO - 2019-08-19 16:46:16 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:46:16 --> Final output sent to browser
DEBUG - 2019-08-19 16:46:16 --> Total execution time: 0.3100
INFO - 2019-08-19 16:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:46:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:46:16 --> Pagination Class Initialized
INFO - 2019-08-19 16:46:16 --> Database Driver Class Initialized
INFO - 2019-08-19 16:46:16 --> Database Driver Class Initialized
INFO - 2019-08-19 16:46:16 --> Controller Class Initialized
INFO - 2019-08-19 16:46:16 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:46:16 --> Final output sent to browser
DEBUG - 2019-08-19 16:46:16 --> Total execution time: 0.3900
INFO - 2019-08-19 16:46:16 --> Config Class Initialized
INFO - 2019-08-19 16:46:16 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:46:16 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:46:16 --> Utf8 Class Initialized
INFO - 2019-08-19 16:46:16 --> URI Class Initialized
INFO - 2019-08-19 16:46:16 --> Router Class Initialized
INFO - 2019-08-19 16:46:16 --> Output Class Initialized
INFO - 2019-08-19 16:46:16 --> Security Class Initialized
DEBUG - 2019-08-19 16:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:46:16 --> Input Class Initialized
INFO - 2019-08-19 16:46:16 --> Language Class Initialized
INFO - 2019-08-19 16:46:16 --> Loader Class Initialized
INFO - 2019-08-19 16:46:16 --> Helper loaded: url_helper
INFO - 2019-08-19 16:46:16 --> Helper loaded: html_helper
INFO - 2019-08-19 16:46:16 --> Helper loaded: form_helper
INFO - 2019-08-19 16:46:16 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:46:16 --> Helper loaded: date_helper
INFO - 2019-08-19 16:46:16 --> Form Validation Class Initialized
INFO - 2019-08-19 16:46:16 --> Email Class Initialized
DEBUG - 2019-08-19 16:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:46:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:46:16 --> Pagination Class Initialized
INFO - 2019-08-19 16:46:16 --> Database Driver Class Initialized
INFO - 2019-08-19 16:46:16 --> Database Driver Class Initialized
INFO - 2019-08-19 16:46:16 --> Controller Class Initialized
INFO - 2019-08-19 16:46:16 --> Final output sent to browser
DEBUG - 2019-08-19 16:46:16 --> Total execution time: 0.2650
INFO - 2019-08-19 16:46:22 --> Config Class Initialized
INFO - 2019-08-19 16:46:22 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:46:22 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:46:22 --> Utf8 Class Initialized
INFO - 2019-08-19 16:46:22 --> URI Class Initialized
INFO - 2019-08-19 16:46:22 --> Router Class Initialized
INFO - 2019-08-19 16:46:22 --> Output Class Initialized
INFO - 2019-08-19 16:46:22 --> Security Class Initialized
DEBUG - 2019-08-19 16:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:46:22 --> Input Class Initialized
INFO - 2019-08-19 16:46:22 --> Language Class Initialized
INFO - 2019-08-19 16:46:22 --> Loader Class Initialized
INFO - 2019-08-19 16:46:22 --> Helper loaded: url_helper
INFO - 2019-08-19 16:46:22 --> Helper loaded: html_helper
INFO - 2019-08-19 16:46:22 --> Helper loaded: form_helper
INFO - 2019-08-19 16:46:22 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:46:22 --> Helper loaded: date_helper
INFO - 2019-08-19 16:46:22 --> Form Validation Class Initialized
INFO - 2019-08-19 16:46:22 --> Email Class Initialized
DEBUG - 2019-08-19 16:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:46:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:46:22 --> Pagination Class Initialized
INFO - 2019-08-19 16:46:22 --> Database Driver Class Initialized
INFO - 2019-08-19 16:46:22 --> Database Driver Class Initialized
INFO - 2019-08-19 16:46:22 --> Controller Class Initialized
INFO - 2019-08-19 16:46:22 --> Config Class Initialized
INFO - 2019-08-19 16:46:22 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:46:22 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:46:22 --> Utf8 Class Initialized
INFO - 2019-08-19 16:46:22 --> URI Class Initialized
INFO - 2019-08-19 16:46:22 --> Router Class Initialized
INFO - 2019-08-19 16:46:22 --> Output Class Initialized
INFO - 2019-08-19 16:46:22 --> Security Class Initialized
DEBUG - 2019-08-19 16:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:46:22 --> Input Class Initialized
INFO - 2019-08-19 16:46:22 --> Language Class Initialized
INFO - 2019-08-19 16:46:22 --> Loader Class Initialized
INFO - 2019-08-19 16:46:22 --> Helper loaded: url_helper
INFO - 2019-08-19 16:46:22 --> Helper loaded: html_helper
INFO - 2019-08-19 16:46:22 --> Helper loaded: form_helper
INFO - 2019-08-19 16:46:22 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:46:22 --> Helper loaded: date_helper
INFO - 2019-08-19 16:46:22 --> Form Validation Class Initialized
INFO - 2019-08-19 16:46:22 --> Email Class Initialized
DEBUG - 2019-08-19 16:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:46:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:46:22 --> Pagination Class Initialized
INFO - 2019-08-19 16:46:22 --> Database Driver Class Initialized
INFO - 2019-08-19 16:46:22 --> Database Driver Class Initialized
INFO - 2019-08-19 16:46:22 --> Controller Class Initialized
INFO - 2019-08-19 16:46:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:46:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomtype.php
INFO - 2019-08-19 16:46:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:46:22 --> Final output sent to browser
DEBUG - 2019-08-19 16:46:22 --> Total execution time: 0.1920
INFO - 2019-08-19 16:46:58 --> Config Class Initialized
INFO - 2019-08-19 16:46:58 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:46:58 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:46:58 --> Utf8 Class Initialized
INFO - 2019-08-19 16:46:58 --> URI Class Initialized
INFO - 2019-08-19 16:46:58 --> Router Class Initialized
INFO - 2019-08-19 16:46:58 --> Output Class Initialized
INFO - 2019-08-19 16:46:58 --> Security Class Initialized
DEBUG - 2019-08-19 16:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:46:58 --> Input Class Initialized
INFO - 2019-08-19 16:46:58 --> Language Class Initialized
INFO - 2019-08-19 16:46:58 --> Config Class Initialized
INFO - 2019-08-19 16:46:58 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:46:58 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:46:58 --> Utf8 Class Initialized
INFO - 2019-08-19 16:46:58 --> URI Class Initialized
INFO - 2019-08-19 16:46:58 --> Loader Class Initialized
INFO - 2019-08-19 16:46:58 --> Helper loaded: url_helper
INFO - 2019-08-19 16:46:58 --> Helper loaded: html_helper
INFO - 2019-08-19 16:46:58 --> Helper loaded: form_helper
INFO - 2019-08-19 16:46:58 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:46:58 --> Helper loaded: date_helper
INFO - 2019-08-19 16:46:58 --> Form Validation Class Initialized
INFO - 2019-08-19 16:46:58 --> Router Class Initialized
INFO - 2019-08-19 16:46:58 --> Output Class Initialized
INFO - 2019-08-19 16:46:58 --> Security Class Initialized
DEBUG - 2019-08-19 16:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:46:58 --> Input Class Initialized
INFO - 2019-08-19 16:46:58 --> Language Class Initialized
INFO - 2019-08-19 16:46:58 --> Email Class Initialized
DEBUG - 2019-08-19 16:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:46:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:46:58 --> Pagination Class Initialized
INFO - 2019-08-19 16:46:58 --> Loader Class Initialized
INFO - 2019-08-19 16:46:58 --> Helper loaded: url_helper
INFO - 2019-08-19 16:46:58 --> Helper loaded: html_helper
INFO - 2019-08-19 16:46:58 --> Helper loaded: form_helper
INFO - 2019-08-19 16:46:58 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:46:58 --> Helper loaded: date_helper
INFO - 2019-08-19 16:46:58 --> Form Validation Class Initialized
INFO - 2019-08-19 16:46:58 --> Database Driver Class Initialized
INFO - 2019-08-19 16:46:58 --> Database Driver Class Initialized
INFO - 2019-08-19 16:46:58 --> Email Class Initialized
DEBUG - 2019-08-19 16:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:46:58 --> Controller Class Initialized
INFO - 2019-08-19 16:46:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:46:58 --> Final output sent to browser
DEBUG - 2019-08-19 16:46:58 --> Total execution time: 0.3040
INFO - 2019-08-19 16:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:46:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:46:58 --> Pagination Class Initialized
INFO - 2019-08-19 16:46:58 --> Database Driver Class Initialized
INFO - 2019-08-19 16:46:58 --> Database Driver Class Initialized
INFO - 2019-08-19 16:46:58 --> Controller Class Initialized
INFO - 2019-08-19 16:46:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:46:58 --> Final output sent to browser
DEBUG - 2019-08-19 16:46:58 --> Total execution time: 0.3340
INFO - 2019-08-19 16:46:58 --> Config Class Initialized
INFO - 2019-08-19 16:46:58 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:46:58 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:46:58 --> Utf8 Class Initialized
INFO - 2019-08-19 16:46:58 --> URI Class Initialized
INFO - 2019-08-19 16:46:58 --> Router Class Initialized
INFO - 2019-08-19 16:46:59 --> Output Class Initialized
INFO - 2019-08-19 16:46:59 --> Security Class Initialized
DEBUG - 2019-08-19 16:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:46:59 --> Input Class Initialized
INFO - 2019-08-19 16:46:59 --> Language Class Initialized
INFO - 2019-08-19 16:46:59 --> Loader Class Initialized
INFO - 2019-08-19 16:46:59 --> Helper loaded: url_helper
INFO - 2019-08-19 16:46:59 --> Helper loaded: html_helper
INFO - 2019-08-19 16:46:59 --> Helper loaded: form_helper
INFO - 2019-08-19 16:46:59 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:46:59 --> Helper loaded: date_helper
INFO - 2019-08-19 16:46:59 --> Form Validation Class Initialized
INFO - 2019-08-19 16:46:59 --> Email Class Initialized
DEBUG - 2019-08-19 16:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:46:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:46:59 --> Pagination Class Initialized
INFO - 2019-08-19 16:46:59 --> Database Driver Class Initialized
INFO - 2019-08-19 16:46:59 --> Database Driver Class Initialized
INFO - 2019-08-19 16:46:59 --> Controller Class Initialized
INFO - 2019-08-19 16:46:59 --> Final output sent to browser
DEBUG - 2019-08-19 16:46:59 --> Total execution time: 0.2690
INFO - 2019-08-19 16:47:05 --> Config Class Initialized
INFO - 2019-08-19 16:47:05 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:47:05 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:47:05 --> Utf8 Class Initialized
INFO - 2019-08-19 16:47:05 --> URI Class Initialized
INFO - 2019-08-19 16:47:05 --> Router Class Initialized
INFO - 2019-08-19 16:47:05 --> Output Class Initialized
INFO - 2019-08-19 16:47:05 --> Security Class Initialized
DEBUG - 2019-08-19 16:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:47:05 --> Input Class Initialized
INFO - 2019-08-19 16:47:05 --> Language Class Initialized
INFO - 2019-08-19 16:47:05 --> Loader Class Initialized
INFO - 2019-08-19 16:47:05 --> Helper loaded: url_helper
INFO - 2019-08-19 16:47:05 --> Helper loaded: html_helper
INFO - 2019-08-19 16:47:05 --> Helper loaded: form_helper
INFO - 2019-08-19 16:47:05 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:47:05 --> Helper loaded: date_helper
INFO - 2019-08-19 16:47:05 --> Form Validation Class Initialized
INFO - 2019-08-19 16:47:05 --> Email Class Initialized
DEBUG - 2019-08-19 16:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:47:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:47:05 --> Pagination Class Initialized
INFO - 2019-08-19 16:47:05 --> Database Driver Class Initialized
INFO - 2019-08-19 16:47:05 --> Database Driver Class Initialized
INFO - 2019-08-19 16:47:05 --> Controller Class Initialized
INFO - 2019-08-19 16:47:05 --> Config Class Initialized
INFO - 2019-08-19 16:47:05 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:47:05 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:47:05 --> Utf8 Class Initialized
INFO - 2019-08-19 16:47:05 --> URI Class Initialized
INFO - 2019-08-19 16:47:05 --> Router Class Initialized
INFO - 2019-08-19 16:47:05 --> Output Class Initialized
INFO - 2019-08-19 16:47:05 --> Security Class Initialized
DEBUG - 2019-08-19 16:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:47:05 --> Input Class Initialized
INFO - 2019-08-19 16:47:05 --> Language Class Initialized
INFO - 2019-08-19 16:47:05 --> Loader Class Initialized
INFO - 2019-08-19 16:47:05 --> Helper loaded: url_helper
INFO - 2019-08-19 16:47:05 --> Helper loaded: html_helper
INFO - 2019-08-19 16:47:05 --> Helper loaded: form_helper
INFO - 2019-08-19 16:47:05 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:47:05 --> Helper loaded: date_helper
INFO - 2019-08-19 16:47:05 --> Form Validation Class Initialized
INFO - 2019-08-19 16:47:06 --> Email Class Initialized
DEBUG - 2019-08-19 16:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:47:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:47:06 --> Pagination Class Initialized
INFO - 2019-08-19 16:47:06 --> Database Driver Class Initialized
INFO - 2019-08-19 16:47:06 --> Database Driver Class Initialized
INFO - 2019-08-19 16:47:06 --> Controller Class Initialized
INFO - 2019-08-19 16:47:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:47:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomtype.php
INFO - 2019-08-19 16:47:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:47:06 --> Final output sent to browser
DEBUG - 2019-08-19 16:47:06 --> Total execution time: 0.1880
INFO - 2019-08-19 16:47:40 --> Config Class Initialized
INFO - 2019-08-19 16:47:40 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:47:40 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:47:40 --> Utf8 Class Initialized
INFO - 2019-08-19 16:47:40 --> URI Class Initialized
INFO - 2019-08-19 16:47:40 --> Router Class Initialized
INFO - 2019-08-19 16:47:40 --> Output Class Initialized
INFO - 2019-08-19 16:47:40 --> Security Class Initialized
DEBUG - 2019-08-19 16:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:47:40 --> Input Class Initialized
INFO - 2019-08-19 16:47:40 --> Language Class Initialized
INFO - 2019-08-19 16:47:40 --> Loader Class Initialized
INFO - 2019-08-19 16:47:40 --> Helper loaded: url_helper
INFO - 2019-08-19 16:47:40 --> Helper loaded: html_helper
INFO - 2019-08-19 16:47:40 --> Helper loaded: form_helper
INFO - 2019-08-19 16:47:40 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:47:40 --> Helper loaded: date_helper
INFO - 2019-08-19 16:47:40 --> Form Validation Class Initialized
INFO - 2019-08-19 16:47:40 --> Email Class Initialized
DEBUG - 2019-08-19 16:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:47:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:47:40 --> Pagination Class Initialized
INFO - 2019-08-19 16:47:40 --> Config Class Initialized
INFO - 2019-08-19 16:47:40 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:47:40 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:47:40 --> Utf8 Class Initialized
INFO - 2019-08-19 16:47:40 --> URI Class Initialized
INFO - 2019-08-19 16:47:40 --> Database Driver Class Initialized
INFO - 2019-08-19 16:47:40 --> Database Driver Class Initialized
INFO - 2019-08-19 16:47:40 --> Router Class Initialized
INFO - 2019-08-19 16:47:40 --> Output Class Initialized
INFO - 2019-08-19 16:47:40 --> Security Class Initialized
DEBUG - 2019-08-19 16:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:47:40 --> Input Class Initialized
INFO - 2019-08-19 16:47:40 --> Language Class Initialized
INFO - 2019-08-19 16:47:40 --> Loader Class Initialized
INFO - 2019-08-19 16:47:40 --> Helper loaded: url_helper
INFO - 2019-08-19 16:47:40 --> Helper loaded: html_helper
INFO - 2019-08-19 16:47:40 --> Helper loaded: form_helper
INFO - 2019-08-19 16:47:40 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:47:40 --> Helper loaded: date_helper
INFO - 2019-08-19 16:47:40 --> Form Validation Class Initialized
INFO - 2019-08-19 16:47:40 --> Email Class Initialized
DEBUG - 2019-08-19 16:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:47:40 --> Controller Class Initialized
INFO - 2019-08-19 16:47:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:47:40 --> Final output sent to browser
DEBUG - 2019-08-19 16:47:40 --> Total execution time: 0.2520
INFO - 2019-08-19 16:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:47:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:47:40 --> Pagination Class Initialized
INFO - 2019-08-19 16:47:40 --> Database Driver Class Initialized
INFO - 2019-08-19 16:47:40 --> Database Driver Class Initialized
INFO - 2019-08-19 16:47:40 --> Controller Class Initialized
INFO - 2019-08-19 16:47:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:47:40 --> Final output sent to browser
DEBUG - 2019-08-19 16:47:40 --> Total execution time: 0.2200
INFO - 2019-08-19 16:47:41 --> Config Class Initialized
INFO - 2019-08-19 16:47:41 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:47:41 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:47:41 --> Utf8 Class Initialized
INFO - 2019-08-19 16:47:41 --> URI Class Initialized
INFO - 2019-08-19 16:47:41 --> Router Class Initialized
INFO - 2019-08-19 16:47:41 --> Output Class Initialized
INFO - 2019-08-19 16:47:41 --> Security Class Initialized
DEBUG - 2019-08-19 16:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:47:41 --> Input Class Initialized
INFO - 2019-08-19 16:47:41 --> Language Class Initialized
INFO - 2019-08-19 16:47:41 --> Loader Class Initialized
INFO - 2019-08-19 16:47:41 --> Helper loaded: url_helper
INFO - 2019-08-19 16:47:41 --> Helper loaded: html_helper
INFO - 2019-08-19 16:47:41 --> Helper loaded: form_helper
INFO - 2019-08-19 16:47:41 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:47:41 --> Helper loaded: date_helper
INFO - 2019-08-19 16:47:41 --> Form Validation Class Initialized
INFO - 2019-08-19 16:47:41 --> Email Class Initialized
DEBUG - 2019-08-19 16:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:47:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:47:41 --> Pagination Class Initialized
INFO - 2019-08-19 16:47:41 --> Database Driver Class Initialized
INFO - 2019-08-19 16:47:41 --> Database Driver Class Initialized
INFO - 2019-08-19 16:47:41 --> Controller Class Initialized
INFO - 2019-08-19 16:47:41 --> Final output sent to browser
DEBUG - 2019-08-19 16:47:41 --> Total execution time: 0.2550
INFO - 2019-08-19 16:47:54 --> Config Class Initialized
INFO - 2019-08-19 16:47:54 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:47:54 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:47:54 --> Utf8 Class Initialized
INFO - 2019-08-19 16:47:54 --> URI Class Initialized
INFO - 2019-08-19 16:47:54 --> Router Class Initialized
INFO - 2019-08-19 16:47:54 --> Output Class Initialized
INFO - 2019-08-19 16:47:54 --> Security Class Initialized
DEBUG - 2019-08-19 16:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:47:54 --> Input Class Initialized
INFO - 2019-08-19 16:47:54 --> Language Class Initialized
INFO - 2019-08-19 16:47:54 --> Loader Class Initialized
INFO - 2019-08-19 16:47:54 --> Helper loaded: url_helper
INFO - 2019-08-19 16:47:54 --> Helper loaded: html_helper
INFO - 2019-08-19 16:47:54 --> Helper loaded: form_helper
INFO - 2019-08-19 16:47:54 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:47:54 --> Helper loaded: date_helper
INFO - 2019-08-19 16:47:54 --> Form Validation Class Initialized
INFO - 2019-08-19 16:47:54 --> Email Class Initialized
DEBUG - 2019-08-19 16:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:47:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:47:54 --> Pagination Class Initialized
INFO - 2019-08-19 16:47:54 --> Database Driver Class Initialized
INFO - 2019-08-19 16:47:54 --> Database Driver Class Initialized
INFO - 2019-08-19 16:47:54 --> Controller Class Initialized
INFO - 2019-08-19 16:47:54 --> Config Class Initialized
INFO - 2019-08-19 16:47:54 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:47:54 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:47:54 --> Utf8 Class Initialized
INFO - 2019-08-19 16:47:54 --> URI Class Initialized
INFO - 2019-08-19 16:47:54 --> Router Class Initialized
INFO - 2019-08-19 16:47:54 --> Output Class Initialized
INFO - 2019-08-19 16:47:54 --> Security Class Initialized
DEBUG - 2019-08-19 16:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:47:54 --> Input Class Initialized
INFO - 2019-08-19 16:47:54 --> Language Class Initialized
INFO - 2019-08-19 16:47:54 --> Loader Class Initialized
INFO - 2019-08-19 16:47:54 --> Helper loaded: url_helper
INFO - 2019-08-19 16:47:54 --> Helper loaded: html_helper
INFO - 2019-08-19 16:47:54 --> Helper loaded: form_helper
INFO - 2019-08-19 16:47:54 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:47:54 --> Helper loaded: date_helper
INFO - 2019-08-19 16:47:55 --> Form Validation Class Initialized
INFO - 2019-08-19 16:47:55 --> Email Class Initialized
DEBUG - 2019-08-19 16:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:47:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:47:55 --> Pagination Class Initialized
INFO - 2019-08-19 16:47:55 --> Database Driver Class Initialized
INFO - 2019-08-19 16:47:55 --> Database Driver Class Initialized
INFO - 2019-08-19 16:47:55 --> Controller Class Initialized
INFO - 2019-08-19 16:47:55 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:47:55 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomtype.php
INFO - 2019-08-19 16:47:55 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:47:55 --> Final output sent to browser
DEBUG - 2019-08-19 16:47:55 --> Total execution time: 0.1840
INFO - 2019-08-19 16:48:43 --> Config Class Initialized
INFO - 2019-08-19 16:48:43 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:48:43 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:48:43 --> Utf8 Class Initialized
INFO - 2019-08-19 16:48:43 --> URI Class Initialized
INFO - 2019-08-19 16:48:43 --> Router Class Initialized
INFO - 2019-08-19 16:48:43 --> Output Class Initialized
INFO - 2019-08-19 16:48:43 --> Security Class Initialized
DEBUG - 2019-08-19 16:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:48:43 --> Input Class Initialized
INFO - 2019-08-19 16:48:43 --> Language Class Initialized
INFO - 2019-08-19 16:48:43 --> Config Class Initialized
INFO - 2019-08-19 16:48:43 --> Hooks Class Initialized
INFO - 2019-08-19 16:48:43 --> Loader Class Initialized
INFO - 2019-08-19 16:48:43 --> Helper loaded: url_helper
DEBUG - 2019-08-19 16:48:43 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:48:43 --> Utf8 Class Initialized
INFO - 2019-08-19 16:48:43 --> URI Class Initialized
INFO - 2019-08-19 16:48:43 --> Router Class Initialized
INFO - 2019-08-19 16:48:43 --> Helper loaded: html_helper
INFO - 2019-08-19 16:48:43 --> Helper loaded: form_helper
INFO - 2019-08-19 16:48:43 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:48:43 --> Helper loaded: date_helper
INFO - 2019-08-19 16:48:43 --> Form Validation Class Initialized
INFO - 2019-08-19 16:48:43 --> Output Class Initialized
INFO - 2019-08-19 16:48:43 --> Email Class Initialized
DEBUG - 2019-08-19 16:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:48:43 --> Pagination Class Initialized
INFO - 2019-08-19 16:48:43 --> Security Class Initialized
DEBUG - 2019-08-19 16:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:48:43 --> Input Class Initialized
INFO - 2019-08-19 16:48:43 --> Language Class Initialized
INFO - 2019-08-19 16:48:43 --> Loader Class Initialized
INFO - 2019-08-19 16:48:43 --> Helper loaded: url_helper
INFO - 2019-08-19 16:48:43 --> Helper loaded: html_helper
INFO - 2019-08-19 16:48:44 --> Database Driver Class Initialized
INFO - 2019-08-19 16:48:44 --> Database Driver Class Initialized
INFO - 2019-08-19 16:48:44 --> Helper loaded: form_helper
INFO - 2019-08-19 16:48:44 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:48:44 --> Helper loaded: date_helper
INFO - 2019-08-19 16:48:44 --> Form Validation Class Initialized
INFO - 2019-08-19 16:48:44 --> Email Class Initialized
DEBUG - 2019-08-19 16:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:48:44 --> Controller Class Initialized
INFO - 2019-08-19 16:48:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:48:44 --> Final output sent to browser
DEBUG - 2019-08-19 16:48:44 --> Total execution time: 0.2920
INFO - 2019-08-19 16:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:48:44 --> Pagination Class Initialized
INFO - 2019-08-19 16:48:44 --> Database Driver Class Initialized
INFO - 2019-08-19 16:48:44 --> Database Driver Class Initialized
INFO - 2019-08-19 16:48:44 --> Controller Class Initialized
INFO - 2019-08-19 16:48:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:48:44 --> Final output sent to browser
DEBUG - 2019-08-19 16:48:44 --> Total execution time: 0.3870
INFO - 2019-08-19 16:48:44 --> Config Class Initialized
INFO - 2019-08-19 16:48:44 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:48:44 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:48:44 --> Utf8 Class Initialized
INFO - 2019-08-19 16:48:44 --> URI Class Initialized
INFO - 2019-08-19 16:48:44 --> Router Class Initialized
INFO - 2019-08-19 16:48:44 --> Output Class Initialized
INFO - 2019-08-19 16:48:44 --> Security Class Initialized
DEBUG - 2019-08-19 16:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:48:44 --> Input Class Initialized
INFO - 2019-08-19 16:48:44 --> Language Class Initialized
INFO - 2019-08-19 16:48:44 --> Loader Class Initialized
INFO - 2019-08-19 16:48:44 --> Helper loaded: url_helper
INFO - 2019-08-19 16:48:44 --> Helper loaded: html_helper
INFO - 2019-08-19 16:48:44 --> Helper loaded: form_helper
INFO - 2019-08-19 16:48:44 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:48:44 --> Helper loaded: date_helper
INFO - 2019-08-19 16:48:44 --> Form Validation Class Initialized
INFO - 2019-08-19 16:48:44 --> Email Class Initialized
DEBUG - 2019-08-19 16:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:48:44 --> Pagination Class Initialized
INFO - 2019-08-19 16:48:44 --> Database Driver Class Initialized
INFO - 2019-08-19 16:48:44 --> Database Driver Class Initialized
INFO - 2019-08-19 16:48:44 --> Controller Class Initialized
INFO - 2019-08-19 16:48:44 --> Final output sent to browser
DEBUG - 2019-08-19 16:48:44 --> Total execution time: 0.2586
INFO - 2019-08-19 16:49:29 --> Config Class Initialized
INFO - 2019-08-19 16:49:29 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:49:29 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:49:29 --> Utf8 Class Initialized
INFO - 2019-08-19 16:49:29 --> URI Class Initialized
INFO - 2019-08-19 16:49:29 --> Router Class Initialized
INFO - 2019-08-19 16:49:29 --> Output Class Initialized
INFO - 2019-08-19 16:49:29 --> Security Class Initialized
DEBUG - 2019-08-19 16:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:49:29 --> Input Class Initialized
INFO - 2019-08-19 16:49:29 --> Language Class Initialized
INFO - 2019-08-19 16:49:29 --> Loader Class Initialized
INFO - 2019-08-19 16:49:29 --> Helper loaded: url_helper
INFO - 2019-08-19 16:49:29 --> Helper loaded: html_helper
INFO - 2019-08-19 16:49:29 --> Helper loaded: form_helper
INFO - 2019-08-19 16:49:29 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:49:29 --> Helper loaded: date_helper
INFO - 2019-08-19 16:49:29 --> Form Validation Class Initialized
INFO - 2019-08-19 16:49:29 --> Email Class Initialized
DEBUG - 2019-08-19 16:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:49:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:49:29 --> Pagination Class Initialized
INFO - 2019-08-19 16:49:29 --> Database Driver Class Initialized
INFO - 2019-08-19 16:49:29 --> Database Driver Class Initialized
INFO - 2019-08-19 16:49:29 --> Controller Class Initialized
INFO - 2019-08-19 16:49:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 16:49:29 --> Config Class Initialized
INFO - 2019-08-19 16:49:29 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:49:29 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:49:29 --> Utf8 Class Initialized
INFO - 2019-08-19 16:49:29 --> URI Class Initialized
INFO - 2019-08-19 16:49:29 --> Router Class Initialized
INFO - 2019-08-19 16:49:29 --> Output Class Initialized
INFO - 2019-08-19 16:49:29 --> Security Class Initialized
DEBUG - 2019-08-19 16:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:49:29 --> Input Class Initialized
INFO - 2019-08-19 16:49:29 --> Language Class Initialized
INFO - 2019-08-19 16:49:29 --> Loader Class Initialized
INFO - 2019-08-19 16:49:29 --> Helper loaded: url_helper
INFO - 2019-08-19 16:49:29 --> Helper loaded: html_helper
INFO - 2019-08-19 16:49:29 --> Helper loaded: form_helper
INFO - 2019-08-19 16:49:29 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:49:29 --> Helper loaded: date_helper
INFO - 2019-08-19 16:49:29 --> Form Validation Class Initialized
INFO - 2019-08-19 16:49:29 --> Email Class Initialized
DEBUG - 2019-08-19 16:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:49:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:49:29 --> Pagination Class Initialized
INFO - 2019-08-19 16:49:29 --> Database Driver Class Initialized
INFO - 2019-08-19 16:49:29 --> Database Driver Class Initialized
INFO - 2019-08-19 16:49:29 --> Controller Class Initialized
INFO - 2019-08-19 16:49:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:49:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomtype.php
INFO - 2019-08-19 16:49:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:49:29 --> Final output sent to browser
DEBUG - 2019-08-19 16:49:29 --> Total execution time: 0.1830
INFO - 2019-08-19 16:50:11 --> Config Class Initialized
INFO - 2019-08-19 16:50:11 --> Hooks Class Initialized
INFO - 2019-08-19 16:50:11 --> Config Class Initialized
INFO - 2019-08-19 16:50:11 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:50:11 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:50:11 --> Utf8 Class Initialized
INFO - 2019-08-19 16:50:11 --> URI Class Initialized
INFO - 2019-08-19 16:50:11 --> Router Class Initialized
INFO - 2019-08-19 16:50:11 --> Output Class Initialized
INFO - 2019-08-19 16:50:11 --> Security Class Initialized
DEBUG - 2019-08-19 16:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:50:11 --> Input Class Initialized
INFO - 2019-08-19 16:50:11 --> Language Class Initialized
DEBUG - 2019-08-19 16:50:11 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:50:11 --> Utf8 Class Initialized
INFO - 2019-08-19 16:50:11 --> URI Class Initialized
INFO - 2019-08-19 16:50:11 --> Router Class Initialized
INFO - 2019-08-19 16:50:11 --> Output Class Initialized
INFO - 2019-08-19 16:50:11 --> Security Class Initialized
DEBUG - 2019-08-19 16:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:50:11 --> Input Class Initialized
INFO - 2019-08-19 16:50:11 --> Language Class Initialized
INFO - 2019-08-19 16:50:11 --> Loader Class Initialized
INFO - 2019-08-19 16:50:11 --> Helper loaded: url_helper
INFO - 2019-08-19 16:50:11 --> Loader Class Initialized
INFO - 2019-08-19 16:50:11 --> Helper loaded: html_helper
INFO - 2019-08-19 16:50:11 --> Helper loaded: form_helper
INFO - 2019-08-19 16:50:11 --> Helper loaded: url_helper
INFO - 2019-08-19 16:50:11 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:50:11 --> Helper loaded: html_helper
INFO - 2019-08-19 16:50:11 --> Helper loaded: date_helper
INFO - 2019-08-19 16:50:11 --> Helper loaded: form_helper
INFO - 2019-08-19 16:50:11 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:50:11 --> Form Validation Class Initialized
INFO - 2019-08-19 16:50:11 --> Helper loaded: date_helper
INFO - 2019-08-19 16:50:11 --> Email Class Initialized
INFO - 2019-08-19 16:50:11 --> Form Validation Class Initialized
DEBUG - 2019-08-19 16:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:50:11 --> Email Class Initialized
INFO - 2019-08-19 16:50:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:50:11 --> Pagination Class Initialized
DEBUG - 2019-08-19 16:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:50:11 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:11 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:11 --> Controller Class Initialized
INFO - 2019-08-19 16:50:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:50:11 --> Final output sent to browser
DEBUG - 2019-08-19 16:50:11 --> Total execution time: 0.2062
INFO - 2019-08-19 16:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:50:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:50:11 --> Pagination Class Initialized
INFO - 2019-08-19 16:50:11 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:11 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:11 --> Controller Class Initialized
INFO - 2019-08-19 16:50:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:50:11 --> Final output sent to browser
DEBUG - 2019-08-19 16:50:11 --> Total execution time: 0.3424
INFO - 2019-08-19 16:50:12 --> Config Class Initialized
INFO - 2019-08-19 16:50:12 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:50:12 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:50:12 --> Utf8 Class Initialized
INFO - 2019-08-19 16:50:12 --> URI Class Initialized
INFO - 2019-08-19 16:50:12 --> Router Class Initialized
INFO - 2019-08-19 16:50:12 --> Output Class Initialized
INFO - 2019-08-19 16:50:12 --> Security Class Initialized
DEBUG - 2019-08-19 16:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:50:12 --> Input Class Initialized
INFO - 2019-08-19 16:50:12 --> Language Class Initialized
INFO - 2019-08-19 16:50:12 --> Loader Class Initialized
INFO - 2019-08-19 16:50:12 --> Helper loaded: url_helper
INFO - 2019-08-19 16:50:12 --> Helper loaded: html_helper
INFO - 2019-08-19 16:50:12 --> Helper loaded: form_helper
INFO - 2019-08-19 16:50:12 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:50:12 --> Helper loaded: date_helper
INFO - 2019-08-19 16:50:12 --> Form Validation Class Initialized
INFO - 2019-08-19 16:50:12 --> Email Class Initialized
DEBUG - 2019-08-19 16:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:50:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:50:12 --> Pagination Class Initialized
INFO - 2019-08-19 16:50:12 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:12 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:12 --> Controller Class Initialized
INFO - 2019-08-19 16:50:12 --> Final output sent to browser
DEBUG - 2019-08-19 16:50:12 --> Total execution time: 0.2496
INFO - 2019-08-19 16:50:19 --> Config Class Initialized
INFO - 2019-08-19 16:50:19 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:50:19 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:50:19 --> Utf8 Class Initialized
INFO - 2019-08-19 16:50:19 --> URI Class Initialized
INFO - 2019-08-19 16:50:19 --> Router Class Initialized
INFO - 2019-08-19 16:50:19 --> Output Class Initialized
INFO - 2019-08-19 16:50:19 --> Security Class Initialized
DEBUG - 2019-08-19 16:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:50:19 --> Input Class Initialized
INFO - 2019-08-19 16:50:19 --> Language Class Initialized
INFO - 2019-08-19 16:50:19 --> Loader Class Initialized
INFO - 2019-08-19 16:50:19 --> Helper loaded: url_helper
INFO - 2019-08-19 16:50:19 --> Helper loaded: html_helper
INFO - 2019-08-19 16:50:19 --> Helper loaded: form_helper
INFO - 2019-08-19 16:50:19 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:50:19 --> Helper loaded: date_helper
INFO - 2019-08-19 16:50:19 --> Form Validation Class Initialized
INFO - 2019-08-19 16:50:19 --> Email Class Initialized
DEBUG - 2019-08-19 16:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:50:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:50:19 --> Pagination Class Initialized
INFO - 2019-08-19 16:50:19 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:19 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:19 --> Controller Class Initialized
INFO - 2019-08-19 16:50:19 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:50:19 --> Final output sent to browser
DEBUG - 2019-08-19 16:50:19 --> Total execution time: 0.2390
INFO - 2019-08-19 16:50:20 --> Config Class Initialized
INFO - 2019-08-19 16:50:20 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:50:20 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:50:20 --> Utf8 Class Initialized
INFO - 2019-08-19 16:50:20 --> URI Class Initialized
INFO - 2019-08-19 16:50:20 --> Router Class Initialized
INFO - 2019-08-19 16:50:20 --> Output Class Initialized
INFO - 2019-08-19 16:50:20 --> Security Class Initialized
DEBUG - 2019-08-19 16:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:50:20 --> Input Class Initialized
INFO - 2019-08-19 16:50:20 --> Language Class Initialized
INFO - 2019-08-19 16:50:20 --> Loader Class Initialized
INFO - 2019-08-19 16:50:20 --> Helper loaded: url_helper
INFO - 2019-08-19 16:50:20 --> Helper loaded: html_helper
INFO - 2019-08-19 16:50:20 --> Helper loaded: form_helper
INFO - 2019-08-19 16:50:20 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:50:20 --> Helper loaded: date_helper
INFO - 2019-08-19 16:50:20 --> Form Validation Class Initialized
INFO - 2019-08-19 16:50:20 --> Email Class Initialized
DEBUG - 2019-08-19 16:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:50:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:50:20 --> Pagination Class Initialized
INFO - 2019-08-19 16:50:20 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:20 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:20 --> Controller Class Initialized
INFO - 2019-08-19 16:50:20 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:50:20 --> Final output sent to browser
DEBUG - 2019-08-19 16:50:20 --> Total execution time: 0.1870
INFO - 2019-08-19 16:50:27 --> Config Class Initialized
INFO - 2019-08-19 16:50:27 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:50:27 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:50:27 --> Utf8 Class Initialized
INFO - 2019-08-19 16:50:27 --> URI Class Initialized
INFO - 2019-08-19 16:50:27 --> Router Class Initialized
INFO - 2019-08-19 16:50:27 --> Output Class Initialized
INFO - 2019-08-19 16:50:27 --> Security Class Initialized
DEBUG - 2019-08-19 16:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:50:27 --> Input Class Initialized
INFO - 2019-08-19 16:50:27 --> Language Class Initialized
INFO - 2019-08-19 16:50:27 --> Loader Class Initialized
INFO - 2019-08-19 16:50:27 --> Helper loaded: url_helper
INFO - 2019-08-19 16:50:27 --> Helper loaded: html_helper
INFO - 2019-08-19 16:50:27 --> Helper loaded: form_helper
INFO - 2019-08-19 16:50:27 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:50:27 --> Helper loaded: date_helper
INFO - 2019-08-19 16:50:27 --> Form Validation Class Initialized
INFO - 2019-08-19 16:50:27 --> Email Class Initialized
DEBUG - 2019-08-19 16:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:50:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:50:27 --> Pagination Class Initialized
INFO - 2019-08-19 16:50:27 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:28 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:28 --> Controller Class Initialized
INFO - 2019-08-19 16:50:28 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:50:28 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_class.php
INFO - 2019-08-19 16:50:28 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:50:28 --> Final output sent to browser
DEBUG - 2019-08-19 16:50:28 --> Total execution time: 0.2160
INFO - 2019-08-19 16:50:53 --> Config Class Initialized
INFO - 2019-08-19 16:50:53 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:50:53 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:50:53 --> Utf8 Class Initialized
INFO - 2019-08-19 16:50:53 --> Config Class Initialized
INFO - 2019-08-19 16:50:53 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:50:53 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:50:53 --> Utf8 Class Initialized
INFO - 2019-08-19 16:50:53 --> URI Class Initialized
INFO - 2019-08-19 16:50:53 --> Router Class Initialized
INFO - 2019-08-19 16:50:53 --> Output Class Initialized
INFO - 2019-08-19 16:50:53 --> Security Class Initialized
DEBUG - 2019-08-19 16:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:50:53 --> Input Class Initialized
INFO - 2019-08-19 16:50:53 --> Language Class Initialized
INFO - 2019-08-19 16:50:54 --> URI Class Initialized
INFO - 2019-08-19 16:50:54 --> Router Class Initialized
INFO - 2019-08-19 16:50:54 --> Output Class Initialized
INFO - 2019-08-19 16:50:54 --> Security Class Initialized
DEBUG - 2019-08-19 16:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:50:54 --> Input Class Initialized
INFO - 2019-08-19 16:50:54 --> Language Class Initialized
INFO - 2019-08-19 16:50:54 --> Loader Class Initialized
INFO - 2019-08-19 16:50:54 --> Helper loaded: url_helper
INFO - 2019-08-19 16:50:54 --> Helper loaded: html_helper
INFO - 2019-08-19 16:50:54 --> Helper loaded: form_helper
INFO - 2019-08-19 16:50:54 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:50:54 --> Helper loaded: date_helper
INFO - 2019-08-19 16:50:54 --> Form Validation Class Initialized
INFO - 2019-08-19 16:50:54 --> Email Class Initialized
INFO - 2019-08-19 16:50:54 --> Loader Class Initialized
DEBUG - 2019-08-19 16:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:50:54 --> Helper loaded: url_helper
INFO - 2019-08-19 16:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:50:54 --> Helper loaded: html_helper
INFO - 2019-08-19 16:50:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:50:54 --> Pagination Class Initialized
INFO - 2019-08-19 16:50:54 --> Helper loaded: form_helper
INFO - 2019-08-19 16:50:54 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:50:54 --> Helper loaded: date_helper
INFO - 2019-08-19 16:50:54 --> Form Validation Class Initialized
INFO - 2019-08-19 16:50:54 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:54 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:54 --> Email Class Initialized
DEBUG - 2019-08-19 16:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:50:54 --> Controller Class Initialized
INFO - 2019-08-19 16:50:54 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:50:54 --> Final output sent to browser
DEBUG - 2019-08-19 16:50:54 --> Total execution time: 0.2830
INFO - 2019-08-19 16:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:50:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:50:54 --> Pagination Class Initialized
INFO - 2019-08-19 16:50:54 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:54 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:54 --> Controller Class Initialized
INFO - 2019-08-19 16:50:54 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:50:54 --> Final output sent to browser
DEBUG - 2019-08-19 16:50:54 --> Total execution time: 0.3490
INFO - 2019-08-19 16:50:54 --> Config Class Initialized
INFO - 2019-08-19 16:50:54 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:50:54 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:50:54 --> Utf8 Class Initialized
INFO - 2019-08-19 16:50:54 --> URI Class Initialized
INFO - 2019-08-19 16:50:54 --> Router Class Initialized
INFO - 2019-08-19 16:50:54 --> Output Class Initialized
INFO - 2019-08-19 16:50:54 --> Security Class Initialized
DEBUG - 2019-08-19 16:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:50:54 --> Input Class Initialized
INFO - 2019-08-19 16:50:54 --> Language Class Initialized
INFO - 2019-08-19 16:50:54 --> Loader Class Initialized
INFO - 2019-08-19 16:50:54 --> Helper loaded: url_helper
INFO - 2019-08-19 16:50:54 --> Helper loaded: html_helper
INFO - 2019-08-19 16:50:54 --> Helper loaded: form_helper
INFO - 2019-08-19 16:50:54 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:50:54 --> Helper loaded: date_helper
INFO - 2019-08-19 16:50:54 --> Form Validation Class Initialized
INFO - 2019-08-19 16:50:54 --> Email Class Initialized
DEBUG - 2019-08-19 16:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:50:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:50:54 --> Pagination Class Initialized
INFO - 2019-08-19 16:50:54 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:54 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:54 --> Controller Class Initialized
INFO - 2019-08-19 16:50:55 --> Final output sent to browser
DEBUG - 2019-08-19 16:50:55 --> Total execution time: 0.2540
INFO - 2019-08-19 16:50:57 --> Config Class Initialized
INFO - 2019-08-19 16:50:57 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:50:57 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:50:57 --> Utf8 Class Initialized
INFO - 2019-08-19 16:50:57 --> URI Class Initialized
INFO - 2019-08-19 16:50:57 --> Router Class Initialized
INFO - 2019-08-19 16:50:57 --> Output Class Initialized
INFO - 2019-08-19 16:50:57 --> Security Class Initialized
DEBUG - 2019-08-19 16:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:50:57 --> Input Class Initialized
INFO - 2019-08-19 16:50:57 --> Language Class Initialized
INFO - 2019-08-19 16:50:57 --> Loader Class Initialized
INFO - 2019-08-19 16:50:57 --> Helper loaded: url_helper
INFO - 2019-08-19 16:50:57 --> Helper loaded: html_helper
INFO - 2019-08-19 16:50:57 --> Helper loaded: form_helper
INFO - 2019-08-19 16:50:57 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:50:57 --> Helper loaded: date_helper
INFO - 2019-08-19 16:50:57 --> Form Validation Class Initialized
INFO - 2019-08-19 16:50:57 --> Email Class Initialized
DEBUG - 2019-08-19 16:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:50:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:50:57 --> Pagination Class Initialized
INFO - 2019-08-19 16:50:57 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:57 --> Database Driver Class Initialized
INFO - 2019-08-19 16:50:57 --> Controller Class Initialized
INFO - 2019-08-19 16:50:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:50:57 --> Final output sent to browser
DEBUG - 2019-08-19 16:50:57 --> Total execution time: 0.2150
INFO - 2019-08-19 16:51:01 --> Config Class Initialized
INFO - 2019-08-19 16:51:01 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:51:01 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:51:01 --> Utf8 Class Initialized
INFO - 2019-08-19 16:51:01 --> URI Class Initialized
INFO - 2019-08-19 16:51:01 --> Router Class Initialized
INFO - 2019-08-19 16:51:01 --> Output Class Initialized
INFO - 2019-08-19 16:51:01 --> Security Class Initialized
DEBUG - 2019-08-19 16:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:51:01 --> Input Class Initialized
INFO - 2019-08-19 16:51:01 --> Language Class Initialized
INFO - 2019-08-19 16:51:01 --> Loader Class Initialized
INFO - 2019-08-19 16:51:01 --> Helper loaded: url_helper
INFO - 2019-08-19 16:51:01 --> Helper loaded: html_helper
INFO - 2019-08-19 16:51:01 --> Helper loaded: form_helper
INFO - 2019-08-19 16:51:01 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:51:01 --> Helper loaded: date_helper
INFO - 2019-08-19 16:51:01 --> Form Validation Class Initialized
INFO - 2019-08-19 16:51:01 --> Email Class Initialized
DEBUG - 2019-08-19 16:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:51:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:51:02 --> Pagination Class Initialized
INFO - 2019-08-19 16:51:02 --> Database Driver Class Initialized
INFO - 2019-08-19 16:51:02 --> Database Driver Class Initialized
INFO - 2019-08-19 16:51:02 --> Controller Class Initialized
INFO - 2019-08-19 16:51:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:51:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_salescategory.php
INFO - 2019-08-19 16:51:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:51:02 --> Final output sent to browser
DEBUG - 2019-08-19 16:51:02 --> Total execution time: 0.2260
INFO - 2019-08-19 16:51:52 --> Config Class Initialized
INFO - 2019-08-19 16:51:52 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:51:52 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:51:52 --> Utf8 Class Initialized
INFO - 2019-08-19 16:51:52 --> URI Class Initialized
INFO - 2019-08-19 16:51:52 --> Router Class Initialized
INFO - 2019-08-19 16:51:52 --> Output Class Initialized
INFO - 2019-08-19 16:51:52 --> Security Class Initialized
DEBUG - 2019-08-19 16:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:51:52 --> Input Class Initialized
INFO - 2019-08-19 16:51:52 --> Language Class Initialized
INFO - 2019-08-19 16:51:52 --> Loader Class Initialized
INFO - 2019-08-19 16:51:52 --> Helper loaded: url_helper
INFO - 2019-08-19 16:51:52 --> Helper loaded: html_helper
INFO - 2019-08-19 16:51:52 --> Helper loaded: form_helper
INFO - 2019-08-19 16:51:52 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:51:52 --> Helper loaded: date_helper
INFO - 2019-08-19 16:51:52 --> Config Class Initialized
INFO - 2019-08-19 16:51:52 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:51:52 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:51:52 --> Utf8 Class Initialized
INFO - 2019-08-19 16:51:52 --> URI Class Initialized
INFO - 2019-08-19 16:51:52 --> Router Class Initialized
INFO - 2019-08-19 16:51:52 --> Output Class Initialized
INFO - 2019-08-19 16:51:52 --> Security Class Initialized
DEBUG - 2019-08-19 16:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:51:52 --> Input Class Initialized
INFO - 2019-08-19 16:51:52 --> Language Class Initialized
INFO - 2019-08-19 16:51:52 --> Loader Class Initialized
INFO - 2019-08-19 16:51:52 --> Helper loaded: url_helper
INFO - 2019-08-19 16:51:52 --> Form Validation Class Initialized
INFO - 2019-08-19 16:51:52 --> Email Class Initialized
DEBUG - 2019-08-19 16:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:51:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:51:52 --> Pagination Class Initialized
INFO - 2019-08-19 16:51:52 --> Database Driver Class Initialized
INFO - 2019-08-19 16:51:52 --> Helper loaded: html_helper
INFO - 2019-08-19 16:51:52 --> Helper loaded: form_helper
INFO - 2019-08-19 16:51:52 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:51:52 --> Helper loaded: date_helper
INFO - 2019-08-19 16:51:52 --> Form Validation Class Initialized
INFO - 2019-08-19 16:51:52 --> Email Class Initialized
DEBUG - 2019-08-19 16:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:51:52 --> Database Driver Class Initialized
INFO - 2019-08-19 16:51:52 --> Controller Class Initialized
INFO - 2019-08-19 16:51:52 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:51:52 --> Final output sent to browser
DEBUG - 2019-08-19 16:51:52 --> Total execution time: 0.2808
INFO - 2019-08-19 16:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:51:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:51:52 --> Pagination Class Initialized
INFO - 2019-08-19 16:51:52 --> Database Driver Class Initialized
INFO - 2019-08-19 16:51:52 --> Database Driver Class Initialized
INFO - 2019-08-19 16:51:52 --> Controller Class Initialized
INFO - 2019-08-19 16:51:52 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:51:52 --> Final output sent to browser
DEBUG - 2019-08-19 16:51:52 --> Total execution time: 0.3038
INFO - 2019-08-19 16:51:53 --> Config Class Initialized
INFO - 2019-08-19 16:51:53 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:51:53 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:51:53 --> Utf8 Class Initialized
INFO - 2019-08-19 16:51:53 --> URI Class Initialized
INFO - 2019-08-19 16:51:53 --> Router Class Initialized
INFO - 2019-08-19 16:51:53 --> Output Class Initialized
INFO - 2019-08-19 16:51:53 --> Security Class Initialized
DEBUG - 2019-08-19 16:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:51:53 --> Input Class Initialized
INFO - 2019-08-19 16:51:53 --> Language Class Initialized
INFO - 2019-08-19 16:51:53 --> Loader Class Initialized
INFO - 2019-08-19 16:51:53 --> Helper loaded: url_helper
INFO - 2019-08-19 16:51:53 --> Helper loaded: html_helper
INFO - 2019-08-19 16:51:53 --> Helper loaded: form_helper
INFO - 2019-08-19 16:51:53 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:51:53 --> Helper loaded: date_helper
INFO - 2019-08-19 16:51:53 --> Form Validation Class Initialized
INFO - 2019-08-19 16:51:53 --> Email Class Initialized
DEBUG - 2019-08-19 16:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:51:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:51:53 --> Pagination Class Initialized
INFO - 2019-08-19 16:51:53 --> Database Driver Class Initialized
INFO - 2019-08-19 16:51:53 --> Database Driver Class Initialized
INFO - 2019-08-19 16:51:53 --> Controller Class Initialized
INFO - 2019-08-19 16:51:53 --> Final output sent to browser
DEBUG - 2019-08-19 16:51:53 --> Total execution time: 0.3100
INFO - 2019-08-19 16:52:12 --> Config Class Initialized
INFO - 2019-08-19 16:52:12 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:52:12 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:52:12 --> Utf8 Class Initialized
INFO - 2019-08-19 16:52:12 --> URI Class Initialized
INFO - 2019-08-19 16:52:12 --> Router Class Initialized
INFO - 2019-08-19 16:52:12 --> Output Class Initialized
INFO - 2019-08-19 16:52:12 --> Security Class Initialized
DEBUG - 2019-08-19 16:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:52:12 --> Input Class Initialized
INFO - 2019-08-19 16:52:12 --> Language Class Initialized
INFO - 2019-08-19 16:52:12 --> Loader Class Initialized
INFO - 2019-08-19 16:52:12 --> Helper loaded: url_helper
INFO - 2019-08-19 16:52:12 --> Helper loaded: html_helper
INFO - 2019-08-19 16:52:12 --> Helper loaded: form_helper
INFO - 2019-08-19 16:52:12 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:52:12 --> Helper loaded: date_helper
INFO - 2019-08-19 16:52:12 --> Form Validation Class Initialized
INFO - 2019-08-19 16:52:12 --> Email Class Initialized
DEBUG - 2019-08-19 16:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:52:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:52:12 --> Pagination Class Initialized
INFO - 2019-08-19 16:52:12 --> Database Driver Class Initialized
INFO - 2019-08-19 16:52:12 --> Database Driver Class Initialized
INFO - 2019-08-19 16:52:12 --> Controller Class Initialized
INFO - 2019-08-19 16:52:12 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:52:12 --> Final output sent to browser
DEBUG - 2019-08-19 16:52:12 --> Total execution time: 0.2320
INFO - 2019-08-19 16:52:12 --> Config Class Initialized
INFO - 2019-08-19 16:52:12 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:52:12 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:52:12 --> Utf8 Class Initialized
INFO - 2019-08-19 16:52:12 --> URI Class Initialized
INFO - 2019-08-19 16:52:12 --> Router Class Initialized
INFO - 2019-08-19 16:52:12 --> Output Class Initialized
INFO - 2019-08-19 16:52:12 --> Security Class Initialized
DEBUG - 2019-08-19 16:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:52:12 --> Input Class Initialized
INFO - 2019-08-19 16:52:12 --> Language Class Initialized
INFO - 2019-08-19 16:52:12 --> Loader Class Initialized
INFO - 2019-08-19 16:52:12 --> Helper loaded: url_helper
INFO - 2019-08-19 16:52:12 --> Helper loaded: html_helper
INFO - 2019-08-19 16:52:12 --> Helper loaded: form_helper
INFO - 2019-08-19 16:52:12 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:52:12 --> Helper loaded: date_helper
INFO - 2019-08-19 16:52:12 --> Form Validation Class Initialized
INFO - 2019-08-19 16:52:12 --> Email Class Initialized
DEBUG - 2019-08-19 16:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:52:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:52:12 --> Pagination Class Initialized
INFO - 2019-08-19 16:52:12 --> Database Driver Class Initialized
INFO - 2019-08-19 16:52:12 --> Database Driver Class Initialized
INFO - 2019-08-19 16:52:12 --> Controller Class Initialized
INFO - 2019-08-19 16:52:12 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:52:12 --> Final output sent to browser
DEBUG - 2019-08-19 16:52:12 --> Total execution time: 0.1930
INFO - 2019-08-19 16:52:17 --> Config Class Initialized
INFO - 2019-08-19 16:52:17 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:52:17 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:52:17 --> Utf8 Class Initialized
INFO - 2019-08-19 16:52:17 --> URI Class Initialized
INFO - 2019-08-19 16:52:17 --> Router Class Initialized
INFO - 2019-08-19 16:52:17 --> Output Class Initialized
INFO - 2019-08-19 16:52:17 --> Security Class Initialized
DEBUG - 2019-08-19 16:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:52:17 --> Input Class Initialized
INFO - 2019-08-19 16:52:17 --> Language Class Initialized
INFO - 2019-08-19 16:52:17 --> Loader Class Initialized
INFO - 2019-08-19 16:52:17 --> Helper loaded: url_helper
INFO - 2019-08-19 16:52:17 --> Helper loaded: html_helper
INFO - 2019-08-19 16:52:17 --> Helper loaded: form_helper
INFO - 2019-08-19 16:52:17 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:52:17 --> Helper loaded: date_helper
INFO - 2019-08-19 16:52:17 --> Form Validation Class Initialized
INFO - 2019-08-19 16:52:17 --> Email Class Initialized
DEBUG - 2019-08-19 16:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:52:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:52:17 --> Pagination Class Initialized
INFO - 2019-08-19 16:52:17 --> Database Driver Class Initialized
INFO - 2019-08-19 16:52:17 --> Database Driver Class Initialized
INFO - 2019-08-19 16:52:17 --> Controller Class Initialized
INFO - 2019-08-19 16:52:17 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:52:17 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_type.php
INFO - 2019-08-19 16:52:17 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:52:17 --> Final output sent to browser
DEBUG - 2019-08-19 16:52:18 --> Total execution time: 0.1930
INFO - 2019-08-19 16:53:00 --> Config Class Initialized
INFO - 2019-08-19 16:53:00 --> Hooks Class Initialized
INFO - 2019-08-19 16:53:00 --> Config Class Initialized
INFO - 2019-08-19 16:53:00 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:53:00 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:53:00 --> Utf8 Class Initialized
DEBUG - 2019-08-19 16:53:00 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:53:00 --> Utf8 Class Initialized
INFO - 2019-08-19 16:53:00 --> URI Class Initialized
INFO - 2019-08-19 16:53:00 --> Router Class Initialized
INFO - 2019-08-19 16:53:00 --> Output Class Initialized
INFO - 2019-08-19 16:53:00 --> Security Class Initialized
DEBUG - 2019-08-19 16:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:53:00 --> Input Class Initialized
INFO - 2019-08-19 16:53:00 --> Language Class Initialized
INFO - 2019-08-19 16:53:00 --> URI Class Initialized
INFO - 2019-08-19 16:53:00 --> Router Class Initialized
INFO - 2019-08-19 16:53:00 --> Output Class Initialized
INFO - 2019-08-19 16:53:00 --> Security Class Initialized
DEBUG - 2019-08-19 16:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:53:00 --> Input Class Initialized
INFO - 2019-08-19 16:53:00 --> Language Class Initialized
INFO - 2019-08-19 16:53:00 --> Loader Class Initialized
INFO - 2019-08-19 16:53:00 --> Helper loaded: url_helper
INFO - 2019-08-19 16:53:00 --> Helper loaded: html_helper
INFO - 2019-08-19 16:53:00 --> Helper loaded: form_helper
INFO - 2019-08-19 16:53:00 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:53:00 --> Helper loaded: date_helper
INFO - 2019-08-19 16:53:00 --> Loader Class Initialized
INFO - 2019-08-19 16:53:00 --> Helper loaded: url_helper
INFO - 2019-08-19 16:53:00 --> Helper loaded: html_helper
INFO - 2019-08-19 16:53:00 --> Helper loaded: form_helper
INFO - 2019-08-19 16:53:00 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:53:00 --> Helper loaded: date_helper
INFO - 2019-08-19 16:53:00 --> Form Validation Class Initialized
INFO - 2019-08-19 16:53:00 --> Form Validation Class Initialized
INFO - 2019-08-19 16:53:00 --> Email Class Initialized
DEBUG - 2019-08-19 16:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:53:00 --> Pagination Class Initialized
INFO - 2019-08-19 16:53:00 --> Email Class Initialized
DEBUG - 2019-08-19 16:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:53:00 --> Database Driver Class Initialized
INFO - 2019-08-19 16:53:00 --> Database Driver Class Initialized
INFO - 2019-08-19 16:53:00 --> Controller Class Initialized
INFO - 2019-08-19 16:53:00 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:53:00 --> Final output sent to browser
DEBUG - 2019-08-19 16:53:00 --> Total execution time: 0.3180
INFO - 2019-08-19 16:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:53:00 --> Pagination Class Initialized
INFO - 2019-08-19 16:53:00 --> Database Driver Class Initialized
INFO - 2019-08-19 16:53:00 --> Database Driver Class Initialized
INFO - 2019-08-19 16:53:00 --> Controller Class Initialized
INFO - 2019-08-19 16:53:00 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:53:00 --> Final output sent to browser
DEBUG - 2019-08-19 16:53:00 --> Total execution time: 0.3960
INFO - 2019-08-19 16:53:01 --> Config Class Initialized
INFO - 2019-08-19 16:53:01 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:53:01 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:53:01 --> Utf8 Class Initialized
INFO - 2019-08-19 16:53:01 --> URI Class Initialized
INFO - 2019-08-19 16:53:01 --> Router Class Initialized
INFO - 2019-08-19 16:53:01 --> Output Class Initialized
INFO - 2019-08-19 16:53:01 --> Security Class Initialized
DEBUG - 2019-08-19 16:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:53:01 --> Input Class Initialized
INFO - 2019-08-19 16:53:01 --> Language Class Initialized
INFO - 2019-08-19 16:53:01 --> Loader Class Initialized
INFO - 2019-08-19 16:53:01 --> Helper loaded: url_helper
INFO - 2019-08-19 16:53:01 --> Helper loaded: html_helper
INFO - 2019-08-19 16:53:01 --> Helper loaded: form_helper
INFO - 2019-08-19 16:53:01 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:53:01 --> Helper loaded: date_helper
INFO - 2019-08-19 16:53:01 --> Form Validation Class Initialized
INFO - 2019-08-19 16:53:01 --> Email Class Initialized
DEBUG - 2019-08-19 16:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:53:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:53:01 --> Pagination Class Initialized
INFO - 2019-08-19 16:53:01 --> Database Driver Class Initialized
INFO - 2019-08-19 16:53:01 --> Database Driver Class Initialized
INFO - 2019-08-19 16:53:01 --> Controller Class Initialized
INFO - 2019-08-19 16:53:01 --> Final output sent to browser
DEBUG - 2019-08-19 16:53:01 --> Total execution time: 0.2490
INFO - 2019-08-19 16:53:13 --> Config Class Initialized
INFO - 2019-08-19 16:53:13 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:53:13 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:53:13 --> Utf8 Class Initialized
INFO - 2019-08-19 16:53:13 --> URI Class Initialized
INFO - 2019-08-19 16:53:13 --> Router Class Initialized
INFO - 2019-08-19 16:53:13 --> Output Class Initialized
INFO - 2019-08-19 16:53:13 --> Security Class Initialized
DEBUG - 2019-08-19 16:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:53:13 --> Input Class Initialized
INFO - 2019-08-19 16:53:13 --> Language Class Initialized
INFO - 2019-08-19 16:53:13 --> Loader Class Initialized
INFO - 2019-08-19 16:53:13 --> Helper loaded: url_helper
INFO - 2019-08-19 16:53:13 --> Helper loaded: html_helper
INFO - 2019-08-19 16:53:13 --> Helper loaded: form_helper
INFO - 2019-08-19 16:53:13 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:53:13 --> Helper loaded: date_helper
INFO - 2019-08-19 16:53:13 --> Form Validation Class Initialized
INFO - 2019-08-19 16:53:13 --> Email Class Initialized
DEBUG - 2019-08-19 16:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:53:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:53:13 --> Pagination Class Initialized
INFO - 2019-08-19 16:53:13 --> Database Driver Class Initialized
INFO - 2019-08-19 16:53:13 --> Database Driver Class Initialized
INFO - 2019-08-19 16:53:13 --> Controller Class Initialized
INFO - 2019-08-19 16:53:13 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:53:13 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_sale.php
INFO - 2019-08-19 16:53:13 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:53:13 --> Final output sent to browser
DEBUG - 2019-08-19 16:53:13 --> Total execution time: 0.2490
INFO - 2019-08-19 16:53:42 --> Config Class Initialized
INFO - 2019-08-19 16:53:42 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:53:42 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:53:42 --> Utf8 Class Initialized
INFO - 2019-08-19 16:53:42 --> URI Class Initialized
INFO - 2019-08-19 16:53:42 --> Router Class Initialized
INFO - 2019-08-19 16:53:42 --> Output Class Initialized
INFO - 2019-08-19 16:53:42 --> Security Class Initialized
DEBUG - 2019-08-19 16:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:53:42 --> Input Class Initialized
INFO - 2019-08-19 16:53:42 --> Language Class Initialized
INFO - 2019-08-19 16:53:42 --> Loader Class Initialized
INFO - 2019-08-19 16:53:42 --> Helper loaded: url_helper
INFO - 2019-08-19 16:53:42 --> Helper loaded: html_helper
INFO - 2019-08-19 16:53:42 --> Helper loaded: form_helper
INFO - 2019-08-19 16:53:42 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:53:42 --> Helper loaded: date_helper
INFO - 2019-08-19 16:53:42 --> Form Validation Class Initialized
INFO - 2019-08-19 16:53:42 --> Email Class Initialized
DEBUG - 2019-08-19 16:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:53:42 --> Config Class Initialized
INFO - 2019-08-19 16:53:42 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:53:42 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:53:42 --> Utf8 Class Initialized
INFO - 2019-08-19 16:53:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:53:42 --> Pagination Class Initialized
INFO - 2019-08-19 16:53:42 --> URI Class Initialized
INFO - 2019-08-19 16:53:42 --> Router Class Initialized
INFO - 2019-08-19 16:53:42 --> Output Class Initialized
INFO - 2019-08-19 16:53:42 --> Security Class Initialized
DEBUG - 2019-08-19 16:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:53:42 --> Input Class Initialized
INFO - 2019-08-19 16:53:42 --> Language Class Initialized
INFO - 2019-08-19 16:53:42 --> Database Driver Class Initialized
INFO - 2019-08-19 16:53:42 --> Database Driver Class Initialized
INFO - 2019-08-19 16:53:42 --> Loader Class Initialized
INFO - 2019-08-19 16:53:42 --> Helper loaded: url_helper
INFO - 2019-08-19 16:53:42 --> Helper loaded: html_helper
INFO - 2019-08-19 16:53:42 --> Helper loaded: form_helper
INFO - 2019-08-19 16:53:42 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:53:42 --> Helper loaded: date_helper
INFO - 2019-08-19 16:53:42 --> Form Validation Class Initialized
INFO - 2019-08-19 16:53:42 --> Email Class Initialized
DEBUG - 2019-08-19 16:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:53:42 --> Controller Class Initialized
INFO - 2019-08-19 16:53:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:53:42 --> Final output sent to browser
DEBUG - 2019-08-19 16:53:42 --> Total execution time: 0.2990
INFO - 2019-08-19 16:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:53:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:53:42 --> Pagination Class Initialized
INFO - 2019-08-19 16:53:42 --> Database Driver Class Initialized
INFO - 2019-08-19 16:53:42 --> Database Driver Class Initialized
INFO - 2019-08-19 16:53:42 --> Controller Class Initialized
INFO - 2019-08-19 16:53:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:53:42 --> Final output sent to browser
DEBUG - 2019-08-19 16:53:42 --> Total execution time: 0.2752
INFO - 2019-08-19 16:53:43 --> Config Class Initialized
INFO - 2019-08-19 16:53:43 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:53:43 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:53:43 --> Utf8 Class Initialized
INFO - 2019-08-19 16:53:43 --> URI Class Initialized
INFO - 2019-08-19 16:53:43 --> Router Class Initialized
INFO - 2019-08-19 16:53:43 --> Output Class Initialized
INFO - 2019-08-19 16:53:43 --> Security Class Initialized
DEBUG - 2019-08-19 16:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:53:43 --> Input Class Initialized
INFO - 2019-08-19 16:53:43 --> Language Class Initialized
INFO - 2019-08-19 16:53:43 --> Loader Class Initialized
INFO - 2019-08-19 16:53:43 --> Helper loaded: url_helper
INFO - 2019-08-19 16:53:43 --> Helper loaded: html_helper
INFO - 2019-08-19 16:53:43 --> Helper loaded: form_helper
INFO - 2019-08-19 16:53:43 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:53:43 --> Helper loaded: date_helper
INFO - 2019-08-19 16:53:43 --> Form Validation Class Initialized
INFO - 2019-08-19 16:53:43 --> Email Class Initialized
DEBUG - 2019-08-19 16:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:53:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:53:43 --> Pagination Class Initialized
INFO - 2019-08-19 16:53:43 --> Database Driver Class Initialized
INFO - 2019-08-19 16:53:43 --> Database Driver Class Initialized
INFO - 2019-08-19 16:53:43 --> Controller Class Initialized
INFO - 2019-08-19 16:53:43 --> Final output sent to browser
DEBUG - 2019-08-19 16:53:43 --> Total execution time: 0.2450
INFO - 2019-08-19 16:53:51 --> Config Class Initialized
INFO - 2019-08-19 16:53:51 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:53:51 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:53:51 --> Utf8 Class Initialized
INFO - 2019-08-19 16:53:51 --> URI Class Initialized
INFO - 2019-08-19 16:53:51 --> Router Class Initialized
INFO - 2019-08-19 16:53:51 --> Output Class Initialized
INFO - 2019-08-19 16:53:51 --> Security Class Initialized
DEBUG - 2019-08-19 16:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:53:51 --> Input Class Initialized
INFO - 2019-08-19 16:53:51 --> Language Class Initialized
INFO - 2019-08-19 16:53:51 --> Loader Class Initialized
INFO - 2019-08-19 16:53:51 --> Helper loaded: url_helper
INFO - 2019-08-19 16:53:51 --> Helper loaded: html_helper
INFO - 2019-08-19 16:53:51 --> Helper loaded: form_helper
INFO - 2019-08-19 16:53:51 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:53:51 --> Helper loaded: date_helper
INFO - 2019-08-19 16:53:51 --> Form Validation Class Initialized
INFO - 2019-08-19 16:53:51 --> Email Class Initialized
DEBUG - 2019-08-19 16:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:53:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:53:51 --> Pagination Class Initialized
INFO - 2019-08-19 16:53:51 --> Database Driver Class Initialized
INFO - 2019-08-19 16:53:51 --> Database Driver Class Initialized
INFO - 2019-08-19 16:53:51 --> Controller Class Initialized
INFO - 2019-08-19 16:53:51 --> Final output sent to browser
DEBUG - 2019-08-19 16:53:51 --> Total execution time: 0.2460
INFO - 2019-08-19 16:54:40 --> Config Class Initialized
INFO - 2019-08-19 16:54:40 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:54:40 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:54:40 --> Utf8 Class Initialized
INFO - 2019-08-19 16:54:40 --> URI Class Initialized
INFO - 2019-08-19 16:54:40 --> Router Class Initialized
INFO - 2019-08-19 16:54:40 --> Output Class Initialized
INFO - 2019-08-19 16:54:40 --> Security Class Initialized
DEBUG - 2019-08-19 16:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:54:40 --> Input Class Initialized
INFO - 2019-08-19 16:54:40 --> Language Class Initialized
INFO - 2019-08-19 16:54:40 --> Loader Class Initialized
INFO - 2019-08-19 16:54:40 --> Helper loaded: url_helper
INFO - 2019-08-19 16:54:40 --> Helper loaded: html_helper
INFO - 2019-08-19 16:54:40 --> Helper loaded: form_helper
INFO - 2019-08-19 16:54:40 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:54:40 --> Helper loaded: date_helper
INFO - 2019-08-19 16:54:40 --> Form Validation Class Initialized
INFO - 2019-08-19 16:54:40 --> Email Class Initialized
DEBUG - 2019-08-19 16:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:54:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:54:40 --> Pagination Class Initialized
INFO - 2019-08-19 16:54:40 --> Database Driver Class Initialized
INFO - 2019-08-19 16:54:40 --> Database Driver Class Initialized
INFO - 2019-08-19 16:54:40 --> Controller Class Initialized
INFO - 2019-08-19 16:54:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 16:54:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:54:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_sale.php
INFO - 2019-08-19 16:54:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:54:40 --> Final output sent to browser
DEBUG - 2019-08-19 16:54:40 --> Total execution time: 0.2310
INFO - 2019-08-19 16:55:46 --> Config Class Initialized
INFO - 2019-08-19 16:55:46 --> Hooks Class Initialized
INFO - 2019-08-19 16:55:46 --> Config Class Initialized
INFO - 2019-08-19 16:55:46 --> Hooks Class Initialized
INFO - 2019-08-19 16:55:46 --> Config Class Initialized
INFO - 2019-08-19 16:55:46 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:55:46 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:55:46 --> Utf8 Class Initialized
DEBUG - 2019-08-19 16:55:46 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:55:46 --> Utf8 Class Initialized
INFO - 2019-08-19 16:55:46 --> URI Class Initialized
INFO - 2019-08-19 16:55:46 --> URI Class Initialized
INFO - 2019-08-19 16:55:46 --> Router Class Initialized
INFO - 2019-08-19 16:55:46 --> Router Class Initialized
INFO - 2019-08-19 16:55:46 --> Output Class Initialized
INFO - 2019-08-19 16:55:46 --> Output Class Initialized
INFO - 2019-08-19 16:55:46 --> Security Class Initialized
DEBUG - 2019-08-19 16:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:55:46 --> Input Class Initialized
INFO - 2019-08-19 16:55:46 --> Security Class Initialized
INFO - 2019-08-19 16:55:46 --> Language Class Initialized
DEBUG - 2019-08-19 16:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:55:46 --> Input Class Initialized
INFO - 2019-08-19 16:55:46 --> Language Class Initialized
DEBUG - 2019-08-19 16:55:46 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:55:46 --> Utf8 Class Initialized
INFO - 2019-08-19 16:55:46 --> URI Class Initialized
INFO - 2019-08-19 16:55:46 --> Loader Class Initialized
INFO - 2019-08-19 16:55:46 --> Helper loaded: url_helper
INFO - 2019-08-19 16:55:46 --> Helper loaded: html_helper
INFO - 2019-08-19 16:55:46 --> Router Class Initialized
INFO - 2019-08-19 16:55:46 --> Helper loaded: form_helper
INFO - 2019-08-19 16:55:46 --> Output Class Initialized
INFO - 2019-08-19 16:55:46 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:55:46 --> Helper loaded: date_helper
INFO - 2019-08-19 16:55:46 --> Security Class Initialized
DEBUG - 2019-08-19 16:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:55:46 --> Input Class Initialized
INFO - 2019-08-19 16:55:46 --> Language Class Initialized
INFO - 2019-08-19 16:55:46 --> Form Validation Class Initialized
INFO - 2019-08-19 16:55:46 --> Loader Class Initialized
INFO - 2019-08-19 16:55:46 --> Helper loaded: url_helper
INFO - 2019-08-19 16:55:46 --> Email Class Initialized
INFO - 2019-08-19 16:55:46 --> Helper loaded: html_helper
INFO - 2019-08-19 16:55:46 --> Helper loaded: form_helper
DEBUG - 2019-08-19 16:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:55:46 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:55:46 --> Helper loaded: date_helper
INFO - 2019-08-19 16:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:55:46 --> Form Validation Class Initialized
INFO - 2019-08-19 16:55:46 --> Pagination Class Initialized
INFO - 2019-08-19 16:55:46 --> Email Class Initialized
INFO - 2019-08-19 16:55:46 --> Loader Class Initialized
INFO - 2019-08-19 16:55:46 --> Database Driver Class Initialized
INFO - 2019-08-19 16:55:46 --> Database Driver Class Initialized
INFO - 2019-08-19 16:55:46 --> Helper loaded: url_helper
INFO - 2019-08-19 16:55:46 --> Helper loaded: html_helper
INFO - 2019-08-19 16:55:46 --> Helper loaded: form_helper
INFO - 2019-08-19 16:55:46 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:55:46 --> Helper loaded: date_helper
DEBUG - 2019-08-19 16:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:55:46 --> Form Validation Class Initialized
INFO - 2019-08-19 16:55:46 --> Email Class Initialized
DEBUG - 2019-08-19 16:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:55:46 --> Controller Class Initialized
INFO - 2019-08-19 16:55:46 --> Final output sent to browser
DEBUG - 2019-08-19 16:55:46 --> Total execution time: 0.2650
INFO - 2019-08-19 16:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:55:46 --> Pagination Class Initialized
INFO - 2019-08-19 16:55:46 --> Database Driver Class Initialized
INFO - 2019-08-19 16:55:46 --> Database Driver Class Initialized
INFO - 2019-08-19 16:55:46 --> Controller Class Initialized
INFO - 2019-08-19 16:55:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:55:46 --> Final output sent to browser
DEBUG - 2019-08-19 16:55:46 --> Total execution time: 0.3860
INFO - 2019-08-19 16:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:55:46 --> Pagination Class Initialized
INFO - 2019-08-19 16:55:46 --> Database Driver Class Initialized
INFO - 2019-08-19 16:55:46 --> Database Driver Class Initialized
INFO - 2019-08-19 16:55:46 --> Controller Class Initialized
INFO - 2019-08-19 16:55:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:55:46 --> Final output sent to browser
DEBUG - 2019-08-19 16:55:46 --> Total execution time: 0.5040
INFO - 2019-08-19 16:55:49 --> Config Class Initialized
INFO - 2019-08-19 16:55:49 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:55:49 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:55:49 --> Utf8 Class Initialized
INFO - 2019-08-19 16:55:49 --> URI Class Initialized
INFO - 2019-08-19 16:55:49 --> Router Class Initialized
INFO - 2019-08-19 16:55:49 --> Output Class Initialized
INFO - 2019-08-19 16:55:49 --> Security Class Initialized
DEBUG - 2019-08-19 16:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:55:49 --> Input Class Initialized
INFO - 2019-08-19 16:55:49 --> Language Class Initialized
INFO - 2019-08-19 16:55:49 --> Loader Class Initialized
INFO - 2019-08-19 16:55:49 --> Helper loaded: url_helper
INFO - 2019-08-19 16:55:49 --> Helper loaded: html_helper
INFO - 2019-08-19 16:55:49 --> Helper loaded: form_helper
INFO - 2019-08-19 16:55:49 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:55:49 --> Helper loaded: date_helper
INFO - 2019-08-19 16:55:49 --> Form Validation Class Initialized
INFO - 2019-08-19 16:55:49 --> Email Class Initialized
DEBUG - 2019-08-19 16:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:55:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:55:49 --> Pagination Class Initialized
INFO - 2019-08-19 16:55:49 --> Database Driver Class Initialized
INFO - 2019-08-19 16:55:49 --> Database Driver Class Initialized
INFO - 2019-08-19 16:55:49 --> Controller Class Initialized
INFO - 2019-08-19 16:55:49 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:55:49 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_sale.php
INFO - 2019-08-19 16:55:49 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:55:49 --> Final output sent to browser
DEBUG - 2019-08-19 16:55:49 --> Total execution time: 0.2780
INFO - 2019-08-19 16:55:51 --> Config Class Initialized
INFO - 2019-08-19 16:55:51 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:55:51 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:55:51 --> Utf8 Class Initialized
INFO - 2019-08-19 16:55:51 --> URI Class Initialized
INFO - 2019-08-19 16:55:51 --> Router Class Initialized
INFO - 2019-08-19 16:55:51 --> Output Class Initialized
INFO - 2019-08-19 16:55:51 --> Security Class Initialized
DEBUG - 2019-08-19 16:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:55:51 --> Input Class Initialized
INFO - 2019-08-19 16:55:51 --> Language Class Initialized
INFO - 2019-08-19 16:55:51 --> Loader Class Initialized
INFO - 2019-08-19 16:55:51 --> Helper loaded: url_helper
INFO - 2019-08-19 16:55:51 --> Helper loaded: html_helper
INFO - 2019-08-19 16:55:51 --> Helper loaded: form_helper
INFO - 2019-08-19 16:55:51 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:55:51 --> Helper loaded: date_helper
INFO - 2019-08-19 16:55:51 --> Form Validation Class Initialized
INFO - 2019-08-19 16:55:51 --> Email Class Initialized
DEBUG - 2019-08-19 16:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:55:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:55:51 --> Pagination Class Initialized
INFO - 2019-08-19 16:55:51 --> Database Driver Class Initialized
INFO - 2019-08-19 16:55:51 --> Database Driver Class Initialized
INFO - 2019-08-19 16:55:51 --> Controller Class Initialized
INFO - 2019-08-19 16:55:51 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:55:51 --> Final output sent to browser
DEBUG - 2019-08-19 16:55:51 --> Total execution time: 0.2420
INFO - 2019-08-19 16:55:51 --> Config Class Initialized
INFO - 2019-08-19 16:55:51 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:55:51 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:55:51 --> Utf8 Class Initialized
INFO - 2019-08-19 16:55:51 --> URI Class Initialized
INFO - 2019-08-19 16:55:52 --> Router Class Initialized
INFO - 2019-08-19 16:55:52 --> Output Class Initialized
INFO - 2019-08-19 16:55:52 --> Security Class Initialized
DEBUG - 2019-08-19 16:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:55:52 --> Input Class Initialized
INFO - 2019-08-19 16:55:52 --> Language Class Initialized
INFO - 2019-08-19 16:55:52 --> Loader Class Initialized
INFO - 2019-08-19 16:55:52 --> Helper loaded: url_helper
INFO - 2019-08-19 16:55:52 --> Helper loaded: html_helper
INFO - 2019-08-19 16:55:52 --> Helper loaded: form_helper
INFO - 2019-08-19 16:55:52 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:55:52 --> Helper loaded: date_helper
INFO - 2019-08-19 16:55:52 --> Form Validation Class Initialized
INFO - 2019-08-19 16:55:52 --> Email Class Initialized
DEBUG - 2019-08-19 16:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:55:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:55:52 --> Pagination Class Initialized
INFO - 2019-08-19 16:55:52 --> Database Driver Class Initialized
INFO - 2019-08-19 16:55:52 --> Database Driver Class Initialized
INFO - 2019-08-19 16:55:52 --> Controller Class Initialized
INFO - 2019-08-19 16:55:52 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:55:52 --> Final output sent to browser
DEBUG - 2019-08-19 16:55:52 --> Total execution time: 0.2270
INFO - 2019-08-19 16:56:13 --> Config Class Initialized
INFO - 2019-08-19 16:56:13 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:56:13 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:56:13 --> Utf8 Class Initialized
INFO - 2019-08-19 16:56:13 --> URI Class Initialized
INFO - 2019-08-19 16:56:13 --> Router Class Initialized
INFO - 2019-08-19 16:56:13 --> Output Class Initialized
INFO - 2019-08-19 16:56:13 --> Security Class Initialized
DEBUG - 2019-08-19 16:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:56:13 --> Input Class Initialized
INFO - 2019-08-19 16:56:13 --> Language Class Initialized
INFO - 2019-08-19 16:56:13 --> Loader Class Initialized
INFO - 2019-08-19 16:56:13 --> Helper loaded: url_helper
INFO - 2019-08-19 16:56:13 --> Helper loaded: html_helper
INFO - 2019-08-19 16:56:13 --> Helper loaded: form_helper
INFO - 2019-08-19 16:56:13 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:56:13 --> Helper loaded: date_helper
INFO - 2019-08-19 16:56:13 --> Form Validation Class Initialized
INFO - 2019-08-19 16:56:13 --> Email Class Initialized
DEBUG - 2019-08-19 16:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:56:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:56:13 --> Pagination Class Initialized
INFO - 2019-08-19 16:56:13 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:13 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:13 --> Config Class Initialized
INFO - 2019-08-19 16:56:13 --> Hooks Class Initialized
INFO - 2019-08-19 16:56:13 --> Controller Class Initialized
DEBUG - 2019-08-19 16:56:13 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:56:13 --> Utf8 Class Initialized
INFO - 2019-08-19 16:56:13 --> URI Class Initialized
INFO - 2019-08-19 16:56:13 --> Router Class Initialized
INFO - 2019-08-19 16:56:13 --> Output Class Initialized
INFO - 2019-08-19 16:56:13 --> Security Class Initialized
DEBUG - 2019-08-19 16:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:56:13 --> Input Class Initialized
INFO - 2019-08-19 16:56:13 --> Language Class Initialized
INFO - 2019-08-19 16:56:13 --> Loader Class Initialized
INFO - 2019-08-19 16:56:13 --> Helper loaded: url_helper
INFO - 2019-08-19 16:56:13 --> Helper loaded: html_helper
INFO - 2019-08-19 16:56:13 --> Helper loaded: form_helper
INFO - 2019-08-19 16:56:13 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:56:13 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:56:13 --> Final output sent to browser
INFO - 2019-08-19 16:56:13 --> Helper loaded: date_helper
DEBUG - 2019-08-19 16:56:13 --> Total execution time: 0.2240
INFO - 2019-08-19 16:56:13 --> Form Validation Class Initialized
INFO - 2019-08-19 16:56:13 --> Email Class Initialized
DEBUG - 2019-08-19 16:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:56:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:56:13 --> Pagination Class Initialized
INFO - 2019-08-19 16:56:13 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:13 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:13 --> Controller Class Initialized
INFO - 2019-08-19 16:56:13 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:56:13 --> Final output sent to browser
DEBUG - 2019-08-19 16:56:13 --> Total execution time: 0.1760
INFO - 2019-08-19 16:56:13 --> Config Class Initialized
INFO - 2019-08-19 16:56:13 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:56:13 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:56:13 --> Utf8 Class Initialized
INFO - 2019-08-19 16:56:13 --> URI Class Initialized
INFO - 2019-08-19 16:56:13 --> Router Class Initialized
INFO - 2019-08-19 16:56:13 --> Output Class Initialized
INFO - 2019-08-19 16:56:13 --> Security Class Initialized
DEBUG - 2019-08-19 16:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:56:13 --> Input Class Initialized
INFO - 2019-08-19 16:56:13 --> Language Class Initialized
INFO - 2019-08-19 16:56:13 --> Loader Class Initialized
INFO - 2019-08-19 16:56:13 --> Helper loaded: url_helper
INFO - 2019-08-19 16:56:13 --> Helper loaded: html_helper
INFO - 2019-08-19 16:56:13 --> Helper loaded: form_helper
INFO - 2019-08-19 16:56:13 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:56:13 --> Helper loaded: date_helper
INFO - 2019-08-19 16:56:13 --> Form Validation Class Initialized
INFO - 2019-08-19 16:56:13 --> Email Class Initialized
DEBUG - 2019-08-19 16:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:56:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:56:14 --> Pagination Class Initialized
INFO - 2019-08-19 16:56:14 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:14 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:14 --> Controller Class Initialized
INFO - 2019-08-19 16:56:14 --> Final output sent to browser
DEBUG - 2019-08-19 16:56:14 --> Total execution time: 0.2620
INFO - 2019-08-19 16:56:26 --> Config Class Initialized
INFO - 2019-08-19 16:56:26 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:56:26 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:56:26 --> Utf8 Class Initialized
INFO - 2019-08-19 16:56:26 --> URI Class Initialized
INFO - 2019-08-19 16:56:26 --> Router Class Initialized
INFO - 2019-08-19 16:56:26 --> Output Class Initialized
INFO - 2019-08-19 16:56:26 --> Security Class Initialized
DEBUG - 2019-08-19 16:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:56:26 --> Input Class Initialized
INFO - 2019-08-19 16:56:26 --> Language Class Initialized
INFO - 2019-08-19 16:56:26 --> Loader Class Initialized
INFO - 2019-08-19 16:56:26 --> Helper loaded: url_helper
INFO - 2019-08-19 16:56:26 --> Helper loaded: html_helper
INFO - 2019-08-19 16:56:26 --> Helper loaded: form_helper
INFO - 2019-08-19 16:56:26 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:56:26 --> Helper loaded: date_helper
INFO - 2019-08-19 16:56:26 --> Form Validation Class Initialized
INFO - 2019-08-19 16:56:26 --> Email Class Initialized
DEBUG - 2019-08-19 16:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:56:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:56:26 --> Pagination Class Initialized
INFO - 2019-08-19 16:56:26 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:26 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:26 --> Controller Class Initialized
INFO - 2019-08-19 16:56:26 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:56:26 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_class.php
INFO - 2019-08-19 16:56:26 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:56:26 --> Final output sent to browser
DEBUG - 2019-08-19 16:56:26 --> Total execution time: 0.1740
INFO - 2019-08-19 16:56:52 --> Config Class Initialized
INFO - 2019-08-19 16:56:52 --> Hooks Class Initialized
INFO - 2019-08-19 16:56:52 --> Config Class Initialized
INFO - 2019-08-19 16:56:52 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:56:52 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:56:52 --> Utf8 Class Initialized
INFO - 2019-08-19 16:56:52 --> URI Class Initialized
DEBUG - 2019-08-19 16:56:52 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:56:52 --> Utf8 Class Initialized
INFO - 2019-08-19 16:56:52 --> URI Class Initialized
INFO - 2019-08-19 16:56:52 --> Router Class Initialized
INFO - 2019-08-19 16:56:52 --> Output Class Initialized
INFO - 2019-08-19 16:56:52 --> Security Class Initialized
DEBUG - 2019-08-19 16:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:56:52 --> Input Class Initialized
INFO - 2019-08-19 16:56:52 --> Language Class Initialized
INFO - 2019-08-19 16:56:53 --> Loader Class Initialized
INFO - 2019-08-19 16:56:53 --> Helper loaded: url_helper
INFO - 2019-08-19 16:56:53 --> Helper loaded: html_helper
INFO - 2019-08-19 16:56:53 --> Helper loaded: form_helper
INFO - 2019-08-19 16:56:53 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:56:53 --> Helper loaded: date_helper
INFO - 2019-08-19 16:56:53 --> Form Validation Class Initialized
INFO - 2019-08-19 16:56:53 --> Email Class Initialized
DEBUG - 2019-08-19 16:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:56:53 --> Pagination Class Initialized
INFO - 2019-08-19 16:56:53 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:53 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:53 --> Router Class Initialized
INFO - 2019-08-19 16:56:53 --> Output Class Initialized
INFO - 2019-08-19 16:56:53 --> Security Class Initialized
DEBUG - 2019-08-19 16:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:56:53 --> Input Class Initialized
INFO - 2019-08-19 16:56:53 --> Language Class Initialized
INFO - 2019-08-19 16:56:53 --> Loader Class Initialized
INFO - 2019-08-19 16:56:53 --> Helper loaded: url_helper
INFO - 2019-08-19 16:56:53 --> Helper loaded: html_helper
INFO - 2019-08-19 16:56:53 --> Helper loaded: form_helper
INFO - 2019-08-19 16:56:53 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:56:53 --> Helper loaded: date_helper
INFO - 2019-08-19 16:56:53 --> Form Validation Class Initialized
INFO - 2019-08-19 16:56:53 --> Email Class Initialized
DEBUG - 2019-08-19 16:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:56:53 --> Controller Class Initialized
INFO - 2019-08-19 16:56:53 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:56:53 --> Final output sent to browser
DEBUG - 2019-08-19 16:56:53 --> Total execution time: 0.2490
INFO - 2019-08-19 16:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:56:53 --> Pagination Class Initialized
INFO - 2019-08-19 16:56:53 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:53 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:53 --> Controller Class Initialized
INFO - 2019-08-19 16:56:53 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:56:53 --> Final output sent to browser
DEBUG - 2019-08-19 16:56:53 --> Total execution time: 0.3210
INFO - 2019-08-19 16:56:53 --> Config Class Initialized
INFO - 2019-08-19 16:56:53 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:56:53 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:56:53 --> Utf8 Class Initialized
INFO - 2019-08-19 16:56:53 --> URI Class Initialized
INFO - 2019-08-19 16:56:53 --> Router Class Initialized
INFO - 2019-08-19 16:56:53 --> Output Class Initialized
INFO - 2019-08-19 16:56:53 --> Security Class Initialized
DEBUG - 2019-08-19 16:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:56:53 --> Input Class Initialized
INFO - 2019-08-19 16:56:53 --> Language Class Initialized
INFO - 2019-08-19 16:56:53 --> Loader Class Initialized
INFO - 2019-08-19 16:56:53 --> Helper loaded: url_helper
INFO - 2019-08-19 16:56:53 --> Helper loaded: html_helper
INFO - 2019-08-19 16:56:53 --> Helper loaded: form_helper
INFO - 2019-08-19 16:56:53 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:56:53 --> Helper loaded: date_helper
INFO - 2019-08-19 16:56:53 --> Form Validation Class Initialized
INFO - 2019-08-19 16:56:53 --> Email Class Initialized
DEBUG - 2019-08-19 16:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:56:53 --> Pagination Class Initialized
INFO - 2019-08-19 16:56:54 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:54 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:54 --> Controller Class Initialized
INFO - 2019-08-19 16:56:54 --> Final output sent to browser
DEBUG - 2019-08-19 16:56:54 --> Total execution time: 0.2270
INFO - 2019-08-19 16:56:57 --> Config Class Initialized
INFO - 2019-08-19 16:56:57 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:56:57 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:56:57 --> Utf8 Class Initialized
INFO - 2019-08-19 16:56:57 --> URI Class Initialized
INFO - 2019-08-19 16:56:57 --> Router Class Initialized
INFO - 2019-08-19 16:56:57 --> Output Class Initialized
INFO - 2019-08-19 16:56:57 --> Security Class Initialized
DEBUG - 2019-08-19 16:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:56:57 --> Input Class Initialized
INFO - 2019-08-19 16:56:57 --> Language Class Initialized
INFO - 2019-08-19 16:56:57 --> Loader Class Initialized
INFO - 2019-08-19 16:56:57 --> Helper loaded: url_helper
INFO - 2019-08-19 16:56:57 --> Helper loaded: html_helper
INFO - 2019-08-19 16:56:57 --> Helper loaded: form_helper
INFO - 2019-08-19 16:56:57 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:56:57 --> Helper loaded: date_helper
INFO - 2019-08-19 16:56:57 --> Form Validation Class Initialized
INFO - 2019-08-19 16:56:57 --> Email Class Initialized
DEBUG - 2019-08-19 16:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:56:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:56:57 --> Pagination Class Initialized
INFO - 2019-08-19 16:56:57 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:57 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:57 --> Controller Class Initialized
INFO - 2019-08-19 16:56:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:56:57 --> Final output sent to browser
DEBUG - 2019-08-19 16:56:57 --> Total execution time: 0.2250
INFO - 2019-08-19 16:56:58 --> Config Class Initialized
INFO - 2019-08-19 16:56:58 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:56:58 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:56:58 --> Utf8 Class Initialized
INFO - 2019-08-19 16:56:58 --> URI Class Initialized
INFO - 2019-08-19 16:56:58 --> Router Class Initialized
INFO - 2019-08-19 16:56:58 --> Output Class Initialized
INFO - 2019-08-19 16:56:58 --> Security Class Initialized
DEBUG - 2019-08-19 16:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:56:58 --> Input Class Initialized
INFO - 2019-08-19 16:56:58 --> Language Class Initialized
INFO - 2019-08-19 16:56:58 --> Loader Class Initialized
INFO - 2019-08-19 16:56:58 --> Helper loaded: url_helper
INFO - 2019-08-19 16:56:58 --> Helper loaded: html_helper
INFO - 2019-08-19 16:56:58 --> Helper loaded: form_helper
INFO - 2019-08-19 16:56:58 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:56:58 --> Helper loaded: date_helper
INFO - 2019-08-19 16:56:58 --> Form Validation Class Initialized
INFO - 2019-08-19 16:56:58 --> Email Class Initialized
DEBUG - 2019-08-19 16:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:56:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:56:59 --> Pagination Class Initialized
INFO - 2019-08-19 16:56:59 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:59 --> Database Driver Class Initialized
INFO - 2019-08-19 16:56:59 --> Controller Class Initialized
INFO - 2019-08-19 16:56:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:56:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_type.php
INFO - 2019-08-19 16:56:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:56:59 --> Final output sent to browser
DEBUG - 2019-08-19 16:56:59 --> Total execution time: 0.4380
INFO - 2019-08-19 16:57:26 --> Config Class Initialized
INFO - 2019-08-19 16:57:26 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:57:26 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:57:26 --> Utf8 Class Initialized
INFO - 2019-08-19 16:57:26 --> URI Class Initialized
INFO - 2019-08-19 16:57:26 --> Router Class Initialized
INFO - 2019-08-19 16:57:26 --> Output Class Initialized
INFO - 2019-08-19 16:57:26 --> Security Class Initialized
DEBUG - 2019-08-19 16:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:57:26 --> Input Class Initialized
INFO - 2019-08-19 16:57:26 --> Language Class Initialized
INFO - 2019-08-19 16:57:26 --> Loader Class Initialized
INFO - 2019-08-19 16:57:26 --> Helper loaded: url_helper
INFO - 2019-08-19 16:57:26 --> Helper loaded: html_helper
INFO - 2019-08-19 16:57:26 --> Helper loaded: form_helper
INFO - 2019-08-19 16:57:26 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:57:26 --> Helper loaded: date_helper
INFO - 2019-08-19 16:57:26 --> Form Validation Class Initialized
INFO - 2019-08-19 16:57:26 --> Email Class Initialized
DEBUG - 2019-08-19 16:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:57:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:57:26 --> Pagination Class Initialized
INFO - 2019-08-19 16:57:26 --> Database Driver Class Initialized
INFO - 2019-08-19 16:57:26 --> Database Driver Class Initialized
INFO - 2019-08-19 16:57:26 --> Controller Class Initialized
INFO - 2019-08-19 16:57:26 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:57:26 --> Final output sent to browser
DEBUG - 2019-08-19 16:57:26 --> Total execution time: 0.1820
INFO - 2019-08-19 16:57:51 --> Config Class Initialized
INFO - 2019-08-19 16:57:51 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:57:51 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:57:51 --> Utf8 Class Initialized
INFO - 2019-08-19 16:57:51 --> URI Class Initialized
INFO - 2019-08-19 16:57:51 --> Router Class Initialized
INFO - 2019-08-19 16:57:51 --> Output Class Initialized
INFO - 2019-08-19 16:57:51 --> Security Class Initialized
DEBUG - 2019-08-19 16:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:57:51 --> Input Class Initialized
INFO - 2019-08-19 16:57:51 --> Language Class Initialized
INFO - 2019-08-19 16:57:51 --> Loader Class Initialized
INFO - 2019-08-19 16:57:51 --> Helper loaded: url_helper
INFO - 2019-08-19 16:57:51 --> Helper loaded: html_helper
INFO - 2019-08-19 16:57:51 --> Config Class Initialized
INFO - 2019-08-19 16:57:51 --> Helper loaded: form_helper
INFO - 2019-08-19 16:57:51 --> Hooks Class Initialized
INFO - 2019-08-19 16:57:51 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:57:51 --> Helper loaded: date_helper
DEBUG - 2019-08-19 16:57:51 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:57:51 --> Utf8 Class Initialized
INFO - 2019-08-19 16:57:51 --> Form Validation Class Initialized
INFO - 2019-08-19 16:57:51 --> URI Class Initialized
INFO - 2019-08-19 16:57:51 --> Email Class Initialized
DEBUG - 2019-08-19 16:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:57:51 --> Router Class Initialized
INFO - 2019-08-19 16:57:51 --> Output Class Initialized
INFO - 2019-08-19 16:57:51 --> Security Class Initialized
DEBUG - 2019-08-19 16:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:57:51 --> Input Class Initialized
INFO - 2019-08-19 16:57:51 --> Language Class Initialized
INFO - 2019-08-19 16:57:51 --> Loader Class Initialized
INFO - 2019-08-19 16:57:51 --> Helper loaded: url_helper
INFO - 2019-08-19 16:57:51 --> Helper loaded: html_helper
INFO - 2019-08-19 16:57:51 --> Helper loaded: form_helper
INFO - 2019-08-19 16:57:51 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:57:51 --> Helper loaded: date_helper
INFO - 2019-08-19 16:57:51 --> Form Validation Class Initialized
INFO - 2019-08-19 16:57:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:57:51 --> Pagination Class Initialized
INFO - 2019-08-19 16:57:51 --> Email Class Initialized
DEBUG - 2019-08-19 16:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:57:51 --> Database Driver Class Initialized
INFO - 2019-08-19 16:57:51 --> Database Driver Class Initialized
INFO - 2019-08-19 16:57:51 --> Controller Class Initialized
INFO - 2019-08-19 16:57:51 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:57:51 --> Final output sent to browser
DEBUG - 2019-08-19 16:57:51 --> Total execution time: 0.3150
INFO - 2019-08-19 16:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:57:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:57:51 --> Pagination Class Initialized
INFO - 2019-08-19 16:57:51 --> Database Driver Class Initialized
INFO - 2019-08-19 16:57:51 --> Database Driver Class Initialized
INFO - 2019-08-19 16:57:51 --> Controller Class Initialized
INFO - 2019-08-19 16:57:51 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:57:51 --> Final output sent to browser
DEBUG - 2019-08-19 16:57:51 --> Total execution time: 0.3780
INFO - 2019-08-19 16:57:51 --> Config Class Initialized
INFO - 2019-08-19 16:57:51 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:57:51 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:57:51 --> Utf8 Class Initialized
INFO - 2019-08-19 16:57:51 --> URI Class Initialized
INFO - 2019-08-19 16:57:51 --> Router Class Initialized
INFO - 2019-08-19 16:57:51 --> Output Class Initialized
INFO - 2019-08-19 16:57:51 --> Security Class Initialized
DEBUG - 2019-08-19 16:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:57:51 --> Input Class Initialized
INFO - 2019-08-19 16:57:51 --> Language Class Initialized
INFO - 2019-08-19 16:57:51 --> Loader Class Initialized
INFO - 2019-08-19 16:57:51 --> Helper loaded: url_helper
INFO - 2019-08-19 16:57:52 --> Helper loaded: html_helper
INFO - 2019-08-19 16:57:52 --> Helper loaded: form_helper
INFO - 2019-08-19 16:57:52 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:57:52 --> Helper loaded: date_helper
INFO - 2019-08-19 16:57:52 --> Form Validation Class Initialized
INFO - 2019-08-19 16:57:52 --> Email Class Initialized
DEBUG - 2019-08-19 16:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:57:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:57:52 --> Pagination Class Initialized
INFO - 2019-08-19 16:57:52 --> Database Driver Class Initialized
INFO - 2019-08-19 16:57:52 --> Database Driver Class Initialized
INFO - 2019-08-19 16:57:52 --> Controller Class Initialized
INFO - 2019-08-19 16:57:52 --> Final output sent to browser
DEBUG - 2019-08-19 16:57:52 --> Total execution time: 0.2520
INFO - 2019-08-19 16:58:07 --> Config Class Initialized
INFO - 2019-08-19 16:58:07 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:58:07 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:58:07 --> Utf8 Class Initialized
INFO - 2019-08-19 16:58:07 --> URI Class Initialized
INFO - 2019-08-19 16:58:07 --> Router Class Initialized
INFO - 2019-08-19 16:58:07 --> Output Class Initialized
INFO - 2019-08-19 16:58:07 --> Security Class Initialized
DEBUG - 2019-08-19 16:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:58:07 --> Input Class Initialized
INFO - 2019-08-19 16:58:07 --> Language Class Initialized
INFO - 2019-08-19 16:58:07 --> Loader Class Initialized
INFO - 2019-08-19 16:58:07 --> Helper loaded: url_helper
INFO - 2019-08-19 16:58:07 --> Helper loaded: html_helper
INFO - 2019-08-19 16:58:07 --> Helper loaded: form_helper
INFO - 2019-08-19 16:58:07 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:58:07 --> Helper loaded: date_helper
INFO - 2019-08-19 16:58:07 --> Form Validation Class Initialized
INFO - 2019-08-19 16:58:07 --> Email Class Initialized
DEBUG - 2019-08-19 16:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:58:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:58:07 --> Pagination Class Initialized
INFO - 2019-08-19 16:58:07 --> Database Driver Class Initialized
INFO - 2019-08-19 16:58:07 --> Database Driver Class Initialized
INFO - 2019-08-19 16:58:07 --> Controller Class Initialized
INFO - 2019-08-19 16:58:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:58:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_salescategory.php
INFO - 2019-08-19 16:58:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:58:07 --> Final output sent to browser
DEBUG - 2019-08-19 16:58:07 --> Total execution time: 0.1894
INFO - 2019-08-19 16:58:33 --> Config Class Initialized
INFO - 2019-08-19 16:58:33 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:58:33 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:58:33 --> Utf8 Class Initialized
INFO - 2019-08-19 16:58:33 --> URI Class Initialized
INFO - 2019-08-19 16:58:33 --> Router Class Initialized
INFO - 2019-08-19 16:58:33 --> Output Class Initialized
INFO - 2019-08-19 16:58:33 --> Security Class Initialized
DEBUG - 2019-08-19 16:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:58:33 --> Input Class Initialized
INFO - 2019-08-19 16:58:33 --> Language Class Initialized
INFO - 2019-08-19 16:58:33 --> Loader Class Initialized
INFO - 2019-08-19 16:58:33 --> Helper loaded: url_helper
INFO - 2019-08-19 16:58:33 --> Helper loaded: html_helper
INFO - 2019-08-19 16:58:33 --> Helper loaded: form_helper
INFO - 2019-08-19 16:58:33 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:58:33 --> Helper loaded: date_helper
INFO - 2019-08-19 16:58:33 --> Form Validation Class Initialized
INFO - 2019-08-19 16:58:33 --> Email Class Initialized
DEBUG - 2019-08-19 16:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:58:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:58:33 --> Pagination Class Initialized
INFO - 2019-08-19 16:58:33 --> Config Class Initialized
INFO - 2019-08-19 16:58:33 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:58:33 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:58:33 --> Database Driver Class Initialized
INFO - 2019-08-19 16:58:33 --> Utf8 Class Initialized
INFO - 2019-08-19 16:58:33 --> Database Driver Class Initialized
INFO - 2019-08-19 16:58:33 --> URI Class Initialized
INFO - 2019-08-19 16:58:33 --> Router Class Initialized
INFO - 2019-08-19 16:58:33 --> Output Class Initialized
INFO - 2019-08-19 16:58:33 --> Security Class Initialized
DEBUG - 2019-08-19 16:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:58:33 --> Input Class Initialized
INFO - 2019-08-19 16:58:33 --> Language Class Initialized
INFO - 2019-08-19 16:58:33 --> Loader Class Initialized
INFO - 2019-08-19 16:58:33 --> Helper loaded: url_helper
INFO - 2019-08-19 16:58:33 --> Helper loaded: html_helper
INFO - 2019-08-19 16:58:33 --> Helper loaded: form_helper
INFO - 2019-08-19 16:58:33 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:58:33 --> Helper loaded: date_helper
INFO - 2019-08-19 16:58:33 --> Form Validation Class Initialized
INFO - 2019-08-19 16:58:33 --> Email Class Initialized
DEBUG - 2019-08-19 16:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:58:33 --> Controller Class Initialized
INFO - 2019-08-19 16:58:33 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:58:33 --> Final output sent to browser
DEBUG - 2019-08-19 16:58:33 --> Total execution time: 0.2780
INFO - 2019-08-19 16:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:58:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:58:33 --> Pagination Class Initialized
INFO - 2019-08-19 16:58:33 --> Database Driver Class Initialized
INFO - 2019-08-19 16:58:33 --> Database Driver Class Initialized
INFO - 2019-08-19 16:58:33 --> Controller Class Initialized
INFO - 2019-08-19 16:58:33 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:58:33 --> Final output sent to browser
DEBUG - 2019-08-19 16:58:33 --> Total execution time: 0.2460
INFO - 2019-08-19 16:58:34 --> Config Class Initialized
INFO - 2019-08-19 16:58:34 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:58:34 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:58:34 --> Utf8 Class Initialized
INFO - 2019-08-19 16:58:34 --> URI Class Initialized
INFO - 2019-08-19 16:58:34 --> Router Class Initialized
INFO - 2019-08-19 16:58:34 --> Output Class Initialized
INFO - 2019-08-19 16:58:34 --> Security Class Initialized
DEBUG - 2019-08-19 16:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:58:34 --> Input Class Initialized
INFO - 2019-08-19 16:58:34 --> Language Class Initialized
INFO - 2019-08-19 16:58:34 --> Loader Class Initialized
INFO - 2019-08-19 16:58:34 --> Helper loaded: url_helper
INFO - 2019-08-19 16:58:34 --> Helper loaded: html_helper
INFO - 2019-08-19 16:58:34 --> Helper loaded: form_helper
INFO - 2019-08-19 16:58:34 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:58:34 --> Helper loaded: date_helper
INFO - 2019-08-19 16:58:34 --> Form Validation Class Initialized
INFO - 2019-08-19 16:58:34 --> Email Class Initialized
DEBUG - 2019-08-19 16:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:58:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:58:34 --> Pagination Class Initialized
INFO - 2019-08-19 16:58:34 --> Database Driver Class Initialized
INFO - 2019-08-19 16:58:34 --> Database Driver Class Initialized
INFO - 2019-08-19 16:58:34 --> Controller Class Initialized
INFO - 2019-08-19 16:58:34 --> Final output sent to browser
DEBUG - 2019-08-19 16:58:34 --> Total execution time: 0.2470
INFO - 2019-08-19 16:58:36 --> Config Class Initialized
INFO - 2019-08-19 16:58:36 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:58:36 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:58:36 --> Utf8 Class Initialized
INFO - 2019-08-19 16:58:36 --> URI Class Initialized
INFO - 2019-08-19 16:58:36 --> Router Class Initialized
INFO - 2019-08-19 16:58:36 --> Output Class Initialized
INFO - 2019-08-19 16:58:36 --> Security Class Initialized
DEBUG - 2019-08-19 16:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:58:36 --> Input Class Initialized
INFO - 2019-08-19 16:58:36 --> Language Class Initialized
INFO - 2019-08-19 16:58:36 --> Loader Class Initialized
INFO - 2019-08-19 16:58:36 --> Helper loaded: url_helper
INFO - 2019-08-19 16:58:36 --> Helper loaded: html_helper
INFO - 2019-08-19 16:58:36 --> Helper loaded: form_helper
INFO - 2019-08-19 16:58:36 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:58:36 --> Helper loaded: date_helper
INFO - 2019-08-19 16:58:36 --> Form Validation Class Initialized
INFO - 2019-08-19 16:58:36 --> Email Class Initialized
DEBUG - 2019-08-19 16:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:58:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:58:36 --> Pagination Class Initialized
INFO - 2019-08-19 16:58:36 --> Database Driver Class Initialized
INFO - 2019-08-19 16:58:36 --> Database Driver Class Initialized
INFO - 2019-08-19 16:58:36 --> Controller Class Initialized
INFO - 2019-08-19 16:58:36 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:58:36 --> Final output sent to browser
DEBUG - 2019-08-19 16:58:36 --> Total execution time: 0.2250
INFO - 2019-08-19 16:58:42 --> Config Class Initialized
INFO - 2019-08-19 16:58:42 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:58:42 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:58:42 --> Utf8 Class Initialized
INFO - 2019-08-19 16:58:42 --> URI Class Initialized
INFO - 2019-08-19 16:58:42 --> Router Class Initialized
INFO - 2019-08-19 16:58:42 --> Output Class Initialized
INFO - 2019-08-19 16:58:42 --> Security Class Initialized
DEBUG - 2019-08-19 16:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:58:42 --> Input Class Initialized
INFO - 2019-08-19 16:58:42 --> Language Class Initialized
INFO - 2019-08-19 16:58:42 --> Loader Class Initialized
INFO - 2019-08-19 16:58:42 --> Helper loaded: url_helper
INFO - 2019-08-19 16:58:42 --> Helper loaded: html_helper
INFO - 2019-08-19 16:58:42 --> Helper loaded: form_helper
INFO - 2019-08-19 16:58:42 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:58:42 --> Helper loaded: date_helper
INFO - 2019-08-19 16:58:42 --> Form Validation Class Initialized
INFO - 2019-08-19 16:58:42 --> Email Class Initialized
DEBUG - 2019-08-19 16:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:58:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:58:42 --> Pagination Class Initialized
INFO - 2019-08-19 16:58:42 --> Database Driver Class Initialized
INFO - 2019-08-19 16:58:42 --> Database Driver Class Initialized
INFO - 2019-08-19 16:58:42 --> Controller Class Initialized
INFO - 2019-08-19 16:58:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 16:58:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomtype.php
INFO - 2019-08-19 16:58:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 16:58:42 --> Final output sent to browser
DEBUG - 2019-08-19 16:58:42 --> Total execution time: 0.1940
INFO - 2019-08-19 16:59:11 --> Config Class Initialized
INFO - 2019-08-19 16:59:11 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:59:11 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:59:11 --> Utf8 Class Initialized
INFO - 2019-08-19 16:59:11 --> URI Class Initialized
INFO - 2019-08-19 16:59:11 --> Router Class Initialized
INFO - 2019-08-19 16:59:11 --> Output Class Initialized
INFO - 2019-08-19 16:59:11 --> Security Class Initialized
DEBUG - 2019-08-19 16:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:59:11 --> Input Class Initialized
INFO - 2019-08-19 16:59:11 --> Language Class Initialized
INFO - 2019-08-19 16:59:11 --> Loader Class Initialized
INFO - 2019-08-19 16:59:11 --> Helper loaded: url_helper
INFO - 2019-08-19 16:59:11 --> Helper loaded: html_helper
INFO - 2019-08-19 16:59:11 --> Helper loaded: form_helper
INFO - 2019-08-19 16:59:11 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:59:11 --> Helper loaded: date_helper
INFO - 2019-08-19 16:59:11 --> Form Validation Class Initialized
INFO - 2019-08-19 16:59:11 --> Email Class Initialized
DEBUG - 2019-08-19 16:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:59:11 --> Pagination Class Initialized
INFO - 2019-08-19 16:59:11 --> Database Driver Class Initialized
INFO - 2019-08-19 16:59:11 --> Database Driver Class Initialized
INFO - 2019-08-19 16:59:11 --> Config Class Initialized
INFO - 2019-08-19 16:59:11 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:59:11 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:59:11 --> Utf8 Class Initialized
INFO - 2019-08-19 16:59:11 --> URI Class Initialized
INFO - 2019-08-19 16:59:11 --> Router Class Initialized
INFO - 2019-08-19 16:59:11 --> Output Class Initialized
INFO - 2019-08-19 16:59:11 --> Security Class Initialized
DEBUG - 2019-08-19 16:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:59:11 --> Input Class Initialized
INFO - 2019-08-19 16:59:11 --> Language Class Initialized
INFO - 2019-08-19 16:59:11 --> Loader Class Initialized
INFO - 2019-08-19 16:59:11 --> Helper loaded: url_helper
INFO - 2019-08-19 16:59:11 --> Helper loaded: html_helper
INFO - 2019-08-19 16:59:11 --> Helper loaded: form_helper
INFO - 2019-08-19 16:59:11 --> Controller Class Initialized
INFO - 2019-08-19 16:59:11 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:59:11 --> Helper loaded: date_helper
INFO - 2019-08-19 16:59:11 --> Form Validation Class Initialized
INFO - 2019-08-19 16:59:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:59:11 --> Final output sent to browser
DEBUG - 2019-08-19 16:59:11 --> Total execution time: 0.2420
INFO - 2019-08-19 16:59:11 --> Email Class Initialized
DEBUG - 2019-08-19 16:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:59:11 --> Pagination Class Initialized
INFO - 2019-08-19 16:59:11 --> Database Driver Class Initialized
INFO - 2019-08-19 16:59:11 --> Database Driver Class Initialized
INFO - 2019-08-19 16:59:11 --> Controller Class Initialized
INFO - 2019-08-19 16:59:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:59:11 --> Final output sent to browser
DEBUG - 2019-08-19 16:59:11 --> Total execution time: 0.1980
INFO - 2019-08-19 16:59:12 --> Config Class Initialized
INFO - 2019-08-19 16:59:12 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:59:12 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:59:12 --> Utf8 Class Initialized
INFO - 2019-08-19 16:59:12 --> URI Class Initialized
INFO - 2019-08-19 16:59:12 --> Router Class Initialized
INFO - 2019-08-19 16:59:12 --> Output Class Initialized
INFO - 2019-08-19 16:59:12 --> Security Class Initialized
DEBUG - 2019-08-19 16:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:59:12 --> Input Class Initialized
INFO - 2019-08-19 16:59:12 --> Language Class Initialized
INFO - 2019-08-19 16:59:12 --> Loader Class Initialized
INFO - 2019-08-19 16:59:12 --> Helper loaded: url_helper
INFO - 2019-08-19 16:59:12 --> Helper loaded: html_helper
INFO - 2019-08-19 16:59:12 --> Helper loaded: form_helper
INFO - 2019-08-19 16:59:12 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:59:12 --> Helper loaded: date_helper
INFO - 2019-08-19 16:59:12 --> Form Validation Class Initialized
INFO - 2019-08-19 16:59:12 --> Email Class Initialized
DEBUG - 2019-08-19 16:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:59:12 --> Pagination Class Initialized
INFO - 2019-08-19 16:59:12 --> Database Driver Class Initialized
INFO - 2019-08-19 16:59:12 --> Database Driver Class Initialized
INFO - 2019-08-19 16:59:12 --> Controller Class Initialized
INFO - 2019-08-19 16:59:12 --> Final output sent to browser
DEBUG - 2019-08-19 16:59:12 --> Total execution time: 0.2600
INFO - 2019-08-19 16:59:51 --> Config Class Initialized
INFO - 2019-08-19 16:59:51 --> Hooks Class Initialized
DEBUG - 2019-08-19 16:59:51 --> UTF-8 Support Enabled
INFO - 2019-08-19 16:59:51 --> Utf8 Class Initialized
INFO - 2019-08-19 16:59:51 --> URI Class Initialized
INFO - 2019-08-19 16:59:51 --> Router Class Initialized
INFO - 2019-08-19 16:59:51 --> Output Class Initialized
INFO - 2019-08-19 16:59:51 --> Security Class Initialized
DEBUG - 2019-08-19 16:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 16:59:51 --> Input Class Initialized
INFO - 2019-08-19 16:59:51 --> Language Class Initialized
INFO - 2019-08-19 16:59:51 --> Loader Class Initialized
INFO - 2019-08-19 16:59:51 --> Helper loaded: url_helper
INFO - 2019-08-19 16:59:51 --> Helper loaded: html_helper
INFO - 2019-08-19 16:59:51 --> Helper loaded: form_helper
INFO - 2019-08-19 16:59:51 --> Helper loaded: cookie_helper
INFO - 2019-08-19 16:59:51 --> Helper loaded: date_helper
INFO - 2019-08-19 16:59:51 --> Form Validation Class Initialized
INFO - 2019-08-19 16:59:51 --> Email Class Initialized
DEBUG - 2019-08-19 16:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 16:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 16:59:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 16:59:51 --> Pagination Class Initialized
INFO - 2019-08-19 16:59:51 --> Database Driver Class Initialized
INFO - 2019-08-19 16:59:51 --> Database Driver Class Initialized
INFO - 2019-08-19 16:59:51 --> Controller Class Initialized
INFO - 2019-08-19 16:59:51 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 16:59:51 --> Final output sent to browser
DEBUG - 2019-08-19 16:59:51 --> Total execution time: 0.2270
INFO - 2019-08-19 17:00:12 --> Config Class Initialized
INFO - 2019-08-19 17:00:12 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:00:12 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:00:12 --> Utf8 Class Initialized
INFO - 2019-08-19 17:00:12 --> URI Class Initialized
INFO - 2019-08-19 17:00:12 --> Router Class Initialized
INFO - 2019-08-19 17:00:12 --> Output Class Initialized
INFO - 2019-08-19 17:00:12 --> Security Class Initialized
DEBUG - 2019-08-19 17:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:00:12 --> Input Class Initialized
INFO - 2019-08-19 17:00:12 --> Language Class Initialized
INFO - 2019-08-19 17:00:12 --> Loader Class Initialized
INFO - 2019-08-19 17:00:12 --> Helper loaded: url_helper
INFO - 2019-08-19 17:00:12 --> Helper loaded: html_helper
INFO - 2019-08-19 17:00:12 --> Helper loaded: form_helper
INFO - 2019-08-19 17:00:12 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:00:12 --> Helper loaded: date_helper
INFO - 2019-08-19 17:00:12 --> Form Validation Class Initialized
INFO - 2019-08-19 17:00:12 --> Email Class Initialized
DEBUG - 2019-08-19 17:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:00:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:00:12 --> Pagination Class Initialized
INFO - 2019-08-19 17:00:12 --> Database Driver Class Initialized
INFO - 2019-08-19 17:00:12 --> Database Driver Class Initialized
INFO - 2019-08-19 17:00:12 --> Controller Class Initialized
INFO - 2019-08-19 17:00:12 --> Final output sent to browser
DEBUG - 2019-08-19 17:00:12 --> Total execution time: 0.1990
INFO - 2019-08-19 17:00:16 --> Config Class Initialized
INFO - 2019-08-19 17:00:16 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:00:16 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:00:16 --> Utf8 Class Initialized
INFO - 2019-08-19 17:00:16 --> URI Class Initialized
INFO - 2019-08-19 17:00:16 --> Router Class Initialized
INFO - 2019-08-19 17:00:16 --> Output Class Initialized
INFO - 2019-08-19 17:00:16 --> Security Class Initialized
DEBUG - 2019-08-19 17:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:00:16 --> Input Class Initialized
INFO - 2019-08-19 17:00:16 --> Language Class Initialized
INFO - 2019-08-19 17:00:16 --> Loader Class Initialized
INFO - 2019-08-19 17:00:16 --> Helper loaded: url_helper
INFO - 2019-08-19 17:00:16 --> Helper loaded: html_helper
INFO - 2019-08-19 17:00:16 --> Helper loaded: form_helper
INFO - 2019-08-19 17:00:16 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:00:16 --> Helper loaded: date_helper
INFO - 2019-08-19 17:00:16 --> Form Validation Class Initialized
INFO - 2019-08-19 17:00:16 --> Email Class Initialized
DEBUG - 2019-08-19 17:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:00:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:00:16 --> Pagination Class Initialized
INFO - 2019-08-19 17:00:17 --> Database Driver Class Initialized
INFO - 2019-08-19 17:00:17 --> Database Driver Class Initialized
INFO - 2019-08-19 17:00:17 --> Controller Class Initialized
INFO - 2019-08-19 17:00:17 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:00:17 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomtype.php
INFO - 2019-08-19 17:00:17 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:00:17 --> Final output sent to browser
DEBUG - 2019-08-19 17:00:17 --> Total execution time: 0.2530
INFO - 2019-08-19 17:01:22 --> Config Class Initialized
INFO - 2019-08-19 17:01:22 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:01:22 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:01:22 --> Utf8 Class Initialized
INFO - 2019-08-19 17:01:22 --> Config Class Initialized
INFO - 2019-08-19 17:01:22 --> Hooks Class Initialized
INFO - 2019-08-19 17:01:22 --> URI Class Initialized
DEBUG - 2019-08-19 17:01:22 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:01:22 --> Utf8 Class Initialized
INFO - 2019-08-19 17:01:22 --> Router Class Initialized
INFO - 2019-08-19 17:01:22 --> URI Class Initialized
INFO - 2019-08-19 17:01:22 --> Output Class Initialized
INFO - 2019-08-19 17:01:22 --> Security Class Initialized
INFO - 2019-08-19 17:01:22 --> Router Class Initialized
DEBUG - 2019-08-19 17:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:01:22 --> Input Class Initialized
INFO - 2019-08-19 17:01:22 --> Language Class Initialized
INFO - 2019-08-19 17:01:22 --> Output Class Initialized
INFO - 2019-08-19 17:01:22 --> Loader Class Initialized
INFO - 2019-08-19 17:01:22 --> Helper loaded: url_helper
INFO - 2019-08-19 17:01:22 --> Helper loaded: html_helper
INFO - 2019-08-19 17:01:22 --> Helper loaded: form_helper
INFO - 2019-08-19 17:01:22 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:01:22 --> Helper loaded: date_helper
INFO - 2019-08-19 17:01:22 --> Form Validation Class Initialized
INFO - 2019-08-19 17:01:22 --> Security Class Initialized
DEBUG - 2019-08-19 17:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:01:22 --> Input Class Initialized
INFO - 2019-08-19 17:01:22 --> Language Class Initialized
INFO - 2019-08-19 17:01:22 --> Email Class Initialized
INFO - 2019-08-19 17:01:22 --> Loader Class Initialized
INFO - 2019-08-19 17:01:22 --> Helper loaded: url_helper
INFO - 2019-08-19 17:01:22 --> Helper loaded: html_helper
DEBUG - 2019-08-19 17:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:01:22 --> Helper loaded: form_helper
INFO - 2019-08-19 17:01:22 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:01:22 --> Helper loaded: date_helper
INFO - 2019-08-19 17:01:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:01:22 --> Pagination Class Initialized
INFO - 2019-08-19 17:01:22 --> Form Validation Class Initialized
INFO - 2019-08-19 17:01:22 --> Email Class Initialized
INFO - 2019-08-19 17:01:22 --> Config Class Initialized
INFO - 2019-08-19 17:01:22 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-19 17:01:22 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:01:22 --> Utf8 Class Initialized
INFO - 2019-08-19 17:01:22 --> URI Class Initialized
INFO - 2019-08-19 17:01:22 --> Router Class Initialized
INFO - 2019-08-19 17:01:22 --> Output Class Initialized
INFO - 2019-08-19 17:01:23 --> Database Driver Class Initialized
INFO - 2019-08-19 17:01:23 --> Database Driver Class Initialized
INFO - 2019-08-19 17:01:23 --> Security Class Initialized
DEBUG - 2019-08-19 17:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:01:23 --> Input Class Initialized
INFO - 2019-08-19 17:01:23 --> Language Class Initialized
INFO - 2019-08-19 17:01:23 --> Loader Class Initialized
INFO - 2019-08-19 17:01:23 --> Helper loaded: url_helper
INFO - 2019-08-19 17:01:23 --> Helper loaded: html_helper
INFO - 2019-08-19 17:01:23 --> Controller Class Initialized
INFO - 2019-08-19 17:01:23 --> Helper loaded: form_helper
INFO - 2019-08-19 17:01:23 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:01:23 --> Helper loaded: date_helper
INFO - 2019-08-19 17:01:23 --> Form Validation Class Initialized
INFO - 2019-08-19 17:01:23 --> Email Class Initialized
DEBUG - 2019-08-19 17:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:01:23 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:01:23 --> Final output sent to browser
DEBUG - 2019-08-19 17:01:23 --> Total execution time: 0.3570
INFO - 2019-08-19 17:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:01:23 --> Pagination Class Initialized
INFO - 2019-08-19 17:01:23 --> Database Driver Class Initialized
INFO - 2019-08-19 17:01:23 --> Database Driver Class Initialized
INFO - 2019-08-19 17:01:23 --> Controller Class Initialized
INFO - 2019-08-19 17:01:23 --> Final output sent to browser
DEBUG - 2019-08-19 17:01:23 --> Total execution time: 0.4630
INFO - 2019-08-19 17:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:01:23 --> Pagination Class Initialized
INFO - 2019-08-19 17:01:23 --> Database Driver Class Initialized
INFO - 2019-08-19 17:01:23 --> Database Driver Class Initialized
INFO - 2019-08-19 17:01:23 --> Controller Class Initialized
INFO - 2019-08-19 17:01:23 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:01:23 --> Final output sent to browser
DEBUG - 2019-08-19 17:01:23 --> Total execution time: 0.3860
INFO - 2019-08-19 17:02:04 --> Config Class Initialized
INFO - 2019-08-19 17:02:04 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:02:04 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:02:04 --> Utf8 Class Initialized
INFO - 2019-08-19 17:02:04 --> URI Class Initialized
INFO - 2019-08-19 17:02:04 --> Router Class Initialized
INFO - 2019-08-19 17:02:04 --> Output Class Initialized
INFO - 2019-08-19 17:02:04 --> Security Class Initialized
DEBUG - 2019-08-19 17:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:02:04 --> Input Class Initialized
INFO - 2019-08-19 17:02:04 --> Language Class Initialized
INFO - 2019-08-19 17:02:04 --> Loader Class Initialized
INFO - 2019-08-19 17:02:04 --> Helper loaded: url_helper
INFO - 2019-08-19 17:02:04 --> Helper loaded: html_helper
INFO - 2019-08-19 17:02:04 --> Helper loaded: form_helper
INFO - 2019-08-19 17:02:04 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:02:04 --> Helper loaded: date_helper
INFO - 2019-08-19 17:02:04 --> Form Validation Class Initialized
INFO - 2019-08-19 17:02:04 --> Email Class Initialized
DEBUG - 2019-08-19 17:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:02:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:02:04 --> Pagination Class Initialized
INFO - 2019-08-19 17:02:04 --> Database Driver Class Initialized
INFO - 2019-08-19 17:02:04 --> Database Driver Class Initialized
INFO - 2019-08-19 17:02:04 --> Controller Class Initialized
INFO - 2019-08-19 17:02:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:02:04 --> Config Class Initialized
INFO - 2019-08-19 17:02:04 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:02:04 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:02:04 --> Utf8 Class Initialized
INFO - 2019-08-19 17:02:04 --> URI Class Initialized
INFO - 2019-08-19 17:02:04 --> Router Class Initialized
INFO - 2019-08-19 17:02:04 --> Output Class Initialized
INFO - 2019-08-19 17:02:04 --> Security Class Initialized
DEBUG - 2019-08-19 17:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:02:04 --> Input Class Initialized
INFO - 2019-08-19 17:02:04 --> Language Class Initialized
INFO - 2019-08-19 17:02:04 --> Loader Class Initialized
INFO - 2019-08-19 17:02:04 --> Helper loaded: url_helper
INFO - 2019-08-19 17:02:04 --> Helper loaded: html_helper
INFO - 2019-08-19 17:02:04 --> Helper loaded: form_helper
INFO - 2019-08-19 17:02:04 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:02:04 --> Helper loaded: date_helper
INFO - 2019-08-19 17:02:04 --> Form Validation Class Initialized
INFO - 2019-08-19 17:02:04 --> Email Class Initialized
DEBUG - 2019-08-19 17:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:02:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:02:04 --> Pagination Class Initialized
INFO - 2019-08-19 17:02:04 --> Database Driver Class Initialized
INFO - 2019-08-19 17:02:04 --> Database Driver Class Initialized
INFO - 2019-08-19 17:02:04 --> Controller Class Initialized
INFO - 2019-08-19 17:02:05 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:02:05 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomtype.php
INFO - 2019-08-19 17:02:05 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:02:05 --> Final output sent to browser
DEBUG - 2019-08-19 17:02:05 --> Total execution time: 0.1760
INFO - 2019-08-19 17:02:47 --> Config Class Initialized
INFO - 2019-08-19 17:02:47 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:02:47 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:02:47 --> Utf8 Class Initialized
INFO - 2019-08-19 17:02:47 --> URI Class Initialized
INFO - 2019-08-19 17:02:47 --> Router Class Initialized
INFO - 2019-08-19 17:02:47 --> Output Class Initialized
INFO - 2019-08-19 17:02:47 --> Security Class Initialized
DEBUG - 2019-08-19 17:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:02:47 --> Input Class Initialized
INFO - 2019-08-19 17:02:47 --> Language Class Initialized
INFO - 2019-08-19 17:02:47 --> Loader Class Initialized
INFO - 2019-08-19 17:02:47 --> Helper loaded: url_helper
INFO - 2019-08-19 17:02:47 --> Helper loaded: html_helper
INFO - 2019-08-19 17:02:47 --> Helper loaded: form_helper
INFO - 2019-08-19 17:02:47 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:02:47 --> Helper loaded: date_helper
INFO - 2019-08-19 17:02:47 --> Form Validation Class Initialized
INFO - 2019-08-19 17:02:47 --> Email Class Initialized
DEBUG - 2019-08-19 17:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:02:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:02:47 --> Pagination Class Initialized
INFO - 2019-08-19 17:02:47 --> Config Class Initialized
INFO - 2019-08-19 17:02:47 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:02:47 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:02:47 --> Utf8 Class Initialized
INFO - 2019-08-19 17:02:47 --> URI Class Initialized
INFO - 2019-08-19 17:02:47 --> Router Class Initialized
INFO - 2019-08-19 17:02:47 --> Database Driver Class Initialized
INFO - 2019-08-19 17:02:47 --> Output Class Initialized
INFO - 2019-08-19 17:02:47 --> Database Driver Class Initialized
INFO - 2019-08-19 17:02:47 --> Security Class Initialized
DEBUG - 2019-08-19 17:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:02:47 --> Input Class Initialized
INFO - 2019-08-19 17:02:47 --> Language Class Initialized
INFO - 2019-08-19 17:02:47 --> Loader Class Initialized
INFO - 2019-08-19 17:02:47 --> Helper loaded: url_helper
INFO - 2019-08-19 17:02:47 --> Helper loaded: html_helper
INFO - 2019-08-19 17:02:47 --> Helper loaded: form_helper
INFO - 2019-08-19 17:02:47 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:02:47 --> Helper loaded: date_helper
INFO - 2019-08-19 17:02:47 --> Form Validation Class Initialized
INFO - 2019-08-19 17:02:47 --> Email Class Initialized
DEBUG - 2019-08-19 17:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:02:47 --> Controller Class Initialized
INFO - 2019-08-19 17:02:47 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:02:47 --> Final output sent to browser
DEBUG - 2019-08-19 17:02:47 --> Total execution time: 0.2660
INFO - 2019-08-19 17:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:02:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:02:47 --> Pagination Class Initialized
INFO - 2019-08-19 17:02:47 --> Database Driver Class Initialized
INFO - 2019-08-19 17:02:47 --> Database Driver Class Initialized
INFO - 2019-08-19 17:02:47 --> Controller Class Initialized
INFO - 2019-08-19 17:02:47 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:02:47 --> Final output sent to browser
DEBUG - 2019-08-19 17:02:47 --> Total execution time: 0.2410
INFO - 2019-08-19 17:02:48 --> Config Class Initialized
INFO - 2019-08-19 17:02:48 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:02:48 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:02:48 --> Utf8 Class Initialized
INFO - 2019-08-19 17:02:48 --> URI Class Initialized
INFO - 2019-08-19 17:02:48 --> Router Class Initialized
INFO - 2019-08-19 17:02:48 --> Output Class Initialized
INFO - 2019-08-19 17:02:48 --> Security Class Initialized
DEBUG - 2019-08-19 17:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:02:48 --> Input Class Initialized
INFO - 2019-08-19 17:02:48 --> Language Class Initialized
INFO - 2019-08-19 17:02:48 --> Loader Class Initialized
INFO - 2019-08-19 17:02:48 --> Helper loaded: url_helper
INFO - 2019-08-19 17:02:48 --> Helper loaded: html_helper
INFO - 2019-08-19 17:02:48 --> Helper loaded: form_helper
INFO - 2019-08-19 17:02:48 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:02:48 --> Helper loaded: date_helper
INFO - 2019-08-19 17:02:48 --> Form Validation Class Initialized
INFO - 2019-08-19 17:02:48 --> Email Class Initialized
DEBUG - 2019-08-19 17:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:02:48 --> Pagination Class Initialized
INFO - 2019-08-19 17:02:48 --> Database Driver Class Initialized
INFO - 2019-08-19 17:02:48 --> Database Driver Class Initialized
INFO - 2019-08-19 17:02:48 --> Controller Class Initialized
INFO - 2019-08-19 17:02:48 --> Final output sent to browser
DEBUG - 2019-08-19 17:02:48 --> Total execution time: 0.2680
INFO - 2019-08-19 17:03:41 --> Config Class Initialized
INFO - 2019-08-19 17:03:41 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:03:41 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:03:41 --> Utf8 Class Initialized
INFO - 2019-08-19 17:03:41 --> URI Class Initialized
INFO - 2019-08-19 17:03:41 --> Router Class Initialized
INFO - 2019-08-19 17:03:41 --> Output Class Initialized
INFO - 2019-08-19 17:03:41 --> Security Class Initialized
DEBUG - 2019-08-19 17:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:03:41 --> Input Class Initialized
INFO - 2019-08-19 17:03:41 --> Language Class Initialized
INFO - 2019-08-19 17:03:41 --> Loader Class Initialized
INFO - 2019-08-19 17:03:41 --> Helper loaded: url_helper
INFO - 2019-08-19 17:03:41 --> Helper loaded: html_helper
INFO - 2019-08-19 17:03:41 --> Helper loaded: form_helper
INFO - 2019-08-19 17:03:41 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:03:41 --> Helper loaded: date_helper
INFO - 2019-08-19 17:03:41 --> Form Validation Class Initialized
INFO - 2019-08-19 17:03:41 --> Email Class Initialized
DEBUG - 2019-08-19 17:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:03:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:03:41 --> Pagination Class Initialized
INFO - 2019-08-19 17:03:41 --> Database Driver Class Initialized
INFO - 2019-08-19 17:03:41 --> Database Driver Class Initialized
INFO - 2019-08-19 17:03:41 --> Controller Class Initialized
INFO - 2019-08-19 17:03:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:03:41 --> Config Class Initialized
INFO - 2019-08-19 17:03:41 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:03:41 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:03:41 --> Utf8 Class Initialized
INFO - 2019-08-19 17:03:41 --> URI Class Initialized
INFO - 2019-08-19 17:03:41 --> Router Class Initialized
INFO - 2019-08-19 17:03:41 --> Output Class Initialized
INFO - 2019-08-19 17:03:41 --> Security Class Initialized
DEBUG - 2019-08-19 17:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:03:41 --> Input Class Initialized
INFO - 2019-08-19 17:03:41 --> Language Class Initialized
INFO - 2019-08-19 17:03:42 --> Loader Class Initialized
INFO - 2019-08-19 17:03:42 --> Helper loaded: url_helper
INFO - 2019-08-19 17:03:42 --> Helper loaded: html_helper
INFO - 2019-08-19 17:03:42 --> Helper loaded: form_helper
INFO - 2019-08-19 17:03:42 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:03:42 --> Helper loaded: date_helper
INFO - 2019-08-19 17:03:42 --> Form Validation Class Initialized
INFO - 2019-08-19 17:03:42 --> Email Class Initialized
DEBUG - 2019-08-19 17:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:03:42 --> Pagination Class Initialized
INFO - 2019-08-19 17:03:42 --> Database Driver Class Initialized
INFO - 2019-08-19 17:03:42 --> Database Driver Class Initialized
INFO - 2019-08-19 17:03:42 --> Controller Class Initialized
INFO - 2019-08-19 17:03:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:03:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomtype.php
INFO - 2019-08-19 17:03:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:03:42 --> Final output sent to browser
DEBUG - 2019-08-19 17:03:42 --> Total execution time: 0.1940
INFO - 2019-08-19 17:04:45 --> Config Class Initialized
INFO - 2019-08-19 17:04:45 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:04:45 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:04:45 --> Utf8 Class Initialized
INFO - 2019-08-19 17:04:45 --> URI Class Initialized
INFO - 2019-08-19 17:04:45 --> Router Class Initialized
INFO - 2019-08-19 17:04:45 --> Output Class Initialized
INFO - 2019-08-19 17:04:45 --> Security Class Initialized
DEBUG - 2019-08-19 17:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:04:45 --> Input Class Initialized
INFO - 2019-08-19 17:04:45 --> Language Class Initialized
INFO - 2019-08-19 17:04:45 --> Config Class Initialized
INFO - 2019-08-19 17:04:45 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:04:45 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:04:45 --> Utf8 Class Initialized
INFO - 2019-08-19 17:04:45 --> Loader Class Initialized
INFO - 2019-08-19 17:04:45 --> URI Class Initialized
INFO - 2019-08-19 17:04:45 --> Helper loaded: url_helper
INFO - 2019-08-19 17:04:45 --> Helper loaded: html_helper
INFO - 2019-08-19 17:04:45 --> Router Class Initialized
INFO - 2019-08-19 17:04:45 --> Helper loaded: form_helper
INFO - 2019-08-19 17:04:45 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:04:45 --> Output Class Initialized
INFO - 2019-08-19 17:04:45 --> Helper loaded: date_helper
INFO - 2019-08-19 17:04:45 --> Form Validation Class Initialized
INFO - 2019-08-19 17:04:45 --> Email Class Initialized
DEBUG - 2019-08-19 17:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:04:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:04:45 --> Pagination Class Initialized
INFO - 2019-08-19 17:04:45 --> Database Driver Class Initialized
INFO - 2019-08-19 17:04:45 --> Database Driver Class Initialized
INFO - 2019-08-19 17:04:45 --> Security Class Initialized
DEBUG - 2019-08-19 17:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:04:45 --> Input Class Initialized
INFO - 2019-08-19 17:04:45 --> Language Class Initialized
INFO - 2019-08-19 17:04:45 --> Loader Class Initialized
INFO - 2019-08-19 17:04:45 --> Helper loaded: url_helper
INFO - 2019-08-19 17:04:45 --> Helper loaded: html_helper
INFO - 2019-08-19 17:04:45 --> Helper loaded: form_helper
INFO - 2019-08-19 17:04:45 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:04:45 --> Helper loaded: date_helper
INFO - 2019-08-19 17:04:45 --> Form Validation Class Initialized
INFO - 2019-08-19 17:04:45 --> Email Class Initialized
DEBUG - 2019-08-19 17:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:04:45 --> Controller Class Initialized
INFO - 2019-08-19 17:04:45 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:04:45 --> Final output sent to browser
DEBUG - 2019-08-19 17:04:45 --> Total execution time: 0.2630
INFO - 2019-08-19 17:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:04:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:04:45 --> Pagination Class Initialized
INFO - 2019-08-19 17:04:45 --> Database Driver Class Initialized
INFO - 2019-08-19 17:04:45 --> Database Driver Class Initialized
INFO - 2019-08-19 17:04:45 --> Controller Class Initialized
INFO - 2019-08-19 17:04:45 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:04:45 --> Final output sent to browser
DEBUG - 2019-08-19 17:04:45 --> Total execution time: 0.3010
INFO - 2019-08-19 17:04:46 --> Config Class Initialized
INFO - 2019-08-19 17:04:46 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:04:46 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:04:46 --> Utf8 Class Initialized
INFO - 2019-08-19 17:04:46 --> URI Class Initialized
INFO - 2019-08-19 17:04:46 --> Router Class Initialized
INFO - 2019-08-19 17:04:46 --> Output Class Initialized
INFO - 2019-08-19 17:04:46 --> Security Class Initialized
DEBUG - 2019-08-19 17:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:04:46 --> Input Class Initialized
INFO - 2019-08-19 17:04:46 --> Language Class Initialized
INFO - 2019-08-19 17:04:46 --> Loader Class Initialized
INFO - 2019-08-19 17:04:46 --> Helper loaded: url_helper
INFO - 2019-08-19 17:04:46 --> Helper loaded: html_helper
INFO - 2019-08-19 17:04:46 --> Helper loaded: form_helper
INFO - 2019-08-19 17:04:46 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:04:46 --> Helper loaded: date_helper
INFO - 2019-08-19 17:04:46 --> Form Validation Class Initialized
INFO - 2019-08-19 17:04:46 --> Email Class Initialized
DEBUG - 2019-08-19 17:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:04:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:04:46 --> Pagination Class Initialized
INFO - 2019-08-19 17:04:46 --> Database Driver Class Initialized
INFO - 2019-08-19 17:04:46 --> Database Driver Class Initialized
INFO - 2019-08-19 17:04:46 --> Controller Class Initialized
INFO - 2019-08-19 17:04:46 --> Final output sent to browser
DEBUG - 2019-08-19 17:04:46 --> Total execution time: 0.2720
INFO - 2019-08-19 17:05:22 --> Config Class Initialized
INFO - 2019-08-19 17:05:22 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:05:22 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:05:22 --> Utf8 Class Initialized
INFO - 2019-08-19 17:05:22 --> URI Class Initialized
INFO - 2019-08-19 17:05:22 --> Router Class Initialized
INFO - 2019-08-19 17:05:22 --> Output Class Initialized
INFO - 2019-08-19 17:05:22 --> Security Class Initialized
DEBUG - 2019-08-19 17:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:05:22 --> Input Class Initialized
INFO - 2019-08-19 17:05:22 --> Language Class Initialized
INFO - 2019-08-19 17:05:22 --> Loader Class Initialized
INFO - 2019-08-19 17:05:22 --> Helper loaded: url_helper
INFO - 2019-08-19 17:05:22 --> Helper loaded: html_helper
INFO - 2019-08-19 17:05:22 --> Helper loaded: form_helper
INFO - 2019-08-19 17:05:22 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:05:22 --> Helper loaded: date_helper
INFO - 2019-08-19 17:05:22 --> Form Validation Class Initialized
INFO - 2019-08-19 17:05:22 --> Email Class Initialized
DEBUG - 2019-08-19 17:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:05:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:05:22 --> Pagination Class Initialized
INFO - 2019-08-19 17:05:22 --> Database Driver Class Initialized
INFO - 2019-08-19 17:05:22 --> Database Driver Class Initialized
INFO - 2019-08-19 17:05:22 --> Controller Class Initialized
INFO - 2019-08-19 17:05:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:05:22 --> Config Class Initialized
INFO - 2019-08-19 17:05:22 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:05:22 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:05:22 --> Utf8 Class Initialized
INFO - 2019-08-19 17:05:22 --> URI Class Initialized
INFO - 2019-08-19 17:05:22 --> Router Class Initialized
INFO - 2019-08-19 17:05:22 --> Output Class Initialized
INFO - 2019-08-19 17:05:22 --> Security Class Initialized
DEBUG - 2019-08-19 17:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:05:22 --> Input Class Initialized
INFO - 2019-08-19 17:05:22 --> Language Class Initialized
INFO - 2019-08-19 17:05:22 --> Loader Class Initialized
INFO - 2019-08-19 17:05:22 --> Helper loaded: url_helper
INFO - 2019-08-19 17:05:22 --> Helper loaded: html_helper
INFO - 2019-08-19 17:05:22 --> Helper loaded: form_helper
INFO - 2019-08-19 17:05:22 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:05:22 --> Helper loaded: date_helper
INFO - 2019-08-19 17:05:22 --> Form Validation Class Initialized
INFO - 2019-08-19 17:05:22 --> Email Class Initialized
DEBUG - 2019-08-19 17:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:05:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:05:22 --> Pagination Class Initialized
INFO - 2019-08-19 17:05:22 --> Database Driver Class Initialized
INFO - 2019-08-19 17:05:22 --> Database Driver Class Initialized
INFO - 2019-08-19 17:05:22 --> Controller Class Initialized
INFO - 2019-08-19 17:05:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:05:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomtype.php
INFO - 2019-08-19 17:05:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:05:22 --> Final output sent to browser
DEBUG - 2019-08-19 17:05:22 --> Total execution time: 0.1800
INFO - 2019-08-19 17:06:04 --> Config Class Initialized
INFO - 2019-08-19 17:06:04 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:06:04 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:06:04 --> Utf8 Class Initialized
INFO - 2019-08-19 17:06:04 --> URI Class Initialized
INFO - 2019-08-19 17:06:04 --> Router Class Initialized
INFO - 2019-08-19 17:06:04 --> Output Class Initialized
INFO - 2019-08-19 17:06:04 --> Security Class Initialized
DEBUG - 2019-08-19 17:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:06:04 --> Input Class Initialized
INFO - 2019-08-19 17:06:04 --> Language Class Initialized
INFO - 2019-08-19 17:06:04 --> Config Class Initialized
INFO - 2019-08-19 17:06:04 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:06:04 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:06:04 --> Utf8 Class Initialized
INFO - 2019-08-19 17:06:04 --> Loader Class Initialized
INFO - 2019-08-19 17:06:04 --> Helper loaded: url_helper
INFO - 2019-08-19 17:06:04 --> Helper loaded: html_helper
INFO - 2019-08-19 17:06:04 --> Helper loaded: form_helper
INFO - 2019-08-19 17:06:04 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:06:04 --> Helper loaded: date_helper
INFO - 2019-08-19 17:06:04 --> URI Class Initialized
INFO - 2019-08-19 17:06:04 --> Router Class Initialized
INFO - 2019-08-19 17:06:04 --> Output Class Initialized
INFO - 2019-08-19 17:06:04 --> Security Class Initialized
DEBUG - 2019-08-19 17:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:06:04 --> Input Class Initialized
INFO - 2019-08-19 17:06:04 --> Language Class Initialized
INFO - 2019-08-19 17:06:04 --> Form Validation Class Initialized
INFO - 2019-08-19 17:06:04 --> Email Class Initialized
DEBUG - 2019-08-19 17:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:06:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:06:04 --> Pagination Class Initialized
INFO - 2019-08-19 17:06:04 --> Loader Class Initialized
INFO - 2019-08-19 17:06:04 --> Helper loaded: url_helper
INFO - 2019-08-19 17:06:04 --> Helper loaded: html_helper
INFO - 2019-08-19 17:06:04 --> Helper loaded: form_helper
INFO - 2019-08-19 17:06:04 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:06:04 --> Helper loaded: date_helper
INFO - 2019-08-19 17:06:04 --> Form Validation Class Initialized
INFO - 2019-08-19 17:06:04 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:04 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:04 --> Email Class Initialized
DEBUG - 2019-08-19 17:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:06:04 --> Controller Class Initialized
INFO - 2019-08-19 17:06:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:06:04 --> Final output sent to browser
DEBUG - 2019-08-19 17:06:04 --> Total execution time: 0.3178
INFO - 2019-08-19 17:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:06:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:06:05 --> Pagination Class Initialized
INFO - 2019-08-19 17:06:05 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:05 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:05 --> Controller Class Initialized
INFO - 2019-08-19 17:06:05 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:06:05 --> Final output sent to browser
DEBUG - 2019-08-19 17:06:05 --> Total execution time: 0.3484
INFO - 2019-08-19 17:06:05 --> Config Class Initialized
INFO - 2019-08-19 17:06:05 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:06:05 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:06:05 --> Utf8 Class Initialized
INFO - 2019-08-19 17:06:05 --> URI Class Initialized
INFO - 2019-08-19 17:06:05 --> Router Class Initialized
INFO - 2019-08-19 17:06:05 --> Output Class Initialized
INFO - 2019-08-19 17:06:05 --> Security Class Initialized
DEBUG - 2019-08-19 17:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:06:05 --> Input Class Initialized
INFO - 2019-08-19 17:06:05 --> Language Class Initialized
INFO - 2019-08-19 17:06:05 --> Loader Class Initialized
INFO - 2019-08-19 17:06:05 --> Helper loaded: url_helper
INFO - 2019-08-19 17:06:05 --> Helper loaded: html_helper
INFO - 2019-08-19 17:06:05 --> Helper loaded: form_helper
INFO - 2019-08-19 17:06:05 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:06:05 --> Helper loaded: date_helper
INFO - 2019-08-19 17:06:05 --> Form Validation Class Initialized
INFO - 2019-08-19 17:06:05 --> Email Class Initialized
DEBUG - 2019-08-19 17:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:06:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:06:05 --> Pagination Class Initialized
INFO - 2019-08-19 17:06:05 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:05 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:05 --> Controller Class Initialized
INFO - 2019-08-19 17:06:05 --> Final output sent to browser
DEBUG - 2019-08-19 17:06:05 --> Total execution time: 0.2496
INFO - 2019-08-19 17:06:12 --> Config Class Initialized
INFO - 2019-08-19 17:06:12 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:06:12 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:06:12 --> Utf8 Class Initialized
INFO - 2019-08-19 17:06:12 --> URI Class Initialized
INFO - 2019-08-19 17:06:12 --> Router Class Initialized
INFO - 2019-08-19 17:06:12 --> Output Class Initialized
INFO - 2019-08-19 17:06:12 --> Security Class Initialized
DEBUG - 2019-08-19 17:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:06:12 --> Input Class Initialized
INFO - 2019-08-19 17:06:12 --> Language Class Initialized
INFO - 2019-08-19 17:06:12 --> Loader Class Initialized
INFO - 2019-08-19 17:06:12 --> Helper loaded: url_helper
INFO - 2019-08-19 17:06:12 --> Helper loaded: html_helper
INFO - 2019-08-19 17:06:12 --> Helper loaded: form_helper
INFO - 2019-08-19 17:06:12 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:06:12 --> Helper loaded: date_helper
INFO - 2019-08-19 17:06:12 --> Form Validation Class Initialized
INFO - 2019-08-19 17:06:12 --> Email Class Initialized
DEBUG - 2019-08-19 17:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:06:12 --> Pagination Class Initialized
INFO - 2019-08-19 17:06:12 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:12 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:12 --> Controller Class Initialized
INFO - 2019-08-19 17:06:13 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:06:13 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomclass.php
INFO - 2019-08-19 17:06:13 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:06:13 --> Final output sent to browser
DEBUG - 2019-08-19 17:06:13 --> Total execution time: 0.1910
INFO - 2019-08-19 17:06:17 --> Config Class Initialized
INFO - 2019-08-19 17:06:17 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:06:17 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:06:17 --> Utf8 Class Initialized
INFO - 2019-08-19 17:06:18 --> URI Class Initialized
INFO - 2019-08-19 17:06:18 --> Router Class Initialized
INFO - 2019-08-19 17:06:18 --> Output Class Initialized
INFO - 2019-08-19 17:06:18 --> Security Class Initialized
DEBUG - 2019-08-19 17:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:06:18 --> Input Class Initialized
INFO - 2019-08-19 17:06:18 --> Language Class Initialized
INFO - 2019-08-19 17:06:18 --> Loader Class Initialized
INFO - 2019-08-19 17:06:18 --> Helper loaded: url_helper
INFO - 2019-08-19 17:06:18 --> Helper loaded: html_helper
INFO - 2019-08-19 17:06:18 --> Helper loaded: form_helper
INFO - 2019-08-19 17:06:18 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:06:18 --> Helper loaded: date_helper
INFO - 2019-08-19 17:06:18 --> Form Validation Class Initialized
INFO - 2019-08-19 17:06:18 --> Email Class Initialized
DEBUG - 2019-08-19 17:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:06:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:06:18 --> Pagination Class Initialized
INFO - 2019-08-19 17:06:18 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:18 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:18 --> Controller Class Initialized
INFO - 2019-08-19 17:06:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:06:18 --> Final output sent to browser
DEBUG - 2019-08-19 17:06:18 --> Total execution time: 0.1990
INFO - 2019-08-19 17:06:44 --> Config Class Initialized
INFO - 2019-08-19 17:06:44 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:06:44 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:06:44 --> Utf8 Class Initialized
INFO - 2019-08-19 17:06:44 --> Config Class Initialized
INFO - 2019-08-19 17:06:44 --> Hooks Class Initialized
INFO - 2019-08-19 17:06:44 --> URI Class Initialized
DEBUG - 2019-08-19 17:06:44 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:06:44 --> Utf8 Class Initialized
INFO - 2019-08-19 17:06:44 --> Router Class Initialized
INFO - 2019-08-19 17:06:44 --> URI Class Initialized
INFO - 2019-08-19 17:06:44 --> Output Class Initialized
INFO - 2019-08-19 17:06:44 --> Security Class Initialized
INFO - 2019-08-19 17:06:44 --> Router Class Initialized
DEBUG - 2019-08-19 17:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:06:44 --> Input Class Initialized
INFO - 2019-08-19 17:06:44 --> Output Class Initialized
INFO - 2019-08-19 17:06:44 --> Language Class Initialized
INFO - 2019-08-19 17:06:44 --> Security Class Initialized
DEBUG - 2019-08-19 17:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:06:44 --> Input Class Initialized
INFO - 2019-08-19 17:06:44 --> Language Class Initialized
INFO - 2019-08-19 17:06:44 --> Loader Class Initialized
INFO - 2019-08-19 17:06:44 --> Config Class Initialized
INFO - 2019-08-19 17:06:44 --> Hooks Class Initialized
INFO - 2019-08-19 17:06:44 --> Helper loaded: url_helper
INFO - 2019-08-19 17:06:44 --> Helper loaded: html_helper
DEBUG - 2019-08-19 17:06:44 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:06:44 --> Utf8 Class Initialized
INFO - 2019-08-19 17:06:44 --> Helper loaded: form_helper
INFO - 2019-08-19 17:06:44 --> URI Class Initialized
INFO - 2019-08-19 17:06:44 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:06:44 --> Helper loaded: date_helper
INFO - 2019-08-19 17:06:44 --> Router Class Initialized
INFO - 2019-08-19 17:06:44 --> Form Validation Class Initialized
INFO - 2019-08-19 17:06:44 --> Output Class Initialized
INFO - 2019-08-19 17:06:44 --> Security Class Initialized
INFO - 2019-08-19 17:06:44 --> Email Class Initialized
DEBUG - 2019-08-19 17:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:06:44 --> Input Class Initialized
INFO - 2019-08-19 17:06:44 --> Language Class Initialized
DEBUG - 2019-08-19 17:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:06:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:06:44 --> Pagination Class Initialized
INFO - 2019-08-19 17:06:44 --> Loader Class Initialized
INFO - 2019-08-19 17:06:44 --> Helper loaded: url_helper
INFO - 2019-08-19 17:06:44 --> Helper loaded: html_helper
INFO - 2019-08-19 17:06:44 --> Helper loaded: form_helper
INFO - 2019-08-19 17:06:44 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:06:44 --> Helper loaded: date_helper
INFO - 2019-08-19 17:06:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:44 --> Form Validation Class Initialized
INFO - 2019-08-19 17:06:44 --> Email Class Initialized
DEBUG - 2019-08-19 17:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:06:44 --> Controller Class Initialized
INFO - 2019-08-19 17:06:44 --> Loader Class Initialized
INFO - 2019-08-19 17:06:44 --> Helper loaded: url_helper
INFO - 2019-08-19 17:06:44 --> Helper loaded: html_helper
INFO - 2019-08-19 17:06:44 --> Helper loaded: form_helper
INFO - 2019-08-19 17:06:44 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:06:44 --> Helper loaded: date_helper
INFO - 2019-08-19 17:06:44 --> Form Validation Class Initialized
INFO - 2019-08-19 17:06:44 --> Email Class Initialized
DEBUG - 2019-08-19 17:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:06:44 --> Config Class Initialized
INFO - 2019-08-19 17:06:44 --> Hooks Class Initialized
INFO - 2019-08-19 17:06:44 --> Final output sent to browser
DEBUG - 2019-08-19 17:06:44 --> Total execution time: 0.2740
DEBUG - 2019-08-19 17:06:44 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:06:44 --> Utf8 Class Initialized
INFO - 2019-08-19 17:06:44 --> URI Class Initialized
INFO - 2019-08-19 17:06:44 --> Router Class Initialized
INFO - 2019-08-19 17:06:44 --> Output Class Initialized
INFO - 2019-08-19 17:06:44 --> Security Class Initialized
DEBUG - 2019-08-19 17:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:06:44 --> Input Class Initialized
INFO - 2019-08-19 17:06:44 --> Language Class Initialized
INFO - 2019-08-19 17:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:06:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:06:44 --> Pagination Class Initialized
INFO - 2019-08-19 17:06:44 --> Loader Class Initialized
INFO - 2019-08-19 17:06:44 --> Helper loaded: url_helper
INFO - 2019-08-19 17:06:44 --> Helper loaded: html_helper
INFO - 2019-08-19 17:06:44 --> Helper loaded: form_helper
INFO - 2019-08-19 17:06:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:44 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:06:44 --> Controller Class Initialized
INFO - 2019-08-19 17:06:44 --> Helper loaded: date_helper
INFO - 2019-08-19 17:06:44 --> Form Validation Class Initialized
INFO - 2019-08-19 17:06:44 --> Email Class Initialized
DEBUG - 2019-08-19 17:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:06:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:06:44 --> Final output sent to browser
DEBUG - 2019-08-19 17:06:44 --> Total execution time: 0.3970
INFO - 2019-08-19 17:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:06:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:06:44 --> Pagination Class Initialized
INFO - 2019-08-19 17:06:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:44 --> Controller Class Initialized
INFO - 2019-08-19 17:06:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:06:44 --> Final output sent to browser
DEBUG - 2019-08-19 17:06:44 --> Total execution time: 0.5660
INFO - 2019-08-19 17:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:06:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:06:44 --> Pagination Class Initialized
INFO - 2019-08-19 17:06:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:44 --> Controller Class Initialized
INFO - 2019-08-19 17:06:45 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:06:45 --> Final output sent to browser
DEBUG - 2019-08-19 17:06:45 --> Total execution time: 0.4008
INFO - 2019-08-19 17:06:50 --> Config Class Initialized
INFO - 2019-08-19 17:06:50 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:06:50 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:06:50 --> Utf8 Class Initialized
INFO - 2019-08-19 17:06:50 --> URI Class Initialized
INFO - 2019-08-19 17:06:50 --> Router Class Initialized
INFO - 2019-08-19 17:06:50 --> Output Class Initialized
INFO - 2019-08-19 17:06:50 --> Security Class Initialized
DEBUG - 2019-08-19 17:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:06:50 --> Input Class Initialized
INFO - 2019-08-19 17:06:50 --> Language Class Initialized
INFO - 2019-08-19 17:06:50 --> Loader Class Initialized
INFO - 2019-08-19 17:06:50 --> Helper loaded: url_helper
INFO - 2019-08-19 17:06:50 --> Helper loaded: html_helper
INFO - 2019-08-19 17:06:50 --> Helper loaded: form_helper
INFO - 2019-08-19 17:06:50 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:06:50 --> Helper loaded: date_helper
INFO - 2019-08-19 17:06:50 --> Form Validation Class Initialized
INFO - 2019-08-19 17:06:50 --> Email Class Initialized
DEBUG - 2019-08-19 17:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:06:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:06:50 --> Pagination Class Initialized
INFO - 2019-08-19 17:06:50 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:50 --> Database Driver Class Initialized
INFO - 2019-08-19 17:06:50 --> Controller Class Initialized
INFO - 2019-08-19 17:06:50 --> Final output sent to browser
DEBUG - 2019-08-19 17:06:50 --> Total execution time: 0.2180
INFO - 2019-08-19 17:07:09 --> Config Class Initialized
INFO - 2019-08-19 17:07:09 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:07:09 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:07:09 --> Utf8 Class Initialized
INFO - 2019-08-19 17:07:09 --> URI Class Initialized
INFO - 2019-08-19 17:07:09 --> Router Class Initialized
INFO - 2019-08-19 17:07:09 --> Output Class Initialized
INFO - 2019-08-19 17:07:09 --> Security Class Initialized
DEBUG - 2019-08-19 17:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:07:09 --> Input Class Initialized
INFO - 2019-08-19 17:07:09 --> Language Class Initialized
INFO - 2019-08-19 17:07:09 --> Loader Class Initialized
INFO - 2019-08-19 17:07:09 --> Helper loaded: url_helper
INFO - 2019-08-19 17:07:09 --> Helper loaded: html_helper
INFO - 2019-08-19 17:07:09 --> Helper loaded: form_helper
INFO - 2019-08-19 17:07:09 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:07:09 --> Helper loaded: date_helper
INFO - 2019-08-19 17:07:09 --> Form Validation Class Initialized
INFO - 2019-08-19 17:07:09 --> Email Class Initialized
DEBUG - 2019-08-19 17:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:07:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:07:09 --> Pagination Class Initialized
INFO - 2019-08-19 17:07:09 --> Database Driver Class Initialized
INFO - 2019-08-19 17:07:09 --> Database Driver Class Initialized
INFO - 2019-08-19 17:07:09 --> Controller Class Initialized
INFO - 2019-08-19 17:07:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:07:09 --> Config Class Initialized
INFO - 2019-08-19 17:07:09 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:07:09 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:07:09 --> Utf8 Class Initialized
INFO - 2019-08-19 17:07:09 --> URI Class Initialized
INFO - 2019-08-19 17:07:09 --> Router Class Initialized
INFO - 2019-08-19 17:07:09 --> Output Class Initialized
INFO - 2019-08-19 17:07:09 --> Security Class Initialized
DEBUG - 2019-08-19 17:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:07:09 --> Input Class Initialized
INFO - 2019-08-19 17:07:09 --> Language Class Initialized
INFO - 2019-08-19 17:07:09 --> Loader Class Initialized
INFO - 2019-08-19 17:07:09 --> Helper loaded: url_helper
INFO - 2019-08-19 17:07:09 --> Helper loaded: html_helper
INFO - 2019-08-19 17:07:09 --> Helper loaded: form_helper
INFO - 2019-08-19 17:07:09 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:07:09 --> Helper loaded: date_helper
INFO - 2019-08-19 17:07:09 --> Form Validation Class Initialized
INFO - 2019-08-19 17:07:09 --> Email Class Initialized
DEBUG - 2019-08-19 17:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:07:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:07:09 --> Pagination Class Initialized
INFO - 2019-08-19 17:07:09 --> Database Driver Class Initialized
INFO - 2019-08-19 17:07:09 --> Database Driver Class Initialized
INFO - 2019-08-19 17:07:10 --> Controller Class Initialized
INFO - 2019-08-19 17:07:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:07:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomclass.php
INFO - 2019-08-19 17:07:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:07:10 --> Final output sent to browser
DEBUG - 2019-08-19 17:07:10 --> Total execution time: 0.1860
INFO - 2019-08-19 17:07:37 --> Config Class Initialized
INFO - 2019-08-19 17:07:37 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:07:37 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:07:37 --> Utf8 Class Initialized
INFO - 2019-08-19 17:07:37 --> URI Class Initialized
INFO - 2019-08-19 17:07:37 --> Router Class Initialized
INFO - 2019-08-19 17:07:37 --> Output Class Initialized
INFO - 2019-08-19 17:07:37 --> Security Class Initialized
DEBUG - 2019-08-19 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:07:37 --> Input Class Initialized
INFO - 2019-08-19 17:07:37 --> Language Class Initialized
INFO - 2019-08-19 17:07:37 --> Loader Class Initialized
INFO - 2019-08-19 17:07:37 --> Helper loaded: url_helper
INFO - 2019-08-19 17:07:37 --> Helper loaded: html_helper
INFO - 2019-08-19 17:07:37 --> Helper loaded: form_helper
INFO - 2019-08-19 17:07:37 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:07:37 --> Helper loaded: date_helper
INFO - 2019-08-19 17:07:37 --> Form Validation Class Initialized
INFO - 2019-08-19 17:07:37 --> Email Class Initialized
DEBUG - 2019-08-19 17:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:07:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:07:37 --> Pagination Class Initialized
INFO - 2019-08-19 17:07:37 --> Config Class Initialized
INFO - 2019-08-19 17:07:37 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:07:37 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:07:37 --> Utf8 Class Initialized
INFO - 2019-08-19 17:07:37 --> URI Class Initialized
INFO - 2019-08-19 17:07:37 --> Router Class Initialized
INFO - 2019-08-19 17:07:37 --> Output Class Initialized
INFO - 2019-08-19 17:07:37 --> Security Class Initialized
DEBUG - 2019-08-19 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:07:37 --> Input Class Initialized
INFO - 2019-08-19 17:07:37 --> Language Class Initialized
INFO - 2019-08-19 17:07:37 --> Database Driver Class Initialized
INFO - 2019-08-19 17:07:37 --> Database Driver Class Initialized
INFO - 2019-08-19 17:07:37 --> Loader Class Initialized
INFO - 2019-08-19 17:07:37 --> Helper loaded: url_helper
INFO - 2019-08-19 17:07:37 --> Helper loaded: html_helper
INFO - 2019-08-19 17:07:37 --> Helper loaded: form_helper
INFO - 2019-08-19 17:07:37 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:07:37 --> Helper loaded: date_helper
INFO - 2019-08-19 17:07:37 --> Form Validation Class Initialized
INFO - 2019-08-19 17:07:37 --> Email Class Initialized
DEBUG - 2019-08-19 17:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:07:37 --> Controller Class Initialized
INFO - 2019-08-19 17:07:37 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:07:37 --> Final output sent to browser
DEBUG - 2019-08-19 17:07:37 --> Total execution time: 0.2770
INFO - 2019-08-19 17:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:07:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:07:37 --> Pagination Class Initialized
INFO - 2019-08-19 17:07:37 --> Database Driver Class Initialized
INFO - 2019-08-19 17:07:37 --> Database Driver Class Initialized
INFO - 2019-08-19 17:07:37 --> Controller Class Initialized
INFO - 2019-08-19 17:07:37 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:07:37 --> Final output sent to browser
DEBUG - 2019-08-19 17:07:37 --> Total execution time: 0.2718
INFO - 2019-08-19 17:07:38 --> Config Class Initialized
INFO - 2019-08-19 17:07:38 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:07:38 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:07:38 --> Utf8 Class Initialized
INFO - 2019-08-19 17:07:38 --> URI Class Initialized
INFO - 2019-08-19 17:07:38 --> Router Class Initialized
INFO - 2019-08-19 17:07:38 --> Output Class Initialized
INFO - 2019-08-19 17:07:38 --> Security Class Initialized
DEBUG - 2019-08-19 17:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:07:38 --> Input Class Initialized
INFO - 2019-08-19 17:07:38 --> Language Class Initialized
INFO - 2019-08-19 17:07:38 --> Loader Class Initialized
INFO - 2019-08-19 17:07:38 --> Helper loaded: url_helper
INFO - 2019-08-19 17:07:38 --> Helper loaded: html_helper
INFO - 2019-08-19 17:07:38 --> Helper loaded: form_helper
INFO - 2019-08-19 17:07:38 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:07:38 --> Helper loaded: date_helper
INFO - 2019-08-19 17:07:38 --> Form Validation Class Initialized
INFO - 2019-08-19 17:07:38 --> Email Class Initialized
DEBUG - 2019-08-19 17:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:07:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:07:38 --> Pagination Class Initialized
INFO - 2019-08-19 17:07:38 --> Database Driver Class Initialized
INFO - 2019-08-19 17:07:38 --> Database Driver Class Initialized
INFO - 2019-08-19 17:07:38 --> Controller Class Initialized
INFO - 2019-08-19 17:07:38 --> Final output sent to browser
DEBUG - 2019-08-19 17:07:38 --> Total execution time: 0.2650
INFO - 2019-08-19 17:07:46 --> Config Class Initialized
INFO - 2019-08-19 17:07:46 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:07:46 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:07:46 --> Utf8 Class Initialized
INFO - 2019-08-19 17:07:46 --> URI Class Initialized
INFO - 2019-08-19 17:07:46 --> Router Class Initialized
INFO - 2019-08-19 17:07:46 --> Output Class Initialized
INFO - 2019-08-19 17:07:46 --> Security Class Initialized
DEBUG - 2019-08-19 17:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:07:46 --> Input Class Initialized
INFO - 2019-08-19 17:07:46 --> Language Class Initialized
INFO - 2019-08-19 17:07:46 --> Loader Class Initialized
INFO - 2019-08-19 17:07:46 --> Helper loaded: url_helper
INFO - 2019-08-19 17:07:46 --> Helper loaded: html_helper
INFO - 2019-08-19 17:07:46 --> Helper loaded: form_helper
INFO - 2019-08-19 17:07:46 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:07:46 --> Helper loaded: date_helper
INFO - 2019-08-19 17:07:46 --> Form Validation Class Initialized
INFO - 2019-08-19 17:07:46 --> Email Class Initialized
DEBUG - 2019-08-19 17:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:07:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:07:46 --> Pagination Class Initialized
INFO - 2019-08-19 17:07:46 --> Database Driver Class Initialized
INFO - 2019-08-19 17:07:46 --> Database Driver Class Initialized
INFO - 2019-08-19 17:07:46 --> Controller Class Initialized
INFO - 2019-08-19 17:07:46 --> Final output sent to browser
DEBUG - 2019-08-19 17:07:46 --> Total execution time: 0.2458
INFO - 2019-08-19 17:08:10 --> Config Class Initialized
INFO - 2019-08-19 17:08:10 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:08:10 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:08:10 --> Utf8 Class Initialized
INFO - 2019-08-19 17:08:10 --> URI Class Initialized
INFO - 2019-08-19 17:08:10 --> Router Class Initialized
INFO - 2019-08-19 17:08:10 --> Output Class Initialized
INFO - 2019-08-19 17:08:10 --> Security Class Initialized
DEBUG - 2019-08-19 17:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:08:10 --> Input Class Initialized
INFO - 2019-08-19 17:08:10 --> Language Class Initialized
INFO - 2019-08-19 17:08:10 --> Loader Class Initialized
INFO - 2019-08-19 17:08:10 --> Helper loaded: url_helper
INFO - 2019-08-19 17:08:10 --> Helper loaded: html_helper
INFO - 2019-08-19 17:08:10 --> Helper loaded: form_helper
INFO - 2019-08-19 17:08:10 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:08:10 --> Helper loaded: date_helper
INFO - 2019-08-19 17:08:10 --> Form Validation Class Initialized
INFO - 2019-08-19 17:08:10 --> Email Class Initialized
DEBUG - 2019-08-19 17:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:08:10 --> Pagination Class Initialized
INFO - 2019-08-19 17:08:10 --> Database Driver Class Initialized
INFO - 2019-08-19 17:08:10 --> Database Driver Class Initialized
INFO - 2019-08-19 17:08:10 --> Controller Class Initialized
INFO - 2019-08-19 17:08:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:08:10 --> Config Class Initialized
INFO - 2019-08-19 17:08:10 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:08:10 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:08:10 --> Utf8 Class Initialized
INFO - 2019-08-19 17:08:10 --> URI Class Initialized
INFO - 2019-08-19 17:08:10 --> Router Class Initialized
INFO - 2019-08-19 17:08:10 --> Output Class Initialized
INFO - 2019-08-19 17:08:10 --> Security Class Initialized
DEBUG - 2019-08-19 17:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:08:10 --> Input Class Initialized
INFO - 2019-08-19 17:08:10 --> Language Class Initialized
INFO - 2019-08-19 17:08:10 --> Loader Class Initialized
INFO - 2019-08-19 17:08:10 --> Helper loaded: url_helper
INFO - 2019-08-19 17:08:10 --> Helper loaded: html_helper
INFO - 2019-08-19 17:08:10 --> Helper loaded: form_helper
INFO - 2019-08-19 17:08:10 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:08:10 --> Helper loaded: date_helper
INFO - 2019-08-19 17:08:10 --> Form Validation Class Initialized
INFO - 2019-08-19 17:08:10 --> Email Class Initialized
DEBUG - 2019-08-19 17:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:08:10 --> Pagination Class Initialized
INFO - 2019-08-19 17:08:10 --> Database Driver Class Initialized
INFO - 2019-08-19 17:08:10 --> Database Driver Class Initialized
INFO - 2019-08-19 17:08:10 --> Controller Class Initialized
INFO - 2019-08-19 17:08:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:08:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomclass.php
INFO - 2019-08-19 17:08:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:08:10 --> Final output sent to browser
DEBUG - 2019-08-19 17:08:10 --> Total execution time: 0.1950
INFO - 2019-08-19 17:08:52 --> Config Class Initialized
INFO - 2019-08-19 17:08:52 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:08:52 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:08:52 --> Utf8 Class Initialized
INFO - 2019-08-19 17:08:52 --> URI Class Initialized
INFO - 2019-08-19 17:08:52 --> Router Class Initialized
INFO - 2019-08-19 17:08:52 --> Output Class Initialized
INFO - 2019-08-19 17:08:52 --> Security Class Initialized
DEBUG - 2019-08-19 17:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:08:52 --> Input Class Initialized
INFO - 2019-08-19 17:08:52 --> Language Class Initialized
INFO - 2019-08-19 17:08:52 --> Loader Class Initialized
INFO - 2019-08-19 17:08:52 --> Helper loaded: url_helper
INFO - 2019-08-19 17:08:52 --> Helper loaded: html_helper
INFO - 2019-08-19 17:08:52 --> Config Class Initialized
INFO - 2019-08-19 17:08:52 --> Hooks Class Initialized
INFO - 2019-08-19 17:08:52 --> Helper loaded: form_helper
INFO - 2019-08-19 17:08:52 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:08:52 --> Helper loaded: date_helper
DEBUG - 2019-08-19 17:08:52 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:08:52 --> Utf8 Class Initialized
INFO - 2019-08-19 17:08:52 --> URI Class Initialized
INFO - 2019-08-19 17:08:52 --> Form Validation Class Initialized
INFO - 2019-08-19 17:08:52 --> Router Class Initialized
INFO - 2019-08-19 17:08:52 --> Email Class Initialized
INFO - 2019-08-19 17:08:52 --> Output Class Initialized
DEBUG - 2019-08-19 17:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:08:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:08:52 --> Pagination Class Initialized
INFO - 2019-08-19 17:08:52 --> Database Driver Class Initialized
INFO - 2019-08-19 17:08:52 --> Database Driver Class Initialized
INFO - 2019-08-19 17:08:52 --> Security Class Initialized
DEBUG - 2019-08-19 17:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:08:52 --> Input Class Initialized
INFO - 2019-08-19 17:08:52 --> Language Class Initialized
INFO - 2019-08-19 17:08:52 --> Loader Class Initialized
INFO - 2019-08-19 17:08:52 --> Helper loaded: url_helper
INFO - 2019-08-19 17:08:52 --> Helper loaded: html_helper
INFO - 2019-08-19 17:08:52 --> Helper loaded: form_helper
INFO - 2019-08-19 17:08:52 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:08:52 --> Helper loaded: date_helper
INFO - 2019-08-19 17:08:52 --> Form Validation Class Initialized
INFO - 2019-08-19 17:08:52 --> Email Class Initialized
DEBUG - 2019-08-19 17:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:08:52 --> Controller Class Initialized
INFO - 2019-08-19 17:08:52 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:08:52 --> Final output sent to browser
DEBUG - 2019-08-19 17:08:52 --> Total execution time: 0.2492
INFO - 2019-08-19 17:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:08:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:08:52 --> Pagination Class Initialized
INFO - 2019-08-19 17:08:52 --> Database Driver Class Initialized
INFO - 2019-08-19 17:08:52 --> Database Driver Class Initialized
INFO - 2019-08-19 17:08:52 --> Controller Class Initialized
INFO - 2019-08-19 17:08:52 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:08:52 --> Final output sent to browser
DEBUG - 2019-08-19 17:08:52 --> Total execution time: 0.3044
INFO - 2019-08-19 17:08:53 --> Config Class Initialized
INFO - 2019-08-19 17:08:53 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:08:53 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:08:53 --> Utf8 Class Initialized
INFO - 2019-08-19 17:08:53 --> URI Class Initialized
INFO - 2019-08-19 17:08:53 --> Router Class Initialized
INFO - 2019-08-19 17:08:53 --> Output Class Initialized
INFO - 2019-08-19 17:08:53 --> Security Class Initialized
DEBUG - 2019-08-19 17:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:08:53 --> Input Class Initialized
INFO - 2019-08-19 17:08:53 --> Language Class Initialized
INFO - 2019-08-19 17:08:53 --> Loader Class Initialized
INFO - 2019-08-19 17:08:53 --> Helper loaded: url_helper
INFO - 2019-08-19 17:08:53 --> Helper loaded: html_helper
INFO - 2019-08-19 17:08:53 --> Helper loaded: form_helper
INFO - 2019-08-19 17:08:53 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:08:53 --> Helper loaded: date_helper
INFO - 2019-08-19 17:08:53 --> Form Validation Class Initialized
INFO - 2019-08-19 17:08:53 --> Email Class Initialized
DEBUG - 2019-08-19 17:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:08:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:08:53 --> Pagination Class Initialized
INFO - 2019-08-19 17:08:53 --> Database Driver Class Initialized
INFO - 2019-08-19 17:08:53 --> Database Driver Class Initialized
INFO - 2019-08-19 17:08:53 --> Controller Class Initialized
INFO - 2019-08-19 17:08:53 --> Final output sent to browser
DEBUG - 2019-08-19 17:08:53 --> Total execution time: 0.2780
INFO - 2019-08-19 17:08:57 --> Config Class Initialized
INFO - 2019-08-19 17:08:57 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:08:57 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:08:57 --> Utf8 Class Initialized
INFO - 2019-08-19 17:08:57 --> URI Class Initialized
INFO - 2019-08-19 17:08:57 --> Router Class Initialized
INFO - 2019-08-19 17:08:57 --> Output Class Initialized
INFO - 2019-08-19 17:08:57 --> Security Class Initialized
DEBUG - 2019-08-19 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:08:57 --> Input Class Initialized
INFO - 2019-08-19 17:08:57 --> Language Class Initialized
INFO - 2019-08-19 17:08:57 --> Loader Class Initialized
INFO - 2019-08-19 17:08:57 --> Helper loaded: url_helper
INFO - 2019-08-19 17:08:57 --> Helper loaded: html_helper
INFO - 2019-08-19 17:08:57 --> Helper loaded: form_helper
INFO - 2019-08-19 17:08:57 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:08:57 --> Helper loaded: date_helper
INFO - 2019-08-19 17:08:57 --> Form Validation Class Initialized
INFO - 2019-08-19 17:08:57 --> Email Class Initialized
DEBUG - 2019-08-19 17:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:08:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:08:57 --> Pagination Class Initialized
INFO - 2019-08-19 17:08:57 --> Database Driver Class Initialized
INFO - 2019-08-19 17:08:57 --> Database Driver Class Initialized
INFO - 2019-08-19 17:08:57 --> Controller Class Initialized
INFO - 2019-08-19 17:08:57 --> Final output sent to browser
DEBUG - 2019-08-19 17:08:57 --> Total execution time: 0.2250
INFO - 2019-08-19 17:09:32 --> Config Class Initialized
INFO - 2019-08-19 17:09:32 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:09:32 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:09:32 --> Utf8 Class Initialized
INFO - 2019-08-19 17:09:32 --> URI Class Initialized
INFO - 2019-08-19 17:09:32 --> Router Class Initialized
INFO - 2019-08-19 17:09:32 --> Output Class Initialized
INFO - 2019-08-19 17:09:32 --> Security Class Initialized
DEBUG - 2019-08-19 17:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:09:32 --> Input Class Initialized
INFO - 2019-08-19 17:09:32 --> Language Class Initialized
INFO - 2019-08-19 17:09:32 --> Loader Class Initialized
INFO - 2019-08-19 17:09:32 --> Helper loaded: url_helper
INFO - 2019-08-19 17:09:32 --> Helper loaded: html_helper
INFO - 2019-08-19 17:09:32 --> Helper loaded: form_helper
INFO - 2019-08-19 17:09:32 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:09:32 --> Helper loaded: date_helper
INFO - 2019-08-19 17:09:32 --> Form Validation Class Initialized
INFO - 2019-08-19 17:09:32 --> Email Class Initialized
DEBUG - 2019-08-19 17:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:09:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:09:32 --> Pagination Class Initialized
INFO - 2019-08-19 17:09:32 --> Database Driver Class Initialized
INFO - 2019-08-19 17:09:32 --> Database Driver Class Initialized
INFO - 2019-08-19 17:09:32 --> Controller Class Initialized
INFO - 2019-08-19 17:09:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:09:32 --> Config Class Initialized
INFO - 2019-08-19 17:09:32 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:09:32 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:09:32 --> Utf8 Class Initialized
INFO - 2019-08-19 17:09:32 --> URI Class Initialized
INFO - 2019-08-19 17:09:32 --> Router Class Initialized
INFO - 2019-08-19 17:09:32 --> Output Class Initialized
INFO - 2019-08-19 17:09:32 --> Security Class Initialized
DEBUG - 2019-08-19 17:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:09:32 --> Input Class Initialized
INFO - 2019-08-19 17:09:32 --> Language Class Initialized
INFO - 2019-08-19 17:09:32 --> Loader Class Initialized
INFO - 2019-08-19 17:09:32 --> Helper loaded: url_helper
INFO - 2019-08-19 17:09:32 --> Helper loaded: html_helper
INFO - 2019-08-19 17:09:32 --> Helper loaded: form_helper
INFO - 2019-08-19 17:09:32 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:09:32 --> Helper loaded: date_helper
INFO - 2019-08-19 17:09:32 --> Form Validation Class Initialized
INFO - 2019-08-19 17:09:32 --> Email Class Initialized
DEBUG - 2019-08-19 17:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:09:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:09:32 --> Pagination Class Initialized
INFO - 2019-08-19 17:09:32 --> Database Driver Class Initialized
INFO - 2019-08-19 17:09:32 --> Database Driver Class Initialized
INFO - 2019-08-19 17:09:32 --> Controller Class Initialized
INFO - 2019-08-19 17:09:33 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:09:33 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomclass.php
INFO - 2019-08-19 17:09:33 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:09:33 --> Final output sent to browser
DEBUG - 2019-08-19 17:09:33 --> Total execution time: 0.2300
INFO - 2019-08-19 17:10:36 --> Config Class Initialized
INFO - 2019-08-19 17:10:36 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:10:36 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:10:36 --> Utf8 Class Initialized
INFO - 2019-08-19 17:10:36 --> URI Class Initialized
INFO - 2019-08-19 17:10:36 --> Router Class Initialized
INFO - 2019-08-19 17:10:36 --> Output Class Initialized
INFO - 2019-08-19 17:10:36 --> Security Class Initialized
DEBUG - 2019-08-19 17:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:10:36 --> Input Class Initialized
INFO - 2019-08-19 17:10:36 --> Config Class Initialized
INFO - 2019-08-19 17:10:36 --> Hooks Class Initialized
INFO - 2019-08-19 17:10:36 --> Language Class Initialized
DEBUG - 2019-08-19 17:10:36 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:10:36 --> Utf8 Class Initialized
INFO - 2019-08-19 17:10:36 --> URI Class Initialized
INFO - 2019-08-19 17:10:36 --> Loader Class Initialized
INFO - 2019-08-19 17:10:36 --> Router Class Initialized
INFO - 2019-08-19 17:10:36 --> Helper loaded: url_helper
INFO - 2019-08-19 17:10:36 --> Output Class Initialized
INFO - 2019-08-19 17:10:36 --> Helper loaded: html_helper
INFO - 2019-08-19 17:10:36 --> Security Class Initialized
INFO - 2019-08-19 17:10:36 --> Helper loaded: form_helper
INFO - 2019-08-19 17:10:36 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:10:36 --> Helper loaded: date_helper
INFO - 2019-08-19 17:10:36 --> Form Validation Class Initialized
INFO - 2019-08-19 17:10:36 --> Email Class Initialized
DEBUG - 2019-08-19 17:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:10:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:10:36 --> Pagination Class Initialized
INFO - 2019-08-19 17:10:36 --> Database Driver Class Initialized
INFO - 2019-08-19 17:10:36 --> Database Driver Class Initialized
DEBUG - 2019-08-19 17:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:10:36 --> Input Class Initialized
INFO - 2019-08-19 17:10:36 --> Language Class Initialized
INFO - 2019-08-19 17:10:36 --> Loader Class Initialized
INFO - 2019-08-19 17:10:36 --> Helper loaded: url_helper
INFO - 2019-08-19 17:10:36 --> Helper loaded: html_helper
INFO - 2019-08-19 17:10:36 --> Helper loaded: form_helper
INFO - 2019-08-19 17:10:36 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:10:36 --> Helper loaded: date_helper
INFO - 2019-08-19 17:10:36 --> Form Validation Class Initialized
INFO - 2019-08-19 17:10:36 --> Email Class Initialized
DEBUG - 2019-08-19 17:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:10:36 --> Controller Class Initialized
INFO - 2019-08-19 17:10:36 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:10:36 --> Final output sent to browser
DEBUG - 2019-08-19 17:10:36 --> Total execution time: 0.2550
INFO - 2019-08-19 17:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:10:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:10:36 --> Pagination Class Initialized
INFO - 2019-08-19 17:10:36 --> Database Driver Class Initialized
INFO - 2019-08-19 17:10:36 --> Database Driver Class Initialized
INFO - 2019-08-19 17:10:36 --> Controller Class Initialized
INFO - 2019-08-19 17:10:36 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:10:36 --> Final output sent to browser
DEBUG - 2019-08-19 17:10:36 --> Total execution time: 0.3000
INFO - 2019-08-19 17:10:37 --> Config Class Initialized
INFO - 2019-08-19 17:10:37 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:10:37 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:10:37 --> Utf8 Class Initialized
INFO - 2019-08-19 17:10:37 --> URI Class Initialized
INFO - 2019-08-19 17:10:37 --> Router Class Initialized
INFO - 2019-08-19 17:10:37 --> Output Class Initialized
INFO - 2019-08-19 17:10:37 --> Security Class Initialized
DEBUG - 2019-08-19 17:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:10:37 --> Input Class Initialized
INFO - 2019-08-19 17:10:37 --> Language Class Initialized
INFO - 2019-08-19 17:10:37 --> Loader Class Initialized
INFO - 2019-08-19 17:10:37 --> Helper loaded: url_helper
INFO - 2019-08-19 17:10:37 --> Helper loaded: html_helper
INFO - 2019-08-19 17:10:37 --> Helper loaded: form_helper
INFO - 2019-08-19 17:10:37 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:10:37 --> Helper loaded: date_helper
INFO - 2019-08-19 17:10:37 --> Form Validation Class Initialized
INFO - 2019-08-19 17:10:37 --> Email Class Initialized
DEBUG - 2019-08-19 17:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:10:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:10:37 --> Pagination Class Initialized
INFO - 2019-08-19 17:10:37 --> Database Driver Class Initialized
INFO - 2019-08-19 17:10:37 --> Database Driver Class Initialized
INFO - 2019-08-19 17:10:37 --> Controller Class Initialized
INFO - 2019-08-19 17:10:37 --> Final output sent to browser
DEBUG - 2019-08-19 17:10:37 --> Total execution time: 0.2720
INFO - 2019-08-19 17:10:47 --> Config Class Initialized
INFO - 2019-08-19 17:10:47 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:10:47 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:10:47 --> Utf8 Class Initialized
INFO - 2019-08-19 17:10:47 --> URI Class Initialized
INFO - 2019-08-19 17:10:47 --> Router Class Initialized
INFO - 2019-08-19 17:10:47 --> Output Class Initialized
INFO - 2019-08-19 17:10:47 --> Security Class Initialized
DEBUG - 2019-08-19 17:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:10:47 --> Input Class Initialized
INFO - 2019-08-19 17:10:47 --> Language Class Initialized
INFO - 2019-08-19 17:10:47 --> Loader Class Initialized
INFO - 2019-08-19 17:10:47 --> Helper loaded: url_helper
INFO - 2019-08-19 17:10:47 --> Helper loaded: html_helper
INFO - 2019-08-19 17:10:47 --> Helper loaded: form_helper
INFO - 2019-08-19 17:10:47 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:10:47 --> Helper loaded: date_helper
INFO - 2019-08-19 17:10:47 --> Form Validation Class Initialized
INFO - 2019-08-19 17:10:47 --> Email Class Initialized
DEBUG - 2019-08-19 17:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:10:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:10:47 --> Pagination Class Initialized
INFO - 2019-08-19 17:10:47 --> Database Driver Class Initialized
INFO - 2019-08-19 17:10:47 --> Database Driver Class Initialized
INFO - 2019-08-19 17:10:47 --> Controller Class Initialized
INFO - 2019-08-19 17:10:47 --> Final output sent to browser
DEBUG - 2019-08-19 17:10:47 --> Total execution time: 0.2190
INFO - 2019-08-19 17:11:05 --> Config Class Initialized
INFO - 2019-08-19 17:11:05 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:11:05 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:11:05 --> Utf8 Class Initialized
INFO - 2019-08-19 17:11:05 --> URI Class Initialized
INFO - 2019-08-19 17:11:05 --> Router Class Initialized
INFO - 2019-08-19 17:11:05 --> Output Class Initialized
INFO - 2019-08-19 17:11:05 --> Security Class Initialized
DEBUG - 2019-08-19 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:11:05 --> Input Class Initialized
INFO - 2019-08-19 17:11:05 --> Language Class Initialized
INFO - 2019-08-19 17:11:05 --> Loader Class Initialized
INFO - 2019-08-19 17:11:05 --> Helper loaded: url_helper
INFO - 2019-08-19 17:11:05 --> Helper loaded: html_helper
INFO - 2019-08-19 17:11:05 --> Helper loaded: form_helper
INFO - 2019-08-19 17:11:05 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:11:06 --> Helper loaded: date_helper
INFO - 2019-08-19 17:11:06 --> Form Validation Class Initialized
INFO - 2019-08-19 17:11:06 --> Email Class Initialized
DEBUG - 2019-08-19 17:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:11:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:11:06 --> Pagination Class Initialized
INFO - 2019-08-19 17:11:06 --> Database Driver Class Initialized
INFO - 2019-08-19 17:11:06 --> Database Driver Class Initialized
INFO - 2019-08-19 17:11:06 --> Controller Class Initialized
INFO - 2019-08-19 17:11:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:11:06 --> Config Class Initialized
INFO - 2019-08-19 17:11:06 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:11:06 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:11:06 --> Utf8 Class Initialized
INFO - 2019-08-19 17:11:06 --> URI Class Initialized
INFO - 2019-08-19 17:11:06 --> Router Class Initialized
INFO - 2019-08-19 17:11:06 --> Output Class Initialized
INFO - 2019-08-19 17:11:06 --> Security Class Initialized
DEBUG - 2019-08-19 17:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:11:06 --> Input Class Initialized
INFO - 2019-08-19 17:11:06 --> Language Class Initialized
INFO - 2019-08-19 17:11:06 --> Loader Class Initialized
INFO - 2019-08-19 17:11:06 --> Helper loaded: url_helper
INFO - 2019-08-19 17:11:06 --> Helper loaded: html_helper
INFO - 2019-08-19 17:11:06 --> Helper loaded: form_helper
INFO - 2019-08-19 17:11:06 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:11:06 --> Helper loaded: date_helper
INFO - 2019-08-19 17:11:06 --> Form Validation Class Initialized
INFO - 2019-08-19 17:11:06 --> Email Class Initialized
DEBUG - 2019-08-19 17:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:11:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:11:06 --> Pagination Class Initialized
INFO - 2019-08-19 17:11:06 --> Database Driver Class Initialized
INFO - 2019-08-19 17:11:06 --> Database Driver Class Initialized
INFO - 2019-08-19 17:11:06 --> Controller Class Initialized
INFO - 2019-08-19 17:11:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:11:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomclass.php
INFO - 2019-08-19 17:11:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:11:06 --> Final output sent to browser
DEBUG - 2019-08-19 17:11:06 --> Total execution time: 0.1840
INFO - 2019-08-19 17:11:51 --> Config Class Initialized
INFO - 2019-08-19 17:11:51 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:11:51 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:11:51 --> Utf8 Class Initialized
INFO - 2019-08-19 17:11:51 --> Config Class Initialized
INFO - 2019-08-19 17:11:51 --> Hooks Class Initialized
INFO - 2019-08-19 17:11:51 --> Config Class Initialized
INFO - 2019-08-19 17:11:51 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:11:51 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:11:51 --> Utf8 Class Initialized
INFO - 2019-08-19 17:11:51 --> URI Class Initialized
DEBUG - 2019-08-19 17:11:51 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:11:51 --> Utf8 Class Initialized
INFO - 2019-08-19 17:11:51 --> Router Class Initialized
INFO - 2019-08-19 17:11:51 --> URI Class Initialized
INFO - 2019-08-19 17:11:51 --> Output Class Initialized
INFO - 2019-08-19 17:11:51 --> Security Class Initialized
DEBUG - 2019-08-19 17:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:11:51 --> Input Class Initialized
INFO - 2019-08-19 17:11:51 --> Language Class Initialized
INFO - 2019-08-19 17:11:51 --> URI Class Initialized
INFO - 2019-08-19 17:11:51 --> Router Class Initialized
INFO - 2019-08-19 17:11:51 --> Output Class Initialized
INFO - 2019-08-19 17:11:51 --> Router Class Initialized
INFO - 2019-08-19 17:11:51 --> Security Class Initialized
INFO - 2019-08-19 17:11:51 --> Output Class Initialized
DEBUG - 2019-08-19 17:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:11:51 --> Input Class Initialized
INFO - 2019-08-19 17:11:51 --> Security Class Initialized
INFO - 2019-08-19 17:11:51 --> Language Class Initialized
DEBUG - 2019-08-19 17:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:11:51 --> Input Class Initialized
INFO - 2019-08-19 17:11:51 --> Language Class Initialized
INFO - 2019-08-19 17:11:51 --> Loader Class Initialized
INFO - 2019-08-19 17:11:51 --> Helper loaded: url_helper
INFO - 2019-08-19 17:11:51 --> Loader Class Initialized
INFO - 2019-08-19 17:11:51 --> Helper loaded: html_helper
INFO - 2019-08-19 17:11:51 --> Helper loaded: url_helper
INFO - 2019-08-19 17:11:51 --> Helper loaded: form_helper
INFO - 2019-08-19 17:11:51 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:11:51 --> Helper loaded: date_helper
INFO - 2019-08-19 17:11:51 --> Form Validation Class Initialized
INFO - 2019-08-19 17:11:51 --> Loader Class Initialized
INFO - 2019-08-19 17:11:51 --> Helper loaded: html_helper
INFO - 2019-08-19 17:11:51 --> Helper loaded: form_helper
INFO - 2019-08-19 17:11:51 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:11:51 --> Helper loaded: url_helper
INFO - 2019-08-19 17:11:51 --> Helper loaded: html_helper
INFO - 2019-08-19 17:11:51 --> Helper loaded: date_helper
INFO - 2019-08-19 17:11:51 --> Helper loaded: form_helper
INFO - 2019-08-19 17:11:51 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:11:51 --> Form Validation Class Initialized
INFO - 2019-08-19 17:11:51 --> Helper loaded: date_helper
INFO - 2019-08-19 17:11:51 --> Email Class Initialized
DEBUG - 2019-08-19 17:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:11:51 --> Email Class Initialized
INFO - 2019-08-19 17:11:51 --> Form Validation Class Initialized
DEBUG - 2019-08-19 17:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:11:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:11:51 --> Pagination Class Initialized
INFO - 2019-08-19 17:11:51 --> Email Class Initialized
DEBUG - 2019-08-19 17:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:11:51 --> Database Driver Class Initialized
INFO - 2019-08-19 17:11:51 --> Database Driver Class Initialized
INFO - 2019-08-19 17:11:51 --> Controller Class Initialized
INFO - 2019-08-19 17:11:51 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:11:51 --> Final output sent to browser
DEBUG - 2019-08-19 17:11:51 --> Total execution time: 0.3540
INFO - 2019-08-19 17:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:11:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:11:51 --> Pagination Class Initialized
INFO - 2019-08-19 17:11:51 --> Database Driver Class Initialized
INFO - 2019-08-19 17:11:51 --> Database Driver Class Initialized
INFO - 2019-08-19 17:11:51 --> Controller Class Initialized
INFO - 2019-08-19 17:11:51 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:11:51 --> Final output sent to browser
DEBUG - 2019-08-19 17:11:51 --> Total execution time: 0.4070
INFO - 2019-08-19 17:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:11:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:11:51 --> Pagination Class Initialized
INFO - 2019-08-19 17:11:51 --> Database Driver Class Initialized
INFO - 2019-08-19 17:11:51 --> Database Driver Class Initialized
INFO - 2019-08-19 17:11:51 --> Controller Class Initialized
INFO - 2019-08-19 17:11:51 --> Final output sent to browser
DEBUG - 2019-08-19 17:11:51 --> Total execution time: 0.4860
INFO - 2019-08-19 17:12:20 --> Config Class Initialized
INFO - 2019-08-19 17:12:20 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:12:20 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:12:20 --> Utf8 Class Initialized
INFO - 2019-08-19 17:12:20 --> URI Class Initialized
INFO - 2019-08-19 17:12:20 --> Router Class Initialized
INFO - 2019-08-19 17:12:20 --> Output Class Initialized
INFO - 2019-08-19 17:12:20 --> Security Class Initialized
DEBUG - 2019-08-19 17:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:12:20 --> Input Class Initialized
INFO - 2019-08-19 17:12:20 --> Language Class Initialized
INFO - 2019-08-19 17:12:20 --> Loader Class Initialized
INFO - 2019-08-19 17:12:20 --> Helper loaded: url_helper
INFO - 2019-08-19 17:12:20 --> Helper loaded: html_helper
INFO - 2019-08-19 17:12:20 --> Helper loaded: form_helper
INFO - 2019-08-19 17:12:20 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:12:20 --> Helper loaded: date_helper
INFO - 2019-08-19 17:12:20 --> Form Validation Class Initialized
INFO - 2019-08-19 17:12:20 --> Email Class Initialized
DEBUG - 2019-08-19 17:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:12:20 --> Pagination Class Initialized
INFO - 2019-08-19 17:12:20 --> Database Driver Class Initialized
INFO - 2019-08-19 17:12:20 --> Database Driver Class Initialized
INFO - 2019-08-19 17:12:20 --> Controller Class Initialized
INFO - 2019-08-19 17:12:20 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:12:20 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_sale.php
INFO - 2019-08-19 17:12:20 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:12:20 --> Final output sent to browser
DEBUG - 2019-08-19 17:12:20 --> Total execution time: 0.2270
INFO - 2019-08-19 17:13:23 --> Config Class Initialized
INFO - 2019-08-19 17:13:23 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:13:23 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:13:23 --> Utf8 Class Initialized
INFO - 2019-08-19 17:13:23 --> URI Class Initialized
INFO - 2019-08-19 17:13:23 --> Router Class Initialized
INFO - 2019-08-19 17:13:23 --> Output Class Initialized
INFO - 2019-08-19 17:13:23 --> Security Class Initialized
DEBUG - 2019-08-19 17:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:13:23 --> Input Class Initialized
INFO - 2019-08-19 17:13:23 --> Language Class Initialized
INFO - 2019-08-19 17:13:23 --> Loader Class Initialized
INFO - 2019-08-19 17:13:23 --> Helper loaded: url_helper
INFO - 2019-08-19 17:13:23 --> Helper loaded: html_helper
INFO - 2019-08-19 17:13:23 --> Helper loaded: form_helper
INFO - 2019-08-19 17:13:23 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:13:23 --> Helper loaded: date_helper
INFO - 2019-08-19 17:13:23 --> Form Validation Class Initialized
INFO - 2019-08-19 17:13:23 --> Email Class Initialized
DEBUG - 2019-08-19 17:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:13:23 --> Config Class Initialized
INFO - 2019-08-19 17:13:23 --> Hooks Class Initialized
INFO - 2019-08-19 17:13:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:13:23 --> Pagination Class Initialized
DEBUG - 2019-08-19 17:13:23 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:13:23 --> Utf8 Class Initialized
INFO - 2019-08-19 17:13:23 --> URI Class Initialized
INFO - 2019-08-19 17:13:23 --> Router Class Initialized
INFO - 2019-08-19 17:13:23 --> Output Class Initialized
INFO - 2019-08-19 17:13:23 --> Security Class Initialized
INFO - 2019-08-19 17:13:23 --> Database Driver Class Initialized
INFO - 2019-08-19 17:13:23 --> Database Driver Class Initialized
INFO - 2019-08-19 17:13:23 --> Controller Class Initialized
DEBUG - 2019-08-19 17:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:13:23 --> Input Class Initialized
INFO - 2019-08-19 17:13:23 --> Language Class Initialized
INFO - 2019-08-19 17:13:23 --> Loader Class Initialized
INFO - 2019-08-19 17:13:23 --> Helper loaded: url_helper
INFO - 2019-08-19 17:13:23 --> Helper loaded: html_helper
INFO - 2019-08-19 17:13:23 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:13:23 --> Final output sent to browser
INFO - 2019-08-19 17:13:23 --> Helper loaded: form_helper
DEBUG - 2019-08-19 17:13:23 --> Total execution time: 0.1890
INFO - 2019-08-19 17:13:23 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:13:23 --> Helper loaded: date_helper
INFO - 2019-08-19 17:13:23 --> Form Validation Class Initialized
INFO - 2019-08-19 17:13:24 --> Email Class Initialized
DEBUG - 2019-08-19 17:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:13:24 --> Pagination Class Initialized
INFO - 2019-08-19 17:13:24 --> Database Driver Class Initialized
INFO - 2019-08-19 17:13:24 --> Database Driver Class Initialized
INFO - 2019-08-19 17:13:24 --> Controller Class Initialized
INFO - 2019-08-19 17:13:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:13:24 --> Final output sent to browser
DEBUG - 2019-08-19 17:13:24 --> Total execution time: 0.2050
INFO - 2019-08-19 17:13:24 --> Config Class Initialized
INFO - 2019-08-19 17:13:24 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:13:24 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:13:24 --> Utf8 Class Initialized
INFO - 2019-08-19 17:13:24 --> URI Class Initialized
INFO - 2019-08-19 17:13:24 --> Router Class Initialized
INFO - 2019-08-19 17:13:24 --> Output Class Initialized
INFO - 2019-08-19 17:13:24 --> Security Class Initialized
DEBUG - 2019-08-19 17:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:13:24 --> Input Class Initialized
INFO - 2019-08-19 17:13:24 --> Language Class Initialized
INFO - 2019-08-19 17:13:24 --> Loader Class Initialized
INFO - 2019-08-19 17:13:24 --> Helper loaded: url_helper
INFO - 2019-08-19 17:13:24 --> Helper loaded: html_helper
INFO - 2019-08-19 17:13:24 --> Helper loaded: form_helper
INFO - 2019-08-19 17:13:24 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:13:24 --> Helper loaded: date_helper
INFO - 2019-08-19 17:13:24 --> Form Validation Class Initialized
INFO - 2019-08-19 17:13:24 --> Email Class Initialized
DEBUG - 2019-08-19 17:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:13:24 --> Pagination Class Initialized
INFO - 2019-08-19 17:13:24 --> Database Driver Class Initialized
INFO - 2019-08-19 17:13:24 --> Database Driver Class Initialized
INFO - 2019-08-19 17:13:24 --> Controller Class Initialized
INFO - 2019-08-19 17:13:24 --> Final output sent to browser
DEBUG - 2019-08-19 17:13:24 --> Total execution time: 0.2828
INFO - 2019-08-19 17:13:45 --> Config Class Initialized
INFO - 2019-08-19 17:13:45 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:13:45 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:13:45 --> Utf8 Class Initialized
INFO - 2019-08-19 17:13:45 --> URI Class Initialized
INFO - 2019-08-19 17:13:45 --> Router Class Initialized
INFO - 2019-08-19 17:13:45 --> Output Class Initialized
INFO - 2019-08-19 17:13:45 --> Security Class Initialized
DEBUG - 2019-08-19 17:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:13:45 --> Input Class Initialized
INFO - 2019-08-19 17:13:45 --> Language Class Initialized
INFO - 2019-08-19 17:13:45 --> Loader Class Initialized
INFO - 2019-08-19 17:13:45 --> Helper loaded: url_helper
INFO - 2019-08-19 17:13:45 --> Helper loaded: html_helper
INFO - 2019-08-19 17:13:45 --> Helper loaded: form_helper
INFO - 2019-08-19 17:13:45 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:13:45 --> Helper loaded: date_helper
INFO - 2019-08-19 17:13:45 --> Form Validation Class Initialized
INFO - 2019-08-19 17:13:45 --> Email Class Initialized
DEBUG - 2019-08-19 17:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:13:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:13:45 --> Pagination Class Initialized
INFO - 2019-08-19 17:13:45 --> Database Driver Class Initialized
INFO - 2019-08-19 17:13:45 --> Database Driver Class Initialized
INFO - 2019-08-19 17:13:45 --> Controller Class Initialized
INFO - 2019-08-19 17:13:45 --> Final output sent to browser
DEBUG - 2019-08-19 17:13:45 --> Total execution time: 0.2460
INFO - 2019-08-19 17:14:01 --> Config Class Initialized
INFO - 2019-08-19 17:14:01 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:14:01 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:14:01 --> Utf8 Class Initialized
INFO - 2019-08-19 17:14:01 --> URI Class Initialized
INFO - 2019-08-19 17:14:01 --> Router Class Initialized
INFO - 2019-08-19 17:14:01 --> Output Class Initialized
INFO - 2019-08-19 17:14:01 --> Security Class Initialized
DEBUG - 2019-08-19 17:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:14:01 --> Input Class Initialized
INFO - 2019-08-19 17:14:01 --> Language Class Initialized
INFO - 2019-08-19 17:14:01 --> Loader Class Initialized
INFO - 2019-08-19 17:14:01 --> Helper loaded: url_helper
INFO - 2019-08-19 17:14:01 --> Helper loaded: html_helper
INFO - 2019-08-19 17:14:01 --> Helper loaded: form_helper
INFO - 2019-08-19 17:14:01 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:14:01 --> Helper loaded: date_helper
INFO - 2019-08-19 17:14:01 --> Form Validation Class Initialized
INFO - 2019-08-19 17:14:01 --> Email Class Initialized
DEBUG - 2019-08-19 17:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:14:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:14:01 --> Pagination Class Initialized
INFO - 2019-08-19 17:14:01 --> Database Driver Class Initialized
INFO - 2019-08-19 17:14:01 --> Database Driver Class Initialized
INFO - 2019-08-19 17:14:01 --> Controller Class Initialized
INFO - 2019-08-19 17:14:01 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:14:01 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_sale.php
INFO - 2019-08-19 17:14:01 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:14:01 --> Final output sent to browser
DEBUG - 2019-08-19 17:14:01 --> Total execution time: 0.3000
INFO - 2019-08-19 17:14:43 --> Config Class Initialized
INFO - 2019-08-19 17:14:43 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:14:43 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:14:43 --> Utf8 Class Initialized
INFO - 2019-08-19 17:14:43 --> URI Class Initialized
INFO - 2019-08-19 17:14:43 --> Router Class Initialized
INFO - 2019-08-19 17:14:43 --> Output Class Initialized
INFO - 2019-08-19 17:14:43 --> Security Class Initialized
DEBUG - 2019-08-19 17:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:14:43 --> Input Class Initialized
INFO - 2019-08-19 17:14:43 --> Language Class Initialized
INFO - 2019-08-19 17:14:43 --> Loader Class Initialized
INFO - 2019-08-19 17:14:43 --> Helper loaded: url_helper
INFO - 2019-08-19 17:14:43 --> Helper loaded: html_helper
INFO - 2019-08-19 17:14:43 --> Helper loaded: form_helper
INFO - 2019-08-19 17:14:43 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:14:43 --> Helper loaded: date_helper
INFO - 2019-08-19 17:14:43 --> Form Validation Class Initialized
INFO - 2019-08-19 17:14:43 --> Email Class Initialized
DEBUG - 2019-08-19 17:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:14:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:14:44 --> Pagination Class Initialized
INFO - 2019-08-19 17:14:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:14:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:14:44 --> Config Class Initialized
INFO - 2019-08-19 17:14:44 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:14:44 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:14:44 --> Utf8 Class Initialized
INFO - 2019-08-19 17:14:44 --> URI Class Initialized
INFO - 2019-08-19 17:14:44 --> Router Class Initialized
INFO - 2019-08-19 17:14:44 --> Controller Class Initialized
INFO - 2019-08-19 17:14:44 --> Output Class Initialized
INFO - 2019-08-19 17:14:44 --> Security Class Initialized
DEBUG - 2019-08-19 17:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:14:44 --> Input Class Initialized
INFO - 2019-08-19 17:14:44 --> Language Class Initialized
INFO - 2019-08-19 17:14:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:14:44 --> Final output sent to browser
DEBUG - 2019-08-19 17:14:44 --> Total execution time: 0.2560
INFO - 2019-08-19 17:14:44 --> Loader Class Initialized
INFO - 2019-08-19 17:14:44 --> Helper loaded: url_helper
INFO - 2019-08-19 17:14:44 --> Helper loaded: html_helper
INFO - 2019-08-19 17:14:44 --> Helper loaded: form_helper
INFO - 2019-08-19 17:14:44 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:14:44 --> Helper loaded: date_helper
INFO - 2019-08-19 17:14:44 --> Form Validation Class Initialized
INFO - 2019-08-19 17:14:44 --> Email Class Initialized
DEBUG - 2019-08-19 17:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:14:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:14:44 --> Pagination Class Initialized
INFO - 2019-08-19 17:14:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:14:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:14:44 --> Controller Class Initialized
INFO - 2019-08-19 17:14:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:14:44 --> Final output sent to browser
DEBUG - 2019-08-19 17:14:44 --> Total execution time: 0.2430
INFO - 2019-08-19 17:14:44 --> Config Class Initialized
INFO - 2019-08-19 17:14:44 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:14:44 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:14:44 --> Utf8 Class Initialized
INFO - 2019-08-19 17:14:44 --> URI Class Initialized
INFO - 2019-08-19 17:14:44 --> Router Class Initialized
INFO - 2019-08-19 17:14:44 --> Output Class Initialized
INFO - 2019-08-19 17:14:44 --> Security Class Initialized
DEBUG - 2019-08-19 17:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:14:44 --> Input Class Initialized
INFO - 2019-08-19 17:14:44 --> Language Class Initialized
INFO - 2019-08-19 17:14:44 --> Loader Class Initialized
INFO - 2019-08-19 17:14:44 --> Helper loaded: url_helper
INFO - 2019-08-19 17:14:44 --> Helper loaded: html_helper
INFO - 2019-08-19 17:14:44 --> Helper loaded: form_helper
INFO - 2019-08-19 17:14:44 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:14:44 --> Helper loaded: date_helper
INFO - 2019-08-19 17:14:44 --> Form Validation Class Initialized
INFO - 2019-08-19 17:14:44 --> Email Class Initialized
DEBUG - 2019-08-19 17:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:14:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:14:44 --> Pagination Class Initialized
INFO - 2019-08-19 17:14:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:14:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:14:44 --> Controller Class Initialized
INFO - 2019-08-19 17:14:45 --> Final output sent to browser
DEBUG - 2019-08-19 17:14:45 --> Total execution time: 0.2910
INFO - 2019-08-19 17:14:53 --> Config Class Initialized
INFO - 2019-08-19 17:14:53 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:14:53 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:14:53 --> Utf8 Class Initialized
INFO - 2019-08-19 17:14:53 --> URI Class Initialized
INFO - 2019-08-19 17:14:53 --> Router Class Initialized
INFO - 2019-08-19 17:14:53 --> Output Class Initialized
INFO - 2019-08-19 17:14:53 --> Security Class Initialized
DEBUG - 2019-08-19 17:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:14:53 --> Input Class Initialized
INFO - 2019-08-19 17:14:53 --> Language Class Initialized
INFO - 2019-08-19 17:14:53 --> Loader Class Initialized
INFO - 2019-08-19 17:14:53 --> Helper loaded: url_helper
INFO - 2019-08-19 17:14:53 --> Helper loaded: html_helper
INFO - 2019-08-19 17:14:53 --> Helper loaded: form_helper
INFO - 2019-08-19 17:14:53 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:14:53 --> Helper loaded: date_helper
INFO - 2019-08-19 17:14:53 --> Form Validation Class Initialized
INFO - 2019-08-19 17:14:53 --> Email Class Initialized
DEBUG - 2019-08-19 17:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:14:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:14:53 --> Pagination Class Initialized
INFO - 2019-08-19 17:14:53 --> Database Driver Class Initialized
INFO - 2019-08-19 17:14:53 --> Database Driver Class Initialized
INFO - 2019-08-19 17:14:53 --> Controller Class Initialized
INFO - 2019-08-19 17:14:53 --> Final output sent to browser
DEBUG - 2019-08-19 17:14:53 --> Total execution time: 0.2240
INFO - 2019-08-19 17:15:42 --> Config Class Initialized
INFO - 2019-08-19 17:15:42 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:15:42 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:15:42 --> Utf8 Class Initialized
INFO - 2019-08-19 17:15:42 --> URI Class Initialized
INFO - 2019-08-19 17:15:42 --> Router Class Initialized
INFO - 2019-08-19 17:15:42 --> Output Class Initialized
INFO - 2019-08-19 17:15:42 --> Security Class Initialized
DEBUG - 2019-08-19 17:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:15:42 --> Input Class Initialized
INFO - 2019-08-19 17:15:42 --> Language Class Initialized
INFO - 2019-08-19 17:15:42 --> Loader Class Initialized
INFO - 2019-08-19 17:15:42 --> Helper loaded: url_helper
INFO - 2019-08-19 17:15:42 --> Helper loaded: html_helper
INFO - 2019-08-19 17:15:42 --> Helper loaded: form_helper
INFO - 2019-08-19 17:15:42 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:15:42 --> Helper loaded: date_helper
INFO - 2019-08-19 17:15:42 --> Form Validation Class Initialized
INFO - 2019-08-19 17:15:42 --> Email Class Initialized
DEBUG - 2019-08-19 17:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:15:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:15:42 --> Pagination Class Initialized
INFO - 2019-08-19 17:15:42 --> Database Driver Class Initialized
INFO - 2019-08-19 17:15:42 --> Database Driver Class Initialized
INFO - 2019-08-19 17:15:43 --> Controller Class Initialized
INFO - 2019-08-19 17:15:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:15:43 --> Config Class Initialized
INFO - 2019-08-19 17:15:43 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:15:43 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:15:43 --> Utf8 Class Initialized
INFO - 2019-08-19 17:15:43 --> URI Class Initialized
INFO - 2019-08-19 17:15:43 --> Router Class Initialized
INFO - 2019-08-19 17:15:43 --> Output Class Initialized
INFO - 2019-08-19 17:15:43 --> Security Class Initialized
DEBUG - 2019-08-19 17:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:15:43 --> Input Class Initialized
INFO - 2019-08-19 17:15:43 --> Language Class Initialized
INFO - 2019-08-19 17:15:43 --> Loader Class Initialized
INFO - 2019-08-19 17:15:43 --> Helper loaded: url_helper
INFO - 2019-08-19 17:15:43 --> Helper loaded: html_helper
INFO - 2019-08-19 17:15:43 --> Helper loaded: form_helper
INFO - 2019-08-19 17:15:43 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:15:43 --> Helper loaded: date_helper
INFO - 2019-08-19 17:15:43 --> Form Validation Class Initialized
INFO - 2019-08-19 17:15:43 --> Email Class Initialized
DEBUG - 2019-08-19 17:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:15:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:15:43 --> Pagination Class Initialized
INFO - 2019-08-19 17:15:43 --> Database Driver Class Initialized
INFO - 2019-08-19 17:15:43 --> Database Driver Class Initialized
INFO - 2019-08-19 17:15:43 --> Controller Class Initialized
INFO - 2019-08-19 17:15:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:15:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_sale.php
INFO - 2019-08-19 17:15:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:15:43 --> Final output sent to browser
DEBUG - 2019-08-19 17:15:43 --> Total execution time: 0.2180
INFO - 2019-08-19 17:16:46 --> Config Class Initialized
INFO - 2019-08-19 17:16:46 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:16:46 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:16:46 --> Utf8 Class Initialized
INFO - 2019-08-19 17:16:46 --> URI Class Initialized
INFO - 2019-08-19 17:16:46 --> Router Class Initialized
INFO - 2019-08-19 17:16:46 --> Output Class Initialized
INFO - 2019-08-19 17:16:46 --> Security Class Initialized
DEBUG - 2019-08-19 17:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:16:46 --> Input Class Initialized
INFO - 2019-08-19 17:16:46 --> Language Class Initialized
INFO - 2019-08-19 17:16:46 --> Loader Class Initialized
INFO - 2019-08-19 17:16:46 --> Helper loaded: url_helper
INFO - 2019-08-19 17:16:46 --> Helper loaded: html_helper
INFO - 2019-08-19 17:16:46 --> Helper loaded: form_helper
INFO - 2019-08-19 17:16:46 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:16:46 --> Helper loaded: date_helper
INFO - 2019-08-19 17:16:46 --> Form Validation Class Initialized
INFO - 2019-08-19 17:16:46 --> Email Class Initialized
INFO - 2019-08-19 17:16:46 --> Config Class Initialized
INFO - 2019-08-19 17:16:46 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-19 17:16:46 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:16:46 --> Utf8 Class Initialized
INFO - 2019-08-19 17:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:16:46 --> URI Class Initialized
INFO - 2019-08-19 17:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:16:46 --> Pagination Class Initialized
INFO - 2019-08-19 17:16:46 --> Router Class Initialized
INFO - 2019-08-19 17:16:46 --> Output Class Initialized
INFO - 2019-08-19 17:16:46 --> Security Class Initialized
DEBUG - 2019-08-19 17:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:16:46 --> Input Class Initialized
INFO - 2019-08-19 17:16:46 --> Language Class Initialized
INFO - 2019-08-19 17:16:46 --> Database Driver Class Initialized
INFO - 2019-08-19 17:16:46 --> Database Driver Class Initialized
INFO - 2019-08-19 17:16:46 --> Loader Class Initialized
INFO - 2019-08-19 17:16:46 --> Helper loaded: url_helper
INFO - 2019-08-19 17:16:46 --> Helper loaded: html_helper
INFO - 2019-08-19 17:16:46 --> Helper loaded: form_helper
INFO - 2019-08-19 17:16:46 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:16:46 --> Helper loaded: date_helper
INFO - 2019-08-19 17:16:46 --> Controller Class Initialized
INFO - 2019-08-19 17:16:46 --> Form Validation Class Initialized
INFO - 2019-08-19 17:16:46 --> Email Class Initialized
DEBUG - 2019-08-19 17:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:16:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:16:46 --> Final output sent to browser
DEBUG - 2019-08-19 17:16:46 --> Total execution time: 0.1870
INFO - 2019-08-19 17:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:16:46 --> Pagination Class Initialized
INFO - 2019-08-19 17:16:46 --> Database Driver Class Initialized
INFO - 2019-08-19 17:16:46 --> Database Driver Class Initialized
INFO - 2019-08-19 17:16:46 --> Controller Class Initialized
INFO - 2019-08-19 17:16:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:16:46 --> Final output sent to browser
DEBUG - 2019-08-19 17:16:46 --> Total execution time: 0.1890
INFO - 2019-08-19 17:16:47 --> Config Class Initialized
INFO - 2019-08-19 17:16:47 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:16:47 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:16:47 --> Utf8 Class Initialized
INFO - 2019-08-19 17:16:47 --> URI Class Initialized
INFO - 2019-08-19 17:16:47 --> Router Class Initialized
INFO - 2019-08-19 17:16:47 --> Output Class Initialized
INFO - 2019-08-19 17:16:47 --> Security Class Initialized
DEBUG - 2019-08-19 17:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:16:47 --> Input Class Initialized
INFO - 2019-08-19 17:16:47 --> Language Class Initialized
INFO - 2019-08-19 17:16:47 --> Loader Class Initialized
INFO - 2019-08-19 17:16:47 --> Helper loaded: url_helper
INFO - 2019-08-19 17:16:47 --> Helper loaded: html_helper
INFO - 2019-08-19 17:16:47 --> Helper loaded: form_helper
INFO - 2019-08-19 17:16:47 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:16:47 --> Helper loaded: date_helper
INFO - 2019-08-19 17:16:47 --> Form Validation Class Initialized
INFO - 2019-08-19 17:16:47 --> Email Class Initialized
DEBUG - 2019-08-19 17:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:16:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:16:47 --> Pagination Class Initialized
INFO - 2019-08-19 17:16:47 --> Database Driver Class Initialized
INFO - 2019-08-19 17:16:47 --> Database Driver Class Initialized
INFO - 2019-08-19 17:16:47 --> Controller Class Initialized
INFO - 2019-08-19 17:16:47 --> Final output sent to browser
DEBUG - 2019-08-19 17:16:47 --> Total execution time: 0.2686
INFO - 2019-08-19 17:17:04 --> Config Class Initialized
INFO - 2019-08-19 17:17:04 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:17:04 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:17:04 --> Utf8 Class Initialized
INFO - 2019-08-19 17:17:04 --> URI Class Initialized
INFO - 2019-08-19 17:17:04 --> Router Class Initialized
INFO - 2019-08-19 17:17:04 --> Output Class Initialized
INFO - 2019-08-19 17:17:04 --> Security Class Initialized
DEBUG - 2019-08-19 17:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:17:04 --> Input Class Initialized
INFO - 2019-08-19 17:17:04 --> Language Class Initialized
INFO - 2019-08-19 17:17:04 --> Loader Class Initialized
INFO - 2019-08-19 17:17:04 --> Helper loaded: url_helper
INFO - 2019-08-19 17:17:04 --> Helper loaded: html_helper
INFO - 2019-08-19 17:17:04 --> Helper loaded: form_helper
INFO - 2019-08-19 17:17:04 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:17:04 --> Helper loaded: date_helper
INFO - 2019-08-19 17:17:04 --> Form Validation Class Initialized
INFO - 2019-08-19 17:17:04 --> Email Class Initialized
DEBUG - 2019-08-19 17:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:17:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:17:04 --> Pagination Class Initialized
INFO - 2019-08-19 17:17:04 --> Database Driver Class Initialized
INFO - 2019-08-19 17:17:04 --> Database Driver Class Initialized
INFO - 2019-08-19 17:17:04 --> Controller Class Initialized
INFO - 2019-08-19 17:17:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:17:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_sale.php
INFO - 2019-08-19 17:17:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:17:04 --> Final output sent to browser
DEBUG - 2019-08-19 17:17:04 --> Total execution time: 0.2370
INFO - 2019-08-19 17:17:28 --> Config Class Initialized
INFO - 2019-08-19 17:17:28 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:17:28 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:17:28 --> Utf8 Class Initialized
INFO - 2019-08-19 17:17:28 --> URI Class Initialized
INFO - 2019-08-19 17:17:28 --> Router Class Initialized
INFO - 2019-08-19 17:17:28 --> Output Class Initialized
INFO - 2019-08-19 17:17:28 --> Security Class Initialized
DEBUG - 2019-08-19 17:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:17:28 --> Input Class Initialized
INFO - 2019-08-19 17:17:28 --> Language Class Initialized
INFO - 2019-08-19 17:17:28 --> Config Class Initialized
INFO - 2019-08-19 17:17:28 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:17:28 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:17:28 --> Utf8 Class Initialized
INFO - 2019-08-19 17:17:28 --> Loader Class Initialized
INFO - 2019-08-19 17:17:28 --> Helper loaded: url_helper
INFO - 2019-08-19 17:17:28 --> Helper loaded: html_helper
INFO - 2019-08-19 17:17:28 --> Helper loaded: form_helper
INFO - 2019-08-19 17:17:28 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:17:28 --> Helper loaded: date_helper
INFO - 2019-08-19 17:17:28 --> Form Validation Class Initialized
INFO - 2019-08-19 17:17:28 --> URI Class Initialized
INFO - 2019-08-19 17:17:28 --> Router Class Initialized
INFO - 2019-08-19 17:17:28 --> Output Class Initialized
INFO - 2019-08-19 17:17:28 --> Security Class Initialized
DEBUG - 2019-08-19 17:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:17:28 --> Input Class Initialized
INFO - 2019-08-19 17:17:28 --> Language Class Initialized
INFO - 2019-08-19 17:17:28 --> Email Class Initialized
DEBUG - 2019-08-19 17:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:17:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:17:28 --> Pagination Class Initialized
INFO - 2019-08-19 17:17:28 --> Loader Class Initialized
INFO - 2019-08-19 17:17:28 --> Helper loaded: url_helper
INFO - 2019-08-19 17:17:28 --> Helper loaded: html_helper
INFO - 2019-08-19 17:17:28 --> Helper loaded: form_helper
INFO - 2019-08-19 17:17:28 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:17:28 --> Helper loaded: date_helper
INFO - 2019-08-19 17:17:28 --> Form Validation Class Initialized
INFO - 2019-08-19 17:17:29 --> Database Driver Class Initialized
INFO - 2019-08-19 17:17:29 --> Database Driver Class Initialized
INFO - 2019-08-19 17:17:29 --> Email Class Initialized
DEBUG - 2019-08-19 17:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:17:29 --> Controller Class Initialized
INFO - 2019-08-19 17:17:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:17:29 --> Final output sent to browser
DEBUG - 2019-08-19 17:17:29 --> Total execution time: 0.3300
INFO - 2019-08-19 17:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:17:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:17:29 --> Pagination Class Initialized
INFO - 2019-08-19 17:17:29 --> Database Driver Class Initialized
INFO - 2019-08-19 17:17:29 --> Database Driver Class Initialized
INFO - 2019-08-19 17:17:29 --> Controller Class Initialized
INFO - 2019-08-19 17:17:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:17:29 --> Final output sent to browser
DEBUG - 2019-08-19 17:17:29 --> Total execution time: 0.3600
INFO - 2019-08-19 17:17:29 --> Config Class Initialized
INFO - 2019-08-19 17:17:29 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:17:29 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:17:29 --> Utf8 Class Initialized
INFO - 2019-08-19 17:17:29 --> URI Class Initialized
INFO - 2019-08-19 17:17:29 --> Router Class Initialized
INFO - 2019-08-19 17:17:29 --> Output Class Initialized
INFO - 2019-08-19 17:17:29 --> Security Class Initialized
DEBUG - 2019-08-19 17:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:17:29 --> Input Class Initialized
INFO - 2019-08-19 17:17:29 --> Language Class Initialized
INFO - 2019-08-19 17:17:29 --> Loader Class Initialized
INFO - 2019-08-19 17:17:29 --> Helper loaded: url_helper
INFO - 2019-08-19 17:17:29 --> Helper loaded: html_helper
INFO - 2019-08-19 17:17:29 --> Helper loaded: form_helper
INFO - 2019-08-19 17:17:29 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:17:29 --> Helper loaded: date_helper
INFO - 2019-08-19 17:17:29 --> Form Validation Class Initialized
INFO - 2019-08-19 17:17:29 --> Email Class Initialized
DEBUG - 2019-08-19 17:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:17:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:17:29 --> Pagination Class Initialized
INFO - 2019-08-19 17:17:29 --> Database Driver Class Initialized
INFO - 2019-08-19 17:17:29 --> Database Driver Class Initialized
INFO - 2019-08-19 17:17:29 --> Controller Class Initialized
INFO - 2019-08-19 17:17:29 --> Final output sent to browser
DEBUG - 2019-08-19 17:17:29 --> Total execution time: 0.2680
INFO - 2019-08-19 17:17:39 --> Config Class Initialized
INFO - 2019-08-19 17:17:39 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:17:39 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:17:39 --> Utf8 Class Initialized
INFO - 2019-08-19 17:17:39 --> URI Class Initialized
INFO - 2019-08-19 17:17:39 --> Router Class Initialized
INFO - 2019-08-19 17:17:39 --> Output Class Initialized
INFO - 2019-08-19 17:17:39 --> Security Class Initialized
DEBUG - 2019-08-19 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:17:39 --> Input Class Initialized
INFO - 2019-08-19 17:17:39 --> Language Class Initialized
INFO - 2019-08-19 17:17:39 --> Loader Class Initialized
INFO - 2019-08-19 17:17:39 --> Helper loaded: url_helper
INFO - 2019-08-19 17:17:39 --> Helper loaded: html_helper
INFO - 2019-08-19 17:17:39 --> Helper loaded: form_helper
INFO - 2019-08-19 17:17:39 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:17:39 --> Helper loaded: date_helper
INFO - 2019-08-19 17:17:39 --> Form Validation Class Initialized
INFO - 2019-08-19 17:17:39 --> Email Class Initialized
DEBUG - 2019-08-19 17:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:17:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:17:39 --> Pagination Class Initialized
INFO - 2019-08-19 17:17:39 --> Database Driver Class Initialized
INFO - 2019-08-19 17:17:39 --> Database Driver Class Initialized
INFO - 2019-08-19 17:17:39 --> Controller Class Initialized
INFO - 2019-08-19 17:17:39 --> Final output sent to browser
DEBUG - 2019-08-19 17:17:39 --> Total execution time: 0.1910
INFO - 2019-08-19 17:18:08 --> Config Class Initialized
INFO - 2019-08-19 17:18:08 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:18:08 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:18:08 --> Utf8 Class Initialized
INFO - 2019-08-19 17:18:08 --> URI Class Initialized
INFO - 2019-08-19 17:18:08 --> Router Class Initialized
INFO - 2019-08-19 17:18:08 --> Output Class Initialized
INFO - 2019-08-19 17:18:08 --> Security Class Initialized
DEBUG - 2019-08-19 17:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:18:08 --> Input Class Initialized
INFO - 2019-08-19 17:18:08 --> Language Class Initialized
INFO - 2019-08-19 17:18:08 --> Loader Class Initialized
INFO - 2019-08-19 17:18:08 --> Helper loaded: url_helper
INFO - 2019-08-19 17:18:08 --> Helper loaded: html_helper
INFO - 2019-08-19 17:18:08 --> Helper loaded: form_helper
INFO - 2019-08-19 17:18:08 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:18:08 --> Helper loaded: date_helper
INFO - 2019-08-19 17:18:08 --> Form Validation Class Initialized
INFO - 2019-08-19 17:18:08 --> Email Class Initialized
DEBUG - 2019-08-19 17:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:18:08 --> Pagination Class Initialized
INFO - 2019-08-19 17:18:08 --> Database Driver Class Initialized
INFO - 2019-08-19 17:18:08 --> Database Driver Class Initialized
INFO - 2019-08-19 17:18:08 --> Controller Class Initialized
INFO - 2019-08-19 17:18:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:18:08 --> Config Class Initialized
INFO - 2019-08-19 17:18:08 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:18:08 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:18:08 --> Utf8 Class Initialized
INFO - 2019-08-19 17:18:08 --> URI Class Initialized
INFO - 2019-08-19 17:18:08 --> Router Class Initialized
INFO - 2019-08-19 17:18:08 --> Output Class Initialized
INFO - 2019-08-19 17:18:08 --> Security Class Initialized
DEBUG - 2019-08-19 17:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:18:08 --> Input Class Initialized
INFO - 2019-08-19 17:18:08 --> Language Class Initialized
INFO - 2019-08-19 17:18:08 --> Loader Class Initialized
INFO - 2019-08-19 17:18:08 --> Helper loaded: url_helper
INFO - 2019-08-19 17:18:08 --> Helper loaded: html_helper
INFO - 2019-08-19 17:18:08 --> Helper loaded: form_helper
INFO - 2019-08-19 17:18:08 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:18:08 --> Helper loaded: date_helper
INFO - 2019-08-19 17:18:08 --> Form Validation Class Initialized
INFO - 2019-08-19 17:18:08 --> Email Class Initialized
DEBUG - 2019-08-19 17:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:18:08 --> Pagination Class Initialized
INFO - 2019-08-19 17:18:08 --> Database Driver Class Initialized
INFO - 2019-08-19 17:18:08 --> Database Driver Class Initialized
INFO - 2019-08-19 17:18:08 --> Controller Class Initialized
INFO - 2019-08-19 17:18:08 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:18:08 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_sale.php
INFO - 2019-08-19 17:18:08 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:18:08 --> Final output sent to browser
DEBUG - 2019-08-19 17:18:08 --> Total execution time: 0.2320
INFO - 2019-08-19 17:19:12 --> Config Class Initialized
INFO - 2019-08-19 17:19:12 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:19:12 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:19:12 --> Config Class Initialized
INFO - 2019-08-19 17:19:12 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:19:12 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:19:12 --> Utf8 Class Initialized
INFO - 2019-08-19 17:19:12 --> URI Class Initialized
INFO - 2019-08-19 17:19:12 --> Router Class Initialized
INFO - 2019-08-19 17:19:12 --> Output Class Initialized
INFO - 2019-08-19 17:19:12 --> Security Class Initialized
DEBUG - 2019-08-19 17:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:19:12 --> Input Class Initialized
INFO - 2019-08-19 17:19:12 --> Language Class Initialized
INFO - 2019-08-19 17:19:12 --> Utf8 Class Initialized
INFO - 2019-08-19 17:19:12 --> URI Class Initialized
INFO - 2019-08-19 17:19:12 --> Router Class Initialized
INFO - 2019-08-19 17:19:12 --> Output Class Initialized
INFO - 2019-08-19 17:19:12 --> Security Class Initialized
DEBUG - 2019-08-19 17:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:19:12 --> Input Class Initialized
INFO - 2019-08-19 17:19:12 --> Language Class Initialized
INFO - 2019-08-19 17:19:12 --> Loader Class Initialized
INFO - 2019-08-19 17:19:12 --> Helper loaded: url_helper
INFO - 2019-08-19 17:19:12 --> Helper loaded: html_helper
INFO - 2019-08-19 17:19:12 --> Helper loaded: form_helper
INFO - 2019-08-19 17:19:12 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:19:12 --> Helper loaded: date_helper
INFO - 2019-08-19 17:19:12 --> Form Validation Class Initialized
INFO - 2019-08-19 17:19:12 --> Loader Class Initialized
INFO - 2019-08-19 17:19:12 --> Helper loaded: url_helper
INFO - 2019-08-19 17:19:12 --> Helper loaded: html_helper
INFO - 2019-08-19 17:19:12 --> Helper loaded: form_helper
INFO - 2019-08-19 17:19:12 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:19:12 --> Helper loaded: date_helper
INFO - 2019-08-19 17:19:12 --> Form Validation Class Initialized
INFO - 2019-08-19 17:19:12 --> Email Class Initialized
DEBUG - 2019-08-19 17:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:19:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:19:12 --> Pagination Class Initialized
INFO - 2019-08-19 17:19:12 --> Email Class Initialized
DEBUG - 2019-08-19 17:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:19:12 --> Database Driver Class Initialized
INFO - 2019-08-19 17:19:12 --> Database Driver Class Initialized
INFO - 2019-08-19 17:19:12 --> Controller Class Initialized
INFO - 2019-08-19 17:19:12 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:19:12 --> Final output sent to browser
DEBUG - 2019-08-19 17:19:12 --> Total execution time: 0.2570
INFO - 2019-08-19 17:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:19:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:19:12 --> Pagination Class Initialized
INFO - 2019-08-19 17:19:12 --> Database Driver Class Initialized
INFO - 2019-08-19 17:19:12 --> Database Driver Class Initialized
INFO - 2019-08-19 17:19:12 --> Controller Class Initialized
INFO - 2019-08-19 17:19:12 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:19:12 --> Final output sent to browser
DEBUG - 2019-08-19 17:19:12 --> Total execution time: 0.3740
INFO - 2019-08-19 17:19:12 --> Config Class Initialized
INFO - 2019-08-19 17:19:12 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:19:12 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:19:12 --> Utf8 Class Initialized
INFO - 2019-08-19 17:19:12 --> URI Class Initialized
INFO - 2019-08-19 17:19:12 --> Router Class Initialized
INFO - 2019-08-19 17:19:12 --> Output Class Initialized
INFO - 2019-08-19 17:19:12 --> Security Class Initialized
DEBUG - 2019-08-19 17:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:19:12 --> Input Class Initialized
INFO - 2019-08-19 17:19:12 --> Language Class Initialized
INFO - 2019-08-19 17:19:12 --> Loader Class Initialized
INFO - 2019-08-19 17:19:12 --> Helper loaded: url_helper
INFO - 2019-08-19 17:19:13 --> Helper loaded: html_helper
INFO - 2019-08-19 17:19:13 --> Helper loaded: form_helper
INFO - 2019-08-19 17:19:13 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:19:13 --> Helper loaded: date_helper
INFO - 2019-08-19 17:19:13 --> Form Validation Class Initialized
INFO - 2019-08-19 17:19:13 --> Email Class Initialized
DEBUG - 2019-08-19 17:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:19:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:19:13 --> Pagination Class Initialized
INFO - 2019-08-19 17:19:13 --> Database Driver Class Initialized
INFO - 2019-08-19 17:19:13 --> Database Driver Class Initialized
INFO - 2019-08-19 17:19:13 --> Controller Class Initialized
INFO - 2019-08-19 17:19:13 --> Final output sent to browser
DEBUG - 2019-08-19 17:19:13 --> Total execution time: 0.2520
INFO - 2019-08-19 17:19:53 --> Config Class Initialized
INFO - 2019-08-19 17:19:53 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:19:53 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:19:53 --> Utf8 Class Initialized
INFO - 2019-08-19 17:19:53 --> URI Class Initialized
INFO - 2019-08-19 17:19:53 --> Router Class Initialized
INFO - 2019-08-19 17:19:53 --> Output Class Initialized
INFO - 2019-08-19 17:19:53 --> Security Class Initialized
DEBUG - 2019-08-19 17:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:19:53 --> Input Class Initialized
INFO - 2019-08-19 17:19:53 --> Language Class Initialized
INFO - 2019-08-19 17:19:53 --> Loader Class Initialized
INFO - 2019-08-19 17:19:53 --> Helper loaded: url_helper
INFO - 2019-08-19 17:19:53 --> Helper loaded: html_helper
INFO - 2019-08-19 17:19:53 --> Helper loaded: form_helper
INFO - 2019-08-19 17:19:53 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:19:53 --> Helper loaded: date_helper
INFO - 2019-08-19 17:19:53 --> Form Validation Class Initialized
INFO - 2019-08-19 17:19:53 --> Email Class Initialized
DEBUG - 2019-08-19 17:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:19:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:19:53 --> Pagination Class Initialized
INFO - 2019-08-19 17:19:53 --> Database Driver Class Initialized
INFO - 2019-08-19 17:19:53 --> Database Driver Class Initialized
INFO - 2019-08-19 17:19:53 --> Controller Class Initialized
INFO - 2019-08-19 17:19:53 --> Final output sent to browser
DEBUG - 2019-08-19 17:19:53 --> Total execution time: 0.2280
INFO - 2019-08-19 17:20:21 --> Config Class Initialized
INFO - 2019-08-19 17:20:21 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:20:21 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:20:21 --> Utf8 Class Initialized
INFO - 2019-08-19 17:20:21 --> URI Class Initialized
INFO - 2019-08-19 17:20:21 --> Router Class Initialized
INFO - 2019-08-19 17:20:21 --> Output Class Initialized
INFO - 2019-08-19 17:20:21 --> Security Class Initialized
DEBUG - 2019-08-19 17:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:20:21 --> Input Class Initialized
INFO - 2019-08-19 17:20:21 --> Language Class Initialized
INFO - 2019-08-19 17:20:21 --> Loader Class Initialized
INFO - 2019-08-19 17:20:21 --> Helper loaded: url_helper
INFO - 2019-08-19 17:20:21 --> Helper loaded: html_helper
INFO - 2019-08-19 17:20:21 --> Helper loaded: form_helper
INFO - 2019-08-19 17:20:21 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:20:21 --> Helper loaded: date_helper
INFO - 2019-08-19 17:20:21 --> Form Validation Class Initialized
INFO - 2019-08-19 17:20:21 --> Email Class Initialized
DEBUG - 2019-08-19 17:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:20:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:20:21 --> Pagination Class Initialized
INFO - 2019-08-19 17:20:21 --> Database Driver Class Initialized
INFO - 2019-08-19 17:20:21 --> Database Driver Class Initialized
INFO - 2019-08-19 17:20:21 --> Controller Class Initialized
INFO - 2019-08-19 17:20:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:20:21 --> Config Class Initialized
INFO - 2019-08-19 17:20:21 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:20:21 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:20:21 --> Utf8 Class Initialized
INFO - 2019-08-19 17:20:21 --> URI Class Initialized
INFO - 2019-08-19 17:20:21 --> Router Class Initialized
INFO - 2019-08-19 17:20:21 --> Output Class Initialized
INFO - 2019-08-19 17:20:21 --> Security Class Initialized
DEBUG - 2019-08-19 17:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:20:21 --> Input Class Initialized
INFO - 2019-08-19 17:20:21 --> Language Class Initialized
INFO - 2019-08-19 17:20:21 --> Loader Class Initialized
INFO - 2019-08-19 17:20:21 --> Helper loaded: url_helper
INFO - 2019-08-19 17:20:21 --> Helper loaded: html_helper
INFO - 2019-08-19 17:20:21 --> Helper loaded: form_helper
INFO - 2019-08-19 17:20:21 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:20:21 --> Helper loaded: date_helper
INFO - 2019-08-19 17:20:21 --> Form Validation Class Initialized
INFO - 2019-08-19 17:20:21 --> Email Class Initialized
DEBUG - 2019-08-19 17:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:20:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:20:21 --> Pagination Class Initialized
INFO - 2019-08-19 17:20:21 --> Database Driver Class Initialized
INFO - 2019-08-19 17:20:21 --> Database Driver Class Initialized
INFO - 2019-08-19 17:20:21 --> Controller Class Initialized
INFO - 2019-08-19 17:20:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:20:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_sale.php
INFO - 2019-08-19 17:20:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:20:21 --> Final output sent to browser
DEBUG - 2019-08-19 17:20:21 --> Total execution time: 0.2120
INFO - 2019-08-19 17:21:03 --> Config Class Initialized
INFO - 2019-08-19 17:21:03 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:21:03 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:21:03 --> Utf8 Class Initialized
INFO - 2019-08-19 17:21:03 --> URI Class Initialized
INFO - 2019-08-19 17:21:03 --> Router Class Initialized
INFO - 2019-08-19 17:21:03 --> Output Class Initialized
INFO - 2019-08-19 17:21:03 --> Security Class Initialized
DEBUG - 2019-08-19 17:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:21:03 --> Input Class Initialized
INFO - 2019-08-19 17:21:03 --> Language Class Initialized
INFO - 2019-08-19 17:21:03 --> Loader Class Initialized
INFO - 2019-08-19 17:21:03 --> Helper loaded: url_helper
INFO - 2019-08-19 17:21:03 --> Helper loaded: html_helper
INFO - 2019-08-19 17:21:03 --> Helper loaded: form_helper
INFO - 2019-08-19 17:21:03 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:21:03 --> Config Class Initialized
INFO - 2019-08-19 17:21:03 --> Hooks Class Initialized
INFO - 2019-08-19 17:21:03 --> Helper loaded: date_helper
DEBUG - 2019-08-19 17:21:03 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:21:03 --> Form Validation Class Initialized
INFO - 2019-08-19 17:21:03 --> Utf8 Class Initialized
INFO - 2019-08-19 17:21:03 --> URI Class Initialized
INFO - 2019-08-19 17:21:03 --> Email Class Initialized
INFO - 2019-08-19 17:21:03 --> Router Class Initialized
DEBUG - 2019-08-19 17:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:21:03 --> Output Class Initialized
INFO - 2019-08-19 17:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:21:03 --> Security Class Initialized
INFO - 2019-08-19 17:21:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:21:03 --> Pagination Class Initialized
DEBUG - 2019-08-19 17:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:21:03 --> Input Class Initialized
INFO - 2019-08-19 17:21:03 --> Language Class Initialized
INFO - 2019-08-19 17:21:03 --> Database Driver Class Initialized
INFO - 2019-08-19 17:21:03 --> Database Driver Class Initialized
INFO - 2019-08-19 17:21:04 --> Controller Class Initialized
INFO - 2019-08-19 17:21:04 --> Loader Class Initialized
INFO - 2019-08-19 17:21:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:21:04 --> Helper loaded: url_helper
INFO - 2019-08-19 17:21:04 --> Final output sent to browser
DEBUG - 2019-08-19 17:21:04 --> Total execution time: 0.1890
INFO - 2019-08-19 17:21:04 --> Helper loaded: html_helper
INFO - 2019-08-19 17:21:04 --> Helper loaded: form_helper
INFO - 2019-08-19 17:21:04 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:21:04 --> Helper loaded: date_helper
INFO - 2019-08-19 17:21:04 --> Form Validation Class Initialized
INFO - 2019-08-19 17:21:04 --> Email Class Initialized
DEBUG - 2019-08-19 17:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:21:04 --> Pagination Class Initialized
INFO - 2019-08-19 17:21:04 --> Database Driver Class Initialized
INFO - 2019-08-19 17:21:04 --> Database Driver Class Initialized
INFO - 2019-08-19 17:21:04 --> Controller Class Initialized
INFO - 2019-08-19 17:21:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:21:04 --> Final output sent to browser
DEBUG - 2019-08-19 17:21:04 --> Total execution time: 0.2480
INFO - 2019-08-19 17:21:04 --> Config Class Initialized
INFO - 2019-08-19 17:21:04 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:21:04 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:21:04 --> Utf8 Class Initialized
INFO - 2019-08-19 17:21:04 --> URI Class Initialized
INFO - 2019-08-19 17:21:04 --> Router Class Initialized
INFO - 2019-08-19 17:21:04 --> Output Class Initialized
INFO - 2019-08-19 17:21:04 --> Security Class Initialized
DEBUG - 2019-08-19 17:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:21:04 --> Input Class Initialized
INFO - 2019-08-19 17:21:04 --> Language Class Initialized
INFO - 2019-08-19 17:21:04 --> Loader Class Initialized
INFO - 2019-08-19 17:21:04 --> Helper loaded: url_helper
INFO - 2019-08-19 17:21:04 --> Helper loaded: html_helper
INFO - 2019-08-19 17:21:04 --> Helper loaded: form_helper
INFO - 2019-08-19 17:21:04 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:21:04 --> Helper loaded: date_helper
INFO - 2019-08-19 17:21:04 --> Form Validation Class Initialized
INFO - 2019-08-19 17:21:04 --> Email Class Initialized
DEBUG - 2019-08-19 17:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:21:04 --> Pagination Class Initialized
INFO - 2019-08-19 17:21:04 --> Database Driver Class Initialized
INFO - 2019-08-19 17:21:04 --> Database Driver Class Initialized
INFO - 2019-08-19 17:21:05 --> Controller Class Initialized
INFO - 2019-08-19 17:21:05 --> Final output sent to browser
DEBUG - 2019-08-19 17:21:05 --> Total execution time: 0.2700
INFO - 2019-08-19 17:21:42 --> Config Class Initialized
INFO - 2019-08-19 17:21:42 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:21:42 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:21:42 --> Utf8 Class Initialized
INFO - 2019-08-19 17:21:42 --> URI Class Initialized
INFO - 2019-08-19 17:21:42 --> Router Class Initialized
INFO - 2019-08-19 17:21:42 --> Output Class Initialized
INFO - 2019-08-19 17:21:42 --> Security Class Initialized
DEBUG - 2019-08-19 17:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:21:42 --> Input Class Initialized
INFO - 2019-08-19 17:21:42 --> Language Class Initialized
INFO - 2019-08-19 17:21:42 --> Loader Class Initialized
INFO - 2019-08-19 17:21:42 --> Helper loaded: url_helper
INFO - 2019-08-19 17:21:42 --> Helper loaded: html_helper
INFO - 2019-08-19 17:21:42 --> Helper loaded: form_helper
INFO - 2019-08-19 17:21:42 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:21:42 --> Helper loaded: date_helper
INFO - 2019-08-19 17:21:42 --> Form Validation Class Initialized
INFO - 2019-08-19 17:21:42 --> Email Class Initialized
DEBUG - 2019-08-19 17:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:21:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:21:42 --> Pagination Class Initialized
INFO - 2019-08-19 17:21:42 --> Database Driver Class Initialized
INFO - 2019-08-19 17:21:42 --> Database Driver Class Initialized
INFO - 2019-08-19 17:21:42 --> Controller Class Initialized
INFO - 2019-08-19 17:21:42 --> Final output sent to browser
DEBUG - 2019-08-19 17:21:42 --> Total execution time: 0.2280
INFO - 2019-08-19 17:22:22 --> Config Class Initialized
INFO - 2019-08-19 17:22:22 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:22:22 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:22:22 --> Utf8 Class Initialized
INFO - 2019-08-19 17:22:22 --> URI Class Initialized
INFO - 2019-08-19 17:22:22 --> Router Class Initialized
INFO - 2019-08-19 17:22:22 --> Output Class Initialized
INFO - 2019-08-19 17:22:22 --> Security Class Initialized
DEBUG - 2019-08-19 17:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:22:22 --> Input Class Initialized
INFO - 2019-08-19 17:22:22 --> Language Class Initialized
INFO - 2019-08-19 17:22:22 --> Loader Class Initialized
INFO - 2019-08-19 17:22:22 --> Helper loaded: url_helper
INFO - 2019-08-19 17:22:22 --> Helper loaded: html_helper
INFO - 2019-08-19 17:22:22 --> Helper loaded: form_helper
INFO - 2019-08-19 17:22:22 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:22:22 --> Helper loaded: date_helper
INFO - 2019-08-19 17:22:22 --> Form Validation Class Initialized
INFO - 2019-08-19 17:22:22 --> Email Class Initialized
DEBUG - 2019-08-19 17:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:22:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:22:22 --> Pagination Class Initialized
INFO - 2019-08-19 17:22:22 --> Database Driver Class Initialized
INFO - 2019-08-19 17:22:22 --> Database Driver Class Initialized
INFO - 2019-08-19 17:22:22 --> Controller Class Initialized
INFO - 2019-08-19 17:22:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:22:22 --> Config Class Initialized
INFO - 2019-08-19 17:22:22 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:22:22 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:22:22 --> Utf8 Class Initialized
INFO - 2019-08-19 17:22:22 --> URI Class Initialized
INFO - 2019-08-19 17:22:22 --> Router Class Initialized
INFO - 2019-08-19 17:22:22 --> Output Class Initialized
INFO - 2019-08-19 17:22:22 --> Security Class Initialized
DEBUG - 2019-08-19 17:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:22:22 --> Input Class Initialized
INFO - 2019-08-19 17:22:22 --> Language Class Initialized
INFO - 2019-08-19 17:22:22 --> Loader Class Initialized
INFO - 2019-08-19 17:22:22 --> Helper loaded: url_helper
INFO - 2019-08-19 17:22:22 --> Helper loaded: html_helper
INFO - 2019-08-19 17:22:22 --> Helper loaded: form_helper
INFO - 2019-08-19 17:22:22 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:22:22 --> Helper loaded: date_helper
INFO - 2019-08-19 17:22:22 --> Form Validation Class Initialized
INFO - 2019-08-19 17:22:22 --> Email Class Initialized
DEBUG - 2019-08-19 17:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:22:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:22:22 --> Pagination Class Initialized
INFO - 2019-08-19 17:22:22 --> Database Driver Class Initialized
INFO - 2019-08-19 17:22:22 --> Database Driver Class Initialized
INFO - 2019-08-19 17:22:22 --> Controller Class Initialized
INFO - 2019-08-19 17:22:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:22:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_sale.php
INFO - 2019-08-19 17:22:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:22:22 --> Final output sent to browser
DEBUG - 2019-08-19 17:22:22 --> Total execution time: 0.1980
INFO - 2019-08-19 17:23:05 --> Config Class Initialized
INFO - 2019-08-19 17:23:05 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:23:05 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:23:05 --> Utf8 Class Initialized
INFO - 2019-08-19 17:23:05 --> URI Class Initialized
INFO - 2019-08-19 17:23:05 --> Router Class Initialized
INFO - 2019-08-19 17:23:05 --> Output Class Initialized
INFO - 2019-08-19 17:23:05 --> Security Class Initialized
DEBUG - 2019-08-19 17:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:23:05 --> Input Class Initialized
INFO - 2019-08-19 17:23:05 --> Language Class Initialized
INFO - 2019-08-19 17:23:05 --> Config Class Initialized
INFO - 2019-08-19 17:23:05 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:23:05 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:23:05 --> Utf8 Class Initialized
INFO - 2019-08-19 17:23:05 --> Loader Class Initialized
INFO - 2019-08-19 17:23:05 --> Helper loaded: url_helper
INFO - 2019-08-19 17:23:05 --> Helper loaded: html_helper
INFO - 2019-08-19 17:23:05 --> Helper loaded: form_helper
INFO - 2019-08-19 17:23:05 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:23:05 --> Helper loaded: date_helper
INFO - 2019-08-19 17:23:05 --> Form Validation Class Initialized
INFO - 2019-08-19 17:23:05 --> URI Class Initialized
INFO - 2019-08-19 17:23:05 --> Router Class Initialized
INFO - 2019-08-19 17:23:05 --> Output Class Initialized
INFO - 2019-08-19 17:23:05 --> Security Class Initialized
DEBUG - 2019-08-19 17:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:23:05 --> Input Class Initialized
INFO - 2019-08-19 17:23:05 --> Language Class Initialized
INFO - 2019-08-19 17:23:05 --> Email Class Initialized
DEBUG - 2019-08-19 17:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:23:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:23:05 --> Pagination Class Initialized
INFO - 2019-08-19 17:23:05 --> Loader Class Initialized
INFO - 2019-08-19 17:23:05 --> Helper loaded: url_helper
INFO - 2019-08-19 17:23:05 --> Helper loaded: html_helper
INFO - 2019-08-19 17:23:05 --> Helper loaded: form_helper
INFO - 2019-08-19 17:23:05 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:23:05 --> Helper loaded: date_helper
INFO - 2019-08-19 17:23:05 --> Form Validation Class Initialized
INFO - 2019-08-19 17:23:05 --> Database Driver Class Initialized
INFO - 2019-08-19 17:23:05 --> Database Driver Class Initialized
INFO - 2019-08-19 17:23:05 --> Email Class Initialized
DEBUG - 2019-08-19 17:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:23:05 --> Controller Class Initialized
INFO - 2019-08-19 17:23:05 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:23:05 --> Final output sent to browser
DEBUG - 2019-08-19 17:23:05 --> Total execution time: 0.3010
INFO - 2019-08-19 17:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:23:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:23:05 --> Pagination Class Initialized
INFO - 2019-08-19 17:23:05 --> Database Driver Class Initialized
INFO - 2019-08-19 17:23:05 --> Database Driver Class Initialized
INFO - 2019-08-19 17:23:05 --> Controller Class Initialized
INFO - 2019-08-19 17:23:05 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:23:05 --> Final output sent to browser
DEBUG - 2019-08-19 17:23:05 --> Total execution time: 0.3190
INFO - 2019-08-19 17:23:05 --> Config Class Initialized
INFO - 2019-08-19 17:23:05 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:23:05 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:23:05 --> Utf8 Class Initialized
INFO - 2019-08-19 17:23:05 --> URI Class Initialized
INFO - 2019-08-19 17:23:05 --> Router Class Initialized
INFO - 2019-08-19 17:23:05 --> Output Class Initialized
INFO - 2019-08-19 17:23:05 --> Security Class Initialized
DEBUG - 2019-08-19 17:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:23:05 --> Input Class Initialized
INFO - 2019-08-19 17:23:05 --> Language Class Initialized
INFO - 2019-08-19 17:23:05 --> Loader Class Initialized
INFO - 2019-08-19 17:23:05 --> Helper loaded: url_helper
INFO - 2019-08-19 17:23:05 --> Helper loaded: html_helper
INFO - 2019-08-19 17:23:05 --> Helper loaded: form_helper
INFO - 2019-08-19 17:23:05 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:23:05 --> Helper loaded: date_helper
INFO - 2019-08-19 17:23:05 --> Form Validation Class Initialized
INFO - 2019-08-19 17:23:05 --> Email Class Initialized
DEBUG - 2019-08-19 17:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:23:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:23:06 --> Pagination Class Initialized
INFO - 2019-08-19 17:23:06 --> Database Driver Class Initialized
INFO - 2019-08-19 17:23:06 --> Database Driver Class Initialized
INFO - 2019-08-19 17:23:06 --> Controller Class Initialized
INFO - 2019-08-19 17:23:06 --> Final output sent to browser
DEBUG - 2019-08-19 17:23:06 --> Total execution time: 0.2600
INFO - 2019-08-19 17:27:11 --> Config Class Initialized
INFO - 2019-08-19 17:27:11 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:27:11 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:27:11 --> Utf8 Class Initialized
INFO - 2019-08-19 17:27:11 --> URI Class Initialized
INFO - 2019-08-19 17:27:11 --> Router Class Initialized
INFO - 2019-08-19 17:27:11 --> Output Class Initialized
INFO - 2019-08-19 17:27:11 --> Security Class Initialized
DEBUG - 2019-08-19 17:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:27:11 --> Input Class Initialized
INFO - 2019-08-19 17:27:11 --> Language Class Initialized
INFO - 2019-08-19 17:27:11 --> Loader Class Initialized
INFO - 2019-08-19 17:27:11 --> Helper loaded: url_helper
INFO - 2019-08-19 17:27:11 --> Helper loaded: html_helper
INFO - 2019-08-19 17:27:11 --> Helper loaded: form_helper
INFO - 2019-08-19 17:27:11 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:27:11 --> Helper loaded: date_helper
INFO - 2019-08-19 17:27:11 --> Form Validation Class Initialized
INFO - 2019-08-19 17:27:11 --> Email Class Initialized
DEBUG - 2019-08-19 17:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:27:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:27:11 --> Pagination Class Initialized
INFO - 2019-08-19 17:27:11 --> Database Driver Class Initialized
INFO - 2019-08-19 17:27:11 --> Database Driver Class Initialized
INFO - 2019-08-19 17:27:11 --> Controller Class Initialized
INFO - 2019-08-19 17:27:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:27:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_payment.php
INFO - 2019-08-19 17:27:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:27:11 --> Final output sent to browser
DEBUG - 2019-08-19 17:27:11 --> Total execution time: 0.2130
INFO - 2019-08-19 17:28:00 --> Config Class Initialized
INFO - 2019-08-19 17:28:00 --> Hooks Class Initialized
INFO - 2019-08-19 17:28:00 --> Config Class Initialized
INFO - 2019-08-19 17:28:00 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:28:00 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:28:00 --> Utf8 Class Initialized
DEBUG - 2019-08-19 17:28:00 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:28:00 --> URI Class Initialized
INFO - 2019-08-19 17:28:00 --> Utf8 Class Initialized
INFO - 2019-08-19 17:28:00 --> Config Class Initialized
INFO - 2019-08-19 17:28:00 --> Router Class Initialized
INFO - 2019-08-19 17:28:00 --> URI Class Initialized
INFO - 2019-08-19 17:28:00 --> Hooks Class Initialized
INFO - 2019-08-19 17:28:00 --> Output Class Initialized
INFO - 2019-08-19 17:28:00 --> Router Class Initialized
DEBUG - 2019-08-19 17:28:00 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:28:00 --> Security Class Initialized
INFO - 2019-08-19 17:28:00 --> Utf8 Class Initialized
DEBUG - 2019-08-19 17:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:28:00 --> Input Class Initialized
INFO - 2019-08-19 17:28:00 --> Language Class Initialized
INFO - 2019-08-19 17:28:00 --> Output Class Initialized
INFO - 2019-08-19 17:28:00 --> Security Class Initialized
DEBUG - 2019-08-19 17:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:28:00 --> Input Class Initialized
INFO - 2019-08-19 17:28:00 --> Language Class Initialized
INFO - 2019-08-19 17:28:00 --> URI Class Initialized
INFO - 2019-08-19 17:28:00 --> Router Class Initialized
INFO - 2019-08-19 17:28:00 --> Output Class Initialized
INFO - 2019-08-19 17:28:00 --> Security Class Initialized
DEBUG - 2019-08-19 17:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:28:00 --> Input Class Initialized
INFO - 2019-08-19 17:28:00 --> Language Class Initialized
INFO - 2019-08-19 17:28:00 --> Loader Class Initialized
INFO - 2019-08-19 17:28:00 --> Helper loaded: url_helper
INFO - 2019-08-19 17:28:00 --> Helper loaded: html_helper
INFO - 2019-08-19 17:28:00 --> Helper loaded: form_helper
INFO - 2019-08-19 17:28:00 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:28:00 --> Helper loaded: date_helper
INFO - 2019-08-19 17:28:00 --> Loader Class Initialized
INFO - 2019-08-19 17:28:00 --> Helper loaded: url_helper
INFO - 2019-08-19 17:28:00 --> Helper loaded: html_helper
INFO - 2019-08-19 17:28:00 --> Helper loaded: form_helper
INFO - 2019-08-19 17:28:00 --> Form Validation Class Initialized
INFO - 2019-08-19 17:28:00 --> Loader Class Initialized
INFO - 2019-08-19 17:28:00 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:28:00 --> Helper loaded: date_helper
INFO - 2019-08-19 17:28:00 --> Helper loaded: url_helper
INFO - 2019-08-19 17:28:00 --> Helper loaded: html_helper
INFO - 2019-08-19 17:28:00 --> Form Validation Class Initialized
INFO - 2019-08-19 17:28:00 --> Helper loaded: form_helper
INFO - 2019-08-19 17:28:00 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:28:00 --> Email Class Initialized
INFO - 2019-08-19 17:28:00 --> Helper loaded: date_helper
DEBUG - 2019-08-19 17:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:28:00 --> Form Validation Class Initialized
INFO - 2019-08-19 17:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:28:00 --> Email Class Initialized
INFO - 2019-08-19 17:28:00 --> Email Class Initialized
INFO - 2019-08-19 17:28:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:28:00 --> Pagination Class Initialized
DEBUG - 2019-08-19 17:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-19 17:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:28:00 --> Database Driver Class Initialized
INFO - 2019-08-19 17:28:00 --> Database Driver Class Initialized
INFO - 2019-08-19 17:28:00 --> Controller Class Initialized
INFO - 2019-08-19 17:28:00 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:28:00 --> Final output sent to browser
DEBUG - 2019-08-19 17:28:00 --> Total execution time: 0.3190
INFO - 2019-08-19 17:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:28:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:28:00 --> Pagination Class Initialized
INFO - 2019-08-19 17:28:00 --> Database Driver Class Initialized
INFO - 2019-08-19 17:28:00 --> Database Driver Class Initialized
INFO - 2019-08-19 17:28:00 --> Controller Class Initialized
INFO - 2019-08-19 17:28:00 --> Final output sent to browser
DEBUG - 2019-08-19 17:28:00 --> Total execution time: 0.4180
INFO - 2019-08-19 17:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:28:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:28:00 --> Pagination Class Initialized
INFO - 2019-08-19 17:28:00 --> Database Driver Class Initialized
INFO - 2019-08-19 17:28:00 --> Database Driver Class Initialized
INFO - 2019-08-19 17:28:00 --> Controller Class Initialized
INFO - 2019-08-19 17:28:00 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:28:00 --> Final output sent to browser
DEBUG - 2019-08-19 17:28:00 --> Total execution time: 0.4560
INFO - 2019-08-19 17:28:17 --> Config Class Initialized
INFO - 2019-08-19 17:28:17 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:28:17 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:28:17 --> Utf8 Class Initialized
INFO - 2019-08-19 17:28:17 --> URI Class Initialized
INFO - 2019-08-19 17:28:18 --> Router Class Initialized
INFO - 2019-08-19 17:28:18 --> Output Class Initialized
INFO - 2019-08-19 17:28:18 --> Security Class Initialized
DEBUG - 2019-08-19 17:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:28:18 --> Input Class Initialized
INFO - 2019-08-19 17:28:18 --> Language Class Initialized
INFO - 2019-08-19 17:28:18 --> Loader Class Initialized
INFO - 2019-08-19 17:28:18 --> Helper loaded: url_helper
INFO - 2019-08-19 17:28:18 --> Helper loaded: html_helper
INFO - 2019-08-19 17:28:18 --> Helper loaded: form_helper
INFO - 2019-08-19 17:28:18 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:28:18 --> Helper loaded: date_helper
INFO - 2019-08-19 17:28:18 --> Form Validation Class Initialized
INFO - 2019-08-19 17:28:18 --> Email Class Initialized
DEBUG - 2019-08-19 17:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:28:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:28:18 --> Pagination Class Initialized
INFO - 2019-08-19 17:28:18 --> Database Driver Class Initialized
INFO - 2019-08-19 17:28:18 --> Database Driver Class Initialized
INFO - 2019-08-19 17:28:18 --> Controller Class Initialized
INFO - 2019-08-19 17:28:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:28:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_plu_group.php
INFO - 2019-08-19 17:28:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:28:18 --> Final output sent to browser
DEBUG - 2019-08-19 17:28:18 --> Total execution time: 0.2010
INFO - 2019-08-19 17:29:00 --> Config Class Initialized
INFO - 2019-08-19 17:29:00 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:29:00 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:29:00 --> Utf8 Class Initialized
INFO - 2019-08-19 17:29:00 --> URI Class Initialized
INFO - 2019-08-19 17:29:00 --> Config Class Initialized
INFO - 2019-08-19 17:29:00 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:29:00 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:29:00 --> Utf8 Class Initialized
INFO - 2019-08-19 17:29:00 --> URI Class Initialized
INFO - 2019-08-19 17:29:00 --> Router Class Initialized
INFO - 2019-08-19 17:29:00 --> Output Class Initialized
INFO - 2019-08-19 17:29:00 --> Security Class Initialized
DEBUG - 2019-08-19 17:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:29:00 --> Input Class Initialized
INFO - 2019-08-19 17:29:00 --> Language Class Initialized
INFO - 2019-08-19 17:29:00 --> Loader Class Initialized
INFO - 2019-08-19 17:29:00 --> Router Class Initialized
INFO - 2019-08-19 17:29:00 --> Output Class Initialized
INFO - 2019-08-19 17:29:00 --> Security Class Initialized
DEBUG - 2019-08-19 17:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:29:00 --> Input Class Initialized
INFO - 2019-08-19 17:29:00 --> Language Class Initialized
INFO - 2019-08-19 17:29:00 --> Helper loaded: url_helper
INFO - 2019-08-19 17:29:00 --> Helper loaded: html_helper
INFO - 2019-08-19 17:29:00 --> Helper loaded: form_helper
INFO - 2019-08-19 17:29:00 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:29:00 --> Helper loaded: date_helper
INFO - 2019-08-19 17:29:00 --> Form Validation Class Initialized
INFO - 2019-08-19 17:29:00 --> Email Class Initialized
INFO - 2019-08-19 17:29:00 --> Loader Class Initialized
INFO - 2019-08-19 17:29:00 --> Helper loaded: url_helper
INFO - 2019-08-19 17:29:00 --> Helper loaded: html_helper
INFO - 2019-08-19 17:29:00 --> Helper loaded: form_helper
INFO - 2019-08-19 17:29:00 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:29:00 --> Helper loaded: date_helper
INFO - 2019-08-19 17:29:00 --> Form Validation Class Initialized
INFO - 2019-08-19 17:29:00 --> Email Class Initialized
DEBUG - 2019-08-19 17:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:29:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:29:00 --> Pagination Class Initialized
INFO - 2019-08-19 17:29:00 --> Database Driver Class Initialized
DEBUG - 2019-08-19 17:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:29:00 --> Database Driver Class Initialized
INFO - 2019-08-19 17:29:00 --> Controller Class Initialized
INFO - 2019-08-19 17:29:00 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:29:00 --> Final output sent to browser
DEBUG - 2019-08-19 17:29:00 --> Total execution time: 0.3168
INFO - 2019-08-19 17:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:29:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:29:00 --> Pagination Class Initialized
INFO - 2019-08-19 17:29:00 --> Database Driver Class Initialized
INFO - 2019-08-19 17:29:00 --> Database Driver Class Initialized
INFO - 2019-08-19 17:29:00 --> Controller Class Initialized
INFO - 2019-08-19 17:29:00 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:29:00 --> Final output sent to browser
DEBUG - 2019-08-19 17:29:00 --> Total execution time: 0.3658
INFO - 2019-08-19 17:29:01 --> Config Class Initialized
INFO - 2019-08-19 17:29:01 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:29:01 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:29:01 --> Utf8 Class Initialized
INFO - 2019-08-19 17:29:01 --> URI Class Initialized
INFO - 2019-08-19 17:29:01 --> Router Class Initialized
INFO - 2019-08-19 17:29:01 --> Output Class Initialized
INFO - 2019-08-19 17:29:01 --> Security Class Initialized
DEBUG - 2019-08-19 17:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:29:01 --> Input Class Initialized
INFO - 2019-08-19 17:29:01 --> Language Class Initialized
INFO - 2019-08-19 17:29:01 --> Loader Class Initialized
INFO - 2019-08-19 17:29:01 --> Helper loaded: url_helper
INFO - 2019-08-19 17:29:01 --> Helper loaded: html_helper
INFO - 2019-08-19 17:29:01 --> Helper loaded: form_helper
INFO - 2019-08-19 17:29:01 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:29:01 --> Helper loaded: date_helper
INFO - 2019-08-19 17:29:01 --> Form Validation Class Initialized
INFO - 2019-08-19 17:29:01 --> Email Class Initialized
DEBUG - 2019-08-19 17:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:29:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:29:01 --> Pagination Class Initialized
INFO - 2019-08-19 17:29:01 --> Database Driver Class Initialized
INFO - 2019-08-19 17:29:01 --> Database Driver Class Initialized
INFO - 2019-08-19 17:29:01 --> Controller Class Initialized
INFO - 2019-08-19 17:29:01 --> Final output sent to browser
DEBUG - 2019-08-19 17:29:01 --> Total execution time: 0.2832
INFO - 2019-08-19 17:29:33 --> Config Class Initialized
INFO - 2019-08-19 17:29:33 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:29:33 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:29:33 --> Utf8 Class Initialized
INFO - 2019-08-19 17:29:33 --> URI Class Initialized
INFO - 2019-08-19 17:29:33 --> Router Class Initialized
INFO - 2019-08-19 17:29:33 --> Output Class Initialized
INFO - 2019-08-19 17:29:33 --> Security Class Initialized
DEBUG - 2019-08-19 17:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:29:33 --> Input Class Initialized
INFO - 2019-08-19 17:29:33 --> Language Class Initialized
INFO - 2019-08-19 17:29:33 --> Loader Class Initialized
INFO - 2019-08-19 17:29:33 --> Helper loaded: url_helper
INFO - 2019-08-19 17:29:33 --> Helper loaded: html_helper
INFO - 2019-08-19 17:29:33 --> Helper loaded: form_helper
INFO - 2019-08-19 17:29:33 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:29:33 --> Helper loaded: date_helper
INFO - 2019-08-19 17:29:33 --> Form Validation Class Initialized
INFO - 2019-08-19 17:29:33 --> Email Class Initialized
DEBUG - 2019-08-19 17:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:29:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:29:33 --> Pagination Class Initialized
INFO - 2019-08-19 17:29:33 --> Database Driver Class Initialized
INFO - 2019-08-19 17:29:33 --> Database Driver Class Initialized
INFO - 2019-08-19 17:29:33 --> Controller Class Initialized
INFO - 2019-08-19 17:29:33 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:29:33 --> Final output sent to browser
DEBUG - 2019-08-19 17:29:33 --> Total execution time: 0.2652
INFO - 2019-08-19 17:29:35 --> Config Class Initialized
INFO - 2019-08-19 17:29:35 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:29:35 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:29:35 --> Utf8 Class Initialized
INFO - 2019-08-19 17:29:35 --> URI Class Initialized
INFO - 2019-08-19 17:29:35 --> Router Class Initialized
INFO - 2019-08-19 17:29:35 --> Output Class Initialized
INFO - 2019-08-19 17:29:35 --> Security Class Initialized
DEBUG - 2019-08-19 17:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:29:35 --> Input Class Initialized
INFO - 2019-08-19 17:29:35 --> Language Class Initialized
INFO - 2019-08-19 17:29:35 --> Loader Class Initialized
INFO - 2019-08-19 17:29:35 --> Helper loaded: url_helper
INFO - 2019-08-19 17:29:35 --> Helper loaded: html_helper
INFO - 2019-08-19 17:29:35 --> Helper loaded: form_helper
INFO - 2019-08-19 17:29:35 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:29:35 --> Helper loaded: date_helper
INFO - 2019-08-19 17:29:35 --> Form Validation Class Initialized
INFO - 2019-08-19 17:29:35 --> Email Class Initialized
DEBUG - 2019-08-19 17:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:29:35 --> Pagination Class Initialized
INFO - 2019-08-19 17:29:35 --> Database Driver Class Initialized
INFO - 2019-08-19 17:29:35 --> Database Driver Class Initialized
INFO - 2019-08-19 17:29:35 --> Controller Class Initialized
INFO - 2019-08-19 17:29:35 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:29:35 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-19 17:29:35 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:29:35 --> Final output sent to browser
DEBUG - 2019-08-19 17:29:35 --> Total execution time: 0.1872
INFO - 2019-08-19 17:30:17 --> Config Class Initialized
INFO - 2019-08-19 17:30:17 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:30:17 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:30:17 --> Utf8 Class Initialized
INFO - 2019-08-19 17:30:17 --> URI Class Initialized
INFO - 2019-08-19 17:30:17 --> Router Class Initialized
INFO - 2019-08-19 17:30:17 --> Output Class Initialized
INFO - 2019-08-19 17:30:17 --> Security Class Initialized
DEBUG - 2019-08-19 17:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:30:17 --> Input Class Initialized
INFO - 2019-08-19 17:30:17 --> Language Class Initialized
INFO - 2019-08-19 17:30:17 --> Loader Class Initialized
INFO - 2019-08-19 17:30:17 --> Helper loaded: url_helper
INFO - 2019-08-19 17:30:17 --> Helper loaded: html_helper
INFO - 2019-08-19 17:30:17 --> Helper loaded: form_helper
INFO - 2019-08-19 17:30:17 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:30:17 --> Helper loaded: date_helper
INFO - 2019-08-19 17:30:17 --> Form Validation Class Initialized
INFO - 2019-08-19 17:30:17 --> Email Class Initialized
DEBUG - 2019-08-19 17:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:30:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:30:17 --> Pagination Class Initialized
INFO - 2019-08-19 17:30:17 --> Database Driver Class Initialized
INFO - 2019-08-19 17:30:17 --> Database Driver Class Initialized
INFO - 2019-08-19 17:30:17 --> Controller Class Initialized
INFO - 2019-08-19 17:30:17 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:30:17 --> Final output sent to browser
DEBUG - 2019-08-19 17:30:17 --> Total execution time: 0.2050
INFO - 2019-08-19 17:30:18 --> Config Class Initialized
INFO - 2019-08-19 17:30:18 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:30:18 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:30:18 --> Utf8 Class Initialized
INFO - 2019-08-19 17:30:18 --> URI Class Initialized
INFO - 2019-08-19 17:30:18 --> Router Class Initialized
INFO - 2019-08-19 17:30:18 --> Output Class Initialized
INFO - 2019-08-19 17:30:18 --> Security Class Initialized
DEBUG - 2019-08-19 17:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:30:18 --> Input Class Initialized
INFO - 2019-08-19 17:30:18 --> Language Class Initialized
INFO - 2019-08-19 17:30:18 --> Loader Class Initialized
INFO - 2019-08-19 17:30:18 --> Helper loaded: url_helper
INFO - 2019-08-19 17:30:18 --> Helper loaded: html_helper
INFO - 2019-08-19 17:30:18 --> Helper loaded: form_helper
INFO - 2019-08-19 17:30:18 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:30:18 --> Helper loaded: date_helper
INFO - 2019-08-19 17:30:18 --> Form Validation Class Initialized
INFO - 2019-08-19 17:30:18 --> Email Class Initialized
DEBUG - 2019-08-19 17:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:30:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:30:18 --> Pagination Class Initialized
INFO - 2019-08-19 17:30:18 --> Database Driver Class Initialized
INFO - 2019-08-19 17:30:18 --> Database Driver Class Initialized
INFO - 2019-08-19 17:30:18 --> Controller Class Initialized
INFO - 2019-08-19 17:30:18 --> Final output sent to browser
DEBUG - 2019-08-19 17:30:18 --> Total execution time: 0.2980
INFO - 2019-08-19 17:30:30 --> Config Class Initialized
INFO - 2019-08-19 17:30:30 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:30:30 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:30:30 --> Utf8 Class Initialized
INFO - 2019-08-19 17:30:30 --> URI Class Initialized
INFO - 2019-08-19 17:30:30 --> Router Class Initialized
INFO - 2019-08-19 17:30:30 --> Output Class Initialized
INFO - 2019-08-19 17:30:30 --> Security Class Initialized
DEBUG - 2019-08-19 17:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:30:30 --> Input Class Initialized
INFO - 2019-08-19 17:30:30 --> Language Class Initialized
INFO - 2019-08-19 17:30:30 --> Loader Class Initialized
INFO - 2019-08-19 17:30:30 --> Helper loaded: url_helper
INFO - 2019-08-19 17:30:30 --> Helper loaded: html_helper
INFO - 2019-08-19 17:30:30 --> Helper loaded: form_helper
INFO - 2019-08-19 17:30:30 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:30:30 --> Helper loaded: date_helper
INFO - 2019-08-19 17:30:30 --> Form Validation Class Initialized
INFO - 2019-08-19 17:30:30 --> Email Class Initialized
DEBUG - 2019-08-19 17:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:30:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:30:30 --> Pagination Class Initialized
INFO - 2019-08-19 17:30:30 --> Database Driver Class Initialized
INFO - 2019-08-19 17:30:30 --> Database Driver Class Initialized
INFO - 2019-08-19 17:30:30 --> Controller Class Initialized
INFO - 2019-08-19 17:30:30 --> Final output sent to browser
DEBUG - 2019-08-19 17:30:30 --> Total execution time: 0.2460
INFO - 2019-08-19 17:33:36 --> Config Class Initialized
INFO - 2019-08-19 17:33:36 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:33:36 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:33:36 --> Utf8 Class Initialized
INFO - 2019-08-19 17:33:36 --> URI Class Initialized
INFO - 2019-08-19 17:33:36 --> Router Class Initialized
INFO - 2019-08-19 17:33:36 --> Output Class Initialized
INFO - 2019-08-19 17:33:36 --> Security Class Initialized
DEBUG - 2019-08-19 17:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:33:36 --> Input Class Initialized
INFO - 2019-08-19 17:33:36 --> Language Class Initialized
INFO - 2019-08-19 17:33:36 --> Loader Class Initialized
INFO - 2019-08-19 17:33:36 --> Helper loaded: url_helper
INFO - 2019-08-19 17:33:36 --> Helper loaded: html_helper
INFO - 2019-08-19 17:33:36 --> Helper loaded: form_helper
INFO - 2019-08-19 17:33:36 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:33:36 --> Helper loaded: date_helper
INFO - 2019-08-19 17:33:36 --> Form Validation Class Initialized
INFO - 2019-08-19 17:33:36 --> Email Class Initialized
DEBUG - 2019-08-19 17:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:33:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:33:36 --> Pagination Class Initialized
INFO - 2019-08-19 17:33:36 --> Database Driver Class Initialized
INFO - 2019-08-19 17:33:36 --> Database Driver Class Initialized
INFO - 2019-08-19 17:33:36 --> Controller Class Initialized
INFO - 2019-08-19 17:33:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:33:36 --> Config Class Initialized
INFO - 2019-08-19 17:33:36 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:33:36 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:33:36 --> Utf8 Class Initialized
INFO - 2019-08-19 17:33:36 --> URI Class Initialized
INFO - 2019-08-19 17:33:36 --> Router Class Initialized
INFO - 2019-08-19 17:33:36 --> Output Class Initialized
INFO - 2019-08-19 17:33:36 --> Security Class Initialized
DEBUG - 2019-08-19 17:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:33:36 --> Input Class Initialized
INFO - 2019-08-19 17:33:36 --> Language Class Initialized
INFO - 2019-08-19 17:33:36 --> Loader Class Initialized
INFO - 2019-08-19 17:33:36 --> Helper loaded: url_helper
INFO - 2019-08-19 17:33:36 --> Helper loaded: html_helper
INFO - 2019-08-19 17:33:36 --> Helper loaded: form_helper
INFO - 2019-08-19 17:33:36 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:33:36 --> Helper loaded: date_helper
INFO - 2019-08-19 17:33:36 --> Form Validation Class Initialized
INFO - 2019-08-19 17:33:36 --> Email Class Initialized
DEBUG - 2019-08-19 17:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:33:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:33:36 --> Pagination Class Initialized
INFO - 2019-08-19 17:33:36 --> Database Driver Class Initialized
INFO - 2019-08-19 17:33:36 --> Database Driver Class Initialized
INFO - 2019-08-19 17:33:36 --> Controller Class Initialized
INFO - 2019-08-19 17:33:36 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:33:36 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-19 17:33:36 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:33:36 --> Final output sent to browser
DEBUG - 2019-08-19 17:33:36 --> Total execution time: 0.2170
INFO - 2019-08-19 17:34:39 --> Config Class Initialized
INFO - 2019-08-19 17:34:39 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:34:39 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:34:39 --> Utf8 Class Initialized
INFO - 2019-08-19 17:34:39 --> URI Class Initialized
INFO - 2019-08-19 17:34:39 --> Router Class Initialized
INFO - 2019-08-19 17:34:39 --> Output Class Initialized
INFO - 2019-08-19 17:34:39 --> Security Class Initialized
DEBUG - 2019-08-19 17:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:34:39 --> Input Class Initialized
INFO - 2019-08-19 17:34:39 --> Language Class Initialized
INFO - 2019-08-19 17:34:39 --> Loader Class Initialized
INFO - 2019-08-19 17:34:39 --> Helper loaded: url_helper
INFO - 2019-08-19 17:34:39 --> Helper loaded: html_helper
INFO - 2019-08-19 17:34:39 --> Helper loaded: form_helper
INFO - 2019-08-19 17:34:39 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:34:39 --> Helper loaded: date_helper
INFO - 2019-08-19 17:34:39 --> Form Validation Class Initialized
INFO - 2019-08-19 17:34:39 --> Email Class Initialized
DEBUG - 2019-08-19 17:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:34:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:34:39 --> Pagination Class Initialized
INFO - 2019-08-19 17:34:39 --> Database Driver Class Initialized
INFO - 2019-08-19 17:34:39 --> Database Driver Class Initialized
INFO - 2019-08-19 17:34:40 --> Controller Class Initialized
INFO - 2019-08-19 17:34:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:34:40 --> Final output sent to browser
DEBUG - 2019-08-19 17:34:40 --> Total execution time: 0.2940
INFO - 2019-08-19 17:34:41 --> Config Class Initialized
INFO - 2019-08-19 17:34:41 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:34:41 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:34:41 --> Utf8 Class Initialized
INFO - 2019-08-19 17:34:41 --> URI Class Initialized
INFO - 2019-08-19 17:34:41 --> Router Class Initialized
INFO - 2019-08-19 17:34:41 --> Output Class Initialized
INFO - 2019-08-19 17:34:41 --> Security Class Initialized
DEBUG - 2019-08-19 17:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:34:41 --> Input Class Initialized
INFO - 2019-08-19 17:34:41 --> Language Class Initialized
INFO - 2019-08-19 17:34:41 --> Loader Class Initialized
INFO - 2019-08-19 17:34:41 --> Helper loaded: url_helper
INFO - 2019-08-19 17:34:41 --> Helper loaded: html_helper
INFO - 2019-08-19 17:34:41 --> Helper loaded: form_helper
INFO - 2019-08-19 17:34:41 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:34:41 --> Helper loaded: date_helper
INFO - 2019-08-19 17:34:41 --> Form Validation Class Initialized
INFO - 2019-08-19 17:34:41 --> Email Class Initialized
DEBUG - 2019-08-19 17:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:34:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:34:41 --> Pagination Class Initialized
INFO - 2019-08-19 17:34:41 --> Database Driver Class Initialized
INFO - 2019-08-19 17:34:41 --> Database Driver Class Initialized
INFO - 2019-08-19 17:34:41 --> Controller Class Initialized
INFO - 2019-08-19 17:34:41 --> Final output sent to browser
DEBUG - 2019-08-19 17:34:41 --> Total execution time: 0.4290
INFO - 2019-08-19 17:40:06 --> Config Class Initialized
INFO - 2019-08-19 17:40:06 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:40:06 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:40:06 --> Utf8 Class Initialized
INFO - 2019-08-19 17:40:06 --> URI Class Initialized
INFO - 2019-08-19 17:40:06 --> Router Class Initialized
INFO - 2019-08-19 17:40:06 --> Output Class Initialized
INFO - 2019-08-19 17:40:06 --> Security Class Initialized
DEBUG - 2019-08-19 17:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:40:06 --> Input Class Initialized
INFO - 2019-08-19 17:40:06 --> Language Class Initialized
INFO - 2019-08-19 17:40:06 --> Loader Class Initialized
INFO - 2019-08-19 17:40:06 --> Helper loaded: url_helper
INFO - 2019-08-19 17:40:06 --> Helper loaded: html_helper
INFO - 2019-08-19 17:40:06 --> Helper loaded: form_helper
INFO - 2019-08-19 17:40:06 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:40:06 --> Helper loaded: date_helper
INFO - 2019-08-19 17:40:06 --> Form Validation Class Initialized
INFO - 2019-08-19 17:40:06 --> Email Class Initialized
DEBUG - 2019-08-19 17:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:40:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:40:06 --> Pagination Class Initialized
INFO - 2019-08-19 17:40:06 --> Database Driver Class Initialized
INFO - 2019-08-19 17:40:06 --> Database Driver Class Initialized
INFO - 2019-08-19 17:40:06 --> Controller Class Initialized
INFO - 2019-08-19 17:40:06 --> Final output sent to browser
DEBUG - 2019-08-19 17:40:06 --> Total execution time: 0.3020
INFO - 2019-08-19 17:40:54 --> Config Class Initialized
INFO - 2019-08-19 17:40:54 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:40:54 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:40:54 --> Utf8 Class Initialized
INFO - 2019-08-19 17:40:54 --> URI Class Initialized
INFO - 2019-08-19 17:40:54 --> Router Class Initialized
INFO - 2019-08-19 17:40:54 --> Output Class Initialized
INFO - 2019-08-19 17:40:54 --> Security Class Initialized
DEBUG - 2019-08-19 17:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:40:54 --> Input Class Initialized
INFO - 2019-08-19 17:40:54 --> Language Class Initialized
INFO - 2019-08-19 17:40:54 --> Loader Class Initialized
INFO - 2019-08-19 17:40:54 --> Helper loaded: url_helper
INFO - 2019-08-19 17:40:54 --> Helper loaded: html_helper
INFO - 2019-08-19 17:40:54 --> Helper loaded: form_helper
INFO - 2019-08-19 17:40:54 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:40:54 --> Helper loaded: date_helper
INFO - 2019-08-19 17:40:54 --> Form Validation Class Initialized
INFO - 2019-08-19 17:40:54 --> Email Class Initialized
DEBUG - 2019-08-19 17:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:40:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:40:54 --> Pagination Class Initialized
INFO - 2019-08-19 17:40:54 --> Database Driver Class Initialized
INFO - 2019-08-19 17:40:54 --> Database Driver Class Initialized
INFO - 2019-08-19 17:40:54 --> Controller Class Initialized
INFO - 2019-08-19 17:40:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:40:54 --> Config Class Initialized
INFO - 2019-08-19 17:40:54 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:40:54 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:40:54 --> Utf8 Class Initialized
INFO - 2019-08-19 17:40:54 --> URI Class Initialized
INFO - 2019-08-19 17:40:54 --> Router Class Initialized
INFO - 2019-08-19 17:40:54 --> Output Class Initialized
INFO - 2019-08-19 17:40:54 --> Security Class Initialized
DEBUG - 2019-08-19 17:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:40:54 --> Input Class Initialized
INFO - 2019-08-19 17:40:54 --> Language Class Initialized
INFO - 2019-08-19 17:40:54 --> Loader Class Initialized
INFO - 2019-08-19 17:40:55 --> Helper loaded: url_helper
INFO - 2019-08-19 17:40:55 --> Helper loaded: html_helper
INFO - 2019-08-19 17:40:55 --> Helper loaded: form_helper
INFO - 2019-08-19 17:40:55 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:40:55 --> Helper loaded: date_helper
INFO - 2019-08-19 17:40:55 --> Form Validation Class Initialized
INFO - 2019-08-19 17:40:55 --> Email Class Initialized
DEBUG - 2019-08-19 17:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:40:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:40:55 --> Pagination Class Initialized
INFO - 2019-08-19 17:40:55 --> Database Driver Class Initialized
INFO - 2019-08-19 17:40:55 --> Database Driver Class Initialized
INFO - 2019-08-19 17:40:55 --> Controller Class Initialized
INFO - 2019-08-19 17:40:55 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:40:55 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-19 17:40:55 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:40:55 --> Final output sent to browser
DEBUG - 2019-08-19 17:40:55 --> Total execution time: 0.2290
INFO - 2019-08-19 17:41:37 --> Config Class Initialized
INFO - 2019-08-19 17:41:37 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:41:37 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:41:37 --> Utf8 Class Initialized
INFO - 2019-08-19 17:41:37 --> URI Class Initialized
INFO - 2019-08-19 17:41:37 --> Router Class Initialized
INFO - 2019-08-19 17:41:37 --> Output Class Initialized
INFO - 2019-08-19 17:41:37 --> Security Class Initialized
DEBUG - 2019-08-19 17:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:41:37 --> Input Class Initialized
INFO - 2019-08-19 17:41:37 --> Language Class Initialized
INFO - 2019-08-19 17:41:37 --> Loader Class Initialized
INFO - 2019-08-19 17:41:37 --> Helper loaded: url_helper
INFO - 2019-08-19 17:41:37 --> Helper loaded: html_helper
INFO - 2019-08-19 17:41:37 --> Helper loaded: form_helper
INFO - 2019-08-19 17:41:37 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:41:37 --> Helper loaded: date_helper
INFO - 2019-08-19 17:41:37 --> Form Validation Class Initialized
INFO - 2019-08-19 17:41:37 --> Email Class Initialized
DEBUG - 2019-08-19 17:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:41:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:41:37 --> Pagination Class Initialized
INFO - 2019-08-19 17:41:37 --> Database Driver Class Initialized
INFO - 2019-08-19 17:41:37 --> Database Driver Class Initialized
INFO - 2019-08-19 17:41:37 --> Controller Class Initialized
INFO - 2019-08-19 17:41:37 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:41:37 --> Final output sent to browser
DEBUG - 2019-08-19 17:41:37 --> Total execution time: 0.2040
INFO - 2019-08-19 17:41:38 --> Config Class Initialized
INFO - 2019-08-19 17:41:38 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:41:38 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:41:38 --> Utf8 Class Initialized
INFO - 2019-08-19 17:41:38 --> URI Class Initialized
INFO - 2019-08-19 17:41:38 --> Router Class Initialized
INFO - 2019-08-19 17:41:38 --> Output Class Initialized
INFO - 2019-08-19 17:41:38 --> Security Class Initialized
DEBUG - 2019-08-19 17:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:41:38 --> Input Class Initialized
INFO - 2019-08-19 17:41:38 --> Language Class Initialized
INFO - 2019-08-19 17:41:38 --> Loader Class Initialized
INFO - 2019-08-19 17:41:38 --> Helper loaded: url_helper
INFO - 2019-08-19 17:41:38 --> Helper loaded: html_helper
INFO - 2019-08-19 17:41:38 --> Helper loaded: form_helper
INFO - 2019-08-19 17:41:38 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:41:38 --> Helper loaded: date_helper
INFO - 2019-08-19 17:41:38 --> Form Validation Class Initialized
INFO - 2019-08-19 17:41:38 --> Email Class Initialized
DEBUG - 2019-08-19 17:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:41:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:41:38 --> Pagination Class Initialized
INFO - 2019-08-19 17:41:38 --> Database Driver Class Initialized
INFO - 2019-08-19 17:41:38 --> Database Driver Class Initialized
INFO - 2019-08-19 17:41:38 --> Controller Class Initialized
INFO - 2019-08-19 17:41:38 --> Final output sent to browser
DEBUG - 2019-08-19 17:41:38 --> Total execution time: 0.3050
INFO - 2019-08-19 17:41:45 --> Config Class Initialized
INFO - 2019-08-19 17:41:45 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:41:45 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:41:45 --> Utf8 Class Initialized
INFO - 2019-08-19 17:41:45 --> URI Class Initialized
INFO - 2019-08-19 17:41:45 --> Router Class Initialized
INFO - 2019-08-19 17:41:45 --> Output Class Initialized
INFO - 2019-08-19 17:41:45 --> Security Class Initialized
DEBUG - 2019-08-19 17:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:41:45 --> Input Class Initialized
INFO - 2019-08-19 17:41:45 --> Language Class Initialized
INFO - 2019-08-19 17:41:45 --> Loader Class Initialized
INFO - 2019-08-19 17:41:45 --> Helper loaded: url_helper
INFO - 2019-08-19 17:41:45 --> Helper loaded: html_helper
INFO - 2019-08-19 17:41:45 --> Helper loaded: form_helper
INFO - 2019-08-19 17:41:45 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:41:45 --> Helper loaded: date_helper
INFO - 2019-08-19 17:41:45 --> Form Validation Class Initialized
INFO - 2019-08-19 17:41:45 --> Email Class Initialized
DEBUG - 2019-08-19 17:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:41:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:41:45 --> Pagination Class Initialized
INFO - 2019-08-19 17:41:45 --> Database Driver Class Initialized
INFO - 2019-08-19 17:41:45 --> Database Driver Class Initialized
INFO - 2019-08-19 17:41:45 --> Controller Class Initialized
INFO - 2019-08-19 17:41:45 --> Final output sent to browser
DEBUG - 2019-08-19 17:41:45 --> Total execution time: 0.2790
INFO - 2019-08-19 17:41:51 --> Config Class Initialized
INFO - 2019-08-19 17:41:51 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:41:51 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:41:51 --> Utf8 Class Initialized
INFO - 2019-08-19 17:41:51 --> URI Class Initialized
INFO - 2019-08-19 17:41:51 --> Router Class Initialized
INFO - 2019-08-19 17:41:51 --> Output Class Initialized
INFO - 2019-08-19 17:41:51 --> Security Class Initialized
DEBUG - 2019-08-19 17:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:41:51 --> Input Class Initialized
INFO - 2019-08-19 17:41:51 --> Language Class Initialized
INFO - 2019-08-19 17:41:51 --> Loader Class Initialized
INFO - 2019-08-19 17:41:51 --> Helper loaded: url_helper
INFO - 2019-08-19 17:41:51 --> Helper loaded: html_helper
INFO - 2019-08-19 17:41:52 --> Helper loaded: form_helper
INFO - 2019-08-19 17:41:52 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:41:52 --> Helper loaded: date_helper
INFO - 2019-08-19 17:41:52 --> Form Validation Class Initialized
INFO - 2019-08-19 17:41:52 --> Email Class Initialized
DEBUG - 2019-08-19 17:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:41:52 --> Pagination Class Initialized
INFO - 2019-08-19 17:41:52 --> Database Driver Class Initialized
INFO - 2019-08-19 17:41:52 --> Database Driver Class Initialized
INFO - 2019-08-19 17:41:52 --> Controller Class Initialized
INFO - 2019-08-19 17:41:52 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:41:52 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-19 17:41:52 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:41:52 --> Final output sent to browser
DEBUG - 2019-08-19 17:41:52 --> Total execution time: 0.3100
INFO - 2019-08-19 17:42:19 --> Config Class Initialized
INFO - 2019-08-19 17:42:19 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:42:19 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:42:19 --> Utf8 Class Initialized
INFO - 2019-08-19 17:42:19 --> URI Class Initialized
INFO - 2019-08-19 17:42:19 --> Router Class Initialized
INFO - 2019-08-19 17:42:19 --> Output Class Initialized
INFO - 2019-08-19 17:42:19 --> Security Class Initialized
DEBUG - 2019-08-19 17:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:42:19 --> Input Class Initialized
INFO - 2019-08-19 17:42:19 --> Language Class Initialized
INFO - 2019-08-19 17:42:19 --> Loader Class Initialized
INFO - 2019-08-19 17:42:19 --> Helper loaded: url_helper
INFO - 2019-08-19 17:42:19 --> Helper loaded: html_helper
INFO - 2019-08-19 17:42:19 --> Helper loaded: form_helper
INFO - 2019-08-19 17:42:19 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:42:19 --> Helper loaded: date_helper
INFO - 2019-08-19 17:42:19 --> Form Validation Class Initialized
INFO - 2019-08-19 17:42:19 --> Email Class Initialized
DEBUG - 2019-08-19 17:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:42:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:42:19 --> Pagination Class Initialized
INFO - 2019-08-19 17:42:19 --> Database Driver Class Initialized
INFO - 2019-08-19 17:42:19 --> Database Driver Class Initialized
INFO - 2019-08-19 17:42:19 --> Controller Class Initialized
INFO - 2019-08-19 17:42:20 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:42:20 --> Final output sent to browser
DEBUG - 2019-08-19 17:42:20 --> Total execution time: 0.2390
INFO - 2019-08-19 17:42:20 --> Config Class Initialized
INFO - 2019-08-19 17:42:20 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:42:20 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:42:20 --> Utf8 Class Initialized
INFO - 2019-08-19 17:42:20 --> URI Class Initialized
INFO - 2019-08-19 17:42:20 --> Router Class Initialized
INFO - 2019-08-19 17:42:20 --> Output Class Initialized
INFO - 2019-08-19 17:42:20 --> Security Class Initialized
DEBUG - 2019-08-19 17:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:42:20 --> Input Class Initialized
INFO - 2019-08-19 17:42:20 --> Language Class Initialized
INFO - 2019-08-19 17:42:20 --> Loader Class Initialized
INFO - 2019-08-19 17:42:20 --> Helper loaded: url_helper
INFO - 2019-08-19 17:42:20 --> Helper loaded: html_helper
INFO - 2019-08-19 17:42:20 --> Helper loaded: form_helper
INFO - 2019-08-19 17:42:20 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:42:20 --> Helper loaded: date_helper
INFO - 2019-08-19 17:42:20 --> Form Validation Class Initialized
INFO - 2019-08-19 17:42:20 --> Email Class Initialized
DEBUG - 2019-08-19 17:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:42:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:42:20 --> Pagination Class Initialized
INFO - 2019-08-19 17:42:20 --> Database Driver Class Initialized
INFO - 2019-08-19 17:42:20 --> Database Driver Class Initialized
INFO - 2019-08-19 17:42:20 --> Controller Class Initialized
INFO - 2019-08-19 17:42:20 --> Final output sent to browser
DEBUG - 2019-08-19 17:42:20 --> Total execution time: 0.2680
INFO - 2019-08-19 17:42:24 --> Config Class Initialized
INFO - 2019-08-19 17:42:24 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:42:24 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:42:24 --> Utf8 Class Initialized
INFO - 2019-08-19 17:42:24 --> URI Class Initialized
INFO - 2019-08-19 17:42:24 --> Router Class Initialized
INFO - 2019-08-19 17:42:24 --> Output Class Initialized
INFO - 2019-08-19 17:42:24 --> Security Class Initialized
DEBUG - 2019-08-19 17:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:42:24 --> Input Class Initialized
INFO - 2019-08-19 17:42:24 --> Language Class Initialized
INFO - 2019-08-19 17:42:24 --> Loader Class Initialized
INFO - 2019-08-19 17:42:24 --> Helper loaded: url_helper
INFO - 2019-08-19 17:42:24 --> Helper loaded: html_helper
INFO - 2019-08-19 17:42:24 --> Helper loaded: form_helper
INFO - 2019-08-19 17:42:24 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:42:24 --> Helper loaded: date_helper
INFO - 2019-08-19 17:42:24 --> Form Validation Class Initialized
INFO - 2019-08-19 17:42:24 --> Email Class Initialized
DEBUG - 2019-08-19 17:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:42:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:42:24 --> Pagination Class Initialized
INFO - 2019-08-19 17:42:24 --> Database Driver Class Initialized
INFO - 2019-08-19 17:42:24 --> Database Driver Class Initialized
INFO - 2019-08-19 17:42:25 --> Controller Class Initialized
INFO - 2019-08-19 17:42:25 --> Final output sent to browser
DEBUG - 2019-08-19 17:42:25 --> Total execution time: 0.2630
INFO - 2019-08-19 17:43:01 --> Config Class Initialized
INFO - 2019-08-19 17:43:01 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:43:01 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:43:01 --> Utf8 Class Initialized
INFO - 2019-08-19 17:43:01 --> URI Class Initialized
INFO - 2019-08-19 17:43:01 --> Router Class Initialized
INFO - 2019-08-19 17:43:01 --> Output Class Initialized
INFO - 2019-08-19 17:43:01 --> Security Class Initialized
DEBUG - 2019-08-19 17:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:43:01 --> Input Class Initialized
INFO - 2019-08-19 17:43:01 --> Language Class Initialized
INFO - 2019-08-19 17:43:01 --> Loader Class Initialized
INFO - 2019-08-19 17:43:01 --> Helper loaded: url_helper
INFO - 2019-08-19 17:43:01 --> Helper loaded: html_helper
INFO - 2019-08-19 17:43:01 --> Helper loaded: form_helper
INFO - 2019-08-19 17:43:01 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:43:01 --> Helper loaded: date_helper
INFO - 2019-08-19 17:43:01 --> Form Validation Class Initialized
INFO - 2019-08-19 17:43:01 --> Email Class Initialized
DEBUG - 2019-08-19 17:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:43:01 --> Pagination Class Initialized
INFO - 2019-08-19 17:43:01 --> Database Driver Class Initialized
INFO - 2019-08-19 17:43:01 --> Database Driver Class Initialized
INFO - 2019-08-19 17:43:01 --> Controller Class Initialized
INFO - 2019-08-19 17:43:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:43:01 --> Config Class Initialized
INFO - 2019-08-19 17:43:01 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:43:02 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:43:02 --> Utf8 Class Initialized
INFO - 2019-08-19 17:43:02 --> URI Class Initialized
INFO - 2019-08-19 17:43:02 --> Router Class Initialized
INFO - 2019-08-19 17:43:02 --> Output Class Initialized
INFO - 2019-08-19 17:43:02 --> Security Class Initialized
DEBUG - 2019-08-19 17:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:43:02 --> Input Class Initialized
INFO - 2019-08-19 17:43:02 --> Language Class Initialized
INFO - 2019-08-19 17:43:02 --> Loader Class Initialized
INFO - 2019-08-19 17:43:02 --> Helper loaded: url_helper
INFO - 2019-08-19 17:43:02 --> Helper loaded: html_helper
INFO - 2019-08-19 17:43:02 --> Helper loaded: form_helper
INFO - 2019-08-19 17:43:02 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:43:02 --> Helper loaded: date_helper
INFO - 2019-08-19 17:43:02 --> Form Validation Class Initialized
INFO - 2019-08-19 17:43:02 --> Email Class Initialized
DEBUG - 2019-08-19 17:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:43:02 --> Pagination Class Initialized
INFO - 2019-08-19 17:43:02 --> Database Driver Class Initialized
INFO - 2019-08-19 17:43:02 --> Database Driver Class Initialized
INFO - 2019-08-19 17:43:02 --> Controller Class Initialized
INFO - 2019-08-19 17:43:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:43:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-19 17:43:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:43:02 --> Final output sent to browser
DEBUG - 2019-08-19 17:43:02 --> Total execution time: 0.2100
INFO - 2019-08-19 17:44:05 --> Config Class Initialized
INFO - 2019-08-19 17:44:05 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:44:05 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:44:05 --> Utf8 Class Initialized
INFO - 2019-08-19 17:44:05 --> URI Class Initialized
INFO - 2019-08-19 17:44:05 --> Router Class Initialized
INFO - 2019-08-19 17:44:05 --> Output Class Initialized
INFO - 2019-08-19 17:44:05 --> Security Class Initialized
DEBUG - 2019-08-19 17:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:44:05 --> Input Class Initialized
INFO - 2019-08-19 17:44:05 --> Language Class Initialized
INFO - 2019-08-19 17:44:05 --> Loader Class Initialized
INFO - 2019-08-19 17:44:05 --> Helper loaded: url_helper
INFO - 2019-08-19 17:44:05 --> Helper loaded: html_helper
INFO - 2019-08-19 17:44:05 --> Helper loaded: form_helper
INFO - 2019-08-19 17:44:05 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:44:05 --> Helper loaded: date_helper
INFO - 2019-08-19 17:44:05 --> Form Validation Class Initialized
INFO - 2019-08-19 17:44:05 --> Email Class Initialized
DEBUG - 2019-08-19 17:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:44:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:44:05 --> Pagination Class Initialized
INFO - 2019-08-19 17:44:05 --> Database Driver Class Initialized
INFO - 2019-08-19 17:44:05 --> Database Driver Class Initialized
INFO - 2019-08-19 17:44:05 --> Controller Class Initialized
INFO - 2019-08-19 17:44:05 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:44:05 --> Final output sent to browser
DEBUG - 2019-08-19 17:44:05 --> Total execution time: 0.2070
INFO - 2019-08-19 17:44:06 --> Config Class Initialized
INFO - 2019-08-19 17:44:06 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:44:06 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:44:06 --> Utf8 Class Initialized
INFO - 2019-08-19 17:44:06 --> URI Class Initialized
INFO - 2019-08-19 17:44:06 --> Router Class Initialized
INFO - 2019-08-19 17:44:06 --> Output Class Initialized
INFO - 2019-08-19 17:44:06 --> Security Class Initialized
DEBUG - 2019-08-19 17:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:44:06 --> Input Class Initialized
INFO - 2019-08-19 17:44:06 --> Language Class Initialized
INFO - 2019-08-19 17:44:06 --> Loader Class Initialized
INFO - 2019-08-19 17:44:06 --> Helper loaded: url_helper
INFO - 2019-08-19 17:44:06 --> Helper loaded: html_helper
INFO - 2019-08-19 17:44:06 --> Helper loaded: form_helper
INFO - 2019-08-19 17:44:06 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:44:06 --> Helper loaded: date_helper
INFO - 2019-08-19 17:44:06 --> Form Validation Class Initialized
INFO - 2019-08-19 17:44:06 --> Email Class Initialized
DEBUG - 2019-08-19 17:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:44:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:44:06 --> Pagination Class Initialized
INFO - 2019-08-19 17:44:06 --> Database Driver Class Initialized
INFO - 2019-08-19 17:44:06 --> Database Driver Class Initialized
INFO - 2019-08-19 17:44:06 --> Controller Class Initialized
INFO - 2019-08-19 17:44:06 --> Final output sent to browser
DEBUG - 2019-08-19 17:44:06 --> Total execution time: 0.2810
INFO - 2019-08-19 17:44:23 --> Config Class Initialized
INFO - 2019-08-19 17:44:23 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:44:23 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:44:23 --> Utf8 Class Initialized
INFO - 2019-08-19 17:44:23 --> URI Class Initialized
INFO - 2019-08-19 17:44:23 --> Router Class Initialized
INFO - 2019-08-19 17:44:23 --> Output Class Initialized
INFO - 2019-08-19 17:44:23 --> Security Class Initialized
DEBUG - 2019-08-19 17:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:44:23 --> Input Class Initialized
INFO - 2019-08-19 17:44:23 --> Language Class Initialized
INFO - 2019-08-19 17:44:23 --> Loader Class Initialized
INFO - 2019-08-19 17:44:23 --> Helper loaded: url_helper
INFO - 2019-08-19 17:44:23 --> Helper loaded: html_helper
INFO - 2019-08-19 17:44:23 --> Helper loaded: form_helper
INFO - 2019-08-19 17:44:23 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:44:23 --> Helper loaded: date_helper
INFO - 2019-08-19 17:44:23 --> Form Validation Class Initialized
INFO - 2019-08-19 17:44:23 --> Email Class Initialized
DEBUG - 2019-08-19 17:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:44:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:44:23 --> Pagination Class Initialized
INFO - 2019-08-19 17:44:23 --> Database Driver Class Initialized
INFO - 2019-08-19 17:44:23 --> Database Driver Class Initialized
INFO - 2019-08-19 17:44:23 --> Controller Class Initialized
INFO - 2019-08-19 17:44:23 --> Final output sent to browser
DEBUG - 2019-08-19 17:44:23 --> Total execution time: 0.2278
INFO - 2019-08-19 17:44:50 --> Config Class Initialized
INFO - 2019-08-19 17:44:50 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:44:50 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:44:50 --> Utf8 Class Initialized
INFO - 2019-08-19 17:44:50 --> URI Class Initialized
INFO - 2019-08-19 17:44:50 --> Router Class Initialized
INFO - 2019-08-19 17:44:50 --> Output Class Initialized
INFO - 2019-08-19 17:44:50 --> Security Class Initialized
DEBUG - 2019-08-19 17:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:44:50 --> Input Class Initialized
INFO - 2019-08-19 17:44:50 --> Language Class Initialized
INFO - 2019-08-19 17:44:50 --> Loader Class Initialized
INFO - 2019-08-19 17:44:50 --> Helper loaded: url_helper
INFO - 2019-08-19 17:44:50 --> Helper loaded: html_helper
INFO - 2019-08-19 17:44:50 --> Helper loaded: form_helper
INFO - 2019-08-19 17:44:50 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:44:50 --> Helper loaded: date_helper
INFO - 2019-08-19 17:44:50 --> Form Validation Class Initialized
INFO - 2019-08-19 17:44:50 --> Email Class Initialized
DEBUG - 2019-08-19 17:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:44:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:44:50 --> Pagination Class Initialized
INFO - 2019-08-19 17:44:50 --> Database Driver Class Initialized
INFO - 2019-08-19 17:44:50 --> Database Driver Class Initialized
INFO - 2019-08-19 17:44:50 --> Controller Class Initialized
INFO - 2019-08-19 17:44:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:44:50 --> Config Class Initialized
INFO - 2019-08-19 17:44:50 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:44:50 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:44:50 --> Utf8 Class Initialized
INFO - 2019-08-19 17:44:50 --> URI Class Initialized
INFO - 2019-08-19 17:44:50 --> Router Class Initialized
INFO - 2019-08-19 17:44:50 --> Output Class Initialized
INFO - 2019-08-19 17:44:50 --> Security Class Initialized
DEBUG - 2019-08-19 17:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:44:50 --> Input Class Initialized
INFO - 2019-08-19 17:44:50 --> Language Class Initialized
INFO - 2019-08-19 17:44:50 --> Loader Class Initialized
INFO - 2019-08-19 17:44:50 --> Helper loaded: url_helper
INFO - 2019-08-19 17:44:50 --> Helper loaded: html_helper
INFO - 2019-08-19 17:44:50 --> Helper loaded: form_helper
INFO - 2019-08-19 17:44:50 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:44:50 --> Helper loaded: date_helper
INFO - 2019-08-19 17:44:50 --> Form Validation Class Initialized
INFO - 2019-08-19 17:44:50 --> Email Class Initialized
DEBUG - 2019-08-19 17:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:44:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:44:50 --> Pagination Class Initialized
INFO - 2019-08-19 17:44:50 --> Database Driver Class Initialized
INFO - 2019-08-19 17:44:50 --> Database Driver Class Initialized
INFO - 2019-08-19 17:44:50 --> Controller Class Initialized
INFO - 2019-08-19 17:44:51 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:44:51 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-19 17:44:51 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:44:51 --> Final output sent to browser
DEBUG - 2019-08-19 17:44:51 --> Total execution time: 0.1980
INFO - 2019-08-19 17:45:35 --> Config Class Initialized
INFO - 2019-08-19 17:45:35 --> Hooks Class Initialized
INFO - 2019-08-19 17:45:35 --> Config Class Initialized
INFO - 2019-08-19 17:45:35 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:45:35 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:45:35 --> Utf8 Class Initialized
DEBUG - 2019-08-19 17:45:35 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:45:35 --> Utf8 Class Initialized
INFO - 2019-08-19 17:45:35 --> URI Class Initialized
INFO - 2019-08-19 17:45:35 --> Router Class Initialized
INFO - 2019-08-19 17:45:35 --> Output Class Initialized
INFO - 2019-08-19 17:45:35 --> Security Class Initialized
DEBUG - 2019-08-19 17:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:45:35 --> Input Class Initialized
INFO - 2019-08-19 17:45:35 --> Language Class Initialized
INFO - 2019-08-19 17:45:35 --> Loader Class Initialized
INFO - 2019-08-19 17:45:35 --> Helper loaded: url_helper
INFO - 2019-08-19 17:45:35 --> Helper loaded: html_helper
INFO - 2019-08-19 17:45:35 --> Helper loaded: form_helper
INFO - 2019-08-19 17:45:35 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:45:35 --> Helper loaded: date_helper
INFO - 2019-08-19 17:45:35 --> URI Class Initialized
INFO - 2019-08-19 17:45:35 --> Router Class Initialized
INFO - 2019-08-19 17:45:35 --> Form Validation Class Initialized
INFO - 2019-08-19 17:45:35 --> Output Class Initialized
INFO - 2019-08-19 17:45:35 --> Email Class Initialized
INFO - 2019-08-19 17:45:35 --> Security Class Initialized
DEBUG - 2019-08-19 17:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:45:35 --> Input Class Initialized
DEBUG - 2019-08-19 17:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:45:35 --> Language Class Initialized
INFO - 2019-08-19 17:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:45:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:45:35 --> Pagination Class Initialized
INFO - 2019-08-19 17:45:35 --> Loader Class Initialized
INFO - 2019-08-19 17:45:35 --> Helper loaded: url_helper
INFO - 2019-08-19 17:45:35 --> Helper loaded: html_helper
INFO - 2019-08-19 17:45:35 --> Helper loaded: form_helper
INFO - 2019-08-19 17:45:35 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:45:35 --> Database Driver Class Initialized
INFO - 2019-08-19 17:45:35 --> Database Driver Class Initialized
INFO - 2019-08-19 17:45:35 --> Helper loaded: date_helper
INFO - 2019-08-19 17:45:35 --> Form Validation Class Initialized
INFO - 2019-08-19 17:45:35 --> Email Class Initialized
DEBUG - 2019-08-19 17:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:45:35 --> Controller Class Initialized
INFO - 2019-08-19 17:45:36 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:45:36 --> Final output sent to browser
DEBUG - 2019-08-19 17:45:36 --> Total execution time: 0.2600
INFO - 2019-08-19 17:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:45:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:45:36 --> Pagination Class Initialized
INFO - 2019-08-19 17:45:36 --> Database Driver Class Initialized
INFO - 2019-08-19 17:45:36 --> Database Driver Class Initialized
INFO - 2019-08-19 17:45:36 --> Controller Class Initialized
INFO - 2019-08-19 17:45:36 --> Final output sent to browser
DEBUG - 2019-08-19 17:45:36 --> Total execution time: 0.3760
INFO - 2019-08-19 17:45:43 --> Config Class Initialized
INFO - 2019-08-19 17:45:43 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:45:43 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:45:43 --> Utf8 Class Initialized
INFO - 2019-08-19 17:45:43 --> URI Class Initialized
INFO - 2019-08-19 17:45:43 --> Router Class Initialized
INFO - 2019-08-19 17:45:43 --> Output Class Initialized
INFO - 2019-08-19 17:45:43 --> Security Class Initialized
DEBUG - 2019-08-19 17:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:45:43 --> Input Class Initialized
INFO - 2019-08-19 17:45:43 --> Language Class Initialized
INFO - 2019-08-19 17:45:43 --> Loader Class Initialized
INFO - 2019-08-19 17:45:43 --> Helper loaded: url_helper
INFO - 2019-08-19 17:45:43 --> Helper loaded: html_helper
INFO - 2019-08-19 17:45:43 --> Helper loaded: form_helper
INFO - 2019-08-19 17:45:43 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:45:43 --> Helper loaded: date_helper
INFO - 2019-08-19 17:45:43 --> Form Validation Class Initialized
INFO - 2019-08-19 17:45:43 --> Email Class Initialized
DEBUG - 2019-08-19 17:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:45:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:45:43 --> Pagination Class Initialized
INFO - 2019-08-19 17:45:43 --> Database Driver Class Initialized
INFO - 2019-08-19 17:45:43 --> Database Driver Class Initialized
INFO - 2019-08-19 17:45:43 --> Controller Class Initialized
INFO - 2019-08-19 17:45:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:45:43 --> Final output sent to browser
DEBUG - 2019-08-19 17:45:43 --> Total execution time: 0.2360
INFO - 2019-08-19 17:45:47 --> Config Class Initialized
INFO - 2019-08-19 17:45:47 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:45:47 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:45:47 --> Utf8 Class Initialized
INFO - 2019-08-19 17:45:47 --> URI Class Initialized
INFO - 2019-08-19 17:45:47 --> Router Class Initialized
INFO - 2019-08-19 17:45:47 --> Output Class Initialized
INFO - 2019-08-19 17:45:47 --> Security Class Initialized
DEBUG - 2019-08-19 17:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:45:47 --> Input Class Initialized
INFO - 2019-08-19 17:45:47 --> Language Class Initialized
INFO - 2019-08-19 17:45:47 --> Loader Class Initialized
INFO - 2019-08-19 17:45:47 --> Helper loaded: url_helper
INFO - 2019-08-19 17:45:47 --> Helper loaded: html_helper
INFO - 2019-08-19 17:45:47 --> Helper loaded: form_helper
INFO - 2019-08-19 17:45:47 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:45:47 --> Helper loaded: date_helper
INFO - 2019-08-19 17:45:47 --> Form Validation Class Initialized
INFO - 2019-08-19 17:45:47 --> Email Class Initialized
DEBUG - 2019-08-19 17:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:45:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:45:47 --> Pagination Class Initialized
INFO - 2019-08-19 17:45:47 --> Database Driver Class Initialized
INFO - 2019-08-19 17:45:47 --> Database Driver Class Initialized
INFO - 2019-08-19 17:45:47 --> Controller Class Initialized
INFO - 2019-08-19 17:45:47 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:45:47 --> Final output sent to browser
DEBUG - 2019-08-19 17:45:47 --> Total execution time: 0.1810
INFO - 2019-08-19 17:45:48 --> Config Class Initialized
INFO - 2019-08-19 17:45:48 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:45:48 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:45:48 --> Utf8 Class Initialized
INFO - 2019-08-19 17:45:48 --> URI Class Initialized
INFO - 2019-08-19 17:45:48 --> Router Class Initialized
INFO - 2019-08-19 17:45:48 --> Output Class Initialized
INFO - 2019-08-19 17:45:48 --> Security Class Initialized
DEBUG - 2019-08-19 17:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:45:48 --> Input Class Initialized
INFO - 2019-08-19 17:45:48 --> Language Class Initialized
INFO - 2019-08-19 17:45:48 --> Loader Class Initialized
INFO - 2019-08-19 17:45:48 --> Helper loaded: url_helper
INFO - 2019-08-19 17:45:48 --> Helper loaded: html_helper
INFO - 2019-08-19 17:45:48 --> Helper loaded: form_helper
INFO - 2019-08-19 17:45:48 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:45:48 --> Helper loaded: date_helper
INFO - 2019-08-19 17:45:48 --> Form Validation Class Initialized
INFO - 2019-08-19 17:45:48 --> Email Class Initialized
DEBUG - 2019-08-19 17:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:45:48 --> Pagination Class Initialized
INFO - 2019-08-19 17:45:48 --> Database Driver Class Initialized
INFO - 2019-08-19 17:45:48 --> Database Driver Class Initialized
INFO - 2019-08-19 17:45:48 --> Controller Class Initialized
INFO - 2019-08-19 17:45:48 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:45:48 --> Final output sent to browser
DEBUG - 2019-08-19 17:45:48 --> Total execution time: 0.2530
INFO - 2019-08-19 17:46:06 --> Config Class Initialized
INFO - 2019-08-19 17:46:06 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:46:06 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:46:06 --> Utf8 Class Initialized
INFO - 2019-08-19 17:46:06 --> URI Class Initialized
INFO - 2019-08-19 17:46:06 --> Router Class Initialized
INFO - 2019-08-19 17:46:06 --> Output Class Initialized
INFO - 2019-08-19 17:46:06 --> Security Class Initialized
DEBUG - 2019-08-19 17:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:46:07 --> Input Class Initialized
INFO - 2019-08-19 17:46:07 --> Language Class Initialized
INFO - 2019-08-19 17:46:07 --> Loader Class Initialized
INFO - 2019-08-19 17:46:07 --> Helper loaded: url_helper
INFO - 2019-08-19 17:46:07 --> Helper loaded: html_helper
INFO - 2019-08-19 17:46:07 --> Helper loaded: form_helper
INFO - 2019-08-19 17:46:07 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:46:07 --> Helper loaded: date_helper
INFO - 2019-08-19 17:46:07 --> Form Validation Class Initialized
INFO - 2019-08-19 17:46:07 --> Email Class Initialized
DEBUG - 2019-08-19 17:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:46:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:46:07 --> Pagination Class Initialized
INFO - 2019-08-19 17:46:07 --> Database Driver Class Initialized
INFO - 2019-08-19 17:46:07 --> Database Driver Class Initialized
INFO - 2019-08-19 17:46:07 --> Controller Class Initialized
INFO - 2019-08-19 17:46:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:46:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 17:46:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:46:07 --> Final output sent to browser
DEBUG - 2019-08-19 17:46:07 --> Total execution time: 0.2020
INFO - 2019-08-19 17:47:10 --> Config Class Initialized
INFO - 2019-08-19 17:47:10 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:47:10 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:47:10 --> Utf8 Class Initialized
INFO - 2019-08-19 17:47:10 --> URI Class Initialized
INFO - 2019-08-19 17:47:10 --> Config Class Initialized
INFO - 2019-08-19 17:47:10 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:47:10 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:47:10 --> Utf8 Class Initialized
INFO - 2019-08-19 17:47:10 --> URI Class Initialized
INFO - 2019-08-19 17:47:10 --> Router Class Initialized
INFO - 2019-08-19 17:47:10 --> Output Class Initialized
INFO - 2019-08-19 17:47:10 --> Security Class Initialized
DEBUG - 2019-08-19 17:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:47:10 --> Input Class Initialized
INFO - 2019-08-19 17:47:10 --> Language Class Initialized
INFO - 2019-08-19 17:47:10 --> Loader Class Initialized
INFO - 2019-08-19 17:47:10 --> Helper loaded: url_helper
INFO - 2019-08-19 17:47:10 --> Helper loaded: html_helper
INFO - 2019-08-19 17:47:10 --> Helper loaded: form_helper
INFO - 2019-08-19 17:47:10 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:47:10 --> Helper loaded: date_helper
INFO - 2019-08-19 17:47:10 --> Form Validation Class Initialized
INFO - 2019-08-19 17:47:10 --> Router Class Initialized
INFO - 2019-08-19 17:47:10 --> Output Class Initialized
INFO - 2019-08-19 17:47:10 --> Security Class Initialized
DEBUG - 2019-08-19 17:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:47:10 --> Input Class Initialized
INFO - 2019-08-19 17:47:10 --> Language Class Initialized
INFO - 2019-08-19 17:47:10 --> Email Class Initialized
INFO - 2019-08-19 17:47:10 --> Loader Class Initialized
DEBUG - 2019-08-19 17:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:47:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:47:10 --> Pagination Class Initialized
INFO - 2019-08-19 17:47:10 --> Helper loaded: url_helper
INFO - 2019-08-19 17:47:10 --> Helper loaded: html_helper
INFO - 2019-08-19 17:47:10 --> Helper loaded: form_helper
INFO - 2019-08-19 17:47:10 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:47:10 --> Helper loaded: date_helper
INFO - 2019-08-19 17:47:10 --> Form Validation Class Initialized
INFO - 2019-08-19 17:47:10 --> Email Class Initialized
DEBUG - 2019-08-19 17:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:47:10 --> Database Driver Class Initialized
INFO - 2019-08-19 17:47:10 --> Database Driver Class Initialized
INFO - 2019-08-19 17:47:10 --> Controller Class Initialized
INFO - 2019-08-19 17:47:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:47:10 --> Final output sent to browser
DEBUG - 2019-08-19 17:47:10 --> Total execution time: 0.3450
INFO - 2019-08-19 17:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:47:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:47:10 --> Pagination Class Initialized
INFO - 2019-08-19 17:47:10 --> Database Driver Class Initialized
INFO - 2019-08-19 17:47:10 --> Database Driver Class Initialized
INFO - 2019-08-19 17:47:10 --> Controller Class Initialized
INFO - 2019-08-19 17:47:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:47:10 --> Final output sent to browser
DEBUG - 2019-08-19 17:47:10 --> Total execution time: 0.5130
INFO - 2019-08-19 17:47:11 --> Config Class Initialized
INFO - 2019-08-19 17:47:11 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:47:11 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:47:11 --> Utf8 Class Initialized
INFO - 2019-08-19 17:47:11 --> URI Class Initialized
INFO - 2019-08-19 17:47:11 --> Router Class Initialized
INFO - 2019-08-19 17:47:11 --> Output Class Initialized
INFO - 2019-08-19 17:47:11 --> Security Class Initialized
DEBUG - 2019-08-19 17:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:47:11 --> Input Class Initialized
INFO - 2019-08-19 17:47:11 --> Language Class Initialized
INFO - 2019-08-19 17:47:11 --> Loader Class Initialized
INFO - 2019-08-19 17:47:11 --> Helper loaded: url_helper
INFO - 2019-08-19 17:47:11 --> Helper loaded: html_helper
INFO - 2019-08-19 17:47:11 --> Helper loaded: form_helper
INFO - 2019-08-19 17:47:11 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:47:11 --> Helper loaded: date_helper
INFO - 2019-08-19 17:47:11 --> Form Validation Class Initialized
INFO - 2019-08-19 17:47:11 --> Email Class Initialized
DEBUG - 2019-08-19 17:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:47:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:47:11 --> Pagination Class Initialized
INFO - 2019-08-19 17:47:11 --> Database Driver Class Initialized
INFO - 2019-08-19 17:47:11 --> Database Driver Class Initialized
INFO - 2019-08-19 17:47:11 --> Controller Class Initialized
INFO - 2019-08-19 17:47:11 --> Final output sent to browser
DEBUG - 2019-08-19 17:47:11 --> Total execution time: 0.3530
INFO - 2019-08-19 17:48:57 --> Config Class Initialized
INFO - 2019-08-19 17:48:57 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:48:57 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:48:57 --> Utf8 Class Initialized
INFO - 2019-08-19 17:48:57 --> URI Class Initialized
INFO - 2019-08-19 17:48:57 --> Router Class Initialized
INFO - 2019-08-19 17:48:57 --> Output Class Initialized
INFO - 2019-08-19 17:48:57 --> Security Class Initialized
DEBUG - 2019-08-19 17:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:48:57 --> Input Class Initialized
INFO - 2019-08-19 17:48:57 --> Language Class Initialized
INFO - 2019-08-19 17:48:58 --> Loader Class Initialized
INFO - 2019-08-19 17:48:58 --> Helper loaded: url_helper
INFO - 2019-08-19 17:48:58 --> Helper loaded: html_helper
INFO - 2019-08-19 17:48:58 --> Helper loaded: form_helper
INFO - 2019-08-19 17:48:58 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:48:58 --> Helper loaded: date_helper
INFO - 2019-08-19 17:48:58 --> Form Validation Class Initialized
INFO - 2019-08-19 17:48:58 --> Email Class Initialized
DEBUG - 2019-08-19 17:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:48:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:48:58 --> Pagination Class Initialized
INFO - 2019-08-19 17:48:58 --> Database Driver Class Initialized
INFO - 2019-08-19 17:48:58 --> Database Driver Class Initialized
INFO - 2019-08-19 17:48:58 --> Controller Class Initialized
INFO - 2019-08-19 17:48:58 --> Final output sent to browser
DEBUG - 2019-08-19 17:48:58 --> Total execution time: 0.5910
INFO - 2019-08-19 17:49:32 --> Config Class Initialized
INFO - 2019-08-19 17:49:32 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:49:32 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:49:32 --> Utf8 Class Initialized
INFO - 2019-08-19 17:49:32 --> URI Class Initialized
INFO - 2019-08-19 17:49:32 --> Router Class Initialized
INFO - 2019-08-19 17:49:32 --> Output Class Initialized
INFO - 2019-08-19 17:49:32 --> Security Class Initialized
DEBUG - 2019-08-19 17:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:49:32 --> Input Class Initialized
INFO - 2019-08-19 17:49:32 --> Language Class Initialized
INFO - 2019-08-19 17:49:32 --> Loader Class Initialized
INFO - 2019-08-19 17:49:32 --> Helper loaded: url_helper
INFO - 2019-08-19 17:49:32 --> Helper loaded: html_helper
INFO - 2019-08-19 17:49:32 --> Helper loaded: form_helper
INFO - 2019-08-19 17:49:32 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:49:32 --> Helper loaded: date_helper
INFO - 2019-08-19 17:49:32 --> Form Validation Class Initialized
INFO - 2019-08-19 17:49:32 --> Email Class Initialized
DEBUG - 2019-08-19 17:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:49:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:49:32 --> Pagination Class Initialized
INFO - 2019-08-19 17:49:32 --> Database Driver Class Initialized
INFO - 2019-08-19 17:49:32 --> Database Driver Class Initialized
INFO - 2019-08-19 17:49:32 --> Controller Class Initialized
INFO - 2019-08-19 17:49:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:49:32 --> Config Class Initialized
INFO - 2019-08-19 17:49:32 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:49:32 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:49:32 --> Utf8 Class Initialized
INFO - 2019-08-19 17:49:32 --> URI Class Initialized
INFO - 2019-08-19 17:49:32 --> Router Class Initialized
INFO - 2019-08-19 17:49:32 --> Output Class Initialized
INFO - 2019-08-19 17:49:32 --> Security Class Initialized
DEBUG - 2019-08-19 17:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:49:32 --> Input Class Initialized
INFO - 2019-08-19 17:49:32 --> Language Class Initialized
INFO - 2019-08-19 17:49:32 --> Loader Class Initialized
INFO - 2019-08-19 17:49:32 --> Helper loaded: url_helper
INFO - 2019-08-19 17:49:32 --> Helper loaded: html_helper
INFO - 2019-08-19 17:49:32 --> Helper loaded: form_helper
INFO - 2019-08-19 17:49:32 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:49:32 --> Helper loaded: date_helper
INFO - 2019-08-19 17:49:32 --> Form Validation Class Initialized
INFO - 2019-08-19 17:49:32 --> Email Class Initialized
DEBUG - 2019-08-19 17:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:49:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:49:32 --> Pagination Class Initialized
INFO - 2019-08-19 17:49:32 --> Database Driver Class Initialized
INFO - 2019-08-19 17:49:32 --> Database Driver Class Initialized
INFO - 2019-08-19 17:49:32 --> Controller Class Initialized
INFO - 2019-08-19 17:49:32 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:49:32 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 17:49:32 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:49:32 --> Final output sent to browser
DEBUG - 2019-08-19 17:49:32 --> Total execution time: 0.2440
INFO - 2019-08-19 17:50:41 --> Config Class Initialized
INFO - 2019-08-19 17:50:41 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:50:41 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:50:41 --> Utf8 Class Initialized
INFO - 2019-08-19 17:50:41 --> URI Class Initialized
INFO - 2019-08-19 17:50:41 --> Router Class Initialized
INFO - 2019-08-19 17:50:41 --> Output Class Initialized
INFO - 2019-08-19 17:50:41 --> Security Class Initialized
DEBUG - 2019-08-19 17:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:50:41 --> Input Class Initialized
INFO - 2019-08-19 17:50:41 --> Language Class Initialized
INFO - 2019-08-19 17:50:41 --> Config Class Initialized
INFO - 2019-08-19 17:50:41 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:50:41 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:50:41 --> Utf8 Class Initialized
INFO - 2019-08-19 17:50:41 --> URI Class Initialized
INFO - 2019-08-19 17:50:41 --> Config Class Initialized
INFO - 2019-08-19 17:50:41 --> Hooks Class Initialized
INFO - 2019-08-19 17:50:41 --> Router Class Initialized
INFO - 2019-08-19 17:50:41 --> Output Class Initialized
DEBUG - 2019-08-19 17:50:41 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:50:41 --> Utf8 Class Initialized
INFO - 2019-08-19 17:50:41 --> URI Class Initialized
INFO - 2019-08-19 17:50:41 --> Security Class Initialized
DEBUG - 2019-08-19 17:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:50:41 --> Input Class Initialized
INFO - 2019-08-19 17:50:41 --> Router Class Initialized
INFO - 2019-08-19 17:50:41 --> Language Class Initialized
INFO - 2019-08-19 17:50:41 --> Output Class Initialized
INFO - 2019-08-19 17:50:41 --> Security Class Initialized
DEBUG - 2019-08-19 17:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:50:41 --> Input Class Initialized
INFO - 2019-08-19 17:50:41 --> Loader Class Initialized
INFO - 2019-08-19 17:50:41 --> Language Class Initialized
INFO - 2019-08-19 17:50:41 --> Helper loaded: url_helper
INFO - 2019-08-19 17:50:41 --> Helper loaded: html_helper
INFO - 2019-08-19 17:50:41 --> Loader Class Initialized
INFO - 2019-08-19 17:50:41 --> Helper loaded: form_helper
INFO - 2019-08-19 17:50:41 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:50:41 --> Helper loaded: url_helper
INFO - 2019-08-19 17:50:41 --> Helper loaded: date_helper
INFO - 2019-08-19 17:50:41 --> Helper loaded: html_helper
INFO - 2019-08-19 17:50:41 --> Form Validation Class Initialized
INFO - 2019-08-19 17:50:41 --> Helper loaded: form_helper
INFO - 2019-08-19 17:50:41 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:50:41 --> Helper loaded: date_helper
INFO - 2019-08-19 17:50:41 --> Email Class Initialized
INFO - 2019-08-19 17:50:41 --> Loader Class Initialized
INFO - 2019-08-19 17:50:41 --> Helper loaded: url_helper
INFO - 2019-08-19 17:50:41 --> Helper loaded: html_helper
INFO - 2019-08-19 17:50:41 --> Helper loaded: form_helper
INFO - 2019-08-19 17:50:41 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:50:41 --> Helper loaded: date_helper
INFO - 2019-08-19 17:50:41 --> Form Validation Class Initialized
INFO - 2019-08-19 17:50:41 --> Form Validation Class Initialized
INFO - 2019-08-19 17:50:41 --> Email Class Initialized
DEBUG - 2019-08-19 17:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:50:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-08-19 17:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:50:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:50:41 --> Pagination Class Initialized
INFO - 2019-08-19 17:50:41 --> Email Class Initialized
INFO - 2019-08-19 17:50:41 --> Database Driver Class Initialized
INFO - 2019-08-19 17:50:41 --> Database Driver Class Initialized
DEBUG - 2019-08-19 17:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:50:41 --> Controller Class Initialized
INFO - 2019-08-19 17:50:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:50:41 --> Final output sent to browser
DEBUG - 2019-08-19 17:50:41 --> Total execution time: 0.3100
INFO - 2019-08-19 17:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:50:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:50:41 --> Pagination Class Initialized
INFO - 2019-08-19 17:50:42 --> Database Driver Class Initialized
INFO - 2019-08-19 17:50:42 --> Database Driver Class Initialized
INFO - 2019-08-19 17:50:42 --> Controller Class Initialized
INFO - 2019-08-19 17:50:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:50:42 --> Final output sent to browser
DEBUG - 2019-08-19 17:50:42 --> Total execution time: 0.5060
INFO - 2019-08-19 17:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:50:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:50:42 --> Pagination Class Initialized
INFO - 2019-08-19 17:50:42 --> Database Driver Class Initialized
INFO - 2019-08-19 17:50:42 --> Database Driver Class Initialized
INFO - 2019-08-19 17:50:42 --> Controller Class Initialized
INFO - 2019-08-19 17:50:42 --> Final output sent to browser
DEBUG - 2019-08-19 17:50:42 --> Total execution time: 0.9221
INFO - 2019-08-19 17:50:55 --> Config Class Initialized
INFO - 2019-08-19 17:50:55 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:50:55 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:50:55 --> Utf8 Class Initialized
INFO - 2019-08-19 17:50:55 --> URI Class Initialized
INFO - 2019-08-19 17:50:55 --> Router Class Initialized
INFO - 2019-08-19 17:50:55 --> Output Class Initialized
INFO - 2019-08-19 17:50:55 --> Security Class Initialized
DEBUG - 2019-08-19 17:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:50:55 --> Input Class Initialized
INFO - 2019-08-19 17:50:55 --> Language Class Initialized
INFO - 2019-08-19 17:50:55 --> Loader Class Initialized
INFO - 2019-08-19 17:50:55 --> Helper loaded: url_helper
INFO - 2019-08-19 17:50:55 --> Helper loaded: html_helper
INFO - 2019-08-19 17:50:55 --> Helper loaded: form_helper
INFO - 2019-08-19 17:50:55 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:50:55 --> Helper loaded: date_helper
INFO - 2019-08-19 17:50:55 --> Form Validation Class Initialized
INFO - 2019-08-19 17:50:55 --> Email Class Initialized
DEBUG - 2019-08-19 17:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:50:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:50:55 --> Pagination Class Initialized
INFO - 2019-08-19 17:50:55 --> Database Driver Class Initialized
INFO - 2019-08-19 17:50:55 --> Database Driver Class Initialized
INFO - 2019-08-19 17:50:56 --> Controller Class Initialized
INFO - 2019-08-19 17:50:56 --> Final output sent to browser
DEBUG - 2019-08-19 17:50:56 --> Total execution time: 0.3450
INFO - 2019-08-19 17:51:24 --> Config Class Initialized
INFO - 2019-08-19 17:51:24 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:51:24 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:51:24 --> Utf8 Class Initialized
INFO - 2019-08-19 17:51:24 --> URI Class Initialized
INFO - 2019-08-19 17:51:24 --> Router Class Initialized
INFO - 2019-08-19 17:51:24 --> Output Class Initialized
INFO - 2019-08-19 17:51:24 --> Security Class Initialized
DEBUG - 2019-08-19 17:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:51:24 --> Input Class Initialized
INFO - 2019-08-19 17:51:24 --> Language Class Initialized
INFO - 2019-08-19 17:51:24 --> Loader Class Initialized
INFO - 2019-08-19 17:51:24 --> Helper loaded: url_helper
INFO - 2019-08-19 17:51:24 --> Helper loaded: html_helper
INFO - 2019-08-19 17:51:24 --> Helper loaded: form_helper
INFO - 2019-08-19 17:51:24 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:51:24 --> Helper loaded: date_helper
INFO - 2019-08-19 17:51:24 --> Form Validation Class Initialized
INFO - 2019-08-19 17:51:24 --> Email Class Initialized
DEBUG - 2019-08-19 17:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:51:24 --> Pagination Class Initialized
INFO - 2019-08-19 17:51:24 --> Database Driver Class Initialized
INFO - 2019-08-19 17:51:24 --> Database Driver Class Initialized
INFO - 2019-08-19 17:51:24 --> Controller Class Initialized
INFO - 2019-08-19 17:51:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:51:24 --> Config Class Initialized
INFO - 2019-08-19 17:51:24 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:51:24 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:51:24 --> Utf8 Class Initialized
INFO - 2019-08-19 17:51:24 --> URI Class Initialized
INFO - 2019-08-19 17:51:24 --> Router Class Initialized
INFO - 2019-08-19 17:51:24 --> Output Class Initialized
INFO - 2019-08-19 17:51:24 --> Security Class Initialized
DEBUG - 2019-08-19 17:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:51:24 --> Input Class Initialized
INFO - 2019-08-19 17:51:24 --> Language Class Initialized
INFO - 2019-08-19 17:51:24 --> Loader Class Initialized
INFO - 2019-08-19 17:51:24 --> Helper loaded: url_helper
INFO - 2019-08-19 17:51:24 --> Helper loaded: html_helper
INFO - 2019-08-19 17:51:24 --> Helper loaded: form_helper
INFO - 2019-08-19 17:51:24 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:51:24 --> Helper loaded: date_helper
INFO - 2019-08-19 17:51:24 --> Form Validation Class Initialized
INFO - 2019-08-19 17:51:24 --> Email Class Initialized
DEBUG - 2019-08-19 17:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:51:24 --> Pagination Class Initialized
INFO - 2019-08-19 17:51:24 --> Database Driver Class Initialized
INFO - 2019-08-19 17:51:24 --> Database Driver Class Initialized
INFO - 2019-08-19 17:51:24 --> Controller Class Initialized
INFO - 2019-08-19 17:51:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:51:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 17:51:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:51:24 --> Final output sent to browser
DEBUG - 2019-08-19 17:51:24 --> Total execution time: 0.1790
INFO - 2019-08-19 17:52:06 --> Config Class Initialized
INFO - 2019-08-19 17:52:06 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:52:06 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:52:06 --> Utf8 Class Initialized
INFO - 2019-08-19 17:52:06 --> URI Class Initialized
INFO - 2019-08-19 17:52:06 --> Router Class Initialized
INFO - 2019-08-19 17:52:06 --> Output Class Initialized
INFO - 2019-08-19 17:52:06 --> Security Class Initialized
DEBUG - 2019-08-19 17:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:52:06 --> Input Class Initialized
INFO - 2019-08-19 17:52:06 --> Language Class Initialized
INFO - 2019-08-19 17:52:06 --> Config Class Initialized
INFO - 2019-08-19 17:52:06 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:52:06 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:52:06 --> Utf8 Class Initialized
INFO - 2019-08-19 17:52:06 --> URI Class Initialized
INFO - 2019-08-19 17:52:06 --> Router Class Initialized
INFO - 2019-08-19 17:52:06 --> Output Class Initialized
INFO - 2019-08-19 17:52:06 --> Security Class Initialized
DEBUG - 2019-08-19 17:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:52:06 --> Input Class Initialized
INFO - 2019-08-19 17:52:06 --> Language Class Initialized
INFO - 2019-08-19 17:52:06 --> Loader Class Initialized
INFO - 2019-08-19 17:52:06 --> Helper loaded: url_helper
INFO - 2019-08-19 17:52:06 --> Helper loaded: html_helper
INFO - 2019-08-19 17:52:06 --> Helper loaded: form_helper
INFO - 2019-08-19 17:52:06 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:52:06 --> Helper loaded: date_helper
INFO - 2019-08-19 17:52:06 --> Form Validation Class Initialized
INFO - 2019-08-19 17:52:06 --> Loader Class Initialized
INFO - 2019-08-19 17:52:06 --> Helper loaded: url_helper
INFO - 2019-08-19 17:52:06 --> Helper loaded: html_helper
INFO - 2019-08-19 17:52:06 --> Helper loaded: form_helper
INFO - 2019-08-19 17:52:06 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:52:06 --> Helper loaded: date_helper
INFO - 2019-08-19 17:52:06 --> Form Validation Class Initialized
INFO - 2019-08-19 17:52:06 --> Email Class Initialized
DEBUG - 2019-08-19 17:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:52:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:52:06 --> Pagination Class Initialized
INFO - 2019-08-19 17:52:06 --> Email Class Initialized
DEBUG - 2019-08-19 17:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:52:07 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:07 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:07 --> Controller Class Initialized
INFO - 2019-08-19 17:52:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:52:07 --> Final output sent to browser
DEBUG - 2019-08-19 17:52:07 --> Total execution time: 0.3280
INFO - 2019-08-19 17:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:52:07 --> Pagination Class Initialized
INFO - 2019-08-19 17:52:07 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:07 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:07 --> Controller Class Initialized
INFO - 2019-08-19 17:52:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:52:07 --> Final output sent to browser
DEBUG - 2019-08-19 17:52:07 --> Total execution time: 0.3700
INFO - 2019-08-19 17:52:07 --> Config Class Initialized
INFO - 2019-08-19 17:52:07 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:52:07 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:52:07 --> Utf8 Class Initialized
INFO - 2019-08-19 17:52:07 --> URI Class Initialized
INFO - 2019-08-19 17:52:07 --> Router Class Initialized
INFO - 2019-08-19 17:52:07 --> Output Class Initialized
INFO - 2019-08-19 17:52:07 --> Security Class Initialized
DEBUG - 2019-08-19 17:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:52:07 --> Input Class Initialized
INFO - 2019-08-19 17:52:07 --> Language Class Initialized
INFO - 2019-08-19 17:52:07 --> Loader Class Initialized
INFO - 2019-08-19 17:52:07 --> Helper loaded: url_helper
INFO - 2019-08-19 17:52:07 --> Helper loaded: html_helper
INFO - 2019-08-19 17:52:07 --> Helper loaded: form_helper
INFO - 2019-08-19 17:52:07 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:52:07 --> Helper loaded: date_helper
INFO - 2019-08-19 17:52:07 --> Form Validation Class Initialized
INFO - 2019-08-19 17:52:07 --> Email Class Initialized
DEBUG - 2019-08-19 17:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:52:07 --> Pagination Class Initialized
INFO - 2019-08-19 17:52:07 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:07 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:07 --> Controller Class Initialized
INFO - 2019-08-19 17:52:07 --> Final output sent to browser
DEBUG - 2019-08-19 17:52:07 --> Total execution time: 0.2630
INFO - 2019-08-19 17:52:28 --> Config Class Initialized
INFO - 2019-08-19 17:52:28 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:52:28 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:52:28 --> Utf8 Class Initialized
INFO - 2019-08-19 17:52:28 --> URI Class Initialized
INFO - 2019-08-19 17:52:28 --> Router Class Initialized
INFO - 2019-08-19 17:52:28 --> Output Class Initialized
INFO - 2019-08-19 17:52:28 --> Security Class Initialized
DEBUG - 2019-08-19 17:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:52:28 --> Input Class Initialized
INFO - 2019-08-19 17:52:28 --> Language Class Initialized
INFO - 2019-08-19 17:52:28 --> Loader Class Initialized
INFO - 2019-08-19 17:52:28 --> Helper loaded: url_helper
INFO - 2019-08-19 17:52:28 --> Helper loaded: html_helper
INFO - 2019-08-19 17:52:28 --> Helper loaded: form_helper
INFO - 2019-08-19 17:52:28 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:52:28 --> Helper loaded: date_helper
INFO - 2019-08-19 17:52:28 --> Form Validation Class Initialized
INFO - 2019-08-19 17:52:28 --> Email Class Initialized
DEBUG - 2019-08-19 17:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:52:28 --> Pagination Class Initialized
INFO - 2019-08-19 17:52:28 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:28 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:28 --> Controller Class Initialized
INFO - 2019-08-19 17:52:28 --> Final output sent to browser
DEBUG - 2019-08-19 17:52:28 --> Total execution time: 0.2780
INFO - 2019-08-19 17:52:50 --> Config Class Initialized
INFO - 2019-08-19 17:52:50 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:52:50 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:52:50 --> Utf8 Class Initialized
INFO - 2019-08-19 17:52:50 --> URI Class Initialized
INFO - 2019-08-19 17:52:50 --> Router Class Initialized
INFO - 2019-08-19 17:52:50 --> Output Class Initialized
INFO - 2019-08-19 17:52:50 --> Security Class Initialized
DEBUG - 2019-08-19 17:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:52:50 --> Input Class Initialized
INFO - 2019-08-19 17:52:50 --> Language Class Initialized
INFO - 2019-08-19 17:52:50 --> Loader Class Initialized
INFO - 2019-08-19 17:52:50 --> Helper loaded: url_helper
INFO - 2019-08-19 17:52:50 --> Helper loaded: html_helper
INFO - 2019-08-19 17:52:50 --> Helper loaded: form_helper
INFO - 2019-08-19 17:52:50 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:52:50 --> Helper loaded: date_helper
INFO - 2019-08-19 17:52:50 --> Form Validation Class Initialized
INFO - 2019-08-19 17:52:50 --> Email Class Initialized
DEBUG - 2019-08-19 17:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:52:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:52:50 --> Pagination Class Initialized
INFO - 2019-08-19 17:52:50 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:50 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:50 --> Controller Class Initialized
INFO - 2019-08-19 17:52:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2019-08-19 17:52:50 --> Query error: Duplicata du champ '104' pour la clef 'room_number' - Invalid query: UPDATE `roomitems` SET `title` = '104', `description` = 'STANDARD ROOM', `bed` = '1', `roomtype` = '6', `roomclass` = '2', `acctname` = '5', `remark` = 'STANDARD ROOM', `frontview` = '0', `backview` = '0', `groundfloor` = '1', `firstfloor` = '0', `secondfloor` = '0', `thirdfloor` = '0', `signature_created` = 'JBA', `date_modified` = '2018-11-27 17:52:50'
WHERE `ID` = '3'
INFO - 2019-08-19 17:52:50 --> Language file loaded: language/english/db_lang.php
INFO - 2019-08-19 17:52:56 --> Config Class Initialized
INFO - 2019-08-19 17:52:56 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:52:56 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:52:56 --> Utf8 Class Initialized
INFO - 2019-08-19 17:52:56 --> URI Class Initialized
INFO - 2019-08-19 17:52:56 --> Router Class Initialized
INFO - 2019-08-19 17:52:56 --> Output Class Initialized
INFO - 2019-08-19 17:52:56 --> Security Class Initialized
DEBUG - 2019-08-19 17:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:52:56 --> Input Class Initialized
INFO - 2019-08-19 17:52:56 --> Language Class Initialized
INFO - 2019-08-19 17:52:56 --> Loader Class Initialized
INFO - 2019-08-19 17:52:56 --> Helper loaded: url_helper
INFO - 2019-08-19 17:52:56 --> Helper loaded: html_helper
INFO - 2019-08-19 17:52:56 --> Helper loaded: form_helper
INFO - 2019-08-19 17:52:56 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:52:56 --> Helper loaded: date_helper
INFO - 2019-08-19 17:52:56 --> Form Validation Class Initialized
INFO - 2019-08-19 17:52:56 --> Email Class Initialized
DEBUG - 2019-08-19 17:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:52:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:52:56 --> Pagination Class Initialized
INFO - 2019-08-19 17:52:56 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:56 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:56 --> Controller Class Initialized
INFO - 2019-08-19 17:52:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:52:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 17:52:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:52:56 --> Final output sent to browser
DEBUG - 2019-08-19 17:52:56 --> Total execution time: 0.2280
INFO - 2019-08-19 17:52:57 --> Config Class Initialized
INFO - 2019-08-19 17:52:57 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:52:57 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:52:57 --> Utf8 Class Initialized
INFO - 2019-08-19 17:52:57 --> URI Class Initialized
INFO - 2019-08-19 17:52:57 --> Config Class Initialized
INFO - 2019-08-19 17:52:57 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:52:57 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:52:57 --> Utf8 Class Initialized
INFO - 2019-08-19 17:52:57 --> Router Class Initialized
INFO - 2019-08-19 17:52:57 --> Output Class Initialized
INFO - 2019-08-19 17:52:57 --> Security Class Initialized
INFO - 2019-08-19 17:52:57 --> URI Class Initialized
DEBUG - 2019-08-19 17:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:52:57 --> Input Class Initialized
INFO - 2019-08-19 17:52:57 --> Router Class Initialized
INFO - 2019-08-19 17:52:57 --> Language Class Initialized
INFO - 2019-08-19 17:52:57 --> Loader Class Initialized
INFO - 2019-08-19 17:52:57 --> Helper loaded: url_helper
INFO - 2019-08-19 17:52:57 --> Helper loaded: html_helper
INFO - 2019-08-19 17:52:57 --> Helper loaded: form_helper
INFO - 2019-08-19 17:52:57 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:52:57 --> Helper loaded: date_helper
INFO - 2019-08-19 17:52:57 --> Form Validation Class Initialized
INFO - 2019-08-19 17:52:57 --> Email Class Initialized
DEBUG - 2019-08-19 17:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:52:57 --> Output Class Initialized
INFO - 2019-08-19 17:52:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:52:57 --> Pagination Class Initialized
INFO - 2019-08-19 17:52:57 --> Security Class Initialized
DEBUG - 2019-08-19 17:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:52:57 --> Input Class Initialized
INFO - 2019-08-19 17:52:57 --> Language Class Initialized
INFO - 2019-08-19 17:52:57 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:57 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:57 --> Loader Class Initialized
INFO - 2019-08-19 17:52:57 --> Helper loaded: url_helper
INFO - 2019-08-19 17:52:57 --> Helper loaded: html_helper
INFO - 2019-08-19 17:52:57 --> Helper loaded: form_helper
INFO - 2019-08-19 17:52:57 --> Controller Class Initialized
INFO - 2019-08-19 17:52:57 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:52:57 --> Helper loaded: date_helper
INFO - 2019-08-19 17:52:57 --> Form Validation Class Initialized
INFO - 2019-08-19 17:52:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:52:57 --> Final output sent to browser
DEBUG - 2019-08-19 17:52:57 --> Total execution time: 0.2480
INFO - 2019-08-19 17:52:57 --> Email Class Initialized
DEBUG - 2019-08-19 17:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:52:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:52:57 --> Pagination Class Initialized
INFO - 2019-08-19 17:52:57 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:57 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:57 --> Controller Class Initialized
INFO - 2019-08-19 17:52:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:52:57 --> Final output sent to browser
DEBUG - 2019-08-19 17:52:57 --> Total execution time: 0.3470
INFO - 2019-08-19 17:52:57 --> Config Class Initialized
INFO - 2019-08-19 17:52:57 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:52:57 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:52:57 --> Utf8 Class Initialized
INFO - 2019-08-19 17:52:57 --> URI Class Initialized
INFO - 2019-08-19 17:52:57 --> Router Class Initialized
INFO - 2019-08-19 17:52:57 --> Output Class Initialized
INFO - 2019-08-19 17:52:57 --> Security Class Initialized
DEBUG - 2019-08-19 17:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:52:57 --> Input Class Initialized
INFO - 2019-08-19 17:52:57 --> Language Class Initialized
INFO - 2019-08-19 17:52:57 --> Loader Class Initialized
INFO - 2019-08-19 17:52:57 --> Helper loaded: url_helper
INFO - 2019-08-19 17:52:57 --> Helper loaded: html_helper
INFO - 2019-08-19 17:52:58 --> Helper loaded: form_helper
INFO - 2019-08-19 17:52:58 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:52:58 --> Helper loaded: date_helper
INFO - 2019-08-19 17:52:58 --> Form Validation Class Initialized
INFO - 2019-08-19 17:52:58 --> Email Class Initialized
DEBUG - 2019-08-19 17:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:52:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:52:58 --> Pagination Class Initialized
INFO - 2019-08-19 17:52:58 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:58 --> Database Driver Class Initialized
INFO - 2019-08-19 17:52:58 --> Controller Class Initialized
INFO - 2019-08-19 17:52:58 --> Final output sent to browser
DEBUG - 2019-08-19 17:52:58 --> Total execution time: 0.2670
INFO - 2019-08-19 17:53:26 --> Config Class Initialized
INFO - 2019-08-19 17:53:26 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:53:26 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:53:26 --> Utf8 Class Initialized
INFO - 2019-08-19 17:53:26 --> URI Class Initialized
INFO - 2019-08-19 17:53:26 --> Router Class Initialized
INFO - 2019-08-19 17:53:26 --> Output Class Initialized
INFO - 2019-08-19 17:53:26 --> Security Class Initialized
DEBUG - 2019-08-19 17:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:53:26 --> Input Class Initialized
INFO - 2019-08-19 17:53:26 --> Language Class Initialized
INFO - 2019-08-19 17:53:26 --> Loader Class Initialized
INFO - 2019-08-19 17:53:26 --> Helper loaded: url_helper
INFO - 2019-08-19 17:53:26 --> Helper loaded: html_helper
INFO - 2019-08-19 17:53:26 --> Helper loaded: form_helper
INFO - 2019-08-19 17:53:26 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:53:26 --> Helper loaded: date_helper
INFO - 2019-08-19 17:53:26 --> Form Validation Class Initialized
INFO - 2019-08-19 17:53:26 --> Email Class Initialized
DEBUG - 2019-08-19 17:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:53:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:53:26 --> Pagination Class Initialized
INFO - 2019-08-19 17:53:26 --> Database Driver Class Initialized
INFO - 2019-08-19 17:53:26 --> Database Driver Class Initialized
INFO - 2019-08-19 17:53:26 --> Controller Class Initialized
INFO - 2019-08-19 17:53:26 --> Final output sent to browser
DEBUG - 2019-08-19 17:53:26 --> Total execution time: 0.2434
INFO - 2019-08-19 17:53:44 --> Config Class Initialized
INFO - 2019-08-19 17:53:44 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:53:44 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:53:44 --> Utf8 Class Initialized
INFO - 2019-08-19 17:53:44 --> URI Class Initialized
INFO - 2019-08-19 17:53:44 --> Router Class Initialized
INFO - 2019-08-19 17:53:44 --> Output Class Initialized
INFO - 2019-08-19 17:53:44 --> Security Class Initialized
DEBUG - 2019-08-19 17:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:53:44 --> Input Class Initialized
INFO - 2019-08-19 17:53:44 --> Language Class Initialized
INFO - 2019-08-19 17:53:44 --> Loader Class Initialized
INFO - 2019-08-19 17:53:44 --> Helper loaded: url_helper
INFO - 2019-08-19 17:53:44 --> Helper loaded: html_helper
INFO - 2019-08-19 17:53:44 --> Helper loaded: form_helper
INFO - 2019-08-19 17:53:44 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:53:44 --> Helper loaded: date_helper
INFO - 2019-08-19 17:53:44 --> Form Validation Class Initialized
INFO - 2019-08-19 17:53:44 --> Email Class Initialized
DEBUG - 2019-08-19 17:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:53:44 --> Pagination Class Initialized
INFO - 2019-08-19 17:53:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:53:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:53:44 --> Controller Class Initialized
INFO - 2019-08-19 17:53:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:53:44 --> Config Class Initialized
INFO - 2019-08-19 17:53:44 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:53:44 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:53:44 --> Utf8 Class Initialized
INFO - 2019-08-19 17:53:44 --> URI Class Initialized
INFO - 2019-08-19 17:53:44 --> Router Class Initialized
INFO - 2019-08-19 17:53:44 --> Output Class Initialized
INFO - 2019-08-19 17:53:44 --> Security Class Initialized
DEBUG - 2019-08-19 17:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:53:44 --> Input Class Initialized
INFO - 2019-08-19 17:53:44 --> Language Class Initialized
INFO - 2019-08-19 17:53:44 --> Loader Class Initialized
INFO - 2019-08-19 17:53:44 --> Helper loaded: url_helper
INFO - 2019-08-19 17:53:44 --> Helper loaded: html_helper
INFO - 2019-08-19 17:53:44 --> Helper loaded: form_helper
INFO - 2019-08-19 17:53:44 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:53:44 --> Helper loaded: date_helper
INFO - 2019-08-19 17:53:44 --> Form Validation Class Initialized
INFO - 2019-08-19 17:53:44 --> Email Class Initialized
DEBUG - 2019-08-19 17:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:53:44 --> Pagination Class Initialized
INFO - 2019-08-19 17:53:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:53:44 --> Database Driver Class Initialized
INFO - 2019-08-19 17:53:44 --> Controller Class Initialized
INFO - 2019-08-19 17:53:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:53:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 17:53:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:53:44 --> Final output sent to browser
DEBUG - 2019-08-19 17:53:44 --> Total execution time: 0.2138
INFO - 2019-08-19 17:54:21 --> Config Class Initialized
INFO - 2019-08-19 17:54:21 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:54:21 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:54:21 --> Utf8 Class Initialized
INFO - 2019-08-19 17:54:21 --> URI Class Initialized
INFO - 2019-08-19 17:54:21 --> Router Class Initialized
INFO - 2019-08-19 17:54:21 --> Output Class Initialized
INFO - 2019-08-19 17:54:21 --> Security Class Initialized
INFO - 2019-08-19 17:54:21 --> Config Class Initialized
INFO - 2019-08-19 17:54:21 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:54:21 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:54:21 --> Utf8 Class Initialized
INFO - 2019-08-19 17:54:21 --> URI Class Initialized
INFO - 2019-08-19 17:54:21 --> Router Class Initialized
INFO - 2019-08-19 17:54:21 --> Output Class Initialized
DEBUG - 2019-08-19 17:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:54:21 --> Input Class Initialized
INFO - 2019-08-19 17:54:21 --> Language Class Initialized
INFO - 2019-08-19 17:54:21 --> Loader Class Initialized
INFO - 2019-08-19 17:54:21 --> Helper loaded: url_helper
INFO - 2019-08-19 17:54:21 --> Helper loaded: html_helper
INFO - 2019-08-19 17:54:21 --> Helper loaded: form_helper
INFO - 2019-08-19 17:54:21 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:54:21 --> Security Class Initialized
DEBUG - 2019-08-19 17:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:54:21 --> Input Class Initialized
INFO - 2019-08-19 17:54:21 --> Helper loaded: date_helper
INFO - 2019-08-19 17:54:21 --> Form Validation Class Initialized
INFO - 2019-08-19 17:54:21 --> Email Class Initialized
DEBUG - 2019-08-19 17:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:54:21 --> Language Class Initialized
INFO - 2019-08-19 17:54:21 --> Loader Class Initialized
INFO - 2019-08-19 17:54:21 --> Helper loaded: url_helper
INFO - 2019-08-19 17:54:21 --> Helper loaded: html_helper
INFO - 2019-08-19 17:54:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:54:21 --> Pagination Class Initialized
INFO - 2019-08-19 17:54:21 --> Database Driver Class Initialized
INFO - 2019-08-19 17:54:21 --> Database Driver Class Initialized
INFO - 2019-08-19 17:54:21 --> Helper loaded: form_helper
INFO - 2019-08-19 17:54:21 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:54:21 --> Helper loaded: date_helper
INFO - 2019-08-19 17:54:21 --> Form Validation Class Initialized
INFO - 2019-08-19 17:54:21 --> Email Class Initialized
DEBUG - 2019-08-19 17:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:54:21 --> Controller Class Initialized
INFO - 2019-08-19 17:54:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:54:21 --> Final output sent to browser
DEBUG - 2019-08-19 17:54:21 --> Total execution time: 0.3188
INFO - 2019-08-19 17:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:54:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:54:21 --> Pagination Class Initialized
INFO - 2019-08-19 17:54:21 --> Database Driver Class Initialized
INFO - 2019-08-19 17:54:21 --> Database Driver Class Initialized
INFO - 2019-08-19 17:54:21 --> Controller Class Initialized
INFO - 2019-08-19 17:54:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:54:21 --> Final output sent to browser
DEBUG - 2019-08-19 17:54:21 --> Total execution time: 0.3978
INFO - 2019-08-19 17:54:22 --> Config Class Initialized
INFO - 2019-08-19 17:54:22 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:54:22 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:54:22 --> Utf8 Class Initialized
INFO - 2019-08-19 17:54:22 --> URI Class Initialized
INFO - 2019-08-19 17:54:22 --> Router Class Initialized
INFO - 2019-08-19 17:54:22 --> Output Class Initialized
INFO - 2019-08-19 17:54:22 --> Security Class Initialized
DEBUG - 2019-08-19 17:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:54:22 --> Input Class Initialized
INFO - 2019-08-19 17:54:22 --> Language Class Initialized
INFO - 2019-08-19 17:54:22 --> Loader Class Initialized
INFO - 2019-08-19 17:54:22 --> Helper loaded: url_helper
INFO - 2019-08-19 17:54:22 --> Helper loaded: html_helper
INFO - 2019-08-19 17:54:22 --> Helper loaded: form_helper
INFO - 2019-08-19 17:54:22 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:54:22 --> Helper loaded: date_helper
INFO - 2019-08-19 17:54:22 --> Form Validation Class Initialized
INFO - 2019-08-19 17:54:22 --> Email Class Initialized
DEBUG - 2019-08-19 17:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:54:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:54:22 --> Pagination Class Initialized
INFO - 2019-08-19 17:54:22 --> Database Driver Class Initialized
INFO - 2019-08-19 17:54:22 --> Database Driver Class Initialized
INFO - 2019-08-19 17:54:22 --> Controller Class Initialized
INFO - 2019-08-19 17:54:22 --> Final output sent to browser
DEBUG - 2019-08-19 17:54:22 --> Total execution time: 0.3228
INFO - 2019-08-19 17:54:43 --> Config Class Initialized
INFO - 2019-08-19 17:54:43 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:54:43 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:54:43 --> Utf8 Class Initialized
INFO - 2019-08-19 17:54:43 --> URI Class Initialized
INFO - 2019-08-19 17:54:43 --> Router Class Initialized
INFO - 2019-08-19 17:54:43 --> Output Class Initialized
INFO - 2019-08-19 17:54:43 --> Security Class Initialized
DEBUG - 2019-08-19 17:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:54:43 --> Input Class Initialized
INFO - 2019-08-19 17:54:43 --> Language Class Initialized
INFO - 2019-08-19 17:54:43 --> Loader Class Initialized
INFO - 2019-08-19 17:54:43 --> Helper loaded: url_helper
INFO - 2019-08-19 17:54:43 --> Helper loaded: html_helper
INFO - 2019-08-19 17:54:43 --> Helper loaded: form_helper
INFO - 2019-08-19 17:54:43 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:54:43 --> Helper loaded: date_helper
INFO - 2019-08-19 17:54:43 --> Form Validation Class Initialized
INFO - 2019-08-19 17:54:43 --> Email Class Initialized
DEBUG - 2019-08-19 17:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:54:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:54:43 --> Pagination Class Initialized
INFO - 2019-08-19 17:54:43 --> Database Driver Class Initialized
INFO - 2019-08-19 17:54:43 --> Database Driver Class Initialized
INFO - 2019-08-19 17:54:43 --> Controller Class Initialized
INFO - 2019-08-19 17:54:44 --> Final output sent to browser
DEBUG - 2019-08-19 17:54:44 --> Total execution time: 0.4460
INFO - 2019-08-19 17:54:56 --> Config Class Initialized
INFO - 2019-08-19 17:54:56 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:54:56 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:54:56 --> Utf8 Class Initialized
INFO - 2019-08-19 17:54:56 --> URI Class Initialized
INFO - 2019-08-19 17:54:56 --> Router Class Initialized
INFO - 2019-08-19 17:54:56 --> Output Class Initialized
INFO - 2019-08-19 17:54:56 --> Security Class Initialized
DEBUG - 2019-08-19 17:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:54:56 --> Input Class Initialized
INFO - 2019-08-19 17:54:56 --> Language Class Initialized
INFO - 2019-08-19 17:54:57 --> Loader Class Initialized
INFO - 2019-08-19 17:54:57 --> Helper loaded: url_helper
INFO - 2019-08-19 17:54:57 --> Helper loaded: html_helper
INFO - 2019-08-19 17:54:57 --> Helper loaded: form_helper
INFO - 2019-08-19 17:54:57 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:54:57 --> Helper loaded: date_helper
INFO - 2019-08-19 17:54:57 --> Form Validation Class Initialized
INFO - 2019-08-19 17:54:57 --> Email Class Initialized
DEBUG - 2019-08-19 17:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:54:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:54:57 --> Pagination Class Initialized
INFO - 2019-08-19 17:54:57 --> Database Driver Class Initialized
INFO - 2019-08-19 17:54:57 --> Database Driver Class Initialized
INFO - 2019-08-19 17:54:57 --> Controller Class Initialized
INFO - 2019-08-19 17:54:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:54:57 --> Config Class Initialized
INFO - 2019-08-19 17:54:57 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:54:57 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:54:57 --> Utf8 Class Initialized
INFO - 2019-08-19 17:54:57 --> URI Class Initialized
INFO - 2019-08-19 17:54:57 --> Router Class Initialized
INFO - 2019-08-19 17:54:57 --> Output Class Initialized
INFO - 2019-08-19 17:54:57 --> Security Class Initialized
DEBUG - 2019-08-19 17:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:54:57 --> Input Class Initialized
INFO - 2019-08-19 17:54:57 --> Language Class Initialized
INFO - 2019-08-19 17:54:57 --> Loader Class Initialized
INFO - 2019-08-19 17:54:57 --> Helper loaded: url_helper
INFO - 2019-08-19 17:54:57 --> Helper loaded: html_helper
INFO - 2019-08-19 17:54:57 --> Helper loaded: form_helper
INFO - 2019-08-19 17:54:57 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:54:57 --> Helper loaded: date_helper
INFO - 2019-08-19 17:54:57 --> Form Validation Class Initialized
INFO - 2019-08-19 17:54:57 --> Email Class Initialized
DEBUG - 2019-08-19 17:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:54:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:54:57 --> Pagination Class Initialized
INFO - 2019-08-19 17:54:57 --> Database Driver Class Initialized
INFO - 2019-08-19 17:54:57 --> Database Driver Class Initialized
INFO - 2019-08-19 17:54:57 --> Controller Class Initialized
INFO - 2019-08-19 17:54:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:54:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 17:54:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:54:57 --> Final output sent to browser
DEBUG - 2019-08-19 17:54:57 --> Total execution time: 0.2440
INFO - 2019-08-19 17:56:05 --> Config Class Initialized
INFO - 2019-08-19 17:56:05 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:56:05 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:56:05 --> Utf8 Class Initialized
INFO - 2019-08-19 17:56:05 --> URI Class Initialized
INFO - 2019-08-19 17:56:05 --> Config Class Initialized
INFO - 2019-08-19 17:56:05 --> Hooks Class Initialized
INFO - 2019-08-19 17:56:05 --> Router Class Initialized
DEBUG - 2019-08-19 17:56:05 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:56:05 --> Utf8 Class Initialized
INFO - 2019-08-19 17:56:05 --> Output Class Initialized
INFO - 2019-08-19 17:56:05 --> URI Class Initialized
INFO - 2019-08-19 17:56:05 --> Security Class Initialized
INFO - 2019-08-19 17:56:05 --> Router Class Initialized
DEBUG - 2019-08-19 17:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:56:05 --> Input Class Initialized
INFO - 2019-08-19 17:56:05 --> Output Class Initialized
INFO - 2019-08-19 17:56:05 --> Language Class Initialized
INFO - 2019-08-19 17:56:05 --> Security Class Initialized
DEBUG - 2019-08-19 17:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:56:05 --> Input Class Initialized
INFO - 2019-08-19 17:56:05 --> Language Class Initialized
INFO - 2019-08-19 17:56:05 --> Loader Class Initialized
INFO - 2019-08-19 17:56:05 --> Helper loaded: url_helper
INFO - 2019-08-19 17:56:05 --> Helper loaded: html_helper
INFO - 2019-08-19 17:56:05 --> Loader Class Initialized
INFO - 2019-08-19 17:56:05 --> Helper loaded: form_helper
INFO - 2019-08-19 17:56:05 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:56:05 --> Helper loaded: url_helper
INFO - 2019-08-19 17:56:05 --> Helper loaded: html_helper
INFO - 2019-08-19 17:56:05 --> Helper loaded: date_helper
INFO - 2019-08-19 17:56:05 --> Helper loaded: form_helper
INFO - 2019-08-19 17:56:05 --> Form Validation Class Initialized
INFO - 2019-08-19 17:56:05 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:56:05 --> Helper loaded: date_helper
INFO - 2019-08-19 17:56:05 --> Email Class Initialized
INFO - 2019-08-19 17:56:05 --> Form Validation Class Initialized
INFO - 2019-08-19 17:56:05 --> Email Class Initialized
DEBUG - 2019-08-19 17:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:56:05 --> Config Class Initialized
INFO - 2019-08-19 17:56:05 --> Hooks Class Initialized
INFO - 2019-08-19 17:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:56:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:56:05 --> Pagination Class Initialized
DEBUG - 2019-08-19 17:56:05 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:56:05 --> Utf8 Class Initialized
INFO - 2019-08-19 17:56:05 --> URI Class Initialized
INFO - 2019-08-19 17:56:05 --> Router Class Initialized
INFO - 2019-08-19 17:56:05 --> Output Class Initialized
INFO - 2019-08-19 17:56:05 --> Security Class Initialized
DEBUG - 2019-08-19 17:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:56:05 --> Input Class Initialized
INFO - 2019-08-19 17:56:05 --> Language Class Initialized
INFO - 2019-08-19 17:56:05 --> Database Driver Class Initialized
INFO - 2019-08-19 17:56:05 --> Database Driver Class Initialized
INFO - 2019-08-19 17:56:05 --> Loader Class Initialized
INFO - 2019-08-19 17:56:05 --> Helper loaded: url_helper
INFO - 2019-08-19 17:56:05 --> Helper loaded: html_helper
DEBUG - 2019-08-19 17:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:56:05 --> Helper loaded: form_helper
INFO - 2019-08-19 17:56:05 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:56:05 --> Helper loaded: date_helper
INFO - 2019-08-19 17:56:06 --> Form Validation Class Initialized
INFO - 2019-08-19 17:56:06 --> Email Class Initialized
DEBUG - 2019-08-19 17:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:56:06 --> Controller Class Initialized
INFO - 2019-08-19 17:56:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:56:06 --> Final output sent to browser
DEBUG - 2019-08-19 17:56:06 --> Total execution time: 0.2680
INFO - 2019-08-19 17:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:56:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:56:06 --> Pagination Class Initialized
INFO - 2019-08-19 17:56:06 --> Database Driver Class Initialized
INFO - 2019-08-19 17:56:06 --> Database Driver Class Initialized
INFO - 2019-08-19 17:56:06 --> Controller Class Initialized
INFO - 2019-08-19 17:56:06 --> Final output sent to browser
DEBUG - 2019-08-19 17:56:06 --> Total execution time: 0.4290
INFO - 2019-08-19 17:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:56:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:56:06 --> Pagination Class Initialized
INFO - 2019-08-19 17:56:06 --> Database Driver Class Initialized
INFO - 2019-08-19 17:56:06 --> Database Driver Class Initialized
INFO - 2019-08-19 17:56:06 --> Controller Class Initialized
INFO - 2019-08-19 17:56:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:56:06 --> Final output sent to browser
DEBUG - 2019-08-19 17:56:06 --> Total execution time: 0.4190
INFO - 2019-08-19 17:56:33 --> Config Class Initialized
INFO - 2019-08-19 17:56:33 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:56:33 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:56:33 --> Utf8 Class Initialized
INFO - 2019-08-19 17:56:33 --> URI Class Initialized
INFO - 2019-08-19 17:56:33 --> Router Class Initialized
INFO - 2019-08-19 17:56:33 --> Output Class Initialized
INFO - 2019-08-19 17:56:33 --> Security Class Initialized
DEBUG - 2019-08-19 17:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:56:33 --> Input Class Initialized
INFO - 2019-08-19 17:56:33 --> Language Class Initialized
INFO - 2019-08-19 17:56:33 --> Loader Class Initialized
INFO - 2019-08-19 17:56:33 --> Helper loaded: url_helper
INFO - 2019-08-19 17:56:33 --> Helper loaded: html_helper
INFO - 2019-08-19 17:56:33 --> Helper loaded: form_helper
INFO - 2019-08-19 17:56:33 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:56:33 --> Helper loaded: date_helper
INFO - 2019-08-19 17:56:33 --> Form Validation Class Initialized
INFO - 2019-08-19 17:56:33 --> Email Class Initialized
DEBUG - 2019-08-19 17:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:56:33 --> Pagination Class Initialized
INFO - 2019-08-19 17:56:33 --> Database Driver Class Initialized
INFO - 2019-08-19 17:56:33 --> Database Driver Class Initialized
INFO - 2019-08-19 17:56:33 --> Controller Class Initialized
INFO - 2019-08-19 17:56:33 --> Final output sent to browser
DEBUG - 2019-08-19 17:56:33 --> Total execution time: 0.2410
INFO - 2019-08-19 17:57:26 --> Config Class Initialized
INFO - 2019-08-19 17:57:26 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:57:26 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:57:26 --> Utf8 Class Initialized
INFO - 2019-08-19 17:57:26 --> URI Class Initialized
INFO - 2019-08-19 17:57:26 --> Router Class Initialized
INFO - 2019-08-19 17:57:26 --> Output Class Initialized
INFO - 2019-08-19 17:57:26 --> Security Class Initialized
DEBUG - 2019-08-19 17:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:57:26 --> Input Class Initialized
INFO - 2019-08-19 17:57:26 --> Language Class Initialized
INFO - 2019-08-19 17:57:26 --> Loader Class Initialized
INFO - 2019-08-19 17:57:26 --> Helper loaded: url_helper
INFO - 2019-08-19 17:57:26 --> Helper loaded: html_helper
INFO - 2019-08-19 17:57:26 --> Helper loaded: form_helper
INFO - 2019-08-19 17:57:26 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:57:26 --> Helper loaded: date_helper
INFO - 2019-08-19 17:57:26 --> Form Validation Class Initialized
INFO - 2019-08-19 17:57:26 --> Email Class Initialized
DEBUG - 2019-08-19 17:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:57:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:57:26 --> Pagination Class Initialized
INFO - 2019-08-19 17:57:26 --> Database Driver Class Initialized
INFO - 2019-08-19 17:57:26 --> Database Driver Class Initialized
INFO - 2019-08-19 17:57:26 --> Controller Class Initialized
INFO - 2019-08-19 17:57:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:57:26 --> Config Class Initialized
INFO - 2019-08-19 17:57:26 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:57:26 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:57:26 --> Utf8 Class Initialized
INFO - 2019-08-19 17:57:26 --> URI Class Initialized
INFO - 2019-08-19 17:57:26 --> Router Class Initialized
INFO - 2019-08-19 17:57:26 --> Output Class Initialized
INFO - 2019-08-19 17:57:26 --> Security Class Initialized
DEBUG - 2019-08-19 17:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:57:26 --> Input Class Initialized
INFO - 2019-08-19 17:57:26 --> Language Class Initialized
INFO - 2019-08-19 17:57:26 --> Loader Class Initialized
INFO - 2019-08-19 17:57:26 --> Helper loaded: url_helper
INFO - 2019-08-19 17:57:26 --> Helper loaded: html_helper
INFO - 2019-08-19 17:57:27 --> Helper loaded: form_helper
INFO - 2019-08-19 17:57:27 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:57:27 --> Helper loaded: date_helper
INFO - 2019-08-19 17:57:27 --> Form Validation Class Initialized
INFO - 2019-08-19 17:57:27 --> Email Class Initialized
DEBUG - 2019-08-19 17:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:57:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:57:27 --> Pagination Class Initialized
INFO - 2019-08-19 17:57:27 --> Database Driver Class Initialized
INFO - 2019-08-19 17:57:27 --> Database Driver Class Initialized
INFO - 2019-08-19 17:57:27 --> Controller Class Initialized
INFO - 2019-08-19 17:57:27 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:57:27 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 17:57:27 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:57:27 --> Final output sent to browser
DEBUG - 2019-08-19 17:57:27 --> Total execution time: 0.1872
INFO - 2019-08-19 17:58:09 --> Config Class Initialized
INFO - 2019-08-19 17:58:09 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:58:09 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:58:09 --> Utf8 Class Initialized
INFO - 2019-08-19 17:58:09 --> URI Class Initialized
INFO - 2019-08-19 17:58:09 --> Router Class Initialized
INFO - 2019-08-19 17:58:09 --> Output Class Initialized
INFO - 2019-08-19 17:58:09 --> Security Class Initialized
DEBUG - 2019-08-19 17:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:58:09 --> Input Class Initialized
INFO - 2019-08-19 17:58:09 --> Language Class Initialized
INFO - 2019-08-19 17:58:09 --> Loader Class Initialized
INFO - 2019-08-19 17:58:09 --> Helper loaded: url_helper
INFO - 2019-08-19 17:58:09 --> Helper loaded: html_helper
INFO - 2019-08-19 17:58:09 --> Helper loaded: form_helper
INFO - 2019-08-19 17:58:09 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:58:09 --> Helper loaded: date_helper
INFO - 2019-08-19 17:58:09 --> Form Validation Class Initialized
INFO - 2019-08-19 17:58:09 --> Config Class Initialized
INFO - 2019-08-19 17:58:09 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:58:09 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:58:09 --> Utf8 Class Initialized
INFO - 2019-08-19 17:58:09 --> URI Class Initialized
INFO - 2019-08-19 17:58:09 --> Router Class Initialized
INFO - 2019-08-19 17:58:09 --> Output Class Initialized
INFO - 2019-08-19 17:58:09 --> Security Class Initialized
DEBUG - 2019-08-19 17:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:58:09 --> Input Class Initialized
INFO - 2019-08-19 17:58:09 --> Language Class Initialized
INFO - 2019-08-19 17:58:09 --> Email Class Initialized
DEBUG - 2019-08-19 17:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:58:09 --> Loader Class Initialized
INFO - 2019-08-19 17:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:58:09 --> Helper loaded: url_helper
INFO - 2019-08-19 17:58:09 --> Helper loaded: html_helper
INFO - 2019-08-19 17:58:09 --> Helper loaded: form_helper
INFO - 2019-08-19 17:58:09 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:58:09 --> Helper loaded: date_helper
INFO - 2019-08-19 17:58:09 --> Form Validation Class Initialized
INFO - 2019-08-19 17:58:09 --> Email Class Initialized
DEBUG - 2019-08-19 17:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:58:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:58:09 --> Pagination Class Initialized
INFO - 2019-08-19 17:58:09 --> Database Driver Class Initialized
INFO - 2019-08-19 17:58:09 --> Database Driver Class Initialized
INFO - 2019-08-19 17:58:09 --> Controller Class Initialized
INFO - 2019-08-19 17:58:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:58:09 --> Final output sent to browser
DEBUG - 2019-08-19 17:58:09 --> Total execution time: 0.2808
INFO - 2019-08-19 17:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:58:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:58:09 --> Pagination Class Initialized
INFO - 2019-08-19 17:58:09 --> Database Driver Class Initialized
INFO - 2019-08-19 17:58:09 --> Database Driver Class Initialized
INFO - 2019-08-19 17:58:09 --> Controller Class Initialized
INFO - 2019-08-19 17:58:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:58:09 --> Final output sent to browser
DEBUG - 2019-08-19 17:58:09 --> Total execution time: 0.2964
INFO - 2019-08-19 17:58:10 --> Config Class Initialized
INFO - 2019-08-19 17:58:10 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:58:10 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:58:10 --> Utf8 Class Initialized
INFO - 2019-08-19 17:58:10 --> URI Class Initialized
INFO - 2019-08-19 17:58:10 --> Router Class Initialized
INFO - 2019-08-19 17:58:10 --> Output Class Initialized
INFO - 2019-08-19 17:58:10 --> Security Class Initialized
DEBUG - 2019-08-19 17:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:58:10 --> Input Class Initialized
INFO - 2019-08-19 17:58:10 --> Language Class Initialized
INFO - 2019-08-19 17:58:10 --> Loader Class Initialized
INFO - 2019-08-19 17:58:10 --> Helper loaded: url_helper
INFO - 2019-08-19 17:58:10 --> Helper loaded: html_helper
INFO - 2019-08-19 17:58:10 --> Helper loaded: form_helper
INFO - 2019-08-19 17:58:10 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:58:10 --> Helper loaded: date_helper
INFO - 2019-08-19 17:58:10 --> Form Validation Class Initialized
INFO - 2019-08-19 17:58:10 --> Email Class Initialized
DEBUG - 2019-08-19 17:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:58:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:58:10 --> Pagination Class Initialized
INFO - 2019-08-19 17:58:10 --> Database Driver Class Initialized
INFO - 2019-08-19 17:58:10 --> Database Driver Class Initialized
INFO - 2019-08-19 17:58:10 --> Controller Class Initialized
INFO - 2019-08-19 17:58:10 --> Final output sent to browser
DEBUG - 2019-08-19 17:58:10 --> Total execution time: 0.2380
INFO - 2019-08-19 17:58:32 --> Config Class Initialized
INFO - 2019-08-19 17:58:32 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:58:32 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:58:32 --> Utf8 Class Initialized
INFO - 2019-08-19 17:58:32 --> URI Class Initialized
INFO - 2019-08-19 17:58:32 --> Router Class Initialized
INFO - 2019-08-19 17:58:32 --> Output Class Initialized
INFO - 2019-08-19 17:58:32 --> Security Class Initialized
DEBUG - 2019-08-19 17:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:58:32 --> Input Class Initialized
INFO - 2019-08-19 17:58:32 --> Language Class Initialized
INFO - 2019-08-19 17:58:32 --> Loader Class Initialized
INFO - 2019-08-19 17:58:32 --> Helper loaded: url_helper
INFO - 2019-08-19 17:58:32 --> Helper loaded: html_helper
INFO - 2019-08-19 17:58:33 --> Helper loaded: form_helper
INFO - 2019-08-19 17:58:33 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:58:33 --> Helper loaded: date_helper
INFO - 2019-08-19 17:58:33 --> Form Validation Class Initialized
INFO - 2019-08-19 17:58:33 --> Email Class Initialized
DEBUG - 2019-08-19 17:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:58:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:58:33 --> Pagination Class Initialized
INFO - 2019-08-19 17:58:33 --> Database Driver Class Initialized
INFO - 2019-08-19 17:58:33 --> Database Driver Class Initialized
INFO - 2019-08-19 17:58:33 --> Controller Class Initialized
INFO - 2019-08-19 17:58:33 --> Final output sent to browser
DEBUG - 2019-08-19 17:58:33 --> Total execution time: 0.2250
INFO - 2019-08-19 17:59:09 --> Config Class Initialized
INFO - 2019-08-19 17:59:09 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:59:09 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:59:09 --> Utf8 Class Initialized
INFO - 2019-08-19 17:59:09 --> URI Class Initialized
INFO - 2019-08-19 17:59:09 --> Router Class Initialized
INFO - 2019-08-19 17:59:09 --> Output Class Initialized
INFO - 2019-08-19 17:59:09 --> Security Class Initialized
DEBUG - 2019-08-19 17:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:59:09 --> Input Class Initialized
INFO - 2019-08-19 17:59:09 --> Language Class Initialized
INFO - 2019-08-19 17:59:09 --> Loader Class Initialized
INFO - 2019-08-19 17:59:09 --> Helper loaded: url_helper
INFO - 2019-08-19 17:59:09 --> Helper loaded: html_helper
INFO - 2019-08-19 17:59:09 --> Helper loaded: form_helper
INFO - 2019-08-19 17:59:09 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:59:09 --> Helper loaded: date_helper
INFO - 2019-08-19 17:59:09 --> Form Validation Class Initialized
INFO - 2019-08-19 17:59:09 --> Email Class Initialized
DEBUG - 2019-08-19 17:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:59:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:59:09 --> Pagination Class Initialized
INFO - 2019-08-19 17:59:09 --> Database Driver Class Initialized
INFO - 2019-08-19 17:59:09 --> Database Driver Class Initialized
INFO - 2019-08-19 17:59:09 --> Controller Class Initialized
INFO - 2019-08-19 17:59:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 17:59:10 --> Config Class Initialized
INFO - 2019-08-19 17:59:10 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:59:10 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:59:10 --> Utf8 Class Initialized
INFO - 2019-08-19 17:59:10 --> URI Class Initialized
INFO - 2019-08-19 17:59:10 --> Router Class Initialized
INFO - 2019-08-19 17:59:10 --> Output Class Initialized
INFO - 2019-08-19 17:59:10 --> Security Class Initialized
DEBUG - 2019-08-19 17:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:59:10 --> Input Class Initialized
INFO - 2019-08-19 17:59:10 --> Language Class Initialized
INFO - 2019-08-19 17:59:10 --> Loader Class Initialized
INFO - 2019-08-19 17:59:10 --> Helper loaded: url_helper
INFO - 2019-08-19 17:59:10 --> Helper loaded: html_helper
INFO - 2019-08-19 17:59:10 --> Helper loaded: form_helper
INFO - 2019-08-19 17:59:10 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:59:10 --> Helper loaded: date_helper
INFO - 2019-08-19 17:59:10 --> Form Validation Class Initialized
INFO - 2019-08-19 17:59:10 --> Email Class Initialized
DEBUG - 2019-08-19 17:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:59:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:59:10 --> Pagination Class Initialized
INFO - 2019-08-19 17:59:10 --> Database Driver Class Initialized
INFO - 2019-08-19 17:59:10 --> Database Driver Class Initialized
INFO - 2019-08-19 17:59:10 --> Controller Class Initialized
INFO - 2019-08-19 17:59:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 17:59:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 17:59:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 17:59:10 --> Final output sent to browser
DEBUG - 2019-08-19 17:59:10 --> Total execution time: 0.1720
INFO - 2019-08-19 17:59:52 --> Config Class Initialized
INFO - 2019-08-19 17:59:52 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:59:52 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:59:52 --> Utf8 Class Initialized
INFO - 2019-08-19 17:59:52 --> Config Class Initialized
INFO - 2019-08-19 17:59:52 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:59:52 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:59:52 --> Utf8 Class Initialized
INFO - 2019-08-19 17:59:52 --> URI Class Initialized
INFO - 2019-08-19 17:59:52 --> Router Class Initialized
INFO - 2019-08-19 17:59:52 --> Output Class Initialized
INFO - 2019-08-19 17:59:52 --> Security Class Initialized
DEBUG - 2019-08-19 17:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:59:52 --> Input Class Initialized
INFO - 2019-08-19 17:59:52 --> Language Class Initialized
INFO - 2019-08-19 17:59:52 --> URI Class Initialized
INFO - 2019-08-19 17:59:52 --> Router Class Initialized
INFO - 2019-08-19 17:59:52 --> Output Class Initialized
INFO - 2019-08-19 17:59:52 --> Security Class Initialized
DEBUG - 2019-08-19 17:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:59:52 --> Input Class Initialized
INFO - 2019-08-19 17:59:52 --> Language Class Initialized
INFO - 2019-08-19 17:59:52 --> Loader Class Initialized
INFO - 2019-08-19 17:59:52 --> Helper loaded: url_helper
INFO - 2019-08-19 17:59:52 --> Helper loaded: html_helper
INFO - 2019-08-19 17:59:52 --> Helper loaded: form_helper
INFO - 2019-08-19 17:59:52 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:59:52 --> Helper loaded: date_helper
INFO - 2019-08-19 17:59:52 --> Form Validation Class Initialized
INFO - 2019-08-19 17:59:52 --> Loader Class Initialized
INFO - 2019-08-19 17:59:52 --> Helper loaded: url_helper
INFO - 2019-08-19 17:59:52 --> Helper loaded: html_helper
INFO - 2019-08-19 17:59:52 --> Helper loaded: form_helper
INFO - 2019-08-19 17:59:52 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:59:52 --> Helper loaded: date_helper
INFO - 2019-08-19 17:59:52 --> Form Validation Class Initialized
INFO - 2019-08-19 17:59:52 --> Email Class Initialized
DEBUG - 2019-08-19 17:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:59:52 --> Pagination Class Initialized
INFO - 2019-08-19 17:59:52 --> Database Driver Class Initialized
INFO - 2019-08-19 17:59:52 --> Email Class Initialized
DEBUG - 2019-08-19 17:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:59:52 --> Database Driver Class Initialized
INFO - 2019-08-19 17:59:52 --> Controller Class Initialized
INFO - 2019-08-19 17:59:52 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:59:52 --> Final output sent to browser
DEBUG - 2019-08-19 17:59:52 --> Total execution time: 0.3448
INFO - 2019-08-19 17:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:59:52 --> Pagination Class Initialized
INFO - 2019-08-19 17:59:52 --> Database Driver Class Initialized
INFO - 2019-08-19 17:59:52 --> Database Driver Class Initialized
INFO - 2019-08-19 17:59:52 --> Controller Class Initialized
INFO - 2019-08-19 17:59:52 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 17:59:52 --> Final output sent to browser
DEBUG - 2019-08-19 17:59:52 --> Total execution time: 0.4106
INFO - 2019-08-19 17:59:53 --> Config Class Initialized
INFO - 2019-08-19 17:59:53 --> Hooks Class Initialized
DEBUG - 2019-08-19 17:59:53 --> UTF-8 Support Enabled
INFO - 2019-08-19 17:59:53 --> Utf8 Class Initialized
INFO - 2019-08-19 17:59:53 --> URI Class Initialized
INFO - 2019-08-19 17:59:53 --> Router Class Initialized
INFO - 2019-08-19 17:59:53 --> Output Class Initialized
INFO - 2019-08-19 17:59:53 --> Security Class Initialized
DEBUG - 2019-08-19 17:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 17:59:53 --> Input Class Initialized
INFO - 2019-08-19 17:59:53 --> Language Class Initialized
INFO - 2019-08-19 17:59:53 --> Loader Class Initialized
INFO - 2019-08-19 17:59:53 --> Helper loaded: url_helper
INFO - 2019-08-19 17:59:53 --> Helper loaded: html_helper
INFO - 2019-08-19 17:59:53 --> Helper loaded: form_helper
INFO - 2019-08-19 17:59:53 --> Helper loaded: cookie_helper
INFO - 2019-08-19 17:59:53 --> Helper loaded: date_helper
INFO - 2019-08-19 17:59:53 --> Form Validation Class Initialized
INFO - 2019-08-19 17:59:53 --> Email Class Initialized
DEBUG - 2019-08-19 17:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 17:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 17:59:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 17:59:53 --> Pagination Class Initialized
INFO - 2019-08-19 17:59:53 --> Database Driver Class Initialized
INFO - 2019-08-19 17:59:53 --> Database Driver Class Initialized
INFO - 2019-08-19 17:59:53 --> Controller Class Initialized
INFO - 2019-08-19 17:59:53 --> Final output sent to browser
DEBUG - 2019-08-19 17:59:53 --> Total execution time: 0.3016
INFO - 2019-08-19 18:00:04 --> Config Class Initialized
INFO - 2019-08-19 18:00:04 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:00:04 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:00:04 --> Utf8 Class Initialized
INFO - 2019-08-19 18:00:04 --> URI Class Initialized
INFO - 2019-08-19 18:00:04 --> Router Class Initialized
INFO - 2019-08-19 18:00:04 --> Output Class Initialized
INFO - 2019-08-19 18:00:04 --> Security Class Initialized
DEBUG - 2019-08-19 18:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:00:04 --> Input Class Initialized
INFO - 2019-08-19 18:00:04 --> Language Class Initialized
INFO - 2019-08-19 18:00:04 --> Loader Class Initialized
INFO - 2019-08-19 18:00:04 --> Helper loaded: url_helper
INFO - 2019-08-19 18:00:04 --> Helper loaded: html_helper
INFO - 2019-08-19 18:00:04 --> Helper loaded: form_helper
INFO - 2019-08-19 18:00:04 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:00:04 --> Helper loaded: date_helper
INFO - 2019-08-19 18:00:04 --> Form Validation Class Initialized
INFO - 2019-08-19 18:00:04 --> Email Class Initialized
DEBUG - 2019-08-19 18:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:00:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:00:04 --> Pagination Class Initialized
INFO - 2019-08-19 18:00:04 --> Database Driver Class Initialized
INFO - 2019-08-19 18:00:04 --> Database Driver Class Initialized
INFO - 2019-08-19 18:00:04 --> Controller Class Initialized
INFO - 2019-08-19 18:00:04 --> Final output sent to browser
DEBUG - 2019-08-19 18:00:04 --> Total execution time: 0.2240
INFO - 2019-08-19 18:00:29 --> Config Class Initialized
INFO - 2019-08-19 18:00:29 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:00:29 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:00:29 --> Utf8 Class Initialized
INFO - 2019-08-19 18:00:29 --> URI Class Initialized
INFO - 2019-08-19 18:00:29 --> Router Class Initialized
INFO - 2019-08-19 18:00:29 --> Output Class Initialized
INFO - 2019-08-19 18:00:29 --> Security Class Initialized
DEBUG - 2019-08-19 18:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:00:29 --> Input Class Initialized
INFO - 2019-08-19 18:00:29 --> Language Class Initialized
INFO - 2019-08-19 18:00:29 --> Loader Class Initialized
INFO - 2019-08-19 18:00:29 --> Helper loaded: url_helper
INFO - 2019-08-19 18:00:29 --> Helper loaded: html_helper
INFO - 2019-08-19 18:00:29 --> Helper loaded: form_helper
INFO - 2019-08-19 18:00:29 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:00:29 --> Helper loaded: date_helper
INFO - 2019-08-19 18:00:29 --> Form Validation Class Initialized
INFO - 2019-08-19 18:00:29 --> Email Class Initialized
DEBUG - 2019-08-19 18:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:00:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:00:29 --> Pagination Class Initialized
INFO - 2019-08-19 18:00:29 --> Database Driver Class Initialized
INFO - 2019-08-19 18:00:29 --> Database Driver Class Initialized
INFO - 2019-08-19 18:00:29 --> Controller Class Initialized
INFO - 2019-08-19 18:00:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 18:00:29 --> Config Class Initialized
INFO - 2019-08-19 18:00:29 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:00:29 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:00:29 --> Utf8 Class Initialized
INFO - 2019-08-19 18:00:29 --> URI Class Initialized
INFO - 2019-08-19 18:00:29 --> Router Class Initialized
INFO - 2019-08-19 18:00:29 --> Output Class Initialized
INFO - 2019-08-19 18:00:29 --> Security Class Initialized
DEBUG - 2019-08-19 18:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:00:29 --> Input Class Initialized
INFO - 2019-08-19 18:00:29 --> Language Class Initialized
INFO - 2019-08-19 18:00:29 --> Loader Class Initialized
INFO - 2019-08-19 18:00:29 --> Helper loaded: url_helper
INFO - 2019-08-19 18:00:29 --> Helper loaded: html_helper
INFO - 2019-08-19 18:00:29 --> Helper loaded: form_helper
INFO - 2019-08-19 18:00:29 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:00:29 --> Helper loaded: date_helper
INFO - 2019-08-19 18:00:29 --> Form Validation Class Initialized
INFO - 2019-08-19 18:00:29 --> Email Class Initialized
DEBUG - 2019-08-19 18:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:00:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:00:29 --> Pagination Class Initialized
INFO - 2019-08-19 18:00:29 --> Database Driver Class Initialized
INFO - 2019-08-19 18:00:29 --> Database Driver Class Initialized
INFO - 2019-08-19 18:00:29 --> Controller Class Initialized
INFO - 2019-08-19 18:00:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:00:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 18:00:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:00:29 --> Final output sent to browser
DEBUG - 2019-08-19 18:00:29 --> Total execution time: 0.2656
INFO - 2019-08-19 18:01:14 --> Config Class Initialized
INFO - 2019-08-19 18:01:14 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:01:14 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:01:14 --> Utf8 Class Initialized
INFO - 2019-08-19 18:01:14 --> URI Class Initialized
INFO - 2019-08-19 18:01:14 --> Router Class Initialized
INFO - 2019-08-19 18:01:14 --> Output Class Initialized
INFO - 2019-08-19 18:01:14 --> Security Class Initialized
DEBUG - 2019-08-19 18:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:01:14 --> Input Class Initialized
INFO - 2019-08-19 18:01:14 --> Config Class Initialized
INFO - 2019-08-19 18:01:14 --> Hooks Class Initialized
INFO - 2019-08-19 18:01:14 --> Config Class Initialized
INFO - 2019-08-19 18:01:14 --> Hooks Class Initialized
INFO - 2019-08-19 18:01:14 --> Language Class Initialized
DEBUG - 2019-08-19 18:01:14 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:01:14 --> Utf8 Class Initialized
INFO - 2019-08-19 18:01:14 --> Loader Class Initialized
INFO - 2019-08-19 18:01:14 --> URI Class Initialized
INFO - 2019-08-19 18:01:14 --> Helper loaded: url_helper
INFO - 2019-08-19 18:01:14 --> Helper loaded: html_helper
INFO - 2019-08-19 18:01:14 --> Helper loaded: form_helper
INFO - 2019-08-19 18:01:14 --> Helper loaded: cookie_helper
DEBUG - 2019-08-19 18:01:14 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:01:14 --> Utf8 Class Initialized
INFO - 2019-08-19 18:01:14 --> URI Class Initialized
INFO - 2019-08-19 18:01:14 --> Router Class Initialized
INFO - 2019-08-19 18:01:14 --> Router Class Initialized
INFO - 2019-08-19 18:01:14 --> Output Class Initialized
INFO - 2019-08-19 18:01:14 --> Helper loaded: date_helper
INFO - 2019-08-19 18:01:14 --> Output Class Initialized
INFO - 2019-08-19 18:01:14 --> Security Class Initialized
INFO - 2019-08-19 18:01:14 --> Form Validation Class Initialized
INFO - 2019-08-19 18:01:14 --> Security Class Initialized
DEBUG - 2019-08-19 18:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:01:14 --> Email Class Initialized
DEBUG - 2019-08-19 18:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:01:14 --> Input Class Initialized
DEBUG - 2019-08-19 18:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:01:14 --> Input Class Initialized
INFO - 2019-08-19 18:01:14 --> Language Class Initialized
INFO - 2019-08-19 18:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:01:14 --> Language Class Initialized
INFO - 2019-08-19 18:01:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:01:14 --> Pagination Class Initialized
INFO - 2019-08-19 18:01:15 --> Loader Class Initialized
INFO - 2019-08-19 18:01:15 --> Helper loaded: url_helper
INFO - 2019-08-19 18:01:15 --> Helper loaded: html_helper
INFO - 2019-08-19 18:01:15 --> Helper loaded: form_helper
INFO - 2019-08-19 18:01:15 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:01:15 --> Helper loaded: date_helper
INFO - 2019-08-19 18:01:15 --> Form Validation Class Initialized
INFO - 2019-08-19 18:01:15 --> Database Driver Class Initialized
INFO - 2019-08-19 18:01:15 --> Database Driver Class Initialized
INFO - 2019-08-19 18:01:15 --> Email Class Initialized
INFO - 2019-08-19 18:01:15 --> Loader Class Initialized
INFO - 2019-08-19 18:01:15 --> Helper loaded: url_helper
DEBUG - 2019-08-19 18:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:01:15 --> Helper loaded: html_helper
INFO - 2019-08-19 18:01:15 --> Helper loaded: form_helper
INFO - 2019-08-19 18:01:15 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:01:15 --> Controller Class Initialized
INFO - 2019-08-19 18:01:15 --> Helper loaded: date_helper
INFO - 2019-08-19 18:01:15 --> Form Validation Class Initialized
INFO - 2019-08-19 18:01:15 --> Final output sent to browser
INFO - 2019-08-19 18:01:15 --> Email Class Initialized
DEBUG - 2019-08-19 18:01:15 --> Total execution time: 0.4390
INFO - 2019-08-19 18:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:01:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:01:15 --> Pagination Class Initialized
INFO - 2019-08-19 18:01:15 --> Database Driver Class Initialized
INFO - 2019-08-19 18:01:15 --> Database Driver Class Initialized
INFO - 2019-08-19 18:01:15 --> Controller Class Initialized
DEBUG - 2019-08-19 18:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:01:15 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:01:15 --> Final output sent to browser
DEBUG - 2019-08-19 18:01:15 --> Total execution time: 0.4580
INFO - 2019-08-19 18:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:01:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:01:15 --> Pagination Class Initialized
INFO - 2019-08-19 18:01:15 --> Database Driver Class Initialized
INFO - 2019-08-19 18:01:15 --> Database Driver Class Initialized
INFO - 2019-08-19 18:01:15 --> Controller Class Initialized
INFO - 2019-08-19 18:01:15 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:01:15 --> Final output sent to browser
DEBUG - 2019-08-19 18:01:15 --> Total execution time: 0.5998
INFO - 2019-08-19 18:01:54 --> Config Class Initialized
INFO - 2019-08-19 18:01:54 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:01:54 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:01:54 --> Utf8 Class Initialized
INFO - 2019-08-19 18:01:54 --> URI Class Initialized
INFO - 2019-08-19 18:01:54 --> Router Class Initialized
INFO - 2019-08-19 18:01:54 --> Output Class Initialized
INFO - 2019-08-19 18:01:54 --> Security Class Initialized
DEBUG - 2019-08-19 18:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:01:54 --> Input Class Initialized
INFO - 2019-08-19 18:01:54 --> Language Class Initialized
INFO - 2019-08-19 18:01:54 --> Loader Class Initialized
INFO - 2019-08-19 18:01:54 --> Helper loaded: url_helper
INFO - 2019-08-19 18:01:54 --> Helper loaded: html_helper
INFO - 2019-08-19 18:01:54 --> Helper loaded: form_helper
INFO - 2019-08-19 18:01:54 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:01:54 --> Helper loaded: date_helper
INFO - 2019-08-19 18:01:54 --> Form Validation Class Initialized
INFO - 2019-08-19 18:01:54 --> Email Class Initialized
DEBUG - 2019-08-19 18:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:01:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:01:54 --> Pagination Class Initialized
INFO - 2019-08-19 18:01:54 --> Database Driver Class Initialized
INFO - 2019-08-19 18:01:54 --> Database Driver Class Initialized
INFO - 2019-08-19 18:01:54 --> Controller Class Initialized
INFO - 2019-08-19 18:01:54 --> Final output sent to browser
DEBUG - 2019-08-19 18:01:54 --> Total execution time: 0.2482
INFO - 2019-08-19 18:02:11 --> Config Class Initialized
INFO - 2019-08-19 18:02:11 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:02:11 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:02:11 --> Utf8 Class Initialized
INFO - 2019-08-19 18:02:11 --> URI Class Initialized
INFO - 2019-08-19 18:02:11 --> Router Class Initialized
INFO - 2019-08-19 18:02:12 --> Output Class Initialized
INFO - 2019-08-19 18:02:12 --> Security Class Initialized
DEBUG - 2019-08-19 18:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:02:12 --> Input Class Initialized
INFO - 2019-08-19 18:02:12 --> Language Class Initialized
INFO - 2019-08-19 18:02:12 --> Loader Class Initialized
INFO - 2019-08-19 18:02:12 --> Helper loaded: url_helper
INFO - 2019-08-19 18:02:12 --> Helper loaded: html_helper
INFO - 2019-08-19 18:02:12 --> Helper loaded: form_helper
INFO - 2019-08-19 18:02:12 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:02:12 --> Helper loaded: date_helper
INFO - 2019-08-19 18:02:12 --> Form Validation Class Initialized
INFO - 2019-08-19 18:02:12 --> Email Class Initialized
DEBUG - 2019-08-19 18:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:02:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:02:12 --> Pagination Class Initialized
INFO - 2019-08-19 18:02:12 --> Database Driver Class Initialized
INFO - 2019-08-19 18:02:12 --> Database Driver Class Initialized
INFO - 2019-08-19 18:02:12 --> Controller Class Initialized
INFO - 2019-08-19 18:02:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 18:02:12 --> Config Class Initialized
INFO - 2019-08-19 18:02:12 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:02:12 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:02:12 --> Utf8 Class Initialized
INFO - 2019-08-19 18:02:12 --> URI Class Initialized
INFO - 2019-08-19 18:02:12 --> Router Class Initialized
INFO - 2019-08-19 18:02:12 --> Output Class Initialized
INFO - 2019-08-19 18:02:12 --> Security Class Initialized
DEBUG - 2019-08-19 18:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:02:12 --> Input Class Initialized
INFO - 2019-08-19 18:02:12 --> Language Class Initialized
INFO - 2019-08-19 18:02:12 --> Loader Class Initialized
INFO - 2019-08-19 18:02:12 --> Helper loaded: url_helper
INFO - 2019-08-19 18:02:12 --> Helper loaded: html_helper
INFO - 2019-08-19 18:02:12 --> Helper loaded: form_helper
INFO - 2019-08-19 18:02:12 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:02:12 --> Helper loaded: date_helper
INFO - 2019-08-19 18:02:12 --> Form Validation Class Initialized
INFO - 2019-08-19 18:02:12 --> Email Class Initialized
DEBUG - 2019-08-19 18:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:02:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:02:12 --> Pagination Class Initialized
INFO - 2019-08-19 18:02:12 --> Database Driver Class Initialized
INFO - 2019-08-19 18:02:12 --> Database Driver Class Initialized
INFO - 2019-08-19 18:02:12 --> Controller Class Initialized
INFO - 2019-08-19 18:02:12 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:02:12 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 18:02:12 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:02:12 --> Final output sent to browser
DEBUG - 2019-08-19 18:02:12 --> Total execution time: 0.4460
INFO - 2019-08-19 18:02:55 --> Config Class Initialized
INFO - 2019-08-19 18:02:55 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:02:55 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:02:55 --> Utf8 Class Initialized
INFO - 2019-08-19 18:02:55 --> URI Class Initialized
INFO - 2019-08-19 18:02:55 --> Router Class Initialized
INFO - 2019-08-19 18:02:55 --> Output Class Initialized
INFO - 2019-08-19 18:02:55 --> Security Class Initialized
DEBUG - 2019-08-19 18:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:02:55 --> Input Class Initialized
INFO - 2019-08-19 18:02:55 --> Language Class Initialized
INFO - 2019-08-19 18:02:55 --> Loader Class Initialized
INFO - 2019-08-19 18:02:55 --> Helper loaded: url_helper
INFO - 2019-08-19 18:02:56 --> Config Class Initialized
INFO - 2019-08-19 18:02:56 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:02:56 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:02:56 --> Utf8 Class Initialized
INFO - 2019-08-19 18:02:56 --> URI Class Initialized
INFO - 2019-08-19 18:02:56 --> Router Class Initialized
INFO - 2019-08-19 18:02:56 --> Output Class Initialized
INFO - 2019-08-19 18:02:56 --> Helper loaded: html_helper
INFO - 2019-08-19 18:02:56 --> Helper loaded: form_helper
INFO - 2019-08-19 18:02:56 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:02:56 --> Helper loaded: date_helper
INFO - 2019-08-19 18:02:56 --> Form Validation Class Initialized
INFO - 2019-08-19 18:02:56 --> Security Class Initialized
DEBUG - 2019-08-19 18:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:02:56 --> Input Class Initialized
INFO - 2019-08-19 18:02:56 --> Language Class Initialized
INFO - 2019-08-19 18:02:56 --> Loader Class Initialized
INFO - 2019-08-19 18:02:56 --> Helper loaded: url_helper
INFO - 2019-08-19 18:02:56 --> Email Class Initialized
DEBUG - 2019-08-19 18:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:02:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:02:56 --> Pagination Class Initialized
INFO - 2019-08-19 18:02:56 --> Helper loaded: html_helper
INFO - 2019-08-19 18:02:56 --> Helper loaded: form_helper
INFO - 2019-08-19 18:02:56 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:02:56 --> Helper loaded: date_helper
INFO - 2019-08-19 18:02:56 --> Form Validation Class Initialized
INFO - 2019-08-19 18:02:56 --> Email Class Initialized
INFO - 2019-08-19 18:02:56 --> Database Driver Class Initialized
INFO - 2019-08-19 18:02:56 --> Database Driver Class Initialized
DEBUG - 2019-08-19 18:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:02:56 --> Controller Class Initialized
INFO - 2019-08-19 18:02:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:02:56 --> Final output sent to browser
DEBUG - 2019-08-19 18:02:56 --> Total execution time: 1.2211
INFO - 2019-08-19 18:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:02:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:02:56 --> Pagination Class Initialized
INFO - 2019-08-19 18:02:56 --> Database Driver Class Initialized
INFO - 2019-08-19 18:02:56 --> Database Driver Class Initialized
INFO - 2019-08-19 18:02:57 --> Controller Class Initialized
INFO - 2019-08-19 18:02:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:02:57 --> Final output sent to browser
DEBUG - 2019-08-19 18:02:57 --> Total execution time: 1.2951
INFO - 2019-08-19 18:02:57 --> Config Class Initialized
INFO - 2019-08-19 18:02:57 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:02:57 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:02:57 --> Utf8 Class Initialized
INFO - 2019-08-19 18:02:57 --> URI Class Initialized
INFO - 2019-08-19 18:02:57 --> Router Class Initialized
INFO - 2019-08-19 18:02:57 --> Output Class Initialized
INFO - 2019-08-19 18:02:57 --> Security Class Initialized
DEBUG - 2019-08-19 18:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:02:57 --> Input Class Initialized
INFO - 2019-08-19 18:02:57 --> Language Class Initialized
INFO - 2019-08-19 18:02:57 --> Loader Class Initialized
INFO - 2019-08-19 18:02:57 --> Helper loaded: url_helper
INFO - 2019-08-19 18:02:57 --> Helper loaded: html_helper
INFO - 2019-08-19 18:02:57 --> Helper loaded: form_helper
INFO - 2019-08-19 18:02:57 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:02:57 --> Helper loaded: date_helper
INFO - 2019-08-19 18:02:57 --> Form Validation Class Initialized
INFO - 2019-08-19 18:02:57 --> Email Class Initialized
DEBUG - 2019-08-19 18:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:02:57 --> Pagination Class Initialized
INFO - 2019-08-19 18:02:57 --> Database Driver Class Initialized
INFO - 2019-08-19 18:02:57 --> Database Driver Class Initialized
INFO - 2019-08-19 18:02:58 --> Controller Class Initialized
INFO - 2019-08-19 18:02:58 --> Final output sent to browser
DEBUG - 2019-08-19 18:02:58 --> Total execution time: 0.5460
INFO - 2019-08-19 18:04:16 --> Config Class Initialized
INFO - 2019-08-19 18:04:16 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:04:16 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:04:16 --> Utf8 Class Initialized
INFO - 2019-08-19 18:04:16 --> URI Class Initialized
INFO - 2019-08-19 18:04:16 --> Router Class Initialized
INFO - 2019-08-19 18:04:16 --> Output Class Initialized
INFO - 2019-08-19 18:04:16 --> Security Class Initialized
DEBUG - 2019-08-19 18:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:04:16 --> Input Class Initialized
INFO - 2019-08-19 18:04:16 --> Language Class Initialized
INFO - 2019-08-19 18:04:16 --> Loader Class Initialized
INFO - 2019-08-19 18:04:16 --> Helper loaded: url_helper
INFO - 2019-08-19 18:04:16 --> Helper loaded: html_helper
INFO - 2019-08-19 18:04:16 --> Helper loaded: form_helper
INFO - 2019-08-19 18:04:16 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:04:16 --> Helper loaded: date_helper
INFO - 2019-08-19 18:04:16 --> Form Validation Class Initialized
INFO - 2019-08-19 18:04:16 --> Email Class Initialized
DEBUG - 2019-08-19 18:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:04:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:04:16 --> Pagination Class Initialized
INFO - 2019-08-19 18:04:16 --> Database Driver Class Initialized
INFO - 2019-08-19 18:04:16 --> Database Driver Class Initialized
INFO - 2019-08-19 18:04:16 --> Controller Class Initialized
INFO - 2019-08-19 18:04:16 --> Final output sent to browser
DEBUG - 2019-08-19 18:04:16 --> Total execution time: 0.2410
INFO - 2019-08-19 18:04:51 --> Config Class Initialized
INFO - 2019-08-19 18:04:51 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:04:51 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:04:51 --> Utf8 Class Initialized
INFO - 2019-08-19 18:04:51 --> URI Class Initialized
INFO - 2019-08-19 18:04:51 --> Router Class Initialized
INFO - 2019-08-19 18:04:51 --> Output Class Initialized
INFO - 2019-08-19 18:04:51 --> Security Class Initialized
DEBUG - 2019-08-19 18:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:04:51 --> Input Class Initialized
INFO - 2019-08-19 18:04:51 --> Language Class Initialized
INFO - 2019-08-19 18:04:51 --> Loader Class Initialized
INFO - 2019-08-19 18:04:51 --> Helper loaded: url_helper
INFO - 2019-08-19 18:04:51 --> Helper loaded: html_helper
INFO - 2019-08-19 18:04:51 --> Helper loaded: form_helper
INFO - 2019-08-19 18:04:51 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:04:51 --> Helper loaded: date_helper
INFO - 2019-08-19 18:04:52 --> Form Validation Class Initialized
INFO - 2019-08-19 18:04:52 --> Email Class Initialized
DEBUG - 2019-08-19 18:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:04:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:04:52 --> Pagination Class Initialized
INFO - 2019-08-19 18:04:52 --> Database Driver Class Initialized
INFO - 2019-08-19 18:04:52 --> Database Driver Class Initialized
INFO - 2019-08-19 18:04:52 --> Controller Class Initialized
INFO - 2019-08-19 18:04:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 18:04:52 --> Config Class Initialized
INFO - 2019-08-19 18:04:52 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:04:52 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:04:52 --> Utf8 Class Initialized
INFO - 2019-08-19 18:04:52 --> URI Class Initialized
INFO - 2019-08-19 18:04:52 --> Router Class Initialized
INFO - 2019-08-19 18:04:52 --> Output Class Initialized
INFO - 2019-08-19 18:04:52 --> Security Class Initialized
DEBUG - 2019-08-19 18:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:04:52 --> Input Class Initialized
INFO - 2019-08-19 18:04:52 --> Language Class Initialized
INFO - 2019-08-19 18:04:52 --> Loader Class Initialized
INFO - 2019-08-19 18:04:52 --> Helper loaded: url_helper
INFO - 2019-08-19 18:04:52 --> Helper loaded: html_helper
INFO - 2019-08-19 18:04:52 --> Helper loaded: form_helper
INFO - 2019-08-19 18:04:52 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:04:52 --> Helper loaded: date_helper
INFO - 2019-08-19 18:04:52 --> Form Validation Class Initialized
INFO - 2019-08-19 18:04:52 --> Email Class Initialized
DEBUG - 2019-08-19 18:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:04:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:04:52 --> Pagination Class Initialized
INFO - 2019-08-19 18:04:52 --> Database Driver Class Initialized
INFO - 2019-08-19 18:04:52 --> Database Driver Class Initialized
INFO - 2019-08-19 18:04:52 --> Controller Class Initialized
INFO - 2019-08-19 18:04:52 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:04:52 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 18:04:52 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:04:52 --> Final output sent to browser
DEBUG - 2019-08-19 18:04:52 --> Total execution time: 0.2230
INFO - 2019-08-19 18:05:55 --> Config Class Initialized
INFO - 2019-08-19 18:05:55 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:05:55 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:05:55 --> Utf8 Class Initialized
INFO - 2019-08-19 18:05:55 --> Config Class Initialized
INFO - 2019-08-19 18:05:55 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:05:55 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:05:55 --> Utf8 Class Initialized
INFO - 2019-08-19 18:05:55 --> URI Class Initialized
INFO - 2019-08-19 18:05:55 --> Router Class Initialized
INFO - 2019-08-19 18:05:55 --> Output Class Initialized
INFO - 2019-08-19 18:05:55 --> Security Class Initialized
DEBUG - 2019-08-19 18:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:05:55 --> Input Class Initialized
INFO - 2019-08-19 18:05:55 --> Language Class Initialized
INFO - 2019-08-19 18:05:55 --> URI Class Initialized
INFO - 2019-08-19 18:05:55 --> Router Class Initialized
INFO - 2019-08-19 18:05:55 --> Loader Class Initialized
INFO - 2019-08-19 18:05:55 --> Output Class Initialized
INFO - 2019-08-19 18:05:55 --> Helper loaded: url_helper
INFO - 2019-08-19 18:05:55 --> Security Class Initialized
INFO - 2019-08-19 18:05:55 --> Helper loaded: html_helper
DEBUG - 2019-08-19 18:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:05:55 --> Input Class Initialized
INFO - 2019-08-19 18:05:55 --> Helper loaded: form_helper
INFO - 2019-08-19 18:05:55 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:05:55 --> Language Class Initialized
INFO - 2019-08-19 18:05:55 --> Helper loaded: date_helper
INFO - 2019-08-19 18:05:55 --> Form Validation Class Initialized
INFO - 2019-08-19 18:05:55 --> Loader Class Initialized
INFO - 2019-08-19 18:05:55 --> Email Class Initialized
INFO - 2019-08-19 18:05:55 --> Helper loaded: url_helper
INFO - 2019-08-19 18:05:55 --> Helper loaded: html_helper
DEBUG - 2019-08-19 18:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:05:55 --> Helper loaded: form_helper
INFO - 2019-08-19 18:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:05:55 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:05:55 --> Helper loaded: date_helper
INFO - 2019-08-19 18:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:05:55 --> Pagination Class Initialized
INFO - 2019-08-19 18:05:55 --> Form Validation Class Initialized
INFO - 2019-08-19 18:05:55 --> Email Class Initialized
DEBUG - 2019-08-19 18:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:05:55 --> Database Driver Class Initialized
INFO - 2019-08-19 18:05:55 --> Database Driver Class Initialized
INFO - 2019-08-19 18:05:55 --> Controller Class Initialized
INFO - 2019-08-19 18:05:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:05:56 --> Final output sent to browser
DEBUG - 2019-08-19 18:05:56 --> Total execution time: 0.3610
INFO - 2019-08-19 18:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:05:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:05:56 --> Pagination Class Initialized
INFO - 2019-08-19 18:05:56 --> Database Driver Class Initialized
INFO - 2019-08-19 18:05:56 --> Database Driver Class Initialized
INFO - 2019-08-19 18:05:56 --> Controller Class Initialized
INFO - 2019-08-19 18:05:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:05:56 --> Final output sent to browser
DEBUG - 2019-08-19 18:05:56 --> Total execution time: 0.5320
INFO - 2019-08-19 18:05:56 --> Config Class Initialized
INFO - 2019-08-19 18:05:56 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:05:56 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:05:56 --> Utf8 Class Initialized
INFO - 2019-08-19 18:05:56 --> URI Class Initialized
INFO - 2019-08-19 18:05:56 --> Router Class Initialized
INFO - 2019-08-19 18:05:56 --> Output Class Initialized
INFO - 2019-08-19 18:05:56 --> Security Class Initialized
DEBUG - 2019-08-19 18:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:05:56 --> Input Class Initialized
INFO - 2019-08-19 18:05:56 --> Language Class Initialized
INFO - 2019-08-19 18:05:56 --> Loader Class Initialized
INFO - 2019-08-19 18:05:56 --> Helper loaded: url_helper
INFO - 2019-08-19 18:05:56 --> Helper loaded: html_helper
INFO - 2019-08-19 18:05:56 --> Helper loaded: form_helper
INFO - 2019-08-19 18:05:56 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:05:56 --> Helper loaded: date_helper
INFO - 2019-08-19 18:05:56 --> Form Validation Class Initialized
INFO - 2019-08-19 18:05:56 --> Email Class Initialized
DEBUG - 2019-08-19 18:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:05:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:05:57 --> Pagination Class Initialized
INFO - 2019-08-19 18:05:57 --> Database Driver Class Initialized
INFO - 2019-08-19 18:05:57 --> Database Driver Class Initialized
INFO - 2019-08-19 18:05:57 --> Controller Class Initialized
INFO - 2019-08-19 18:05:57 --> Final output sent to browser
DEBUG - 2019-08-19 18:05:57 --> Total execution time: 0.4190
INFO - 2019-08-19 18:07:37 --> Config Class Initialized
INFO - 2019-08-19 18:07:37 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:07:37 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:07:37 --> Utf8 Class Initialized
INFO - 2019-08-19 18:07:37 --> URI Class Initialized
INFO - 2019-08-19 18:07:37 --> Router Class Initialized
INFO - 2019-08-19 18:07:37 --> Output Class Initialized
INFO - 2019-08-19 18:07:37 --> Security Class Initialized
DEBUG - 2019-08-19 18:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:07:37 --> Input Class Initialized
INFO - 2019-08-19 18:07:37 --> Language Class Initialized
INFO - 2019-08-19 18:07:37 --> Loader Class Initialized
INFO - 2019-08-19 18:07:37 --> Helper loaded: url_helper
INFO - 2019-08-19 18:07:37 --> Helper loaded: html_helper
INFO - 2019-08-19 18:07:37 --> Helper loaded: form_helper
INFO - 2019-08-19 18:07:37 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:07:37 --> Helper loaded: date_helper
INFO - 2019-08-19 18:07:37 --> Form Validation Class Initialized
INFO - 2019-08-19 18:07:37 --> Email Class Initialized
DEBUG - 2019-08-19 18:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:07:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:07:37 --> Pagination Class Initialized
INFO - 2019-08-19 18:07:37 --> Database Driver Class Initialized
INFO - 2019-08-19 18:07:37 --> Database Driver Class Initialized
INFO - 2019-08-19 18:07:37 --> Controller Class Initialized
INFO - 2019-08-19 18:07:38 --> Final output sent to browser
DEBUG - 2019-08-19 18:07:38 --> Total execution time: 0.2670
INFO - 2019-08-19 18:08:08 --> Config Class Initialized
INFO - 2019-08-19 18:08:08 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:08:08 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:08:08 --> Utf8 Class Initialized
INFO - 2019-08-19 18:08:08 --> URI Class Initialized
INFO - 2019-08-19 18:08:08 --> Router Class Initialized
INFO - 2019-08-19 18:08:08 --> Output Class Initialized
INFO - 2019-08-19 18:08:08 --> Security Class Initialized
DEBUG - 2019-08-19 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:08:08 --> Input Class Initialized
INFO - 2019-08-19 18:08:08 --> Language Class Initialized
INFO - 2019-08-19 18:08:08 --> Loader Class Initialized
INFO - 2019-08-19 18:08:08 --> Helper loaded: url_helper
INFO - 2019-08-19 18:08:08 --> Helper loaded: html_helper
INFO - 2019-08-19 18:08:08 --> Helper loaded: form_helper
INFO - 2019-08-19 18:08:08 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:08:08 --> Helper loaded: date_helper
INFO - 2019-08-19 18:08:08 --> Form Validation Class Initialized
INFO - 2019-08-19 18:08:08 --> Email Class Initialized
DEBUG - 2019-08-19 18:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:08:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:08:08 --> Pagination Class Initialized
INFO - 2019-08-19 18:08:08 --> Database Driver Class Initialized
INFO - 2019-08-19 18:08:08 --> Database Driver Class Initialized
INFO - 2019-08-19 18:08:08 --> Controller Class Initialized
INFO - 2019-08-19 18:08:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 18:08:09 --> Config Class Initialized
INFO - 2019-08-19 18:08:09 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:08:09 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:08:09 --> Utf8 Class Initialized
INFO - 2019-08-19 18:08:09 --> URI Class Initialized
INFO - 2019-08-19 18:08:09 --> Router Class Initialized
INFO - 2019-08-19 18:08:09 --> Output Class Initialized
INFO - 2019-08-19 18:08:09 --> Security Class Initialized
DEBUG - 2019-08-19 18:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:08:09 --> Input Class Initialized
INFO - 2019-08-19 18:08:09 --> Language Class Initialized
INFO - 2019-08-19 18:08:09 --> Loader Class Initialized
INFO - 2019-08-19 18:08:09 --> Helper loaded: url_helper
INFO - 2019-08-19 18:08:09 --> Helper loaded: html_helper
INFO - 2019-08-19 18:08:09 --> Helper loaded: form_helper
INFO - 2019-08-19 18:08:09 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:08:09 --> Helper loaded: date_helper
INFO - 2019-08-19 18:08:09 --> Form Validation Class Initialized
INFO - 2019-08-19 18:08:09 --> Email Class Initialized
DEBUG - 2019-08-19 18:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:08:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:08:09 --> Pagination Class Initialized
INFO - 2019-08-19 18:08:09 --> Database Driver Class Initialized
INFO - 2019-08-19 18:08:09 --> Database Driver Class Initialized
INFO - 2019-08-19 18:08:09 --> Controller Class Initialized
INFO - 2019-08-19 18:08:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:08:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 18:08:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:08:09 --> Final output sent to browser
DEBUG - 2019-08-19 18:08:09 --> Total execution time: 0.3650
INFO - 2019-08-19 18:08:51 --> Config Class Initialized
INFO - 2019-08-19 18:08:51 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:08:51 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:08:51 --> Utf8 Class Initialized
INFO - 2019-08-19 18:08:51 --> URI Class Initialized
INFO - 2019-08-19 18:08:51 --> Router Class Initialized
INFO - 2019-08-19 18:08:51 --> Output Class Initialized
INFO - 2019-08-19 18:08:51 --> Security Class Initialized
DEBUG - 2019-08-19 18:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:08:51 --> Input Class Initialized
INFO - 2019-08-19 18:08:51 --> Language Class Initialized
INFO - 2019-08-19 18:08:51 --> Loader Class Initialized
INFO - 2019-08-19 18:08:51 --> Helper loaded: url_helper
INFO - 2019-08-19 18:08:51 --> Helper loaded: html_helper
INFO - 2019-08-19 18:08:51 --> Helper loaded: form_helper
INFO - 2019-08-19 18:08:51 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:08:51 --> Helper loaded: date_helper
INFO - 2019-08-19 18:08:51 --> Form Validation Class Initialized
INFO - 2019-08-19 18:08:51 --> Email Class Initialized
DEBUG - 2019-08-19 18:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:08:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:08:51 --> Pagination Class Initialized
INFO - 2019-08-19 18:08:51 --> Database Driver Class Initialized
INFO - 2019-08-19 18:08:51 --> Database Driver Class Initialized
INFO - 2019-08-19 18:08:51 --> Config Class Initialized
INFO - 2019-08-19 18:08:51 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:08:51 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:08:51 --> Utf8 Class Initialized
INFO - 2019-08-19 18:08:51 --> URI Class Initialized
INFO - 2019-08-19 18:08:51 --> Router Class Initialized
INFO - 2019-08-19 18:08:51 --> Output Class Initialized
INFO - 2019-08-19 18:08:51 --> Security Class Initialized
DEBUG - 2019-08-19 18:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:08:51 --> Input Class Initialized
INFO - 2019-08-19 18:08:51 --> Language Class Initialized
INFO - 2019-08-19 18:08:51 --> Loader Class Initialized
INFO - 2019-08-19 18:08:51 --> Helper loaded: url_helper
INFO - 2019-08-19 18:08:51 --> Helper loaded: html_helper
INFO - 2019-08-19 18:08:51 --> Helper loaded: form_helper
INFO - 2019-08-19 18:08:51 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:08:51 --> Helper loaded: date_helper
INFO - 2019-08-19 18:08:51 --> Form Validation Class Initialized
INFO - 2019-08-19 18:08:51 --> Email Class Initialized
DEBUG - 2019-08-19 18:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:08:51 --> Controller Class Initialized
INFO - 2019-08-19 18:08:51 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:08:51 --> Final output sent to browser
DEBUG - 2019-08-19 18:08:51 --> Total execution time: 0.3290
INFO - 2019-08-19 18:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:08:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:08:51 --> Pagination Class Initialized
INFO - 2019-08-19 18:08:52 --> Database Driver Class Initialized
INFO - 2019-08-19 18:08:52 --> Database Driver Class Initialized
INFO - 2019-08-19 18:08:52 --> Controller Class Initialized
INFO - 2019-08-19 18:08:52 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:08:52 --> Final output sent to browser
DEBUG - 2019-08-19 18:08:52 --> Total execution time: 0.2740
INFO - 2019-08-19 18:08:52 --> Config Class Initialized
INFO - 2019-08-19 18:08:52 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:08:52 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:08:52 --> Utf8 Class Initialized
INFO - 2019-08-19 18:08:52 --> URI Class Initialized
INFO - 2019-08-19 18:08:52 --> Router Class Initialized
INFO - 2019-08-19 18:08:52 --> Output Class Initialized
INFO - 2019-08-19 18:08:52 --> Security Class Initialized
DEBUG - 2019-08-19 18:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:08:52 --> Input Class Initialized
INFO - 2019-08-19 18:08:52 --> Language Class Initialized
INFO - 2019-08-19 18:08:52 --> Loader Class Initialized
INFO - 2019-08-19 18:08:52 --> Helper loaded: url_helper
INFO - 2019-08-19 18:08:52 --> Helper loaded: html_helper
INFO - 2019-08-19 18:08:52 --> Helper loaded: form_helper
INFO - 2019-08-19 18:08:52 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:08:52 --> Helper loaded: date_helper
INFO - 2019-08-19 18:08:52 --> Form Validation Class Initialized
INFO - 2019-08-19 18:08:52 --> Email Class Initialized
DEBUG - 2019-08-19 18:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:08:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:08:52 --> Pagination Class Initialized
INFO - 2019-08-19 18:08:52 --> Database Driver Class Initialized
INFO - 2019-08-19 18:08:52 --> Database Driver Class Initialized
INFO - 2019-08-19 18:08:52 --> Controller Class Initialized
INFO - 2019-08-19 18:08:52 --> Final output sent to browser
DEBUG - 2019-08-19 18:08:52 --> Total execution time: 0.2960
INFO - 2019-08-19 18:09:01 --> Config Class Initialized
INFO - 2019-08-19 18:09:01 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:09:01 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:09:01 --> Utf8 Class Initialized
INFO - 2019-08-19 18:09:01 --> URI Class Initialized
INFO - 2019-08-19 18:09:01 --> Router Class Initialized
INFO - 2019-08-19 18:09:01 --> Output Class Initialized
INFO - 2019-08-19 18:09:01 --> Security Class Initialized
DEBUG - 2019-08-19 18:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:09:01 --> Input Class Initialized
INFO - 2019-08-19 18:09:01 --> Language Class Initialized
INFO - 2019-08-19 18:09:01 --> Loader Class Initialized
INFO - 2019-08-19 18:09:01 --> Helper loaded: url_helper
INFO - 2019-08-19 18:09:01 --> Helper loaded: html_helper
INFO - 2019-08-19 18:09:01 --> Helper loaded: form_helper
INFO - 2019-08-19 18:09:01 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:09:01 --> Helper loaded: date_helper
INFO - 2019-08-19 18:09:01 --> Form Validation Class Initialized
INFO - 2019-08-19 18:09:01 --> Email Class Initialized
DEBUG - 2019-08-19 18:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:09:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:09:01 --> Pagination Class Initialized
INFO - 2019-08-19 18:09:01 --> Database Driver Class Initialized
INFO - 2019-08-19 18:09:01 --> Database Driver Class Initialized
INFO - 2019-08-19 18:09:01 --> Controller Class Initialized
INFO - 2019-08-19 18:09:01 --> Final output sent to browser
DEBUG - 2019-08-19 18:09:01 --> Total execution time: 0.3070
INFO - 2019-08-19 18:09:34 --> Config Class Initialized
INFO - 2019-08-19 18:09:34 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:09:34 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:09:34 --> Utf8 Class Initialized
INFO - 2019-08-19 18:09:34 --> URI Class Initialized
INFO - 2019-08-19 18:09:34 --> Router Class Initialized
INFO - 2019-08-19 18:09:34 --> Output Class Initialized
INFO - 2019-08-19 18:09:34 --> Security Class Initialized
DEBUG - 2019-08-19 18:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:09:34 --> Input Class Initialized
INFO - 2019-08-19 18:09:34 --> Language Class Initialized
INFO - 2019-08-19 18:09:34 --> Loader Class Initialized
INFO - 2019-08-19 18:09:34 --> Helper loaded: url_helper
INFO - 2019-08-19 18:09:34 --> Helper loaded: html_helper
INFO - 2019-08-19 18:09:34 --> Helper loaded: form_helper
INFO - 2019-08-19 18:09:34 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:09:34 --> Helper loaded: date_helper
INFO - 2019-08-19 18:09:34 --> Form Validation Class Initialized
INFO - 2019-08-19 18:09:34 --> Email Class Initialized
DEBUG - 2019-08-19 18:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:09:34 --> Pagination Class Initialized
INFO - 2019-08-19 18:09:34 --> Database Driver Class Initialized
INFO - 2019-08-19 18:09:34 --> Database Driver Class Initialized
INFO - 2019-08-19 18:09:34 --> Controller Class Initialized
INFO - 2019-08-19 18:09:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 18:09:34 --> Config Class Initialized
INFO - 2019-08-19 18:09:34 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:09:34 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:09:34 --> Utf8 Class Initialized
INFO - 2019-08-19 18:09:34 --> URI Class Initialized
INFO - 2019-08-19 18:09:34 --> Router Class Initialized
INFO - 2019-08-19 18:09:34 --> Output Class Initialized
INFO - 2019-08-19 18:09:34 --> Security Class Initialized
DEBUG - 2019-08-19 18:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:09:34 --> Input Class Initialized
INFO - 2019-08-19 18:09:34 --> Language Class Initialized
INFO - 2019-08-19 18:09:34 --> Loader Class Initialized
INFO - 2019-08-19 18:09:35 --> Helper loaded: url_helper
INFO - 2019-08-19 18:09:35 --> Helper loaded: html_helper
INFO - 2019-08-19 18:09:35 --> Helper loaded: form_helper
INFO - 2019-08-19 18:09:35 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:09:35 --> Helper loaded: date_helper
INFO - 2019-08-19 18:09:35 --> Form Validation Class Initialized
INFO - 2019-08-19 18:09:35 --> Email Class Initialized
DEBUG - 2019-08-19 18:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:09:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:09:35 --> Pagination Class Initialized
INFO - 2019-08-19 18:09:35 --> Database Driver Class Initialized
INFO - 2019-08-19 18:09:35 --> Database Driver Class Initialized
INFO - 2019-08-19 18:09:35 --> Controller Class Initialized
INFO - 2019-08-19 18:09:35 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:09:35 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 18:09:35 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:09:35 --> Final output sent to browser
DEBUG - 2019-08-19 18:09:35 --> Total execution time: 0.3140
INFO - 2019-08-19 18:10:17 --> Config Class Initialized
INFO - 2019-08-19 18:10:17 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:10:17 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:10:17 --> Utf8 Class Initialized
INFO - 2019-08-19 18:10:17 --> Config Class Initialized
INFO - 2019-08-19 18:10:17 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:10:17 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:10:17 --> Utf8 Class Initialized
INFO - 2019-08-19 18:10:17 --> URI Class Initialized
INFO - 2019-08-19 18:10:17 --> Router Class Initialized
INFO - 2019-08-19 18:10:17 --> Output Class Initialized
INFO - 2019-08-19 18:10:17 --> Security Class Initialized
DEBUG - 2019-08-19 18:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:10:17 --> Input Class Initialized
INFO - 2019-08-19 18:10:17 --> Language Class Initialized
INFO - 2019-08-19 18:10:17 --> URI Class Initialized
INFO - 2019-08-19 18:10:17 --> Router Class Initialized
INFO - 2019-08-19 18:10:17 --> Output Class Initialized
INFO - 2019-08-19 18:10:17 --> Security Class Initialized
DEBUG - 2019-08-19 18:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:10:17 --> Input Class Initialized
INFO - 2019-08-19 18:10:17 --> Language Class Initialized
INFO - 2019-08-19 18:10:17 --> Loader Class Initialized
INFO - 2019-08-19 18:10:17 --> Helper loaded: url_helper
INFO - 2019-08-19 18:10:17 --> Helper loaded: html_helper
INFO - 2019-08-19 18:10:17 --> Helper loaded: form_helper
INFO - 2019-08-19 18:10:17 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:10:17 --> Helper loaded: date_helper
INFO - 2019-08-19 18:10:17 --> Form Validation Class Initialized
INFO - 2019-08-19 18:10:17 --> Loader Class Initialized
INFO - 2019-08-19 18:10:17 --> Helper loaded: url_helper
INFO - 2019-08-19 18:10:17 --> Helper loaded: html_helper
INFO - 2019-08-19 18:10:17 --> Helper loaded: form_helper
INFO - 2019-08-19 18:10:17 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:10:17 --> Helper loaded: date_helper
INFO - 2019-08-19 18:10:17 --> Email Class Initialized
DEBUG - 2019-08-19 18:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:10:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:10:17 --> Pagination Class Initialized
INFO - 2019-08-19 18:10:17 --> Form Validation Class Initialized
INFO - 2019-08-19 18:10:17 --> Email Class Initialized
DEBUG - 2019-08-19 18:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:10:17 --> Database Driver Class Initialized
INFO - 2019-08-19 18:10:17 --> Database Driver Class Initialized
INFO - 2019-08-19 18:10:18 --> Controller Class Initialized
INFO - 2019-08-19 18:10:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:10:18 --> Final output sent to browser
DEBUG - 2019-08-19 18:10:18 --> Total execution time: 0.9221
INFO - 2019-08-19 18:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:10:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:10:18 --> Pagination Class Initialized
INFO - 2019-08-19 18:10:18 --> Database Driver Class Initialized
INFO - 2019-08-19 18:10:18 --> Database Driver Class Initialized
INFO - 2019-08-19 18:10:18 --> Controller Class Initialized
INFO - 2019-08-19 18:10:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:10:18 --> Final output sent to browser
DEBUG - 2019-08-19 18:10:18 --> Total execution time: 1.0251
INFO - 2019-08-19 18:10:18 --> Config Class Initialized
INFO - 2019-08-19 18:10:18 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:10:18 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:10:18 --> Utf8 Class Initialized
INFO - 2019-08-19 18:10:18 --> URI Class Initialized
INFO - 2019-08-19 18:10:18 --> Router Class Initialized
INFO - 2019-08-19 18:10:18 --> Output Class Initialized
INFO - 2019-08-19 18:10:18 --> Security Class Initialized
DEBUG - 2019-08-19 18:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:10:18 --> Input Class Initialized
INFO - 2019-08-19 18:10:18 --> Language Class Initialized
INFO - 2019-08-19 18:10:18 --> Loader Class Initialized
INFO - 2019-08-19 18:10:18 --> Helper loaded: url_helper
INFO - 2019-08-19 18:10:18 --> Helper loaded: html_helper
INFO - 2019-08-19 18:10:18 --> Helper loaded: form_helper
INFO - 2019-08-19 18:10:18 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:10:18 --> Helper loaded: date_helper
INFO - 2019-08-19 18:10:18 --> Form Validation Class Initialized
INFO - 2019-08-19 18:10:18 --> Email Class Initialized
DEBUG - 2019-08-19 18:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:10:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:10:18 --> Pagination Class Initialized
INFO - 2019-08-19 18:10:18 --> Database Driver Class Initialized
INFO - 2019-08-19 18:10:18 --> Database Driver Class Initialized
INFO - 2019-08-19 18:10:18 --> Controller Class Initialized
INFO - 2019-08-19 18:10:18 --> Final output sent to browser
DEBUG - 2019-08-19 18:10:18 --> Total execution time: 0.2450
INFO - 2019-08-19 18:10:37 --> Config Class Initialized
INFO - 2019-08-19 18:10:37 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:10:37 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:10:37 --> Utf8 Class Initialized
INFO - 2019-08-19 18:10:37 --> URI Class Initialized
INFO - 2019-08-19 18:10:37 --> Router Class Initialized
INFO - 2019-08-19 18:10:37 --> Output Class Initialized
INFO - 2019-08-19 18:10:37 --> Security Class Initialized
DEBUG - 2019-08-19 18:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:10:37 --> Input Class Initialized
INFO - 2019-08-19 18:10:37 --> Language Class Initialized
INFO - 2019-08-19 18:10:37 --> Loader Class Initialized
INFO - 2019-08-19 18:10:37 --> Helper loaded: url_helper
INFO - 2019-08-19 18:10:37 --> Helper loaded: html_helper
INFO - 2019-08-19 18:10:37 --> Helper loaded: form_helper
INFO - 2019-08-19 18:10:37 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:10:37 --> Helper loaded: date_helper
INFO - 2019-08-19 18:10:37 --> Form Validation Class Initialized
INFO - 2019-08-19 18:10:37 --> Email Class Initialized
DEBUG - 2019-08-19 18:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:10:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:10:37 --> Pagination Class Initialized
INFO - 2019-08-19 18:10:37 --> Database Driver Class Initialized
INFO - 2019-08-19 18:10:37 --> Database Driver Class Initialized
INFO - 2019-08-19 18:10:37 --> Controller Class Initialized
INFO - 2019-08-19 18:10:38 --> Final output sent to browser
DEBUG - 2019-08-19 18:10:38 --> Total execution time: 0.2468
INFO - 2019-08-19 18:11:08 --> Config Class Initialized
INFO - 2019-08-19 18:11:08 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:11:08 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:11:08 --> Utf8 Class Initialized
INFO - 2019-08-19 18:11:08 --> URI Class Initialized
INFO - 2019-08-19 18:11:08 --> Router Class Initialized
INFO - 2019-08-19 18:11:08 --> Output Class Initialized
INFO - 2019-08-19 18:11:08 --> Security Class Initialized
DEBUG - 2019-08-19 18:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:11:08 --> Input Class Initialized
INFO - 2019-08-19 18:11:08 --> Language Class Initialized
INFO - 2019-08-19 18:11:08 --> Loader Class Initialized
INFO - 2019-08-19 18:11:08 --> Helper loaded: url_helper
INFO - 2019-08-19 18:11:08 --> Helper loaded: html_helper
INFO - 2019-08-19 18:11:08 --> Helper loaded: form_helper
INFO - 2019-08-19 18:11:08 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:11:08 --> Helper loaded: date_helper
INFO - 2019-08-19 18:11:08 --> Form Validation Class Initialized
INFO - 2019-08-19 18:11:08 --> Email Class Initialized
DEBUG - 2019-08-19 18:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:11:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:11:08 --> Pagination Class Initialized
INFO - 2019-08-19 18:11:08 --> Database Driver Class Initialized
INFO - 2019-08-19 18:11:08 --> Database Driver Class Initialized
INFO - 2019-08-19 18:11:08 --> Controller Class Initialized
INFO - 2019-08-19 18:11:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 18:11:08 --> Config Class Initialized
INFO - 2019-08-19 18:11:08 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:11:08 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:11:08 --> Utf8 Class Initialized
INFO - 2019-08-19 18:11:08 --> URI Class Initialized
INFO - 2019-08-19 18:11:08 --> Router Class Initialized
INFO - 2019-08-19 18:11:09 --> Output Class Initialized
INFO - 2019-08-19 18:11:09 --> Security Class Initialized
DEBUG - 2019-08-19 18:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:11:09 --> Input Class Initialized
INFO - 2019-08-19 18:11:09 --> Language Class Initialized
INFO - 2019-08-19 18:11:09 --> Loader Class Initialized
INFO - 2019-08-19 18:11:09 --> Helper loaded: url_helper
INFO - 2019-08-19 18:11:09 --> Helper loaded: html_helper
INFO - 2019-08-19 18:11:09 --> Helper loaded: form_helper
INFO - 2019-08-19 18:11:09 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:11:09 --> Helper loaded: date_helper
INFO - 2019-08-19 18:11:09 --> Form Validation Class Initialized
INFO - 2019-08-19 18:11:09 --> Email Class Initialized
DEBUG - 2019-08-19 18:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:11:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:11:09 --> Pagination Class Initialized
INFO - 2019-08-19 18:11:09 --> Database Driver Class Initialized
INFO - 2019-08-19 18:11:09 --> Database Driver Class Initialized
INFO - 2019-08-19 18:11:09 --> Controller Class Initialized
INFO - 2019-08-19 18:11:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:11:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 18:11:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:11:09 --> Final output sent to browser
DEBUG - 2019-08-19 18:11:09 --> Total execution time: 0.2240
INFO - 2019-08-19 18:12:12 --> Config Class Initialized
INFO - 2019-08-19 18:12:12 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:12:12 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:12:12 --> Utf8 Class Initialized
INFO - 2019-08-19 18:12:12 --> URI Class Initialized
INFO - 2019-08-19 18:12:12 --> Router Class Initialized
INFO - 2019-08-19 18:12:12 --> Output Class Initialized
INFO - 2019-08-19 18:12:12 --> Security Class Initialized
DEBUG - 2019-08-19 18:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:12:12 --> Input Class Initialized
INFO - 2019-08-19 18:12:12 --> Language Class Initialized
INFO - 2019-08-19 18:12:12 --> Config Class Initialized
INFO - 2019-08-19 18:12:12 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:12:12 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:12:12 --> Utf8 Class Initialized
INFO - 2019-08-19 18:12:12 --> URI Class Initialized
INFO - 2019-08-19 18:12:12 --> Router Class Initialized
INFO - 2019-08-19 18:12:12 --> Output Class Initialized
INFO - 2019-08-19 18:12:12 --> Security Class Initialized
DEBUG - 2019-08-19 18:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:12:12 --> Input Class Initialized
INFO - 2019-08-19 18:12:12 --> Language Class Initialized
INFO - 2019-08-19 18:12:12 --> Loader Class Initialized
INFO - 2019-08-19 18:12:12 --> Helper loaded: url_helper
INFO - 2019-08-19 18:12:12 --> Helper loaded: html_helper
INFO - 2019-08-19 18:12:12 --> Helper loaded: form_helper
INFO - 2019-08-19 18:12:12 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:12:12 --> Helper loaded: date_helper
INFO - 2019-08-19 18:12:12 --> Form Validation Class Initialized
INFO - 2019-08-19 18:12:12 --> Loader Class Initialized
INFO - 2019-08-19 18:12:12 --> Helper loaded: url_helper
INFO - 2019-08-19 18:12:12 --> Helper loaded: html_helper
INFO - 2019-08-19 18:12:12 --> Helper loaded: form_helper
INFO - 2019-08-19 18:12:12 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:12:12 --> Helper loaded: date_helper
INFO - 2019-08-19 18:12:12 --> Email Class Initialized
DEBUG - 2019-08-19 18:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:12:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:12:12 --> Pagination Class Initialized
INFO - 2019-08-19 18:12:12 --> Form Validation Class Initialized
INFO - 2019-08-19 18:12:12 --> Email Class Initialized
DEBUG - 2019-08-19 18:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:12:12 --> Database Driver Class Initialized
INFO - 2019-08-19 18:12:12 --> Database Driver Class Initialized
INFO - 2019-08-19 18:12:12 --> Controller Class Initialized
INFO - 2019-08-19 18:12:12 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:12:12 --> Final output sent to browser
DEBUG - 2019-08-19 18:12:12 --> Total execution time: 0.4330
INFO - 2019-08-19 18:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:12:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:12:12 --> Pagination Class Initialized
INFO - 2019-08-19 18:12:12 --> Database Driver Class Initialized
INFO - 2019-08-19 18:12:12 --> Database Driver Class Initialized
INFO - 2019-08-19 18:12:12 --> Controller Class Initialized
INFO - 2019-08-19 18:12:12 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:12:12 --> Final output sent to browser
DEBUG - 2019-08-19 18:12:12 --> Total execution time: 0.4740
INFO - 2019-08-19 18:12:13 --> Config Class Initialized
INFO - 2019-08-19 18:12:13 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:12:13 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:12:13 --> Utf8 Class Initialized
INFO - 2019-08-19 18:12:13 --> URI Class Initialized
INFO - 2019-08-19 18:12:13 --> Router Class Initialized
INFO - 2019-08-19 18:12:13 --> Output Class Initialized
INFO - 2019-08-19 18:12:13 --> Security Class Initialized
DEBUG - 2019-08-19 18:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:12:13 --> Input Class Initialized
INFO - 2019-08-19 18:12:13 --> Language Class Initialized
INFO - 2019-08-19 18:12:13 --> Loader Class Initialized
INFO - 2019-08-19 18:12:13 --> Helper loaded: url_helper
INFO - 2019-08-19 18:12:13 --> Helper loaded: html_helper
INFO - 2019-08-19 18:12:13 --> Helper loaded: form_helper
INFO - 2019-08-19 18:12:13 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:12:13 --> Helper loaded: date_helper
INFO - 2019-08-19 18:12:13 --> Form Validation Class Initialized
INFO - 2019-08-19 18:12:13 --> Email Class Initialized
DEBUG - 2019-08-19 18:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:12:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:12:13 --> Pagination Class Initialized
INFO - 2019-08-19 18:12:13 --> Database Driver Class Initialized
INFO - 2019-08-19 18:12:13 --> Database Driver Class Initialized
INFO - 2019-08-19 18:12:13 --> Controller Class Initialized
INFO - 2019-08-19 18:12:13 --> Final output sent to browser
DEBUG - 2019-08-19 18:12:13 --> Total execution time: 0.3760
INFO - 2019-08-19 18:12:28 --> Config Class Initialized
INFO - 2019-08-19 18:12:28 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:12:28 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:12:28 --> Utf8 Class Initialized
INFO - 2019-08-19 18:12:28 --> URI Class Initialized
INFO - 2019-08-19 18:12:28 --> Router Class Initialized
INFO - 2019-08-19 18:12:28 --> Output Class Initialized
INFO - 2019-08-19 18:12:29 --> Security Class Initialized
DEBUG - 2019-08-19 18:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:12:29 --> Input Class Initialized
INFO - 2019-08-19 18:12:29 --> Language Class Initialized
INFO - 2019-08-19 18:12:29 --> Loader Class Initialized
INFO - 2019-08-19 18:12:29 --> Helper loaded: url_helper
INFO - 2019-08-19 18:12:29 --> Helper loaded: html_helper
INFO - 2019-08-19 18:12:29 --> Helper loaded: form_helper
INFO - 2019-08-19 18:12:29 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:12:29 --> Helper loaded: date_helper
INFO - 2019-08-19 18:12:29 --> Form Validation Class Initialized
INFO - 2019-08-19 18:12:29 --> Email Class Initialized
DEBUG - 2019-08-19 18:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:12:29 --> Pagination Class Initialized
INFO - 2019-08-19 18:12:29 --> Database Driver Class Initialized
INFO - 2019-08-19 18:12:29 --> Database Driver Class Initialized
INFO - 2019-08-19 18:12:29 --> Controller Class Initialized
INFO - 2019-08-19 18:12:29 --> Final output sent to browser
DEBUG - 2019-08-19 18:12:29 --> Total execution time: 0.2400
INFO - 2019-08-19 18:12:55 --> Config Class Initialized
INFO - 2019-08-19 18:12:55 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:12:55 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:12:55 --> Utf8 Class Initialized
INFO - 2019-08-19 18:12:55 --> URI Class Initialized
INFO - 2019-08-19 18:12:55 --> Router Class Initialized
INFO - 2019-08-19 18:12:55 --> Output Class Initialized
INFO - 2019-08-19 18:12:56 --> Security Class Initialized
DEBUG - 2019-08-19 18:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:12:56 --> Input Class Initialized
INFO - 2019-08-19 18:12:56 --> Language Class Initialized
INFO - 2019-08-19 18:12:56 --> Loader Class Initialized
INFO - 2019-08-19 18:12:56 --> Helper loaded: url_helper
INFO - 2019-08-19 18:12:56 --> Helper loaded: html_helper
INFO - 2019-08-19 18:12:56 --> Helper loaded: form_helper
INFO - 2019-08-19 18:12:56 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:12:56 --> Helper loaded: date_helper
INFO - 2019-08-19 18:12:56 --> Form Validation Class Initialized
INFO - 2019-08-19 18:12:56 --> Email Class Initialized
DEBUG - 2019-08-19 18:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:12:56 --> Pagination Class Initialized
INFO - 2019-08-19 18:12:56 --> Database Driver Class Initialized
INFO - 2019-08-19 18:12:56 --> Database Driver Class Initialized
INFO - 2019-08-19 18:12:56 --> Controller Class Initialized
INFO - 2019-08-19 18:12:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 18:12:56 --> Config Class Initialized
INFO - 2019-08-19 18:12:56 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:12:56 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:12:56 --> Utf8 Class Initialized
INFO - 2019-08-19 18:12:56 --> URI Class Initialized
INFO - 2019-08-19 18:12:56 --> Router Class Initialized
INFO - 2019-08-19 18:12:56 --> Output Class Initialized
INFO - 2019-08-19 18:12:56 --> Security Class Initialized
DEBUG - 2019-08-19 18:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:12:56 --> Input Class Initialized
INFO - 2019-08-19 18:12:56 --> Language Class Initialized
INFO - 2019-08-19 18:12:56 --> Loader Class Initialized
INFO - 2019-08-19 18:12:56 --> Helper loaded: url_helper
INFO - 2019-08-19 18:12:56 --> Helper loaded: html_helper
INFO - 2019-08-19 18:12:56 --> Helper loaded: form_helper
INFO - 2019-08-19 18:12:56 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:12:56 --> Helper loaded: date_helper
INFO - 2019-08-19 18:12:56 --> Form Validation Class Initialized
INFO - 2019-08-19 18:12:56 --> Email Class Initialized
DEBUG - 2019-08-19 18:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:12:56 --> Pagination Class Initialized
INFO - 2019-08-19 18:12:57 --> Database Driver Class Initialized
INFO - 2019-08-19 18:12:57 --> Database Driver Class Initialized
INFO - 2019-08-19 18:12:57 --> Controller Class Initialized
INFO - 2019-08-19 18:12:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:12:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 18:12:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:12:57 --> Final output sent to browser
DEBUG - 2019-08-19 18:12:57 --> Total execution time: 0.5780
INFO - 2019-08-19 18:13:39 --> Config Class Initialized
INFO - 2019-08-19 18:13:39 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:13:39 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:13:39 --> Utf8 Class Initialized
INFO - 2019-08-19 18:13:39 --> URI Class Initialized
INFO - 2019-08-19 18:13:39 --> Router Class Initialized
INFO - 2019-08-19 18:13:39 --> Output Class Initialized
INFO - 2019-08-19 18:13:39 --> Security Class Initialized
DEBUG - 2019-08-19 18:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:13:39 --> Input Class Initialized
INFO - 2019-08-19 18:13:39 --> Language Class Initialized
INFO - 2019-08-19 18:13:39 --> Config Class Initialized
INFO - 2019-08-19 18:13:39 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:13:39 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:13:39 --> Utf8 Class Initialized
INFO - 2019-08-19 18:13:39 --> URI Class Initialized
INFO - 2019-08-19 18:13:39 --> Loader Class Initialized
INFO - 2019-08-19 18:13:39 --> Helper loaded: url_helper
INFO - 2019-08-19 18:13:39 --> Helper loaded: html_helper
INFO - 2019-08-19 18:13:39 --> Helper loaded: form_helper
INFO - 2019-08-19 18:13:39 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:13:39 --> Helper loaded: date_helper
INFO - 2019-08-19 18:13:39 --> Form Validation Class Initialized
INFO - 2019-08-19 18:13:39 --> Email Class Initialized
DEBUG - 2019-08-19 18:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:13:39 --> Pagination Class Initialized
INFO - 2019-08-19 18:13:39 --> Router Class Initialized
INFO - 2019-08-19 18:13:39 --> Output Class Initialized
INFO - 2019-08-19 18:13:39 --> Security Class Initialized
DEBUG - 2019-08-19 18:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:13:39 --> Input Class Initialized
INFO - 2019-08-19 18:13:39 --> Language Class Initialized
INFO - 2019-08-19 18:13:39 --> Loader Class Initialized
INFO - 2019-08-19 18:13:39 --> Helper loaded: url_helper
INFO - 2019-08-19 18:13:39 --> Helper loaded: html_helper
INFO - 2019-08-19 18:13:39 --> Helper loaded: form_helper
INFO - 2019-08-19 18:13:39 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:13:39 --> Helper loaded: date_helper
INFO - 2019-08-19 18:13:39 --> Database Driver Class Initialized
INFO - 2019-08-19 18:13:39 --> Database Driver Class Initialized
INFO - 2019-08-19 18:13:40 --> Form Validation Class Initialized
INFO - 2019-08-19 18:13:40 --> Email Class Initialized
DEBUG - 2019-08-19 18:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:13:40 --> Controller Class Initialized
INFO - 2019-08-19 18:13:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:13:40 --> Final output sent to browser
DEBUG - 2019-08-19 18:13:40 --> Total execution time: 0.4910
INFO - 2019-08-19 18:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:13:40 --> Pagination Class Initialized
INFO - 2019-08-19 18:13:40 --> Database Driver Class Initialized
INFO - 2019-08-19 18:13:40 --> Database Driver Class Initialized
INFO - 2019-08-19 18:13:40 --> Controller Class Initialized
INFO - 2019-08-19 18:13:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:13:40 --> Final output sent to browser
DEBUG - 2019-08-19 18:13:40 --> Total execution time: 0.5550
INFO - 2019-08-19 18:13:42 --> Config Class Initialized
INFO - 2019-08-19 18:13:42 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:13:42 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:13:42 --> Utf8 Class Initialized
INFO - 2019-08-19 18:13:42 --> URI Class Initialized
INFO - 2019-08-19 18:13:42 --> Router Class Initialized
INFO - 2019-08-19 18:13:42 --> Output Class Initialized
INFO - 2019-08-19 18:13:42 --> Security Class Initialized
DEBUG - 2019-08-19 18:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:13:42 --> Input Class Initialized
INFO - 2019-08-19 18:13:42 --> Language Class Initialized
INFO - 2019-08-19 18:13:42 --> Loader Class Initialized
INFO - 2019-08-19 18:13:42 --> Helper loaded: url_helper
INFO - 2019-08-19 18:13:42 --> Helper loaded: html_helper
INFO - 2019-08-19 18:13:42 --> Helper loaded: form_helper
INFO - 2019-08-19 18:13:42 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:13:42 --> Helper loaded: date_helper
INFO - 2019-08-19 18:13:42 --> Form Validation Class Initialized
INFO - 2019-08-19 18:13:42 --> Email Class Initialized
DEBUG - 2019-08-19 18:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:13:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:13:42 --> Pagination Class Initialized
INFO - 2019-08-19 18:13:42 --> Database Driver Class Initialized
INFO - 2019-08-19 18:13:42 --> Database Driver Class Initialized
INFO - 2019-08-19 18:13:42 --> Controller Class Initialized
INFO - 2019-08-19 18:13:42 --> Final output sent to browser
DEBUG - 2019-08-19 18:13:42 --> Total execution time: 0.4290
INFO - 2019-08-19 18:15:45 --> Config Class Initialized
INFO - 2019-08-19 18:15:45 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:15:45 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:15:45 --> Utf8 Class Initialized
INFO - 2019-08-19 18:15:45 --> URI Class Initialized
INFO - 2019-08-19 18:15:45 --> Router Class Initialized
INFO - 2019-08-19 18:15:45 --> Output Class Initialized
INFO - 2019-08-19 18:15:45 --> Security Class Initialized
DEBUG - 2019-08-19 18:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:15:45 --> Input Class Initialized
INFO - 2019-08-19 18:15:45 --> Language Class Initialized
INFO - 2019-08-19 18:15:45 --> Loader Class Initialized
INFO - 2019-08-19 18:15:45 --> Helper loaded: url_helper
INFO - 2019-08-19 18:15:45 --> Helper loaded: html_helper
INFO - 2019-08-19 18:15:45 --> Helper loaded: form_helper
INFO - 2019-08-19 18:15:45 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:15:45 --> Helper loaded: date_helper
INFO - 2019-08-19 18:15:45 --> Form Validation Class Initialized
INFO - 2019-08-19 18:15:45 --> Email Class Initialized
DEBUG - 2019-08-19 18:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:15:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:15:45 --> Pagination Class Initialized
INFO - 2019-08-19 18:15:45 --> Database Driver Class Initialized
INFO - 2019-08-19 18:15:45 --> Database Driver Class Initialized
INFO - 2019-08-19 18:15:45 --> Controller Class Initialized
INFO - 2019-08-19 18:15:45 --> Final output sent to browser
DEBUG - 2019-08-19 18:15:45 --> Total execution time: 0.2810
INFO - 2019-08-19 18:16:06 --> Config Class Initialized
INFO - 2019-08-19 18:16:06 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:16:06 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:16:06 --> Utf8 Class Initialized
INFO - 2019-08-19 18:16:06 --> URI Class Initialized
INFO - 2019-08-19 18:16:06 --> Router Class Initialized
INFO - 2019-08-19 18:16:06 --> Output Class Initialized
INFO - 2019-08-19 18:16:06 --> Security Class Initialized
DEBUG - 2019-08-19 18:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:16:06 --> Input Class Initialized
INFO - 2019-08-19 18:16:06 --> Language Class Initialized
INFO - 2019-08-19 18:16:06 --> Loader Class Initialized
INFO - 2019-08-19 18:16:06 --> Helper loaded: url_helper
INFO - 2019-08-19 18:16:06 --> Helper loaded: html_helper
INFO - 2019-08-19 18:16:06 --> Helper loaded: form_helper
INFO - 2019-08-19 18:16:06 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:16:06 --> Helper loaded: date_helper
INFO - 2019-08-19 18:16:06 --> Form Validation Class Initialized
INFO - 2019-08-19 18:16:06 --> Email Class Initialized
DEBUG - 2019-08-19 18:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:16:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:16:06 --> Pagination Class Initialized
INFO - 2019-08-19 18:16:06 --> Database Driver Class Initialized
INFO - 2019-08-19 18:16:06 --> Database Driver Class Initialized
INFO - 2019-08-19 18:16:06 --> Controller Class Initialized
INFO - 2019-08-19 18:16:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 18:16:06 --> Config Class Initialized
INFO - 2019-08-19 18:16:06 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:16:06 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:16:06 --> Utf8 Class Initialized
INFO - 2019-08-19 18:16:06 --> URI Class Initialized
INFO - 2019-08-19 18:16:06 --> Router Class Initialized
INFO - 2019-08-19 18:16:06 --> Output Class Initialized
INFO - 2019-08-19 18:16:06 --> Security Class Initialized
DEBUG - 2019-08-19 18:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:16:06 --> Input Class Initialized
INFO - 2019-08-19 18:16:06 --> Language Class Initialized
INFO - 2019-08-19 18:16:06 --> Loader Class Initialized
INFO - 2019-08-19 18:16:06 --> Helper loaded: url_helper
INFO - 2019-08-19 18:16:06 --> Helper loaded: html_helper
INFO - 2019-08-19 18:16:06 --> Helper loaded: form_helper
INFO - 2019-08-19 18:16:06 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:16:06 --> Helper loaded: date_helper
INFO - 2019-08-19 18:16:06 --> Form Validation Class Initialized
INFO - 2019-08-19 18:16:06 --> Email Class Initialized
DEBUG - 2019-08-19 18:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:16:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:16:06 --> Pagination Class Initialized
INFO - 2019-08-19 18:16:06 --> Database Driver Class Initialized
INFO - 2019-08-19 18:16:06 --> Database Driver Class Initialized
INFO - 2019-08-19 18:16:06 --> Controller Class Initialized
INFO - 2019-08-19 18:16:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:16:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 18:16:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:16:06 --> Final output sent to browser
DEBUG - 2019-08-19 18:16:06 --> Total execution time: 0.2210
INFO - 2019-08-19 18:16:48 --> Config Class Initialized
INFO - 2019-08-19 18:16:48 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:16:48 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:16:48 --> Utf8 Class Initialized
INFO - 2019-08-19 18:16:48 --> Config Class Initialized
INFO - 2019-08-19 18:16:48 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:16:48 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:16:48 --> Utf8 Class Initialized
INFO - 2019-08-19 18:16:48 --> URI Class Initialized
INFO - 2019-08-19 18:16:48 --> Router Class Initialized
INFO - 2019-08-19 18:16:48 --> Output Class Initialized
INFO - 2019-08-19 18:16:48 --> Security Class Initialized
DEBUG - 2019-08-19 18:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:16:48 --> Input Class Initialized
INFO - 2019-08-19 18:16:48 --> Language Class Initialized
INFO - 2019-08-19 18:16:48 --> Loader Class Initialized
INFO - 2019-08-19 18:16:48 --> Helper loaded: url_helper
INFO - 2019-08-19 18:16:48 --> Helper loaded: html_helper
INFO - 2019-08-19 18:16:48 --> Helper loaded: form_helper
INFO - 2019-08-19 18:16:48 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:16:48 --> Helper loaded: date_helper
INFO - 2019-08-19 18:16:48 --> Form Validation Class Initialized
INFO - 2019-08-19 18:16:48 --> URI Class Initialized
INFO - 2019-08-19 18:16:48 --> Router Class Initialized
INFO - 2019-08-19 18:16:48 --> Output Class Initialized
INFO - 2019-08-19 18:16:49 --> Security Class Initialized
DEBUG - 2019-08-19 18:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:16:49 --> Input Class Initialized
INFO - 2019-08-19 18:16:49 --> Language Class Initialized
INFO - 2019-08-19 18:16:49 --> Email Class Initialized
DEBUG - 2019-08-19 18:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:16:49 --> Pagination Class Initialized
INFO - 2019-08-19 18:16:49 --> Loader Class Initialized
INFO - 2019-08-19 18:16:49 --> Helper loaded: url_helper
INFO - 2019-08-19 18:16:49 --> Helper loaded: html_helper
INFO - 2019-08-19 18:16:49 --> Helper loaded: form_helper
INFO - 2019-08-19 18:16:49 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:16:49 --> Helper loaded: date_helper
INFO - 2019-08-19 18:16:49 --> Form Validation Class Initialized
INFO - 2019-08-19 18:16:49 --> Database Driver Class Initialized
INFO - 2019-08-19 18:16:49 --> Database Driver Class Initialized
INFO - 2019-08-19 18:16:49 --> Email Class Initialized
DEBUG - 2019-08-19 18:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:16:49 --> Controller Class Initialized
INFO - 2019-08-19 18:16:49 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:16:49 --> Final output sent to browser
DEBUG - 2019-08-19 18:16:49 --> Total execution time: 0.4170
INFO - 2019-08-19 18:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:16:49 --> Pagination Class Initialized
INFO - 2019-08-19 18:16:49 --> Database Driver Class Initialized
INFO - 2019-08-19 18:16:49 --> Database Driver Class Initialized
INFO - 2019-08-19 18:16:49 --> Controller Class Initialized
INFO - 2019-08-19 18:16:49 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:16:49 --> Final output sent to browser
DEBUG - 2019-08-19 18:16:49 --> Total execution time: 0.4880
INFO - 2019-08-19 18:16:50 --> Config Class Initialized
INFO - 2019-08-19 18:16:50 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:16:50 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:16:50 --> Utf8 Class Initialized
INFO - 2019-08-19 18:16:50 --> URI Class Initialized
INFO - 2019-08-19 18:16:50 --> Router Class Initialized
INFO - 2019-08-19 18:16:50 --> Output Class Initialized
INFO - 2019-08-19 18:16:50 --> Security Class Initialized
DEBUG - 2019-08-19 18:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:16:50 --> Input Class Initialized
INFO - 2019-08-19 18:16:50 --> Language Class Initialized
INFO - 2019-08-19 18:16:50 --> Loader Class Initialized
INFO - 2019-08-19 18:16:50 --> Helper loaded: url_helper
INFO - 2019-08-19 18:16:50 --> Helper loaded: html_helper
INFO - 2019-08-19 18:16:50 --> Helper loaded: form_helper
INFO - 2019-08-19 18:16:50 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:16:50 --> Helper loaded: date_helper
INFO - 2019-08-19 18:16:50 --> Form Validation Class Initialized
INFO - 2019-08-19 18:16:50 --> Email Class Initialized
DEBUG - 2019-08-19 18:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:16:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:16:50 --> Pagination Class Initialized
INFO - 2019-08-19 18:16:50 --> Database Driver Class Initialized
INFO - 2019-08-19 18:16:50 --> Database Driver Class Initialized
INFO - 2019-08-19 18:16:50 --> Controller Class Initialized
INFO - 2019-08-19 18:16:50 --> Final output sent to browser
DEBUG - 2019-08-19 18:16:50 --> Total execution time: 0.3820
INFO - 2019-08-19 18:16:57 --> Config Class Initialized
INFO - 2019-08-19 18:16:57 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:16:57 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:16:57 --> Utf8 Class Initialized
INFO - 2019-08-19 18:16:57 --> URI Class Initialized
INFO - 2019-08-19 18:16:57 --> Router Class Initialized
INFO - 2019-08-19 18:16:57 --> Output Class Initialized
INFO - 2019-08-19 18:16:57 --> Security Class Initialized
DEBUG - 2019-08-19 18:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:16:57 --> Input Class Initialized
INFO - 2019-08-19 18:16:57 --> Language Class Initialized
INFO - 2019-08-19 18:16:57 --> Loader Class Initialized
INFO - 2019-08-19 18:16:57 --> Helper loaded: url_helper
INFO - 2019-08-19 18:16:57 --> Helper loaded: html_helper
INFO - 2019-08-19 18:16:57 --> Helper loaded: form_helper
INFO - 2019-08-19 18:16:57 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:16:57 --> Helper loaded: date_helper
INFO - 2019-08-19 18:16:57 --> Form Validation Class Initialized
INFO - 2019-08-19 18:16:57 --> Email Class Initialized
DEBUG - 2019-08-19 18:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:16:57 --> Pagination Class Initialized
INFO - 2019-08-19 18:16:57 --> Database Driver Class Initialized
INFO - 2019-08-19 18:16:57 --> Database Driver Class Initialized
INFO - 2019-08-19 18:16:57 --> Controller Class Initialized
INFO - 2019-08-19 18:16:57 --> Final output sent to browser
DEBUG - 2019-08-19 18:16:57 --> Total execution time: 0.2420
INFO - 2019-08-19 18:17:16 --> Config Class Initialized
INFO - 2019-08-19 18:17:16 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:17:16 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:17:16 --> Utf8 Class Initialized
INFO - 2019-08-19 18:17:16 --> URI Class Initialized
INFO - 2019-08-19 18:17:16 --> Router Class Initialized
INFO - 2019-08-19 18:17:16 --> Output Class Initialized
INFO - 2019-08-19 18:17:16 --> Security Class Initialized
DEBUG - 2019-08-19 18:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:17:16 --> Input Class Initialized
INFO - 2019-08-19 18:17:16 --> Language Class Initialized
INFO - 2019-08-19 18:17:16 --> Loader Class Initialized
INFO - 2019-08-19 18:17:16 --> Helper loaded: url_helper
INFO - 2019-08-19 18:17:16 --> Helper loaded: html_helper
INFO - 2019-08-19 18:17:16 --> Helper loaded: form_helper
INFO - 2019-08-19 18:17:16 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:17:16 --> Helper loaded: date_helper
INFO - 2019-08-19 18:17:16 --> Form Validation Class Initialized
INFO - 2019-08-19 18:17:16 --> Email Class Initialized
DEBUG - 2019-08-19 18:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:17:16 --> Pagination Class Initialized
INFO - 2019-08-19 18:17:16 --> Database Driver Class Initialized
INFO - 2019-08-19 18:17:16 --> Database Driver Class Initialized
INFO - 2019-08-19 18:17:16 --> Controller Class Initialized
INFO - 2019-08-19 18:17:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 18:17:17 --> Config Class Initialized
INFO - 2019-08-19 18:17:17 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:17:17 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:17:17 --> Utf8 Class Initialized
INFO - 2019-08-19 18:17:17 --> URI Class Initialized
INFO - 2019-08-19 18:17:17 --> Router Class Initialized
INFO - 2019-08-19 18:17:17 --> Output Class Initialized
INFO - 2019-08-19 18:17:17 --> Security Class Initialized
DEBUG - 2019-08-19 18:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:17:17 --> Input Class Initialized
INFO - 2019-08-19 18:17:17 --> Language Class Initialized
INFO - 2019-08-19 18:17:17 --> Loader Class Initialized
INFO - 2019-08-19 18:17:17 --> Helper loaded: url_helper
INFO - 2019-08-19 18:17:17 --> Helper loaded: html_helper
INFO - 2019-08-19 18:17:17 --> Helper loaded: form_helper
INFO - 2019-08-19 18:17:17 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:17:17 --> Helper loaded: date_helper
INFO - 2019-08-19 18:17:17 --> Form Validation Class Initialized
INFO - 2019-08-19 18:17:17 --> Email Class Initialized
DEBUG - 2019-08-19 18:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:17:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:17:17 --> Pagination Class Initialized
INFO - 2019-08-19 18:17:17 --> Database Driver Class Initialized
INFO - 2019-08-19 18:17:17 --> Database Driver Class Initialized
INFO - 2019-08-19 18:17:17 --> Controller Class Initialized
INFO - 2019-08-19 18:17:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:17:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 18:17:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:17:18 --> Final output sent to browser
DEBUG - 2019-08-19 18:17:18 --> Total execution time: 0.7800
INFO - 2019-08-19 18:18:02 --> Config Class Initialized
INFO - 2019-08-19 18:18:02 --> Hooks Class Initialized
INFO - 2019-08-19 18:18:02 --> Config Class Initialized
INFO - 2019-08-19 18:18:02 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:18:02 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:18:02 --> Utf8 Class Initialized
DEBUG - 2019-08-19 18:18:02 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:18:02 --> Utf8 Class Initialized
INFO - 2019-08-19 18:18:02 --> URI Class Initialized
INFO - 2019-08-19 18:18:02 --> URI Class Initialized
INFO - 2019-08-19 18:18:02 --> Router Class Initialized
INFO - 2019-08-19 18:18:02 --> Router Class Initialized
INFO - 2019-08-19 18:18:02 --> Output Class Initialized
INFO - 2019-08-19 18:18:02 --> Security Class Initialized
INFO - 2019-08-19 18:18:03 --> Output Class Initialized
DEBUG - 2019-08-19 18:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:18:03 --> Security Class Initialized
INFO - 2019-08-19 18:18:03 --> Input Class Initialized
INFO - 2019-08-19 18:18:03 --> Language Class Initialized
DEBUG - 2019-08-19 18:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:18:03 --> Input Class Initialized
INFO - 2019-08-19 18:18:03 --> Language Class Initialized
INFO - 2019-08-19 18:18:03 --> Loader Class Initialized
INFO - 2019-08-19 18:18:03 --> Helper loaded: url_helper
INFO - 2019-08-19 18:18:03 --> Helper loaded: html_helper
INFO - 2019-08-19 18:18:03 --> Helper loaded: form_helper
INFO - 2019-08-19 18:18:03 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:18:03 --> Loader Class Initialized
INFO - 2019-08-19 18:18:03 --> Helper loaded: date_helper
INFO - 2019-08-19 18:18:03 --> Helper loaded: url_helper
INFO - 2019-08-19 18:18:03 --> Form Validation Class Initialized
INFO - 2019-08-19 18:18:03 --> Email Class Initialized
DEBUG - 2019-08-19 18:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:18:03 --> Helper loaded: html_helper
INFO - 2019-08-19 18:18:03 --> Helper loaded: form_helper
INFO - 2019-08-19 18:18:03 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:18:03 --> Helper loaded: date_helper
INFO - 2019-08-19 18:18:03 --> Form Validation Class Initialized
INFO - 2019-08-19 18:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:18:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:18:03 --> Pagination Class Initialized
INFO - 2019-08-19 18:18:03 --> Config Class Initialized
INFO - 2019-08-19 18:18:03 --> Hooks Class Initialized
INFO - 2019-08-19 18:18:03 --> Database Driver Class Initialized
DEBUG - 2019-08-19 18:18:03 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:18:03 --> Utf8 Class Initialized
INFO - 2019-08-19 18:18:03 --> Database Driver Class Initialized
INFO - 2019-08-19 18:18:03 --> URI Class Initialized
INFO - 2019-08-19 18:18:03 --> Router Class Initialized
INFO - 2019-08-19 18:18:03 --> Output Class Initialized
INFO - 2019-08-19 18:18:03 --> Controller Class Initialized
INFO - 2019-08-19 18:18:03 --> Security Class Initialized
INFO - 2019-08-19 18:18:03 --> Email Class Initialized
DEBUG - 2019-08-19 18:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:18:03 --> Final output sent to browser
DEBUG - 2019-08-19 18:18:03 --> Total execution time: 0.2720
INFO - 2019-08-19 18:18:03 --> Input Class Initialized
INFO - 2019-08-19 18:18:03 --> Language Class Initialized
INFO - 2019-08-19 18:18:03 --> Loader Class Initialized
INFO - 2019-08-19 18:18:03 --> Helper loaded: url_helper
INFO - 2019-08-19 18:18:03 --> Helper loaded: html_helper
INFO - 2019-08-19 18:18:03 --> Helper loaded: form_helper
INFO - 2019-08-19 18:18:03 --> Helper loaded: cookie_helper
DEBUG - 2019-08-19 18:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:18:03 --> Helper loaded: date_helper
INFO - 2019-08-19 18:18:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:18:03 --> Pagination Class Initialized
INFO - 2019-08-19 18:18:03 --> Form Validation Class Initialized
INFO - 2019-08-19 18:18:03 --> Email Class Initialized
DEBUG - 2019-08-19 18:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:18:03 --> Database Driver Class Initialized
INFO - 2019-08-19 18:18:03 --> Database Driver Class Initialized
INFO - 2019-08-19 18:18:03 --> Controller Class Initialized
INFO - 2019-08-19 18:18:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:18:03 --> Final output sent to browser
DEBUG - 2019-08-19 18:18:03 --> Total execution time: 0.5360
INFO - 2019-08-19 18:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:18:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:18:03 --> Pagination Class Initialized
INFO - 2019-08-19 18:18:03 --> Database Driver Class Initialized
INFO - 2019-08-19 18:18:03 --> Database Driver Class Initialized
INFO - 2019-08-19 18:18:03 --> Controller Class Initialized
INFO - 2019-08-19 18:18:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:18:03 --> Final output sent to browser
DEBUG - 2019-08-19 18:18:03 --> Total execution time: 0.4750
INFO - 2019-08-19 18:19:46 --> Config Class Initialized
INFO - 2019-08-19 18:19:46 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:19:46 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:19:46 --> Utf8 Class Initialized
INFO - 2019-08-19 18:19:46 --> URI Class Initialized
INFO - 2019-08-19 18:19:46 --> Router Class Initialized
INFO - 2019-08-19 18:19:46 --> Output Class Initialized
INFO - 2019-08-19 18:19:46 --> Security Class Initialized
DEBUG - 2019-08-19 18:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:19:46 --> Input Class Initialized
INFO - 2019-08-19 18:19:46 --> Language Class Initialized
INFO - 2019-08-19 18:19:46 --> Loader Class Initialized
INFO - 2019-08-19 18:19:46 --> Helper loaded: url_helper
INFO - 2019-08-19 18:19:46 --> Helper loaded: html_helper
INFO - 2019-08-19 18:19:46 --> Helper loaded: form_helper
INFO - 2019-08-19 18:19:46 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:19:46 --> Helper loaded: date_helper
INFO - 2019-08-19 18:19:46 --> Form Validation Class Initialized
INFO - 2019-08-19 18:19:46 --> Email Class Initialized
DEBUG - 2019-08-19 18:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:19:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:19:46 --> Pagination Class Initialized
INFO - 2019-08-19 18:19:46 --> Database Driver Class Initialized
INFO - 2019-08-19 18:19:46 --> Database Driver Class Initialized
INFO - 2019-08-19 18:19:46 --> Controller Class Initialized
INFO - 2019-08-19 18:19:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 18:19:46 --> Config Class Initialized
INFO - 2019-08-19 18:19:46 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:19:46 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:19:46 --> Utf8 Class Initialized
INFO - 2019-08-19 18:19:46 --> URI Class Initialized
INFO - 2019-08-19 18:19:46 --> Router Class Initialized
INFO - 2019-08-19 18:19:46 --> Output Class Initialized
INFO - 2019-08-19 18:19:46 --> Security Class Initialized
DEBUG - 2019-08-19 18:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:19:46 --> Input Class Initialized
INFO - 2019-08-19 18:19:46 --> Language Class Initialized
INFO - 2019-08-19 18:19:46 --> Loader Class Initialized
INFO - 2019-08-19 18:19:46 --> Helper loaded: url_helper
INFO - 2019-08-19 18:19:46 --> Helper loaded: html_helper
INFO - 2019-08-19 18:19:46 --> Helper loaded: form_helper
INFO - 2019-08-19 18:19:46 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:19:46 --> Helper loaded: date_helper
INFO - 2019-08-19 18:19:46 --> Form Validation Class Initialized
INFO - 2019-08-19 18:19:46 --> Email Class Initialized
DEBUG - 2019-08-19 18:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:19:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:19:46 --> Pagination Class Initialized
INFO - 2019-08-19 18:19:46 --> Database Driver Class Initialized
INFO - 2019-08-19 18:19:46 --> Database Driver Class Initialized
INFO - 2019-08-19 18:19:46 --> Controller Class Initialized
INFO - 2019-08-19 18:19:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:19:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 18:19:47 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:19:47 --> Final output sent to browser
DEBUG - 2019-08-19 18:19:47 --> Total execution time: 0.4880
INFO - 2019-08-19 18:20:50 --> Config Class Initialized
INFO - 2019-08-19 18:20:50 --> Hooks Class Initialized
INFO - 2019-08-19 18:20:50 --> Config Class Initialized
INFO - 2019-08-19 18:20:50 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:20:50 --> UTF-8 Support Enabled
DEBUG - 2019-08-19 18:20:50 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:20:50 --> Utf8 Class Initialized
INFO - 2019-08-19 18:20:50 --> Utf8 Class Initialized
INFO - 2019-08-19 18:20:50 --> URI Class Initialized
INFO - 2019-08-19 18:20:50 --> URI Class Initialized
INFO - 2019-08-19 18:20:50 --> Router Class Initialized
INFO - 2019-08-19 18:20:50 --> Router Class Initialized
INFO - 2019-08-19 18:20:50 --> Output Class Initialized
INFO - 2019-08-19 18:20:50 --> Output Class Initialized
INFO - 2019-08-19 18:20:50 --> Security Class Initialized
INFO - 2019-08-19 18:20:50 --> Security Class Initialized
DEBUG - 2019-08-19 18:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:20:50 --> Input Class Initialized
INFO - 2019-08-19 18:20:50 --> Language Class Initialized
DEBUG - 2019-08-19 18:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:20:50 --> Input Class Initialized
INFO - 2019-08-19 18:20:50 --> Language Class Initialized
INFO - 2019-08-19 18:20:50 --> Loader Class Initialized
INFO - 2019-08-19 18:20:50 --> Helper loaded: url_helper
INFO - 2019-08-19 18:20:50 --> Helper loaded: html_helper
INFO - 2019-08-19 18:20:50 --> Helper loaded: form_helper
INFO - 2019-08-19 18:20:50 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:20:50 --> Helper loaded: date_helper
INFO - 2019-08-19 18:20:50 --> Form Validation Class Initialized
INFO - 2019-08-19 18:20:50 --> Loader Class Initialized
INFO - 2019-08-19 18:20:50 --> Email Class Initialized
INFO - 2019-08-19 18:20:50 --> Helper loaded: url_helper
INFO - 2019-08-19 18:20:50 --> Helper loaded: html_helper
DEBUG - 2019-08-19 18:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:20:50 --> Helper loaded: form_helper
INFO - 2019-08-19 18:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:20:50 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:20:50 --> Helper loaded: date_helper
INFO - 2019-08-19 18:20:50 --> Form Validation Class Initialized
INFO - 2019-08-19 18:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:20:50 --> Pagination Class Initialized
INFO - 2019-08-19 18:20:50 --> Database Driver Class Initialized
INFO - 2019-08-19 18:20:50 --> Database Driver Class Initialized
INFO - 2019-08-19 18:20:50 --> Email Class Initialized
DEBUG - 2019-08-19 18:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:20:50 --> Controller Class Initialized
INFO - 2019-08-19 18:20:50 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:20:50 --> Final output sent to browser
DEBUG - 2019-08-19 18:20:50 --> Total execution time: 0.2610
INFO - 2019-08-19 18:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:20:50 --> Pagination Class Initialized
INFO - 2019-08-19 18:20:50 --> Database Driver Class Initialized
INFO - 2019-08-19 18:20:50 --> Database Driver Class Initialized
INFO - 2019-08-19 18:20:50 --> Controller Class Initialized
INFO - 2019-08-19 18:20:50 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:20:50 --> Final output sent to browser
DEBUG - 2019-08-19 18:20:50 --> Total execution time: 0.3880
INFO - 2019-08-19 18:20:51 --> Config Class Initialized
INFO - 2019-08-19 18:20:51 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:20:51 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:20:51 --> Utf8 Class Initialized
INFO - 2019-08-19 18:20:51 --> URI Class Initialized
INFO - 2019-08-19 18:20:51 --> Router Class Initialized
INFO - 2019-08-19 18:20:51 --> Output Class Initialized
INFO - 2019-08-19 18:20:51 --> Security Class Initialized
DEBUG - 2019-08-19 18:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:20:51 --> Input Class Initialized
INFO - 2019-08-19 18:20:51 --> Language Class Initialized
INFO - 2019-08-19 18:20:51 --> Loader Class Initialized
INFO - 2019-08-19 18:20:51 --> Helper loaded: url_helper
INFO - 2019-08-19 18:20:51 --> Helper loaded: html_helper
INFO - 2019-08-19 18:20:51 --> Helper loaded: form_helper
INFO - 2019-08-19 18:20:51 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:20:51 --> Helper loaded: date_helper
INFO - 2019-08-19 18:20:51 --> Form Validation Class Initialized
INFO - 2019-08-19 18:20:51 --> Email Class Initialized
DEBUG - 2019-08-19 18:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:20:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:20:51 --> Pagination Class Initialized
INFO - 2019-08-19 18:20:51 --> Database Driver Class Initialized
INFO - 2019-08-19 18:20:51 --> Database Driver Class Initialized
INFO - 2019-08-19 18:20:51 --> Controller Class Initialized
INFO - 2019-08-19 18:20:51 --> Final output sent to browser
DEBUG - 2019-08-19 18:20:51 --> Total execution time: 0.4830
INFO - 2019-08-19 18:21:02 --> Config Class Initialized
INFO - 2019-08-19 18:21:02 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:21:02 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:21:02 --> Utf8 Class Initialized
INFO - 2019-08-19 18:21:02 --> URI Class Initialized
INFO - 2019-08-19 18:21:02 --> Router Class Initialized
INFO - 2019-08-19 18:21:02 --> Output Class Initialized
INFO - 2019-08-19 18:21:02 --> Security Class Initialized
DEBUG - 2019-08-19 18:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:21:02 --> Input Class Initialized
INFO - 2019-08-19 18:21:02 --> Language Class Initialized
INFO - 2019-08-19 18:21:02 --> Loader Class Initialized
INFO - 2019-08-19 18:21:02 --> Helper loaded: url_helper
INFO - 2019-08-19 18:21:02 --> Helper loaded: html_helper
INFO - 2019-08-19 18:21:02 --> Helper loaded: form_helper
INFO - 2019-08-19 18:21:02 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:21:02 --> Helper loaded: date_helper
INFO - 2019-08-19 18:21:02 --> Form Validation Class Initialized
INFO - 2019-08-19 18:21:02 --> Email Class Initialized
DEBUG - 2019-08-19 18:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:21:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:21:02 --> Pagination Class Initialized
INFO - 2019-08-19 18:21:02 --> Database Driver Class Initialized
INFO - 2019-08-19 18:21:02 --> Database Driver Class Initialized
INFO - 2019-08-19 18:21:02 --> Controller Class Initialized
INFO - 2019-08-19 18:21:02 --> Final output sent to browser
DEBUG - 2019-08-19 18:21:02 --> Total execution time: 0.3580
INFO - 2019-08-19 18:21:13 --> Config Class Initialized
INFO - 2019-08-19 18:21:13 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:21:13 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:21:13 --> Utf8 Class Initialized
INFO - 2019-08-19 18:21:13 --> URI Class Initialized
INFO - 2019-08-19 18:21:13 --> Router Class Initialized
INFO - 2019-08-19 18:21:13 --> Output Class Initialized
INFO - 2019-08-19 18:21:13 --> Security Class Initialized
DEBUG - 2019-08-19 18:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:21:13 --> Input Class Initialized
INFO - 2019-08-19 18:21:13 --> Language Class Initialized
INFO - 2019-08-19 18:21:13 --> Loader Class Initialized
INFO - 2019-08-19 18:21:13 --> Helper loaded: url_helper
INFO - 2019-08-19 18:21:13 --> Helper loaded: html_helper
INFO - 2019-08-19 18:21:13 --> Helper loaded: form_helper
INFO - 2019-08-19 18:21:13 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:21:13 --> Helper loaded: date_helper
INFO - 2019-08-19 18:21:13 --> Form Validation Class Initialized
INFO - 2019-08-19 18:21:13 --> Email Class Initialized
DEBUG - 2019-08-19 18:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:21:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:21:13 --> Pagination Class Initialized
INFO - 2019-08-19 18:21:13 --> Database Driver Class Initialized
INFO - 2019-08-19 18:21:13 --> Database Driver Class Initialized
INFO - 2019-08-19 18:21:13 --> Controller Class Initialized
INFO - 2019-08-19 18:21:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 18:21:13 --> Config Class Initialized
INFO - 2019-08-19 18:21:13 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:21:13 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:21:13 --> Utf8 Class Initialized
INFO - 2019-08-19 18:21:13 --> URI Class Initialized
INFO - 2019-08-19 18:21:13 --> Router Class Initialized
INFO - 2019-08-19 18:21:13 --> Output Class Initialized
INFO - 2019-08-19 18:21:13 --> Security Class Initialized
DEBUG - 2019-08-19 18:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:21:13 --> Input Class Initialized
INFO - 2019-08-19 18:21:13 --> Language Class Initialized
INFO - 2019-08-19 18:21:13 --> Loader Class Initialized
INFO - 2019-08-19 18:21:13 --> Helper loaded: url_helper
INFO - 2019-08-19 18:21:13 --> Helper loaded: html_helper
INFO - 2019-08-19 18:21:13 --> Helper loaded: form_helper
INFO - 2019-08-19 18:21:13 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:21:13 --> Helper loaded: date_helper
INFO - 2019-08-19 18:21:13 --> Form Validation Class Initialized
INFO - 2019-08-19 18:21:13 --> Email Class Initialized
DEBUG - 2019-08-19 18:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:21:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:21:13 --> Pagination Class Initialized
INFO - 2019-08-19 18:21:13 --> Database Driver Class Initialized
INFO - 2019-08-19 18:21:13 --> Database Driver Class Initialized
INFO - 2019-08-19 18:21:13 --> Controller Class Initialized
INFO - 2019-08-19 18:21:13 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:21:13 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 18:21:13 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:21:13 --> Final output sent to browser
DEBUG - 2019-08-19 18:21:13 --> Total execution time: 0.2070
INFO - 2019-08-19 18:21:56 --> Config Class Initialized
INFO - 2019-08-19 18:21:56 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:21:56 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:21:56 --> Utf8 Class Initialized
INFO - 2019-08-19 18:21:56 --> URI Class Initialized
INFO - 2019-08-19 18:21:56 --> Router Class Initialized
INFO - 2019-08-19 18:21:56 --> Output Class Initialized
INFO - 2019-08-19 18:21:56 --> Security Class Initialized
DEBUG - 2019-08-19 18:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:21:56 --> Input Class Initialized
INFO - 2019-08-19 18:21:56 --> Language Class Initialized
INFO - 2019-08-19 18:21:56 --> Loader Class Initialized
INFO - 2019-08-19 18:21:56 --> Helper loaded: url_helper
INFO - 2019-08-19 18:21:56 --> Helper loaded: html_helper
INFO - 2019-08-19 18:21:56 --> Helper loaded: form_helper
INFO - 2019-08-19 18:21:56 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:21:56 --> Helper loaded: date_helper
INFO - 2019-08-19 18:21:56 --> Form Validation Class Initialized
INFO - 2019-08-19 18:21:56 --> Email Class Initialized
DEBUG - 2019-08-19 18:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:21:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:21:56 --> Pagination Class Initialized
INFO - 2019-08-19 18:21:56 --> Config Class Initialized
INFO - 2019-08-19 18:21:56 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:21:56 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:21:56 --> Utf8 Class Initialized
INFO - 2019-08-19 18:21:56 --> Database Driver Class Initialized
INFO - 2019-08-19 18:21:56 --> Database Driver Class Initialized
INFO - 2019-08-19 18:21:56 --> URI Class Initialized
INFO - 2019-08-19 18:21:56 --> Controller Class Initialized
INFO - 2019-08-19 18:21:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:21:56 --> Final output sent to browser
DEBUG - 2019-08-19 18:21:56 --> Total execution time: 0.6060
INFO - 2019-08-19 18:21:56 --> Router Class Initialized
INFO - 2019-08-19 18:21:56 --> Output Class Initialized
INFO - 2019-08-19 18:21:56 --> Security Class Initialized
DEBUG - 2019-08-19 18:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:21:56 --> Input Class Initialized
INFO - 2019-08-19 18:21:56 --> Language Class Initialized
INFO - 2019-08-19 18:21:56 --> Loader Class Initialized
INFO - 2019-08-19 18:21:56 --> Helper loaded: url_helper
INFO - 2019-08-19 18:21:56 --> Helper loaded: html_helper
INFO - 2019-08-19 18:21:56 --> Helper loaded: form_helper
INFO - 2019-08-19 18:21:56 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:21:56 --> Helper loaded: date_helper
INFO - 2019-08-19 18:21:56 --> Form Validation Class Initialized
INFO - 2019-08-19 18:21:56 --> Email Class Initialized
DEBUG - 2019-08-19 18:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:21:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:21:56 --> Pagination Class Initialized
INFO - 2019-08-19 18:21:56 --> Database Driver Class Initialized
INFO - 2019-08-19 18:21:56 --> Database Driver Class Initialized
INFO - 2019-08-19 18:21:57 --> Controller Class Initialized
INFO - 2019-08-19 18:21:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:21:57 --> Final output sent to browser
DEBUG - 2019-08-19 18:21:57 --> Total execution time: 1.0601
INFO - 2019-08-19 18:21:58 --> Config Class Initialized
INFO - 2019-08-19 18:21:58 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:21:58 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:21:58 --> Utf8 Class Initialized
INFO - 2019-08-19 18:21:58 --> URI Class Initialized
INFO - 2019-08-19 18:21:58 --> Router Class Initialized
INFO - 2019-08-19 18:21:58 --> Output Class Initialized
INFO - 2019-08-19 18:21:58 --> Security Class Initialized
DEBUG - 2019-08-19 18:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:21:58 --> Input Class Initialized
INFO - 2019-08-19 18:21:58 --> Language Class Initialized
INFO - 2019-08-19 18:21:58 --> Loader Class Initialized
INFO - 2019-08-19 18:21:58 --> Helper loaded: url_helper
INFO - 2019-08-19 18:21:58 --> Helper loaded: html_helper
INFO - 2019-08-19 18:21:58 --> Helper loaded: form_helper
INFO - 2019-08-19 18:21:58 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:21:58 --> Helper loaded: date_helper
INFO - 2019-08-19 18:21:59 --> Form Validation Class Initialized
INFO - 2019-08-19 18:21:59 --> Email Class Initialized
DEBUG - 2019-08-19 18:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:21:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:21:59 --> Pagination Class Initialized
INFO - 2019-08-19 18:21:59 --> Database Driver Class Initialized
INFO - 2019-08-19 18:21:59 --> Database Driver Class Initialized
INFO - 2019-08-19 18:21:59 --> Controller Class Initialized
INFO - 2019-08-19 18:21:59 --> Final output sent to browser
DEBUG - 2019-08-19 18:21:59 --> Total execution time: 0.5070
INFO - 2019-08-19 18:22:50 --> Config Class Initialized
INFO - 2019-08-19 18:22:50 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:22:50 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:22:50 --> Utf8 Class Initialized
INFO - 2019-08-19 18:22:50 --> URI Class Initialized
INFO - 2019-08-19 18:22:50 --> Router Class Initialized
INFO - 2019-08-19 18:22:50 --> Output Class Initialized
INFO - 2019-08-19 18:22:50 --> Security Class Initialized
DEBUG - 2019-08-19 18:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:22:50 --> Input Class Initialized
INFO - 2019-08-19 18:22:50 --> Language Class Initialized
INFO - 2019-08-19 18:22:50 --> Loader Class Initialized
INFO - 2019-08-19 18:22:50 --> Helper loaded: url_helper
INFO - 2019-08-19 18:22:50 --> Helper loaded: html_helper
INFO - 2019-08-19 18:22:50 --> Helper loaded: form_helper
INFO - 2019-08-19 18:22:50 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:22:50 --> Helper loaded: date_helper
INFO - 2019-08-19 18:22:50 --> Form Validation Class Initialized
INFO - 2019-08-19 18:22:50 --> Email Class Initialized
DEBUG - 2019-08-19 18:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:22:50 --> Pagination Class Initialized
INFO - 2019-08-19 18:22:50 --> Database Driver Class Initialized
INFO - 2019-08-19 18:22:50 --> Database Driver Class Initialized
INFO - 2019-08-19 18:22:50 --> Controller Class Initialized
INFO - 2019-08-19 18:22:50 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:22:50 --> Final output sent to browser
DEBUG - 2019-08-19 18:22:50 --> Total execution time: 0.2940
INFO - 2019-08-19 18:22:51 --> Config Class Initialized
INFO - 2019-08-19 18:22:51 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:22:51 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:22:51 --> Utf8 Class Initialized
INFO - 2019-08-19 18:22:51 --> URI Class Initialized
INFO - 2019-08-19 18:22:51 --> Router Class Initialized
INFO - 2019-08-19 18:22:51 --> Output Class Initialized
INFO - 2019-08-19 18:22:51 --> Security Class Initialized
DEBUG - 2019-08-19 18:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:22:51 --> Input Class Initialized
INFO - 2019-08-19 18:22:51 --> Language Class Initialized
INFO - 2019-08-19 18:22:51 --> Loader Class Initialized
INFO - 2019-08-19 18:22:51 --> Helper loaded: url_helper
INFO - 2019-08-19 18:22:51 --> Helper loaded: html_helper
INFO - 2019-08-19 18:22:51 --> Helper loaded: form_helper
INFO - 2019-08-19 18:22:51 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:22:51 --> Helper loaded: date_helper
INFO - 2019-08-19 18:22:51 --> Form Validation Class Initialized
INFO - 2019-08-19 18:22:51 --> Email Class Initialized
DEBUG - 2019-08-19 18:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:22:51 --> Pagination Class Initialized
INFO - 2019-08-19 18:22:51 --> Database Driver Class Initialized
INFO - 2019-08-19 18:22:51 --> Database Driver Class Initialized
INFO - 2019-08-19 18:22:52 --> Controller Class Initialized
INFO - 2019-08-19 18:22:52 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:22:52 --> Final output sent to browser
DEBUG - 2019-08-19 18:22:52 --> Total execution time: 0.2530
INFO - 2019-08-19 18:22:53 --> Config Class Initialized
INFO - 2019-08-19 18:22:53 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:22:53 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:22:53 --> Utf8 Class Initialized
INFO - 2019-08-19 18:22:53 --> URI Class Initialized
INFO - 2019-08-19 18:22:53 --> Router Class Initialized
INFO - 2019-08-19 18:22:53 --> Output Class Initialized
INFO - 2019-08-19 18:22:53 --> Security Class Initialized
DEBUG - 2019-08-19 18:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:22:53 --> Input Class Initialized
INFO - 2019-08-19 18:22:53 --> Language Class Initialized
INFO - 2019-08-19 18:22:53 --> Loader Class Initialized
INFO - 2019-08-19 18:22:53 --> Helper loaded: url_helper
INFO - 2019-08-19 18:22:53 --> Helper loaded: html_helper
INFO - 2019-08-19 18:22:53 --> Helper loaded: form_helper
INFO - 2019-08-19 18:22:53 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:22:53 --> Helper loaded: date_helper
INFO - 2019-08-19 18:22:53 --> Form Validation Class Initialized
INFO - 2019-08-19 18:22:53 --> Email Class Initialized
DEBUG - 2019-08-19 18:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:22:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:22:53 --> Pagination Class Initialized
INFO - 2019-08-19 18:22:53 --> Database Driver Class Initialized
INFO - 2019-08-19 18:22:53 --> Database Driver Class Initialized
INFO - 2019-08-19 18:22:53 --> Controller Class Initialized
INFO - 2019-08-19 18:22:53 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:22:53 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-19 18:22:54 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:22:54 --> Final output sent to browser
DEBUG - 2019-08-19 18:22:54 --> Total execution time: 0.2310
INFO - 2019-08-19 18:24:02 --> Config Class Initialized
INFO - 2019-08-19 18:24:02 --> Hooks Class Initialized
INFO - 2019-08-19 18:24:02 --> Config Class Initialized
INFO - 2019-08-19 18:24:02 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:24:02 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:24:02 --> Utf8 Class Initialized
INFO - 2019-08-19 18:24:02 --> URI Class Initialized
INFO - 2019-08-19 18:24:02 --> Router Class Initialized
INFO - 2019-08-19 18:24:02 --> Output Class Initialized
INFO - 2019-08-19 18:24:02 --> Security Class Initialized
DEBUG - 2019-08-19 18:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:24:02 --> Input Class Initialized
INFO - 2019-08-19 18:24:02 --> Language Class Initialized
DEBUG - 2019-08-19 18:24:02 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:24:02 --> Utf8 Class Initialized
INFO - 2019-08-19 18:24:02 --> URI Class Initialized
INFO - 2019-08-19 18:24:02 --> Loader Class Initialized
INFO - 2019-08-19 18:24:02 --> Helper loaded: url_helper
INFO - 2019-08-19 18:24:02 --> Helper loaded: html_helper
INFO - 2019-08-19 18:24:02 --> Helper loaded: form_helper
INFO - 2019-08-19 18:24:02 --> Router Class Initialized
INFO - 2019-08-19 18:24:02 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:24:02 --> Helper loaded: date_helper
INFO - 2019-08-19 18:24:02 --> Form Validation Class Initialized
INFO - 2019-08-19 18:24:02 --> Email Class Initialized
INFO - 2019-08-19 18:24:02 --> Output Class Initialized
INFO - 2019-08-19 18:24:02 --> Security Class Initialized
DEBUG - 2019-08-19 18:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:24:02 --> Input Class Initialized
INFO - 2019-08-19 18:24:02 --> Language Class Initialized
DEBUG - 2019-08-19 18:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:24:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:24:02 --> Pagination Class Initialized
INFO - 2019-08-19 18:24:02 --> Database Driver Class Initialized
INFO - 2019-08-19 18:24:02 --> Database Driver Class Initialized
INFO - 2019-08-19 18:24:03 --> Loader Class Initialized
INFO - 2019-08-19 18:24:03 --> Helper loaded: url_helper
INFO - 2019-08-19 18:24:03 --> Controller Class Initialized
INFO - 2019-08-19 18:24:03 --> Helper loaded: html_helper
INFO - 2019-08-19 18:24:03 --> Helper loaded: form_helper
INFO - 2019-08-19 18:24:03 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:24:03 --> Helper loaded: date_helper
INFO - 2019-08-19 18:24:03 --> Form Validation Class Initialized
INFO - 2019-08-19 18:24:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:24:03 --> Final output sent to browser
DEBUG - 2019-08-19 18:24:03 --> Total execution time: 0.5480
INFO - 2019-08-19 18:24:03 --> Email Class Initialized
DEBUG - 2019-08-19 18:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:24:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:24:03 --> Pagination Class Initialized
INFO - 2019-08-19 18:24:03 --> Database Driver Class Initialized
INFO - 2019-08-19 18:24:03 --> Database Driver Class Initialized
INFO - 2019-08-19 18:24:03 --> Controller Class Initialized
INFO - 2019-08-19 18:24:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:24:03 --> Final output sent to browser
DEBUG - 2019-08-19 18:24:03 --> Total execution time: 0.8490
INFO - 2019-08-19 18:26:03 --> Config Class Initialized
INFO - 2019-08-19 18:26:03 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:26:03 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:26:03 --> Utf8 Class Initialized
INFO - 2019-08-19 18:26:03 --> URI Class Initialized
INFO - 2019-08-19 18:26:03 --> Router Class Initialized
INFO - 2019-08-19 18:26:03 --> Output Class Initialized
INFO - 2019-08-19 18:26:03 --> Security Class Initialized
DEBUG - 2019-08-19 18:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:26:03 --> Input Class Initialized
INFO - 2019-08-19 18:26:03 --> Language Class Initialized
INFO - 2019-08-19 18:26:03 --> Loader Class Initialized
INFO - 2019-08-19 18:26:03 --> Helper loaded: url_helper
INFO - 2019-08-19 18:26:03 --> Helper loaded: html_helper
INFO - 2019-08-19 18:26:03 --> Helper loaded: form_helper
INFO - 2019-08-19 18:26:03 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:26:03 --> Helper loaded: date_helper
INFO - 2019-08-19 18:26:03 --> Form Validation Class Initialized
INFO - 2019-08-19 18:26:03 --> Email Class Initialized
DEBUG - 2019-08-19 18:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:26:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:26:03 --> Pagination Class Initialized
INFO - 2019-08-19 18:26:03 --> Database Driver Class Initialized
INFO - 2019-08-19 18:26:03 --> Database Driver Class Initialized
INFO - 2019-08-19 18:26:03 --> Controller Class Initialized
INFO - 2019-08-19 18:26:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:26:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-19 18:26:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/guest.php
INFO - 2019-08-19 18:26:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:26:03 --> Final output sent to browser
DEBUG - 2019-08-19 18:26:03 --> Total execution time: 0.3150
INFO - 2019-08-19 18:26:46 --> Config Class Initialized
INFO - 2019-08-19 18:26:46 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:26:46 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:26:46 --> Utf8 Class Initialized
INFO - 2019-08-19 18:26:46 --> Config Class Initialized
INFO - 2019-08-19 18:26:46 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:26:46 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:26:46 --> Utf8 Class Initialized
INFO - 2019-08-19 18:26:46 --> URI Class Initialized
INFO - 2019-08-19 18:26:46 --> Router Class Initialized
INFO - 2019-08-19 18:26:46 --> Output Class Initialized
INFO - 2019-08-19 18:26:46 --> Security Class Initialized
DEBUG - 2019-08-19 18:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:26:46 --> Input Class Initialized
INFO - 2019-08-19 18:26:46 --> Language Class Initialized
INFO - 2019-08-19 18:26:46 --> URI Class Initialized
INFO - 2019-08-19 18:26:46 --> Router Class Initialized
INFO - 2019-08-19 18:26:46 --> Output Class Initialized
INFO - 2019-08-19 18:26:46 --> Security Class Initialized
DEBUG - 2019-08-19 18:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:26:46 --> Input Class Initialized
INFO - 2019-08-19 18:26:46 --> Language Class Initialized
INFO - 2019-08-19 18:26:46 --> Loader Class Initialized
INFO - 2019-08-19 18:26:46 --> Helper loaded: url_helper
INFO - 2019-08-19 18:26:46 --> Helper loaded: html_helper
INFO - 2019-08-19 18:26:46 --> Helper loaded: form_helper
INFO - 2019-08-19 18:26:46 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:26:46 --> Helper loaded: date_helper
INFO - 2019-08-19 18:26:46 --> Form Validation Class Initialized
INFO - 2019-08-19 18:26:46 --> Loader Class Initialized
INFO - 2019-08-19 18:26:46 --> Helper loaded: url_helper
INFO - 2019-08-19 18:26:46 --> Helper loaded: html_helper
INFO - 2019-08-19 18:26:46 --> Helper loaded: form_helper
INFO - 2019-08-19 18:26:46 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:26:46 --> Helper loaded: date_helper
INFO - 2019-08-19 18:26:46 --> Form Validation Class Initialized
INFO - 2019-08-19 18:26:46 --> Email Class Initialized
DEBUG - 2019-08-19 18:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:26:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:26:46 --> Pagination Class Initialized
INFO - 2019-08-19 18:26:46 --> Email Class Initialized
DEBUG - 2019-08-19 18:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:26:46 --> Database Driver Class Initialized
INFO - 2019-08-19 18:26:46 --> Database Driver Class Initialized
INFO - 2019-08-19 18:26:46 --> Controller Class Initialized
INFO - 2019-08-19 18:26:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:26:46 --> Final output sent to browser
DEBUG - 2019-08-19 18:26:46 --> Total execution time: 0.3460
INFO - 2019-08-19 18:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:26:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:26:46 --> Pagination Class Initialized
INFO - 2019-08-19 18:26:46 --> Database Driver Class Initialized
INFO - 2019-08-19 18:26:46 --> Database Driver Class Initialized
INFO - 2019-08-19 18:26:46 --> Controller Class Initialized
INFO - 2019-08-19 18:26:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:26:46 --> Final output sent to browser
DEBUG - 2019-08-19 18:26:46 --> Total execution time: 0.3990
INFO - 2019-08-19 18:26:59 --> Config Class Initialized
INFO - 2019-08-19 18:26:59 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:26:59 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:26:59 --> Utf8 Class Initialized
INFO - 2019-08-19 18:26:59 --> URI Class Initialized
INFO - 2019-08-19 18:26:59 --> Router Class Initialized
INFO - 2019-08-19 18:26:59 --> Output Class Initialized
INFO - 2019-08-19 18:26:59 --> Security Class Initialized
DEBUG - 2019-08-19 18:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:26:59 --> Input Class Initialized
INFO - 2019-08-19 18:26:59 --> Language Class Initialized
INFO - 2019-08-19 18:26:59 --> Loader Class Initialized
INFO - 2019-08-19 18:26:59 --> Helper loaded: url_helper
INFO - 2019-08-19 18:26:59 --> Helper loaded: html_helper
INFO - 2019-08-19 18:26:59 --> Helper loaded: form_helper
INFO - 2019-08-19 18:26:59 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:26:59 --> Helper loaded: date_helper
INFO - 2019-08-19 18:26:59 --> Form Validation Class Initialized
INFO - 2019-08-19 18:26:59 --> Email Class Initialized
DEBUG - 2019-08-19 18:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:26:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:26:59 --> Pagination Class Initialized
INFO - 2019-08-19 18:26:59 --> Database Driver Class Initialized
INFO - 2019-08-19 18:26:59 --> Database Driver Class Initialized
INFO - 2019-08-19 18:26:59 --> Controller Class Initialized
ERROR - 2019-08-19 18:26:59 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-19 18:27:00 --> Config Class Initialized
INFO - 2019-08-19 18:27:00 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:27:00 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:27:00 --> Utf8 Class Initialized
INFO - 2019-08-19 18:27:00 --> URI Class Initialized
INFO - 2019-08-19 18:27:00 --> Router Class Initialized
INFO - 2019-08-19 18:27:00 --> Output Class Initialized
INFO - 2019-08-19 18:27:00 --> Security Class Initialized
DEBUG - 2019-08-19 18:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:27:00 --> Input Class Initialized
INFO - 2019-08-19 18:27:00 --> Language Class Initialized
INFO - 2019-08-19 18:27:00 --> Loader Class Initialized
INFO - 2019-08-19 18:27:00 --> Helper loaded: url_helper
INFO - 2019-08-19 18:27:00 --> Helper loaded: html_helper
INFO - 2019-08-19 18:27:00 --> Helper loaded: form_helper
INFO - 2019-08-19 18:27:00 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:27:00 --> Helper loaded: date_helper
INFO - 2019-08-19 18:27:00 --> Form Validation Class Initialized
INFO - 2019-08-19 18:27:00 --> Email Class Initialized
DEBUG - 2019-08-19 18:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:27:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:27:01 --> Pagination Class Initialized
INFO - 2019-08-19 18:27:01 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:01 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:01 --> Controller Class Initialized
ERROR - 2019-08-19 18:27:01 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-19 18:27:01 --> Config Class Initialized
INFO - 2019-08-19 18:27:01 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:27:01 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:27:01 --> Utf8 Class Initialized
INFO - 2019-08-19 18:27:01 --> URI Class Initialized
INFO - 2019-08-19 18:27:01 --> Router Class Initialized
INFO - 2019-08-19 18:27:01 --> Output Class Initialized
INFO - 2019-08-19 18:27:01 --> Security Class Initialized
DEBUG - 2019-08-19 18:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:27:01 --> Input Class Initialized
INFO - 2019-08-19 18:27:01 --> Language Class Initialized
INFO - 2019-08-19 18:27:01 --> Loader Class Initialized
INFO - 2019-08-19 18:27:01 --> Helper loaded: url_helper
INFO - 2019-08-19 18:27:01 --> Helper loaded: html_helper
INFO - 2019-08-19 18:27:01 --> Helper loaded: form_helper
INFO - 2019-08-19 18:27:01 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:27:01 --> Helper loaded: date_helper
INFO - 2019-08-19 18:27:01 --> Form Validation Class Initialized
INFO - 2019-08-19 18:27:01 --> Email Class Initialized
DEBUG - 2019-08-19 18:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:27:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:27:01 --> Pagination Class Initialized
INFO - 2019-08-19 18:27:01 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:01 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:01 --> Controller Class Initialized
ERROR - 2019-08-19 18:27:01 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-19 18:27:02 --> Config Class Initialized
INFO - 2019-08-19 18:27:02 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:27:02 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:27:02 --> Utf8 Class Initialized
INFO - 2019-08-19 18:27:02 --> URI Class Initialized
INFO - 2019-08-19 18:27:02 --> Router Class Initialized
INFO - 2019-08-19 18:27:02 --> Output Class Initialized
INFO - 2019-08-19 18:27:02 --> Security Class Initialized
DEBUG - 2019-08-19 18:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:27:02 --> Input Class Initialized
INFO - 2019-08-19 18:27:02 --> Language Class Initialized
INFO - 2019-08-19 18:27:02 --> Loader Class Initialized
INFO - 2019-08-19 18:27:02 --> Helper loaded: url_helper
INFO - 2019-08-19 18:27:02 --> Helper loaded: html_helper
INFO - 2019-08-19 18:27:02 --> Helper loaded: form_helper
INFO - 2019-08-19 18:27:02 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:27:02 --> Helper loaded: date_helper
INFO - 2019-08-19 18:27:02 --> Form Validation Class Initialized
INFO - 2019-08-19 18:27:02 --> Email Class Initialized
DEBUG - 2019-08-19 18:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:27:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:27:02 --> Pagination Class Initialized
INFO - 2019-08-19 18:27:02 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:02 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:02 --> Controller Class Initialized
ERROR - 2019-08-19 18:27:02 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-19 18:27:02 --> Config Class Initialized
INFO - 2019-08-19 18:27:02 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:27:02 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:27:02 --> Utf8 Class Initialized
INFO - 2019-08-19 18:27:02 --> URI Class Initialized
INFO - 2019-08-19 18:27:02 --> Router Class Initialized
INFO - 2019-08-19 18:27:02 --> Output Class Initialized
INFO - 2019-08-19 18:27:02 --> Security Class Initialized
DEBUG - 2019-08-19 18:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:27:02 --> Input Class Initialized
INFO - 2019-08-19 18:27:02 --> Language Class Initialized
INFO - 2019-08-19 18:27:02 --> Loader Class Initialized
INFO - 2019-08-19 18:27:02 --> Helper loaded: url_helper
INFO - 2019-08-19 18:27:02 --> Helper loaded: html_helper
INFO - 2019-08-19 18:27:02 --> Helper loaded: form_helper
INFO - 2019-08-19 18:27:02 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:27:02 --> Helper loaded: date_helper
INFO - 2019-08-19 18:27:02 --> Form Validation Class Initialized
INFO - 2019-08-19 18:27:02 --> Email Class Initialized
DEBUG - 2019-08-19 18:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:27:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:27:02 --> Pagination Class Initialized
INFO - 2019-08-19 18:27:02 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:02 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:02 --> Controller Class Initialized
ERROR - 2019-08-19 18:27:02 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-19 18:27:03 --> Config Class Initialized
INFO - 2019-08-19 18:27:03 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:27:03 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:27:03 --> Utf8 Class Initialized
INFO - 2019-08-19 18:27:03 --> URI Class Initialized
INFO - 2019-08-19 18:27:03 --> Router Class Initialized
INFO - 2019-08-19 18:27:03 --> Output Class Initialized
INFO - 2019-08-19 18:27:03 --> Security Class Initialized
DEBUG - 2019-08-19 18:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:27:03 --> Input Class Initialized
INFO - 2019-08-19 18:27:03 --> Language Class Initialized
INFO - 2019-08-19 18:27:03 --> Loader Class Initialized
INFO - 2019-08-19 18:27:03 --> Helper loaded: url_helper
INFO - 2019-08-19 18:27:03 --> Helper loaded: html_helper
INFO - 2019-08-19 18:27:03 --> Helper loaded: form_helper
INFO - 2019-08-19 18:27:03 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:27:03 --> Helper loaded: date_helper
INFO - 2019-08-19 18:27:03 --> Form Validation Class Initialized
INFO - 2019-08-19 18:27:03 --> Email Class Initialized
DEBUG - 2019-08-19 18:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:27:03 --> Pagination Class Initialized
INFO - 2019-08-19 18:27:03 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:03 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:03 --> Controller Class Initialized
ERROR - 2019-08-19 18:27:03 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-19 18:27:09 --> Config Class Initialized
INFO - 2019-08-19 18:27:09 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:27:09 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:27:09 --> Utf8 Class Initialized
INFO - 2019-08-19 18:27:09 --> URI Class Initialized
INFO - 2019-08-19 18:27:09 --> Router Class Initialized
INFO - 2019-08-19 18:27:09 --> Output Class Initialized
INFO - 2019-08-19 18:27:09 --> Security Class Initialized
DEBUG - 2019-08-19 18:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:27:09 --> Input Class Initialized
INFO - 2019-08-19 18:27:09 --> Language Class Initialized
INFO - 2019-08-19 18:27:09 --> Loader Class Initialized
INFO - 2019-08-19 18:27:09 --> Helper loaded: url_helper
INFO - 2019-08-19 18:27:09 --> Helper loaded: html_helper
INFO - 2019-08-19 18:27:09 --> Helper loaded: form_helper
INFO - 2019-08-19 18:27:09 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:27:09 --> Helper loaded: date_helper
INFO - 2019-08-19 18:27:09 --> Form Validation Class Initialized
INFO - 2019-08-19 18:27:09 --> Email Class Initialized
DEBUG - 2019-08-19 18:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:27:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:27:09 --> Pagination Class Initialized
INFO - 2019-08-19 18:27:09 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:09 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:09 --> Controller Class Initialized
INFO - 2019-08-19 18:27:09 --> Final output sent to browser
DEBUG - 2019-08-19 18:27:09 --> Total execution time: 0.2440
INFO - 2019-08-19 18:27:14 --> Config Class Initialized
INFO - 2019-08-19 18:27:14 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:27:14 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:27:14 --> Utf8 Class Initialized
INFO - 2019-08-19 18:27:14 --> URI Class Initialized
INFO - 2019-08-19 18:27:15 --> Router Class Initialized
INFO - 2019-08-19 18:27:15 --> Output Class Initialized
INFO - 2019-08-19 18:27:15 --> Security Class Initialized
DEBUG - 2019-08-19 18:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:27:15 --> Input Class Initialized
INFO - 2019-08-19 18:27:15 --> Language Class Initialized
INFO - 2019-08-19 18:27:15 --> Loader Class Initialized
INFO - 2019-08-19 18:27:15 --> Helper loaded: url_helper
INFO - 2019-08-19 18:27:15 --> Helper loaded: html_helper
INFO - 2019-08-19 18:27:15 --> Helper loaded: form_helper
INFO - 2019-08-19 18:27:15 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:27:15 --> Helper loaded: date_helper
INFO - 2019-08-19 18:27:15 --> Form Validation Class Initialized
INFO - 2019-08-19 18:27:15 --> Email Class Initialized
DEBUG - 2019-08-19 18:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:27:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:27:15 --> Pagination Class Initialized
INFO - 2019-08-19 18:27:15 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:15 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:15 --> Controller Class Initialized
INFO - 2019-08-19 18:27:15 --> Final output sent to browser
DEBUG - 2019-08-19 18:27:15 --> Total execution time: 0.2320
INFO - 2019-08-19 18:27:18 --> Config Class Initialized
INFO - 2019-08-19 18:27:18 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:27:18 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:27:18 --> Utf8 Class Initialized
INFO - 2019-08-19 18:27:18 --> URI Class Initialized
INFO - 2019-08-19 18:27:18 --> Router Class Initialized
INFO - 2019-08-19 18:27:18 --> Output Class Initialized
INFO - 2019-08-19 18:27:18 --> Security Class Initialized
DEBUG - 2019-08-19 18:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:27:18 --> Input Class Initialized
INFO - 2019-08-19 18:27:18 --> Language Class Initialized
INFO - 2019-08-19 18:27:18 --> Loader Class Initialized
INFO - 2019-08-19 18:27:18 --> Helper loaded: url_helper
INFO - 2019-08-19 18:27:18 --> Helper loaded: html_helper
INFO - 2019-08-19 18:27:18 --> Helper loaded: form_helper
INFO - 2019-08-19 18:27:18 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:27:18 --> Helper loaded: date_helper
INFO - 2019-08-19 18:27:18 --> Form Validation Class Initialized
INFO - 2019-08-19 18:27:18 --> Email Class Initialized
DEBUG - 2019-08-19 18:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:27:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:27:18 --> Pagination Class Initialized
INFO - 2019-08-19 18:27:19 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:19 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:19 --> Controller Class Initialized
INFO - 2019-08-19 18:27:19 --> Final output sent to browser
DEBUG - 2019-08-19 18:27:19 --> Total execution time: 0.1780
INFO - 2019-08-19 18:27:30 --> Config Class Initialized
INFO - 2019-08-19 18:27:30 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:27:30 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:27:30 --> Utf8 Class Initialized
INFO - 2019-08-19 18:27:30 --> URI Class Initialized
INFO - 2019-08-19 18:27:30 --> Router Class Initialized
INFO - 2019-08-19 18:27:30 --> Output Class Initialized
INFO - 2019-08-19 18:27:30 --> Security Class Initialized
DEBUG - 2019-08-19 18:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:27:30 --> Input Class Initialized
INFO - 2019-08-19 18:27:30 --> Language Class Initialized
INFO - 2019-08-19 18:27:30 --> Loader Class Initialized
INFO - 2019-08-19 18:27:30 --> Helper loaded: url_helper
INFO - 2019-08-19 18:27:30 --> Helper loaded: html_helper
INFO - 2019-08-19 18:27:30 --> Helper loaded: form_helper
INFO - 2019-08-19 18:27:30 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:27:30 --> Helper loaded: date_helper
INFO - 2019-08-19 18:27:30 --> Form Validation Class Initialized
INFO - 2019-08-19 18:27:30 --> Email Class Initialized
DEBUG - 2019-08-19 18:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:27:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:27:30 --> Pagination Class Initialized
INFO - 2019-08-19 18:27:30 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:30 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:30 --> Controller Class Initialized
INFO - 2019-08-19 18:27:30 --> Final output sent to browser
DEBUG - 2019-08-19 18:27:30 --> Total execution time: 0.2138
INFO - 2019-08-19 18:27:34 --> Config Class Initialized
INFO - 2019-08-19 18:27:34 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:27:34 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:27:34 --> Utf8 Class Initialized
INFO - 2019-08-19 18:27:34 --> URI Class Initialized
INFO - 2019-08-19 18:27:34 --> Router Class Initialized
INFO - 2019-08-19 18:27:34 --> Output Class Initialized
INFO - 2019-08-19 18:27:34 --> Security Class Initialized
DEBUG - 2019-08-19 18:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:27:34 --> Input Class Initialized
INFO - 2019-08-19 18:27:34 --> Language Class Initialized
INFO - 2019-08-19 18:27:34 --> Loader Class Initialized
INFO - 2019-08-19 18:27:34 --> Helper loaded: url_helper
INFO - 2019-08-19 18:27:34 --> Helper loaded: html_helper
INFO - 2019-08-19 18:27:34 --> Helper loaded: form_helper
INFO - 2019-08-19 18:27:34 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:27:34 --> Helper loaded: date_helper
INFO - 2019-08-19 18:27:34 --> Form Validation Class Initialized
INFO - 2019-08-19 18:27:34 --> Email Class Initialized
DEBUG - 2019-08-19 18:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:27:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:27:34 --> Pagination Class Initialized
INFO - 2019-08-19 18:27:35 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:35 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:35 --> Controller Class Initialized
INFO - 2019-08-19 18:27:35 --> Final output sent to browser
DEBUG - 2019-08-19 18:27:35 --> Total execution time: 0.2650
INFO - 2019-08-19 18:27:50 --> Config Class Initialized
INFO - 2019-08-19 18:27:50 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:27:50 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:27:50 --> Utf8 Class Initialized
INFO - 2019-08-19 18:27:50 --> URI Class Initialized
INFO - 2019-08-19 18:27:50 --> Router Class Initialized
INFO - 2019-08-19 18:27:50 --> Output Class Initialized
INFO - 2019-08-19 18:27:50 --> Security Class Initialized
DEBUG - 2019-08-19 18:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:27:50 --> Input Class Initialized
INFO - 2019-08-19 18:27:50 --> Language Class Initialized
INFO - 2019-08-19 18:27:50 --> Loader Class Initialized
INFO - 2019-08-19 18:27:50 --> Helper loaded: url_helper
INFO - 2019-08-19 18:27:50 --> Helper loaded: html_helper
INFO - 2019-08-19 18:27:50 --> Helper loaded: form_helper
INFO - 2019-08-19 18:27:50 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:27:50 --> Helper loaded: date_helper
INFO - 2019-08-19 18:27:50 --> Form Validation Class Initialized
INFO - 2019-08-19 18:27:50 --> Email Class Initialized
DEBUG - 2019-08-19 18:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:27:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:27:50 --> Pagination Class Initialized
INFO - 2019-08-19 18:27:50 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:50 --> Database Driver Class Initialized
INFO - 2019-08-19 18:27:50 --> Controller Class Initialized
INFO - 2019-08-19 18:27:50 --> Final output sent to browser
DEBUG - 2019-08-19 18:27:50 --> Total execution time: 0.3376
INFO - 2019-08-19 18:28:09 --> Config Class Initialized
INFO - 2019-08-19 18:28:09 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:28:09 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:28:09 --> Utf8 Class Initialized
INFO - 2019-08-19 18:28:09 --> URI Class Initialized
INFO - 2019-08-19 18:28:09 --> Router Class Initialized
INFO - 2019-08-19 18:28:09 --> Output Class Initialized
INFO - 2019-08-19 18:28:09 --> Security Class Initialized
DEBUG - 2019-08-19 18:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:28:09 --> Input Class Initialized
INFO - 2019-08-19 18:28:09 --> Language Class Initialized
INFO - 2019-08-19 18:28:09 --> Loader Class Initialized
INFO - 2019-08-19 18:28:09 --> Helper loaded: url_helper
INFO - 2019-08-19 18:28:09 --> Helper loaded: html_helper
INFO - 2019-08-19 18:28:09 --> Helper loaded: form_helper
INFO - 2019-08-19 18:28:09 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:28:09 --> Helper loaded: date_helper
INFO - 2019-08-19 18:28:09 --> Form Validation Class Initialized
INFO - 2019-08-19 18:28:09 --> Email Class Initialized
DEBUG - 2019-08-19 18:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:28:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:28:09 --> Pagination Class Initialized
INFO - 2019-08-19 18:28:09 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:09 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:09 --> Controller Class Initialized
INFO - 2019-08-19 18:28:09 --> Final output sent to browser
DEBUG - 2019-08-19 18:28:09 --> Total execution time: 0.2356
INFO - 2019-08-19 18:28:22 --> Config Class Initialized
INFO - 2019-08-19 18:28:22 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:28:22 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:28:22 --> Utf8 Class Initialized
INFO - 2019-08-19 18:28:22 --> URI Class Initialized
INFO - 2019-08-19 18:28:22 --> Router Class Initialized
INFO - 2019-08-19 18:28:22 --> Output Class Initialized
INFO - 2019-08-19 18:28:22 --> Security Class Initialized
DEBUG - 2019-08-19 18:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:28:22 --> Input Class Initialized
INFO - 2019-08-19 18:28:22 --> Language Class Initialized
INFO - 2019-08-19 18:28:22 --> Loader Class Initialized
INFO - 2019-08-19 18:28:22 --> Helper loaded: url_helper
INFO - 2019-08-19 18:28:22 --> Helper loaded: html_helper
INFO - 2019-08-19 18:28:22 --> Helper loaded: form_helper
INFO - 2019-08-19 18:28:22 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:28:22 --> Helper loaded: date_helper
INFO - 2019-08-19 18:28:22 --> Form Validation Class Initialized
INFO - 2019-08-19 18:28:22 --> Email Class Initialized
DEBUG - 2019-08-19 18:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:28:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:28:22 --> Pagination Class Initialized
INFO - 2019-08-19 18:28:22 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:22 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:22 --> Controller Class Initialized
INFO - 2019-08-19 18:28:22 --> Final output sent to browser
DEBUG - 2019-08-19 18:28:22 --> Total execution time: 0.2360
INFO - 2019-08-19 18:28:26 --> Config Class Initialized
INFO - 2019-08-19 18:28:26 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:28:26 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:28:26 --> Utf8 Class Initialized
INFO - 2019-08-19 18:28:26 --> URI Class Initialized
INFO - 2019-08-19 18:28:26 --> Router Class Initialized
INFO - 2019-08-19 18:28:26 --> Output Class Initialized
INFO - 2019-08-19 18:28:26 --> Security Class Initialized
DEBUG - 2019-08-19 18:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:28:27 --> Input Class Initialized
INFO - 2019-08-19 18:28:27 --> Language Class Initialized
INFO - 2019-08-19 18:28:27 --> Loader Class Initialized
INFO - 2019-08-19 18:28:27 --> Helper loaded: url_helper
INFO - 2019-08-19 18:28:27 --> Helper loaded: html_helper
INFO - 2019-08-19 18:28:27 --> Helper loaded: form_helper
INFO - 2019-08-19 18:28:27 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:28:27 --> Helper loaded: date_helper
INFO - 2019-08-19 18:28:27 --> Form Validation Class Initialized
INFO - 2019-08-19 18:28:27 --> Email Class Initialized
DEBUG - 2019-08-19 18:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:28:27 --> Pagination Class Initialized
INFO - 2019-08-19 18:28:27 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:27 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:27 --> Controller Class Initialized
INFO - 2019-08-19 18:28:27 --> Final output sent to browser
DEBUG - 2019-08-19 18:28:27 --> Total execution time: 0.2000
INFO - 2019-08-19 18:28:33 --> Config Class Initialized
INFO - 2019-08-19 18:28:33 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:28:33 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:28:33 --> Utf8 Class Initialized
INFO - 2019-08-19 18:28:33 --> URI Class Initialized
INFO - 2019-08-19 18:28:33 --> Router Class Initialized
INFO - 2019-08-19 18:28:33 --> Output Class Initialized
INFO - 2019-08-19 18:28:33 --> Security Class Initialized
DEBUG - 2019-08-19 18:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:28:33 --> Input Class Initialized
INFO - 2019-08-19 18:28:33 --> Language Class Initialized
INFO - 2019-08-19 18:28:33 --> Loader Class Initialized
INFO - 2019-08-19 18:28:33 --> Helper loaded: url_helper
INFO - 2019-08-19 18:28:33 --> Helper loaded: html_helper
INFO - 2019-08-19 18:28:33 --> Helper loaded: form_helper
INFO - 2019-08-19 18:28:33 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:28:33 --> Helper loaded: date_helper
INFO - 2019-08-19 18:28:33 --> Form Validation Class Initialized
INFO - 2019-08-19 18:28:33 --> Email Class Initialized
DEBUG - 2019-08-19 18:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:28:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:28:33 --> Pagination Class Initialized
INFO - 2019-08-19 18:28:33 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:33 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:33 --> Controller Class Initialized
INFO - 2019-08-19 18:28:33 --> Final output sent to browser
DEBUG - 2019-08-19 18:28:33 --> Total execution time: 0.1880
INFO - 2019-08-19 18:28:40 --> Config Class Initialized
INFO - 2019-08-19 18:28:40 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:28:40 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:28:40 --> Utf8 Class Initialized
INFO - 2019-08-19 18:28:40 --> URI Class Initialized
INFO - 2019-08-19 18:28:40 --> Router Class Initialized
INFO - 2019-08-19 18:28:40 --> Output Class Initialized
INFO - 2019-08-19 18:28:40 --> Security Class Initialized
DEBUG - 2019-08-19 18:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:28:40 --> Input Class Initialized
INFO - 2019-08-19 18:28:40 --> Language Class Initialized
INFO - 2019-08-19 18:28:40 --> Loader Class Initialized
INFO - 2019-08-19 18:28:40 --> Helper loaded: url_helper
INFO - 2019-08-19 18:28:40 --> Helper loaded: html_helper
INFO - 2019-08-19 18:28:40 --> Helper loaded: form_helper
INFO - 2019-08-19 18:28:40 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:28:40 --> Helper loaded: date_helper
INFO - 2019-08-19 18:28:40 --> Form Validation Class Initialized
INFO - 2019-08-19 18:28:40 --> Email Class Initialized
DEBUG - 2019-08-19 18:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:28:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:28:40 --> Pagination Class Initialized
INFO - 2019-08-19 18:28:40 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:41 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:41 --> Controller Class Initialized
INFO - 2019-08-19 18:28:41 --> Final output sent to browser
DEBUG - 2019-08-19 18:28:41 --> Total execution time: 0.2070
INFO - 2019-08-19 18:28:45 --> Config Class Initialized
INFO - 2019-08-19 18:28:45 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:28:45 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:28:45 --> Utf8 Class Initialized
INFO - 2019-08-19 18:28:45 --> URI Class Initialized
INFO - 2019-08-19 18:28:45 --> Router Class Initialized
INFO - 2019-08-19 18:28:45 --> Output Class Initialized
INFO - 2019-08-19 18:28:45 --> Security Class Initialized
DEBUG - 2019-08-19 18:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:28:45 --> Input Class Initialized
INFO - 2019-08-19 18:28:45 --> Language Class Initialized
INFO - 2019-08-19 18:28:45 --> Loader Class Initialized
INFO - 2019-08-19 18:28:46 --> Helper loaded: url_helper
INFO - 2019-08-19 18:28:46 --> Helper loaded: html_helper
INFO - 2019-08-19 18:28:46 --> Helper loaded: form_helper
INFO - 2019-08-19 18:28:46 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:28:46 --> Helper loaded: date_helper
INFO - 2019-08-19 18:28:46 --> Form Validation Class Initialized
INFO - 2019-08-19 18:28:46 --> Email Class Initialized
DEBUG - 2019-08-19 18:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:28:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:28:46 --> Pagination Class Initialized
INFO - 2019-08-19 18:28:46 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:46 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:46 --> Controller Class Initialized
INFO - 2019-08-19 18:28:46 --> Final output sent to browser
DEBUG - 2019-08-19 18:28:46 --> Total execution time: 0.1960
INFO - 2019-08-19 18:28:50 --> Config Class Initialized
INFO - 2019-08-19 18:28:50 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:28:50 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:28:50 --> Utf8 Class Initialized
INFO - 2019-08-19 18:28:50 --> URI Class Initialized
INFO - 2019-08-19 18:28:51 --> Router Class Initialized
INFO - 2019-08-19 18:28:51 --> Output Class Initialized
INFO - 2019-08-19 18:28:51 --> Security Class Initialized
DEBUG - 2019-08-19 18:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:28:51 --> Input Class Initialized
INFO - 2019-08-19 18:28:51 --> Language Class Initialized
INFO - 2019-08-19 18:28:51 --> Loader Class Initialized
INFO - 2019-08-19 18:28:51 --> Helper loaded: url_helper
INFO - 2019-08-19 18:28:51 --> Helper loaded: html_helper
INFO - 2019-08-19 18:28:51 --> Helper loaded: form_helper
INFO - 2019-08-19 18:28:51 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:28:51 --> Helper loaded: date_helper
INFO - 2019-08-19 18:28:51 --> Form Validation Class Initialized
INFO - 2019-08-19 18:28:51 --> Email Class Initialized
DEBUG - 2019-08-19 18:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:28:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:28:51 --> Pagination Class Initialized
INFO - 2019-08-19 18:28:51 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:51 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:51 --> Controller Class Initialized
INFO - 2019-08-19 18:28:51 --> Final output sent to browser
DEBUG - 2019-08-19 18:28:51 --> Total execution time: 0.2420
INFO - 2019-08-19 18:28:53 --> Config Class Initialized
INFO - 2019-08-19 18:28:53 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:28:53 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:28:53 --> Utf8 Class Initialized
INFO - 2019-08-19 18:28:53 --> URI Class Initialized
INFO - 2019-08-19 18:28:53 --> Router Class Initialized
INFO - 2019-08-19 18:28:53 --> Output Class Initialized
INFO - 2019-08-19 18:28:53 --> Security Class Initialized
DEBUG - 2019-08-19 18:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:28:53 --> Input Class Initialized
INFO - 2019-08-19 18:28:53 --> Language Class Initialized
INFO - 2019-08-19 18:28:53 --> Loader Class Initialized
INFO - 2019-08-19 18:28:53 --> Helper loaded: url_helper
INFO - 2019-08-19 18:28:53 --> Helper loaded: html_helper
INFO - 2019-08-19 18:28:53 --> Helper loaded: form_helper
INFO - 2019-08-19 18:28:53 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:28:53 --> Helper loaded: date_helper
INFO - 2019-08-19 18:28:53 --> Form Validation Class Initialized
INFO - 2019-08-19 18:28:53 --> Email Class Initialized
DEBUG - 2019-08-19 18:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:28:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:28:53 --> Pagination Class Initialized
INFO - 2019-08-19 18:28:53 --> Config Class Initialized
INFO - 2019-08-19 18:28:53 --> Hooks Class Initialized
INFO - 2019-08-19 18:28:54 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:54 --> Database Driver Class Initialized
DEBUG - 2019-08-19 18:28:54 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:28:54 --> Utf8 Class Initialized
INFO - 2019-08-19 18:28:54 --> URI Class Initialized
INFO - 2019-08-19 18:28:54 --> Router Class Initialized
INFO - 2019-08-19 18:28:54 --> Output Class Initialized
INFO - 2019-08-19 18:28:54 --> Security Class Initialized
DEBUG - 2019-08-19 18:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:28:54 --> Input Class Initialized
INFO - 2019-08-19 18:28:54 --> Language Class Initialized
INFO - 2019-08-19 18:28:54 --> Loader Class Initialized
INFO - 2019-08-19 18:28:54 --> Helper loaded: url_helper
INFO - 2019-08-19 18:28:54 --> Helper loaded: html_helper
INFO - 2019-08-19 18:28:54 --> Helper loaded: form_helper
INFO - 2019-08-19 18:28:54 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:28:54 --> Controller Class Initialized
INFO - 2019-08-19 18:28:54 --> Helper loaded: date_helper
INFO - 2019-08-19 18:28:54 --> Form Validation Class Initialized
INFO - 2019-08-19 18:28:54 --> Email Class Initialized
INFO - 2019-08-19 18:28:54 --> Final output sent to browser
DEBUG - 2019-08-19 18:28:54 --> Total execution time: 0.5640
DEBUG - 2019-08-19 18:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:28:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:28:54 --> Pagination Class Initialized
INFO - 2019-08-19 18:28:54 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:54 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:54 --> Controller Class Initialized
INFO - 2019-08-19 18:28:54 --> Final output sent to browser
DEBUG - 2019-08-19 18:28:54 --> Total execution time: 0.5030
INFO - 2019-08-19 18:28:54 --> Config Class Initialized
INFO - 2019-08-19 18:28:54 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:28:54 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:28:54 --> Utf8 Class Initialized
INFO - 2019-08-19 18:28:54 --> URI Class Initialized
INFO - 2019-08-19 18:28:54 --> Router Class Initialized
INFO - 2019-08-19 18:28:54 --> Output Class Initialized
INFO - 2019-08-19 18:28:54 --> Security Class Initialized
DEBUG - 2019-08-19 18:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:28:54 --> Input Class Initialized
INFO - 2019-08-19 18:28:54 --> Language Class Initialized
INFO - 2019-08-19 18:28:55 --> Loader Class Initialized
INFO - 2019-08-19 18:28:55 --> Helper loaded: url_helper
INFO - 2019-08-19 18:28:55 --> Helper loaded: html_helper
INFO - 2019-08-19 18:28:55 --> Helper loaded: form_helper
INFO - 2019-08-19 18:28:55 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:28:55 --> Config Class Initialized
INFO - 2019-08-19 18:28:55 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:28:55 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:28:55 --> Utf8 Class Initialized
INFO - 2019-08-19 18:28:55 --> URI Class Initialized
INFO - 2019-08-19 18:28:55 --> Router Class Initialized
INFO - 2019-08-19 18:28:55 --> Output Class Initialized
INFO - 2019-08-19 18:28:55 --> Security Class Initialized
DEBUG - 2019-08-19 18:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:28:55 --> Input Class Initialized
INFO - 2019-08-19 18:28:55 --> Language Class Initialized
INFO - 2019-08-19 18:28:55 --> Helper loaded: date_helper
INFO - 2019-08-19 18:28:55 --> Form Validation Class Initialized
INFO - 2019-08-19 18:28:55 --> Loader Class Initialized
INFO - 2019-08-19 18:28:55 --> Email Class Initialized
DEBUG - 2019-08-19 18:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:28:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:28:55 --> Pagination Class Initialized
INFO - 2019-08-19 18:28:55 --> Helper loaded: url_helper
INFO - 2019-08-19 18:28:55 --> Helper loaded: html_helper
INFO - 2019-08-19 18:28:55 --> Helper loaded: form_helper
INFO - 2019-08-19 18:28:55 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:55 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:55 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:28:55 --> Helper loaded: date_helper
INFO - 2019-08-19 18:28:55 --> Form Validation Class Initialized
INFO - 2019-08-19 18:28:55 --> Controller Class Initialized
INFO - 2019-08-19 18:28:55 --> Email Class Initialized
DEBUG - 2019-08-19 18:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:28:55 --> Final output sent to browser
DEBUG - 2019-08-19 18:28:55 --> Total execution time: 0.4610
INFO - 2019-08-19 18:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:28:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:28:55 --> Pagination Class Initialized
INFO - 2019-08-19 18:28:55 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:55 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:55 --> Controller Class Initialized
INFO - 2019-08-19 18:28:55 --> Final output sent to browser
DEBUG - 2019-08-19 18:28:55 --> Total execution time: 0.3910
INFO - 2019-08-19 18:28:58 --> Config Class Initialized
INFO - 2019-08-19 18:28:58 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:28:58 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:28:58 --> Utf8 Class Initialized
INFO - 2019-08-19 18:28:58 --> URI Class Initialized
INFO - 2019-08-19 18:28:58 --> Router Class Initialized
INFO - 2019-08-19 18:28:58 --> Output Class Initialized
INFO - 2019-08-19 18:28:58 --> Security Class Initialized
DEBUG - 2019-08-19 18:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:28:58 --> Input Class Initialized
INFO - 2019-08-19 18:28:58 --> Language Class Initialized
INFO - 2019-08-19 18:28:58 --> Loader Class Initialized
INFO - 2019-08-19 18:28:58 --> Helper loaded: url_helper
INFO - 2019-08-19 18:28:58 --> Helper loaded: html_helper
INFO - 2019-08-19 18:28:58 --> Helper loaded: form_helper
INFO - 2019-08-19 18:28:58 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:28:58 --> Helper loaded: date_helper
INFO - 2019-08-19 18:28:58 --> Form Validation Class Initialized
INFO - 2019-08-19 18:28:58 --> Email Class Initialized
DEBUG - 2019-08-19 18:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:28:58 --> Pagination Class Initialized
INFO - 2019-08-19 18:28:58 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:58 --> Database Driver Class Initialized
INFO - 2019-08-19 18:28:58 --> Controller Class Initialized
INFO - 2019-08-19 18:28:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:28:58 --> Final output sent to browser
DEBUG - 2019-08-19 18:28:58 --> Total execution time: 0.2470
INFO - 2019-08-19 18:29:00 --> Config Class Initialized
INFO - 2019-08-19 18:29:00 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:29:00 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:29:00 --> Utf8 Class Initialized
INFO - 2019-08-19 18:29:00 --> URI Class Initialized
INFO - 2019-08-19 18:29:00 --> Router Class Initialized
INFO - 2019-08-19 18:29:00 --> Output Class Initialized
INFO - 2019-08-19 18:29:00 --> Security Class Initialized
DEBUG - 2019-08-19 18:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:29:00 --> Input Class Initialized
INFO - 2019-08-19 18:29:00 --> Language Class Initialized
INFO - 2019-08-19 18:29:00 --> Loader Class Initialized
INFO - 2019-08-19 18:29:00 --> Helper loaded: url_helper
INFO - 2019-08-19 18:29:00 --> Helper loaded: html_helper
INFO - 2019-08-19 18:29:00 --> Helper loaded: form_helper
INFO - 2019-08-19 18:29:00 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:29:00 --> Helper loaded: date_helper
INFO - 2019-08-19 18:29:00 --> Form Validation Class Initialized
INFO - 2019-08-19 18:29:00 --> Email Class Initialized
DEBUG - 2019-08-19 18:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:29:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:29:00 --> Pagination Class Initialized
INFO - 2019-08-19 18:29:00 --> Database Driver Class Initialized
INFO - 2019-08-19 18:29:00 --> Database Driver Class Initialized
INFO - 2019-08-19 18:29:00 --> Controller Class Initialized
INFO - 2019-08-19 18:29:00 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:29:00 --> Final output sent to browser
DEBUG - 2019-08-19 18:29:00 --> Total execution time: 0.2350
INFO - 2019-08-19 18:29:11 --> Config Class Initialized
INFO - 2019-08-19 18:29:11 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:29:11 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:29:11 --> Utf8 Class Initialized
INFO - 2019-08-19 18:29:11 --> URI Class Initialized
INFO - 2019-08-19 18:29:11 --> Router Class Initialized
INFO - 2019-08-19 18:29:11 --> Output Class Initialized
INFO - 2019-08-19 18:29:11 --> Security Class Initialized
DEBUG - 2019-08-19 18:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:29:11 --> Input Class Initialized
INFO - 2019-08-19 18:29:11 --> Language Class Initialized
INFO - 2019-08-19 18:29:11 --> Loader Class Initialized
INFO - 2019-08-19 18:29:11 --> Helper loaded: url_helper
INFO - 2019-08-19 18:29:11 --> Helper loaded: html_helper
INFO - 2019-08-19 18:29:11 --> Helper loaded: form_helper
INFO - 2019-08-19 18:29:11 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:29:11 --> Helper loaded: date_helper
INFO - 2019-08-19 18:29:11 --> Form Validation Class Initialized
INFO - 2019-08-19 18:29:11 --> Email Class Initialized
DEBUG - 2019-08-19 18:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:29:11 --> Pagination Class Initialized
INFO - 2019-08-19 18:29:11 --> Database Driver Class Initialized
INFO - 2019-08-19 18:29:11 --> Database Driver Class Initialized
INFO - 2019-08-19 18:29:11 --> Controller Class Initialized
INFO - 2019-08-19 18:29:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:29:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_salescategory.php
INFO - 2019-08-19 18:29:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:29:11 --> Final output sent to browser
DEBUG - 2019-08-19 18:29:11 --> Total execution time: 0.2120
INFO - 2019-08-19 18:30:14 --> Config Class Initialized
INFO - 2019-08-19 18:30:14 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:30:14 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:30:14 --> Utf8 Class Initialized
INFO - 2019-08-19 18:30:14 --> URI Class Initialized
INFO - 2019-08-19 18:30:14 --> Router Class Initialized
INFO - 2019-08-19 18:30:14 --> Output Class Initialized
INFO - 2019-08-19 18:30:14 --> Security Class Initialized
DEBUG - 2019-08-19 18:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:30:14 --> Input Class Initialized
INFO - 2019-08-19 18:30:14 --> Language Class Initialized
INFO - 2019-08-19 18:30:14 --> Config Class Initialized
INFO - 2019-08-19 18:30:14 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:30:14 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:30:14 --> Utf8 Class Initialized
INFO - 2019-08-19 18:30:14 --> Loader Class Initialized
INFO - 2019-08-19 18:30:14 --> Helper loaded: url_helper
INFO - 2019-08-19 18:30:14 --> Helper loaded: html_helper
INFO - 2019-08-19 18:30:14 --> Helper loaded: form_helper
INFO - 2019-08-19 18:30:14 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:30:14 --> Helper loaded: date_helper
INFO - 2019-08-19 18:30:14 --> URI Class Initialized
INFO - 2019-08-19 18:30:14 --> Form Validation Class Initialized
INFO - 2019-08-19 18:30:14 --> Router Class Initialized
INFO - 2019-08-19 18:30:14 --> Output Class Initialized
INFO - 2019-08-19 18:30:14 --> Email Class Initialized
INFO - 2019-08-19 18:30:14 --> Security Class Initialized
DEBUG - 2019-08-19 18:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:30:14 --> Input Class Initialized
INFO - 2019-08-19 18:30:14 --> Language Class Initialized
DEBUG - 2019-08-19 18:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:30:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:30:14 --> Pagination Class Initialized
INFO - 2019-08-19 18:30:14 --> Loader Class Initialized
INFO - 2019-08-19 18:30:14 --> Helper loaded: url_helper
INFO - 2019-08-19 18:30:14 --> Helper loaded: html_helper
INFO - 2019-08-19 18:30:14 --> Helper loaded: form_helper
INFO - 2019-08-19 18:30:14 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:30:14 --> Helper loaded: date_helper
INFO - 2019-08-19 18:30:14 --> Database Driver Class Initialized
INFO - 2019-08-19 18:30:15 --> Form Validation Class Initialized
INFO - 2019-08-19 18:30:15 --> Database Driver Class Initialized
INFO - 2019-08-19 18:30:15 --> Email Class Initialized
DEBUG - 2019-08-19 18:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:30:15 --> Controller Class Initialized
INFO - 2019-08-19 18:30:15 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:30:15 --> Final output sent to browser
DEBUG - 2019-08-19 18:30:15 --> Total execution time: 0.2748
INFO - 2019-08-19 18:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:30:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:30:15 --> Pagination Class Initialized
INFO - 2019-08-19 18:30:15 --> Database Driver Class Initialized
INFO - 2019-08-19 18:30:15 --> Database Driver Class Initialized
INFO - 2019-08-19 18:30:15 --> Controller Class Initialized
INFO - 2019-08-19 18:30:15 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:30:15 --> Final output sent to browser
DEBUG - 2019-08-19 18:30:15 --> Total execution time: 0.3250
INFO - 2019-08-19 18:30:15 --> Config Class Initialized
INFO - 2019-08-19 18:30:15 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:30:15 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:30:15 --> Utf8 Class Initialized
INFO - 2019-08-19 18:30:15 --> URI Class Initialized
INFO - 2019-08-19 18:30:15 --> Router Class Initialized
INFO - 2019-08-19 18:30:15 --> Output Class Initialized
INFO - 2019-08-19 18:30:15 --> Security Class Initialized
DEBUG - 2019-08-19 18:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:30:15 --> Input Class Initialized
INFO - 2019-08-19 18:30:16 --> Language Class Initialized
INFO - 2019-08-19 18:30:16 --> Loader Class Initialized
INFO - 2019-08-19 18:30:16 --> Helper loaded: url_helper
INFO - 2019-08-19 18:30:16 --> Helper loaded: html_helper
INFO - 2019-08-19 18:30:16 --> Helper loaded: form_helper
INFO - 2019-08-19 18:30:16 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:30:16 --> Helper loaded: date_helper
INFO - 2019-08-19 18:30:16 --> Form Validation Class Initialized
INFO - 2019-08-19 18:30:16 --> Email Class Initialized
DEBUG - 2019-08-19 18:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:30:16 --> Pagination Class Initialized
INFO - 2019-08-19 18:30:16 --> Database Driver Class Initialized
INFO - 2019-08-19 18:30:16 --> Database Driver Class Initialized
INFO - 2019-08-19 18:30:16 --> Controller Class Initialized
INFO - 2019-08-19 18:30:16 --> Final output sent to browser
DEBUG - 2019-08-19 18:30:16 --> Total execution time: 0.4330
INFO - 2019-08-19 18:30:57 --> Config Class Initialized
INFO - 2019-08-19 18:30:57 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:30:57 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:30:57 --> Utf8 Class Initialized
INFO - 2019-08-19 18:30:57 --> URI Class Initialized
INFO - 2019-08-19 18:30:57 --> Router Class Initialized
INFO - 2019-08-19 18:30:57 --> Output Class Initialized
INFO - 2019-08-19 18:30:57 --> Security Class Initialized
DEBUG - 2019-08-19 18:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:30:57 --> Input Class Initialized
INFO - 2019-08-19 18:30:57 --> Language Class Initialized
INFO - 2019-08-19 18:30:57 --> Loader Class Initialized
INFO - 2019-08-19 18:30:57 --> Helper loaded: url_helper
INFO - 2019-08-19 18:30:57 --> Helper loaded: html_helper
INFO - 2019-08-19 18:30:57 --> Helper loaded: form_helper
INFO - 2019-08-19 18:30:57 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:30:57 --> Helper loaded: date_helper
INFO - 2019-08-19 18:30:57 --> Form Validation Class Initialized
INFO - 2019-08-19 18:30:57 --> Email Class Initialized
DEBUG - 2019-08-19 18:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:30:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:30:57 --> Pagination Class Initialized
INFO - 2019-08-19 18:30:57 --> Database Driver Class Initialized
INFO - 2019-08-19 18:30:57 --> Database Driver Class Initialized
INFO - 2019-08-19 18:30:57 --> Controller Class Initialized
INFO - 2019-08-19 18:30:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:30:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_sale.php
INFO - 2019-08-19 18:30:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:30:58 --> Final output sent to browser
DEBUG - 2019-08-19 18:30:58 --> Total execution time: 0.2112
INFO - 2019-08-19 18:31:40 --> Config Class Initialized
INFO - 2019-08-19 18:31:40 --> Hooks Class Initialized
INFO - 2019-08-19 18:31:40 --> Config Class Initialized
INFO - 2019-08-19 18:31:40 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:31:40 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:31:40 --> Utf8 Class Initialized
DEBUG - 2019-08-19 18:31:40 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:31:40 --> Utf8 Class Initialized
INFO - 2019-08-19 18:31:40 --> URI Class Initialized
INFO - 2019-08-19 18:31:40 --> Router Class Initialized
INFO - 2019-08-19 18:31:40 --> Output Class Initialized
INFO - 2019-08-19 18:31:40 --> Security Class Initialized
DEBUG - 2019-08-19 18:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:31:40 --> Input Class Initialized
INFO - 2019-08-19 18:31:40 --> Language Class Initialized
INFO - 2019-08-19 18:31:40 --> URI Class Initialized
INFO - 2019-08-19 18:31:40 --> Router Class Initialized
INFO - 2019-08-19 18:31:40 --> Output Class Initialized
INFO - 2019-08-19 18:31:40 --> Security Class Initialized
DEBUG - 2019-08-19 18:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:31:40 --> Input Class Initialized
INFO - 2019-08-19 18:31:40 --> Language Class Initialized
INFO - 2019-08-19 18:31:40 --> Loader Class Initialized
INFO - 2019-08-19 18:31:40 --> Helper loaded: url_helper
INFO - 2019-08-19 18:31:40 --> Helper loaded: html_helper
INFO - 2019-08-19 18:31:40 --> Helper loaded: form_helper
INFO - 2019-08-19 18:31:40 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:31:40 --> Helper loaded: date_helper
INFO - 2019-08-19 18:31:40 --> Loader Class Initialized
INFO - 2019-08-19 18:31:40 --> Helper loaded: url_helper
INFO - 2019-08-19 18:31:40 --> Helper loaded: html_helper
INFO - 2019-08-19 18:31:40 --> Helper loaded: form_helper
INFO - 2019-08-19 18:31:40 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:31:40 --> Helper loaded: date_helper
INFO - 2019-08-19 18:31:40 --> Form Validation Class Initialized
INFO - 2019-08-19 18:31:40 --> Form Validation Class Initialized
INFO - 2019-08-19 18:31:40 --> Email Class Initialized
DEBUG - 2019-08-19 18:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:31:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:31:40 --> Pagination Class Initialized
INFO - 2019-08-19 18:31:40 --> Email Class Initialized
DEBUG - 2019-08-19 18:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:31:40 --> Database Driver Class Initialized
INFO - 2019-08-19 18:31:40 --> Database Driver Class Initialized
INFO - 2019-08-19 18:31:40 --> Controller Class Initialized
INFO - 2019-08-19 18:31:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:31:40 --> Final output sent to browser
DEBUG - 2019-08-19 18:31:40 --> Total execution time: 0.3450
INFO - 2019-08-19 18:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:31:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:31:40 --> Pagination Class Initialized
INFO - 2019-08-19 18:31:40 --> Database Driver Class Initialized
INFO - 2019-08-19 18:31:40 --> Database Driver Class Initialized
INFO - 2019-08-19 18:31:40 --> Controller Class Initialized
INFO - 2019-08-19 18:31:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:31:40 --> Final output sent to browser
DEBUG - 2019-08-19 18:31:40 --> Total execution time: 0.4210
INFO - 2019-08-19 18:31:41 --> Config Class Initialized
INFO - 2019-08-19 18:31:41 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:31:41 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:31:41 --> Utf8 Class Initialized
INFO - 2019-08-19 18:31:41 --> URI Class Initialized
INFO - 2019-08-19 18:31:41 --> Router Class Initialized
INFO - 2019-08-19 18:31:41 --> Output Class Initialized
INFO - 2019-08-19 18:31:41 --> Security Class Initialized
DEBUG - 2019-08-19 18:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:31:41 --> Input Class Initialized
INFO - 2019-08-19 18:31:41 --> Language Class Initialized
INFO - 2019-08-19 18:31:41 --> Loader Class Initialized
INFO - 2019-08-19 18:31:41 --> Helper loaded: url_helper
INFO - 2019-08-19 18:31:41 --> Helper loaded: html_helper
INFO - 2019-08-19 18:31:41 --> Helper loaded: form_helper
INFO - 2019-08-19 18:31:41 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:31:41 --> Helper loaded: date_helper
INFO - 2019-08-19 18:31:41 --> Form Validation Class Initialized
INFO - 2019-08-19 18:31:41 --> Email Class Initialized
DEBUG - 2019-08-19 18:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:31:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:31:41 --> Pagination Class Initialized
INFO - 2019-08-19 18:31:41 --> Database Driver Class Initialized
INFO - 2019-08-19 18:31:41 --> Database Driver Class Initialized
INFO - 2019-08-19 18:31:41 --> Controller Class Initialized
INFO - 2019-08-19 18:31:41 --> Final output sent to browser
DEBUG - 2019-08-19 18:31:41 --> Total execution time: 0.3020
INFO - 2019-08-19 18:31:54 --> Config Class Initialized
INFO - 2019-08-19 18:31:54 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:31:54 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:31:54 --> Utf8 Class Initialized
INFO - 2019-08-19 18:31:54 --> URI Class Initialized
INFO - 2019-08-19 18:31:54 --> Router Class Initialized
INFO - 2019-08-19 18:31:54 --> Output Class Initialized
INFO - 2019-08-19 18:31:54 --> Security Class Initialized
DEBUG - 2019-08-19 18:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:31:54 --> Input Class Initialized
INFO - 2019-08-19 18:31:54 --> Language Class Initialized
INFO - 2019-08-19 18:31:55 --> Loader Class Initialized
INFO - 2019-08-19 18:31:55 --> Helper loaded: url_helper
INFO - 2019-08-19 18:31:55 --> Helper loaded: html_helper
INFO - 2019-08-19 18:31:55 --> Helper loaded: form_helper
INFO - 2019-08-19 18:31:55 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:31:55 --> Helper loaded: date_helper
INFO - 2019-08-19 18:31:55 --> Form Validation Class Initialized
INFO - 2019-08-19 18:31:55 --> Email Class Initialized
DEBUG - 2019-08-19 18:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:31:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:31:55 --> Pagination Class Initialized
INFO - 2019-08-19 18:31:55 --> Database Driver Class Initialized
INFO - 2019-08-19 18:31:55 --> Database Driver Class Initialized
INFO - 2019-08-19 18:31:55 --> Controller Class Initialized
INFO - 2019-08-19 18:31:55 --> Final output sent to browser
DEBUG - 2019-08-19 18:31:55 --> Total execution time: 0.2780
INFO - 2019-08-19 18:32:39 --> Config Class Initialized
INFO - 2019-08-19 18:32:39 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:32:39 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:32:39 --> Utf8 Class Initialized
INFO - 2019-08-19 18:32:39 --> URI Class Initialized
INFO - 2019-08-19 18:32:39 --> Router Class Initialized
INFO - 2019-08-19 18:32:39 --> Output Class Initialized
INFO - 2019-08-19 18:32:39 --> Security Class Initialized
DEBUG - 2019-08-19 18:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:32:39 --> Input Class Initialized
INFO - 2019-08-19 18:32:39 --> Language Class Initialized
INFO - 2019-08-19 18:32:39 --> Loader Class Initialized
INFO - 2019-08-19 18:32:39 --> Helper loaded: url_helper
INFO - 2019-08-19 18:32:39 --> Helper loaded: html_helper
INFO - 2019-08-19 18:32:39 --> Helper loaded: form_helper
INFO - 2019-08-19 18:32:39 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:32:39 --> Helper loaded: date_helper
INFO - 2019-08-19 18:32:39 --> Form Validation Class Initialized
INFO - 2019-08-19 18:32:39 --> Email Class Initialized
DEBUG - 2019-08-19 18:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:32:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:32:39 --> Pagination Class Initialized
INFO - 2019-08-19 18:32:39 --> Database Driver Class Initialized
INFO - 2019-08-19 18:32:39 --> Database Driver Class Initialized
INFO - 2019-08-19 18:32:39 --> Controller Class Initialized
INFO - 2019-08-19 18:32:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 18:32:39 --> Config Class Initialized
INFO - 2019-08-19 18:32:39 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:32:39 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:32:39 --> Utf8 Class Initialized
INFO - 2019-08-19 18:32:39 --> URI Class Initialized
INFO - 2019-08-19 18:32:39 --> Router Class Initialized
INFO - 2019-08-19 18:32:39 --> Output Class Initialized
INFO - 2019-08-19 18:32:39 --> Security Class Initialized
DEBUG - 2019-08-19 18:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:32:39 --> Input Class Initialized
INFO - 2019-08-19 18:32:39 --> Language Class Initialized
INFO - 2019-08-19 18:32:39 --> Loader Class Initialized
INFO - 2019-08-19 18:32:39 --> Helper loaded: url_helper
INFO - 2019-08-19 18:32:39 --> Helper loaded: html_helper
INFO - 2019-08-19 18:32:39 --> Helper loaded: form_helper
INFO - 2019-08-19 18:32:39 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:32:39 --> Helper loaded: date_helper
INFO - 2019-08-19 18:32:39 --> Form Validation Class Initialized
INFO - 2019-08-19 18:32:39 --> Email Class Initialized
DEBUG - 2019-08-19 18:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:32:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:32:39 --> Pagination Class Initialized
INFO - 2019-08-19 18:32:39 --> Database Driver Class Initialized
INFO - 2019-08-19 18:32:39 --> Database Driver Class Initialized
INFO - 2019-08-19 18:32:39 --> Controller Class Initialized
INFO - 2019-08-19 18:32:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:32:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/account_sale.php
INFO - 2019-08-19 18:32:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:32:39 --> Final output sent to browser
DEBUG - 2019-08-19 18:32:39 --> Total execution time: 0.2910
INFO - 2019-08-19 18:33:43 --> Config Class Initialized
INFO - 2019-08-19 18:33:43 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:33:43 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:33:43 --> Utf8 Class Initialized
INFO - 2019-08-19 18:33:43 --> Config Class Initialized
INFO - 2019-08-19 18:33:43 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:33:43 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:33:43 --> Utf8 Class Initialized
INFO - 2019-08-19 18:33:43 --> URI Class Initialized
INFO - 2019-08-19 18:33:43 --> Router Class Initialized
INFO - 2019-08-19 18:33:43 --> Output Class Initialized
INFO - 2019-08-19 18:33:43 --> Security Class Initialized
DEBUG - 2019-08-19 18:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:33:43 --> Input Class Initialized
INFO - 2019-08-19 18:33:43 --> Language Class Initialized
INFO - 2019-08-19 18:33:43 --> URI Class Initialized
INFO - 2019-08-19 18:33:43 --> Router Class Initialized
INFO - 2019-08-19 18:33:43 --> Output Class Initialized
INFO - 2019-08-19 18:33:43 --> Security Class Initialized
DEBUG - 2019-08-19 18:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:33:43 --> Input Class Initialized
INFO - 2019-08-19 18:33:43 --> Language Class Initialized
INFO - 2019-08-19 18:33:43 --> Loader Class Initialized
INFO - 2019-08-19 18:33:43 --> Helper loaded: url_helper
INFO - 2019-08-19 18:33:43 --> Helper loaded: html_helper
INFO - 2019-08-19 18:33:43 --> Helper loaded: form_helper
INFO - 2019-08-19 18:33:43 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:33:43 --> Helper loaded: date_helper
INFO - 2019-08-19 18:33:43 --> Form Validation Class Initialized
INFO - 2019-08-19 18:33:43 --> Email Class Initialized
DEBUG - 2019-08-19 18:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:33:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:33:43 --> Pagination Class Initialized
INFO - 2019-08-19 18:33:43 --> Database Driver Class Initialized
INFO - 2019-08-19 18:33:43 --> Database Driver Class Initialized
INFO - 2019-08-19 18:33:43 --> Loader Class Initialized
INFO - 2019-08-19 18:33:43 --> Helper loaded: url_helper
INFO - 2019-08-19 18:33:43 --> Helper loaded: html_helper
INFO - 2019-08-19 18:33:43 --> Helper loaded: form_helper
INFO - 2019-08-19 18:33:43 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:33:43 --> Helper loaded: date_helper
INFO - 2019-08-19 18:33:43 --> Form Validation Class Initialized
INFO - 2019-08-19 18:33:43 --> Email Class Initialized
DEBUG - 2019-08-19 18:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:33:43 --> Controller Class Initialized
INFO - 2019-08-19 18:33:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:33:43 --> Final output sent to browser
DEBUG - 2019-08-19 18:33:43 --> Total execution time: 0.3980
INFO - 2019-08-19 18:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:33:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:33:43 --> Pagination Class Initialized
INFO - 2019-08-19 18:33:43 --> Database Driver Class Initialized
INFO - 2019-08-19 18:33:43 --> Database Driver Class Initialized
INFO - 2019-08-19 18:33:43 --> Controller Class Initialized
INFO - 2019-08-19 18:33:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:33:43 --> Final output sent to browser
DEBUG - 2019-08-19 18:33:43 --> Total execution time: 0.5640
INFO - 2019-08-19 18:33:44 --> Config Class Initialized
INFO - 2019-08-19 18:33:44 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:33:44 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:33:44 --> Utf8 Class Initialized
INFO - 2019-08-19 18:33:44 --> URI Class Initialized
INFO - 2019-08-19 18:33:44 --> Router Class Initialized
INFO - 2019-08-19 18:33:44 --> Output Class Initialized
INFO - 2019-08-19 18:33:44 --> Security Class Initialized
DEBUG - 2019-08-19 18:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:33:44 --> Input Class Initialized
INFO - 2019-08-19 18:33:44 --> Language Class Initialized
INFO - 2019-08-19 18:33:44 --> Loader Class Initialized
INFO - 2019-08-19 18:33:44 --> Helper loaded: url_helper
INFO - 2019-08-19 18:33:44 --> Helper loaded: html_helper
INFO - 2019-08-19 18:33:44 --> Helper loaded: form_helper
INFO - 2019-08-19 18:33:44 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:33:44 --> Helper loaded: date_helper
INFO - 2019-08-19 18:33:44 --> Form Validation Class Initialized
INFO - 2019-08-19 18:33:44 --> Email Class Initialized
DEBUG - 2019-08-19 18:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:33:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:33:44 --> Pagination Class Initialized
INFO - 2019-08-19 18:33:44 --> Database Driver Class Initialized
INFO - 2019-08-19 18:33:44 --> Database Driver Class Initialized
INFO - 2019-08-19 18:33:44 --> Controller Class Initialized
INFO - 2019-08-19 18:33:44 --> Final output sent to browser
DEBUG - 2019-08-19 18:33:44 --> Total execution time: 0.3100
INFO - 2019-08-19 18:34:44 --> Config Class Initialized
INFO - 2019-08-19 18:34:44 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:34:44 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:34:44 --> Utf8 Class Initialized
INFO - 2019-08-19 18:34:44 --> URI Class Initialized
INFO - 2019-08-19 18:34:44 --> Router Class Initialized
INFO - 2019-08-19 18:34:44 --> Output Class Initialized
INFO - 2019-08-19 18:34:44 --> Security Class Initialized
DEBUG - 2019-08-19 18:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:34:44 --> Input Class Initialized
INFO - 2019-08-19 18:34:44 --> Language Class Initialized
INFO - 2019-08-19 18:34:44 --> Loader Class Initialized
INFO - 2019-08-19 18:34:44 --> Helper loaded: url_helper
INFO - 2019-08-19 18:34:44 --> Helper loaded: html_helper
INFO - 2019-08-19 18:34:44 --> Helper loaded: form_helper
INFO - 2019-08-19 18:34:44 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:34:44 --> Helper loaded: date_helper
INFO - 2019-08-19 18:34:44 --> Form Validation Class Initialized
INFO - 2019-08-19 18:34:44 --> Email Class Initialized
DEBUG - 2019-08-19 18:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:34:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:34:44 --> Pagination Class Initialized
INFO - 2019-08-19 18:34:44 --> Database Driver Class Initialized
INFO - 2019-08-19 18:34:44 --> Database Driver Class Initialized
INFO - 2019-08-19 18:34:44 --> Controller Class Initialized
INFO - 2019-08-19 18:34:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:34:44 --> Final output sent to browser
DEBUG - 2019-08-19 18:34:44 --> Total execution time: 0.3140
INFO - 2019-08-19 18:35:03 --> Config Class Initialized
INFO - 2019-08-19 18:35:03 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:35:03 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:35:03 --> Utf8 Class Initialized
INFO - 2019-08-19 18:35:03 --> URI Class Initialized
INFO - 2019-08-19 18:35:03 --> Router Class Initialized
INFO - 2019-08-19 18:35:03 --> Output Class Initialized
INFO - 2019-08-19 18:35:03 --> Security Class Initialized
DEBUG - 2019-08-19 18:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:35:03 --> Input Class Initialized
INFO - 2019-08-19 18:35:03 --> Language Class Initialized
INFO - 2019-08-19 18:35:03 --> Loader Class Initialized
INFO - 2019-08-19 18:35:03 --> Helper loaded: url_helper
INFO - 2019-08-19 18:35:03 --> Helper loaded: html_helper
INFO - 2019-08-19 18:35:03 --> Helper loaded: form_helper
INFO - 2019-08-19 18:35:03 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:35:03 --> Helper loaded: date_helper
INFO - 2019-08-19 18:35:03 --> Form Validation Class Initialized
INFO - 2019-08-19 18:35:03 --> Email Class Initialized
DEBUG - 2019-08-19 18:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:35:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:35:03 --> Pagination Class Initialized
INFO - 2019-08-19 18:35:03 --> Database Driver Class Initialized
INFO - 2019-08-19 18:35:03 --> Database Driver Class Initialized
INFO - 2019-08-19 18:35:03 --> Controller Class Initialized
INFO - 2019-08-19 18:35:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:35:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 18:35:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:35:03 --> Final output sent to browser
DEBUG - 2019-08-19 18:35:03 --> Total execution time: 0.2790
INFO - 2019-08-19 18:36:07 --> Config Class Initialized
INFO - 2019-08-19 18:36:07 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:36:07 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:36:07 --> Utf8 Class Initialized
INFO - 2019-08-19 18:36:07 --> Config Class Initialized
INFO - 2019-08-19 18:36:07 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:36:07 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:36:07 --> Utf8 Class Initialized
INFO - 2019-08-19 18:36:07 --> URI Class Initialized
INFO - 2019-08-19 18:36:07 --> URI Class Initialized
INFO - 2019-08-19 18:36:07 --> Router Class Initialized
INFO - 2019-08-19 18:36:07 --> Router Class Initialized
INFO - 2019-08-19 18:36:07 --> Output Class Initialized
INFO - 2019-08-19 18:36:07 --> Output Class Initialized
INFO - 2019-08-19 18:36:07 --> Security Class Initialized
INFO - 2019-08-19 18:36:07 --> Security Class Initialized
DEBUG - 2019-08-19 18:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:36:07 --> Input Class Initialized
DEBUG - 2019-08-19 18:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:36:07 --> Input Class Initialized
INFO - 2019-08-19 18:36:07 --> Language Class Initialized
INFO - 2019-08-19 18:36:07 --> Language Class Initialized
INFO - 2019-08-19 18:36:07 --> Loader Class Initialized
INFO - 2019-08-19 18:36:07 --> Loader Class Initialized
INFO - 2019-08-19 18:36:07 --> Helper loaded: url_helper
INFO - 2019-08-19 18:36:07 --> Helper loaded: url_helper
INFO - 2019-08-19 18:36:07 --> Helper loaded: html_helper
INFO - 2019-08-19 18:36:07 --> Helper loaded: html_helper
INFO - 2019-08-19 18:36:07 --> Helper loaded: form_helper
INFO - 2019-08-19 18:36:07 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:36:07 --> Helper loaded: form_helper
INFO - 2019-08-19 18:36:07 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:36:07 --> Helper loaded: date_helper
INFO - 2019-08-19 18:36:07 --> Form Validation Class Initialized
INFO - 2019-08-19 18:36:07 --> Helper loaded: date_helper
INFO - 2019-08-19 18:36:07 --> Email Class Initialized
INFO - 2019-08-19 18:36:07 --> Form Validation Class Initialized
DEBUG - 2019-08-19 18:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:36:07 --> Email Class Initialized
INFO - 2019-08-19 18:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:36:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:36:07 --> Pagination Class Initialized
DEBUG - 2019-08-19 18:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:36:07 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:07 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:07 --> Controller Class Initialized
INFO - 2019-08-19 18:36:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:36:07 --> Final output sent to browser
DEBUG - 2019-08-19 18:36:07 --> Total execution time: 0.2110
INFO - 2019-08-19 18:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:36:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:36:07 --> Pagination Class Initialized
INFO - 2019-08-19 18:36:07 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:07 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:07 --> Controller Class Initialized
INFO - 2019-08-19 18:36:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:36:07 --> Final output sent to browser
DEBUG - 2019-08-19 18:36:07 --> Total execution time: 0.4220
INFO - 2019-08-19 18:36:08 --> Config Class Initialized
INFO - 2019-08-19 18:36:08 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:36:08 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:36:08 --> Utf8 Class Initialized
INFO - 2019-08-19 18:36:08 --> URI Class Initialized
INFO - 2019-08-19 18:36:08 --> Router Class Initialized
INFO - 2019-08-19 18:36:08 --> Output Class Initialized
INFO - 2019-08-19 18:36:08 --> Security Class Initialized
DEBUG - 2019-08-19 18:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:36:08 --> Input Class Initialized
INFO - 2019-08-19 18:36:08 --> Language Class Initialized
INFO - 2019-08-19 18:36:08 --> Loader Class Initialized
INFO - 2019-08-19 18:36:08 --> Helper loaded: url_helper
INFO - 2019-08-19 18:36:08 --> Helper loaded: html_helper
INFO - 2019-08-19 18:36:08 --> Helper loaded: form_helper
INFO - 2019-08-19 18:36:08 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:36:08 --> Helper loaded: date_helper
INFO - 2019-08-19 18:36:08 --> Form Validation Class Initialized
INFO - 2019-08-19 18:36:08 --> Email Class Initialized
DEBUG - 2019-08-19 18:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:36:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:36:08 --> Pagination Class Initialized
INFO - 2019-08-19 18:36:08 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:08 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:08 --> Controller Class Initialized
INFO - 2019-08-19 18:36:08 --> Final output sent to browser
DEBUG - 2019-08-19 18:36:08 --> Total execution time: 0.2882
INFO - 2019-08-19 18:36:15 --> Config Class Initialized
INFO - 2019-08-19 18:36:15 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:36:15 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:36:15 --> Utf8 Class Initialized
INFO - 2019-08-19 18:36:15 --> URI Class Initialized
INFO - 2019-08-19 18:36:15 --> Router Class Initialized
INFO - 2019-08-19 18:36:15 --> Output Class Initialized
INFO - 2019-08-19 18:36:15 --> Security Class Initialized
DEBUG - 2019-08-19 18:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:36:15 --> Input Class Initialized
INFO - 2019-08-19 18:36:15 --> Language Class Initialized
INFO - 2019-08-19 18:36:15 --> Loader Class Initialized
INFO - 2019-08-19 18:36:15 --> Helper loaded: url_helper
INFO - 2019-08-19 18:36:15 --> Helper loaded: html_helper
INFO - 2019-08-19 18:36:15 --> Helper loaded: form_helper
INFO - 2019-08-19 18:36:15 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:36:15 --> Helper loaded: date_helper
INFO - 2019-08-19 18:36:15 --> Form Validation Class Initialized
INFO - 2019-08-19 18:36:15 --> Email Class Initialized
DEBUG - 2019-08-19 18:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:36:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:36:15 --> Pagination Class Initialized
INFO - 2019-08-19 18:36:15 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:15 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:15 --> Controller Class Initialized
INFO - 2019-08-19 18:36:15 --> Final output sent to browser
DEBUG - 2019-08-19 18:36:15 --> Total execution time: 0.3380
INFO - 2019-08-19 18:36:21 --> Config Class Initialized
INFO - 2019-08-19 18:36:21 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:36:21 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:36:21 --> Utf8 Class Initialized
INFO - 2019-08-19 18:36:21 --> URI Class Initialized
INFO - 2019-08-19 18:36:21 --> Router Class Initialized
INFO - 2019-08-19 18:36:21 --> Output Class Initialized
INFO - 2019-08-19 18:36:21 --> Security Class Initialized
DEBUG - 2019-08-19 18:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:36:21 --> Input Class Initialized
INFO - 2019-08-19 18:36:21 --> Language Class Initialized
INFO - 2019-08-19 18:36:21 --> Loader Class Initialized
INFO - 2019-08-19 18:36:21 --> Helper loaded: url_helper
INFO - 2019-08-19 18:36:21 --> Helper loaded: html_helper
INFO - 2019-08-19 18:36:21 --> Helper loaded: form_helper
INFO - 2019-08-19 18:36:21 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:36:21 --> Helper loaded: date_helper
INFO - 2019-08-19 18:36:21 --> Form Validation Class Initialized
INFO - 2019-08-19 18:36:21 --> Email Class Initialized
DEBUG - 2019-08-19 18:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:36:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:36:21 --> Pagination Class Initialized
INFO - 2019-08-19 18:36:21 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:21 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:21 --> Controller Class Initialized
INFO - 2019-08-19 18:36:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:36:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 18:36:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:36:21 --> Final output sent to browser
DEBUG - 2019-08-19 18:36:21 --> Total execution time: 0.2700
INFO - 2019-08-19 18:36:49 --> Config Class Initialized
INFO - 2019-08-19 18:36:49 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:36:49 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:36:49 --> Utf8 Class Initialized
INFO - 2019-08-19 18:36:49 --> Config Class Initialized
INFO - 2019-08-19 18:36:49 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:36:49 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:36:49 --> Utf8 Class Initialized
INFO - 2019-08-19 18:36:49 --> URI Class Initialized
INFO - 2019-08-19 18:36:49 --> Router Class Initialized
INFO - 2019-08-19 18:36:49 --> Output Class Initialized
INFO - 2019-08-19 18:36:49 --> Security Class Initialized
DEBUG - 2019-08-19 18:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:36:49 --> Input Class Initialized
INFO - 2019-08-19 18:36:49 --> Language Class Initialized
INFO - 2019-08-19 18:36:49 --> URI Class Initialized
INFO - 2019-08-19 18:36:49 --> Router Class Initialized
INFO - 2019-08-19 18:36:49 --> Output Class Initialized
INFO - 2019-08-19 18:36:49 --> Security Class Initialized
DEBUG - 2019-08-19 18:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:36:49 --> Input Class Initialized
INFO - 2019-08-19 18:36:49 --> Language Class Initialized
INFO - 2019-08-19 18:36:49 --> Loader Class Initialized
INFO - 2019-08-19 18:36:49 --> Helper loaded: url_helper
INFO - 2019-08-19 18:36:49 --> Helper loaded: html_helper
INFO - 2019-08-19 18:36:49 --> Helper loaded: form_helper
INFO - 2019-08-19 18:36:49 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:36:49 --> Helper loaded: date_helper
INFO - 2019-08-19 18:36:49 --> Loader Class Initialized
INFO - 2019-08-19 18:36:49 --> Helper loaded: url_helper
INFO - 2019-08-19 18:36:49 --> Helper loaded: html_helper
INFO - 2019-08-19 18:36:49 --> Helper loaded: form_helper
INFO - 2019-08-19 18:36:49 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:36:49 --> Helper loaded: date_helper
INFO - 2019-08-19 18:36:49 --> Form Validation Class Initialized
INFO - 2019-08-19 18:36:49 --> Form Validation Class Initialized
INFO - 2019-08-19 18:36:49 --> Email Class Initialized
DEBUG - 2019-08-19 18:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:36:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:36:49 --> Pagination Class Initialized
INFO - 2019-08-19 18:36:49 --> Email Class Initialized
DEBUG - 2019-08-19 18:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:36:49 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:49 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:49 --> Controller Class Initialized
INFO - 2019-08-19 18:36:49 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:36:49 --> Final output sent to browser
DEBUG - 2019-08-19 18:36:49 --> Total execution time: 0.4020
INFO - 2019-08-19 18:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:36:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:36:49 --> Pagination Class Initialized
INFO - 2019-08-19 18:36:49 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:49 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:49 --> Controller Class Initialized
INFO - 2019-08-19 18:36:49 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:36:49 --> Final output sent to browser
DEBUG - 2019-08-19 18:36:49 --> Total execution time: 0.4930
INFO - 2019-08-19 18:36:50 --> Config Class Initialized
INFO - 2019-08-19 18:36:50 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:36:50 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:36:50 --> Utf8 Class Initialized
INFO - 2019-08-19 18:36:50 --> URI Class Initialized
INFO - 2019-08-19 18:36:50 --> Router Class Initialized
INFO - 2019-08-19 18:36:50 --> Output Class Initialized
INFO - 2019-08-19 18:36:50 --> Security Class Initialized
DEBUG - 2019-08-19 18:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:36:50 --> Input Class Initialized
INFO - 2019-08-19 18:36:50 --> Language Class Initialized
INFO - 2019-08-19 18:36:50 --> Loader Class Initialized
INFO - 2019-08-19 18:36:50 --> Helper loaded: url_helper
INFO - 2019-08-19 18:36:50 --> Helper loaded: html_helper
INFO - 2019-08-19 18:36:50 --> Helper loaded: form_helper
INFO - 2019-08-19 18:36:50 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:36:50 --> Helper loaded: date_helper
INFO - 2019-08-19 18:36:50 --> Form Validation Class Initialized
INFO - 2019-08-19 18:36:50 --> Email Class Initialized
DEBUG - 2019-08-19 18:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:36:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:36:50 --> Pagination Class Initialized
INFO - 2019-08-19 18:36:50 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:50 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:50 --> Controller Class Initialized
INFO - 2019-08-19 18:36:50 --> Final output sent to browser
DEBUG - 2019-08-19 18:36:50 --> Total execution time: 0.4204
INFO - 2019-08-19 18:36:59 --> Config Class Initialized
INFO - 2019-08-19 18:36:59 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:36:59 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:36:59 --> Utf8 Class Initialized
INFO - 2019-08-19 18:36:59 --> URI Class Initialized
INFO - 2019-08-19 18:36:59 --> Router Class Initialized
INFO - 2019-08-19 18:36:59 --> Output Class Initialized
INFO - 2019-08-19 18:36:59 --> Security Class Initialized
DEBUG - 2019-08-19 18:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:36:59 --> Input Class Initialized
INFO - 2019-08-19 18:36:59 --> Language Class Initialized
INFO - 2019-08-19 18:36:59 --> Loader Class Initialized
INFO - 2019-08-19 18:36:59 --> Helper loaded: url_helper
INFO - 2019-08-19 18:36:59 --> Helper loaded: html_helper
INFO - 2019-08-19 18:36:59 --> Helper loaded: form_helper
INFO - 2019-08-19 18:36:59 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:36:59 --> Helper loaded: date_helper
INFO - 2019-08-19 18:36:59 --> Form Validation Class Initialized
INFO - 2019-08-19 18:36:59 --> Email Class Initialized
DEBUG - 2019-08-19 18:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:36:59 --> Pagination Class Initialized
INFO - 2019-08-19 18:36:59 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:59 --> Database Driver Class Initialized
INFO - 2019-08-19 18:36:59 --> Controller Class Initialized
INFO - 2019-08-19 18:36:59 --> Final output sent to browser
DEBUG - 2019-08-19 18:36:59 --> Total execution time: 0.2490
INFO - 2019-08-19 18:37:23 --> Config Class Initialized
INFO - 2019-08-19 18:37:23 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:37:23 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:37:23 --> Utf8 Class Initialized
INFO - 2019-08-19 18:37:23 --> URI Class Initialized
INFO - 2019-08-19 18:37:23 --> Router Class Initialized
INFO - 2019-08-19 18:37:23 --> Output Class Initialized
INFO - 2019-08-19 18:37:23 --> Security Class Initialized
DEBUG - 2019-08-19 18:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:37:23 --> Input Class Initialized
INFO - 2019-08-19 18:37:23 --> Language Class Initialized
INFO - 2019-08-19 18:37:23 --> Loader Class Initialized
INFO - 2019-08-19 18:37:23 --> Helper loaded: url_helper
INFO - 2019-08-19 18:37:23 --> Helper loaded: html_helper
INFO - 2019-08-19 18:37:23 --> Helper loaded: form_helper
INFO - 2019-08-19 18:37:23 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:37:23 --> Helper loaded: date_helper
INFO - 2019-08-19 18:37:23 --> Form Validation Class Initialized
INFO - 2019-08-19 18:37:23 --> Email Class Initialized
DEBUG - 2019-08-19 18:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:37:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:37:23 --> Pagination Class Initialized
INFO - 2019-08-19 18:37:23 --> Database Driver Class Initialized
INFO - 2019-08-19 18:37:23 --> Database Driver Class Initialized
INFO - 2019-08-19 18:37:23 --> Controller Class Initialized
INFO - 2019-08-19 18:37:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 18:37:24 --> Config Class Initialized
INFO - 2019-08-19 18:37:24 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:37:24 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:37:24 --> Utf8 Class Initialized
INFO - 2019-08-19 18:37:24 --> URI Class Initialized
INFO - 2019-08-19 18:37:24 --> Router Class Initialized
INFO - 2019-08-19 18:37:24 --> Output Class Initialized
INFO - 2019-08-19 18:37:24 --> Security Class Initialized
DEBUG - 2019-08-19 18:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:37:24 --> Input Class Initialized
INFO - 2019-08-19 18:37:24 --> Language Class Initialized
INFO - 2019-08-19 18:37:24 --> Loader Class Initialized
INFO - 2019-08-19 18:37:24 --> Helper loaded: url_helper
INFO - 2019-08-19 18:37:24 --> Helper loaded: html_helper
INFO - 2019-08-19 18:37:24 --> Helper loaded: form_helper
INFO - 2019-08-19 18:37:24 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:37:24 --> Helper loaded: date_helper
INFO - 2019-08-19 18:37:24 --> Form Validation Class Initialized
INFO - 2019-08-19 18:37:24 --> Email Class Initialized
DEBUG - 2019-08-19 18:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:37:24 --> Pagination Class Initialized
INFO - 2019-08-19 18:37:24 --> Database Driver Class Initialized
INFO - 2019-08-19 18:37:24 --> Database Driver Class Initialized
INFO - 2019-08-19 18:37:24 --> Controller Class Initialized
INFO - 2019-08-19 18:37:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:37:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/room.php
INFO - 2019-08-19 18:37:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:37:24 --> Final output sent to browser
DEBUG - 2019-08-19 18:37:24 --> Total execution time: 0.2280
INFO - 2019-08-19 18:38:06 --> Config Class Initialized
INFO - 2019-08-19 18:38:06 --> Hooks Class Initialized
INFO - 2019-08-19 18:38:06 --> Config Class Initialized
INFO - 2019-08-19 18:38:06 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:38:06 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:38:06 --> Utf8 Class Initialized
DEBUG - 2019-08-19 18:38:06 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:38:06 --> Utf8 Class Initialized
INFO - 2019-08-19 18:38:06 --> URI Class Initialized
INFO - 2019-08-19 18:38:06 --> URI Class Initialized
INFO - 2019-08-19 18:38:06 --> Router Class Initialized
INFO - 2019-08-19 18:38:06 --> Router Class Initialized
INFO - 2019-08-19 18:38:06 --> Output Class Initialized
INFO - 2019-08-19 18:38:06 --> Output Class Initialized
INFO - 2019-08-19 18:38:06 --> Security Class Initialized
INFO - 2019-08-19 18:38:06 --> Security Class Initialized
DEBUG - 2019-08-19 18:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:38:06 --> Input Class Initialized
DEBUG - 2019-08-19 18:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:38:06 --> Input Class Initialized
INFO - 2019-08-19 18:38:06 --> Language Class Initialized
INFO - 2019-08-19 18:38:06 --> Language Class Initialized
INFO - 2019-08-19 18:38:06 --> Loader Class Initialized
INFO - 2019-08-19 18:38:06 --> Helper loaded: url_helper
INFO - 2019-08-19 18:38:06 --> Helper loaded: html_helper
INFO - 2019-08-19 18:38:06 --> Helper loaded: form_helper
INFO - 2019-08-19 18:38:06 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:38:06 --> Helper loaded: date_helper
INFO - 2019-08-19 18:38:06 --> Form Validation Class Initialized
INFO - 2019-08-19 18:38:06 --> Loader Class Initialized
INFO - 2019-08-19 18:38:06 --> Helper loaded: url_helper
INFO - 2019-08-19 18:38:06 --> Helper loaded: html_helper
INFO - 2019-08-19 18:38:06 --> Helper loaded: form_helper
INFO - 2019-08-19 18:38:06 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:38:06 --> Helper loaded: date_helper
INFO - 2019-08-19 18:38:06 --> Email Class Initialized
DEBUG - 2019-08-19 18:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:38:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:38:06 --> Pagination Class Initialized
INFO - 2019-08-19 18:38:06 --> Form Validation Class Initialized
INFO - 2019-08-19 18:38:06 --> Email Class Initialized
DEBUG - 2019-08-19 18:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:38:06 --> Database Driver Class Initialized
INFO - 2019-08-19 18:38:06 --> Database Driver Class Initialized
INFO - 2019-08-19 18:38:06 --> Controller Class Initialized
INFO - 2019-08-19 18:38:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:38:06 --> Final output sent to browser
DEBUG - 2019-08-19 18:38:06 --> Total execution time: 0.3080
INFO - 2019-08-19 18:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:38:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:38:06 --> Pagination Class Initialized
INFO - 2019-08-19 18:38:06 --> Database Driver Class Initialized
INFO - 2019-08-19 18:38:06 --> Database Driver Class Initialized
INFO - 2019-08-19 18:38:06 --> Controller Class Initialized
INFO - 2019-08-19 18:38:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:38:06 --> Final output sent to browser
DEBUG - 2019-08-19 18:38:06 --> Total execution time: 0.4530
INFO - 2019-08-19 18:38:07 --> Config Class Initialized
INFO - 2019-08-19 18:38:07 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:38:07 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:38:07 --> Utf8 Class Initialized
INFO - 2019-08-19 18:38:07 --> URI Class Initialized
INFO - 2019-08-19 18:38:07 --> Router Class Initialized
INFO - 2019-08-19 18:38:07 --> Output Class Initialized
INFO - 2019-08-19 18:38:07 --> Security Class Initialized
DEBUG - 2019-08-19 18:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:38:07 --> Input Class Initialized
INFO - 2019-08-19 18:38:07 --> Language Class Initialized
INFO - 2019-08-19 18:38:07 --> Loader Class Initialized
INFO - 2019-08-19 18:38:07 --> Helper loaded: url_helper
INFO - 2019-08-19 18:38:07 --> Helper loaded: html_helper
INFO - 2019-08-19 18:38:07 --> Helper loaded: form_helper
INFO - 2019-08-19 18:38:07 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:38:07 --> Helper loaded: date_helper
INFO - 2019-08-19 18:38:07 --> Form Validation Class Initialized
INFO - 2019-08-19 18:38:07 --> Email Class Initialized
DEBUG - 2019-08-19 18:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:38:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:38:07 --> Pagination Class Initialized
INFO - 2019-08-19 18:38:07 --> Database Driver Class Initialized
INFO - 2019-08-19 18:38:07 --> Database Driver Class Initialized
INFO - 2019-08-19 18:38:07 --> Controller Class Initialized
INFO - 2019-08-19 18:38:07 --> Final output sent to browser
DEBUG - 2019-08-19 18:38:07 --> Total execution time: 0.2870
INFO - 2019-08-19 18:38:21 --> Config Class Initialized
INFO - 2019-08-19 18:38:21 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:38:21 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:38:21 --> Utf8 Class Initialized
INFO - 2019-08-19 18:38:21 --> URI Class Initialized
INFO - 2019-08-19 18:38:21 --> Router Class Initialized
INFO - 2019-08-19 18:38:21 --> Output Class Initialized
INFO - 2019-08-19 18:38:21 --> Security Class Initialized
DEBUG - 2019-08-19 18:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:38:21 --> Input Class Initialized
INFO - 2019-08-19 18:38:21 --> Language Class Initialized
INFO - 2019-08-19 18:38:21 --> Loader Class Initialized
INFO - 2019-08-19 18:38:21 --> Helper loaded: url_helper
INFO - 2019-08-19 18:38:21 --> Helper loaded: html_helper
INFO - 2019-08-19 18:38:21 --> Helper loaded: form_helper
INFO - 2019-08-19 18:38:21 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:38:21 --> Helper loaded: date_helper
INFO - 2019-08-19 18:38:21 --> Form Validation Class Initialized
INFO - 2019-08-19 18:38:21 --> Email Class Initialized
DEBUG - 2019-08-19 18:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:38:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:38:21 --> Pagination Class Initialized
INFO - 2019-08-19 18:38:21 --> Database Driver Class Initialized
INFO - 2019-08-19 18:38:21 --> Database Driver Class Initialized
INFO - 2019-08-19 18:38:21 --> Controller Class Initialized
INFO - 2019-08-19 18:38:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:38:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomclass.php
INFO - 2019-08-19 18:38:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:38:21 --> Final output sent to browser
DEBUG - 2019-08-19 18:38:21 --> Total execution time: 0.1812
INFO - 2019-08-19 18:39:03 --> Config Class Initialized
INFO - 2019-08-19 18:39:03 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:39:03 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:39:03 --> Utf8 Class Initialized
INFO - 2019-08-19 18:39:03 --> URI Class Initialized
INFO - 2019-08-19 18:39:03 --> Router Class Initialized
INFO - 2019-08-19 18:39:03 --> Output Class Initialized
INFO - 2019-08-19 18:39:03 --> Security Class Initialized
DEBUG - 2019-08-19 18:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:39:04 --> Input Class Initialized
INFO - 2019-08-19 18:39:04 --> Language Class Initialized
INFO - 2019-08-19 18:39:04 --> Config Class Initialized
INFO - 2019-08-19 18:39:04 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:39:04 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:39:04 --> Utf8 Class Initialized
INFO - 2019-08-19 18:39:04 --> URI Class Initialized
INFO - 2019-08-19 18:39:04 --> Router Class Initialized
INFO - 2019-08-19 18:39:04 --> Loader Class Initialized
INFO - 2019-08-19 18:39:04 --> Output Class Initialized
INFO - 2019-08-19 18:39:04 --> Security Class Initialized
INFO - 2019-08-19 18:39:04 --> Helper loaded: url_helper
INFO - 2019-08-19 18:39:04 --> Helper loaded: html_helper
DEBUG - 2019-08-19 18:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:39:04 --> Input Class Initialized
INFO - 2019-08-19 18:39:04 --> Helper loaded: form_helper
INFO - 2019-08-19 18:39:04 --> Language Class Initialized
INFO - 2019-08-19 18:39:04 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:39:04 --> Helper loaded: date_helper
INFO - 2019-08-19 18:39:04 --> Form Validation Class Initialized
INFO - 2019-08-19 18:39:04 --> Loader Class Initialized
INFO - 2019-08-19 18:39:04 --> Helper loaded: url_helper
INFO - 2019-08-19 18:39:04 --> Helper loaded: html_helper
INFO - 2019-08-19 18:39:04 --> Helper loaded: form_helper
INFO - 2019-08-19 18:39:04 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:39:04 --> Helper loaded: date_helper
INFO - 2019-08-19 18:39:04 --> Form Validation Class Initialized
INFO - 2019-08-19 18:39:04 --> Email Class Initialized
INFO - 2019-08-19 18:39:04 --> Email Class Initialized
DEBUG - 2019-08-19 18:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:39:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:39:04 --> Pagination Class Initialized
DEBUG - 2019-08-19 18:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:39:04 --> Database Driver Class Initialized
INFO - 2019-08-19 18:39:04 --> Database Driver Class Initialized
INFO - 2019-08-19 18:39:04 --> Controller Class Initialized
INFO - 2019-08-19 18:39:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:39:04 --> Final output sent to browser
DEBUG - 2019-08-19 18:39:04 --> Total execution time: 0.2590
INFO - 2019-08-19 18:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:39:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:39:04 --> Pagination Class Initialized
INFO - 2019-08-19 18:39:04 --> Database Driver Class Initialized
INFO - 2019-08-19 18:39:04 --> Database Driver Class Initialized
INFO - 2019-08-19 18:39:04 --> Controller Class Initialized
INFO - 2019-08-19 18:39:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:39:04 --> Final output sent to browser
DEBUG - 2019-08-19 18:39:04 --> Total execution time: 0.3660
INFO - 2019-08-19 18:39:04 --> Config Class Initialized
INFO - 2019-08-19 18:39:04 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:39:04 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:39:04 --> Utf8 Class Initialized
INFO - 2019-08-19 18:39:04 --> URI Class Initialized
INFO - 2019-08-19 18:39:04 --> Router Class Initialized
INFO - 2019-08-19 18:39:04 --> Output Class Initialized
INFO - 2019-08-19 18:39:04 --> Security Class Initialized
DEBUG - 2019-08-19 18:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:39:04 --> Input Class Initialized
INFO - 2019-08-19 18:39:04 --> Language Class Initialized
INFO - 2019-08-19 18:39:04 --> Loader Class Initialized
INFO - 2019-08-19 18:39:04 --> Helper loaded: url_helper
INFO - 2019-08-19 18:39:04 --> Helper loaded: html_helper
INFO - 2019-08-19 18:39:05 --> Helper loaded: form_helper
INFO - 2019-08-19 18:39:05 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:39:05 --> Helper loaded: date_helper
INFO - 2019-08-19 18:39:05 --> Form Validation Class Initialized
INFO - 2019-08-19 18:39:05 --> Email Class Initialized
DEBUG - 2019-08-19 18:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:39:05 --> Pagination Class Initialized
INFO - 2019-08-19 18:39:05 --> Database Driver Class Initialized
INFO - 2019-08-19 18:39:05 --> Database Driver Class Initialized
INFO - 2019-08-19 18:39:05 --> Controller Class Initialized
INFO - 2019-08-19 18:39:05 --> Final output sent to browser
DEBUG - 2019-08-19 18:39:05 --> Total execution time: 0.3102
INFO - 2019-08-19 18:39:17 --> Config Class Initialized
INFO - 2019-08-19 18:39:17 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:39:17 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:39:17 --> Utf8 Class Initialized
INFO - 2019-08-19 18:39:17 --> URI Class Initialized
INFO - 2019-08-19 18:39:17 --> Router Class Initialized
INFO - 2019-08-19 18:39:17 --> Output Class Initialized
INFO - 2019-08-19 18:39:17 --> Security Class Initialized
DEBUG - 2019-08-19 18:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:39:17 --> Input Class Initialized
INFO - 2019-08-19 18:39:17 --> Language Class Initialized
INFO - 2019-08-19 18:39:18 --> Loader Class Initialized
INFO - 2019-08-19 18:39:18 --> Helper loaded: url_helper
INFO - 2019-08-19 18:39:18 --> Helper loaded: html_helper
INFO - 2019-08-19 18:39:18 --> Helper loaded: form_helper
INFO - 2019-08-19 18:39:18 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:39:18 --> Helper loaded: date_helper
INFO - 2019-08-19 18:39:18 --> Form Validation Class Initialized
INFO - 2019-08-19 18:39:18 --> Email Class Initialized
DEBUG - 2019-08-19 18:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:39:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:39:18 --> Pagination Class Initialized
INFO - 2019-08-19 18:39:18 --> Database Driver Class Initialized
INFO - 2019-08-19 18:39:18 --> Database Driver Class Initialized
INFO - 2019-08-19 18:39:18 --> Controller Class Initialized
INFO - 2019-08-19 18:39:18 --> Final output sent to browser
DEBUG - 2019-08-19 18:39:18 --> Total execution time: 0.2670
INFO - 2019-08-19 18:39:25 --> Config Class Initialized
INFO - 2019-08-19 18:39:25 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:39:25 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:39:25 --> Utf8 Class Initialized
INFO - 2019-08-19 18:39:25 --> URI Class Initialized
INFO - 2019-08-19 18:39:25 --> Router Class Initialized
INFO - 2019-08-19 18:39:25 --> Output Class Initialized
INFO - 2019-08-19 18:39:25 --> Security Class Initialized
DEBUG - 2019-08-19 18:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:39:25 --> Input Class Initialized
INFO - 2019-08-19 18:39:25 --> Language Class Initialized
INFO - 2019-08-19 18:39:25 --> Loader Class Initialized
INFO - 2019-08-19 18:39:25 --> Helper loaded: url_helper
INFO - 2019-08-19 18:39:25 --> Helper loaded: html_helper
INFO - 2019-08-19 18:39:25 --> Helper loaded: form_helper
INFO - 2019-08-19 18:39:25 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:39:25 --> Helper loaded: date_helper
INFO - 2019-08-19 18:39:25 --> Form Validation Class Initialized
INFO - 2019-08-19 18:39:25 --> Email Class Initialized
DEBUG - 2019-08-19 18:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:39:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:39:25 --> Pagination Class Initialized
INFO - 2019-08-19 18:39:25 --> Database Driver Class Initialized
INFO - 2019-08-19 18:39:25 --> Database Driver Class Initialized
INFO - 2019-08-19 18:39:25 --> Controller Class Initialized
INFO - 2019-08-19 18:39:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 18:39:25 --> Config Class Initialized
INFO - 2019-08-19 18:39:25 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:39:25 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:39:25 --> Utf8 Class Initialized
INFO - 2019-08-19 18:39:25 --> URI Class Initialized
INFO - 2019-08-19 18:39:25 --> Router Class Initialized
INFO - 2019-08-19 18:39:25 --> Output Class Initialized
INFO - 2019-08-19 18:39:25 --> Security Class Initialized
DEBUG - 2019-08-19 18:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:39:25 --> Input Class Initialized
INFO - 2019-08-19 18:39:25 --> Language Class Initialized
INFO - 2019-08-19 18:39:25 --> Loader Class Initialized
INFO - 2019-08-19 18:39:25 --> Helper loaded: url_helper
INFO - 2019-08-19 18:39:25 --> Helper loaded: html_helper
INFO - 2019-08-19 18:39:25 --> Helper loaded: form_helper
INFO - 2019-08-19 18:39:25 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:39:25 --> Helper loaded: date_helper
INFO - 2019-08-19 18:39:25 --> Form Validation Class Initialized
INFO - 2019-08-19 18:39:25 --> Email Class Initialized
DEBUG - 2019-08-19 18:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:39:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:39:25 --> Pagination Class Initialized
INFO - 2019-08-19 18:39:25 --> Database Driver Class Initialized
INFO - 2019-08-19 18:39:25 --> Database Driver Class Initialized
INFO - 2019-08-19 18:39:25 --> Controller Class Initialized
INFO - 2019-08-19 18:39:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:39:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomclass.php
INFO - 2019-08-19 18:39:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:39:25 --> Final output sent to browser
DEBUG - 2019-08-19 18:39:25 --> Total execution time: 0.1910
INFO - 2019-08-19 18:40:10 --> Config Class Initialized
INFO - 2019-08-19 18:40:10 --> Hooks Class Initialized
INFO - 2019-08-19 18:40:10 --> Config Class Initialized
INFO - 2019-08-19 18:40:10 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:40:10 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:40:10 --> Utf8 Class Initialized
DEBUG - 2019-08-19 18:40:10 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:40:10 --> Utf8 Class Initialized
INFO - 2019-08-19 18:40:10 --> URI Class Initialized
INFO - 2019-08-19 18:40:10 --> URI Class Initialized
INFO - 2019-08-19 18:40:10 --> Router Class Initialized
INFO - 2019-08-19 18:40:10 --> Output Class Initialized
INFO - 2019-08-19 18:40:10 --> Security Class Initialized
DEBUG - 2019-08-19 18:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:40:10 --> Input Class Initialized
INFO - 2019-08-19 18:40:10 --> Language Class Initialized
INFO - 2019-08-19 18:40:10 --> Loader Class Initialized
INFO - 2019-08-19 18:40:10 --> Config Class Initialized
INFO - 2019-08-19 18:40:10 --> Hooks Class Initialized
INFO - 2019-08-19 18:40:10 --> Router Class Initialized
INFO - 2019-08-19 18:40:10 --> Helper loaded: url_helper
INFO - 2019-08-19 18:40:10 --> Helper loaded: html_helper
DEBUG - 2019-08-19 18:40:10 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:40:10 --> Utf8 Class Initialized
INFO - 2019-08-19 18:40:10 --> Helper loaded: form_helper
INFO - 2019-08-19 18:40:10 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:40:10 --> Output Class Initialized
INFO - 2019-08-19 18:40:10 --> Helper loaded: date_helper
INFO - 2019-08-19 18:40:10 --> Security Class Initialized
INFO - 2019-08-19 18:40:10 --> Form Validation Class Initialized
DEBUG - 2019-08-19 18:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:40:10 --> Input Class Initialized
INFO - 2019-08-19 18:40:10 --> Email Class Initialized
INFO - 2019-08-19 18:40:10 --> Language Class Initialized
INFO - 2019-08-19 18:40:10 --> URI Class Initialized
DEBUG - 2019-08-19 18:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:40:10 --> Loader Class Initialized
INFO - 2019-08-19 18:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:40:10 --> Router Class Initialized
INFO - 2019-08-19 18:40:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:40:10 --> Pagination Class Initialized
INFO - 2019-08-19 18:40:10 --> Output Class Initialized
INFO - 2019-08-19 18:40:10 --> Security Class Initialized
DEBUG - 2019-08-19 18:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:40:10 --> Input Class Initialized
INFO - 2019-08-19 18:40:10 --> Language Class Initialized
INFO - 2019-08-19 18:40:10 --> Helper loaded: url_helper
INFO - 2019-08-19 18:40:10 --> Helper loaded: html_helper
INFO - 2019-08-19 18:40:10 --> Database Driver Class Initialized
INFO - 2019-08-19 18:40:10 --> Helper loaded: form_helper
INFO - 2019-08-19 18:40:10 --> Database Driver Class Initialized
INFO - 2019-08-19 18:40:10 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:40:10 --> Helper loaded: date_helper
INFO - 2019-08-19 18:40:10 --> Loader Class Initialized
INFO - 2019-08-19 18:40:10 --> Form Validation Class Initialized
INFO - 2019-08-19 18:40:10 --> Helper loaded: url_helper
INFO - 2019-08-19 18:40:10 --> Helper loaded: html_helper
INFO - 2019-08-19 18:40:10 --> Helper loaded: form_helper
INFO - 2019-08-19 18:40:10 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:40:10 --> Email Class Initialized
INFO - 2019-08-19 18:40:10 --> Helper loaded: date_helper
DEBUG - 2019-08-19 18:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:40:10 --> Form Validation Class Initialized
INFO - 2019-08-19 18:40:10 --> Email Class Initialized
DEBUG - 2019-08-19 18:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:40:10 --> Controller Class Initialized
INFO - 2019-08-19 18:40:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:40:10 --> Final output sent to browser
DEBUG - 2019-08-19 18:40:10 --> Total execution time: 0.4520
INFO - 2019-08-19 18:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:40:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:40:10 --> Pagination Class Initialized
INFO - 2019-08-19 18:40:10 --> Database Driver Class Initialized
INFO - 2019-08-19 18:40:10 --> Database Driver Class Initialized
INFO - 2019-08-19 18:40:11 --> Controller Class Initialized
INFO - 2019-08-19 18:40:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:40:11 --> Final output sent to browser
DEBUG - 2019-08-19 18:40:11 --> Total execution time: 0.5540
INFO - 2019-08-19 18:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:40:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:40:11 --> Pagination Class Initialized
INFO - 2019-08-19 18:40:11 --> Database Driver Class Initialized
INFO - 2019-08-19 18:40:11 --> Database Driver Class Initialized
INFO - 2019-08-19 18:40:11 --> Controller Class Initialized
INFO - 2019-08-19 18:40:11 --> Final output sent to browser
DEBUG - 2019-08-19 18:40:11 --> Total execution time: 0.6240
INFO - 2019-08-19 18:40:42 --> Config Class Initialized
INFO - 2019-08-19 18:40:42 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:40:42 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:40:42 --> Utf8 Class Initialized
INFO - 2019-08-19 18:40:42 --> URI Class Initialized
INFO - 2019-08-19 18:40:42 --> Router Class Initialized
INFO - 2019-08-19 18:40:42 --> Output Class Initialized
INFO - 2019-08-19 18:40:42 --> Security Class Initialized
DEBUG - 2019-08-19 18:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:40:42 --> Input Class Initialized
INFO - 2019-08-19 18:40:42 --> Language Class Initialized
INFO - 2019-08-19 18:40:42 --> Loader Class Initialized
INFO - 2019-08-19 18:40:42 --> Helper loaded: url_helper
INFO - 2019-08-19 18:40:42 --> Helper loaded: html_helper
INFO - 2019-08-19 18:40:42 --> Helper loaded: form_helper
INFO - 2019-08-19 18:40:42 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:40:42 --> Helper loaded: date_helper
INFO - 2019-08-19 18:40:42 --> Form Validation Class Initialized
INFO - 2019-08-19 18:40:42 --> Email Class Initialized
DEBUG - 2019-08-19 18:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:40:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:40:42 --> Pagination Class Initialized
INFO - 2019-08-19 18:40:42 --> Database Driver Class Initialized
INFO - 2019-08-19 18:40:42 --> Database Driver Class Initialized
INFO - 2019-08-19 18:40:42 --> Controller Class Initialized
INFO - 2019-08-19 18:40:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:40:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomtype.php
INFO - 2019-08-19 18:40:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:40:42 --> Final output sent to browser
DEBUG - 2019-08-19 18:40:42 --> Total execution time: 0.2260
INFO - 2019-08-19 18:41:48 --> Config Class Initialized
INFO - 2019-08-19 18:41:48 --> Hooks Class Initialized
INFO - 2019-08-19 18:41:48 --> Config Class Initialized
INFO - 2019-08-19 18:41:48 --> Hooks Class Initialized
INFO - 2019-08-19 18:41:48 --> Config Class Initialized
INFO - 2019-08-19 18:41:48 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:41:48 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:41:48 --> Utf8 Class Initialized
INFO - 2019-08-19 18:41:48 --> URI Class Initialized
DEBUG - 2019-08-19 18:41:48 --> UTF-8 Support Enabled
DEBUG - 2019-08-19 18:41:48 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:41:48 --> Utf8 Class Initialized
INFO - 2019-08-19 18:41:48 --> Router Class Initialized
INFO - 2019-08-19 18:41:48 --> Utf8 Class Initialized
INFO - 2019-08-19 18:41:48 --> URI Class Initialized
INFO - 2019-08-19 18:41:48 --> Output Class Initialized
INFO - 2019-08-19 18:41:48 --> Security Class Initialized
DEBUG - 2019-08-19 18:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:41:48 --> Input Class Initialized
INFO - 2019-08-19 18:41:48 --> Language Class Initialized
INFO - 2019-08-19 18:41:48 --> URI Class Initialized
INFO - 2019-08-19 18:41:48 --> Router Class Initialized
INFO - 2019-08-19 18:41:48 --> Output Class Initialized
INFO - 2019-08-19 18:41:48 --> Security Class Initialized
DEBUG - 2019-08-19 18:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:41:48 --> Input Class Initialized
INFO - 2019-08-19 18:41:48 --> Language Class Initialized
INFO - 2019-08-19 18:41:48 --> Loader Class Initialized
INFO - 2019-08-19 18:41:48 --> Helper loaded: url_helper
INFO - 2019-08-19 18:41:48 --> Helper loaded: html_helper
INFO - 2019-08-19 18:41:48 --> Router Class Initialized
INFO - 2019-08-19 18:41:48 --> Helper loaded: form_helper
INFO - 2019-08-19 18:41:48 --> Output Class Initialized
INFO - 2019-08-19 18:41:48 --> Security Class Initialized
DEBUG - 2019-08-19 18:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:41:48 --> Input Class Initialized
INFO - 2019-08-19 18:41:48 --> Language Class Initialized
INFO - 2019-08-19 18:41:48 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:41:48 --> Helper loaded: date_helper
INFO - 2019-08-19 18:41:48 --> Form Validation Class Initialized
INFO - 2019-08-19 18:41:48 --> Loader Class Initialized
INFO - 2019-08-19 18:41:48 --> Helper loaded: url_helper
INFO - 2019-08-19 18:41:48 --> Helper loaded: html_helper
INFO - 2019-08-19 18:41:48 --> Helper loaded: form_helper
INFO - 2019-08-19 18:41:48 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:41:48 --> Email Class Initialized
DEBUG - 2019-08-19 18:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:41:48 --> Loader Class Initialized
INFO - 2019-08-19 18:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:41:48 --> Helper loaded: url_helper
INFO - 2019-08-19 18:41:48 --> Helper loaded: html_helper
INFO - 2019-08-19 18:41:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:41:48 --> Pagination Class Initialized
INFO - 2019-08-19 18:41:48 --> Helper loaded: form_helper
INFO - 2019-08-19 18:41:48 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:41:48 --> Helper loaded: date_helper
INFO - 2019-08-19 18:41:48 --> Helper loaded: date_helper
INFO - 2019-08-19 18:41:48 --> Form Validation Class Initialized
INFO - 2019-08-19 18:41:48 --> Form Validation Class Initialized
INFO - 2019-08-19 18:41:48 --> Email Class Initialized
INFO - 2019-08-19 18:41:48 --> Email Class Initialized
DEBUG - 2019-08-19 18:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-19 18:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:41:48 --> Database Driver Class Initialized
INFO - 2019-08-19 18:41:48 --> Database Driver Class Initialized
INFO - 2019-08-19 18:41:49 --> Controller Class Initialized
INFO - 2019-08-19 18:41:49 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:41:49 --> Final output sent to browser
DEBUG - 2019-08-19 18:41:49 --> Total execution time: 0.4110
INFO - 2019-08-19 18:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:41:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:41:49 --> Pagination Class Initialized
INFO - 2019-08-19 18:41:49 --> Database Driver Class Initialized
INFO - 2019-08-19 18:41:49 --> Database Driver Class Initialized
INFO - 2019-08-19 18:41:49 --> Controller Class Initialized
INFO - 2019-08-19 18:41:49 --> Final output sent to browser
DEBUG - 2019-08-19 18:41:49 --> Total execution time: 0.5340
INFO - 2019-08-19 18:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:41:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:41:49 --> Pagination Class Initialized
INFO - 2019-08-19 18:41:49 --> Database Driver Class Initialized
INFO - 2019-08-19 18:41:49 --> Database Driver Class Initialized
INFO - 2019-08-19 18:41:49 --> Controller Class Initialized
INFO - 2019-08-19 18:41:49 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:41:49 --> Final output sent to browser
DEBUG - 2019-08-19 18:41:49 --> Total execution time: 0.6130
INFO - 2019-08-19 18:43:28 --> Config Class Initialized
INFO - 2019-08-19 18:43:28 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:43:28 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:43:28 --> Utf8 Class Initialized
INFO - 2019-08-19 18:43:28 --> URI Class Initialized
INFO - 2019-08-19 18:43:28 --> Router Class Initialized
INFO - 2019-08-19 18:43:28 --> Output Class Initialized
INFO - 2019-08-19 18:43:28 --> Security Class Initialized
DEBUG - 2019-08-19 18:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:43:28 --> Input Class Initialized
INFO - 2019-08-19 18:43:28 --> Language Class Initialized
INFO - 2019-08-19 18:43:28 --> Loader Class Initialized
INFO - 2019-08-19 18:43:28 --> Helper loaded: url_helper
INFO - 2019-08-19 18:43:28 --> Helper loaded: html_helper
INFO - 2019-08-19 18:43:28 --> Helper loaded: form_helper
INFO - 2019-08-19 18:43:28 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:43:28 --> Helper loaded: date_helper
INFO - 2019-08-19 18:43:28 --> Form Validation Class Initialized
INFO - 2019-08-19 18:43:28 --> Email Class Initialized
DEBUG - 2019-08-19 18:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:43:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:43:28 --> Pagination Class Initialized
INFO - 2019-08-19 18:43:28 --> Database Driver Class Initialized
INFO - 2019-08-19 18:43:28 --> Database Driver Class Initialized
INFO - 2019-08-19 18:43:28 --> Controller Class Initialized
INFO - 2019-08-19 18:43:28 --> Final output sent to browser
DEBUG - 2019-08-19 18:43:28 --> Total execution time: 0.2560
INFO - 2019-08-19 18:43:39 --> Config Class Initialized
INFO - 2019-08-19 18:43:39 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:43:39 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:43:39 --> Utf8 Class Initialized
INFO - 2019-08-19 18:43:39 --> URI Class Initialized
INFO - 2019-08-19 18:43:39 --> Router Class Initialized
INFO - 2019-08-19 18:43:39 --> Output Class Initialized
INFO - 2019-08-19 18:43:39 --> Security Class Initialized
DEBUG - 2019-08-19 18:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:43:39 --> Input Class Initialized
INFO - 2019-08-19 18:43:39 --> Language Class Initialized
INFO - 2019-08-19 18:43:39 --> Loader Class Initialized
INFO - 2019-08-19 18:43:39 --> Helper loaded: url_helper
INFO - 2019-08-19 18:43:39 --> Helper loaded: html_helper
INFO - 2019-08-19 18:43:39 --> Helper loaded: form_helper
INFO - 2019-08-19 18:43:39 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:43:39 --> Helper loaded: date_helper
INFO - 2019-08-19 18:43:39 --> Form Validation Class Initialized
INFO - 2019-08-19 18:43:39 --> Email Class Initialized
DEBUG - 2019-08-19 18:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:43:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:43:39 --> Pagination Class Initialized
INFO - 2019-08-19 18:43:39 --> Database Driver Class Initialized
INFO - 2019-08-19 18:43:39 --> Database Driver Class Initialized
INFO - 2019-08-19 18:43:39 --> Controller Class Initialized
INFO - 2019-08-19 18:43:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-19 18:43:39 --> Config Class Initialized
INFO - 2019-08-19 18:43:39 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:43:39 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:43:39 --> Utf8 Class Initialized
INFO - 2019-08-19 18:43:39 --> URI Class Initialized
INFO - 2019-08-19 18:43:39 --> Router Class Initialized
INFO - 2019-08-19 18:43:39 --> Output Class Initialized
INFO - 2019-08-19 18:43:39 --> Security Class Initialized
DEBUG - 2019-08-19 18:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:43:39 --> Input Class Initialized
INFO - 2019-08-19 18:43:39 --> Language Class Initialized
INFO - 2019-08-19 18:43:39 --> Loader Class Initialized
INFO - 2019-08-19 18:43:39 --> Helper loaded: url_helper
INFO - 2019-08-19 18:43:39 --> Helper loaded: html_helper
INFO - 2019-08-19 18:43:39 --> Helper loaded: form_helper
INFO - 2019-08-19 18:43:39 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:43:39 --> Helper loaded: date_helper
INFO - 2019-08-19 18:43:39 --> Form Validation Class Initialized
INFO - 2019-08-19 18:43:39 --> Email Class Initialized
DEBUG - 2019-08-19 18:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:43:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:43:39 --> Pagination Class Initialized
INFO - 2019-08-19 18:43:39 --> Database Driver Class Initialized
INFO - 2019-08-19 18:43:39 --> Database Driver Class Initialized
INFO - 2019-08-19 18:43:39 --> Controller Class Initialized
INFO - 2019-08-19 18:43:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:43:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomtype.php
INFO - 2019-08-19 18:43:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:43:39 --> Final output sent to browser
DEBUG - 2019-08-19 18:43:39 --> Total execution time: 0.2530
INFO - 2019-08-19 18:44:45 --> Config Class Initialized
INFO - 2019-08-19 18:44:45 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:44:45 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:44:45 --> Config Class Initialized
INFO - 2019-08-19 18:44:45 --> Hooks Class Initialized
INFO - 2019-08-19 18:44:45 --> Utf8 Class Initialized
INFO - 2019-08-19 18:44:45 --> URI Class Initialized
DEBUG - 2019-08-19 18:44:45 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:44:45 --> Utf8 Class Initialized
INFO - 2019-08-19 18:44:45 --> URI Class Initialized
INFO - 2019-08-19 18:44:45 --> Router Class Initialized
INFO - 2019-08-19 18:44:45 --> Output Class Initialized
INFO - 2019-08-19 18:44:45 --> Router Class Initialized
INFO - 2019-08-19 18:44:45 --> Security Class Initialized
INFO - 2019-08-19 18:44:45 --> Output Class Initialized
DEBUG - 2019-08-19 18:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:44:45 --> Input Class Initialized
INFO - 2019-08-19 18:44:45 --> Language Class Initialized
INFO - 2019-08-19 18:44:45 --> Security Class Initialized
DEBUG - 2019-08-19 18:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:44:45 --> Input Class Initialized
INFO - 2019-08-19 18:44:45 --> Language Class Initialized
INFO - 2019-08-19 18:44:45 --> Loader Class Initialized
INFO - 2019-08-19 18:44:45 --> Helper loaded: url_helper
INFO - 2019-08-19 18:44:45 --> Helper loaded: html_helper
INFO - 2019-08-19 18:44:45 --> Helper loaded: form_helper
INFO - 2019-08-19 18:44:45 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:44:45 --> Helper loaded: date_helper
INFO - 2019-08-19 18:44:45 --> Loader Class Initialized
INFO - 2019-08-19 18:44:45 --> Helper loaded: url_helper
INFO - 2019-08-19 18:44:46 --> Helper loaded: html_helper
INFO - 2019-08-19 18:44:46 --> Helper loaded: form_helper
INFO - 2019-08-19 18:44:46 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:44:46 --> Config Class Initialized
INFO - 2019-08-19 18:44:46 --> Hooks Class Initialized
INFO - 2019-08-19 18:44:46 --> Helper loaded: date_helper
DEBUG - 2019-08-19 18:44:46 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:44:46 --> Utf8 Class Initialized
INFO - 2019-08-19 18:44:46 --> URI Class Initialized
INFO - 2019-08-19 18:44:46 --> Form Validation Class Initialized
INFO - 2019-08-19 18:44:46 --> Form Validation Class Initialized
INFO - 2019-08-19 18:44:46 --> Email Class Initialized
INFO - 2019-08-19 18:44:46 --> Email Class Initialized
DEBUG - 2019-08-19 18:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-19 18:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:44:46 --> Router Class Initialized
INFO - 2019-08-19 18:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:44:46 --> Output Class Initialized
INFO - 2019-08-19 18:44:46 --> Pagination Class Initialized
INFO - 2019-08-19 18:44:46 --> Security Class Initialized
DEBUG - 2019-08-19 18:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:44:46 --> Input Class Initialized
INFO - 2019-08-19 18:44:46 --> Language Class Initialized
INFO - 2019-08-19 18:44:46 --> Loader Class Initialized
INFO - 2019-08-19 18:44:46 --> Helper loaded: url_helper
INFO - 2019-08-19 18:44:46 --> Helper loaded: html_helper
INFO - 2019-08-19 18:44:46 --> Database Driver Class Initialized
INFO - 2019-08-19 18:44:46 --> Database Driver Class Initialized
INFO - 2019-08-19 18:44:46 --> Helper loaded: form_helper
INFO - 2019-08-19 18:44:46 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:44:46 --> Helper loaded: date_helper
INFO - 2019-08-19 18:44:46 --> Controller Class Initialized
INFO - 2019-08-19 18:44:46 --> Form Validation Class Initialized
INFO - 2019-08-19 18:44:46 --> Final output sent to browser
DEBUG - 2019-08-19 18:44:46 --> Total execution time: 0.5800
INFO - 2019-08-19 18:44:46 --> Email Class Initialized
INFO - 2019-08-19 18:44:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-08-19 18:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:44:46 --> Pagination Class Initialized
INFO - 2019-08-19 18:44:46 --> Database Driver Class Initialized
INFO - 2019-08-19 18:44:46 --> Database Driver Class Initialized
INFO - 2019-08-19 18:44:46 --> Controller Class Initialized
INFO - 2019-08-19 18:44:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:44:46 --> Final output sent to browser
DEBUG - 2019-08-19 18:44:46 --> Total execution time: 0.6830
INFO - 2019-08-19 18:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:44:46 --> Pagination Class Initialized
INFO - 2019-08-19 18:44:46 --> Database Driver Class Initialized
INFO - 2019-08-19 18:44:46 --> Database Driver Class Initialized
INFO - 2019-08-19 18:44:46 --> Controller Class Initialized
INFO - 2019-08-19 18:44:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:44:46 --> Final output sent to browser
DEBUG - 2019-08-19 18:44:46 --> Total execution time: 0.6750
INFO - 2019-08-19 18:44:50 --> Config Class Initialized
INFO - 2019-08-19 18:44:50 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:44:50 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:44:50 --> Utf8 Class Initialized
INFO - 2019-08-19 18:44:50 --> URI Class Initialized
INFO - 2019-08-19 18:44:50 --> Router Class Initialized
INFO - 2019-08-19 18:44:50 --> Output Class Initialized
INFO - 2019-08-19 18:44:50 --> Security Class Initialized
DEBUG - 2019-08-19 18:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:44:50 --> Input Class Initialized
INFO - 2019-08-19 18:44:50 --> Language Class Initialized
INFO - 2019-08-19 18:44:50 --> Loader Class Initialized
INFO - 2019-08-19 18:44:50 --> Helper loaded: url_helper
INFO - 2019-08-19 18:44:50 --> Helper loaded: html_helper
INFO - 2019-08-19 18:44:50 --> Helper loaded: form_helper
INFO - 2019-08-19 18:44:50 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:44:50 --> Helper loaded: date_helper
INFO - 2019-08-19 18:44:50 --> Form Validation Class Initialized
INFO - 2019-08-19 18:44:50 --> Email Class Initialized
DEBUG - 2019-08-19 18:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:44:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:44:50 --> Pagination Class Initialized
INFO - 2019-08-19 18:44:50 --> Database Driver Class Initialized
INFO - 2019-08-19 18:44:50 --> Database Driver Class Initialized
INFO - 2019-08-19 18:44:50 --> Controller Class Initialized
INFO - 2019-08-19 18:44:50 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:44:50 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomclass.php
INFO - 2019-08-19 18:44:50 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:44:50 --> Final output sent to browser
DEBUG - 2019-08-19 18:44:50 --> Total execution time: 0.2710
INFO - 2019-08-19 18:45:25 --> Config Class Initialized
INFO - 2019-08-19 18:45:25 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:45:25 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:45:25 --> Utf8 Class Initialized
INFO - 2019-08-19 18:45:25 --> Config Class Initialized
INFO - 2019-08-19 18:45:25 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:45:25 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:45:25 --> Utf8 Class Initialized
INFO - 2019-08-19 18:45:25 --> URI Class Initialized
INFO - 2019-08-19 18:45:25 --> Router Class Initialized
INFO - 2019-08-19 18:45:25 --> Output Class Initialized
INFO - 2019-08-19 18:45:25 --> Security Class Initialized
DEBUG - 2019-08-19 18:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:45:25 --> Input Class Initialized
INFO - 2019-08-19 18:45:25 --> Language Class Initialized
INFO - 2019-08-19 18:45:25 --> URI Class Initialized
INFO - 2019-08-19 18:45:25 --> Router Class Initialized
INFO - 2019-08-19 18:45:25 --> Output Class Initialized
INFO - 2019-08-19 18:45:25 --> Security Class Initialized
DEBUG - 2019-08-19 18:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:45:25 --> Input Class Initialized
INFO - 2019-08-19 18:45:25 --> Language Class Initialized
INFO - 2019-08-19 18:45:25 --> Loader Class Initialized
INFO - 2019-08-19 18:45:25 --> Helper loaded: url_helper
INFO - 2019-08-19 18:45:25 --> Helper loaded: html_helper
INFO - 2019-08-19 18:45:25 --> Helper loaded: form_helper
INFO - 2019-08-19 18:45:25 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:45:25 --> Helper loaded: date_helper
INFO - 2019-08-19 18:45:25 --> Loader Class Initialized
INFO - 2019-08-19 18:45:25 --> Helper loaded: url_helper
INFO - 2019-08-19 18:45:25 --> Helper loaded: html_helper
INFO - 2019-08-19 18:45:25 --> Helper loaded: form_helper
INFO - 2019-08-19 18:45:25 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:45:25 --> Helper loaded: date_helper
INFO - 2019-08-19 18:45:25 --> Form Validation Class Initialized
INFO - 2019-08-19 18:45:25 --> Form Validation Class Initialized
INFO - 2019-08-19 18:45:25 --> Email Class Initialized
DEBUG - 2019-08-19 18:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:45:25 --> Pagination Class Initialized
INFO - 2019-08-19 18:45:25 --> Email Class Initialized
DEBUG - 2019-08-19 18:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:45:25 --> Database Driver Class Initialized
INFO - 2019-08-19 18:45:25 --> Database Driver Class Initialized
INFO - 2019-08-19 18:45:25 --> Controller Class Initialized
INFO - 2019-08-19 18:45:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:45:25 --> Final output sent to browser
DEBUG - 2019-08-19 18:45:25 --> Total execution time: 0.6940
INFO - 2019-08-19 18:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:45:25 --> Pagination Class Initialized
INFO - 2019-08-19 18:45:25 --> Database Driver Class Initialized
INFO - 2019-08-19 18:45:25 --> Database Driver Class Initialized
INFO - 2019-08-19 18:45:25 --> Controller Class Initialized
INFO - 2019-08-19 18:45:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:45:25 --> Final output sent to browser
DEBUG - 2019-08-19 18:45:25 --> Total execution time: 0.7730
INFO - 2019-08-19 18:45:28 --> Config Class Initialized
INFO - 2019-08-19 18:45:28 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:45:28 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:45:28 --> Utf8 Class Initialized
INFO - 2019-08-19 18:45:28 --> URI Class Initialized
INFO - 2019-08-19 18:45:28 --> Router Class Initialized
INFO - 2019-08-19 18:45:28 --> Output Class Initialized
INFO - 2019-08-19 18:45:28 --> Security Class Initialized
DEBUG - 2019-08-19 18:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:45:28 --> Input Class Initialized
INFO - 2019-08-19 18:45:28 --> Language Class Initialized
INFO - 2019-08-19 18:45:28 --> Loader Class Initialized
INFO - 2019-08-19 18:45:28 --> Helper loaded: url_helper
INFO - 2019-08-19 18:45:28 --> Helper loaded: html_helper
INFO - 2019-08-19 18:45:28 --> Helper loaded: form_helper
INFO - 2019-08-19 18:45:28 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:45:28 --> Helper loaded: date_helper
INFO - 2019-08-19 18:45:28 --> Form Validation Class Initialized
INFO - 2019-08-19 18:45:28 --> Email Class Initialized
DEBUG - 2019-08-19 18:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:45:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:45:28 --> Pagination Class Initialized
INFO - 2019-08-19 18:45:28 --> Database Driver Class Initialized
INFO - 2019-08-19 18:45:28 --> Database Driver Class Initialized
INFO - 2019-08-19 18:45:29 --> Controller Class Initialized
INFO - 2019-08-19 18:45:29 --> Final output sent to browser
DEBUG - 2019-08-19 18:45:29 --> Total execution time: 0.2330
INFO - 2019-08-19 18:45:42 --> Config Class Initialized
INFO - 2019-08-19 18:45:42 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:45:42 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:45:42 --> Utf8 Class Initialized
INFO - 2019-08-19 18:45:42 --> URI Class Initialized
INFO - 2019-08-19 18:45:42 --> Router Class Initialized
INFO - 2019-08-19 18:45:42 --> Output Class Initialized
INFO - 2019-08-19 18:45:42 --> Security Class Initialized
DEBUG - 2019-08-19 18:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:45:42 --> Input Class Initialized
INFO - 2019-08-19 18:45:42 --> Language Class Initialized
INFO - 2019-08-19 18:45:42 --> Loader Class Initialized
INFO - 2019-08-19 18:45:42 --> Helper loaded: url_helper
INFO - 2019-08-19 18:45:42 --> Helper loaded: html_helper
INFO - 2019-08-19 18:45:42 --> Helper loaded: form_helper
INFO - 2019-08-19 18:45:42 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:45:42 --> Helper loaded: date_helper
INFO - 2019-08-19 18:45:42 --> Form Validation Class Initialized
INFO - 2019-08-19 18:45:42 --> Email Class Initialized
DEBUG - 2019-08-19 18:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:45:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:45:42 --> Pagination Class Initialized
INFO - 2019-08-19 18:45:42 --> Database Driver Class Initialized
INFO - 2019-08-19 18:45:42 --> Database Driver Class Initialized
INFO - 2019-08-19 18:45:42 --> Controller Class Initialized
INFO - 2019-08-19 18:45:42 --> Final output sent to browser
DEBUG - 2019-08-19 18:45:42 --> Total execution time: 0.2920
INFO - 2019-08-19 18:45:45 --> Config Class Initialized
INFO - 2019-08-19 18:45:45 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:45:45 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:45:45 --> Utf8 Class Initialized
INFO - 2019-08-19 18:45:45 --> URI Class Initialized
INFO - 2019-08-19 18:45:45 --> Router Class Initialized
INFO - 2019-08-19 18:45:45 --> Output Class Initialized
INFO - 2019-08-19 18:45:45 --> Security Class Initialized
DEBUG - 2019-08-19 18:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:45:45 --> Input Class Initialized
INFO - 2019-08-19 18:45:45 --> Language Class Initialized
INFO - 2019-08-19 18:45:45 --> Loader Class Initialized
INFO - 2019-08-19 18:45:45 --> Helper loaded: url_helper
INFO - 2019-08-19 18:45:45 --> Helper loaded: html_helper
INFO - 2019-08-19 18:45:45 --> Helper loaded: form_helper
INFO - 2019-08-19 18:45:45 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:45:45 --> Helper loaded: date_helper
INFO - 2019-08-19 18:45:45 --> Form Validation Class Initialized
INFO - 2019-08-19 18:45:45 --> Email Class Initialized
DEBUG - 2019-08-19 18:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:45:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:45:45 --> Pagination Class Initialized
INFO - 2019-08-19 18:45:45 --> Database Driver Class Initialized
INFO - 2019-08-19 18:45:45 --> Database Driver Class Initialized
INFO - 2019-08-19 18:45:45 --> Controller Class Initialized
INFO - 2019-08-19 18:45:45 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:45:45 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomclass.php
INFO - 2019-08-19 18:45:45 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:45:45 --> Final output sent to browser
DEBUG - 2019-08-19 18:45:45 --> Total execution time: 0.3480
INFO - 2019-08-19 18:45:51 --> Config Class Initialized
INFO - 2019-08-19 18:45:51 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:45:51 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:45:51 --> Utf8 Class Initialized
INFO - 2019-08-19 18:45:51 --> URI Class Initialized
INFO - 2019-08-19 18:45:51 --> Router Class Initialized
INFO - 2019-08-19 18:45:51 --> Output Class Initialized
INFO - 2019-08-19 18:45:51 --> Security Class Initialized
DEBUG - 2019-08-19 18:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:45:51 --> Input Class Initialized
INFO - 2019-08-19 18:45:51 --> Language Class Initialized
INFO - 2019-08-19 18:45:51 --> Loader Class Initialized
INFO - 2019-08-19 18:45:51 --> Helper loaded: url_helper
INFO - 2019-08-19 18:45:51 --> Helper loaded: html_helper
INFO - 2019-08-19 18:45:51 --> Helper loaded: form_helper
INFO - 2019-08-19 18:45:51 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:45:51 --> Helper loaded: date_helper
INFO - 2019-08-19 18:45:51 --> Form Validation Class Initialized
INFO - 2019-08-19 18:45:51 --> Email Class Initialized
DEBUG - 2019-08-19 18:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:45:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:45:51 --> Pagination Class Initialized
INFO - 2019-08-19 18:45:51 --> Database Driver Class Initialized
INFO - 2019-08-19 18:45:51 --> Database Driver Class Initialized
INFO - 2019-08-19 18:45:51 --> Controller Class Initialized
INFO - 2019-08-19 18:45:51 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:45:51 --> Final output sent to browser
DEBUG - 2019-08-19 18:45:51 --> Total execution time: 0.2310
INFO - 2019-08-19 18:46:07 --> Config Class Initialized
INFO - 2019-08-19 18:46:07 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:46:07 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:46:07 --> Utf8 Class Initialized
INFO - 2019-08-19 18:46:07 --> URI Class Initialized
INFO - 2019-08-19 18:46:07 --> Router Class Initialized
INFO - 2019-08-19 18:46:07 --> Output Class Initialized
INFO - 2019-08-19 18:46:07 --> Security Class Initialized
DEBUG - 2019-08-19 18:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:46:07 --> Input Class Initialized
INFO - 2019-08-19 18:46:07 --> Config Class Initialized
INFO - 2019-08-19 18:46:07 --> Hooks Class Initialized
INFO - 2019-08-19 18:46:07 --> Language Class Initialized
DEBUG - 2019-08-19 18:46:07 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:46:07 --> Utf8 Class Initialized
INFO - 2019-08-19 18:46:07 --> URI Class Initialized
INFO - 2019-08-19 18:46:07 --> Loader Class Initialized
INFO - 2019-08-19 18:46:07 --> Helper loaded: url_helper
INFO - 2019-08-19 18:46:07 --> Helper loaded: html_helper
INFO - 2019-08-19 18:46:07 --> Helper loaded: form_helper
INFO - 2019-08-19 18:46:07 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:46:07 --> Helper loaded: date_helper
INFO - 2019-08-19 18:46:07 --> Form Validation Class Initialized
INFO - 2019-08-19 18:46:07 --> Email Class Initialized
DEBUG - 2019-08-19 18:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:46:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:46:07 --> Pagination Class Initialized
INFO - 2019-08-19 18:46:07 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:07 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:07 --> Router Class Initialized
INFO - 2019-08-19 18:46:07 --> Output Class Initialized
INFO - 2019-08-19 18:46:07 --> Security Class Initialized
DEBUG - 2019-08-19 18:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:46:07 --> Input Class Initialized
INFO - 2019-08-19 18:46:07 --> Language Class Initialized
INFO - 2019-08-19 18:46:07 --> Loader Class Initialized
INFO - 2019-08-19 18:46:07 --> Helper loaded: url_helper
INFO - 2019-08-19 18:46:07 --> Helper loaded: html_helper
INFO - 2019-08-19 18:46:07 --> Helper loaded: form_helper
INFO - 2019-08-19 18:46:07 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:46:07 --> Helper loaded: date_helper
INFO - 2019-08-19 18:46:07 --> Form Validation Class Initialized
INFO - 2019-08-19 18:46:07 --> Email Class Initialized
DEBUG - 2019-08-19 18:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:46:07 --> Controller Class Initialized
INFO - 2019-08-19 18:46:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:46:07 --> Final output sent to browser
DEBUG - 2019-08-19 18:46:07 --> Total execution time: 0.2840
INFO - 2019-08-19 18:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:46:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:46:07 --> Pagination Class Initialized
INFO - 2019-08-19 18:46:07 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:07 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:07 --> Controller Class Initialized
INFO - 2019-08-19 18:46:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:46:07 --> Final output sent to browser
DEBUG - 2019-08-19 18:46:07 --> Total execution time: 0.3420
INFO - 2019-08-19 18:46:08 --> Config Class Initialized
INFO - 2019-08-19 18:46:08 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:46:08 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:46:08 --> Utf8 Class Initialized
INFO - 2019-08-19 18:46:08 --> URI Class Initialized
INFO - 2019-08-19 18:46:08 --> Router Class Initialized
INFO - 2019-08-19 18:46:08 --> Output Class Initialized
INFO - 2019-08-19 18:46:08 --> Security Class Initialized
DEBUG - 2019-08-19 18:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:46:08 --> Input Class Initialized
INFO - 2019-08-19 18:46:08 --> Language Class Initialized
INFO - 2019-08-19 18:46:08 --> Loader Class Initialized
INFO - 2019-08-19 18:46:08 --> Helper loaded: url_helper
INFO - 2019-08-19 18:46:08 --> Helper loaded: html_helper
INFO - 2019-08-19 18:46:08 --> Helper loaded: form_helper
INFO - 2019-08-19 18:46:08 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:46:08 --> Helper loaded: date_helper
INFO - 2019-08-19 18:46:08 --> Form Validation Class Initialized
INFO - 2019-08-19 18:46:08 --> Email Class Initialized
DEBUG - 2019-08-19 18:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:46:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:46:08 --> Pagination Class Initialized
INFO - 2019-08-19 18:46:08 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:08 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:08 --> Controller Class Initialized
INFO - 2019-08-19 18:46:08 --> Final output sent to browser
DEBUG - 2019-08-19 18:46:08 --> Total execution time: 0.3150
INFO - 2019-08-19 18:46:16 --> Config Class Initialized
INFO - 2019-08-19 18:46:16 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:46:16 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:46:16 --> Utf8 Class Initialized
INFO - 2019-08-19 18:46:16 --> URI Class Initialized
INFO - 2019-08-19 18:46:16 --> Router Class Initialized
INFO - 2019-08-19 18:46:16 --> Output Class Initialized
INFO - 2019-08-19 18:46:16 --> Security Class Initialized
DEBUG - 2019-08-19 18:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:46:16 --> Input Class Initialized
INFO - 2019-08-19 18:46:16 --> Language Class Initialized
INFO - 2019-08-19 18:46:16 --> Loader Class Initialized
INFO - 2019-08-19 18:46:16 --> Helper loaded: url_helper
INFO - 2019-08-19 18:46:16 --> Helper loaded: html_helper
INFO - 2019-08-19 18:46:16 --> Helper loaded: form_helper
INFO - 2019-08-19 18:46:16 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:46:16 --> Helper loaded: date_helper
INFO - 2019-08-19 18:46:16 --> Form Validation Class Initialized
INFO - 2019-08-19 18:46:16 --> Email Class Initialized
DEBUG - 2019-08-19 18:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:46:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:46:16 --> Pagination Class Initialized
INFO - 2019-08-19 18:46:16 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:16 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:16 --> Controller Class Initialized
INFO - 2019-08-19 18:46:16 --> Final output sent to browser
DEBUG - 2019-08-19 18:46:16 --> Total execution time: 0.2840
INFO - 2019-08-19 18:46:19 --> Config Class Initialized
INFO - 2019-08-19 18:46:19 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:46:19 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:46:19 --> Utf8 Class Initialized
INFO - 2019-08-19 18:46:19 --> URI Class Initialized
INFO - 2019-08-19 18:46:19 --> Router Class Initialized
INFO - 2019-08-19 18:46:19 --> Output Class Initialized
INFO - 2019-08-19 18:46:19 --> Security Class Initialized
DEBUG - 2019-08-19 18:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:46:19 --> Input Class Initialized
INFO - 2019-08-19 18:46:19 --> Language Class Initialized
INFO - 2019-08-19 18:46:19 --> Loader Class Initialized
INFO - 2019-08-19 18:46:19 --> Helper loaded: url_helper
INFO - 2019-08-19 18:46:19 --> Helper loaded: html_helper
INFO - 2019-08-19 18:46:19 --> Helper loaded: form_helper
INFO - 2019-08-19 18:46:19 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:46:19 --> Helper loaded: date_helper
INFO - 2019-08-19 18:46:19 --> Form Validation Class Initialized
INFO - 2019-08-19 18:46:19 --> Email Class Initialized
DEBUG - 2019-08-19 18:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:46:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:46:19 --> Pagination Class Initialized
INFO - 2019-08-19 18:46:19 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:19 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:19 --> Controller Class Initialized
INFO - 2019-08-19 18:46:19 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:46:19 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/roomclass.php
INFO - 2019-08-19 18:46:19 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:46:19 --> Final output sent to browser
DEBUG - 2019-08-19 18:46:19 --> Total execution time: 0.3240
INFO - 2019-08-19 18:46:20 --> Config Class Initialized
INFO - 2019-08-19 18:46:20 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:46:20 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:46:20 --> Utf8 Class Initialized
INFO - 2019-08-19 18:46:20 --> URI Class Initialized
INFO - 2019-08-19 18:46:20 --> Router Class Initialized
INFO - 2019-08-19 18:46:20 --> Output Class Initialized
INFO - 2019-08-19 18:46:20 --> Security Class Initialized
DEBUG - 2019-08-19 18:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:46:20 --> Input Class Initialized
INFO - 2019-08-19 18:46:20 --> Language Class Initialized
INFO - 2019-08-19 18:46:20 --> Loader Class Initialized
INFO - 2019-08-19 18:46:20 --> Helper loaded: url_helper
INFO - 2019-08-19 18:46:20 --> Helper loaded: html_helper
INFO - 2019-08-19 18:46:20 --> Helper loaded: form_helper
INFO - 2019-08-19 18:46:20 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:46:20 --> Helper loaded: date_helper
INFO - 2019-08-19 18:46:20 --> Form Validation Class Initialized
INFO - 2019-08-19 18:46:20 --> Email Class Initialized
DEBUG - 2019-08-19 18:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:46:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:46:21 --> Pagination Class Initialized
INFO - 2019-08-19 18:46:21 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:21 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:21 --> Controller Class Initialized
INFO - 2019-08-19 18:46:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:46:21 --> Final output sent to browser
DEBUG - 2019-08-19 18:46:21 --> Total execution time: 0.3080
INFO - 2019-08-19 18:46:42 --> Config Class Initialized
INFO - 2019-08-19 18:46:42 --> Hooks Class Initialized
INFO - 2019-08-19 18:46:42 --> Config Class Initialized
INFO - 2019-08-19 18:46:42 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:46:42 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:46:42 --> Utf8 Class Initialized
DEBUG - 2019-08-19 18:46:42 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:46:42 --> Utf8 Class Initialized
INFO - 2019-08-19 18:46:42 --> URI Class Initialized
INFO - 2019-08-19 18:46:42 --> URI Class Initialized
INFO - 2019-08-19 18:46:42 --> Router Class Initialized
INFO - 2019-08-19 18:46:42 --> Router Class Initialized
INFO - 2019-08-19 18:46:42 --> Output Class Initialized
INFO - 2019-08-19 18:46:42 --> Security Class Initialized
INFO - 2019-08-19 18:46:42 --> Output Class Initialized
DEBUG - 2019-08-19 18:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:46:42 --> Input Class Initialized
INFO - 2019-08-19 18:46:42 --> Language Class Initialized
INFO - 2019-08-19 18:46:42 --> Security Class Initialized
DEBUG - 2019-08-19 18:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:46:42 --> Input Class Initialized
INFO - 2019-08-19 18:46:42 --> Language Class Initialized
INFO - 2019-08-19 18:46:42 --> Loader Class Initialized
INFO - 2019-08-19 18:46:42 --> Helper loaded: url_helper
INFO - 2019-08-19 18:46:42 --> Helper loaded: html_helper
INFO - 2019-08-19 18:46:42 --> Helper loaded: form_helper
INFO - 2019-08-19 18:46:42 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:46:42 --> Loader Class Initialized
INFO - 2019-08-19 18:46:42 --> Helper loaded: url_helper
INFO - 2019-08-19 18:46:42 --> Helper loaded: date_helper
INFO - 2019-08-19 18:46:42 --> Form Validation Class Initialized
INFO - 2019-08-19 18:46:42 --> Email Class Initialized
INFO - 2019-08-19 18:46:42 --> Helper loaded: html_helper
INFO - 2019-08-19 18:46:42 --> Helper loaded: form_helper
INFO - 2019-08-19 18:46:42 --> Helper loaded: cookie_helper
DEBUG - 2019-08-19 18:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:46:42 --> Helper loaded: date_helper
INFO - 2019-08-19 18:46:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:46:42 --> Form Validation Class Initialized
INFO - 2019-08-19 18:46:42 --> Pagination Class Initialized
INFO - 2019-08-19 18:46:42 --> Email Class Initialized
INFO - 2019-08-19 18:46:42 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:42 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:42 --> Controller Class Initialized
INFO - 2019-08-19 18:46:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:46:42 --> Final output sent to browser
DEBUG - 2019-08-19 18:46:42 --> Total execution time: 0.2400
DEBUG - 2019-08-19 18:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:46:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:46:42 --> Pagination Class Initialized
INFO - 2019-08-19 18:46:42 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:42 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:42 --> Controller Class Initialized
INFO - 2019-08-19 18:46:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:46:42 --> Final output sent to browser
DEBUG - 2019-08-19 18:46:42 --> Total execution time: 0.3640
INFO - 2019-08-19 18:46:43 --> Config Class Initialized
INFO - 2019-08-19 18:46:43 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:46:43 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:46:43 --> Utf8 Class Initialized
INFO - 2019-08-19 18:46:43 --> URI Class Initialized
INFO - 2019-08-19 18:46:43 --> Router Class Initialized
INFO - 2019-08-19 18:46:43 --> Output Class Initialized
INFO - 2019-08-19 18:46:43 --> Security Class Initialized
DEBUG - 2019-08-19 18:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:46:43 --> Input Class Initialized
INFO - 2019-08-19 18:46:43 --> Language Class Initialized
INFO - 2019-08-19 18:46:43 --> Loader Class Initialized
INFO - 2019-08-19 18:46:43 --> Helper loaded: url_helper
INFO - 2019-08-19 18:46:43 --> Helper loaded: html_helper
INFO - 2019-08-19 18:46:43 --> Helper loaded: form_helper
INFO - 2019-08-19 18:46:43 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:46:43 --> Helper loaded: date_helper
INFO - 2019-08-19 18:46:43 --> Form Validation Class Initialized
INFO - 2019-08-19 18:46:43 --> Email Class Initialized
DEBUG - 2019-08-19 18:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:46:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:46:43 --> Pagination Class Initialized
INFO - 2019-08-19 18:46:43 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:43 --> Database Driver Class Initialized
INFO - 2019-08-19 18:46:43 --> Controller Class Initialized
INFO - 2019-08-19 18:46:43 --> Final output sent to browser
DEBUG - 2019-08-19 18:46:43 --> Total execution time: 0.3690
INFO - 2019-08-19 18:47:07 --> Config Class Initialized
INFO - 2019-08-19 18:47:07 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:47:07 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:47:07 --> Utf8 Class Initialized
INFO - 2019-08-19 18:47:07 --> URI Class Initialized
INFO - 2019-08-19 18:47:07 --> Router Class Initialized
INFO - 2019-08-19 18:47:07 --> Output Class Initialized
INFO - 2019-08-19 18:47:07 --> Security Class Initialized
DEBUG - 2019-08-19 18:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:47:07 --> Input Class Initialized
INFO - 2019-08-19 18:47:07 --> Language Class Initialized
INFO - 2019-08-19 18:47:07 --> Loader Class Initialized
INFO - 2019-08-19 18:47:07 --> Helper loaded: url_helper
INFO - 2019-08-19 18:47:08 --> Helper loaded: html_helper
INFO - 2019-08-19 18:47:08 --> Helper loaded: form_helper
INFO - 2019-08-19 18:47:08 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:47:08 --> Helper loaded: date_helper
INFO - 2019-08-19 18:47:08 --> Form Validation Class Initialized
INFO - 2019-08-19 18:47:08 --> Email Class Initialized
DEBUG - 2019-08-19 18:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:47:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:47:08 --> Pagination Class Initialized
INFO - 2019-08-19 18:47:08 --> Database Driver Class Initialized
INFO - 2019-08-19 18:47:08 --> Database Driver Class Initialized
INFO - 2019-08-19 18:47:08 --> Controller Class Initialized
INFO - 2019-08-19 18:47:08 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:47:08 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-19 18:47:08 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:47:08 --> Final output sent to browser
DEBUG - 2019-08-19 18:47:08 --> Total execution time: 0.3950
INFO - 2019-08-19 18:48:11 --> Config Class Initialized
INFO - 2019-08-19 18:48:11 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:48:11 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:48:11 --> Utf8 Class Initialized
INFO - 2019-08-19 18:48:11 --> URI Class Initialized
INFO - 2019-08-19 18:48:11 --> Router Class Initialized
INFO - 2019-08-19 18:48:11 --> Output Class Initialized
INFO - 2019-08-19 18:48:11 --> Security Class Initialized
DEBUG - 2019-08-19 18:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:48:11 --> Input Class Initialized
INFO - 2019-08-19 18:48:11 --> Language Class Initialized
INFO - 2019-08-19 18:48:11 --> Loader Class Initialized
INFO - 2019-08-19 18:48:11 --> Helper loaded: url_helper
INFO - 2019-08-19 18:48:11 --> Helper loaded: html_helper
INFO - 2019-08-19 18:48:11 --> Helper loaded: form_helper
INFO - 2019-08-19 18:48:11 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:48:11 --> Helper loaded: date_helper
INFO - 2019-08-19 18:48:11 --> Form Validation Class Initialized
INFO - 2019-08-19 18:48:11 --> Email Class Initialized
DEBUG - 2019-08-19 18:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:48:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:48:11 --> Pagination Class Initialized
INFO - 2019-08-19 18:48:11 --> Database Driver Class Initialized
INFO - 2019-08-19 18:48:11 --> Database Driver Class Initialized
INFO - 2019-08-19 18:48:11 --> Controller Class Initialized
INFO - 2019-08-19 18:48:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:48:11 --> Final output sent to browser
DEBUG - 2019-08-19 18:48:11 --> Total execution time: 0.2310
INFO - 2019-08-19 18:48:12 --> Config Class Initialized
INFO - 2019-08-19 18:48:12 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:48:12 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:48:12 --> Utf8 Class Initialized
INFO - 2019-08-19 18:48:12 --> URI Class Initialized
INFO - 2019-08-19 18:48:12 --> Router Class Initialized
INFO - 2019-08-19 18:48:12 --> Output Class Initialized
INFO - 2019-08-19 18:48:12 --> Security Class Initialized
DEBUG - 2019-08-19 18:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:48:12 --> Input Class Initialized
INFO - 2019-08-19 18:48:12 --> Language Class Initialized
INFO - 2019-08-19 18:48:12 --> Loader Class Initialized
INFO - 2019-08-19 18:48:12 --> Helper loaded: url_helper
INFO - 2019-08-19 18:48:12 --> Helper loaded: html_helper
INFO - 2019-08-19 18:48:12 --> Helper loaded: form_helper
INFO - 2019-08-19 18:48:12 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:48:12 --> Helper loaded: date_helper
INFO - 2019-08-19 18:48:12 --> Form Validation Class Initialized
INFO - 2019-08-19 18:48:12 --> Email Class Initialized
DEBUG - 2019-08-19 18:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:48:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:48:12 --> Pagination Class Initialized
INFO - 2019-08-19 18:48:12 --> Database Driver Class Initialized
INFO - 2019-08-19 18:48:12 --> Database Driver Class Initialized
INFO - 2019-08-19 18:48:12 --> Controller Class Initialized
INFO - 2019-08-19 18:48:12 --> Final output sent to browser
DEBUG - 2019-08-19 18:48:12 --> Total execution time: 0.3760
INFO - 2019-08-19 18:51:47 --> Config Class Initialized
INFO - 2019-08-19 18:51:47 --> Hooks Class Initialized
INFO - 2019-08-19 18:51:47 --> Config Class Initialized
INFO - 2019-08-19 18:51:47 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:51:47 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:51:47 --> Utf8 Class Initialized
INFO - 2019-08-19 18:51:47 --> URI Class Initialized
DEBUG - 2019-08-19 18:51:47 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:51:47 --> Utf8 Class Initialized
INFO - 2019-08-19 18:51:47 --> Router Class Initialized
INFO - 2019-08-19 18:51:47 --> URI Class Initialized
INFO - 2019-08-19 18:51:47 --> Output Class Initialized
INFO - 2019-08-19 18:51:47 --> Router Class Initialized
INFO - 2019-08-19 18:51:47 --> Security Class Initialized
DEBUG - 2019-08-19 18:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:51:47 --> Input Class Initialized
INFO - 2019-08-19 18:51:47 --> Language Class Initialized
INFO - 2019-08-19 18:51:47 --> Output Class Initialized
INFO - 2019-08-19 18:51:47 --> Security Class Initialized
DEBUG - 2019-08-19 18:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:51:47 --> Input Class Initialized
INFO - 2019-08-19 18:51:47 --> Language Class Initialized
INFO - 2019-08-19 18:51:47 --> Loader Class Initialized
INFO - 2019-08-19 18:51:47 --> Helper loaded: url_helper
INFO - 2019-08-19 18:51:47 --> Helper loaded: html_helper
INFO - 2019-08-19 18:51:47 --> Helper loaded: form_helper
INFO - 2019-08-19 18:51:47 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:51:47 --> Helper loaded: date_helper
INFO - 2019-08-19 18:51:47 --> Loader Class Initialized
INFO - 2019-08-19 18:51:47 --> Form Validation Class Initialized
INFO - 2019-08-19 18:51:47 --> Helper loaded: url_helper
INFO - 2019-08-19 18:51:47 --> Helper loaded: html_helper
INFO - 2019-08-19 18:51:47 --> Email Class Initialized
INFO - 2019-08-19 18:51:47 --> Helper loaded: form_helper
DEBUG - 2019-08-19 18:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:51:48 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:51:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:51:48 --> Helper loaded: date_helper
INFO - 2019-08-19 18:51:48 --> Pagination Class Initialized
INFO - 2019-08-19 18:51:48 --> Form Validation Class Initialized
INFO - 2019-08-19 18:51:48 --> Email Class Initialized
INFO - 2019-08-19 18:51:48 --> Database Driver Class Initialized
INFO - 2019-08-19 18:51:48 --> Database Driver Class Initialized
DEBUG - 2019-08-19 18:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:51:48 --> Controller Class Initialized
INFO - 2019-08-19 18:51:48 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:51:48 --> Final output sent to browser
DEBUG - 2019-08-19 18:51:48 --> Total execution time: 0.3000
INFO - 2019-08-19 18:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:51:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:51:48 --> Pagination Class Initialized
INFO - 2019-08-19 18:51:48 --> Database Driver Class Initialized
INFO - 2019-08-19 18:51:48 --> Database Driver Class Initialized
INFO - 2019-08-19 18:51:48 --> Controller Class Initialized
INFO - 2019-08-19 18:51:48 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:51:48 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-19 18:51:48 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:51:48 --> Final output sent to browser
DEBUG - 2019-08-19 18:51:48 --> Total execution time: 0.4660
INFO - 2019-08-19 18:52:30 --> Config Class Initialized
INFO - 2019-08-19 18:52:30 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:52:30 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:52:30 --> Utf8 Class Initialized
INFO - 2019-08-19 18:52:30 --> URI Class Initialized
INFO - 2019-08-19 18:52:30 --> Router Class Initialized
INFO - 2019-08-19 18:52:30 --> Config Class Initialized
INFO - 2019-08-19 18:52:30 --> Hooks Class Initialized
INFO - 2019-08-19 18:52:30 --> Output Class Initialized
INFO - 2019-08-19 18:52:30 --> Security Class Initialized
DEBUG - 2019-08-19 18:52:30 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:52:30 --> Utf8 Class Initialized
INFO - 2019-08-19 18:52:30 --> URI Class Initialized
DEBUG - 2019-08-19 18:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:52:30 --> Input Class Initialized
INFO - 2019-08-19 18:52:30 --> Language Class Initialized
INFO - 2019-08-19 18:52:30 --> Router Class Initialized
INFO - 2019-08-19 18:52:30 --> Output Class Initialized
INFO - 2019-08-19 18:52:30 --> Security Class Initialized
DEBUG - 2019-08-19 18:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:52:30 --> Input Class Initialized
INFO - 2019-08-19 18:52:30 --> Language Class Initialized
INFO - 2019-08-19 18:52:30 --> Loader Class Initialized
INFO - 2019-08-19 18:52:30 --> Helper loaded: url_helper
INFO - 2019-08-19 18:52:30 --> Helper loaded: html_helper
INFO - 2019-08-19 18:52:30 --> Helper loaded: form_helper
INFO - 2019-08-19 18:52:30 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:52:30 --> Helper loaded: date_helper
INFO - 2019-08-19 18:52:30 --> Form Validation Class Initialized
INFO - 2019-08-19 18:52:30 --> Email Class Initialized
DEBUG - 2019-08-19 18:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:52:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:52:30 --> Pagination Class Initialized
INFO - 2019-08-19 18:52:30 --> Loader Class Initialized
INFO - 2019-08-19 18:52:30 --> Helper loaded: url_helper
INFO - 2019-08-19 18:52:30 --> Helper loaded: html_helper
INFO - 2019-08-19 18:52:30 --> Helper loaded: form_helper
INFO - 2019-08-19 18:52:30 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:52:30 --> Helper loaded: date_helper
INFO - 2019-08-19 18:52:30 --> Database Driver Class Initialized
INFO - 2019-08-19 18:52:30 --> Database Driver Class Initialized
INFO - 2019-08-19 18:52:30 --> Form Validation Class Initialized
INFO - 2019-08-19 18:52:30 --> Controller Class Initialized
INFO - 2019-08-19 18:52:30 --> Email Class Initialized
DEBUG - 2019-08-19 18:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:52:30 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:52:30 --> Final output sent to browser
DEBUG - 2019-08-19 18:52:30 --> Total execution time: 0.2080
INFO - 2019-08-19 18:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:52:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:52:30 --> Pagination Class Initialized
INFO - 2019-08-19 18:52:30 --> Database Driver Class Initialized
INFO - 2019-08-19 18:52:30 --> Database Driver Class Initialized
INFO - 2019-08-19 18:52:30 --> Controller Class Initialized
INFO - 2019-08-19 18:52:30 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:52:30 --> Final output sent to browser
DEBUG - 2019-08-19 18:52:30 --> Total execution time: 0.3006
INFO - 2019-08-19 18:54:05 --> Config Class Initialized
INFO - 2019-08-19 18:54:05 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:54:05 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:54:05 --> Utf8 Class Initialized
INFO - 2019-08-19 18:54:05 --> URI Class Initialized
INFO - 2019-08-19 18:54:05 --> Router Class Initialized
INFO - 2019-08-19 18:54:05 --> Output Class Initialized
INFO - 2019-08-19 18:54:05 --> Security Class Initialized
DEBUG - 2019-08-19 18:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:54:05 --> Input Class Initialized
INFO - 2019-08-19 18:54:05 --> Language Class Initialized
INFO - 2019-08-19 18:54:05 --> Loader Class Initialized
INFO - 2019-08-19 18:54:05 --> Helper loaded: url_helper
INFO - 2019-08-19 18:54:05 --> Helper loaded: html_helper
INFO - 2019-08-19 18:54:05 --> Helper loaded: form_helper
INFO - 2019-08-19 18:54:05 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:54:05 --> Helper loaded: date_helper
INFO - 2019-08-19 18:54:05 --> Form Validation Class Initialized
INFO - 2019-08-19 18:54:05 --> Email Class Initialized
DEBUG - 2019-08-19 18:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:54:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:54:05 --> Pagination Class Initialized
INFO - 2019-08-19 18:54:05 --> Database Driver Class Initialized
INFO - 2019-08-19 18:54:05 --> Database Driver Class Initialized
INFO - 2019-08-19 18:54:05 --> Controller Class Initialized
INFO - 2019-08-19 18:54:05 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:54:05 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-19 18:54:05 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/guest.php
INFO - 2019-08-19 18:54:05 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:54:05 --> Final output sent to browser
DEBUG - 2019-08-19 18:54:05 --> Total execution time: 0.3030
INFO - 2019-08-19 18:55:08 --> Config Class Initialized
INFO - 2019-08-19 18:55:08 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:55:08 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:55:08 --> Utf8 Class Initialized
INFO - 2019-08-19 18:55:08 --> URI Class Initialized
INFO - 2019-08-19 18:55:08 --> Config Class Initialized
INFO - 2019-08-19 18:55:08 --> Hooks Class Initialized
INFO - 2019-08-19 18:55:08 --> Router Class Initialized
DEBUG - 2019-08-19 18:55:08 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:55:08 --> Utf8 Class Initialized
INFO - 2019-08-19 18:55:08 --> Output Class Initialized
INFO - 2019-08-19 18:55:08 --> URI Class Initialized
INFO - 2019-08-19 18:55:08 --> Security Class Initialized
DEBUG - 2019-08-19 18:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:55:08 --> Input Class Initialized
INFO - 2019-08-19 18:55:08 --> Language Class Initialized
INFO - 2019-08-19 18:55:09 --> Router Class Initialized
INFO - 2019-08-19 18:55:09 --> Output Class Initialized
INFO - 2019-08-19 18:55:09 --> Security Class Initialized
DEBUG - 2019-08-19 18:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:55:09 --> Input Class Initialized
INFO - 2019-08-19 18:55:09 --> Language Class Initialized
INFO - 2019-08-19 18:55:09 --> Loader Class Initialized
INFO - 2019-08-19 18:55:09 --> Helper loaded: url_helper
INFO - 2019-08-19 18:55:09 --> Helper loaded: html_helper
INFO - 2019-08-19 18:55:09 --> Helper loaded: form_helper
INFO - 2019-08-19 18:55:09 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:55:09 --> Helper loaded: date_helper
INFO - 2019-08-19 18:55:09 --> Form Validation Class Initialized
INFO - 2019-08-19 18:55:09 --> Loader Class Initialized
INFO - 2019-08-19 18:55:09 --> Helper loaded: url_helper
INFO - 2019-08-19 18:55:09 --> Helper loaded: html_helper
INFO - 2019-08-19 18:55:09 --> Helper loaded: form_helper
INFO - 2019-08-19 18:55:09 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:55:09 --> Helper loaded: date_helper
INFO - 2019-08-19 18:55:09 --> Form Validation Class Initialized
INFO - 2019-08-19 18:55:09 --> Email Class Initialized
DEBUG - 2019-08-19 18:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:55:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:55:09 --> Pagination Class Initialized
INFO - 2019-08-19 18:55:09 --> Email Class Initialized
DEBUG - 2019-08-19 18:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:55:09 --> Database Driver Class Initialized
INFO - 2019-08-19 18:55:09 --> Database Driver Class Initialized
INFO - 2019-08-19 18:55:09 --> Controller Class Initialized
INFO - 2019-08-19 18:55:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:55:09 --> Final output sent to browser
DEBUG - 2019-08-19 18:55:09 --> Total execution time: 0.2670
INFO - 2019-08-19 18:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:55:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:55:09 --> Pagination Class Initialized
INFO - 2019-08-19 18:55:09 --> Database Driver Class Initialized
INFO - 2019-08-19 18:55:09 --> Database Driver Class Initialized
INFO - 2019-08-19 18:55:09 --> Controller Class Initialized
INFO - 2019-08-19 18:55:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:55:09 --> Final output sent to browser
DEBUG - 2019-08-19 18:55:09 --> Total execution time: 0.3380
INFO - 2019-08-19 18:56:55 --> Config Class Initialized
INFO - 2019-08-19 18:56:55 --> Config Class Initialized
INFO - 2019-08-19 18:56:55 --> Hooks Class Initialized
INFO - 2019-08-19 18:56:55 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:56:55 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:56:55 --> Utf8 Class Initialized
DEBUG - 2019-08-19 18:56:55 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:56:55 --> Utf8 Class Initialized
INFO - 2019-08-19 18:56:55 --> URI Class Initialized
INFO - 2019-08-19 18:56:55 --> URI Class Initialized
INFO - 2019-08-19 18:56:55 --> Router Class Initialized
INFO - 2019-08-19 18:56:55 --> Output Class Initialized
INFO - 2019-08-19 18:56:55 --> Router Class Initialized
INFO - 2019-08-19 18:56:55 --> Output Class Initialized
INFO - 2019-08-19 18:56:55 --> Security Class Initialized
DEBUG - 2019-08-19 18:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:56:55 --> Input Class Initialized
INFO - 2019-08-19 18:56:55 --> Language Class Initialized
INFO - 2019-08-19 18:56:55 --> Security Class Initialized
DEBUG - 2019-08-19 18:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:56:55 --> Input Class Initialized
INFO - 2019-08-19 18:56:55 --> Language Class Initialized
INFO - 2019-08-19 18:56:55 --> Loader Class Initialized
INFO - 2019-08-19 18:56:55 --> Helper loaded: url_helper
INFO - 2019-08-19 18:56:55 --> Loader Class Initialized
INFO - 2019-08-19 18:56:55 --> Helper loaded: url_helper
INFO - 2019-08-19 18:56:55 --> Helper loaded: html_helper
INFO - 2019-08-19 18:56:55 --> Helper loaded: html_helper
INFO - 2019-08-19 18:56:55 --> Helper loaded: form_helper
INFO - 2019-08-19 18:56:55 --> Helper loaded: form_helper
INFO - 2019-08-19 18:56:55 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:56:55 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:56:55 --> Helper loaded: date_helper
INFO - 2019-08-19 18:56:55 --> Helper loaded: date_helper
INFO - 2019-08-19 18:56:55 --> Form Validation Class Initialized
INFO - 2019-08-19 18:56:55 --> Form Validation Class Initialized
INFO - 2019-08-19 18:56:55 --> Email Class Initialized
INFO - 2019-08-19 18:56:55 --> Email Class Initialized
DEBUG - 2019-08-19 18:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:56:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-08-19 18:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:56:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:56:55 --> Pagination Class Initialized
INFO - 2019-08-19 18:56:55 --> Database Driver Class Initialized
INFO - 2019-08-19 18:56:55 --> Database Driver Class Initialized
INFO - 2019-08-19 18:56:55 --> Controller Class Initialized
INFO - 2019-08-19 18:56:56 --> Final output sent to browser
DEBUG - 2019-08-19 18:56:56 --> Total execution time: 0.2780
INFO - 2019-08-19 18:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:56:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:56:56 --> Pagination Class Initialized
INFO - 2019-08-19 18:56:56 --> Database Driver Class Initialized
INFO - 2019-08-19 18:56:56 --> Database Driver Class Initialized
INFO - 2019-08-19 18:56:56 --> Controller Class Initialized
ERROR - 2019-08-19 18:56:56 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-19 18:57:01 --> Config Class Initialized
INFO - 2019-08-19 18:57:01 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:57:01 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:57:01 --> Utf8 Class Initialized
INFO - 2019-08-19 18:57:01 --> URI Class Initialized
INFO - 2019-08-19 18:57:01 --> Router Class Initialized
INFO - 2019-08-19 18:57:01 --> Output Class Initialized
INFO - 2019-08-19 18:57:01 --> Security Class Initialized
DEBUG - 2019-08-19 18:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:57:01 --> Input Class Initialized
INFO - 2019-08-19 18:57:01 --> Language Class Initialized
INFO - 2019-08-19 18:57:01 --> Loader Class Initialized
INFO - 2019-08-19 18:57:01 --> Helper loaded: url_helper
INFO - 2019-08-19 18:57:01 --> Helper loaded: html_helper
INFO - 2019-08-19 18:57:01 --> Helper loaded: form_helper
INFO - 2019-08-19 18:57:01 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:57:01 --> Helper loaded: date_helper
INFO - 2019-08-19 18:57:01 --> Form Validation Class Initialized
INFO - 2019-08-19 18:57:01 --> Email Class Initialized
DEBUG - 2019-08-19 18:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:57:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:57:01 --> Pagination Class Initialized
INFO - 2019-08-19 18:57:02 --> Database Driver Class Initialized
INFO - 2019-08-19 18:57:02 --> Database Driver Class Initialized
INFO - 2019-08-19 18:57:02 --> Controller Class Initialized
INFO - 2019-08-19 18:57:02 --> Final output sent to browser
DEBUG - 2019-08-19 18:57:02 --> Total execution time: 0.1890
INFO - 2019-08-19 18:57:07 --> Config Class Initialized
INFO - 2019-08-19 18:57:07 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:57:07 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:57:07 --> Utf8 Class Initialized
INFO - 2019-08-19 18:57:07 --> URI Class Initialized
INFO - 2019-08-19 18:57:07 --> Router Class Initialized
INFO - 2019-08-19 18:57:07 --> Output Class Initialized
INFO - 2019-08-19 18:57:07 --> Security Class Initialized
DEBUG - 2019-08-19 18:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:57:07 --> Input Class Initialized
INFO - 2019-08-19 18:57:07 --> Language Class Initialized
INFO - 2019-08-19 18:57:07 --> Loader Class Initialized
INFO - 2019-08-19 18:57:07 --> Helper loaded: url_helper
INFO - 2019-08-19 18:57:07 --> Helper loaded: html_helper
INFO - 2019-08-19 18:57:07 --> Helper loaded: form_helper
INFO - 2019-08-19 18:57:07 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:57:07 --> Helper loaded: date_helper
INFO - 2019-08-19 18:57:07 --> Form Validation Class Initialized
INFO - 2019-08-19 18:57:07 --> Email Class Initialized
DEBUG - 2019-08-19 18:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:57:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:57:07 --> Pagination Class Initialized
INFO - 2019-08-19 18:57:07 --> Database Driver Class Initialized
INFO - 2019-08-19 18:57:07 --> Database Driver Class Initialized
INFO - 2019-08-19 18:57:07 --> Controller Class Initialized
INFO - 2019-08-19 18:57:07 --> Final output sent to browser
DEBUG - 2019-08-19 18:57:07 --> Total execution time: 0.1820
INFO - 2019-08-19 18:57:12 --> Config Class Initialized
INFO - 2019-08-19 18:57:12 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:57:12 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:57:12 --> Utf8 Class Initialized
INFO - 2019-08-19 18:57:12 --> URI Class Initialized
INFO - 2019-08-19 18:57:12 --> Router Class Initialized
INFO - 2019-08-19 18:57:12 --> Output Class Initialized
INFO - 2019-08-19 18:57:12 --> Security Class Initialized
DEBUG - 2019-08-19 18:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:57:12 --> Input Class Initialized
INFO - 2019-08-19 18:57:12 --> Language Class Initialized
INFO - 2019-08-19 18:57:12 --> Loader Class Initialized
INFO - 2019-08-19 18:57:12 --> Helper loaded: url_helper
INFO - 2019-08-19 18:57:12 --> Helper loaded: html_helper
INFO - 2019-08-19 18:57:12 --> Helper loaded: form_helper
INFO - 2019-08-19 18:57:12 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:57:12 --> Helper loaded: date_helper
INFO - 2019-08-19 18:57:12 --> Form Validation Class Initialized
INFO - 2019-08-19 18:57:12 --> Email Class Initialized
DEBUG - 2019-08-19 18:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:57:12 --> Pagination Class Initialized
INFO - 2019-08-19 18:57:12 --> Database Driver Class Initialized
INFO - 2019-08-19 18:57:12 --> Database Driver Class Initialized
INFO - 2019-08-19 18:57:12 --> Controller Class Initialized
INFO - 2019-08-19 18:57:12 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-19 18:57:12 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-19 18:57:12 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-19 18:57:12 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-19 18:57:12 --> Final output sent to browser
DEBUG - 2019-08-19 18:57:12 --> Total execution time: 0.2670
INFO - 2019-08-19 18:57:45 --> Config Class Initialized
INFO - 2019-08-19 18:57:45 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:57:45 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:57:45 --> Utf8 Class Initialized
INFO - 2019-08-19 18:57:45 --> URI Class Initialized
INFO - 2019-08-19 18:57:45 --> Router Class Initialized
INFO - 2019-08-19 18:57:45 --> Output Class Initialized
INFO - 2019-08-19 18:57:45 --> Security Class Initialized
DEBUG - 2019-08-19 18:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:57:45 --> Input Class Initialized
INFO - 2019-08-19 18:57:45 --> Language Class Initialized
INFO - 2019-08-19 18:57:45 --> Loader Class Initialized
INFO - 2019-08-19 18:57:45 --> Helper loaded: url_helper
INFO - 2019-08-19 18:57:45 --> Helper loaded: html_helper
INFO - 2019-08-19 18:57:45 --> Helper loaded: form_helper
INFO - 2019-08-19 18:57:45 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:57:45 --> Helper loaded: date_helper
INFO - 2019-08-19 18:57:45 --> Form Validation Class Initialized
INFO - 2019-08-19 18:57:45 --> Email Class Initialized
DEBUG - 2019-08-19 18:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:57:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:57:45 --> Pagination Class Initialized
INFO - 2019-08-19 18:57:45 --> Database Driver Class Initialized
INFO - 2019-08-19 18:57:45 --> Database Driver Class Initialized
INFO - 2019-08-19 18:57:46 --> Controller Class Initialized
INFO - 2019-08-19 18:57:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:57:46 --> Final output sent to browser
DEBUG - 2019-08-19 18:57:46 --> Total execution time: 0.2000
INFO - 2019-08-19 18:58:03 --> Config Class Initialized
INFO - 2019-08-19 18:58:03 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:58:03 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:58:03 --> Utf8 Class Initialized
INFO - 2019-08-19 18:58:03 --> URI Class Initialized
INFO - 2019-08-19 18:58:03 --> Router Class Initialized
INFO - 2019-08-19 18:58:03 --> Output Class Initialized
INFO - 2019-08-19 18:58:03 --> Security Class Initialized
DEBUG - 2019-08-19 18:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:58:03 --> Input Class Initialized
INFO - 2019-08-19 18:58:03 --> Language Class Initialized
INFO - 2019-08-19 18:58:03 --> Loader Class Initialized
INFO - 2019-08-19 18:58:03 --> Helper loaded: url_helper
INFO - 2019-08-19 18:58:03 --> Helper loaded: html_helper
INFO - 2019-08-19 18:58:03 --> Helper loaded: form_helper
INFO - 2019-08-19 18:58:03 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:58:03 --> Helper loaded: date_helper
INFO - 2019-08-19 18:58:03 --> Config Class Initialized
INFO - 2019-08-19 18:58:03 --> Hooks Class Initialized
DEBUG - 2019-08-19 18:58:03 --> UTF-8 Support Enabled
INFO - 2019-08-19 18:58:03 --> Utf8 Class Initialized
INFO - 2019-08-19 18:58:03 --> URI Class Initialized
INFO - 2019-08-19 18:58:03 --> Router Class Initialized
INFO - 2019-08-19 18:58:03 --> Output Class Initialized
INFO - 2019-08-19 18:58:03 --> Security Class Initialized
DEBUG - 2019-08-19 18:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-19 18:58:03 --> Input Class Initialized
INFO - 2019-08-19 18:58:03 --> Language Class Initialized
INFO - 2019-08-19 18:58:03 --> Form Validation Class Initialized
INFO - 2019-08-19 18:58:03 --> Email Class Initialized
DEBUG - 2019-08-19 18:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:58:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:58:03 --> Pagination Class Initialized
INFO - 2019-08-19 18:58:04 --> Loader Class Initialized
INFO - 2019-08-19 18:58:04 --> Database Driver Class Initialized
INFO - 2019-08-19 18:58:04 --> Database Driver Class Initialized
INFO - 2019-08-19 18:58:04 --> Helper loaded: url_helper
INFO - 2019-08-19 18:58:04 --> Helper loaded: html_helper
INFO - 2019-08-19 18:58:04 --> Helper loaded: form_helper
INFO - 2019-08-19 18:58:04 --> Helper loaded: cookie_helper
INFO - 2019-08-19 18:58:04 --> Helper loaded: date_helper
INFO - 2019-08-19 18:58:04 --> Form Validation Class Initialized
INFO - 2019-08-19 18:58:04 --> Email Class Initialized
INFO - 2019-08-19 18:58:04 --> Controller Class Initialized
INFO - 2019-08-19 18:58:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:58:04 --> Final output sent to browser
DEBUG - 2019-08-19 18:58:04 --> Total execution time: 1.2041
DEBUG - 2019-08-19 18:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-19 18:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-19 18:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-19 18:58:04 --> Pagination Class Initialized
INFO - 2019-08-19 18:58:04 --> Database Driver Class Initialized
INFO - 2019-08-19 18:58:04 --> Database Driver Class Initialized
INFO - 2019-08-19 18:58:04 --> Controller Class Initialized
INFO - 2019-08-19 18:58:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-19 18:58:04 --> Final output sent to browser
DEBUG - 2019-08-19 18:58:04 --> Total execution time: 1.2731
