<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-23 03:05:14 --> Config Class Initialized
INFO - 2019-09-23 03:05:14 --> Hooks Class Initialized
DEBUG - 2019-09-23 03:05:14 --> UTF-8 Support Enabled
INFO - 2019-09-23 03:05:14 --> Utf8 Class Initialized
INFO - 2019-09-23 03:05:14 --> URI Class Initialized
INFO - 2019-09-23 03:05:14 --> Router Class Initialized
INFO - 2019-09-23 03:05:14 --> Output Class Initialized
INFO - 2019-09-23 03:05:14 --> Security Class Initialized
DEBUG - 2019-09-23 03:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 03:05:14 --> Input Class Initialized
INFO - 2019-09-23 03:05:14 --> Language Class Initialized
INFO - 2019-09-23 03:05:14 --> Loader Class Initialized
INFO - 2019-09-23 03:05:14 --> Helper loaded: url_helper
INFO - 2019-09-23 03:05:14 --> Helper loaded: html_helper
INFO - 2019-09-23 03:05:14 --> Helper loaded: form_helper
INFO - 2019-09-23 03:05:14 --> Helper loaded: cookie_helper
INFO - 2019-09-23 03:05:14 --> Helper loaded: date_helper
INFO - 2019-09-23 03:05:14 --> Form Validation Class Initialized
INFO - 2019-09-23 03:05:14 --> Email Class Initialized
DEBUG - 2019-09-23 03:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 03:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 03:05:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 03:05:15 --> Pagination Class Initialized
INFO - 2019-09-23 03:05:15 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:15 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:15 --> Controller Class Initialized
INFO - 2019-09-23 03:05:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-23 03:05:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-23 03:05:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-23 03:05:15 --> Final output sent to browser
DEBUG - 2019-09-23 03:05:15 --> Total execution time: 0.7525
INFO - 2019-09-23 03:05:15 --> Config Class Initialized
INFO - 2019-09-23 03:05:15 --> Hooks Class Initialized
DEBUG - 2019-09-23 03:05:15 --> UTF-8 Support Enabled
INFO - 2019-09-23 03:05:15 --> Utf8 Class Initialized
INFO - 2019-09-23 03:05:15 --> URI Class Initialized
INFO - 2019-09-23 03:05:15 --> Router Class Initialized
INFO - 2019-09-23 03:05:15 --> Output Class Initialized
INFO - 2019-09-23 03:05:15 --> Security Class Initialized
DEBUG - 2019-09-23 03:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 03:05:15 --> Input Class Initialized
INFO - 2019-09-23 03:05:15 --> Language Class Initialized
INFO - 2019-09-23 03:05:15 --> Loader Class Initialized
INFO - 2019-09-23 03:05:15 --> Helper loaded: url_helper
INFO - 2019-09-23 03:05:15 --> Helper loaded: html_helper
INFO - 2019-09-23 03:05:15 --> Helper loaded: form_helper
INFO - 2019-09-23 03:05:15 --> Helper loaded: cookie_helper
INFO - 2019-09-23 03:05:15 --> Helper loaded: date_helper
INFO - 2019-09-23 03:05:15 --> Form Validation Class Initialized
INFO - 2019-09-23 03:05:15 --> Email Class Initialized
DEBUG - 2019-09-23 03:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 03:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 03:05:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 03:05:15 --> Pagination Class Initialized
INFO - 2019-09-23 03:05:15 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:15 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:15 --> Controller Class Initialized
INFO - 2019-09-23 03:05:15 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-23 03:05:15 --> Final output sent to browser
DEBUG - 2019-09-23 03:05:15 --> Total execution time: 0.0764
INFO - 2019-09-23 03:05:16 --> Config Class Initialized
INFO - 2019-09-23 03:05:16 --> Hooks Class Initialized
DEBUG - 2019-09-23 03:05:16 --> UTF-8 Support Enabled
INFO - 2019-09-23 03:05:16 --> Utf8 Class Initialized
INFO - 2019-09-23 03:05:16 --> URI Class Initialized
INFO - 2019-09-23 03:05:16 --> Router Class Initialized
INFO - 2019-09-23 03:05:16 --> Output Class Initialized
INFO - 2019-09-23 03:05:16 --> Security Class Initialized
DEBUG - 2019-09-23 03:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 03:05:16 --> Input Class Initialized
INFO - 2019-09-23 03:05:16 --> Language Class Initialized
INFO - 2019-09-23 03:05:16 --> Loader Class Initialized
INFO - 2019-09-23 03:05:16 --> Helper loaded: url_helper
INFO - 2019-09-23 03:05:16 --> Helper loaded: html_helper
INFO - 2019-09-23 03:05:16 --> Helper loaded: form_helper
INFO - 2019-09-23 03:05:16 --> Helper loaded: cookie_helper
INFO - 2019-09-23 03:05:16 --> Helper loaded: date_helper
INFO - 2019-09-23 03:05:16 --> Form Validation Class Initialized
INFO - 2019-09-23 03:05:16 --> Email Class Initialized
DEBUG - 2019-09-23 03:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 03:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 03:05:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 03:05:16 --> Pagination Class Initialized
INFO - 2019-09-23 03:05:16 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:16 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:16 --> Controller Class Initialized
INFO - 2019-09-23 03:05:16 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-23 03:05:16 --> Final output sent to browser
DEBUG - 2019-09-23 03:05:16 --> Total execution time: 0.0570
INFO - 2019-09-23 03:05:19 --> Config Class Initialized
INFO - 2019-09-23 03:05:19 --> Hooks Class Initialized
DEBUG - 2019-09-23 03:05:19 --> UTF-8 Support Enabled
INFO - 2019-09-23 03:05:19 --> Utf8 Class Initialized
INFO - 2019-09-23 03:05:19 --> URI Class Initialized
INFO - 2019-09-23 03:05:19 --> Router Class Initialized
INFO - 2019-09-23 03:05:19 --> Output Class Initialized
INFO - 2019-09-23 03:05:19 --> Security Class Initialized
DEBUG - 2019-09-23 03:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 03:05:19 --> Input Class Initialized
INFO - 2019-09-23 03:05:19 --> Language Class Initialized
INFO - 2019-09-23 03:05:19 --> Loader Class Initialized
INFO - 2019-09-23 03:05:19 --> Helper loaded: url_helper
INFO - 2019-09-23 03:05:19 --> Helper loaded: html_helper
INFO - 2019-09-23 03:05:19 --> Helper loaded: form_helper
INFO - 2019-09-23 03:05:19 --> Helper loaded: cookie_helper
INFO - 2019-09-23 03:05:19 --> Helper loaded: date_helper
INFO - 2019-09-23 03:05:19 --> Form Validation Class Initialized
INFO - 2019-09-23 03:05:19 --> Email Class Initialized
DEBUG - 2019-09-23 03:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 03:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 03:05:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 03:05:19 --> Pagination Class Initialized
INFO - 2019-09-23 03:05:19 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:19 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:19 --> Controller Class Initialized
INFO - 2019-09-23 03:05:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-23 03:05:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-23 03:05:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-23 03:05:19 --> Final output sent to browser
DEBUG - 2019-09-23 03:05:19 --> Total execution time: 0.0639
INFO - 2019-09-23 03:05:19 --> Config Class Initialized
INFO - 2019-09-23 03:05:19 --> Hooks Class Initialized
DEBUG - 2019-09-23 03:05:19 --> UTF-8 Support Enabled
INFO - 2019-09-23 03:05:19 --> Utf8 Class Initialized
INFO - 2019-09-23 03:05:19 --> URI Class Initialized
INFO - 2019-09-23 03:05:19 --> Router Class Initialized
INFO - 2019-09-23 03:05:19 --> Output Class Initialized
INFO - 2019-09-23 03:05:19 --> Security Class Initialized
DEBUG - 2019-09-23 03:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 03:05:19 --> Input Class Initialized
INFO - 2019-09-23 03:05:19 --> Language Class Initialized
INFO - 2019-09-23 03:05:19 --> Loader Class Initialized
INFO - 2019-09-23 03:05:19 --> Helper loaded: url_helper
INFO - 2019-09-23 03:05:19 --> Helper loaded: html_helper
INFO - 2019-09-23 03:05:19 --> Helper loaded: form_helper
INFO - 2019-09-23 03:05:19 --> Helper loaded: cookie_helper
INFO - 2019-09-23 03:05:19 --> Helper loaded: date_helper
INFO - 2019-09-23 03:05:19 --> Form Validation Class Initialized
INFO - 2019-09-23 03:05:19 --> Email Class Initialized
DEBUG - 2019-09-23 03:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 03:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 03:05:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 03:05:19 --> Pagination Class Initialized
INFO - 2019-09-23 03:05:19 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:19 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:19 --> Controller Class Initialized
INFO - 2019-09-23 03:05:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-23 03:05:19 --> Final output sent to browser
DEBUG - 2019-09-23 03:05:19 --> Total execution time: 0.0750
INFO - 2019-09-23 03:05:20 --> Config Class Initialized
INFO - 2019-09-23 03:05:20 --> Hooks Class Initialized
DEBUG - 2019-09-23 03:05:20 --> UTF-8 Support Enabled
INFO - 2019-09-23 03:05:20 --> Utf8 Class Initialized
INFO - 2019-09-23 03:05:20 --> URI Class Initialized
INFO - 2019-09-23 03:05:20 --> Router Class Initialized
INFO - 2019-09-23 03:05:20 --> Output Class Initialized
INFO - 2019-09-23 03:05:20 --> Security Class Initialized
DEBUG - 2019-09-23 03:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 03:05:20 --> Input Class Initialized
INFO - 2019-09-23 03:05:20 --> Language Class Initialized
INFO - 2019-09-23 03:05:20 --> Loader Class Initialized
INFO - 2019-09-23 03:05:20 --> Helper loaded: url_helper
INFO - 2019-09-23 03:05:20 --> Helper loaded: html_helper
INFO - 2019-09-23 03:05:20 --> Helper loaded: form_helper
INFO - 2019-09-23 03:05:20 --> Helper loaded: cookie_helper
INFO - 2019-09-23 03:05:20 --> Helper loaded: date_helper
INFO - 2019-09-23 03:05:20 --> Form Validation Class Initialized
INFO - 2019-09-23 03:05:20 --> Email Class Initialized
DEBUG - 2019-09-23 03:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 03:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 03:05:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 03:05:20 --> Pagination Class Initialized
INFO - 2019-09-23 03:05:20 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:20 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:20 --> Controller Class Initialized
INFO - 2019-09-23 03:05:20 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-23 03:05:20 --> Final output sent to browser
DEBUG - 2019-09-23 03:05:20 --> Total execution time: 0.0625
INFO - 2019-09-23 03:05:21 --> Config Class Initialized
INFO - 2019-09-23 03:05:21 --> Hooks Class Initialized
DEBUG - 2019-09-23 03:05:21 --> UTF-8 Support Enabled
INFO - 2019-09-23 03:05:21 --> Utf8 Class Initialized
INFO - 2019-09-23 03:05:21 --> URI Class Initialized
INFO - 2019-09-23 03:05:21 --> Router Class Initialized
INFO - 2019-09-23 03:05:21 --> Output Class Initialized
INFO - 2019-09-23 03:05:21 --> Security Class Initialized
DEBUG - 2019-09-23 03:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 03:05:21 --> Input Class Initialized
INFO - 2019-09-23 03:05:21 --> Language Class Initialized
INFO - 2019-09-23 03:05:21 --> Loader Class Initialized
INFO - 2019-09-23 03:05:21 --> Helper loaded: url_helper
INFO - 2019-09-23 03:05:21 --> Helper loaded: html_helper
INFO - 2019-09-23 03:05:21 --> Helper loaded: form_helper
INFO - 2019-09-23 03:05:21 --> Helper loaded: cookie_helper
INFO - 2019-09-23 03:05:21 --> Helper loaded: date_helper
INFO - 2019-09-23 03:05:21 --> Form Validation Class Initialized
INFO - 2019-09-23 03:05:21 --> Email Class Initialized
DEBUG - 2019-09-23 03:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 03:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 03:05:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 03:05:21 --> Pagination Class Initialized
INFO - 2019-09-23 03:05:21 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:21 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:21 --> Controller Class Initialized
INFO - 2019-09-23 03:05:21 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-23 03:05:21 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/nightaudit.php
INFO - 2019-09-23 03:05:21 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-23 03:05:21 --> Final output sent to browser
DEBUG - 2019-09-23 03:05:21 --> Total execution time: 0.0857
INFO - 2019-09-23 03:05:21 --> Config Class Initialized
INFO - 2019-09-23 03:05:21 --> Hooks Class Initialized
DEBUG - 2019-09-23 03:05:21 --> UTF-8 Support Enabled
INFO - 2019-09-23 03:05:21 --> Utf8 Class Initialized
INFO - 2019-09-23 03:05:21 --> URI Class Initialized
INFO - 2019-09-23 03:05:21 --> Router Class Initialized
INFO - 2019-09-23 03:05:21 --> Output Class Initialized
INFO - 2019-09-23 03:05:21 --> Security Class Initialized
DEBUG - 2019-09-23 03:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 03:05:21 --> Input Class Initialized
INFO - 2019-09-23 03:05:21 --> Language Class Initialized
INFO - 2019-09-23 03:05:21 --> Loader Class Initialized
INFO - 2019-09-23 03:05:21 --> Helper loaded: url_helper
INFO - 2019-09-23 03:05:21 --> Helper loaded: html_helper
INFO - 2019-09-23 03:05:21 --> Helper loaded: form_helper
INFO - 2019-09-23 03:05:21 --> Helper loaded: cookie_helper
INFO - 2019-09-23 03:05:21 --> Helper loaded: date_helper
INFO - 2019-09-23 03:05:21 --> Form Validation Class Initialized
INFO - 2019-09-23 03:05:21 --> Email Class Initialized
DEBUG - 2019-09-23 03:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 03:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 03:05:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 03:05:21 --> Pagination Class Initialized
INFO - 2019-09-23 03:05:21 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:21 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:21 --> Controller Class Initialized
INFO - 2019-09-23 03:05:21 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-23 03:05:21 --> Final output sent to browser
DEBUG - 2019-09-23 03:05:21 --> Total execution time: 0.0686
INFO - 2019-09-23 03:05:22 --> Config Class Initialized
INFO - 2019-09-23 03:05:22 --> Hooks Class Initialized
DEBUG - 2019-09-23 03:05:22 --> UTF-8 Support Enabled
INFO - 2019-09-23 03:05:22 --> Utf8 Class Initialized
INFO - 2019-09-23 03:05:22 --> URI Class Initialized
INFO - 2019-09-23 03:05:22 --> Router Class Initialized
INFO - 2019-09-23 03:05:22 --> Output Class Initialized
INFO - 2019-09-23 03:05:22 --> Security Class Initialized
DEBUG - 2019-09-23 03:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 03:05:22 --> Input Class Initialized
INFO - 2019-09-23 03:05:22 --> Language Class Initialized
INFO - 2019-09-23 03:05:22 --> Loader Class Initialized
INFO - 2019-09-23 03:05:22 --> Helper loaded: url_helper
INFO - 2019-09-23 03:05:22 --> Helper loaded: html_helper
INFO - 2019-09-23 03:05:22 --> Helper loaded: form_helper
INFO - 2019-09-23 03:05:22 --> Helper loaded: cookie_helper
INFO - 2019-09-23 03:05:22 --> Helper loaded: date_helper
INFO - 2019-09-23 03:05:22 --> Form Validation Class Initialized
INFO - 2019-09-23 03:05:22 --> Email Class Initialized
DEBUG - 2019-09-23 03:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 03:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 03:05:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 03:05:22 --> Pagination Class Initialized
INFO - 2019-09-23 03:05:22 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:22 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:22 --> Controller Class Initialized
INFO - 2019-09-23 03:05:22 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-23 03:05:22 --> Final output sent to browser
DEBUG - 2019-09-23 03:05:22 --> Total execution time: 0.0587
INFO - 2019-09-23 03:05:29 --> Config Class Initialized
INFO - 2019-09-23 03:05:29 --> Hooks Class Initialized
DEBUG - 2019-09-23 03:05:29 --> UTF-8 Support Enabled
INFO - 2019-09-23 03:05:29 --> Utf8 Class Initialized
INFO - 2019-09-23 03:05:29 --> URI Class Initialized
INFO - 2019-09-23 03:05:29 --> Router Class Initialized
INFO - 2019-09-23 03:05:29 --> Output Class Initialized
INFO - 2019-09-23 03:05:29 --> Security Class Initialized
DEBUG - 2019-09-23 03:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 03:05:29 --> Input Class Initialized
INFO - 2019-09-23 03:05:29 --> Language Class Initialized
INFO - 2019-09-23 03:05:29 --> Loader Class Initialized
INFO - 2019-09-23 03:05:29 --> Helper loaded: url_helper
INFO - 2019-09-23 03:05:29 --> Helper loaded: html_helper
INFO - 2019-09-23 03:05:29 --> Helper loaded: form_helper
INFO - 2019-09-23 03:05:29 --> Helper loaded: cookie_helper
INFO - 2019-09-23 03:05:29 --> Helper loaded: date_helper
INFO - 2019-09-23 03:05:29 --> Form Validation Class Initialized
INFO - 2019-09-23 03:05:29 --> Email Class Initialized
DEBUG - 2019-09-23 03:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 03:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 03:05:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 03:05:29 --> Pagination Class Initialized
INFO - 2019-09-23 03:05:29 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:29 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:29 --> Controller Class Initialized
INFO - 2019-09-23 03:05:30 --> Final output sent to browser
DEBUG - 2019-09-23 03:05:30 --> Total execution time: 1.3800
INFO - 2019-09-23 03:05:32 --> Config Class Initialized
INFO - 2019-09-23 03:05:32 --> Hooks Class Initialized
DEBUG - 2019-09-23 03:05:32 --> UTF-8 Support Enabled
INFO - 2019-09-23 03:05:32 --> Utf8 Class Initialized
INFO - 2019-09-23 03:05:32 --> URI Class Initialized
INFO - 2019-09-23 03:05:32 --> Router Class Initialized
INFO - 2019-09-23 03:05:32 --> Output Class Initialized
INFO - 2019-09-23 03:05:32 --> Security Class Initialized
DEBUG - 2019-09-23 03:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 03:05:32 --> Input Class Initialized
INFO - 2019-09-23 03:05:32 --> Language Class Initialized
INFO - 2019-09-23 03:05:32 --> Loader Class Initialized
INFO - 2019-09-23 03:05:32 --> Helper loaded: url_helper
INFO - 2019-09-23 03:05:32 --> Helper loaded: html_helper
INFO - 2019-09-23 03:05:32 --> Helper loaded: form_helper
INFO - 2019-09-23 03:05:32 --> Helper loaded: cookie_helper
INFO - 2019-09-23 03:05:32 --> Helper loaded: date_helper
INFO - 2019-09-23 03:05:32 --> Form Validation Class Initialized
INFO - 2019-09-23 03:05:32 --> Email Class Initialized
DEBUG - 2019-09-23 03:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 03:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 03:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 03:05:32 --> Pagination Class Initialized
INFO - 2019-09-23 03:05:32 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:32 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:32 --> Controller Class Initialized
INFO - 2019-09-23 03:05:32 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-23 03:05:32 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/nightaudit.php
INFO - 2019-09-23 03:05:32 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-23 03:05:32 --> Final output sent to browser
DEBUG - 2019-09-23 03:05:32 --> Total execution time: 0.0576
INFO - 2019-09-23 03:05:32 --> Config Class Initialized
INFO - 2019-09-23 03:05:32 --> Hooks Class Initialized
DEBUG - 2019-09-23 03:05:32 --> UTF-8 Support Enabled
INFO - 2019-09-23 03:05:32 --> Utf8 Class Initialized
INFO - 2019-09-23 03:05:32 --> URI Class Initialized
INFO - 2019-09-23 03:05:32 --> Router Class Initialized
INFO - 2019-09-23 03:05:32 --> Output Class Initialized
INFO - 2019-09-23 03:05:32 --> Security Class Initialized
DEBUG - 2019-09-23 03:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 03:05:32 --> Input Class Initialized
INFO - 2019-09-23 03:05:32 --> Language Class Initialized
INFO - 2019-09-23 03:05:32 --> Loader Class Initialized
INFO - 2019-09-23 03:05:32 --> Helper loaded: url_helper
INFO - 2019-09-23 03:05:32 --> Helper loaded: html_helper
INFO - 2019-09-23 03:05:32 --> Helper loaded: form_helper
INFO - 2019-09-23 03:05:32 --> Helper loaded: cookie_helper
INFO - 2019-09-23 03:05:32 --> Helper loaded: date_helper
INFO - 2019-09-23 03:05:32 --> Form Validation Class Initialized
INFO - 2019-09-23 03:05:32 --> Email Class Initialized
DEBUG - 2019-09-23 03:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 03:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 03:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 03:05:32 --> Pagination Class Initialized
INFO - 2019-09-23 03:05:33 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:33 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:33 --> Controller Class Initialized
INFO - 2019-09-23 03:05:33 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-23 03:05:33 --> Final output sent to browser
DEBUG - 2019-09-23 03:05:33 --> Total execution time: 0.0612
INFO - 2019-09-23 03:05:39 --> Config Class Initialized
INFO - 2019-09-23 03:05:39 --> Hooks Class Initialized
DEBUG - 2019-09-23 03:05:39 --> UTF-8 Support Enabled
INFO - 2019-09-23 03:05:39 --> Utf8 Class Initialized
INFO - 2019-09-23 03:05:39 --> URI Class Initialized
INFO - 2019-09-23 03:05:39 --> Router Class Initialized
INFO - 2019-09-23 03:05:39 --> Output Class Initialized
INFO - 2019-09-23 03:05:39 --> Security Class Initialized
DEBUG - 2019-09-23 03:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 03:05:39 --> Input Class Initialized
INFO - 2019-09-23 03:05:39 --> Language Class Initialized
INFO - 2019-09-23 03:05:39 --> Loader Class Initialized
INFO - 2019-09-23 03:05:39 --> Helper loaded: url_helper
INFO - 2019-09-23 03:05:39 --> Helper loaded: html_helper
INFO - 2019-09-23 03:05:39 --> Helper loaded: form_helper
INFO - 2019-09-23 03:05:39 --> Helper loaded: cookie_helper
INFO - 2019-09-23 03:05:39 --> Helper loaded: date_helper
INFO - 2019-09-23 03:05:39 --> Form Validation Class Initialized
INFO - 2019-09-23 03:05:39 --> Email Class Initialized
DEBUG - 2019-09-23 03:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 03:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 03:05:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 03:05:39 --> Pagination Class Initialized
INFO - 2019-09-23 03:05:39 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:39 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:39 --> Controller Class Initialized
INFO - 2019-09-23 03:05:42 --> Final output sent to browser
DEBUG - 2019-09-23 03:05:42 --> Total execution time: 2.4647
INFO - 2019-09-23 03:05:44 --> Config Class Initialized
INFO - 2019-09-23 03:05:44 --> Hooks Class Initialized
DEBUG - 2019-09-23 03:05:44 --> UTF-8 Support Enabled
INFO - 2019-09-23 03:05:44 --> Utf8 Class Initialized
INFO - 2019-09-23 03:05:44 --> URI Class Initialized
INFO - 2019-09-23 03:05:44 --> Router Class Initialized
INFO - 2019-09-23 03:05:44 --> Output Class Initialized
INFO - 2019-09-23 03:05:44 --> Security Class Initialized
DEBUG - 2019-09-23 03:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 03:05:44 --> Input Class Initialized
INFO - 2019-09-23 03:05:44 --> Language Class Initialized
INFO - 2019-09-23 03:05:44 --> Loader Class Initialized
INFO - 2019-09-23 03:05:44 --> Helper loaded: url_helper
INFO - 2019-09-23 03:05:44 --> Helper loaded: html_helper
INFO - 2019-09-23 03:05:44 --> Helper loaded: form_helper
INFO - 2019-09-23 03:05:44 --> Helper loaded: cookie_helper
INFO - 2019-09-23 03:05:44 --> Helper loaded: date_helper
INFO - 2019-09-23 03:05:44 --> Form Validation Class Initialized
INFO - 2019-09-23 03:05:44 --> Email Class Initialized
DEBUG - 2019-09-23 03:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 03:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 03:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 03:05:44 --> Pagination Class Initialized
INFO - 2019-09-23 03:05:44 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:44 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:44 --> Controller Class Initialized
INFO - 2019-09-23 03:05:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-23 03:05:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/nightaudit.php
INFO - 2019-09-23 03:05:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-23 03:05:44 --> Final output sent to browser
DEBUG - 2019-09-23 03:05:44 --> Total execution time: 0.0531
INFO - 2019-09-23 03:05:44 --> Config Class Initialized
INFO - 2019-09-23 03:05:44 --> Hooks Class Initialized
DEBUG - 2019-09-23 03:05:44 --> UTF-8 Support Enabled
INFO - 2019-09-23 03:05:44 --> Utf8 Class Initialized
INFO - 2019-09-23 03:05:44 --> URI Class Initialized
INFO - 2019-09-23 03:05:44 --> Router Class Initialized
INFO - 2019-09-23 03:05:44 --> Output Class Initialized
INFO - 2019-09-23 03:05:44 --> Security Class Initialized
DEBUG - 2019-09-23 03:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 03:05:44 --> Input Class Initialized
INFO - 2019-09-23 03:05:44 --> Language Class Initialized
INFO - 2019-09-23 03:05:44 --> Loader Class Initialized
INFO - 2019-09-23 03:05:44 --> Helper loaded: url_helper
INFO - 2019-09-23 03:05:44 --> Helper loaded: html_helper
INFO - 2019-09-23 03:05:44 --> Helper loaded: form_helper
INFO - 2019-09-23 03:05:44 --> Helper loaded: cookie_helper
INFO - 2019-09-23 03:05:44 --> Helper loaded: date_helper
INFO - 2019-09-23 03:05:44 --> Form Validation Class Initialized
INFO - 2019-09-23 03:05:44 --> Email Class Initialized
DEBUG - 2019-09-23 03:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 03:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 03:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 03:05:44 --> Pagination Class Initialized
INFO - 2019-09-23 03:05:44 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:44 --> Database Driver Class Initialized
INFO - 2019-09-23 03:05:44 --> Controller Class Initialized
INFO - 2019-09-23 03:05:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-23 03:05:44 --> Final output sent to browser
DEBUG - 2019-09-23 03:05:44 --> Total execution time: 0.0661
INFO - 2019-09-23 04:02:18 --> Config Class Initialized
INFO - 2019-09-23 04:02:18 --> Hooks Class Initialized
DEBUG - 2019-09-23 04:02:18 --> UTF-8 Support Enabled
INFO - 2019-09-23 04:02:18 --> Utf8 Class Initialized
INFO - 2019-09-23 04:02:18 --> URI Class Initialized
INFO - 2019-09-23 04:02:18 --> Router Class Initialized
INFO - 2019-09-23 04:02:18 --> Output Class Initialized
INFO - 2019-09-23 04:02:18 --> Security Class Initialized
DEBUG - 2019-09-23 04:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 04:02:18 --> Input Class Initialized
INFO - 2019-09-23 04:02:18 --> Language Class Initialized
INFO - 2019-09-23 04:02:18 --> Loader Class Initialized
INFO - 2019-09-23 04:02:18 --> Helper loaded: url_helper
INFO - 2019-09-23 04:02:18 --> Helper loaded: html_helper
INFO - 2019-09-23 04:02:18 --> Helper loaded: form_helper
INFO - 2019-09-23 04:02:18 --> Helper loaded: cookie_helper
INFO - 2019-09-23 04:02:18 --> Helper loaded: date_helper
INFO - 2019-09-23 04:02:18 --> Form Validation Class Initialized
INFO - 2019-09-23 04:02:18 --> Email Class Initialized
DEBUG - 2019-09-23 04:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 04:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 04:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 04:02:18 --> Pagination Class Initialized
INFO - 2019-09-23 04:02:18 --> Database Driver Class Initialized
INFO - 2019-09-23 04:02:18 --> Database Driver Class Initialized
INFO - 2019-09-23 04:02:18 --> Controller Class Initialized
INFO - 2019-09-23 04:02:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-23 04:02:18 --> Final output sent to browser
DEBUG - 2019-09-23 04:02:18 --> Total execution time: 0.0619
INFO - 2019-09-23 04:02:19 --> Config Class Initialized
INFO - 2019-09-23 04:02:19 --> Hooks Class Initialized
DEBUG - 2019-09-23 04:02:19 --> UTF-8 Support Enabled
INFO - 2019-09-23 04:02:19 --> Utf8 Class Initialized
INFO - 2019-09-23 04:02:19 --> URI Class Initialized
INFO - 2019-09-23 04:02:19 --> Router Class Initialized
INFO - 2019-09-23 04:02:19 --> Output Class Initialized
INFO - 2019-09-23 04:02:19 --> Security Class Initialized
DEBUG - 2019-09-23 04:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 04:02:19 --> Input Class Initialized
INFO - 2019-09-23 04:02:19 --> Language Class Initialized
INFO - 2019-09-23 04:02:19 --> Loader Class Initialized
INFO - 2019-09-23 04:02:19 --> Helper loaded: url_helper
INFO - 2019-09-23 04:02:19 --> Helper loaded: html_helper
INFO - 2019-09-23 04:02:19 --> Helper loaded: form_helper
INFO - 2019-09-23 04:02:19 --> Helper loaded: cookie_helper
INFO - 2019-09-23 04:02:19 --> Helper loaded: date_helper
INFO - 2019-09-23 04:02:19 --> Form Validation Class Initialized
INFO - 2019-09-23 04:02:19 --> Email Class Initialized
DEBUG - 2019-09-23 04:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 04:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 04:02:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 04:02:19 --> Pagination Class Initialized
INFO - 2019-09-23 04:02:19 --> Database Driver Class Initialized
INFO - 2019-09-23 04:02:19 --> Database Driver Class Initialized
INFO - 2019-09-23 04:02:19 --> Controller Class Initialized
INFO - 2019-09-23 04:02:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-23 04:02:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-23 04:02:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-23 04:02:19 --> Final output sent to browser
DEBUG - 2019-09-23 04:02:19 --> Total execution time: 0.0603
INFO - 2019-09-23 04:02:19 --> Config Class Initialized
INFO - 2019-09-23 04:02:19 --> Hooks Class Initialized
DEBUG - 2019-09-23 04:02:19 --> UTF-8 Support Enabled
INFO - 2019-09-23 04:02:19 --> Utf8 Class Initialized
INFO - 2019-09-23 04:02:19 --> URI Class Initialized
INFO - 2019-09-23 04:02:19 --> Router Class Initialized
INFO - 2019-09-23 04:02:19 --> Output Class Initialized
INFO - 2019-09-23 04:02:19 --> Security Class Initialized
DEBUG - 2019-09-23 04:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 04:02:19 --> Input Class Initialized
INFO - 2019-09-23 04:02:19 --> Language Class Initialized
INFO - 2019-09-23 04:02:19 --> Loader Class Initialized
INFO - 2019-09-23 04:02:19 --> Helper loaded: url_helper
INFO - 2019-09-23 04:02:19 --> Helper loaded: html_helper
INFO - 2019-09-23 04:02:19 --> Helper loaded: form_helper
INFO - 2019-09-23 04:02:19 --> Helper loaded: cookie_helper
INFO - 2019-09-23 04:02:19 --> Helper loaded: date_helper
INFO - 2019-09-23 04:02:19 --> Form Validation Class Initialized
INFO - 2019-09-23 04:02:19 --> Email Class Initialized
DEBUG - 2019-09-23 04:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 04:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 04:02:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 04:02:19 --> Pagination Class Initialized
INFO - 2019-09-23 04:02:19 --> Database Driver Class Initialized
INFO - 2019-09-23 04:02:19 --> Database Driver Class Initialized
INFO - 2019-09-23 04:02:19 --> Controller Class Initialized
INFO - 2019-09-23 04:02:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-23 04:02:19 --> Final output sent to browser
DEBUG - 2019-09-23 04:02:19 --> Total execution time: 0.0591
INFO - 2019-09-23 04:12:40 --> Config Class Initialized
INFO - 2019-09-23 04:12:40 --> Hooks Class Initialized
DEBUG - 2019-09-23 04:12:40 --> UTF-8 Support Enabled
INFO - 2019-09-23 04:12:40 --> Utf8 Class Initialized
INFO - 2019-09-23 04:12:40 --> URI Class Initialized
INFO - 2019-09-23 04:12:40 --> Router Class Initialized
INFO - 2019-09-23 04:12:40 --> Output Class Initialized
INFO - 2019-09-23 04:12:40 --> Security Class Initialized
DEBUG - 2019-09-23 04:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 04:12:40 --> Input Class Initialized
INFO - 2019-09-23 04:12:40 --> Language Class Initialized
INFO - 2019-09-23 04:12:40 --> Loader Class Initialized
INFO - 2019-09-23 04:12:40 --> Helper loaded: url_helper
INFO - 2019-09-23 04:12:40 --> Helper loaded: html_helper
INFO - 2019-09-23 04:12:40 --> Helper loaded: form_helper
INFO - 2019-09-23 04:12:40 --> Helper loaded: cookie_helper
INFO - 2019-09-23 04:12:40 --> Helper loaded: date_helper
INFO - 2019-09-23 04:12:40 --> Form Validation Class Initialized
INFO - 2019-09-23 04:12:40 --> Email Class Initialized
DEBUG - 2019-09-23 04:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 04:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 04:12:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 04:12:40 --> Pagination Class Initialized
INFO - 2019-09-23 04:12:40 --> Database Driver Class Initialized
INFO - 2019-09-23 04:12:40 --> Database Driver Class Initialized
INFO - 2019-09-23 04:12:40 --> Controller Class Initialized
INFO - 2019-09-23 04:12:40 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-23 04:12:40 --> Final output sent to browser
DEBUG - 2019-09-23 04:12:40 --> Total execution time: 0.0641
INFO - 2019-09-23 04:12:43 --> Config Class Initialized
INFO - 2019-09-23 04:12:43 --> Hooks Class Initialized
DEBUG - 2019-09-23 04:12:43 --> UTF-8 Support Enabled
INFO - 2019-09-23 04:12:43 --> Utf8 Class Initialized
INFO - 2019-09-23 04:12:43 --> URI Class Initialized
INFO - 2019-09-23 04:12:43 --> Router Class Initialized
INFO - 2019-09-23 04:12:43 --> Output Class Initialized
INFO - 2019-09-23 04:12:43 --> Security Class Initialized
DEBUG - 2019-09-23 04:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 04:12:43 --> Input Class Initialized
INFO - 2019-09-23 04:12:43 --> Language Class Initialized
INFO - 2019-09-23 04:12:44 --> Loader Class Initialized
INFO - 2019-09-23 04:12:44 --> Helper loaded: url_helper
INFO - 2019-09-23 04:12:44 --> Helper loaded: html_helper
INFO - 2019-09-23 04:12:44 --> Helper loaded: form_helper
INFO - 2019-09-23 04:12:44 --> Helper loaded: cookie_helper
INFO - 2019-09-23 04:12:44 --> Helper loaded: date_helper
INFO - 2019-09-23 04:12:44 --> Form Validation Class Initialized
INFO - 2019-09-23 04:12:44 --> Email Class Initialized
DEBUG - 2019-09-23 04:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 04:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 04:12:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 04:12:44 --> Pagination Class Initialized
INFO - 2019-09-23 04:12:44 --> Database Driver Class Initialized
INFO - 2019-09-23 04:12:44 --> Database Driver Class Initialized
INFO - 2019-09-23 04:12:44 --> Controller Class Initialized
INFO - 2019-09-23 04:12:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-23 04:12:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report_sales.php
INFO - 2019-09-23 04:12:44 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-23 04:12:44 --> Final output sent to browser
DEBUG - 2019-09-23 04:12:44 --> Total execution time: 0.1682
INFO - 2019-09-23 09:45:28 --> Config Class Initialized
INFO - 2019-09-23 09:45:28 --> Hooks Class Initialized
DEBUG - 2019-09-23 09:45:28 --> UTF-8 Support Enabled
INFO - 2019-09-23 09:45:28 --> Utf8 Class Initialized
INFO - 2019-09-23 09:45:28 --> URI Class Initialized
INFO - 2019-09-23 09:45:29 --> Router Class Initialized
INFO - 2019-09-23 09:45:29 --> Output Class Initialized
INFO - 2019-09-23 09:45:29 --> Security Class Initialized
DEBUG - 2019-09-23 09:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 09:45:29 --> Input Class Initialized
INFO - 2019-09-23 09:45:29 --> Language Class Initialized
INFO - 2019-09-23 09:45:30 --> Loader Class Initialized
INFO - 2019-09-23 09:45:31 --> Helper loaded: url_helper
INFO - 2019-09-23 09:45:31 --> Helper loaded: html_helper
INFO - 2019-09-23 09:45:31 --> Helper loaded: form_helper
INFO - 2019-09-23 09:45:31 --> Helper loaded: cookie_helper
INFO - 2019-09-23 09:45:31 --> Helper loaded: date_helper
INFO - 2019-09-23 09:45:31 --> Form Validation Class Initialized
INFO - 2019-09-23 09:45:32 --> Email Class Initialized
DEBUG - 2019-09-23 09:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 09:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 09:45:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 09:45:32 --> Pagination Class Initialized
INFO - 2019-09-23 09:45:33 --> Database Driver Class Initialized
INFO - 2019-09-23 09:45:33 --> Database Driver Class Initialized
INFO - 2019-09-23 09:45:34 --> Controller Class Initialized
DEBUG - 2019-09-23 09:45:34 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-23 09:45:35 --> Helper loaded: inflector_helper
INFO - 2019-09-23 09:45:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-23 09:45:35 --> Final output sent to browser
DEBUG - 2019-09-23 09:45:35 --> Total execution time: 7.2628
INFO - 2019-09-23 09:51:36 --> Config Class Initialized
INFO - 2019-09-23 09:51:36 --> Hooks Class Initialized
DEBUG - 2019-09-23 09:51:36 --> UTF-8 Support Enabled
INFO - 2019-09-23 09:51:36 --> Utf8 Class Initialized
INFO - 2019-09-23 09:51:36 --> URI Class Initialized
INFO - 2019-09-23 09:51:36 --> Router Class Initialized
INFO - 2019-09-23 09:51:36 --> Output Class Initialized
INFO - 2019-09-23 09:51:36 --> Security Class Initialized
DEBUG - 2019-09-23 09:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-23 09:51:36 --> Input Class Initialized
INFO - 2019-09-23 09:51:36 --> Language Class Initialized
INFO - 2019-09-23 09:51:36 --> Loader Class Initialized
INFO - 2019-09-23 09:51:36 --> Helper loaded: url_helper
INFO - 2019-09-23 09:51:36 --> Helper loaded: html_helper
INFO - 2019-09-23 09:51:36 --> Helper loaded: form_helper
INFO - 2019-09-23 09:51:36 --> Helper loaded: cookie_helper
INFO - 2019-09-23 09:51:36 --> Helper loaded: date_helper
INFO - 2019-09-23 09:51:36 --> Form Validation Class Initialized
INFO - 2019-09-23 09:51:36 --> Email Class Initialized
DEBUG - 2019-09-23 09:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-23 09:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-23 09:51:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-23 09:51:36 --> Pagination Class Initialized
INFO - 2019-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2019-09-23 09:51:36 --> Database Driver Class Initialized
INFO - 2019-09-23 09:51:36 --> Controller Class Initialized
INFO - 2019-09-23 09:51:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-23 09:51:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report_sales.php
INFO - 2019-09-23 09:51:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-23 09:51:36 --> Final output sent to browser
DEBUG - 2019-09-23 09:51:36 --> Total execution time: 0.3498
