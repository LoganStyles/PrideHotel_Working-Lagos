<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-08-25 23:27:35 --> Config Class Initialized
INFO - 2019-08-25 23:27:35 --> Hooks Class Initialized
DEBUG - 2019-08-25 23:27:35 --> UTF-8 Support Enabled
INFO - 2019-08-25 23:27:35 --> Utf8 Class Initialized
INFO - 2019-08-25 23:27:35 --> URI Class Initialized
DEBUG - 2019-08-25 23:27:35 --> No URI present. Default controller set.
INFO - 2019-08-25 23:27:35 --> Router Class Initialized
INFO - 2019-08-25 23:27:35 --> Output Class Initialized
INFO - 2019-08-25 23:27:36 --> Security Class Initialized
DEBUG - 2019-08-25 23:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-25 23:27:36 --> Input Class Initialized
INFO - 2019-08-25 23:27:36 --> Language Class Initialized
INFO - 2019-08-25 23:27:36 --> Loader Class Initialized
INFO - 2019-08-25 23:27:36 --> Helper loaded: url_helper
INFO - 2019-08-25 23:27:36 --> Helper loaded: html_helper
INFO - 2019-08-25 23:27:36 --> Helper loaded: form_helper
INFO - 2019-08-25 23:27:36 --> Helper loaded: cookie_helper
INFO - 2019-08-25 23:27:36 --> Helper loaded: date_helper
INFO - 2019-08-25 23:27:36 --> Form Validation Class Initialized
INFO - 2019-08-25 23:27:36 --> Email Class Initialized
DEBUG - 2019-08-25 23:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-25 23:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-25 23:27:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-25 23:27:36 --> Pagination Class Initialized
INFO - 2019-08-25 23:27:37 --> Database Driver Class Initialized
INFO - 2019-08-25 23:27:37 --> Database Driver Class Initialized
INFO - 2019-08-25 23:27:37 --> Language file loaded: language/english/db_lang.php
INFO - 2019-08-25 23:28:29 --> Config Class Initialized
INFO - 2019-08-25 23:28:29 --> Hooks Class Initialized
DEBUG - 2019-08-25 23:28:29 --> UTF-8 Support Enabled
INFO - 2019-08-25 23:28:29 --> Utf8 Class Initialized
INFO - 2019-08-25 23:28:29 --> URI Class Initialized
INFO - 2019-08-25 23:28:29 --> Router Class Initialized
INFO - 2019-08-25 23:28:29 --> Output Class Initialized
INFO - 2019-08-25 23:28:29 --> Security Class Initialized
DEBUG - 2019-08-25 23:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-25 23:28:29 --> Input Class Initialized
INFO - 2019-08-25 23:28:29 --> Language Class Initialized
INFO - 2019-08-25 23:28:29 --> Loader Class Initialized
INFO - 2019-08-25 23:28:29 --> Helper loaded: url_helper
INFO - 2019-08-25 23:28:29 --> Helper loaded: html_helper
INFO - 2019-08-25 23:28:29 --> Helper loaded: form_helper
INFO - 2019-08-25 23:28:29 --> Helper loaded: cookie_helper
INFO - 2019-08-25 23:28:29 --> Helper loaded: date_helper
INFO - 2019-08-25 23:28:29 --> Form Validation Class Initialized
INFO - 2019-08-25 23:28:29 --> Email Class Initialized
DEBUG - 2019-08-25 23:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-25 23:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-25 23:28:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-25 23:28:29 --> Pagination Class Initialized
INFO - 2019-08-25 23:28:29 --> Database Driver Class Initialized
INFO - 2019-08-25 23:28:30 --> Database Driver Class Initialized
INFO - 2019-08-25 23:28:30 --> Language file loaded: language/english/db_lang.php
INFO - 2019-08-25 23:30:07 --> Config Class Initialized
INFO - 2019-08-25 23:30:07 --> Hooks Class Initialized
DEBUG - 2019-08-25 23:30:07 --> UTF-8 Support Enabled
INFO - 2019-08-25 23:30:07 --> Utf8 Class Initialized
INFO - 2019-08-25 23:30:07 --> URI Class Initialized
DEBUG - 2019-08-25 23:30:07 --> No URI present. Default controller set.
INFO - 2019-08-25 23:30:07 --> Router Class Initialized
INFO - 2019-08-25 23:30:07 --> Output Class Initialized
INFO - 2019-08-25 23:30:07 --> Security Class Initialized
DEBUG - 2019-08-25 23:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-25 23:30:07 --> Input Class Initialized
INFO - 2019-08-25 23:30:07 --> Language Class Initialized
INFO - 2019-08-25 23:30:07 --> Loader Class Initialized
INFO - 2019-08-25 23:30:07 --> Helper loaded: url_helper
INFO - 2019-08-25 23:30:07 --> Helper loaded: html_helper
INFO - 2019-08-25 23:30:07 --> Helper loaded: form_helper
INFO - 2019-08-25 23:30:07 --> Helper loaded: cookie_helper
INFO - 2019-08-25 23:30:07 --> Helper loaded: date_helper
INFO - 2019-08-25 23:30:07 --> Form Validation Class Initialized
INFO - 2019-08-25 23:30:07 --> Email Class Initialized
DEBUG - 2019-08-25 23:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-25 23:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-25 23:30:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-25 23:30:07 --> Pagination Class Initialized
INFO - 2019-08-25 23:30:07 --> Database Driver Class Initialized
INFO - 2019-08-25 23:30:07 --> Database Driver Class Initialized
INFO - 2019-08-25 23:30:07 --> Language file loaded: language/english/db_lang.php
INFO - 2019-08-25 23:40:26 --> Config Class Initialized
INFO - 2019-08-25 23:40:26 --> Hooks Class Initialized
DEBUG - 2019-08-25 23:40:26 --> UTF-8 Support Enabled
INFO - 2019-08-25 23:40:26 --> Utf8 Class Initialized
INFO - 2019-08-25 23:40:26 --> URI Class Initialized
DEBUG - 2019-08-25 23:40:26 --> No URI present. Default controller set.
INFO - 2019-08-25 23:40:26 --> Router Class Initialized
INFO - 2019-08-25 23:40:26 --> Output Class Initialized
INFO - 2019-08-25 23:40:26 --> Security Class Initialized
DEBUG - 2019-08-25 23:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-25 23:40:26 --> Input Class Initialized
INFO - 2019-08-25 23:40:26 --> Language Class Initialized
INFO - 2019-08-25 23:40:26 --> Loader Class Initialized
INFO - 2019-08-25 23:40:26 --> Helper loaded: url_helper
INFO - 2019-08-25 23:40:26 --> Helper loaded: html_helper
INFO - 2019-08-25 23:40:26 --> Helper loaded: form_helper
INFO - 2019-08-25 23:40:26 --> Helper loaded: cookie_helper
INFO - 2019-08-25 23:40:26 --> Helper loaded: date_helper
INFO - 2019-08-25 23:40:26 --> Form Validation Class Initialized
INFO - 2019-08-25 23:40:26 --> Email Class Initialized
DEBUG - 2019-08-25 23:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-25 23:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-25 23:40:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-25 23:40:26 --> Pagination Class Initialized
INFO - 2019-08-25 23:40:26 --> Database Driver Class Initialized
INFO - 2019-08-25 23:40:26 --> Database Driver Class Initialized
INFO - 2019-08-25 23:40:26 --> Language file loaded: language/english/db_lang.php
INFO - 2019-08-25 23:56:28 --> Config Class Initialized
INFO - 2019-08-25 23:56:28 --> Hooks Class Initialized
DEBUG - 2019-08-25 23:56:28 --> UTF-8 Support Enabled
INFO - 2019-08-25 23:56:28 --> Utf8 Class Initialized
INFO - 2019-08-25 23:56:28 --> URI Class Initialized
DEBUG - 2019-08-25 23:56:28 --> No URI present. Default controller set.
INFO - 2019-08-25 23:56:28 --> Router Class Initialized
INFO - 2019-08-25 23:56:28 --> Output Class Initialized
INFO - 2019-08-25 23:56:28 --> Security Class Initialized
DEBUG - 2019-08-25 23:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-25 23:56:28 --> Input Class Initialized
INFO - 2019-08-25 23:56:28 --> Language Class Initialized
INFO - 2019-08-25 23:56:28 --> Loader Class Initialized
INFO - 2019-08-25 23:56:28 --> Helper loaded: url_helper
INFO - 2019-08-25 23:56:28 --> Helper loaded: html_helper
INFO - 2019-08-25 23:56:28 --> Helper loaded: form_helper
INFO - 2019-08-25 23:56:28 --> Helper loaded: cookie_helper
INFO - 2019-08-25 23:56:28 --> Helper loaded: date_helper
INFO - 2019-08-25 23:56:28 --> Form Validation Class Initialized
INFO - 2019-08-25 23:56:28 --> Email Class Initialized
DEBUG - 2019-08-25 23:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-25 23:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-25 23:56:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-25 23:56:28 --> Pagination Class Initialized
INFO - 2019-08-25 23:56:28 --> Database Driver Class Initialized
INFO - 2019-08-25 23:56:28 --> Database Driver Class Initialized
INFO - 2019-08-25 23:56:28 --> Language file loaded: language/english/db_lang.php
