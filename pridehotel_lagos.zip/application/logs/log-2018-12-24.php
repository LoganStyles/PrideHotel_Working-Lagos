<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-12-24 17:59:03 --> Config Class Initialized
INFO - 2018-12-24 17:59:03 --> Hooks Class Initialized
DEBUG - 2018-12-24 17:59:04 --> UTF-8 Support Enabled
INFO - 2018-12-24 17:59:04 --> Utf8 Class Initialized
INFO - 2018-12-24 17:59:04 --> URI Class Initialized
DEBUG - 2018-12-24 17:59:04 --> No URI present. Default controller set.
INFO - 2018-12-24 17:59:04 --> Router Class Initialized
INFO - 2018-12-24 17:59:04 --> Output Class Initialized
INFO - 2018-12-24 17:59:04 --> Security Class Initialized
DEBUG - 2018-12-24 17:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 17:59:04 --> Input Class Initialized
INFO - 2018-12-24 17:59:04 --> Language Class Initialized
INFO - 2018-12-24 17:59:04 --> Loader Class Initialized
INFO - 2018-12-24 17:59:04 --> Helper loaded: url_helper
INFO - 2018-12-24 17:59:04 --> Helper loaded: html_helper
INFO - 2018-12-24 17:59:04 --> Helper loaded: form_helper
INFO - 2018-12-24 17:59:04 --> Helper loaded: cookie_helper
INFO - 2018-12-24 17:59:04 --> Helper loaded: date_helper
INFO - 2018-12-24 17:59:04 --> Form Validation Class Initialized
INFO - 2018-12-24 17:59:04 --> Email Class Initialized
DEBUG - 2018-12-24 17:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 17:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 17:59:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 17:59:04 --> Pagination Class Initialized
INFO - 2018-12-24 17:59:04 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:04 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:05 --> Controller Class Initialized
INFO - 2018-12-24 17:59:05 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-12-24 17:59:05 --> Final output sent to browser
DEBUG - 2018-12-24 17:59:05 --> Total execution time: 1.4421
INFO - 2018-12-24 17:59:28 --> Config Class Initialized
INFO - 2018-12-24 17:59:28 --> Hooks Class Initialized
DEBUG - 2018-12-24 17:59:28 --> UTF-8 Support Enabled
INFO - 2018-12-24 17:59:28 --> Utf8 Class Initialized
INFO - 2018-12-24 17:59:28 --> URI Class Initialized
INFO - 2018-12-24 17:59:28 --> Router Class Initialized
INFO - 2018-12-24 17:59:28 --> Output Class Initialized
INFO - 2018-12-24 17:59:28 --> Security Class Initialized
DEBUG - 2018-12-24 17:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 17:59:28 --> Input Class Initialized
INFO - 2018-12-24 17:59:28 --> Language Class Initialized
INFO - 2018-12-24 17:59:28 --> Loader Class Initialized
INFO - 2018-12-24 17:59:28 --> Helper loaded: url_helper
INFO - 2018-12-24 17:59:28 --> Helper loaded: html_helper
INFO - 2018-12-24 17:59:28 --> Helper loaded: form_helper
INFO - 2018-12-24 17:59:28 --> Helper loaded: cookie_helper
INFO - 2018-12-24 17:59:28 --> Helper loaded: date_helper
INFO - 2018-12-24 17:59:28 --> Form Validation Class Initialized
INFO - 2018-12-24 17:59:28 --> Email Class Initialized
DEBUG - 2018-12-24 17:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 17:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 17:59:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 17:59:28 --> Pagination Class Initialized
INFO - 2018-12-24 17:59:28 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:28 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:28 --> Controller Class Initialized
INFO - 2018-12-24 17:59:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-12-24 17:59:29 --> Config Class Initialized
INFO - 2018-12-24 17:59:29 --> Hooks Class Initialized
DEBUG - 2018-12-24 17:59:29 --> UTF-8 Support Enabled
INFO - 2018-12-24 17:59:29 --> Utf8 Class Initialized
INFO - 2018-12-24 17:59:29 --> URI Class Initialized
INFO - 2018-12-24 17:59:29 --> Router Class Initialized
INFO - 2018-12-24 17:59:29 --> Output Class Initialized
INFO - 2018-12-24 17:59:29 --> Security Class Initialized
DEBUG - 2018-12-24 17:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 17:59:29 --> Input Class Initialized
INFO - 2018-12-24 17:59:29 --> Language Class Initialized
INFO - 2018-12-24 17:59:29 --> Loader Class Initialized
INFO - 2018-12-24 17:59:29 --> Helper loaded: url_helper
INFO - 2018-12-24 17:59:29 --> Helper loaded: html_helper
INFO - 2018-12-24 17:59:29 --> Helper loaded: form_helper
INFO - 2018-12-24 17:59:29 --> Helper loaded: cookie_helper
INFO - 2018-12-24 17:59:29 --> Helper loaded: date_helper
INFO - 2018-12-24 17:59:29 --> Form Validation Class Initialized
INFO - 2018-12-24 17:59:29 --> Email Class Initialized
DEBUG - 2018-12-24 17:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 17:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 17:59:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 17:59:29 --> Pagination Class Initialized
INFO - 2018-12-24 17:59:29 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:29 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:29 --> Controller Class Initialized
INFO - 2018-12-24 17:59:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-24 17:59:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-12-24 17:59:29 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-24 17:59:29 --> Final output sent to browser
DEBUG - 2018-12-24 17:59:29 --> Total execution time: 0.2744
INFO - 2018-12-24 17:59:29 --> Config Class Initialized
INFO - 2018-12-24 17:59:29 --> Config Class Initialized
INFO - 2018-12-24 17:59:29 --> Hooks Class Initialized
INFO - 2018-12-24 17:59:29 --> Hooks Class Initialized
DEBUG - 2018-12-24 17:59:29 --> UTF-8 Support Enabled
DEBUG - 2018-12-24 17:59:29 --> UTF-8 Support Enabled
INFO - 2018-12-24 17:59:29 --> Utf8 Class Initialized
INFO - 2018-12-24 17:59:29 --> Utf8 Class Initialized
INFO - 2018-12-24 17:59:29 --> URI Class Initialized
INFO - 2018-12-24 17:59:29 --> URI Class Initialized
INFO - 2018-12-24 17:59:29 --> Router Class Initialized
INFO - 2018-12-24 17:59:29 --> Router Class Initialized
INFO - 2018-12-24 17:59:29 --> Output Class Initialized
INFO - 2018-12-24 17:59:29 --> Output Class Initialized
INFO - 2018-12-24 17:59:29 --> Security Class Initialized
INFO - 2018-12-24 17:59:29 --> Security Class Initialized
DEBUG - 2018-12-24 17:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 17:59:29 --> Input Class Initialized
DEBUG - 2018-12-24 17:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 17:59:29 --> Input Class Initialized
INFO - 2018-12-24 17:59:29 --> Language Class Initialized
INFO - 2018-12-24 17:59:29 --> Language Class Initialized
INFO - 2018-12-24 17:59:29 --> Loader Class Initialized
INFO - 2018-12-24 17:59:29 --> Helper loaded: url_helper
INFO - 2018-12-24 17:59:29 --> Helper loaded: html_helper
INFO - 2018-12-24 17:59:29 --> Helper loaded: form_helper
INFO - 2018-12-24 17:59:29 --> Helper loaded: cookie_helper
INFO - 2018-12-24 17:59:29 --> Loader Class Initialized
INFO - 2018-12-24 17:59:29 --> Helper loaded: url_helper
INFO - 2018-12-24 17:59:29 --> Helper loaded: date_helper
INFO - 2018-12-24 17:59:29 --> Helper loaded: html_helper
INFO - 2018-12-24 17:59:29 --> Form Validation Class Initialized
INFO - 2018-12-24 17:59:29 --> Helper loaded: form_helper
INFO - 2018-12-24 17:59:29 --> Helper loaded: cookie_helper
INFO - 2018-12-24 17:59:29 --> Helper loaded: date_helper
INFO - 2018-12-24 17:59:29 --> Email Class Initialized
INFO - 2018-12-24 17:59:29 --> Form Validation Class Initialized
INFO - 2018-12-24 17:59:29 --> Email Class Initialized
DEBUG - 2018-12-24 17:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 17:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 17:59:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 17:59:29 --> Pagination Class Initialized
DEBUG - 2018-12-24 17:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 17:59:30 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:30 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:30 --> Controller Class Initialized
INFO - 2018-12-24 17:59:30 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 17:59:30 --> Final output sent to browser
DEBUG - 2018-12-24 17:59:30 --> Total execution time: 0.3213
INFO - 2018-12-24 17:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 17:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 17:59:30 --> Pagination Class Initialized
INFO - 2018-12-24 17:59:30 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:30 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:30 --> Controller Class Initialized
INFO - 2018-12-24 17:59:30 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 17:59:30 --> Final output sent to browser
DEBUG - 2018-12-24 17:59:30 --> Total execution time: 0.4352
INFO - 2018-12-24 17:59:51 --> Config Class Initialized
INFO - 2018-12-24 17:59:51 --> Hooks Class Initialized
DEBUG - 2018-12-24 17:59:51 --> UTF-8 Support Enabled
INFO - 2018-12-24 17:59:51 --> Utf8 Class Initialized
INFO - 2018-12-24 17:59:51 --> URI Class Initialized
INFO - 2018-12-24 17:59:51 --> Router Class Initialized
INFO - 2018-12-24 17:59:51 --> Output Class Initialized
INFO - 2018-12-24 17:59:51 --> Security Class Initialized
DEBUG - 2018-12-24 17:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 17:59:51 --> Input Class Initialized
INFO - 2018-12-24 17:59:51 --> Language Class Initialized
INFO - 2018-12-24 17:59:51 --> Loader Class Initialized
INFO - 2018-12-24 17:59:51 --> Helper loaded: url_helper
INFO - 2018-12-24 17:59:51 --> Helper loaded: html_helper
INFO - 2018-12-24 17:59:51 --> Helper loaded: form_helper
INFO - 2018-12-24 17:59:51 --> Helper loaded: cookie_helper
INFO - 2018-12-24 17:59:51 --> Helper loaded: date_helper
INFO - 2018-12-24 17:59:51 --> Form Validation Class Initialized
INFO - 2018-12-24 17:59:51 --> Email Class Initialized
DEBUG - 2018-12-24 17:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 17:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 17:59:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 17:59:51 --> Pagination Class Initialized
INFO - 2018-12-24 17:59:51 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:51 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:51 --> Controller Class Initialized
INFO - 2018-12-24 17:59:51 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-24 17:59:51 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation_house.php
INFO - 2018-12-24 17:59:51 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-24 17:59:51 --> Final output sent to browser
DEBUG - 2018-12-24 17:59:51 --> Total execution time: 0.2221
INFO - 2018-12-24 17:59:51 --> Config Class Initialized
INFO - 2018-12-24 17:59:51 --> Config Class Initialized
INFO - 2018-12-24 17:59:51 --> Hooks Class Initialized
INFO - 2018-12-24 17:59:51 --> Hooks Class Initialized
DEBUG - 2018-12-24 17:59:51 --> UTF-8 Support Enabled
INFO - 2018-12-24 17:59:51 --> Utf8 Class Initialized
DEBUG - 2018-12-24 17:59:51 --> UTF-8 Support Enabled
INFO - 2018-12-24 17:59:51 --> Utf8 Class Initialized
INFO - 2018-12-24 17:59:51 --> URI Class Initialized
INFO - 2018-12-24 17:59:51 --> URI Class Initialized
INFO - 2018-12-24 17:59:51 --> Router Class Initialized
INFO - 2018-12-24 17:59:51 --> Router Class Initialized
INFO - 2018-12-24 17:59:51 --> Output Class Initialized
INFO - 2018-12-24 17:59:51 --> Security Class Initialized
INFO - 2018-12-24 17:59:51 --> Output Class Initialized
INFO - 2018-12-24 17:59:51 --> Security Class Initialized
DEBUG - 2018-12-24 17:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 17:59:51 --> Input Class Initialized
INFO - 2018-12-24 17:59:51 --> Language Class Initialized
DEBUG - 2018-12-24 17:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 17:59:51 --> Input Class Initialized
INFO - 2018-12-24 17:59:51 --> Language Class Initialized
INFO - 2018-12-24 17:59:52 --> Loader Class Initialized
INFO - 2018-12-24 17:59:52 --> Loader Class Initialized
INFO - 2018-12-24 17:59:52 --> Helper loaded: url_helper
INFO - 2018-12-24 17:59:52 --> Helper loaded: url_helper
INFO - 2018-12-24 17:59:52 --> Helper loaded: html_helper
INFO - 2018-12-24 17:59:52 --> Helper loaded: html_helper
INFO - 2018-12-24 17:59:52 --> Helper loaded: form_helper
INFO - 2018-12-24 17:59:52 --> Helper loaded: form_helper
INFO - 2018-12-24 17:59:52 --> Helper loaded: cookie_helper
INFO - 2018-12-24 17:59:52 --> Helper loaded: cookie_helper
INFO - 2018-12-24 17:59:52 --> Helper loaded: date_helper
INFO - 2018-12-24 17:59:52 --> Helper loaded: date_helper
INFO - 2018-12-24 17:59:52 --> Form Validation Class Initialized
INFO - 2018-12-24 17:59:52 --> Form Validation Class Initialized
INFO - 2018-12-24 17:59:52 --> Email Class Initialized
INFO - 2018-12-24 17:59:52 --> Email Class Initialized
DEBUG - 2018-12-24 17:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 17:59:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-24 17:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 17:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 17:59:52 --> Pagination Class Initialized
INFO - 2018-12-24 17:59:52 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:52 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:52 --> Controller Class Initialized
INFO - 2018-12-24 17:59:52 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 17:59:52 --> Final output sent to browser
DEBUG - 2018-12-24 17:59:52 --> Total execution time: 0.2487
INFO - 2018-12-24 17:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 17:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 17:59:52 --> Pagination Class Initialized
INFO - 2018-12-24 17:59:52 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:52 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:52 --> Controller Class Initialized
INFO - 2018-12-24 17:59:52 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 17:59:52 --> Final output sent to browser
DEBUG - 2018-12-24 17:59:52 --> Total execution time: 0.3517
INFO - 2018-12-24 17:59:56 --> Config Class Initialized
INFO - 2018-12-24 17:59:56 --> Hooks Class Initialized
DEBUG - 2018-12-24 17:59:56 --> UTF-8 Support Enabled
INFO - 2018-12-24 17:59:56 --> Utf8 Class Initialized
INFO - 2018-12-24 17:59:56 --> URI Class Initialized
INFO - 2018-12-24 17:59:56 --> Router Class Initialized
INFO - 2018-12-24 17:59:56 --> Output Class Initialized
INFO - 2018-12-24 17:59:56 --> Security Class Initialized
DEBUG - 2018-12-24 17:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 17:59:56 --> Input Class Initialized
INFO - 2018-12-24 17:59:56 --> Language Class Initialized
INFO - 2018-12-24 17:59:56 --> Loader Class Initialized
INFO - 2018-12-24 17:59:56 --> Helper loaded: url_helper
INFO - 2018-12-24 17:59:56 --> Helper loaded: html_helper
INFO - 2018-12-24 17:59:56 --> Helper loaded: form_helper
INFO - 2018-12-24 17:59:56 --> Helper loaded: cookie_helper
INFO - 2018-12-24 17:59:56 --> Helper loaded: date_helper
INFO - 2018-12-24 17:59:56 --> Form Validation Class Initialized
INFO - 2018-12-24 17:59:56 --> Email Class Initialized
DEBUG - 2018-12-24 17:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 17:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 17:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 17:59:56 --> Pagination Class Initialized
INFO - 2018-12-24 17:59:56 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:56 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:56 --> Controller Class Initialized
INFO - 2018-12-24 17:59:56 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-24 17:59:56 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-12-24 17:59:56 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-24 17:59:56 --> Final output sent to browser
DEBUG - 2018-12-24 17:59:56 --> Total execution time: 0.1914
INFO - 2018-12-24 17:59:56 --> Config Class Initialized
INFO - 2018-12-24 17:59:56 --> Hooks Class Initialized
INFO - 2018-12-24 17:59:56 --> Config Class Initialized
INFO - 2018-12-24 17:59:56 --> Hooks Class Initialized
DEBUG - 2018-12-24 17:59:56 --> UTF-8 Support Enabled
INFO - 2018-12-24 17:59:56 --> Utf8 Class Initialized
DEBUG - 2018-12-24 17:59:56 --> UTF-8 Support Enabled
INFO - 2018-12-24 17:59:56 --> Utf8 Class Initialized
INFO - 2018-12-24 17:59:56 --> URI Class Initialized
INFO - 2018-12-24 17:59:56 --> URI Class Initialized
INFO - 2018-12-24 17:59:56 --> Router Class Initialized
INFO - 2018-12-24 17:59:56 --> Router Class Initialized
INFO - 2018-12-24 17:59:56 --> Output Class Initialized
INFO - 2018-12-24 17:59:56 --> Output Class Initialized
INFO - 2018-12-24 17:59:56 --> Security Class Initialized
INFO - 2018-12-24 17:59:56 --> Security Class Initialized
DEBUG - 2018-12-24 17:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 17:59:56 --> Input Class Initialized
DEBUG - 2018-12-24 17:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 17:59:56 --> Input Class Initialized
INFO - 2018-12-24 17:59:56 --> Language Class Initialized
INFO - 2018-12-24 17:59:56 --> Language Class Initialized
INFO - 2018-12-24 17:59:56 --> Loader Class Initialized
INFO - 2018-12-24 17:59:56 --> Loader Class Initialized
INFO - 2018-12-24 17:59:56 --> Helper loaded: url_helper
INFO - 2018-12-24 17:59:56 --> Helper loaded: url_helper
INFO - 2018-12-24 17:59:56 --> Helper loaded: html_helper
INFO - 2018-12-24 17:59:56 --> Helper loaded: html_helper
INFO - 2018-12-24 17:59:56 --> Helper loaded: form_helper
INFO - 2018-12-24 17:59:56 --> Helper loaded: form_helper
INFO - 2018-12-24 17:59:56 --> Helper loaded: cookie_helper
INFO - 2018-12-24 17:59:56 --> Helper loaded: cookie_helper
INFO - 2018-12-24 17:59:56 --> Helper loaded: date_helper
INFO - 2018-12-24 17:59:56 --> Helper loaded: date_helper
INFO - 2018-12-24 17:59:56 --> Form Validation Class Initialized
INFO - 2018-12-24 17:59:56 --> Form Validation Class Initialized
INFO - 2018-12-24 17:59:56 --> Email Class Initialized
INFO - 2018-12-24 17:59:56 --> Email Class Initialized
DEBUG - 2018-12-24 17:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 17:59:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-24 17:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 17:59:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 17:59:56 --> Pagination Class Initialized
INFO - 2018-12-24 17:59:56 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:56 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:56 --> Controller Class Initialized
INFO - 2018-12-24 17:59:56 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 17:59:56 --> Final output sent to browser
DEBUG - 2018-12-24 17:59:56 --> Total execution time: 0.2384
INFO - 2018-12-24 17:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 17:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 17:59:57 --> Pagination Class Initialized
INFO - 2018-12-24 17:59:57 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:57 --> Database Driver Class Initialized
INFO - 2018-12-24 17:59:57 --> Controller Class Initialized
INFO - 2018-12-24 17:59:57 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 17:59:57 --> Final output sent to browser
DEBUG - 2018-12-24 17:59:57 --> Total execution time: 0.3496
INFO - 2018-12-24 18:00:17 --> Config Class Initialized
INFO - 2018-12-24 18:00:17 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:00:17 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:00:17 --> Utf8 Class Initialized
INFO - 2018-12-24 18:00:17 --> URI Class Initialized
INFO - 2018-12-24 18:00:17 --> Router Class Initialized
INFO - 2018-12-24 18:00:17 --> Output Class Initialized
INFO - 2018-12-24 18:00:17 --> Security Class Initialized
DEBUG - 2018-12-24 18:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:00:17 --> Input Class Initialized
INFO - 2018-12-24 18:00:17 --> Language Class Initialized
INFO - 2018-12-24 18:00:17 --> Loader Class Initialized
INFO - 2018-12-24 18:00:17 --> Helper loaded: url_helper
INFO - 2018-12-24 18:00:17 --> Helper loaded: html_helper
INFO - 2018-12-24 18:00:17 --> Helper loaded: form_helper
INFO - 2018-12-24 18:00:17 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:00:17 --> Helper loaded: date_helper
INFO - 2018-12-24 18:00:17 --> Form Validation Class Initialized
INFO - 2018-12-24 18:00:17 --> Email Class Initialized
DEBUG - 2018-12-24 18:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:00:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:00:17 --> Pagination Class Initialized
INFO - 2018-12-24 18:00:17 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:17 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:17 --> Controller Class Initialized
INFO - 2018-12-24 18:00:17 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 18:00:17 --> Final output sent to browser
DEBUG - 2018-12-24 18:00:17 --> Total execution time: 0.1944
INFO - 2018-12-24 18:00:18 --> Config Class Initialized
INFO - 2018-12-24 18:00:18 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:00:18 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:00:18 --> Utf8 Class Initialized
INFO - 2018-12-24 18:00:18 --> URI Class Initialized
INFO - 2018-12-24 18:00:18 --> Router Class Initialized
INFO - 2018-12-24 18:00:18 --> Output Class Initialized
INFO - 2018-12-24 18:00:18 --> Security Class Initialized
DEBUG - 2018-12-24 18:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:00:18 --> Input Class Initialized
INFO - 2018-12-24 18:00:18 --> Language Class Initialized
INFO - 2018-12-24 18:00:18 --> Loader Class Initialized
INFO - 2018-12-24 18:00:18 --> Helper loaded: url_helper
INFO - 2018-12-24 18:00:18 --> Helper loaded: html_helper
INFO - 2018-12-24 18:00:18 --> Helper loaded: form_helper
INFO - 2018-12-24 18:00:18 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:00:18 --> Helper loaded: date_helper
INFO - 2018-12-24 18:00:18 --> Form Validation Class Initialized
INFO - 2018-12-24 18:00:18 --> Email Class Initialized
DEBUG - 2018-12-24 18:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:00:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:00:18 --> Pagination Class Initialized
INFO - 2018-12-24 18:00:18 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:18 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:18 --> Controller Class Initialized
INFO - 2018-12-24 18:00:18 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-24 18:00:18 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation_house.php
INFO - 2018-12-24 18:00:18 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-24 18:00:18 --> Final output sent to browser
DEBUG - 2018-12-24 18:00:18 --> Total execution time: 0.1985
INFO - 2018-12-24 18:00:18 --> Config Class Initialized
INFO - 2018-12-24 18:00:18 --> Hooks Class Initialized
INFO - 2018-12-24 18:00:18 --> Config Class Initialized
INFO - 2018-12-24 18:00:18 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:00:18 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:00:18 --> Utf8 Class Initialized
DEBUG - 2018-12-24 18:00:18 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:00:18 --> Utf8 Class Initialized
INFO - 2018-12-24 18:00:18 --> URI Class Initialized
INFO - 2018-12-24 18:00:18 --> URI Class Initialized
INFO - 2018-12-24 18:00:18 --> Router Class Initialized
INFO - 2018-12-24 18:00:18 --> Router Class Initialized
INFO - 2018-12-24 18:00:18 --> Output Class Initialized
INFO - 2018-12-24 18:00:18 --> Output Class Initialized
INFO - 2018-12-24 18:00:18 --> Security Class Initialized
INFO - 2018-12-24 18:00:18 --> Security Class Initialized
DEBUG - 2018-12-24 18:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-12-24 18:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:00:18 --> Input Class Initialized
INFO - 2018-12-24 18:00:18 --> Input Class Initialized
INFO - 2018-12-24 18:00:18 --> Language Class Initialized
INFO - 2018-12-24 18:00:18 --> Language Class Initialized
INFO - 2018-12-24 18:00:18 --> Loader Class Initialized
INFO - 2018-12-24 18:00:18 --> Loader Class Initialized
INFO - 2018-12-24 18:00:18 --> Helper loaded: url_helper
INFO - 2018-12-24 18:00:18 --> Helper loaded: html_helper
INFO - 2018-12-24 18:00:18 --> Helper loaded: form_helper
INFO - 2018-12-24 18:00:18 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:00:18 --> Helper loaded: url_helper
INFO - 2018-12-24 18:00:18 --> Helper loaded: html_helper
INFO - 2018-12-24 18:00:18 --> Helper loaded: date_helper
INFO - 2018-12-24 18:00:18 --> Helper loaded: form_helper
INFO - 2018-12-24 18:00:18 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:00:18 --> Form Validation Class Initialized
INFO - 2018-12-24 18:00:18 --> Helper loaded: date_helper
INFO - 2018-12-24 18:00:18 --> Form Validation Class Initialized
INFO - 2018-12-24 18:00:18 --> Email Class Initialized
INFO - 2018-12-24 18:00:18 --> Email Class Initialized
DEBUG - 2018-12-24 18:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:00:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-24 18:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:00:19 --> Pagination Class Initialized
INFO - 2018-12-24 18:00:19 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:19 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:19 --> Controller Class Initialized
INFO - 2018-12-24 18:00:19 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 18:00:19 --> Final output sent to browser
DEBUG - 2018-12-24 18:00:19 --> Total execution time: 0.2464
INFO - 2018-12-24 18:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:00:19 --> Pagination Class Initialized
INFO - 2018-12-24 18:00:19 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:19 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:19 --> Controller Class Initialized
INFO - 2018-12-24 18:00:19 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 18:00:19 --> Final output sent to browser
DEBUG - 2018-12-24 18:00:19 --> Total execution time: 0.3600
INFO - 2018-12-24 18:00:20 --> Config Class Initialized
INFO - 2018-12-24 18:00:20 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:00:20 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:00:20 --> Utf8 Class Initialized
INFO - 2018-12-24 18:00:20 --> URI Class Initialized
INFO - 2018-12-24 18:00:20 --> Router Class Initialized
INFO - 2018-12-24 18:00:20 --> Output Class Initialized
INFO - 2018-12-24 18:00:20 --> Security Class Initialized
DEBUG - 2018-12-24 18:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:00:20 --> Input Class Initialized
INFO - 2018-12-24 18:00:20 --> Language Class Initialized
INFO - 2018-12-24 18:00:20 --> Loader Class Initialized
INFO - 2018-12-24 18:00:20 --> Helper loaded: url_helper
INFO - 2018-12-24 18:00:20 --> Helper loaded: html_helper
INFO - 2018-12-24 18:00:20 --> Helper loaded: form_helper
INFO - 2018-12-24 18:00:20 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:00:20 --> Helper loaded: date_helper
INFO - 2018-12-24 18:00:20 --> Form Validation Class Initialized
INFO - 2018-12-24 18:00:20 --> Email Class Initialized
DEBUG - 2018-12-24 18:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:00:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:00:20 --> Pagination Class Initialized
INFO - 2018-12-24 18:00:20 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:20 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:20 --> Controller Class Initialized
INFO - 2018-12-24 18:00:20 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 18:00:20 --> Final output sent to browser
DEBUG - 2018-12-24 18:00:20 --> Total execution time: 0.2582
INFO - 2018-12-24 18:00:23 --> Config Class Initialized
INFO - 2018-12-24 18:00:23 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:00:23 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:00:23 --> Utf8 Class Initialized
INFO - 2018-12-24 18:00:23 --> URI Class Initialized
INFO - 2018-12-24 18:00:23 --> Router Class Initialized
INFO - 2018-12-24 18:00:23 --> Output Class Initialized
INFO - 2018-12-24 18:00:23 --> Security Class Initialized
DEBUG - 2018-12-24 18:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:00:23 --> Input Class Initialized
INFO - 2018-12-24 18:00:23 --> Language Class Initialized
INFO - 2018-12-24 18:00:23 --> Loader Class Initialized
INFO - 2018-12-24 18:00:23 --> Helper loaded: url_helper
INFO - 2018-12-24 18:00:23 --> Helper loaded: html_helper
INFO - 2018-12-24 18:00:23 --> Helper loaded: form_helper
INFO - 2018-12-24 18:00:23 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:00:23 --> Helper loaded: date_helper
INFO - 2018-12-24 18:00:23 --> Form Validation Class Initialized
INFO - 2018-12-24 18:00:23 --> Email Class Initialized
DEBUG - 2018-12-24 18:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:00:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:00:23 --> Pagination Class Initialized
INFO - 2018-12-24 18:00:23 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:23 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:23 --> Controller Class Initialized
INFO - 2018-12-24 18:00:23 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-24 18:00:23 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-12-24 18:00:23 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-24 18:00:23 --> Final output sent to browser
DEBUG - 2018-12-24 18:00:23 --> Total execution time: 0.1914
INFO - 2018-12-24 18:00:23 --> Config Class Initialized
INFO - 2018-12-24 18:00:23 --> Hooks Class Initialized
INFO - 2018-12-24 18:00:23 --> Config Class Initialized
INFO - 2018-12-24 18:00:23 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:00:23 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:00:23 --> Utf8 Class Initialized
DEBUG - 2018-12-24 18:00:23 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:00:23 --> Utf8 Class Initialized
INFO - 2018-12-24 18:00:23 --> URI Class Initialized
INFO - 2018-12-24 18:00:23 --> URI Class Initialized
INFO - 2018-12-24 18:00:23 --> Router Class Initialized
INFO - 2018-12-24 18:00:23 --> Router Class Initialized
INFO - 2018-12-24 18:00:23 --> Output Class Initialized
INFO - 2018-12-24 18:00:23 --> Security Class Initialized
INFO - 2018-12-24 18:00:23 --> Output Class Initialized
DEBUG - 2018-12-24 18:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:00:23 --> Security Class Initialized
INFO - 2018-12-24 18:00:23 --> Input Class Initialized
INFO - 2018-12-24 18:00:23 --> Language Class Initialized
DEBUG - 2018-12-24 18:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:00:23 --> Input Class Initialized
INFO - 2018-12-24 18:00:23 --> Language Class Initialized
INFO - 2018-12-24 18:00:23 --> Loader Class Initialized
INFO - 2018-12-24 18:00:23 --> Loader Class Initialized
INFO - 2018-12-24 18:00:23 --> Helper loaded: url_helper
INFO - 2018-12-24 18:00:23 --> Helper loaded: html_helper
INFO - 2018-12-24 18:00:23 --> Helper loaded: url_helper
INFO - 2018-12-24 18:00:23 --> Helper loaded: html_helper
INFO - 2018-12-24 18:00:23 --> Helper loaded: form_helper
INFO - 2018-12-24 18:00:23 --> Helper loaded: form_helper
INFO - 2018-12-24 18:00:23 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:00:23 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:00:23 --> Helper loaded: date_helper
INFO - 2018-12-24 18:00:23 --> Helper loaded: date_helper
INFO - 2018-12-24 18:00:23 --> Form Validation Class Initialized
INFO - 2018-12-24 18:00:23 --> Form Validation Class Initialized
INFO - 2018-12-24 18:00:23 --> Email Class Initialized
INFO - 2018-12-24 18:00:23 --> Email Class Initialized
DEBUG - 2018-12-24 18:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:00:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:00:23 --> Pagination Class Initialized
DEBUG - 2018-12-24 18:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:00:23 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:23 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:23 --> Controller Class Initialized
INFO - 2018-12-24 18:00:23 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 18:00:23 --> Final output sent to browser
DEBUG - 2018-12-24 18:00:23 --> Total execution time: 0.2334
INFO - 2018-12-24 18:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:00:24 --> Pagination Class Initialized
INFO - 2018-12-24 18:00:24 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:24 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:24 --> Controller Class Initialized
INFO - 2018-12-24 18:00:24 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 18:00:24 --> Final output sent to browser
DEBUG - 2018-12-24 18:00:24 --> Total execution time: 0.3249
INFO - 2018-12-24 18:00:24 --> Config Class Initialized
INFO - 2018-12-24 18:00:24 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:00:24 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:00:24 --> Utf8 Class Initialized
INFO - 2018-12-24 18:00:24 --> URI Class Initialized
INFO - 2018-12-24 18:00:24 --> Router Class Initialized
INFO - 2018-12-24 18:00:24 --> Output Class Initialized
INFO - 2018-12-24 18:00:24 --> Security Class Initialized
DEBUG - 2018-12-24 18:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:00:24 --> Input Class Initialized
INFO - 2018-12-24 18:00:24 --> Language Class Initialized
INFO - 2018-12-24 18:00:24 --> Loader Class Initialized
INFO - 2018-12-24 18:00:24 --> Helper loaded: url_helper
INFO - 2018-12-24 18:00:24 --> Helper loaded: html_helper
INFO - 2018-12-24 18:00:24 --> Helper loaded: form_helper
INFO - 2018-12-24 18:00:24 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:00:24 --> Helper loaded: date_helper
INFO - 2018-12-24 18:00:24 --> Form Validation Class Initialized
INFO - 2018-12-24 18:00:24 --> Email Class Initialized
DEBUG - 2018-12-24 18:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:00:24 --> Pagination Class Initialized
INFO - 2018-12-24 18:00:24 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:24 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:24 --> Controller Class Initialized
INFO - 2018-12-24 18:00:24 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 18:00:24 --> Final output sent to browser
DEBUG - 2018-12-24 18:00:24 --> Total execution time: 0.2084
INFO - 2018-12-24 18:00:26 --> Config Class Initialized
INFO - 2018-12-24 18:00:26 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:00:26 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:00:26 --> Utf8 Class Initialized
INFO - 2018-12-24 18:00:26 --> URI Class Initialized
INFO - 2018-12-24 18:00:26 --> Router Class Initialized
INFO - 2018-12-24 18:00:26 --> Output Class Initialized
INFO - 2018-12-24 18:00:26 --> Security Class Initialized
DEBUG - 2018-12-24 18:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:00:26 --> Input Class Initialized
INFO - 2018-12-24 18:00:26 --> Language Class Initialized
INFO - 2018-12-24 18:00:26 --> Loader Class Initialized
INFO - 2018-12-24 18:00:26 --> Helper loaded: url_helper
INFO - 2018-12-24 18:00:26 --> Helper loaded: html_helper
INFO - 2018-12-24 18:00:26 --> Helper loaded: form_helper
INFO - 2018-12-24 18:00:26 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:00:26 --> Helper loaded: date_helper
INFO - 2018-12-24 18:00:26 --> Form Validation Class Initialized
INFO - 2018-12-24 18:00:26 --> Email Class Initialized
DEBUG - 2018-12-24 18:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:00:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:00:26 --> Pagination Class Initialized
INFO - 2018-12-24 18:00:26 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:26 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:26 --> Controller Class Initialized
INFO - 2018-12-24 18:00:26 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-24 18:00:26 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-12-24 18:00:26 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/guest.php
INFO - 2018-12-24 18:00:26 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-24 18:00:26 --> Final output sent to browser
DEBUG - 2018-12-24 18:00:26 --> Total execution time: 0.2818
INFO - 2018-12-24 18:00:26 --> Config Class Initialized
INFO - 2018-12-24 18:00:26 --> Hooks Class Initialized
INFO - 2018-12-24 18:00:26 --> Config Class Initialized
INFO - 2018-12-24 18:00:26 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:00:26 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:00:26 --> Utf8 Class Initialized
DEBUG - 2018-12-24 18:00:26 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:00:26 --> Utf8 Class Initialized
INFO - 2018-12-24 18:00:26 --> URI Class Initialized
INFO - 2018-12-24 18:00:26 --> URI Class Initialized
INFO - 2018-12-24 18:00:26 --> Router Class Initialized
INFO - 2018-12-24 18:00:26 --> Router Class Initialized
INFO - 2018-12-24 18:00:26 --> Output Class Initialized
INFO - 2018-12-24 18:00:26 --> Output Class Initialized
INFO - 2018-12-24 18:00:26 --> Security Class Initialized
INFO - 2018-12-24 18:00:26 --> Security Class Initialized
DEBUG - 2018-12-24 18:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:00:26 --> Input Class Initialized
DEBUG - 2018-12-24 18:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:00:26 --> Input Class Initialized
INFO - 2018-12-24 18:00:26 --> Language Class Initialized
INFO - 2018-12-24 18:00:26 --> Language Class Initialized
INFO - 2018-12-24 18:00:26 --> Loader Class Initialized
INFO - 2018-12-24 18:00:26 --> Loader Class Initialized
INFO - 2018-12-24 18:00:26 --> Helper loaded: url_helper
INFO - 2018-12-24 18:00:26 --> Helper loaded: html_helper
INFO - 2018-12-24 18:00:26 --> Helper loaded: url_helper
INFO - 2018-12-24 18:00:26 --> Helper loaded: html_helper
INFO - 2018-12-24 18:00:26 --> Helper loaded: form_helper
INFO - 2018-12-24 18:00:26 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:00:26 --> Helper loaded: form_helper
INFO - 2018-12-24 18:00:26 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:00:26 --> Helper loaded: date_helper
INFO - 2018-12-24 18:00:26 --> Helper loaded: date_helper
INFO - 2018-12-24 18:00:26 --> Form Validation Class Initialized
INFO - 2018-12-24 18:00:26 --> Form Validation Class Initialized
INFO - 2018-12-24 18:00:26 --> Email Class Initialized
INFO - 2018-12-24 18:00:26 --> Email Class Initialized
DEBUG - 2018-12-24 18:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:00:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-24 18:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:00:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:00:26 --> Pagination Class Initialized
INFO - 2018-12-24 18:00:26 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:26 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:26 --> Controller Class Initialized
INFO - 2018-12-24 18:00:26 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 18:00:26 --> Final output sent to browser
DEBUG - 2018-12-24 18:00:26 --> Total execution time: 0.2205
INFO - 2018-12-24 18:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:00:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:00:26 --> Pagination Class Initialized
INFO - 2018-12-24 18:00:26 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:26 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:26 --> Controller Class Initialized
INFO - 2018-12-24 18:00:26 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 18:00:26 --> Final output sent to browser
DEBUG - 2018-12-24 18:00:26 --> Total execution time: 0.3157
INFO - 2018-12-24 18:00:45 --> Config Class Initialized
INFO - 2018-12-24 18:00:45 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:00:45 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:00:45 --> Utf8 Class Initialized
INFO - 2018-12-24 18:00:45 --> URI Class Initialized
INFO - 2018-12-24 18:00:45 --> Router Class Initialized
INFO - 2018-12-24 18:00:45 --> Output Class Initialized
INFO - 2018-12-24 18:00:45 --> Security Class Initialized
DEBUG - 2018-12-24 18:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:00:45 --> Input Class Initialized
INFO - 2018-12-24 18:00:45 --> Language Class Initialized
INFO - 2018-12-24 18:00:45 --> Loader Class Initialized
INFO - 2018-12-24 18:00:45 --> Helper loaded: url_helper
INFO - 2018-12-24 18:00:45 --> Helper loaded: html_helper
INFO - 2018-12-24 18:00:45 --> Helper loaded: form_helper
INFO - 2018-12-24 18:00:45 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:00:45 --> Helper loaded: date_helper
INFO - 2018-12-24 18:00:45 --> Form Validation Class Initialized
INFO - 2018-12-24 18:00:45 --> Email Class Initialized
DEBUG - 2018-12-24 18:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:00:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:00:45 --> Pagination Class Initialized
INFO - 2018-12-24 18:00:45 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:45 --> Database Driver Class Initialized
INFO - 2018-12-24 18:00:45 --> Controller Class Initialized
INFO - 2018-12-24 18:00:45 --> Final output sent to browser
DEBUG - 2018-12-24 18:00:45 --> Total execution time: 0.2517
INFO - 2018-12-24 18:01:04 --> Config Class Initialized
INFO - 2018-12-24 18:01:04 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:01:04 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:01:04 --> Utf8 Class Initialized
INFO - 2018-12-24 18:01:04 --> URI Class Initialized
INFO - 2018-12-24 18:01:04 --> Router Class Initialized
INFO - 2018-12-24 18:01:04 --> Output Class Initialized
INFO - 2018-12-24 18:01:04 --> Security Class Initialized
DEBUG - 2018-12-24 18:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:01:04 --> Input Class Initialized
INFO - 2018-12-24 18:01:04 --> Language Class Initialized
INFO - 2018-12-24 18:01:04 --> Loader Class Initialized
INFO - 2018-12-24 18:01:04 --> Helper loaded: url_helper
INFO - 2018-12-24 18:01:04 --> Helper loaded: html_helper
INFO - 2018-12-24 18:01:04 --> Helper loaded: form_helper
INFO - 2018-12-24 18:01:04 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:01:04 --> Helper loaded: date_helper
INFO - 2018-12-24 18:01:04 --> Form Validation Class Initialized
INFO - 2018-12-24 18:01:04 --> Email Class Initialized
DEBUG - 2018-12-24 18:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:01:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:01:04 --> Pagination Class Initialized
INFO - 2018-12-24 18:01:04 --> Database Driver Class Initialized
INFO - 2018-12-24 18:01:04 --> Database Driver Class Initialized
INFO - 2018-12-24 18:01:04 --> Controller Class Initialized
INFO - 2018-12-24 18:01:04 --> Final output sent to browser
DEBUG - 2018-12-24 18:01:04 --> Total execution time: 0.2392
INFO - 2018-12-24 18:01:23 --> Config Class Initialized
INFO - 2018-12-24 18:01:23 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:01:23 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:01:23 --> Utf8 Class Initialized
INFO - 2018-12-24 18:01:23 --> URI Class Initialized
INFO - 2018-12-24 18:01:23 --> Router Class Initialized
INFO - 2018-12-24 18:01:23 --> Output Class Initialized
INFO - 2018-12-24 18:01:23 --> Security Class Initialized
DEBUG - 2018-12-24 18:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:01:23 --> Input Class Initialized
INFO - 2018-12-24 18:01:23 --> Language Class Initialized
INFO - 2018-12-24 18:01:23 --> Loader Class Initialized
INFO - 2018-12-24 18:01:23 --> Helper loaded: url_helper
INFO - 2018-12-24 18:01:23 --> Helper loaded: html_helper
INFO - 2018-12-24 18:01:23 --> Helper loaded: form_helper
INFO - 2018-12-24 18:01:23 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:01:23 --> Helper loaded: date_helper
INFO - 2018-12-24 18:01:23 --> Form Validation Class Initialized
INFO - 2018-12-24 18:01:23 --> Email Class Initialized
DEBUG - 2018-12-24 18:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:01:23 --> Pagination Class Initialized
INFO - 2018-12-24 18:01:23 --> Database Driver Class Initialized
INFO - 2018-12-24 18:01:23 --> Database Driver Class Initialized
INFO - 2018-12-24 18:01:23 --> Controller Class Initialized
INFO - 2018-12-24 18:01:23 --> Final output sent to browser
DEBUG - 2018-12-24 18:01:23 --> Total execution time: 0.1499
INFO - 2018-12-24 18:01:45 --> Config Class Initialized
INFO - 2018-12-24 18:01:45 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:01:45 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:01:45 --> Utf8 Class Initialized
INFO - 2018-12-24 18:01:45 --> URI Class Initialized
INFO - 2018-12-24 18:01:45 --> Router Class Initialized
INFO - 2018-12-24 18:01:45 --> Output Class Initialized
INFO - 2018-12-24 18:01:45 --> Security Class Initialized
DEBUG - 2018-12-24 18:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:01:45 --> Input Class Initialized
INFO - 2018-12-24 18:01:45 --> Language Class Initialized
INFO - 2018-12-24 18:01:45 --> Loader Class Initialized
INFO - 2018-12-24 18:01:45 --> Helper loaded: url_helper
INFO - 2018-12-24 18:01:45 --> Helper loaded: html_helper
INFO - 2018-12-24 18:01:45 --> Helper loaded: form_helper
INFO - 2018-12-24 18:01:45 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:01:45 --> Helper loaded: date_helper
INFO - 2018-12-24 18:01:45 --> Form Validation Class Initialized
INFO - 2018-12-24 18:01:45 --> Email Class Initialized
DEBUG - 2018-12-24 18:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:01:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:01:45 --> Pagination Class Initialized
INFO - 2018-12-24 18:01:45 --> Database Driver Class Initialized
INFO - 2018-12-24 18:01:45 --> Database Driver Class Initialized
INFO - 2018-12-24 18:01:45 --> Controller Class Initialized
INFO - 2018-12-24 18:01:45 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-24 18:01:45 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2018-12-24 18:01:45 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/guest.php
INFO - 2018-12-24 18:01:45 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-24 18:01:45 --> Final output sent to browser
DEBUG - 2018-12-24 18:01:45 --> Total execution time: 0.2347
INFO - 2018-12-24 18:01:46 --> Config Class Initialized
INFO - 2018-12-24 18:01:46 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:01:46 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:01:46 --> Utf8 Class Initialized
INFO - 2018-12-24 18:01:46 --> Config Class Initialized
INFO - 2018-12-24 18:01:46 --> Hooks Class Initialized
INFO - 2018-12-24 18:01:46 --> URI Class Initialized
DEBUG - 2018-12-24 18:01:46 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:01:46 --> Router Class Initialized
INFO - 2018-12-24 18:01:46 --> Utf8 Class Initialized
INFO - 2018-12-24 18:01:46 --> URI Class Initialized
INFO - 2018-12-24 18:01:46 --> Output Class Initialized
INFO - 2018-12-24 18:01:46 --> Router Class Initialized
INFO - 2018-12-24 18:01:46 --> Security Class Initialized
DEBUG - 2018-12-24 18:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:01:46 --> Output Class Initialized
INFO - 2018-12-24 18:01:46 --> Input Class Initialized
INFO - 2018-12-24 18:01:46 --> Language Class Initialized
INFO - 2018-12-24 18:01:46 --> Security Class Initialized
DEBUG - 2018-12-24 18:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:01:46 --> Input Class Initialized
INFO - 2018-12-24 18:01:46 --> Language Class Initialized
INFO - 2018-12-24 18:01:46 --> Loader Class Initialized
INFO - 2018-12-24 18:01:46 --> Helper loaded: url_helper
INFO - 2018-12-24 18:01:46 --> Loader Class Initialized
INFO - 2018-12-24 18:01:46 --> Helper loaded: html_helper
INFO - 2018-12-24 18:01:46 --> Helper loaded: url_helper
INFO - 2018-12-24 18:01:46 --> Helper loaded: html_helper
INFO - 2018-12-24 18:01:46 --> Helper loaded: form_helper
INFO - 2018-12-24 18:01:46 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:01:46 --> Helper loaded: form_helper
INFO - 2018-12-24 18:01:46 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:01:46 --> Helper loaded: date_helper
INFO - 2018-12-24 18:01:46 --> Helper loaded: date_helper
INFO - 2018-12-24 18:01:46 --> Form Validation Class Initialized
INFO - 2018-12-24 18:01:46 --> Form Validation Class Initialized
INFO - 2018-12-24 18:01:46 --> Email Class Initialized
INFO - 2018-12-24 18:01:46 --> Email Class Initialized
DEBUG - 2018-12-24 18:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:01:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-12-24 18:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:01:46 --> Pagination Class Initialized
INFO - 2018-12-24 18:01:46 --> Database Driver Class Initialized
INFO - 2018-12-24 18:01:46 --> Database Driver Class Initialized
INFO - 2018-12-24 18:01:46 --> Controller Class Initialized
INFO - 2018-12-24 18:01:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 18:01:46 --> Final output sent to browser
DEBUG - 2018-12-24 18:01:46 --> Total execution time: 0.2532
INFO - 2018-12-24 18:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:01:46 --> Pagination Class Initialized
INFO - 2018-12-24 18:01:46 --> Database Driver Class Initialized
INFO - 2018-12-24 18:01:46 --> Database Driver Class Initialized
INFO - 2018-12-24 18:01:46 --> Controller Class Initialized
INFO - 2018-12-24 18:01:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 18:01:46 --> Final output sent to browser
DEBUG - 2018-12-24 18:01:46 --> Total execution time: 0.3315
INFO - 2018-12-24 18:03:13 --> Config Class Initialized
INFO - 2018-12-24 18:03:13 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:03:13 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:03:13 --> Utf8 Class Initialized
INFO - 2018-12-24 18:03:13 --> URI Class Initialized
INFO - 2018-12-24 18:03:13 --> Router Class Initialized
INFO - 2018-12-24 18:03:13 --> Output Class Initialized
INFO - 2018-12-24 18:03:13 --> Security Class Initialized
DEBUG - 2018-12-24 18:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:03:13 --> Input Class Initialized
INFO - 2018-12-24 18:03:13 --> Language Class Initialized
INFO - 2018-12-24 18:03:13 --> Loader Class Initialized
INFO - 2018-12-24 18:03:13 --> Helper loaded: url_helper
INFO - 2018-12-24 18:03:13 --> Helper loaded: html_helper
INFO - 2018-12-24 18:03:13 --> Helper loaded: form_helper
INFO - 2018-12-24 18:03:13 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:03:13 --> Helper loaded: date_helper
INFO - 2018-12-24 18:03:13 --> Form Validation Class Initialized
INFO - 2018-12-24 18:03:13 --> Email Class Initialized
DEBUG - 2018-12-24 18:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:03:13 --> Pagination Class Initialized
INFO - 2018-12-24 18:03:13 --> Database Driver Class Initialized
INFO - 2018-12-24 18:03:13 --> Database Driver Class Initialized
INFO - 2018-12-24 18:03:13 --> Controller Class Initialized
INFO - 2018-12-24 18:03:13 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 18:03:13 --> Final output sent to browser
DEBUG - 2018-12-24 18:03:13 --> Total execution time: 0.1905
INFO - 2018-12-24 18:03:14 --> Config Class Initialized
INFO - 2018-12-24 18:03:14 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:03:14 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:03:14 --> Utf8 Class Initialized
INFO - 2018-12-24 18:03:14 --> URI Class Initialized
INFO - 2018-12-24 18:03:14 --> Router Class Initialized
INFO - 2018-12-24 18:03:14 --> Output Class Initialized
INFO - 2018-12-24 18:03:14 --> Security Class Initialized
DEBUG - 2018-12-24 18:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:03:14 --> Input Class Initialized
INFO - 2018-12-24 18:03:14 --> Language Class Initialized
INFO - 2018-12-24 18:03:14 --> Loader Class Initialized
INFO - 2018-12-24 18:03:14 --> Helper loaded: url_helper
INFO - 2018-12-24 18:03:14 --> Helper loaded: html_helper
INFO - 2018-12-24 18:03:14 --> Helper loaded: form_helper
INFO - 2018-12-24 18:03:14 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:03:14 --> Helper loaded: date_helper
INFO - 2018-12-24 18:03:14 --> Form Validation Class Initialized
INFO - 2018-12-24 18:03:14 --> Email Class Initialized
DEBUG - 2018-12-24 18:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:03:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:03:14 --> Pagination Class Initialized
INFO - 2018-12-24 18:03:14 --> Database Driver Class Initialized
INFO - 2018-12-24 18:03:14 --> Database Driver Class Initialized
INFO - 2018-12-24 18:03:14 --> Controller Class Initialized
INFO - 2018-12-24 18:03:14 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2018-12-24 18:03:14 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/report.php
INFO - 2018-12-24 18:03:14 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2018-12-24 18:03:14 --> Final output sent to browser
DEBUG - 2018-12-24 18:03:14 --> Total execution time: 0.2008
INFO - 2018-12-24 18:03:15 --> Config Class Initialized
INFO - 2018-12-24 18:03:15 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:03:15 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:03:15 --> Utf8 Class Initialized
INFO - 2018-12-24 18:03:15 --> URI Class Initialized
INFO - 2018-12-24 18:03:15 --> Router Class Initialized
INFO - 2018-12-24 18:03:15 --> Output Class Initialized
INFO - 2018-12-24 18:03:15 --> Security Class Initialized
DEBUG - 2018-12-24 18:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:03:15 --> Input Class Initialized
INFO - 2018-12-24 18:03:15 --> Language Class Initialized
INFO - 2018-12-24 18:03:15 --> Loader Class Initialized
INFO - 2018-12-24 18:03:15 --> Helper loaded: url_helper
INFO - 2018-12-24 18:03:15 --> Helper loaded: html_helper
INFO - 2018-12-24 18:03:15 --> Helper loaded: form_helper
INFO - 2018-12-24 18:03:15 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:03:15 --> Helper loaded: date_helper
INFO - 2018-12-24 18:03:15 --> Form Validation Class Initialized
INFO - 2018-12-24 18:03:15 --> Email Class Initialized
DEBUG - 2018-12-24 18:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:03:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:03:15 --> Pagination Class Initialized
INFO - 2018-12-24 18:03:15 --> Database Driver Class Initialized
INFO - 2018-12-24 18:03:15 --> Database Driver Class Initialized
INFO - 2018-12-24 18:03:15 --> Controller Class Initialized
INFO - 2018-12-24 18:03:15 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 18:03:15 --> Final output sent to browser
DEBUG - 2018-12-24 18:03:15 --> Total execution time: 0.2159
INFO - 2018-12-24 18:03:24 --> Config Class Initialized
INFO - 2018-12-24 18:03:24 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:03:24 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:03:24 --> Utf8 Class Initialized
INFO - 2018-12-24 18:03:24 --> URI Class Initialized
INFO - 2018-12-24 18:03:24 --> Router Class Initialized
INFO - 2018-12-24 18:03:24 --> Output Class Initialized
INFO - 2018-12-24 18:03:24 --> Security Class Initialized
DEBUG - 2018-12-24 18:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:03:24 --> Input Class Initialized
INFO - 2018-12-24 18:03:24 --> Language Class Initialized
INFO - 2018-12-24 18:03:24 --> Loader Class Initialized
INFO - 2018-12-24 18:03:24 --> Helper loaded: url_helper
INFO - 2018-12-24 18:03:24 --> Helper loaded: html_helper
INFO - 2018-12-24 18:03:24 --> Helper loaded: form_helper
INFO - 2018-12-24 18:03:24 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:03:24 --> Helper loaded: date_helper
INFO - 2018-12-24 18:03:24 --> Form Validation Class Initialized
INFO - 2018-12-24 18:03:24 --> Email Class Initialized
DEBUG - 2018-12-24 18:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:03:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:03:24 --> Pagination Class Initialized
INFO - 2018-12-24 18:03:24 --> Database Driver Class Initialized
INFO - 2018-12-24 18:03:24 --> Database Driver Class Initialized
INFO - 2018-12-24 18:03:24 --> Controller Class Initialized
INFO - 2018-12-24 18:03:24 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 18:03:24 --> Final output sent to browser
DEBUG - 2018-12-24 18:03:24 --> Total execution time: 0.2116
INFO - 2018-12-24 18:03:24 --> Config Class Initialized
INFO - 2018-12-24 18:03:24 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:03:24 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:03:24 --> Utf8 Class Initialized
INFO - 2018-12-24 18:03:24 --> URI Class Initialized
INFO - 2018-12-24 18:03:24 --> Router Class Initialized
INFO - 2018-12-24 18:03:24 --> Output Class Initialized
INFO - 2018-12-24 18:03:24 --> Security Class Initialized
DEBUG - 2018-12-24 18:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:03:24 --> Input Class Initialized
INFO - 2018-12-24 18:03:24 --> Language Class Initialized
INFO - 2018-12-24 18:03:24 --> Loader Class Initialized
INFO - 2018-12-24 18:03:24 --> Helper loaded: url_helper
INFO - 2018-12-24 18:03:24 --> Helper loaded: html_helper
INFO - 2018-12-24 18:03:24 --> Helper loaded: form_helper
INFO - 2018-12-24 18:03:24 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:03:24 --> Helper loaded: date_helper
INFO - 2018-12-24 18:03:24 --> Form Validation Class Initialized
INFO - 2018-12-24 18:03:24 --> Email Class Initialized
DEBUG - 2018-12-24 18:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:03:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:03:24 --> Pagination Class Initialized
INFO - 2018-12-24 18:03:24 --> Database Driver Class Initialized
INFO - 2018-12-24 18:03:24 --> Database Driver Class Initialized
INFO - 2018-12-24 18:03:24 --> Controller Class Initialized
INFO - 2018-12-24 18:03:24 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 18:03:24 --> Final output sent to browser
DEBUG - 2018-12-24 18:03:24 --> Total execution time: 0.1658
INFO - 2018-12-24 18:03:30 --> Config Class Initialized
INFO - 2018-12-24 18:03:30 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:03:30 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:03:30 --> Utf8 Class Initialized
INFO - 2018-12-24 18:03:30 --> URI Class Initialized
INFO - 2018-12-24 18:03:30 --> Router Class Initialized
INFO - 2018-12-24 18:03:30 --> Output Class Initialized
INFO - 2018-12-24 18:03:30 --> Security Class Initialized
DEBUG - 2018-12-24 18:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:03:30 --> Input Class Initialized
INFO - 2018-12-24 18:03:30 --> Language Class Initialized
INFO - 2018-12-24 18:03:30 --> Loader Class Initialized
INFO - 2018-12-24 18:03:30 --> Helper loaded: url_helper
INFO - 2018-12-24 18:03:30 --> Helper loaded: html_helper
INFO - 2018-12-24 18:03:30 --> Helper loaded: form_helper
INFO - 2018-12-24 18:03:30 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:03:30 --> Helper loaded: date_helper
INFO - 2018-12-24 18:03:30 --> Form Validation Class Initialized
INFO - 2018-12-24 18:03:30 --> Email Class Initialized
DEBUG - 2018-12-24 18:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:03:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:03:30 --> Pagination Class Initialized
INFO - 2018-12-24 18:03:30 --> Database Driver Class Initialized
INFO - 2018-12-24 18:03:30 --> Database Driver Class Initialized
INFO - 2018-12-24 18:03:30 --> Controller Class Initialized
INFO - 2018-12-24 18:03:30 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-12-24 18:03:30 --> Final output sent to browser
DEBUG - 2018-12-24 18:03:30 --> Total execution time: 0.2123
INFO - 2018-12-24 18:04:41 --> Config Class Initialized
INFO - 2018-12-24 18:04:41 --> Hooks Class Initialized
DEBUG - 2018-12-24 18:04:41 --> UTF-8 Support Enabled
INFO - 2018-12-24 18:04:41 --> Utf8 Class Initialized
INFO - 2018-12-24 18:04:41 --> URI Class Initialized
INFO - 2018-12-24 18:04:41 --> Router Class Initialized
INFO - 2018-12-24 18:04:41 --> Output Class Initialized
INFO - 2018-12-24 18:04:41 --> Security Class Initialized
DEBUG - 2018-12-24 18:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 18:04:41 --> Input Class Initialized
INFO - 2018-12-24 18:04:41 --> Language Class Initialized
INFO - 2018-12-24 18:04:41 --> Loader Class Initialized
INFO - 2018-12-24 18:04:41 --> Helper loaded: url_helper
INFO - 2018-12-24 18:04:41 --> Helper loaded: html_helper
INFO - 2018-12-24 18:04:41 --> Helper loaded: form_helper
INFO - 2018-12-24 18:04:41 --> Helper loaded: cookie_helper
INFO - 2018-12-24 18:04:41 --> Helper loaded: date_helper
INFO - 2018-12-24 18:04:41 --> Form Validation Class Initialized
INFO - 2018-12-24 18:04:41 --> Email Class Initialized
DEBUG - 2018-12-24 18:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 18:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 18:04:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 18:04:41 --> Pagination Class Initialized
INFO - 2018-12-24 18:04:41 --> Database Driver Class Initialized
INFO - 2018-12-24 18:04:41 --> Database Driver Class Initialized
INFO - 2018-12-24 18:04:41 --> Controller Class Initialized
DEBUG - 2018-12-24 18:04:41 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2018-12-24 18:04:41 --> Helper loaded: inflector_helper
INFO - 2018-12-24 18:04:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-12-24 18:04:41 --> Final output sent to browser
DEBUG - 2018-12-24 18:04:41 --> Total execution time: 0.2850
INFO - 2018-12-24 19:44:42 --> Config Class Initialized
INFO - 2018-12-24 19:44:42 --> Hooks Class Initialized
DEBUG - 2018-12-24 19:44:42 --> UTF-8 Support Enabled
INFO - 2018-12-24 19:44:42 --> Utf8 Class Initialized
INFO - 2018-12-24 19:44:42 --> URI Class Initialized
INFO - 2018-12-24 19:44:42 --> Router Class Initialized
INFO - 2018-12-24 19:44:42 --> Output Class Initialized
INFO - 2018-12-24 19:44:42 --> Security Class Initialized
DEBUG - 2018-12-24 19:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 19:44:42 --> Input Class Initialized
INFO - 2018-12-24 19:44:42 --> Language Class Initialized
INFO - 2018-12-24 19:44:42 --> Loader Class Initialized
INFO - 2018-12-24 19:44:42 --> Helper loaded: url_helper
INFO - 2018-12-24 19:44:42 --> Helper loaded: html_helper
INFO - 2018-12-24 19:44:42 --> Helper loaded: form_helper
INFO - 2018-12-24 19:44:42 --> Helper loaded: cookie_helper
INFO - 2018-12-24 19:44:42 --> Helper loaded: date_helper
INFO - 2018-12-24 19:44:42 --> Form Validation Class Initialized
INFO - 2018-12-24 19:44:42 --> Email Class Initialized
DEBUG - 2018-12-24 19:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 19:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 19:44:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 19:44:42 --> Pagination Class Initialized
INFO - 2018-12-24 19:44:43 --> Database Driver Class Initialized
INFO - 2018-12-24 19:44:43 --> Database Driver Class Initialized
INFO - 2018-12-24 19:44:44 --> Controller Class Initialized
INFO - 2018-12-24 19:44:44 --> Config Class Initialized
INFO - 2018-12-24 19:44:44 --> Hooks Class Initialized
DEBUG - 2018-12-24 19:44:44 --> UTF-8 Support Enabled
INFO - 2018-12-24 19:44:44 --> Utf8 Class Initialized
INFO - 2018-12-24 19:44:44 --> URI Class Initialized
INFO - 2018-12-24 19:44:44 --> Router Class Initialized
INFO - 2018-12-24 19:44:44 --> Output Class Initialized
INFO - 2018-12-24 19:44:44 --> Security Class Initialized
DEBUG - 2018-12-24 19:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-24 19:44:44 --> Input Class Initialized
INFO - 2018-12-24 19:44:44 --> Language Class Initialized
INFO - 2018-12-24 19:44:44 --> Loader Class Initialized
INFO - 2018-12-24 19:44:44 --> Helper loaded: url_helper
INFO - 2018-12-24 19:44:44 --> Helper loaded: html_helper
INFO - 2018-12-24 19:44:44 --> Helper loaded: form_helper
INFO - 2018-12-24 19:44:44 --> Helper loaded: cookie_helper
INFO - 2018-12-24 19:44:44 --> Helper loaded: date_helper
INFO - 2018-12-24 19:44:44 --> Form Validation Class Initialized
INFO - 2018-12-24 19:44:44 --> Email Class Initialized
DEBUG - 2018-12-24 19:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-12-24 19:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-12-24 19:44:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-12-24 19:44:44 --> Pagination Class Initialized
INFO - 2018-12-24 19:44:44 --> Database Driver Class Initialized
INFO - 2018-12-24 19:44:44 --> Database Driver Class Initialized
INFO - 2018-12-24 19:44:44 --> Controller Class Initialized
INFO - 2018-12-24 19:44:45 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-12-24 19:44:45 --> Final output sent to browser
DEBUG - 2018-12-24 19:44:45 --> Total execution time: 0.4641
