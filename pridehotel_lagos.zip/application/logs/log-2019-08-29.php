<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-08-29 10:53:51 --> Config Class Initialized
INFO - 2019-08-29 10:53:51 --> Hooks Class Initialized
DEBUG - 2019-08-29 10:53:51 --> UTF-8 Support Enabled
INFO - 2019-08-29 10:53:51 --> Utf8 Class Initialized
INFO - 2019-08-29 10:53:51 --> URI Class Initialized
INFO - 2019-08-29 10:53:51 --> Router Class Initialized
INFO - 2019-08-29 10:53:51 --> Output Class Initialized
INFO - 2019-08-29 10:53:51 --> Security Class Initialized
DEBUG - 2019-08-29 10:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 10:53:51 --> Input Class Initialized
INFO - 2019-08-29 10:53:51 --> Language Class Initialized
INFO - 2019-08-29 10:53:51 --> Loader Class Initialized
INFO - 2019-08-29 10:53:51 --> Helper loaded: url_helper
INFO - 2019-08-29 10:53:51 --> Helper loaded: html_helper
INFO - 2019-08-29 10:53:51 --> Helper loaded: form_helper
INFO - 2019-08-29 10:53:51 --> Helper loaded: cookie_helper
INFO - 2019-08-29 10:53:51 --> Helper loaded: date_helper
INFO - 2019-08-29 10:53:51 --> Form Validation Class Initialized
INFO - 2019-08-29 10:53:51 --> Email Class Initialized
DEBUG - 2019-08-29 10:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 10:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 10:53:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 10:53:51 --> Pagination Class Initialized
INFO - 2019-08-29 10:53:51 --> Database Driver Class Initialized
INFO - 2019-08-29 10:53:51 --> Database Driver Class Initialized
INFO - 2019-08-29 10:53:51 --> Controller Class Initialized
INFO - 2019-08-29 10:53:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-08-29 10:53:51 --> Final output sent to browser
DEBUG - 2019-08-29 10:53:51 --> Total execution time: 0.4519
INFO - 2019-08-29 14:20:16 --> Config Class Initialized
INFO - 2019-08-29 14:20:16 --> Hooks Class Initialized
DEBUG - 2019-08-29 14:20:16 --> UTF-8 Support Enabled
INFO - 2019-08-29 14:20:16 --> Utf8 Class Initialized
INFO - 2019-08-29 14:20:16 --> URI Class Initialized
INFO - 2019-08-29 14:20:16 --> Router Class Initialized
INFO - 2019-08-29 14:20:16 --> Output Class Initialized
INFO - 2019-08-29 14:20:16 --> Security Class Initialized
DEBUG - 2019-08-29 14:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 14:20:16 --> Input Class Initialized
INFO - 2019-08-29 14:20:16 --> Language Class Initialized
INFO - 2019-08-29 14:20:16 --> Loader Class Initialized
INFO - 2019-08-29 14:20:16 --> Helper loaded: url_helper
INFO - 2019-08-29 14:20:16 --> Helper loaded: html_helper
INFO - 2019-08-29 14:20:16 --> Helper loaded: form_helper
INFO - 2019-08-29 14:20:16 --> Helper loaded: cookie_helper
INFO - 2019-08-29 14:20:16 --> Helper loaded: date_helper
INFO - 2019-08-29 14:20:16 --> Form Validation Class Initialized
INFO - 2019-08-29 14:20:16 --> Email Class Initialized
DEBUG - 2019-08-29 14:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 14:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 14:20:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 14:20:17 --> Pagination Class Initialized
INFO - 2019-08-29 14:20:17 --> Database Driver Class Initialized
INFO - 2019-08-29 14:20:17 --> Database Driver Class Initialized
INFO - 2019-08-29 14:20:17 --> Controller Class Initialized
INFO - 2019-08-29 14:20:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-29 14:20:17 --> Config Class Initialized
INFO - 2019-08-29 14:20:17 --> Hooks Class Initialized
DEBUG - 2019-08-29 14:20:17 --> UTF-8 Support Enabled
INFO - 2019-08-29 14:20:17 --> Utf8 Class Initialized
INFO - 2019-08-29 14:20:17 --> URI Class Initialized
INFO - 2019-08-29 14:20:17 --> Router Class Initialized
INFO - 2019-08-29 14:20:17 --> Output Class Initialized
INFO - 2019-08-29 14:20:17 --> Security Class Initialized
DEBUG - 2019-08-29 14:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 14:20:17 --> Input Class Initialized
INFO - 2019-08-29 14:20:17 --> Language Class Initialized
INFO - 2019-08-29 14:20:17 --> Loader Class Initialized
INFO - 2019-08-29 14:20:17 --> Helper loaded: url_helper
INFO - 2019-08-29 14:20:17 --> Helper loaded: html_helper
INFO - 2019-08-29 14:20:17 --> Helper loaded: form_helper
INFO - 2019-08-29 14:20:17 --> Helper loaded: cookie_helper
INFO - 2019-08-29 14:20:17 --> Helper loaded: date_helper
INFO - 2019-08-29 14:20:17 --> Form Validation Class Initialized
INFO - 2019-08-29 14:20:17 --> Email Class Initialized
DEBUG - 2019-08-29 14:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 14:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 14:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 14:20:17 --> Pagination Class Initialized
INFO - 2019-08-29 14:20:17 --> Database Driver Class Initialized
INFO - 2019-08-29 14:20:17 --> Database Driver Class Initialized
INFO - 2019-08-29 14:20:17 --> Controller Class Initialized
INFO - 2019-08-29 14:20:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-29 14:20:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-08-29 14:20:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-08-29 14:20:18 --> Final output sent to browser
DEBUG - 2019-08-29 14:20:18 --> Total execution time: 0.1518
INFO - 2019-08-29 14:20:18 --> Config Class Initialized
INFO - 2019-08-29 14:20:18 --> Hooks Class Initialized
INFO - 2019-08-29 14:20:18 --> Config Class Initialized
INFO - 2019-08-29 14:20:18 --> Hooks Class Initialized
DEBUG - 2019-08-29 14:20:18 --> UTF-8 Support Enabled
DEBUG - 2019-08-29 14:20:18 --> UTF-8 Support Enabled
INFO - 2019-08-29 14:20:18 --> Utf8 Class Initialized
INFO - 2019-08-29 14:20:18 --> Utf8 Class Initialized
INFO - 2019-08-29 14:20:18 --> URI Class Initialized
INFO - 2019-08-29 14:20:18 --> URI Class Initialized
INFO - 2019-08-29 14:20:18 --> Router Class Initialized
INFO - 2019-08-29 14:20:18 --> Router Class Initialized
INFO - 2019-08-29 14:20:18 --> Output Class Initialized
INFO - 2019-08-29 14:20:18 --> Output Class Initialized
INFO - 2019-08-29 14:20:18 --> Security Class Initialized
INFO - 2019-08-29 14:20:18 --> Security Class Initialized
DEBUG - 2019-08-29 14:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-29 14:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 14:20:18 --> Input Class Initialized
INFO - 2019-08-29 14:20:18 --> Input Class Initialized
INFO - 2019-08-29 14:20:18 --> Language Class Initialized
INFO - 2019-08-29 14:20:18 --> Language Class Initialized
INFO - 2019-08-29 14:20:18 --> Loader Class Initialized
INFO - 2019-08-29 14:20:18 --> Loader Class Initialized
INFO - 2019-08-29 14:20:18 --> Helper loaded: url_helper
INFO - 2019-08-29 14:20:18 --> Helper loaded: url_helper
INFO - 2019-08-29 14:20:18 --> Helper loaded: html_helper
INFO - 2019-08-29 14:20:18 --> Helper loaded: html_helper
INFO - 2019-08-29 14:20:18 --> Helper loaded: form_helper
INFO - 2019-08-29 14:20:18 --> Helper loaded: form_helper
INFO - 2019-08-29 14:20:18 --> Helper loaded: cookie_helper
INFO - 2019-08-29 14:20:18 --> Helper loaded: cookie_helper
INFO - 2019-08-29 14:20:18 --> Helper loaded: date_helper
INFO - 2019-08-29 14:20:18 --> Helper loaded: date_helper
INFO - 2019-08-29 14:20:18 --> Form Validation Class Initialized
INFO - 2019-08-29 14:20:18 --> Form Validation Class Initialized
INFO - 2019-08-29 14:20:18 --> Email Class Initialized
INFO - 2019-08-29 14:20:18 --> Email Class Initialized
DEBUG - 2019-08-29 14:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-29 14:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 14:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 14:20:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 14:20:18 --> Pagination Class Initialized
INFO - 2019-08-29 14:20:18 --> Database Driver Class Initialized
INFO - 2019-08-29 14:20:18 --> Database Driver Class Initialized
INFO - 2019-08-29 14:20:18 --> Controller Class Initialized
INFO - 2019-08-29 14:20:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 14:20:18 --> Final output sent to browser
DEBUG - 2019-08-29 14:20:18 --> Total execution time: 0.0784
INFO - 2019-08-29 14:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 14:20:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 14:20:18 --> Pagination Class Initialized
INFO - 2019-08-29 14:20:18 --> Database Driver Class Initialized
INFO - 2019-08-29 14:20:18 --> Database Driver Class Initialized
INFO - 2019-08-29 14:20:18 --> Controller Class Initialized
INFO - 2019-08-29 14:20:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 14:20:18 --> Final output sent to browser
DEBUG - 2019-08-29 14:20:18 --> Total execution time: 0.1103
INFO - 2019-08-29 14:21:10 --> Config Class Initialized
INFO - 2019-08-29 14:21:10 --> Hooks Class Initialized
DEBUG - 2019-08-29 14:21:10 --> UTF-8 Support Enabled
INFO - 2019-08-29 14:21:10 --> Utf8 Class Initialized
INFO - 2019-08-29 14:21:10 --> URI Class Initialized
INFO - 2019-08-29 14:21:10 --> Router Class Initialized
INFO - 2019-08-29 14:21:10 --> Output Class Initialized
INFO - 2019-08-29 14:21:10 --> Security Class Initialized
DEBUG - 2019-08-29 14:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 14:21:10 --> Input Class Initialized
INFO - 2019-08-29 14:21:10 --> Language Class Initialized
INFO - 2019-08-29 14:21:10 --> Loader Class Initialized
INFO - 2019-08-29 14:21:10 --> Helper loaded: url_helper
INFO - 2019-08-29 14:21:10 --> Helper loaded: html_helper
INFO - 2019-08-29 14:21:10 --> Helper loaded: form_helper
INFO - 2019-08-29 14:21:10 --> Helper loaded: cookie_helper
INFO - 2019-08-29 14:21:10 --> Helper loaded: date_helper
INFO - 2019-08-29 14:21:10 --> Form Validation Class Initialized
INFO - 2019-08-29 14:21:11 --> Email Class Initialized
DEBUG - 2019-08-29 14:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 14:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 14:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 14:21:11 --> Pagination Class Initialized
INFO - 2019-08-29 14:21:11 --> Database Driver Class Initialized
INFO - 2019-08-29 14:21:11 --> Database Driver Class Initialized
INFO - 2019-08-29 14:21:11 --> Controller Class Initialized
INFO - 2019-08-29 14:21:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 14:21:11 --> Final output sent to browser
DEBUG - 2019-08-29 14:21:11 --> Total execution time: 0.0704
INFO - 2019-08-29 14:21:14 --> Config Class Initialized
INFO - 2019-08-29 14:21:14 --> Hooks Class Initialized
DEBUG - 2019-08-29 14:21:14 --> UTF-8 Support Enabled
INFO - 2019-08-29 14:21:14 --> Utf8 Class Initialized
INFO - 2019-08-29 14:21:14 --> URI Class Initialized
INFO - 2019-08-29 14:21:14 --> Router Class Initialized
INFO - 2019-08-29 14:21:14 --> Output Class Initialized
INFO - 2019-08-29 14:21:14 --> Security Class Initialized
DEBUG - 2019-08-29 14:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 14:21:14 --> Input Class Initialized
INFO - 2019-08-29 14:21:14 --> Language Class Initialized
INFO - 2019-08-29 14:21:14 --> Loader Class Initialized
INFO - 2019-08-29 14:21:14 --> Helper loaded: url_helper
INFO - 2019-08-29 14:21:14 --> Helper loaded: html_helper
INFO - 2019-08-29 14:21:14 --> Helper loaded: form_helper
INFO - 2019-08-29 14:21:14 --> Helper loaded: cookie_helper
INFO - 2019-08-29 14:21:14 --> Helper loaded: date_helper
INFO - 2019-08-29 14:21:14 --> Form Validation Class Initialized
INFO - 2019-08-29 14:21:14 --> Email Class Initialized
DEBUG - 2019-08-29 14:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 14:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 14:21:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 14:21:14 --> Pagination Class Initialized
INFO - 2019-08-29 14:21:14 --> Database Driver Class Initialized
INFO - 2019-08-29 14:21:14 --> Database Driver Class Initialized
INFO - 2019-08-29 14:21:14 --> Controller Class Initialized
INFO - 2019-08-29 14:21:14 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 14:21:14 --> Final output sent to browser
DEBUG - 2019-08-29 14:21:14 --> Total execution time: 0.0627
INFO - 2019-08-29 14:21:18 --> Config Class Initialized
INFO - 2019-08-29 14:21:18 --> Hooks Class Initialized
DEBUG - 2019-08-29 14:21:18 --> UTF-8 Support Enabled
INFO - 2019-08-29 14:21:18 --> Utf8 Class Initialized
INFO - 2019-08-29 14:21:18 --> URI Class Initialized
INFO - 2019-08-29 14:21:18 --> Router Class Initialized
INFO - 2019-08-29 14:21:18 --> Output Class Initialized
INFO - 2019-08-29 14:21:18 --> Security Class Initialized
DEBUG - 2019-08-29 14:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 14:21:18 --> Input Class Initialized
INFO - 2019-08-29 14:21:18 --> Language Class Initialized
INFO - 2019-08-29 14:21:18 --> Loader Class Initialized
INFO - 2019-08-29 14:21:18 --> Helper loaded: url_helper
INFO - 2019-08-29 14:21:18 --> Helper loaded: html_helper
INFO - 2019-08-29 14:21:18 --> Helper loaded: form_helper
INFO - 2019-08-29 14:21:18 --> Helper loaded: cookie_helper
INFO - 2019-08-29 14:21:18 --> Helper loaded: date_helper
INFO - 2019-08-29 14:21:18 --> Form Validation Class Initialized
INFO - 2019-08-29 14:21:18 --> Email Class Initialized
DEBUG - 2019-08-29 14:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 14:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 14:21:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 14:21:18 --> Pagination Class Initialized
INFO - 2019-08-29 14:21:18 --> Database Driver Class Initialized
INFO - 2019-08-29 14:21:18 --> Database Driver Class Initialized
INFO - 2019-08-29 14:21:18 --> Controller Class Initialized
INFO - 2019-08-29 14:21:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-29 14:21:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/nightaudit.php
INFO - 2019-08-29 14:21:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-08-29 14:21:18 --> Final output sent to browser
DEBUG - 2019-08-29 14:21:18 --> Total execution time: 0.0761
INFO - 2019-08-29 14:21:19 --> Config Class Initialized
INFO - 2019-08-29 14:21:19 --> Hooks Class Initialized
DEBUG - 2019-08-29 14:21:19 --> UTF-8 Support Enabled
INFO - 2019-08-29 14:21:19 --> Utf8 Class Initialized
INFO - 2019-08-29 14:21:19 --> URI Class Initialized
INFO - 2019-08-29 14:21:19 --> Router Class Initialized
INFO - 2019-08-29 14:21:19 --> Output Class Initialized
INFO - 2019-08-29 14:21:19 --> Security Class Initialized
DEBUG - 2019-08-29 14:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 14:21:19 --> Input Class Initialized
INFO - 2019-08-29 14:21:19 --> Language Class Initialized
INFO - 2019-08-29 14:21:19 --> Loader Class Initialized
INFO - 2019-08-29 14:21:19 --> Helper loaded: url_helper
INFO - 2019-08-29 14:21:19 --> Helper loaded: html_helper
INFO - 2019-08-29 14:21:19 --> Helper loaded: form_helper
INFO - 2019-08-29 14:21:19 --> Helper loaded: cookie_helper
INFO - 2019-08-29 14:21:19 --> Helper loaded: date_helper
INFO - 2019-08-29 14:21:19 --> Form Validation Class Initialized
INFO - 2019-08-29 14:21:19 --> Email Class Initialized
DEBUG - 2019-08-29 14:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 14:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 14:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 14:21:19 --> Pagination Class Initialized
INFO - 2019-08-29 14:21:19 --> Database Driver Class Initialized
INFO - 2019-08-29 14:21:19 --> Database Driver Class Initialized
INFO - 2019-08-29 14:21:19 --> Controller Class Initialized
INFO - 2019-08-29 14:21:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 14:21:19 --> Final output sent to browser
DEBUG - 2019-08-29 14:21:19 --> Total execution time: 0.0729
INFO - 2019-08-29 14:21:19 --> Config Class Initialized
INFO - 2019-08-29 14:21:19 --> Hooks Class Initialized
DEBUG - 2019-08-29 14:21:19 --> UTF-8 Support Enabled
INFO - 2019-08-29 14:21:19 --> Utf8 Class Initialized
INFO - 2019-08-29 14:21:19 --> URI Class Initialized
INFO - 2019-08-29 14:21:19 --> Router Class Initialized
INFO - 2019-08-29 14:21:19 --> Output Class Initialized
INFO - 2019-08-29 14:21:19 --> Security Class Initialized
DEBUG - 2019-08-29 14:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 14:21:19 --> Input Class Initialized
INFO - 2019-08-29 14:21:19 --> Language Class Initialized
INFO - 2019-08-29 14:21:19 --> Loader Class Initialized
INFO - 2019-08-29 14:21:19 --> Helper loaded: url_helper
INFO - 2019-08-29 14:21:19 --> Helper loaded: html_helper
INFO - 2019-08-29 14:21:19 --> Helper loaded: form_helper
INFO - 2019-08-29 14:21:19 --> Helper loaded: cookie_helper
INFO - 2019-08-29 14:21:19 --> Helper loaded: date_helper
INFO - 2019-08-29 14:21:19 --> Form Validation Class Initialized
INFO - 2019-08-29 14:21:19 --> Email Class Initialized
DEBUG - 2019-08-29 14:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 14:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 14:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 14:21:19 --> Pagination Class Initialized
INFO - 2019-08-29 14:21:19 --> Database Driver Class Initialized
INFO - 2019-08-29 14:21:19 --> Database Driver Class Initialized
INFO - 2019-08-29 14:21:19 --> Controller Class Initialized
INFO - 2019-08-29 14:21:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 14:21:19 --> Final output sent to browser
DEBUG - 2019-08-29 14:21:19 --> Total execution time: 0.0635
INFO - 2019-08-29 14:21:30 --> Config Class Initialized
INFO - 2019-08-29 14:21:30 --> Hooks Class Initialized
DEBUG - 2019-08-29 14:21:30 --> UTF-8 Support Enabled
INFO - 2019-08-29 14:21:30 --> Utf8 Class Initialized
INFO - 2019-08-29 14:21:30 --> URI Class Initialized
INFO - 2019-08-29 14:21:30 --> Router Class Initialized
INFO - 2019-08-29 14:21:30 --> Output Class Initialized
INFO - 2019-08-29 14:21:30 --> Security Class Initialized
DEBUG - 2019-08-29 14:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 14:21:30 --> Input Class Initialized
INFO - 2019-08-29 14:21:30 --> Language Class Initialized
INFO - 2019-08-29 14:21:30 --> Loader Class Initialized
INFO - 2019-08-29 14:21:30 --> Helper loaded: url_helper
INFO - 2019-08-29 14:21:31 --> Helper loaded: html_helper
INFO - 2019-08-29 14:21:31 --> Helper loaded: form_helper
INFO - 2019-08-29 14:21:31 --> Helper loaded: cookie_helper
INFO - 2019-08-29 14:21:31 --> Helper loaded: date_helper
INFO - 2019-08-29 14:21:31 --> Form Validation Class Initialized
INFO - 2019-08-29 14:21:31 --> Email Class Initialized
DEBUG - 2019-08-29 14:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 14:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 14:21:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 14:21:31 --> Pagination Class Initialized
INFO - 2019-08-29 14:21:31 --> Database Driver Class Initialized
INFO - 2019-08-29 14:21:31 --> Database Driver Class Initialized
INFO - 2019-08-29 14:21:31 --> Controller Class Initialized
INFO - 2019-08-29 14:21:31 --> Final output sent to browser
DEBUG - 2019-08-29 14:21:31 --> Total execution time: 0.1569
INFO - 2019-08-29 14:49:47 --> Config Class Initialized
INFO - 2019-08-29 14:49:47 --> Hooks Class Initialized
DEBUG - 2019-08-29 14:49:47 --> UTF-8 Support Enabled
INFO - 2019-08-29 14:49:47 --> Utf8 Class Initialized
INFO - 2019-08-29 14:49:47 --> URI Class Initialized
INFO - 2019-08-29 14:49:47 --> Router Class Initialized
INFO - 2019-08-29 14:49:47 --> Output Class Initialized
INFO - 2019-08-29 14:49:47 --> Security Class Initialized
DEBUG - 2019-08-29 14:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 14:49:47 --> Input Class Initialized
INFO - 2019-08-29 14:49:47 --> Language Class Initialized
INFO - 2019-08-29 14:49:47 --> Loader Class Initialized
INFO - 2019-08-29 14:49:47 --> Helper loaded: url_helper
INFO - 2019-08-29 14:49:47 --> Helper loaded: html_helper
INFO - 2019-08-29 14:49:47 --> Helper loaded: form_helper
INFO - 2019-08-29 14:49:47 --> Helper loaded: cookie_helper
INFO - 2019-08-29 14:49:47 --> Helper loaded: date_helper
INFO - 2019-08-29 14:49:47 --> Form Validation Class Initialized
INFO - 2019-08-29 14:49:47 --> Email Class Initialized
DEBUG - 2019-08-29 14:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 14:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 14:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 14:49:47 --> Pagination Class Initialized
INFO - 2019-08-29 14:49:47 --> Database Driver Class Initialized
INFO - 2019-08-29 14:49:47 --> Database Driver Class Initialized
INFO - 2019-08-29 14:49:47 --> Controller Class Initialized
INFO - 2019-08-29 14:49:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-29 14:49:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/nightaudit.php
INFO - 2019-08-29 14:49:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-08-29 14:49:47 --> Final output sent to browser
DEBUG - 2019-08-29 14:49:47 --> Total execution time: 0.1697
INFO - 2019-08-29 14:49:47 --> Config Class Initialized
INFO - 2019-08-29 14:49:47 --> Hooks Class Initialized
DEBUG - 2019-08-29 14:49:47 --> UTF-8 Support Enabled
INFO - 2019-08-29 14:49:47 --> Utf8 Class Initialized
INFO - 2019-08-29 14:49:47 --> URI Class Initialized
INFO - 2019-08-29 14:49:47 --> Router Class Initialized
INFO - 2019-08-29 14:49:47 --> Output Class Initialized
INFO - 2019-08-29 14:49:47 --> Security Class Initialized
DEBUG - 2019-08-29 14:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 14:49:47 --> Input Class Initialized
INFO - 2019-08-29 14:49:47 --> Language Class Initialized
INFO - 2019-08-29 14:49:47 --> Loader Class Initialized
INFO - 2019-08-29 14:49:47 --> Helper loaded: url_helper
INFO - 2019-08-29 14:49:47 --> Helper loaded: html_helper
INFO - 2019-08-29 14:49:47 --> Helper loaded: form_helper
INFO - 2019-08-29 14:49:47 --> Helper loaded: cookie_helper
INFO - 2019-08-29 14:49:47 --> Helper loaded: date_helper
INFO - 2019-08-29 14:49:47 --> Form Validation Class Initialized
INFO - 2019-08-29 14:49:47 --> Email Class Initialized
DEBUG - 2019-08-29 14:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 14:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 14:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 14:49:47 --> Pagination Class Initialized
INFO - 2019-08-29 14:49:47 --> Database Driver Class Initialized
INFO - 2019-08-29 14:49:47 --> Database Driver Class Initialized
INFO - 2019-08-29 14:49:47 --> Controller Class Initialized
INFO - 2019-08-29 14:49:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 14:49:47 --> Final output sent to browser
DEBUG - 2019-08-29 14:49:47 --> Total execution time: 0.1001
INFO - 2019-08-29 14:49:52 --> Config Class Initialized
INFO - 2019-08-29 14:49:52 --> Hooks Class Initialized
DEBUG - 2019-08-29 14:49:52 --> UTF-8 Support Enabled
INFO - 2019-08-29 14:49:52 --> Utf8 Class Initialized
INFO - 2019-08-29 14:49:52 --> URI Class Initialized
INFO - 2019-08-29 14:49:52 --> Router Class Initialized
INFO - 2019-08-29 14:49:52 --> Output Class Initialized
INFO - 2019-08-29 14:49:52 --> Security Class Initialized
DEBUG - 2019-08-29 14:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 14:49:52 --> Input Class Initialized
INFO - 2019-08-29 14:49:52 --> Language Class Initialized
INFO - 2019-08-29 14:49:52 --> Loader Class Initialized
INFO - 2019-08-29 14:49:52 --> Helper loaded: url_helper
INFO - 2019-08-29 14:49:52 --> Helper loaded: html_helper
INFO - 2019-08-29 14:49:52 --> Helper loaded: form_helper
INFO - 2019-08-29 14:49:52 --> Helper loaded: cookie_helper
INFO - 2019-08-29 14:49:52 --> Helper loaded: date_helper
INFO - 2019-08-29 14:49:52 --> Form Validation Class Initialized
INFO - 2019-08-29 14:49:52 --> Email Class Initialized
DEBUG - 2019-08-29 14:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 14:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 14:49:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 14:49:52 --> Pagination Class Initialized
INFO - 2019-08-29 14:49:52 --> Database Driver Class Initialized
INFO - 2019-08-29 14:49:52 --> Database Driver Class Initialized
INFO - 2019-08-29 14:49:52 --> Controller Class Initialized
INFO - 2019-08-29 14:49:54 --> Final output sent to browser
DEBUG - 2019-08-29 14:49:54 --> Total execution time: 1.3682
INFO - 2019-08-29 14:49:56 --> Config Class Initialized
INFO - 2019-08-29 14:49:56 --> Hooks Class Initialized
DEBUG - 2019-08-29 14:49:56 --> UTF-8 Support Enabled
INFO - 2019-08-29 14:49:56 --> Utf8 Class Initialized
INFO - 2019-08-29 14:49:56 --> URI Class Initialized
INFO - 2019-08-29 14:49:56 --> Router Class Initialized
INFO - 2019-08-29 14:49:56 --> Output Class Initialized
INFO - 2019-08-29 14:49:56 --> Security Class Initialized
DEBUG - 2019-08-29 14:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 14:49:56 --> Input Class Initialized
INFO - 2019-08-29 14:49:56 --> Language Class Initialized
INFO - 2019-08-29 14:49:56 --> Loader Class Initialized
INFO - 2019-08-29 14:49:56 --> Helper loaded: url_helper
INFO - 2019-08-29 14:49:56 --> Helper loaded: html_helper
INFO - 2019-08-29 14:49:56 --> Helper loaded: form_helper
INFO - 2019-08-29 14:49:56 --> Helper loaded: cookie_helper
INFO - 2019-08-29 14:49:56 --> Helper loaded: date_helper
INFO - 2019-08-29 14:49:56 --> Form Validation Class Initialized
INFO - 2019-08-29 14:49:56 --> Email Class Initialized
DEBUG - 2019-08-29 14:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 14:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 14:49:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 14:49:56 --> Pagination Class Initialized
INFO - 2019-08-29 14:49:56 --> Database Driver Class Initialized
INFO - 2019-08-29 14:49:56 --> Database Driver Class Initialized
INFO - 2019-08-29 14:49:56 --> Controller Class Initialized
INFO - 2019-08-29 14:49:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-29 14:49:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/nightaudit.php
INFO - 2019-08-29 14:49:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-08-29 14:49:56 --> Final output sent to browser
DEBUG - 2019-08-29 14:49:56 --> Total execution time: 0.0631
INFO - 2019-08-29 14:49:56 --> Config Class Initialized
INFO - 2019-08-29 14:49:56 --> Hooks Class Initialized
DEBUG - 2019-08-29 14:49:56 --> UTF-8 Support Enabled
INFO - 2019-08-29 14:49:56 --> Utf8 Class Initialized
INFO - 2019-08-29 14:49:56 --> URI Class Initialized
INFO - 2019-08-29 14:49:56 --> Router Class Initialized
INFO - 2019-08-29 14:49:56 --> Output Class Initialized
INFO - 2019-08-29 14:49:56 --> Security Class Initialized
DEBUG - 2019-08-29 14:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 14:49:56 --> Input Class Initialized
INFO - 2019-08-29 14:49:56 --> Language Class Initialized
INFO - 2019-08-29 14:49:56 --> Loader Class Initialized
INFO - 2019-08-29 14:49:56 --> Helper loaded: url_helper
INFO - 2019-08-29 14:49:56 --> Helper loaded: html_helper
INFO - 2019-08-29 14:49:56 --> Helper loaded: form_helper
INFO - 2019-08-29 14:49:56 --> Helper loaded: cookie_helper
INFO - 2019-08-29 14:49:56 --> Helper loaded: date_helper
INFO - 2019-08-29 14:49:56 --> Form Validation Class Initialized
INFO - 2019-08-29 14:49:56 --> Email Class Initialized
DEBUG - 2019-08-29 14:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 14:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 14:49:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 14:49:56 --> Pagination Class Initialized
INFO - 2019-08-29 14:49:56 --> Database Driver Class Initialized
INFO - 2019-08-29 14:49:56 --> Database Driver Class Initialized
INFO - 2019-08-29 14:49:56 --> Controller Class Initialized
INFO - 2019-08-29 14:49:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 14:49:56 --> Final output sent to browser
DEBUG - 2019-08-29 14:49:56 --> Total execution time: 0.0610
INFO - 2019-08-29 14:49:58 --> Config Class Initialized
INFO - 2019-08-29 14:49:58 --> Hooks Class Initialized
DEBUG - 2019-08-29 14:49:58 --> UTF-8 Support Enabled
INFO - 2019-08-29 14:49:58 --> Utf8 Class Initialized
INFO - 2019-08-29 14:49:58 --> URI Class Initialized
INFO - 2019-08-29 14:49:58 --> Router Class Initialized
INFO - 2019-08-29 14:49:58 --> Output Class Initialized
INFO - 2019-08-29 14:49:58 --> Security Class Initialized
DEBUG - 2019-08-29 14:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 14:49:58 --> Input Class Initialized
INFO - 2019-08-29 14:49:58 --> Language Class Initialized
INFO - 2019-08-29 14:49:58 --> Loader Class Initialized
INFO - 2019-08-29 14:49:58 --> Helper loaded: url_helper
INFO - 2019-08-29 14:49:58 --> Helper loaded: html_helper
INFO - 2019-08-29 14:49:58 --> Helper loaded: form_helper
INFO - 2019-08-29 14:49:58 --> Helper loaded: cookie_helper
INFO - 2019-08-29 14:49:58 --> Helper loaded: date_helper
INFO - 2019-08-29 14:49:58 --> Form Validation Class Initialized
INFO - 2019-08-29 14:49:58 --> Email Class Initialized
DEBUG - 2019-08-29 14:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 14:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 14:49:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 14:49:58 --> Pagination Class Initialized
INFO - 2019-08-29 14:49:58 --> Database Driver Class Initialized
INFO - 2019-08-29 14:49:58 --> Database Driver Class Initialized
INFO - 2019-08-29 14:49:58 --> Controller Class Initialized
INFO - 2019-08-29 14:49:58 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 14:49:58 --> Final output sent to browser
DEBUG - 2019-08-29 14:49:58 --> Total execution time: 0.0612
INFO - 2019-08-29 16:39:28 --> Config Class Initialized
INFO - 2019-08-29 16:39:28 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:39:28 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:39:28 --> Utf8 Class Initialized
INFO - 2019-08-29 16:39:28 --> URI Class Initialized
INFO - 2019-08-29 16:39:28 --> Router Class Initialized
INFO - 2019-08-29 16:39:29 --> Output Class Initialized
INFO - 2019-08-29 16:39:29 --> Security Class Initialized
DEBUG - 2019-08-29 16:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:39:29 --> Input Class Initialized
INFO - 2019-08-29 16:39:29 --> Language Class Initialized
INFO - 2019-08-29 16:39:29 --> Loader Class Initialized
INFO - 2019-08-29 16:39:29 --> Helper loaded: url_helper
INFO - 2019-08-29 16:39:29 --> Helper loaded: html_helper
INFO - 2019-08-29 16:39:29 --> Helper loaded: form_helper
INFO - 2019-08-29 16:39:29 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:39:29 --> Helper loaded: date_helper
INFO - 2019-08-29 16:39:29 --> Form Validation Class Initialized
INFO - 2019-08-29 16:39:29 --> Email Class Initialized
DEBUG - 2019-08-29 16:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:39:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:39:29 --> Pagination Class Initialized
INFO - 2019-08-29 16:39:30 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:30 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:30 --> Controller Class Initialized
INFO - 2019-08-29 16:39:30 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 16:39:30 --> Final output sent to browser
DEBUG - 2019-08-29 16:39:30 --> Total execution time: 1.5171
INFO - 2019-08-29 16:39:33 --> Config Class Initialized
INFO - 2019-08-29 16:39:33 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:39:33 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:39:33 --> Utf8 Class Initialized
INFO - 2019-08-29 16:39:33 --> URI Class Initialized
INFO - 2019-08-29 16:39:33 --> Router Class Initialized
INFO - 2019-08-29 16:39:33 --> Output Class Initialized
INFO - 2019-08-29 16:39:33 --> Security Class Initialized
DEBUG - 2019-08-29 16:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:39:33 --> Input Class Initialized
INFO - 2019-08-29 16:39:33 --> Language Class Initialized
INFO - 2019-08-29 16:39:33 --> Loader Class Initialized
INFO - 2019-08-29 16:39:33 --> Helper loaded: url_helper
INFO - 2019-08-29 16:39:33 --> Helper loaded: html_helper
INFO - 2019-08-29 16:39:33 --> Helper loaded: form_helper
INFO - 2019-08-29 16:39:33 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:39:33 --> Helper loaded: date_helper
INFO - 2019-08-29 16:39:33 --> Form Validation Class Initialized
INFO - 2019-08-29 16:39:33 --> Email Class Initialized
DEBUG - 2019-08-29 16:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:39:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:39:33 --> Pagination Class Initialized
INFO - 2019-08-29 16:39:33 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:33 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:33 --> Controller Class Initialized
INFO - 2019-08-29 16:39:33 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-29 16:39:33 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-08-29 16:39:33 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-08-29 16:39:33 --> Final output sent to browser
DEBUG - 2019-08-29 16:39:33 --> Total execution time: 0.1550
INFO - 2019-08-29 16:39:34 --> Config Class Initialized
INFO - 2019-08-29 16:39:34 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:39:34 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:39:34 --> Utf8 Class Initialized
INFO - 2019-08-29 16:39:34 --> URI Class Initialized
INFO - 2019-08-29 16:39:34 --> Config Class Initialized
INFO - 2019-08-29 16:39:34 --> Hooks Class Initialized
INFO - 2019-08-29 16:39:34 --> Router Class Initialized
INFO - 2019-08-29 16:39:34 --> Output Class Initialized
INFO - 2019-08-29 16:39:34 --> Security Class Initialized
DEBUG - 2019-08-29 16:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:39:34 --> Input Class Initialized
INFO - 2019-08-29 16:39:34 --> Language Class Initialized
INFO - 2019-08-29 16:39:34 --> Loader Class Initialized
INFO - 2019-08-29 16:39:34 --> Helper loaded: url_helper
INFO - 2019-08-29 16:39:34 --> Helper loaded: html_helper
INFO - 2019-08-29 16:39:34 --> Helper loaded: form_helper
INFO - 2019-08-29 16:39:34 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:39:34 --> Helper loaded: date_helper
INFO - 2019-08-29 16:39:34 --> Form Validation Class Initialized
INFO - 2019-08-29 16:39:34 --> Email Class Initialized
DEBUG - 2019-08-29 16:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:39:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:39:34 --> Pagination Class Initialized
INFO - 2019-08-29 16:39:34 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:34 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:34 --> Controller Class Initialized
INFO - 2019-08-29 16:39:34 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 16:39:34 --> Final output sent to browser
DEBUG - 2019-08-29 16:39:34 --> Total execution time: 0.0625
DEBUG - 2019-08-29 16:39:34 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:39:34 --> Utf8 Class Initialized
INFO - 2019-08-29 16:39:34 --> URI Class Initialized
INFO - 2019-08-29 16:39:34 --> Router Class Initialized
INFO - 2019-08-29 16:39:34 --> Output Class Initialized
INFO - 2019-08-29 16:39:34 --> Security Class Initialized
DEBUG - 2019-08-29 16:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:39:34 --> Input Class Initialized
INFO - 2019-08-29 16:39:34 --> Language Class Initialized
INFO - 2019-08-29 16:39:34 --> Loader Class Initialized
INFO - 2019-08-29 16:39:34 --> Helper loaded: url_helper
INFO - 2019-08-29 16:39:34 --> Helper loaded: html_helper
INFO - 2019-08-29 16:39:34 --> Helper loaded: form_helper
INFO - 2019-08-29 16:39:34 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:39:34 --> Helper loaded: date_helper
INFO - 2019-08-29 16:39:34 --> Form Validation Class Initialized
INFO - 2019-08-29 16:39:34 --> Email Class Initialized
DEBUG - 2019-08-29 16:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:39:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:39:34 --> Pagination Class Initialized
INFO - 2019-08-29 16:39:34 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:34 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:34 --> Controller Class Initialized
INFO - 2019-08-29 16:39:34 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 16:39:34 --> Final output sent to browser
DEBUG - 2019-08-29 16:39:34 --> Total execution time: 0.1769
INFO - 2019-08-29 16:39:38 --> Config Class Initialized
INFO - 2019-08-29 16:39:38 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:39:38 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:39:38 --> Utf8 Class Initialized
INFO - 2019-08-29 16:39:38 --> URI Class Initialized
INFO - 2019-08-29 16:39:38 --> Router Class Initialized
INFO - 2019-08-29 16:39:38 --> Output Class Initialized
INFO - 2019-08-29 16:39:38 --> Security Class Initialized
DEBUG - 2019-08-29 16:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:39:38 --> Input Class Initialized
INFO - 2019-08-29 16:39:38 --> Language Class Initialized
INFO - 2019-08-29 16:39:38 --> Loader Class Initialized
INFO - 2019-08-29 16:39:38 --> Helper loaded: url_helper
INFO - 2019-08-29 16:39:38 --> Helper loaded: html_helper
INFO - 2019-08-29 16:39:38 --> Helper loaded: form_helper
INFO - 2019-08-29 16:39:38 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:39:38 --> Helper loaded: date_helper
INFO - 2019-08-29 16:39:38 --> Form Validation Class Initialized
INFO - 2019-08-29 16:39:38 --> Email Class Initialized
DEBUG - 2019-08-29 16:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:39:38 --> Pagination Class Initialized
INFO - 2019-08-29 16:39:38 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:38 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:38 --> Controller Class Initialized
INFO - 2019-08-29 16:39:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-29 16:39:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-08-29 16:39:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-08-29 16:39:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-08-29 16:39:38 --> Final output sent to browser
DEBUG - 2019-08-29 16:39:38 --> Total execution time: 0.2315
INFO - 2019-08-29 16:39:38 --> Config Class Initialized
INFO - 2019-08-29 16:39:38 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:39:38 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:39:38 --> Utf8 Class Initialized
INFO - 2019-08-29 16:39:38 --> URI Class Initialized
INFO - 2019-08-29 16:39:38 --> Router Class Initialized
INFO - 2019-08-29 16:39:38 --> Output Class Initialized
INFO - 2019-08-29 16:39:38 --> Security Class Initialized
DEBUG - 2019-08-29 16:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:39:38 --> Input Class Initialized
INFO - 2019-08-29 16:39:38 --> Language Class Initialized
INFO - 2019-08-29 16:39:38 --> Config Class Initialized
INFO - 2019-08-29 16:39:38 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:39:38 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:39:38 --> Utf8 Class Initialized
INFO - 2019-08-29 16:39:38 --> Loader Class Initialized
INFO - 2019-08-29 16:39:38 --> URI Class Initialized
INFO - 2019-08-29 16:39:38 --> Helper loaded: url_helper
INFO - 2019-08-29 16:39:38 --> Router Class Initialized
INFO - 2019-08-29 16:39:38 --> Helper loaded: html_helper
INFO - 2019-08-29 16:39:38 --> Output Class Initialized
INFO - 2019-08-29 16:39:38 --> Helper loaded: form_helper
INFO - 2019-08-29 16:39:38 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:39:38 --> Security Class Initialized
INFO - 2019-08-29 16:39:38 --> Helper loaded: date_helper
DEBUG - 2019-08-29 16:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:39:38 --> Input Class Initialized
INFO - 2019-08-29 16:39:38 --> Language Class Initialized
INFO - 2019-08-29 16:39:38 --> Form Validation Class Initialized
INFO - 2019-08-29 16:39:38 --> Email Class Initialized
INFO - 2019-08-29 16:39:38 --> Loader Class Initialized
INFO - 2019-08-29 16:39:38 --> Helper loaded: url_helper
DEBUG - 2019-08-29 16:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:39:38 --> Helper loaded: html_helper
INFO - 2019-08-29 16:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:39:38 --> Helper loaded: form_helper
INFO - 2019-08-29 16:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:39:38 --> Pagination Class Initialized
INFO - 2019-08-29 16:39:38 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:39:38 --> Helper loaded: date_helper
INFO - 2019-08-29 16:39:38 --> Form Validation Class Initialized
INFO - 2019-08-29 16:39:38 --> Email Class Initialized
INFO - 2019-08-29 16:39:38 --> Database Driver Class Initialized
DEBUG - 2019-08-29 16:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:39:38 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:38 --> Controller Class Initialized
INFO - 2019-08-29 16:39:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 16:39:38 --> Final output sent to browser
DEBUG - 2019-08-29 16:39:38 --> Total execution time: 0.0819
INFO - 2019-08-29 16:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:39:38 --> Pagination Class Initialized
INFO - 2019-08-29 16:39:38 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:38 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:38 --> Controller Class Initialized
INFO - 2019-08-29 16:39:38 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 16:39:38 --> Final output sent to browser
DEBUG - 2019-08-29 16:39:38 --> Total execution time: 0.1029
INFO - 2019-08-29 16:39:41 --> Config Class Initialized
INFO - 2019-08-29 16:39:41 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:39:41 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:39:41 --> Utf8 Class Initialized
INFO - 2019-08-29 16:39:41 --> URI Class Initialized
INFO - 2019-08-29 16:39:41 --> Router Class Initialized
INFO - 2019-08-29 16:39:41 --> Output Class Initialized
INFO - 2019-08-29 16:39:41 --> Security Class Initialized
DEBUG - 2019-08-29 16:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:39:41 --> Input Class Initialized
INFO - 2019-08-29 16:39:41 --> Language Class Initialized
INFO - 2019-08-29 16:39:41 --> Loader Class Initialized
INFO - 2019-08-29 16:39:41 --> Helper loaded: url_helper
INFO - 2019-08-29 16:39:41 --> Helper loaded: html_helper
INFO - 2019-08-29 16:39:41 --> Helper loaded: form_helper
INFO - 2019-08-29 16:39:41 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:39:41 --> Helper loaded: date_helper
INFO - 2019-08-29 16:39:41 --> Form Validation Class Initialized
INFO - 2019-08-29 16:39:41 --> Email Class Initialized
DEBUG - 2019-08-29 16:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:39:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:39:41 --> Pagination Class Initialized
INFO - 2019-08-29 16:39:41 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:41 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:41 --> Controller Class Initialized
INFO - 2019-08-29 16:39:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-29 16:39:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/folio.php
INFO - 2019-08-29 16:39:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-08-29 16:39:42 --> Final output sent to browser
DEBUG - 2019-08-29 16:39:42 --> Total execution time: 0.2225
INFO - 2019-08-29 16:39:42 --> Config Class Initialized
INFO - 2019-08-29 16:39:42 --> Hooks Class Initialized
INFO - 2019-08-29 16:39:42 --> Config Class Initialized
INFO - 2019-08-29 16:39:42 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:39:42 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:39:42 --> Utf8 Class Initialized
DEBUG - 2019-08-29 16:39:42 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:39:42 --> Utf8 Class Initialized
INFO - 2019-08-29 16:39:42 --> URI Class Initialized
INFO - 2019-08-29 16:39:42 --> URI Class Initialized
INFO - 2019-08-29 16:39:42 --> Router Class Initialized
INFO - 2019-08-29 16:39:42 --> Router Class Initialized
INFO - 2019-08-29 16:39:42 --> Output Class Initialized
INFO - 2019-08-29 16:39:42 --> Output Class Initialized
INFO - 2019-08-29 16:39:42 --> Security Class Initialized
INFO - 2019-08-29 16:39:42 --> Security Class Initialized
DEBUG - 2019-08-29 16:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:39:42 --> Input Class Initialized
INFO - 2019-08-29 16:39:42 --> Language Class Initialized
DEBUG - 2019-08-29 16:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:39:42 --> Input Class Initialized
INFO - 2019-08-29 16:39:42 --> Language Class Initialized
INFO - 2019-08-29 16:39:42 --> Loader Class Initialized
INFO - 2019-08-29 16:39:42 --> Loader Class Initialized
INFO - 2019-08-29 16:39:42 --> Helper loaded: url_helper
INFO - 2019-08-29 16:39:42 --> Helper loaded: html_helper
INFO - 2019-08-29 16:39:42 --> Helper loaded: url_helper
INFO - 2019-08-29 16:39:42 --> Helper loaded: html_helper
INFO - 2019-08-29 16:39:42 --> Helper loaded: form_helper
INFO - 2019-08-29 16:39:42 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:39:42 --> Helper loaded: form_helper
INFO - 2019-08-29 16:39:42 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:39:42 --> Helper loaded: date_helper
INFO - 2019-08-29 16:39:42 --> Helper loaded: date_helper
INFO - 2019-08-29 16:39:42 --> Form Validation Class Initialized
INFO - 2019-08-29 16:39:42 --> Form Validation Class Initialized
INFO - 2019-08-29 16:39:42 --> Email Class Initialized
INFO - 2019-08-29 16:39:42 --> Email Class Initialized
DEBUG - 2019-08-29 16:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:39:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-08-29 16:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:39:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:39:42 --> Pagination Class Initialized
INFO - 2019-08-29 16:39:42 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:42 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:42 --> Controller Class Initialized
INFO - 2019-08-29 16:39:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 16:39:42 --> Final output sent to browser
DEBUG - 2019-08-29 16:39:42 --> Total execution time: 0.1171
INFO - 2019-08-29 16:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:39:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:39:42 --> Pagination Class Initialized
INFO - 2019-08-29 16:39:42 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:42 --> Database Driver Class Initialized
INFO - 2019-08-29 16:39:42 --> Controller Class Initialized
INFO - 2019-08-29 16:39:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 16:39:42 --> Final output sent to browser
DEBUG - 2019-08-29 16:39:42 --> Total execution time: 0.1493
INFO - 2019-08-29 16:40:39 --> Config Class Initialized
INFO - 2019-08-29 16:40:39 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:40:39 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:40:39 --> Utf8 Class Initialized
INFO - 2019-08-29 16:40:39 --> URI Class Initialized
INFO - 2019-08-29 16:40:39 --> Router Class Initialized
INFO - 2019-08-29 16:40:39 --> Output Class Initialized
INFO - 2019-08-29 16:40:39 --> Security Class Initialized
DEBUG - 2019-08-29 16:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:40:39 --> Input Class Initialized
INFO - 2019-08-29 16:40:39 --> Language Class Initialized
INFO - 2019-08-29 16:40:39 --> Loader Class Initialized
INFO - 2019-08-29 16:40:39 --> Helper loaded: url_helper
INFO - 2019-08-29 16:40:39 --> Helper loaded: html_helper
INFO - 2019-08-29 16:40:39 --> Helper loaded: form_helper
INFO - 2019-08-29 16:40:39 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:40:39 --> Helper loaded: date_helper
INFO - 2019-08-29 16:40:39 --> Form Validation Class Initialized
INFO - 2019-08-29 16:40:39 --> Email Class Initialized
DEBUG - 2019-08-29 16:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:40:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:40:39 --> Pagination Class Initialized
INFO - 2019-08-29 16:40:39 --> Database Driver Class Initialized
INFO - 2019-08-29 16:40:39 --> Database Driver Class Initialized
INFO - 2019-08-29 16:40:39 --> Controller Class Initialized
INFO - 2019-08-29 16:40:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 16:40:39 --> Final output sent to browser
DEBUG - 2019-08-29 16:40:39 --> Total execution time: 0.0623
INFO - 2019-08-29 16:41:11 --> Config Class Initialized
INFO - 2019-08-29 16:41:11 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:41:11 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:41:11 --> Utf8 Class Initialized
INFO - 2019-08-29 16:41:11 --> URI Class Initialized
INFO - 2019-08-29 16:41:11 --> Router Class Initialized
INFO - 2019-08-29 16:41:11 --> Output Class Initialized
INFO - 2019-08-29 16:41:11 --> Security Class Initialized
DEBUG - 2019-08-29 16:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:41:11 --> Input Class Initialized
INFO - 2019-08-29 16:41:11 --> Language Class Initialized
INFO - 2019-08-29 16:41:11 --> Loader Class Initialized
INFO - 2019-08-29 16:41:11 --> Helper loaded: url_helper
INFO - 2019-08-29 16:41:11 --> Helper loaded: html_helper
INFO - 2019-08-29 16:41:11 --> Helper loaded: form_helper
INFO - 2019-08-29 16:41:11 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:41:11 --> Helper loaded: date_helper
INFO - 2019-08-29 16:41:11 --> Form Validation Class Initialized
INFO - 2019-08-29 16:41:11 --> Email Class Initialized
DEBUG - 2019-08-29 16:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:41:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:41:11 --> Pagination Class Initialized
INFO - 2019-08-29 16:41:11 --> Database Driver Class Initialized
INFO - 2019-08-29 16:41:11 --> Database Driver Class Initialized
INFO - 2019-08-29 16:41:11 --> Controller Class Initialized
INFO - 2019-08-29 16:41:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-29 16:41:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-08-29 16:41:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-08-29 16:41:11 --> Final output sent to browser
DEBUG - 2019-08-29 16:41:11 --> Total execution time: 0.1079
INFO - 2019-08-29 16:41:11 --> Config Class Initialized
INFO - 2019-08-29 16:41:11 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:41:11 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:41:11 --> Utf8 Class Initialized
INFO - 2019-08-29 16:41:11 --> URI Class Initialized
INFO - 2019-08-29 16:41:11 --> Router Class Initialized
INFO - 2019-08-29 16:41:11 --> Output Class Initialized
INFO - 2019-08-29 16:41:11 --> Security Class Initialized
DEBUG - 2019-08-29 16:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:41:11 --> Input Class Initialized
INFO - 2019-08-29 16:41:11 --> Language Class Initialized
INFO - 2019-08-29 16:41:11 --> Loader Class Initialized
INFO - 2019-08-29 16:41:11 --> Helper loaded: url_helper
INFO - 2019-08-29 16:41:11 --> Helper loaded: html_helper
INFO - 2019-08-29 16:41:11 --> Helper loaded: form_helper
INFO - 2019-08-29 16:41:11 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:41:11 --> Helper loaded: date_helper
INFO - 2019-08-29 16:41:11 --> Form Validation Class Initialized
INFO - 2019-08-29 16:41:11 --> Email Class Initialized
DEBUG - 2019-08-29 16:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:41:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:41:11 --> Pagination Class Initialized
INFO - 2019-08-29 16:41:11 --> Database Driver Class Initialized
INFO - 2019-08-29 16:41:11 --> Database Driver Class Initialized
INFO - 2019-08-29 16:41:11 --> Controller Class Initialized
INFO - 2019-08-29 16:41:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 16:41:11 --> Final output sent to browser
DEBUG - 2019-08-29 16:41:11 --> Total execution time: 0.0683
INFO - 2019-08-29 16:41:12 --> Config Class Initialized
INFO - 2019-08-29 16:41:12 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:41:12 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:41:12 --> Utf8 Class Initialized
INFO - 2019-08-29 16:41:12 --> URI Class Initialized
INFO - 2019-08-29 16:41:12 --> Router Class Initialized
INFO - 2019-08-29 16:41:12 --> Output Class Initialized
INFO - 2019-08-29 16:41:12 --> Security Class Initialized
DEBUG - 2019-08-29 16:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:41:12 --> Input Class Initialized
INFO - 2019-08-29 16:41:12 --> Language Class Initialized
INFO - 2019-08-29 16:41:12 --> Loader Class Initialized
INFO - 2019-08-29 16:41:12 --> Helper loaded: url_helper
INFO - 2019-08-29 16:41:12 --> Helper loaded: html_helper
INFO - 2019-08-29 16:41:12 --> Helper loaded: form_helper
INFO - 2019-08-29 16:41:12 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:41:12 --> Helper loaded: date_helper
INFO - 2019-08-29 16:41:12 --> Form Validation Class Initialized
INFO - 2019-08-29 16:41:12 --> Email Class Initialized
DEBUG - 2019-08-29 16:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:41:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:41:12 --> Pagination Class Initialized
INFO - 2019-08-29 16:41:12 --> Database Driver Class Initialized
INFO - 2019-08-29 16:41:12 --> Database Driver Class Initialized
INFO - 2019-08-29 16:41:12 --> Controller Class Initialized
INFO - 2019-08-29 16:41:12 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 16:41:12 --> Final output sent to browser
DEBUG - 2019-08-29 16:41:12 --> Total execution time: 0.1044
INFO - 2019-08-29 16:41:32 --> Config Class Initialized
INFO - 2019-08-29 16:41:32 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:41:32 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:41:32 --> Utf8 Class Initialized
INFO - 2019-08-29 16:41:32 --> URI Class Initialized
INFO - 2019-08-29 16:41:32 --> Router Class Initialized
INFO - 2019-08-29 16:41:32 --> Output Class Initialized
INFO - 2019-08-29 16:41:32 --> Security Class Initialized
DEBUG - 2019-08-29 16:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:41:32 --> Input Class Initialized
INFO - 2019-08-29 16:41:32 --> Language Class Initialized
INFO - 2019-08-29 16:41:32 --> Loader Class Initialized
INFO - 2019-08-29 16:41:32 --> Helper loaded: url_helper
INFO - 2019-08-29 16:41:32 --> Helper loaded: html_helper
INFO - 2019-08-29 16:41:32 --> Helper loaded: form_helper
INFO - 2019-08-29 16:41:32 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:41:32 --> Helper loaded: date_helper
INFO - 2019-08-29 16:41:32 --> Form Validation Class Initialized
INFO - 2019-08-29 16:41:32 --> Email Class Initialized
DEBUG - 2019-08-29 16:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:41:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:41:32 --> Pagination Class Initialized
INFO - 2019-08-29 16:41:32 --> Database Driver Class Initialized
INFO - 2019-08-29 16:41:32 --> Database Driver Class Initialized
INFO - 2019-08-29 16:41:32 --> Controller Class Initialized
INFO - 2019-08-29 16:41:32 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-08-29 16:41:32 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report.php
INFO - 2019-08-29 16:41:32 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-08-29 16:41:32 --> Final output sent to browser
DEBUG - 2019-08-29 16:41:32 --> Total execution time: 0.1748
INFO - 2019-08-29 16:41:42 --> Config Class Initialized
INFO - 2019-08-29 16:41:42 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:41:42 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:41:42 --> Utf8 Class Initialized
INFO - 2019-08-29 16:41:42 --> URI Class Initialized
INFO - 2019-08-29 16:41:42 --> Router Class Initialized
INFO - 2019-08-29 16:41:42 --> Output Class Initialized
INFO - 2019-08-29 16:41:42 --> Security Class Initialized
DEBUG - 2019-08-29 16:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:41:42 --> Input Class Initialized
INFO - 2019-08-29 16:41:42 --> Language Class Initialized
INFO - 2019-08-29 16:41:42 --> Loader Class Initialized
INFO - 2019-08-29 16:41:42 --> Helper loaded: url_helper
INFO - 2019-08-29 16:41:42 --> Helper loaded: html_helper
INFO - 2019-08-29 16:41:42 --> Helper loaded: form_helper
INFO - 2019-08-29 16:41:42 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:41:42 --> Helper loaded: date_helper
INFO - 2019-08-29 16:41:42 --> Form Validation Class Initialized
INFO - 2019-08-29 16:41:42 --> Email Class Initialized
DEBUG - 2019-08-29 16:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:41:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:41:42 --> Pagination Class Initialized
INFO - 2019-08-29 16:41:42 --> Database Driver Class Initialized
INFO - 2019-08-29 16:41:42 --> Database Driver Class Initialized
INFO - 2019-08-29 16:41:42 --> Controller Class Initialized
INFO - 2019-08-29 16:41:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-29 16:41:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-08-29 16:41:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-08-29 16:41:42 --> Final output sent to browser
DEBUG - 2019-08-29 16:41:42 --> Total execution time: 0.0724
INFO - 2019-08-29 16:41:42 --> Config Class Initialized
INFO - 2019-08-29 16:41:42 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:41:42 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:41:42 --> Utf8 Class Initialized
INFO - 2019-08-29 16:41:42 --> URI Class Initialized
INFO - 2019-08-29 16:41:42 --> Router Class Initialized
INFO - 2019-08-29 16:41:42 --> Output Class Initialized
INFO - 2019-08-29 16:41:42 --> Security Class Initialized
DEBUG - 2019-08-29 16:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:41:42 --> Input Class Initialized
INFO - 2019-08-29 16:41:42 --> Language Class Initialized
INFO - 2019-08-29 16:41:42 --> Loader Class Initialized
INFO - 2019-08-29 16:41:42 --> Helper loaded: url_helper
INFO - 2019-08-29 16:41:42 --> Helper loaded: html_helper
INFO - 2019-08-29 16:41:42 --> Helper loaded: form_helper
INFO - 2019-08-29 16:41:42 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:41:42 --> Helper loaded: date_helper
INFO - 2019-08-29 16:41:42 --> Form Validation Class Initialized
INFO - 2019-08-29 16:41:42 --> Email Class Initialized
DEBUG - 2019-08-29 16:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:41:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:41:42 --> Pagination Class Initialized
INFO - 2019-08-29 16:41:42 --> Database Driver Class Initialized
INFO - 2019-08-29 16:41:42 --> Database Driver Class Initialized
INFO - 2019-08-29 16:41:42 --> Controller Class Initialized
INFO - 2019-08-29 16:41:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 16:41:42 --> Final output sent to browser
DEBUG - 2019-08-29 16:41:42 --> Total execution time: 0.0724
INFO - 2019-08-29 16:41:56 --> Config Class Initialized
INFO - 2019-08-29 16:41:56 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:41:56 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:41:56 --> Utf8 Class Initialized
INFO - 2019-08-29 16:41:56 --> URI Class Initialized
INFO - 2019-08-29 16:41:56 --> Router Class Initialized
INFO - 2019-08-29 16:41:56 --> Output Class Initialized
INFO - 2019-08-29 16:41:56 --> Security Class Initialized
DEBUG - 2019-08-29 16:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:41:56 --> Input Class Initialized
INFO - 2019-08-29 16:41:56 --> Language Class Initialized
INFO - 2019-08-29 16:41:56 --> Loader Class Initialized
INFO - 2019-08-29 16:41:56 --> Helper loaded: url_helper
INFO - 2019-08-29 16:41:56 --> Helper loaded: html_helper
INFO - 2019-08-29 16:41:56 --> Helper loaded: form_helper
INFO - 2019-08-29 16:41:56 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:41:56 --> Helper loaded: date_helper
INFO - 2019-08-29 16:41:56 --> Form Validation Class Initialized
INFO - 2019-08-29 16:41:56 --> Email Class Initialized
DEBUG - 2019-08-29 16:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:41:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:41:56 --> Pagination Class Initialized
INFO - 2019-08-29 16:41:56 --> Database Driver Class Initialized
INFO - 2019-08-29 16:41:56 --> Database Driver Class Initialized
INFO - 2019-08-29 16:41:56 --> Controller Class Initialized
INFO - 2019-08-29 16:41:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 16:41:56 --> Final output sent to browser
DEBUG - 2019-08-29 16:41:56 --> Total execution time: 0.0576
INFO - 2019-08-29 16:43:10 --> Config Class Initialized
INFO - 2019-08-29 16:43:10 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:43:10 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:43:10 --> Utf8 Class Initialized
INFO - 2019-08-29 16:43:10 --> URI Class Initialized
INFO - 2019-08-29 16:43:10 --> Router Class Initialized
INFO - 2019-08-29 16:43:10 --> Output Class Initialized
INFO - 2019-08-29 16:43:10 --> Security Class Initialized
DEBUG - 2019-08-29 16:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:43:10 --> Input Class Initialized
INFO - 2019-08-29 16:43:10 --> Language Class Initialized
INFO - 2019-08-29 16:43:10 --> Loader Class Initialized
INFO - 2019-08-29 16:43:10 --> Helper loaded: url_helper
INFO - 2019-08-29 16:43:10 --> Helper loaded: html_helper
INFO - 2019-08-29 16:43:10 --> Helper loaded: form_helper
INFO - 2019-08-29 16:43:10 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:43:10 --> Helper loaded: date_helper
INFO - 2019-08-29 16:43:10 --> Form Validation Class Initialized
INFO - 2019-08-29 16:43:10 --> Email Class Initialized
DEBUG - 2019-08-29 16:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:43:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:43:10 --> Pagination Class Initialized
INFO - 2019-08-29 16:43:10 --> Database Driver Class Initialized
INFO - 2019-08-29 16:43:10 --> Database Driver Class Initialized
INFO - 2019-08-29 16:43:10 --> Controller Class Initialized
INFO - 2019-08-29 16:43:10 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-29 16:43:10 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-08-29 16:43:10 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-08-29 16:43:10 --> Final output sent to browser
DEBUG - 2019-08-29 16:43:10 --> Total execution time: 0.0930
INFO - 2019-08-29 16:43:10 --> Config Class Initialized
INFO - 2019-08-29 16:43:10 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:43:10 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:43:10 --> Utf8 Class Initialized
INFO - 2019-08-29 16:43:10 --> URI Class Initialized
INFO - 2019-08-29 16:43:10 --> Router Class Initialized
INFO - 2019-08-29 16:43:10 --> Output Class Initialized
INFO - 2019-08-29 16:43:10 --> Security Class Initialized
DEBUG - 2019-08-29 16:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:43:10 --> Input Class Initialized
INFO - 2019-08-29 16:43:10 --> Language Class Initialized
INFO - 2019-08-29 16:43:10 --> Loader Class Initialized
INFO - 2019-08-29 16:43:11 --> Helper loaded: url_helper
INFO - 2019-08-29 16:43:11 --> Helper loaded: html_helper
INFO - 2019-08-29 16:43:11 --> Helper loaded: form_helper
INFO - 2019-08-29 16:43:11 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:43:11 --> Helper loaded: date_helper
INFO - 2019-08-29 16:43:11 --> Form Validation Class Initialized
INFO - 2019-08-29 16:43:11 --> Email Class Initialized
DEBUG - 2019-08-29 16:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:43:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:43:11 --> Pagination Class Initialized
INFO - 2019-08-29 16:43:11 --> Database Driver Class Initialized
INFO - 2019-08-29 16:43:11 --> Database Driver Class Initialized
INFO - 2019-08-29 16:43:11 --> Controller Class Initialized
INFO - 2019-08-29 16:43:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 16:43:11 --> Final output sent to browser
DEBUG - 2019-08-29 16:43:11 --> Total execution time: 0.0658
INFO - 2019-08-29 16:43:13 --> Config Class Initialized
INFO - 2019-08-29 16:43:13 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:43:13 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:43:13 --> Utf8 Class Initialized
INFO - 2019-08-29 16:43:13 --> URI Class Initialized
INFO - 2019-08-29 16:43:13 --> Router Class Initialized
INFO - 2019-08-29 16:43:13 --> Output Class Initialized
INFO - 2019-08-29 16:43:13 --> Security Class Initialized
DEBUG - 2019-08-29 16:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:43:13 --> Input Class Initialized
INFO - 2019-08-29 16:43:13 --> Language Class Initialized
INFO - 2019-08-29 16:43:13 --> Loader Class Initialized
INFO - 2019-08-29 16:43:13 --> Helper loaded: url_helper
INFO - 2019-08-29 16:43:13 --> Helper loaded: html_helper
INFO - 2019-08-29 16:43:13 --> Helper loaded: form_helper
INFO - 2019-08-29 16:43:13 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:43:13 --> Helper loaded: date_helper
INFO - 2019-08-29 16:43:13 --> Form Validation Class Initialized
INFO - 2019-08-29 16:43:13 --> Email Class Initialized
DEBUG - 2019-08-29 16:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:43:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:43:13 --> Pagination Class Initialized
INFO - 2019-08-29 16:43:13 --> Database Driver Class Initialized
INFO - 2019-08-29 16:43:13 --> Database Driver Class Initialized
INFO - 2019-08-29 16:43:13 --> Controller Class Initialized
INFO - 2019-08-29 16:43:13 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-29 16:43:13 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-08-29 16:43:13 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-08-29 16:43:13 --> Final output sent to browser
DEBUG - 2019-08-29 16:43:13 --> Total execution time: 0.0650
INFO - 2019-08-29 16:43:13 --> Config Class Initialized
INFO - 2019-08-29 16:43:13 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:43:13 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:43:13 --> Utf8 Class Initialized
INFO - 2019-08-29 16:43:13 --> URI Class Initialized
INFO - 2019-08-29 16:43:13 --> Router Class Initialized
INFO - 2019-08-29 16:43:13 --> Output Class Initialized
INFO - 2019-08-29 16:43:13 --> Security Class Initialized
DEBUG - 2019-08-29 16:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:43:13 --> Input Class Initialized
INFO - 2019-08-29 16:43:13 --> Language Class Initialized
INFO - 2019-08-29 16:43:13 --> Loader Class Initialized
INFO - 2019-08-29 16:43:13 --> Helper loaded: url_helper
INFO - 2019-08-29 16:43:13 --> Helper loaded: html_helper
INFO - 2019-08-29 16:43:13 --> Helper loaded: form_helper
INFO - 2019-08-29 16:43:13 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:43:13 --> Helper loaded: date_helper
INFO - 2019-08-29 16:43:13 --> Form Validation Class Initialized
INFO - 2019-08-29 16:43:13 --> Email Class Initialized
DEBUG - 2019-08-29 16:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:43:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:43:13 --> Pagination Class Initialized
INFO - 2019-08-29 16:43:13 --> Database Driver Class Initialized
INFO - 2019-08-29 16:43:13 --> Database Driver Class Initialized
INFO - 2019-08-29 16:43:13 --> Controller Class Initialized
INFO - 2019-08-29 16:43:13 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 16:43:13 --> Final output sent to browser
DEBUG - 2019-08-29 16:43:13 --> Total execution time: 0.0627
INFO - 2019-08-29 16:43:42 --> Config Class Initialized
INFO - 2019-08-29 16:43:42 --> Hooks Class Initialized
DEBUG - 2019-08-29 16:43:42 --> UTF-8 Support Enabled
INFO - 2019-08-29 16:43:42 --> Utf8 Class Initialized
INFO - 2019-08-29 16:43:42 --> URI Class Initialized
INFO - 2019-08-29 16:43:42 --> Router Class Initialized
INFO - 2019-08-29 16:43:42 --> Output Class Initialized
INFO - 2019-08-29 16:43:42 --> Security Class Initialized
DEBUG - 2019-08-29 16:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 16:43:42 --> Input Class Initialized
INFO - 2019-08-29 16:43:42 --> Language Class Initialized
INFO - 2019-08-29 16:43:42 --> Loader Class Initialized
INFO - 2019-08-29 16:43:42 --> Helper loaded: url_helper
INFO - 2019-08-29 16:43:42 --> Helper loaded: html_helper
INFO - 2019-08-29 16:43:42 --> Helper loaded: form_helper
INFO - 2019-08-29 16:43:42 --> Helper loaded: cookie_helper
INFO - 2019-08-29 16:43:42 --> Helper loaded: date_helper
INFO - 2019-08-29 16:43:42 --> Form Validation Class Initialized
INFO - 2019-08-29 16:43:42 --> Email Class Initialized
DEBUG - 2019-08-29 16:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 16:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 16:43:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 16:43:42 --> Pagination Class Initialized
INFO - 2019-08-29 16:43:42 --> Database Driver Class Initialized
INFO - 2019-08-29 16:43:42 --> Database Driver Class Initialized
INFO - 2019-08-29 16:43:42 --> Controller Class Initialized
INFO - 2019-08-29 16:43:42 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-08-29 16:43:42 --> Final output sent to browser
DEBUG - 2019-08-29 16:43:42 --> Total execution time: 0.0601
INFO - 2019-08-29 17:27:58 --> Config Class Initialized
INFO - 2019-08-29 17:27:58 --> Hooks Class Initialized
DEBUG - 2019-08-29 17:27:58 --> UTF-8 Support Enabled
INFO - 2019-08-29 17:27:58 --> Utf8 Class Initialized
INFO - 2019-08-29 17:27:58 --> URI Class Initialized
INFO - 2019-08-29 17:27:58 --> Router Class Initialized
INFO - 2019-08-29 17:27:58 --> Output Class Initialized
INFO - 2019-08-29 17:27:58 --> Security Class Initialized
DEBUG - 2019-08-29 17:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 17:27:58 --> Input Class Initialized
INFO - 2019-08-29 17:27:58 --> Language Class Initialized
INFO - 2019-08-29 17:27:58 --> Loader Class Initialized
INFO - 2019-08-29 17:27:58 --> Helper loaded: url_helper
INFO - 2019-08-29 17:27:58 --> Helper loaded: html_helper
INFO - 2019-08-29 17:27:58 --> Helper loaded: form_helper
INFO - 2019-08-29 17:27:58 --> Helper loaded: cookie_helper
INFO - 2019-08-29 17:27:58 --> Helper loaded: date_helper
INFO - 2019-08-29 17:27:58 --> Form Validation Class Initialized
INFO - 2019-08-29 17:27:58 --> Email Class Initialized
DEBUG - 2019-08-29 17:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 17:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 17:27:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-29 17:27:58 --> Pagination Class Initialized
INFO - 2019-08-29 17:27:58 --> Database Driver Class Initialized
INFO - 2019-08-29 17:27:58 --> Database Driver Class Initialized
INFO - 2019-08-29 17:27:58 --> Controller Class Initialized
INFO - 2019-08-29 17:27:58 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-08-29 17:27:58 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report_sales.php
INFO - 2019-08-29 17:27:58 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-08-29 17:27:58 --> Final output sent to browser
DEBUG - 2019-08-29 17:27:58 --> Total execution time: 0.1215
