<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-22 10:05:45 --> Config Class Initialized
INFO - 2019-09-22 10:05:45 --> Hooks Class Initialized
DEBUG - 2019-09-22 10:05:45 --> UTF-8 Support Enabled
INFO - 2019-09-22 10:05:45 --> Utf8 Class Initialized
INFO - 2019-09-22 10:05:45 --> URI Class Initialized
INFO - 2019-09-22 10:05:45 --> Router Class Initialized
INFO - 2019-09-22 10:05:45 --> Output Class Initialized
INFO - 2019-09-22 10:05:45 --> Security Class Initialized
DEBUG - 2019-09-22 10:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-22 10:05:45 --> Input Class Initialized
INFO - 2019-09-22 10:05:45 --> Language Class Initialized
INFO - 2019-09-22 10:05:45 --> Loader Class Initialized
INFO - 2019-09-22 10:05:45 --> Helper loaded: url_helper
INFO - 2019-09-22 10:05:45 --> Helper loaded: html_helper
INFO - 2019-09-22 10:05:45 --> Helper loaded: form_helper
INFO - 2019-09-22 10:05:45 --> Helper loaded: cookie_helper
INFO - 2019-09-22 10:05:45 --> Helper loaded: date_helper
INFO - 2019-09-22 10:05:45 --> Form Validation Class Initialized
INFO - 2019-09-22 10:05:45 --> Email Class Initialized
DEBUG - 2019-09-22 10:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-22 10:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-22 10:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-22 10:05:45 --> Pagination Class Initialized
INFO - 2019-09-22 10:05:46 --> Database Driver Class Initialized
INFO - 2019-09-22 10:05:46 --> Database Driver Class Initialized
INFO - 2019-09-22 10:05:46 --> Controller Class Initialized
INFO - 2019-09-22 10:05:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-22 10:05:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-22 10:05:46 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-22 10:05:46 --> Final output sent to browser
DEBUG - 2019-09-22 10:05:46 --> Total execution time: 0.5626
INFO - 2019-09-22 10:05:47 --> Config Class Initialized
INFO - 2019-09-22 10:05:47 --> Hooks Class Initialized
DEBUG - 2019-09-22 10:05:47 --> UTF-8 Support Enabled
INFO - 2019-09-22 10:05:47 --> Utf8 Class Initialized
INFO - 2019-09-22 10:05:47 --> URI Class Initialized
INFO - 2019-09-22 10:05:47 --> Router Class Initialized
INFO - 2019-09-22 10:05:47 --> Output Class Initialized
INFO - 2019-09-22 10:05:47 --> Security Class Initialized
DEBUG - 2019-09-22 10:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-22 10:05:47 --> Input Class Initialized
INFO - 2019-09-22 10:05:47 --> Language Class Initialized
INFO - 2019-09-22 10:05:47 --> Loader Class Initialized
INFO - 2019-09-22 10:05:47 --> Helper loaded: url_helper
INFO - 2019-09-22 10:05:47 --> Helper loaded: html_helper
INFO - 2019-09-22 10:05:47 --> Helper loaded: form_helper
INFO - 2019-09-22 10:05:47 --> Helper loaded: cookie_helper
INFO - 2019-09-22 10:05:47 --> Helper loaded: date_helper
INFO - 2019-09-22 10:05:47 --> Form Validation Class Initialized
INFO - 2019-09-22 10:05:47 --> Email Class Initialized
DEBUG - 2019-09-22 10:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-22 10:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-22 10:05:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-22 10:05:47 --> Pagination Class Initialized
INFO - 2019-09-22 10:05:47 --> Database Driver Class Initialized
INFO - 2019-09-22 10:05:47 --> Database Driver Class Initialized
INFO - 2019-09-22 10:05:47 --> Controller Class Initialized
INFO - 2019-09-22 10:05:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-22 10:05:47 --> Final output sent to browser
DEBUG - 2019-09-22 10:05:47 --> Total execution time: 0.2474
INFO - 2019-09-22 10:05:53 --> Config Class Initialized
INFO - 2019-09-22 10:05:53 --> Hooks Class Initialized
DEBUG - 2019-09-22 10:05:53 --> UTF-8 Support Enabled
INFO - 2019-09-22 10:05:54 --> Utf8 Class Initialized
INFO - 2019-09-22 10:05:54 --> URI Class Initialized
INFO - 2019-09-22 10:05:54 --> Router Class Initialized
INFO - 2019-09-22 10:05:54 --> Output Class Initialized
INFO - 2019-09-22 10:05:54 --> Security Class Initialized
DEBUG - 2019-09-22 10:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-22 10:05:54 --> Input Class Initialized
INFO - 2019-09-22 10:05:54 --> Language Class Initialized
INFO - 2019-09-22 10:05:54 --> Loader Class Initialized
INFO - 2019-09-22 10:05:54 --> Helper loaded: url_helper
INFO - 2019-09-22 10:05:54 --> Helper loaded: html_helper
INFO - 2019-09-22 10:05:54 --> Helper loaded: form_helper
INFO - 2019-09-22 10:05:54 --> Helper loaded: cookie_helper
INFO - 2019-09-22 10:05:54 --> Helper loaded: date_helper
INFO - 2019-09-22 10:05:54 --> Form Validation Class Initialized
INFO - 2019-09-22 10:05:54 --> Email Class Initialized
DEBUG - 2019-09-22 10:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-22 10:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-22 10:05:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-22 10:05:54 --> Pagination Class Initialized
INFO - 2019-09-22 10:05:54 --> Database Driver Class Initialized
INFO - 2019-09-22 10:05:54 --> Database Driver Class Initialized
INFO - 2019-09-22 10:05:54 --> Controller Class Initialized
INFO - 2019-09-22 10:09:21 --> Config Class Initialized
INFO - 2019-09-22 10:09:21 --> Hooks Class Initialized
DEBUG - 2019-09-22 10:09:21 --> UTF-8 Support Enabled
INFO - 2019-09-22 10:09:21 --> Utf8 Class Initialized
INFO - 2019-09-22 10:09:21 --> URI Class Initialized
INFO - 2019-09-22 10:09:21 --> Router Class Initialized
INFO - 2019-09-22 10:09:21 --> Output Class Initialized
INFO - 2019-09-22 10:09:21 --> Security Class Initialized
DEBUG - 2019-09-22 10:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-22 10:09:21 --> Input Class Initialized
INFO - 2019-09-22 10:09:21 --> Language Class Initialized
INFO - 2019-09-22 10:09:21 --> Loader Class Initialized
INFO - 2019-09-22 10:09:21 --> Helper loaded: url_helper
INFO - 2019-09-22 10:09:21 --> Helper loaded: html_helper
INFO - 2019-09-22 10:09:21 --> Helper loaded: form_helper
INFO - 2019-09-22 10:09:21 --> Helper loaded: cookie_helper
INFO - 2019-09-22 10:09:21 --> Helper loaded: date_helper
INFO - 2019-09-22 10:09:21 --> Form Validation Class Initialized
INFO - 2019-09-22 10:09:21 --> Email Class Initialized
DEBUG - 2019-09-22 10:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-22 10:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-22 10:09:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-22 10:09:21 --> Pagination Class Initialized
INFO - 2019-09-22 10:09:21 --> Database Driver Class Initialized
INFO - 2019-09-22 10:09:21 --> Database Driver Class Initialized
INFO - 2019-09-22 10:09:21 --> Controller Class Initialized
INFO - 2019-09-22 10:09:21 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-22 10:09:21 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report.php
INFO - 2019-09-22 10:09:21 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-22 10:09:21 --> Final output sent to browser
DEBUG - 2019-09-22 10:09:21 --> Total execution time: 0.4074
INFO - 2019-09-22 10:11:24 --> Config Class Initialized
INFO - 2019-09-22 10:11:24 --> Hooks Class Initialized
DEBUG - 2019-09-22 10:11:24 --> UTF-8 Support Enabled
INFO - 2019-09-22 10:11:24 --> Utf8 Class Initialized
INFO - 2019-09-22 10:11:24 --> URI Class Initialized
INFO - 2019-09-22 10:11:24 --> Router Class Initialized
INFO - 2019-09-22 10:11:24 --> Output Class Initialized
INFO - 2019-09-22 10:11:24 --> Security Class Initialized
DEBUG - 2019-09-22 10:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-22 10:11:24 --> Input Class Initialized
INFO - 2019-09-22 10:11:24 --> Language Class Initialized
INFO - 2019-09-22 10:11:24 --> Loader Class Initialized
INFO - 2019-09-22 10:11:24 --> Helper loaded: url_helper
INFO - 2019-09-22 10:11:24 --> Helper loaded: html_helper
INFO - 2019-09-22 10:11:24 --> Helper loaded: form_helper
INFO - 2019-09-22 10:11:24 --> Helper loaded: cookie_helper
INFO - 2019-09-22 10:11:24 --> Helper loaded: date_helper
INFO - 2019-09-22 10:11:24 --> Form Validation Class Initialized
INFO - 2019-09-22 10:11:24 --> Email Class Initialized
DEBUG - 2019-09-22 10:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-22 10:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-22 10:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-22 10:11:24 --> Pagination Class Initialized
INFO - 2019-09-22 10:11:24 --> Database Driver Class Initialized
INFO - 2019-09-22 10:11:24 --> Database Driver Class Initialized
INFO - 2019-09-22 10:11:24 --> Controller Class Initialized
INFO - 2019-09-22 10:11:24 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-22 10:11:24 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-22 10:11:24 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-22 10:11:24 --> Final output sent to browser
DEBUG - 2019-09-22 10:11:24 --> Total execution time: 0.2054
INFO - 2019-09-22 10:11:24 --> Config Class Initialized
INFO - 2019-09-22 10:11:24 --> Hooks Class Initialized
DEBUG - 2019-09-22 10:11:24 --> UTF-8 Support Enabled
INFO - 2019-09-22 10:11:24 --> Utf8 Class Initialized
INFO - 2019-09-22 10:11:24 --> URI Class Initialized
INFO - 2019-09-22 10:11:24 --> Router Class Initialized
INFO - 2019-09-22 10:11:24 --> Output Class Initialized
INFO - 2019-09-22 10:11:24 --> Security Class Initialized
DEBUG - 2019-09-22 10:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-22 10:11:24 --> Input Class Initialized
INFO - 2019-09-22 10:11:24 --> Language Class Initialized
INFO - 2019-09-22 10:11:24 --> Loader Class Initialized
INFO - 2019-09-22 10:11:24 --> Helper loaded: url_helper
INFO - 2019-09-22 10:11:24 --> Helper loaded: html_helper
INFO - 2019-09-22 10:11:24 --> Helper loaded: form_helper
INFO - 2019-09-22 10:11:24 --> Helper loaded: cookie_helper
INFO - 2019-09-22 10:11:24 --> Helper loaded: date_helper
INFO - 2019-09-22 10:11:24 --> Form Validation Class Initialized
INFO - 2019-09-22 10:11:24 --> Email Class Initialized
DEBUG - 2019-09-22 10:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-22 10:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-22 10:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-22 10:11:24 --> Pagination Class Initialized
INFO - 2019-09-22 10:11:24 --> Database Driver Class Initialized
INFO - 2019-09-22 10:11:24 --> Database Driver Class Initialized
INFO - 2019-09-22 10:11:24 --> Controller Class Initialized
INFO - 2019-09-22 10:11:24 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-22 10:11:24 --> Final output sent to browser
DEBUG - 2019-09-22 10:11:24 --> Total execution time: 0.1935
INFO - 2019-09-22 10:11:33 --> Config Class Initialized
INFO - 2019-09-22 10:11:33 --> Hooks Class Initialized
DEBUG - 2019-09-22 10:11:33 --> UTF-8 Support Enabled
INFO - 2019-09-22 10:11:33 --> Utf8 Class Initialized
INFO - 2019-09-22 10:11:33 --> URI Class Initialized
INFO - 2019-09-22 10:11:33 --> Router Class Initialized
INFO - 2019-09-22 10:11:33 --> Output Class Initialized
INFO - 2019-09-22 10:11:33 --> Security Class Initialized
DEBUG - 2019-09-22 10:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-22 10:11:33 --> Input Class Initialized
INFO - 2019-09-22 10:11:33 --> Language Class Initialized
INFO - 2019-09-22 10:11:33 --> Loader Class Initialized
INFO - 2019-09-22 10:11:33 --> Helper loaded: url_helper
INFO - 2019-09-22 10:11:33 --> Helper loaded: html_helper
INFO - 2019-09-22 10:11:33 --> Helper loaded: form_helper
INFO - 2019-09-22 10:11:33 --> Helper loaded: cookie_helper
INFO - 2019-09-22 10:11:33 --> Helper loaded: date_helper
INFO - 2019-09-22 10:11:33 --> Form Validation Class Initialized
INFO - 2019-09-22 10:11:33 --> Email Class Initialized
DEBUG - 2019-09-22 10:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-22 10:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-22 10:11:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-22 10:11:33 --> Pagination Class Initialized
INFO - 2019-09-22 10:11:33 --> Database Driver Class Initialized
INFO - 2019-09-22 10:11:33 --> Database Driver Class Initialized
INFO - 2019-09-22 10:11:33 --> Controller Class Initialized
INFO - 2019-09-22 10:11:33 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-22 10:11:33 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report.php
INFO - 2019-09-22 10:11:33 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-22 10:11:33 --> Final output sent to browser
DEBUG - 2019-09-22 10:11:33 --> Total execution time: 0.1797
