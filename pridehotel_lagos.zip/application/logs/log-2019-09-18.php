<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-18 19:16:44 --> Config Class Initialized
INFO - 2019-09-18 19:16:44 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:16:44 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:16:44 --> Utf8 Class Initialized
INFO - 2019-09-18 19:16:44 --> URI Class Initialized
INFO - 2019-09-18 19:16:44 --> Router Class Initialized
INFO - 2019-09-18 19:16:44 --> Output Class Initialized
INFO - 2019-09-18 19:16:44 --> Security Class Initialized
DEBUG - 2019-09-18 19:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:16:44 --> Input Class Initialized
INFO - 2019-09-18 19:16:44 --> Language Class Initialized
INFO - 2019-09-18 19:16:44 --> Loader Class Initialized
INFO - 2019-09-18 19:16:44 --> Helper loaded: url_helper
INFO - 2019-09-18 19:16:44 --> Helper loaded: html_helper
INFO - 2019-09-18 19:16:44 --> Helper loaded: form_helper
INFO - 2019-09-18 19:16:44 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:16:44 --> Helper loaded: date_helper
INFO - 2019-09-18 19:16:44 --> Form Validation Class Initialized
INFO - 2019-09-18 19:16:44 --> Email Class Initialized
DEBUG - 2019-09-18 19:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:16:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:16:44 --> Pagination Class Initialized
INFO - 2019-09-18 19:16:45 --> Database Driver Class Initialized
INFO - 2019-09-18 19:16:45 --> Database Driver Class Initialized
INFO - 2019-09-18 19:16:45 --> Controller Class Initialized
INFO - 2019-09-18 19:16:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 19:16:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-18 19:16:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-18 19:16:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 19:16:45 --> Final output sent to browser
DEBUG - 2019-09-18 19:16:45 --> Total execution time: 1.5189
INFO - 2019-09-18 19:16:47 --> Config Class Initialized
INFO - 2019-09-18 19:16:47 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:16:47 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:16:47 --> Utf8 Class Initialized
INFO - 2019-09-18 19:16:47 --> URI Class Initialized
INFO - 2019-09-18 19:16:47 --> Router Class Initialized
INFO - 2019-09-18 19:16:47 --> Output Class Initialized
INFO - 2019-09-18 19:16:47 --> Security Class Initialized
DEBUG - 2019-09-18 19:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:16:47 --> Input Class Initialized
INFO - 2019-09-18 19:16:47 --> Language Class Initialized
INFO - 2019-09-18 19:16:48 --> Loader Class Initialized
INFO - 2019-09-18 19:16:48 --> Helper loaded: url_helper
INFO - 2019-09-18 19:16:48 --> Helper loaded: html_helper
INFO - 2019-09-18 19:16:48 --> Helper loaded: form_helper
INFO - 2019-09-18 19:16:48 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:16:48 --> Helper loaded: date_helper
INFO - 2019-09-18 19:16:48 --> Form Validation Class Initialized
INFO - 2019-09-18 19:16:48 --> Email Class Initialized
DEBUG - 2019-09-18 19:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:16:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:16:48 --> Pagination Class Initialized
INFO - 2019-09-18 19:16:48 --> Database Driver Class Initialized
INFO - 2019-09-18 19:16:48 --> Database Driver Class Initialized
INFO - 2019-09-18 19:16:48 --> Controller Class Initialized
INFO - 2019-09-18 19:16:48 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:16:48 --> Final output sent to browser
DEBUG - 2019-09-18 19:16:48 --> Total execution time: 0.1457
INFO - 2019-09-18 19:16:48 --> Config Class Initialized
INFO - 2019-09-18 19:16:48 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:16:48 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:16:48 --> Utf8 Class Initialized
INFO - 2019-09-18 19:16:48 --> URI Class Initialized
INFO - 2019-09-18 19:16:48 --> Router Class Initialized
INFO - 2019-09-18 19:16:48 --> Output Class Initialized
INFO - 2019-09-18 19:16:48 --> Security Class Initialized
DEBUG - 2019-09-18 19:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:16:48 --> Input Class Initialized
INFO - 2019-09-18 19:16:48 --> Language Class Initialized
INFO - 2019-09-18 19:16:48 --> Loader Class Initialized
INFO - 2019-09-18 19:16:48 --> Helper loaded: url_helper
INFO - 2019-09-18 19:16:48 --> Helper loaded: html_helper
INFO - 2019-09-18 19:16:48 --> Helper loaded: form_helper
INFO - 2019-09-18 19:16:48 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:16:48 --> Helper loaded: date_helper
INFO - 2019-09-18 19:16:48 --> Form Validation Class Initialized
INFO - 2019-09-18 19:16:48 --> Email Class Initialized
DEBUG - 2019-09-18 19:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:16:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:16:48 --> Pagination Class Initialized
INFO - 2019-09-18 19:16:48 --> Database Driver Class Initialized
INFO - 2019-09-18 19:16:48 --> Database Driver Class Initialized
INFO - 2019-09-18 19:16:48 --> Controller Class Initialized
INFO - 2019-09-18 19:16:48 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:16:48 --> Final output sent to browser
DEBUG - 2019-09-18 19:16:48 --> Total execution time: 0.0785
INFO - 2019-09-18 19:18:12 --> Config Class Initialized
INFO - 2019-09-18 19:18:12 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:18:12 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:18:12 --> Utf8 Class Initialized
INFO - 2019-09-18 19:18:12 --> URI Class Initialized
INFO - 2019-09-18 19:18:12 --> Router Class Initialized
INFO - 2019-09-18 19:18:12 --> Output Class Initialized
INFO - 2019-09-18 19:18:12 --> Security Class Initialized
DEBUG - 2019-09-18 19:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:18:12 --> Input Class Initialized
INFO - 2019-09-18 19:18:12 --> Language Class Initialized
INFO - 2019-09-18 19:18:12 --> Loader Class Initialized
INFO - 2019-09-18 19:18:12 --> Helper loaded: url_helper
INFO - 2019-09-18 19:18:12 --> Helper loaded: html_helper
INFO - 2019-09-18 19:18:12 --> Helper loaded: form_helper
INFO - 2019-09-18 19:18:12 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:18:12 --> Helper loaded: date_helper
INFO - 2019-09-18 19:18:12 --> Form Validation Class Initialized
INFO - 2019-09-18 19:18:12 --> Email Class Initialized
DEBUG - 2019-09-18 19:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:18:12 --> Pagination Class Initialized
INFO - 2019-09-18 19:18:12 --> Database Driver Class Initialized
INFO - 2019-09-18 19:18:12 --> Database Driver Class Initialized
INFO - 2019-09-18 19:18:12 --> Controller Class Initialized
INFO - 2019-09-18 19:18:12 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:18:12 --> Final output sent to browser
DEBUG - 2019-09-18 19:18:12 --> Total execution time: 0.0617
INFO - 2019-09-18 19:18:13 --> Config Class Initialized
INFO - 2019-09-18 19:18:13 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:18:13 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:18:13 --> Utf8 Class Initialized
INFO - 2019-09-18 19:18:13 --> URI Class Initialized
INFO - 2019-09-18 19:18:13 --> Router Class Initialized
INFO - 2019-09-18 19:18:13 --> Output Class Initialized
INFO - 2019-09-18 19:18:13 --> Security Class Initialized
DEBUG - 2019-09-18 19:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:18:13 --> Input Class Initialized
INFO - 2019-09-18 19:18:13 --> Language Class Initialized
INFO - 2019-09-18 19:18:13 --> Loader Class Initialized
INFO - 2019-09-18 19:18:13 --> Helper loaded: url_helper
INFO - 2019-09-18 19:18:13 --> Helper loaded: html_helper
INFO - 2019-09-18 19:18:13 --> Helper loaded: form_helper
INFO - 2019-09-18 19:18:13 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:18:13 --> Helper loaded: date_helper
INFO - 2019-09-18 19:18:13 --> Form Validation Class Initialized
INFO - 2019-09-18 19:18:13 --> Email Class Initialized
DEBUG - 2019-09-18 19:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:18:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:18:13 --> Pagination Class Initialized
INFO - 2019-09-18 19:18:13 --> Database Driver Class Initialized
INFO - 2019-09-18 19:18:13 --> Database Driver Class Initialized
INFO - 2019-09-18 19:18:13 --> Controller Class Initialized
INFO - 2019-09-18 19:18:13 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 19:18:13 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-18 19:18:13 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 19:18:13 --> Final output sent to browser
DEBUG - 2019-09-18 19:18:13 --> Total execution time: 0.1128
INFO - 2019-09-18 19:18:13 --> Config Class Initialized
INFO - 2019-09-18 19:18:13 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:18:13 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:18:13 --> Utf8 Class Initialized
INFO - 2019-09-18 19:18:13 --> URI Class Initialized
INFO - 2019-09-18 19:18:13 --> Router Class Initialized
INFO - 2019-09-18 19:18:13 --> Output Class Initialized
INFO - 2019-09-18 19:18:13 --> Security Class Initialized
DEBUG - 2019-09-18 19:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:18:13 --> Input Class Initialized
INFO - 2019-09-18 19:18:13 --> Language Class Initialized
INFO - 2019-09-18 19:18:13 --> Loader Class Initialized
INFO - 2019-09-18 19:18:13 --> Helper loaded: url_helper
INFO - 2019-09-18 19:18:13 --> Helper loaded: html_helper
INFO - 2019-09-18 19:18:13 --> Helper loaded: form_helper
INFO - 2019-09-18 19:18:13 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:18:13 --> Helper loaded: date_helper
INFO - 2019-09-18 19:18:13 --> Form Validation Class Initialized
INFO - 2019-09-18 19:18:13 --> Email Class Initialized
DEBUG - 2019-09-18 19:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:18:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:18:13 --> Pagination Class Initialized
INFO - 2019-09-18 19:18:13 --> Database Driver Class Initialized
INFO - 2019-09-18 19:18:13 --> Database Driver Class Initialized
INFO - 2019-09-18 19:18:13 --> Controller Class Initialized
INFO - 2019-09-18 19:18:13 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:18:13 --> Final output sent to browser
DEBUG - 2019-09-18 19:18:13 --> Total execution time: 0.0642
INFO - 2019-09-18 19:18:22 --> Config Class Initialized
INFO - 2019-09-18 19:18:22 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:18:22 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:18:22 --> Utf8 Class Initialized
INFO - 2019-09-18 19:18:22 --> URI Class Initialized
INFO - 2019-09-18 19:18:22 --> Router Class Initialized
INFO - 2019-09-18 19:18:22 --> Output Class Initialized
INFO - 2019-09-18 19:18:22 --> Security Class Initialized
DEBUG - 2019-09-18 19:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:18:22 --> Input Class Initialized
INFO - 2019-09-18 19:18:22 --> Language Class Initialized
INFO - 2019-09-18 19:18:22 --> Loader Class Initialized
INFO - 2019-09-18 19:18:22 --> Helper loaded: url_helper
INFO - 2019-09-18 19:18:22 --> Helper loaded: html_helper
INFO - 2019-09-18 19:18:22 --> Helper loaded: form_helper
INFO - 2019-09-18 19:18:22 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:18:22 --> Helper loaded: date_helper
INFO - 2019-09-18 19:18:22 --> Form Validation Class Initialized
INFO - 2019-09-18 19:18:22 --> Email Class Initialized
DEBUG - 2019-09-18 19:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:18:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:18:22 --> Pagination Class Initialized
INFO - 2019-09-18 19:18:22 --> Database Driver Class Initialized
INFO - 2019-09-18 19:18:22 --> Database Driver Class Initialized
INFO - 2019-09-18 19:18:22 --> Controller Class Initialized
INFO - 2019-09-18 19:18:22 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:18:22 --> Final output sent to browser
DEBUG - 2019-09-18 19:18:22 --> Total execution time: 0.0636
INFO - 2019-09-18 19:18:25 --> Config Class Initialized
INFO - 2019-09-18 19:18:25 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:18:25 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:18:25 --> Utf8 Class Initialized
INFO - 2019-09-18 19:18:25 --> URI Class Initialized
INFO - 2019-09-18 19:18:25 --> Router Class Initialized
INFO - 2019-09-18 19:18:25 --> Output Class Initialized
INFO - 2019-09-18 19:18:25 --> Security Class Initialized
DEBUG - 2019-09-18 19:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:18:25 --> Input Class Initialized
INFO - 2019-09-18 19:18:25 --> Language Class Initialized
INFO - 2019-09-18 19:18:25 --> Loader Class Initialized
INFO - 2019-09-18 19:18:25 --> Helper loaded: url_helper
INFO - 2019-09-18 19:18:25 --> Helper loaded: html_helper
INFO - 2019-09-18 19:18:25 --> Helper loaded: form_helper
INFO - 2019-09-18 19:18:25 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:18:25 --> Helper loaded: date_helper
INFO - 2019-09-18 19:18:25 --> Form Validation Class Initialized
INFO - 2019-09-18 19:18:25 --> Email Class Initialized
DEBUG - 2019-09-18 19:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:18:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:18:25 --> Pagination Class Initialized
INFO - 2019-09-18 19:18:25 --> Database Driver Class Initialized
INFO - 2019-09-18 19:18:25 --> Database Driver Class Initialized
INFO - 2019-09-18 19:18:25 --> Controller Class Initialized
INFO - 2019-09-18 19:18:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-18 19:18:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report.php
INFO - 2019-09-18 19:18:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 19:18:25 --> Final output sent to browser
DEBUG - 2019-09-18 19:18:25 --> Total execution time: 0.2226
INFO - 2019-09-18 19:20:20 --> Config Class Initialized
INFO - 2019-09-18 19:20:20 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:20:20 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:20:20 --> Utf8 Class Initialized
INFO - 2019-09-18 19:20:20 --> URI Class Initialized
INFO - 2019-09-18 19:20:20 --> Router Class Initialized
INFO - 2019-09-18 19:20:20 --> Output Class Initialized
INFO - 2019-09-18 19:20:20 --> Security Class Initialized
DEBUG - 2019-09-18 19:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:20:20 --> Input Class Initialized
INFO - 2019-09-18 19:20:20 --> Language Class Initialized
INFO - 2019-09-18 19:20:20 --> Loader Class Initialized
INFO - 2019-09-18 19:20:20 --> Helper loaded: url_helper
INFO - 2019-09-18 19:20:20 --> Helper loaded: html_helper
INFO - 2019-09-18 19:20:20 --> Helper loaded: form_helper
INFO - 2019-09-18 19:20:20 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:20:20 --> Helper loaded: date_helper
INFO - 2019-09-18 19:20:20 --> Form Validation Class Initialized
INFO - 2019-09-18 19:20:20 --> Email Class Initialized
DEBUG - 2019-09-18 19:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:20:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:20:20 --> Pagination Class Initialized
INFO - 2019-09-18 19:20:20 --> Database Driver Class Initialized
INFO - 2019-09-18 19:20:20 --> Database Driver Class Initialized
INFO - 2019-09-18 19:20:20 --> Controller Class Initialized
INFO - 2019-09-18 19:24:34 --> Config Class Initialized
INFO - 2019-09-18 19:24:34 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:24:34 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:24:34 --> Utf8 Class Initialized
INFO - 2019-09-18 19:24:34 --> URI Class Initialized
INFO - 2019-09-18 19:24:34 --> Router Class Initialized
INFO - 2019-09-18 19:24:34 --> Output Class Initialized
INFO - 2019-09-18 19:24:34 --> Security Class Initialized
DEBUG - 2019-09-18 19:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:24:34 --> Input Class Initialized
INFO - 2019-09-18 19:24:34 --> Language Class Initialized
INFO - 2019-09-18 19:24:34 --> Loader Class Initialized
INFO - 2019-09-18 19:24:34 --> Helper loaded: url_helper
INFO - 2019-09-18 19:24:34 --> Helper loaded: html_helper
INFO - 2019-09-18 19:24:34 --> Helper loaded: form_helper
INFO - 2019-09-18 19:24:34 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:24:34 --> Helper loaded: date_helper
INFO - 2019-09-18 19:24:34 --> Form Validation Class Initialized
INFO - 2019-09-18 19:24:34 --> Email Class Initialized
DEBUG - 2019-09-18 19:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:24:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:24:34 --> Pagination Class Initialized
INFO - 2019-09-18 19:24:34 --> Database Driver Class Initialized
INFO - 2019-09-18 19:24:34 --> Database Driver Class Initialized
INFO - 2019-09-18 19:24:34 --> Controller Class Initialized
INFO - 2019-09-18 19:24:34 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-18 19:24:34 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report.php
INFO - 2019-09-18 19:24:34 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 19:24:34 --> Final output sent to browser
DEBUG - 2019-09-18 19:24:34 --> Total execution time: 0.0675
INFO - 2019-09-18 19:32:45 --> Config Class Initialized
INFO - 2019-09-18 19:32:45 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:32:45 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:32:45 --> Utf8 Class Initialized
INFO - 2019-09-18 19:32:45 --> URI Class Initialized
INFO - 2019-09-18 19:32:45 --> Router Class Initialized
INFO - 2019-09-18 19:32:45 --> Output Class Initialized
INFO - 2019-09-18 19:32:45 --> Security Class Initialized
DEBUG - 2019-09-18 19:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:32:45 --> Input Class Initialized
INFO - 2019-09-18 19:32:45 --> Language Class Initialized
INFO - 2019-09-18 19:32:45 --> Loader Class Initialized
INFO - 2019-09-18 19:32:45 --> Helper loaded: url_helper
INFO - 2019-09-18 19:32:45 --> Helper loaded: html_helper
INFO - 2019-09-18 19:32:45 --> Helper loaded: form_helper
INFO - 2019-09-18 19:32:45 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:32:45 --> Helper loaded: date_helper
INFO - 2019-09-18 19:32:45 --> Form Validation Class Initialized
INFO - 2019-09-18 19:32:45 --> Email Class Initialized
DEBUG - 2019-09-18 19:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:32:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:32:45 --> Pagination Class Initialized
INFO - 2019-09-18 19:32:45 --> Database Driver Class Initialized
INFO - 2019-09-18 19:32:45 --> Database Driver Class Initialized
INFO - 2019-09-18 19:32:45 --> Controller Class Initialized
INFO - 2019-09-18 19:32:45 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-18 19:34:29 --> Config Class Initialized
INFO - 2019-09-18 19:34:29 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:34:29 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:34:29 --> Utf8 Class Initialized
INFO - 2019-09-18 19:34:29 --> URI Class Initialized
INFO - 2019-09-18 19:34:29 --> Router Class Initialized
INFO - 2019-09-18 19:34:29 --> Output Class Initialized
INFO - 2019-09-18 19:34:29 --> Security Class Initialized
DEBUG - 2019-09-18 19:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:34:29 --> Input Class Initialized
INFO - 2019-09-18 19:34:29 --> Language Class Initialized
INFO - 2019-09-18 19:34:29 --> Loader Class Initialized
INFO - 2019-09-18 19:34:29 --> Helper loaded: url_helper
INFO - 2019-09-18 19:34:29 --> Helper loaded: html_helper
INFO - 2019-09-18 19:34:29 --> Helper loaded: form_helper
INFO - 2019-09-18 19:34:29 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:34:29 --> Helper loaded: date_helper
INFO - 2019-09-18 19:34:29 --> Form Validation Class Initialized
INFO - 2019-09-18 19:34:29 --> Email Class Initialized
DEBUG - 2019-09-18 19:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:34:29 --> Pagination Class Initialized
INFO - 2019-09-18 19:34:29 --> Database Driver Class Initialized
INFO - 2019-09-18 19:34:29 --> Database Driver Class Initialized
INFO - 2019-09-18 19:34:29 --> Controller Class Initialized
INFO - 2019-09-18 19:41:47 --> Config Class Initialized
INFO - 2019-09-18 19:41:47 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:41:47 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:41:47 --> Utf8 Class Initialized
INFO - 2019-09-18 19:41:47 --> URI Class Initialized
INFO - 2019-09-18 19:41:47 --> Router Class Initialized
INFO - 2019-09-18 19:41:47 --> Output Class Initialized
INFO - 2019-09-18 19:41:47 --> Security Class Initialized
DEBUG - 2019-09-18 19:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:41:47 --> Input Class Initialized
INFO - 2019-09-18 19:41:47 --> Language Class Initialized
INFO - 2019-09-18 19:41:47 --> Loader Class Initialized
INFO - 2019-09-18 19:41:47 --> Helper loaded: url_helper
INFO - 2019-09-18 19:41:47 --> Helper loaded: html_helper
INFO - 2019-09-18 19:41:47 --> Helper loaded: form_helper
INFO - 2019-09-18 19:41:47 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:41:47 --> Helper loaded: date_helper
INFO - 2019-09-18 19:41:47 --> Form Validation Class Initialized
INFO - 2019-09-18 19:41:47 --> Email Class Initialized
DEBUG - 2019-09-18 19:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:41:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:41:47 --> Pagination Class Initialized
INFO - 2019-09-18 19:41:47 --> Database Driver Class Initialized
INFO - 2019-09-18 19:41:47 --> Database Driver Class Initialized
INFO - 2019-09-18 19:41:47 --> Controller Class Initialized
INFO - 2019-09-18 19:42:31 --> Config Class Initialized
INFO - 2019-09-18 19:42:31 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:42:31 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:42:31 --> Utf8 Class Initialized
INFO - 2019-09-18 19:42:31 --> URI Class Initialized
INFO - 2019-09-18 19:42:31 --> Router Class Initialized
INFO - 2019-09-18 19:42:31 --> Output Class Initialized
INFO - 2019-09-18 19:42:31 --> Security Class Initialized
DEBUG - 2019-09-18 19:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:42:31 --> Input Class Initialized
INFO - 2019-09-18 19:42:31 --> Language Class Initialized
INFO - 2019-09-18 19:42:31 --> Loader Class Initialized
INFO - 2019-09-18 19:42:31 --> Helper loaded: url_helper
INFO - 2019-09-18 19:42:31 --> Helper loaded: html_helper
INFO - 2019-09-18 19:42:31 --> Helper loaded: form_helper
INFO - 2019-09-18 19:42:31 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:42:31 --> Helper loaded: date_helper
INFO - 2019-09-18 19:42:31 --> Form Validation Class Initialized
INFO - 2019-09-18 19:42:31 --> Email Class Initialized
DEBUG - 2019-09-18 19:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:42:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:42:31 --> Pagination Class Initialized
INFO - 2019-09-18 19:42:31 --> Database Driver Class Initialized
INFO - 2019-09-18 19:42:31 --> Database Driver Class Initialized
INFO - 2019-09-18 19:42:31 --> Controller Class Initialized
INFO - 2019-09-18 19:44:09 --> Config Class Initialized
INFO - 2019-09-18 19:44:09 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:09 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:09 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:09 --> URI Class Initialized
INFO - 2019-09-18 19:44:09 --> Router Class Initialized
INFO - 2019-09-18 19:44:09 --> Output Class Initialized
INFO - 2019-09-18 19:44:09 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:09 --> Input Class Initialized
INFO - 2019-09-18 19:44:09 --> Language Class Initialized
INFO - 2019-09-18 19:44:09 --> Loader Class Initialized
INFO - 2019-09-18 19:44:09 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:09 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:09 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:09 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:09 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:09 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:09 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:09 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:09 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:09 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:09 --> Controller Class Initialized
INFO - 2019-09-18 19:44:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 19:44:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-18 19:44:09 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 19:44:09 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:09 --> Total execution time: 0.0561
INFO - 2019-09-18 19:44:10 --> Config Class Initialized
INFO - 2019-09-18 19:44:10 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:10 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:10 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:10 --> URI Class Initialized
INFO - 2019-09-18 19:44:10 --> Router Class Initialized
INFO - 2019-09-18 19:44:10 --> Output Class Initialized
INFO - 2019-09-18 19:44:10 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:10 --> Input Class Initialized
INFO - 2019-09-18 19:44:10 --> Language Class Initialized
INFO - 2019-09-18 19:44:10 --> Loader Class Initialized
INFO - 2019-09-18 19:44:10 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:10 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:10 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:10 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:10 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:10 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:10 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:10 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:10 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:10 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:10 --> Controller Class Initialized
INFO - 2019-09-18 19:44:10 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:44:10 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:10 --> Total execution time: 0.0719
INFO - 2019-09-18 19:44:11 --> Config Class Initialized
INFO - 2019-09-18 19:44:11 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:11 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:11 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:11 --> URI Class Initialized
INFO - 2019-09-18 19:44:11 --> Router Class Initialized
INFO - 2019-09-18 19:44:11 --> Output Class Initialized
INFO - 2019-09-18 19:44:11 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:11 --> Input Class Initialized
INFO - 2019-09-18 19:44:11 --> Language Class Initialized
INFO - 2019-09-18 19:44:11 --> Loader Class Initialized
INFO - 2019-09-18 19:44:11 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:11 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:11 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:11 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:11 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:11 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:11 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:11 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:11 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:11 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:11 --> Controller Class Initialized
INFO - 2019-09-18 19:44:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:44:11 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:11 --> Total execution time: 0.0631
INFO - 2019-09-18 19:44:12 --> Config Class Initialized
INFO - 2019-09-18 19:44:12 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:12 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:12 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:12 --> URI Class Initialized
INFO - 2019-09-18 19:44:12 --> Router Class Initialized
INFO - 2019-09-18 19:44:12 --> Output Class Initialized
INFO - 2019-09-18 19:44:12 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:12 --> Input Class Initialized
INFO - 2019-09-18 19:44:12 --> Language Class Initialized
INFO - 2019-09-18 19:44:12 --> Loader Class Initialized
INFO - 2019-09-18 19:44:12 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:12 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:12 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:12 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:12 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:12 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:12 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:12 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:12 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:12 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:12 --> Controller Class Initialized
INFO - 2019-09-18 19:44:12 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:44:12 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:12 --> Total execution time: 0.0495
INFO - 2019-09-18 19:44:12 --> Config Class Initialized
INFO - 2019-09-18 19:44:12 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:12 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:12 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:12 --> URI Class Initialized
INFO - 2019-09-18 19:44:12 --> Router Class Initialized
INFO - 2019-09-18 19:44:12 --> Output Class Initialized
INFO - 2019-09-18 19:44:12 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:12 --> Input Class Initialized
INFO - 2019-09-18 19:44:12 --> Language Class Initialized
INFO - 2019-09-18 19:44:12 --> Loader Class Initialized
INFO - 2019-09-18 19:44:12 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:12 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:12 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:12 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:12 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:12 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:12 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:12 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:12 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:12 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:12 --> Controller Class Initialized
INFO - 2019-09-18 19:44:12 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:44:12 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:12 --> Total execution time: 0.0469
INFO - 2019-09-18 19:44:13 --> Config Class Initialized
INFO - 2019-09-18 19:44:13 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:13 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:13 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:13 --> URI Class Initialized
INFO - 2019-09-18 19:44:13 --> Router Class Initialized
INFO - 2019-09-18 19:44:13 --> Output Class Initialized
INFO - 2019-09-18 19:44:13 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:13 --> Input Class Initialized
INFO - 2019-09-18 19:44:13 --> Language Class Initialized
INFO - 2019-09-18 19:44:13 --> Loader Class Initialized
INFO - 2019-09-18 19:44:13 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:13 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:13 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:13 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:13 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:13 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:13 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:13 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:13 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:13 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:13 --> Controller Class Initialized
INFO - 2019-09-18 19:44:13 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 19:44:13 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-18 19:44:13 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 19:44:13 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:13 --> Total execution time: 0.0545
INFO - 2019-09-18 19:44:13 --> Config Class Initialized
INFO - 2019-09-18 19:44:13 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:13 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:13 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:13 --> URI Class Initialized
INFO - 2019-09-18 19:44:13 --> Router Class Initialized
INFO - 2019-09-18 19:44:13 --> Output Class Initialized
INFO - 2019-09-18 19:44:13 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:13 --> Input Class Initialized
INFO - 2019-09-18 19:44:13 --> Language Class Initialized
INFO - 2019-09-18 19:44:13 --> Loader Class Initialized
INFO - 2019-09-18 19:44:13 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:13 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:13 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:13 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:13 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:13 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:13 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:13 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:13 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:13 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:13 --> Controller Class Initialized
INFO - 2019-09-18 19:44:13 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:44:13 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:13 --> Total execution time: 0.0657
INFO - 2019-09-18 19:44:13 --> Config Class Initialized
INFO - 2019-09-18 19:44:13 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:13 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:13 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:13 --> URI Class Initialized
INFO - 2019-09-18 19:44:13 --> Router Class Initialized
INFO - 2019-09-18 19:44:13 --> Output Class Initialized
INFO - 2019-09-18 19:44:13 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:13 --> Input Class Initialized
INFO - 2019-09-18 19:44:13 --> Language Class Initialized
INFO - 2019-09-18 19:44:13 --> Loader Class Initialized
INFO - 2019-09-18 19:44:13 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:13 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:13 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:13 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:13 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:13 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:13 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:13 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:13 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:13 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:13 --> Controller Class Initialized
INFO - 2019-09-18 19:44:13 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:44:13 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:13 --> Total execution time: 0.0873
INFO - 2019-09-18 19:44:14 --> Config Class Initialized
INFO - 2019-09-18 19:44:14 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:14 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:14 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:14 --> URI Class Initialized
INFO - 2019-09-18 19:44:14 --> Router Class Initialized
INFO - 2019-09-18 19:44:14 --> Output Class Initialized
INFO - 2019-09-18 19:44:14 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:14 --> Input Class Initialized
INFO - 2019-09-18 19:44:14 --> Language Class Initialized
INFO - 2019-09-18 19:44:14 --> Loader Class Initialized
INFO - 2019-09-18 19:44:14 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:14 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:14 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:14 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:14 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:14 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:14 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:14 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:14 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:14 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:14 --> Controller Class Initialized
INFO - 2019-09-18 19:44:14 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 19:44:14 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-18 19:44:14 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-18 19:44:14 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 19:44:14 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:14 --> Total execution time: 0.0895
INFO - 2019-09-18 19:44:14 --> Config Class Initialized
INFO - 2019-09-18 19:44:14 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:14 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:14 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:14 --> URI Class Initialized
INFO - 2019-09-18 19:44:14 --> Router Class Initialized
INFO - 2019-09-18 19:44:14 --> Output Class Initialized
INFO - 2019-09-18 19:44:14 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:14 --> Input Class Initialized
INFO - 2019-09-18 19:44:14 --> Language Class Initialized
INFO - 2019-09-18 19:44:14 --> Loader Class Initialized
INFO - 2019-09-18 19:44:14 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:14 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:14 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:14 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:14 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:14 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:14 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:14 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:14 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:14 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:14 --> Controller Class Initialized
INFO - 2019-09-18 19:44:14 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:44:14 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:14 --> Total execution time: 0.0598
INFO - 2019-09-18 19:44:14 --> Config Class Initialized
INFO - 2019-09-18 19:44:14 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:14 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:14 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:14 --> URI Class Initialized
INFO - 2019-09-18 19:44:14 --> Router Class Initialized
INFO - 2019-09-18 19:44:14 --> Output Class Initialized
INFO - 2019-09-18 19:44:14 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:14 --> Input Class Initialized
INFO - 2019-09-18 19:44:14 --> Language Class Initialized
INFO - 2019-09-18 19:44:14 --> Loader Class Initialized
INFO - 2019-09-18 19:44:14 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:14 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:14 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:14 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:14 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:14 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:14 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:14 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:14 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:14 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:14 --> Controller Class Initialized
INFO - 2019-09-18 19:44:14 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:44:14 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:14 --> Total execution time: 0.0622
INFO - 2019-09-18 19:44:28 --> Config Class Initialized
INFO - 2019-09-18 19:44:28 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:28 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:28 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:28 --> URI Class Initialized
INFO - 2019-09-18 19:44:28 --> Router Class Initialized
INFO - 2019-09-18 19:44:28 --> Output Class Initialized
INFO - 2019-09-18 19:44:28 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:28 --> Input Class Initialized
INFO - 2019-09-18 19:44:28 --> Language Class Initialized
INFO - 2019-09-18 19:44:28 --> Loader Class Initialized
INFO - 2019-09-18 19:44:28 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:28 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:28 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:28 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:28 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:28 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:28 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:28 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:28 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:28 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:28 --> Controller Class Initialized
ERROR - 2019-09-18 19:44:28 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-18 19:44:28 --> Config Class Initialized
INFO - 2019-09-18 19:44:28 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:28 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:28 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:28 --> URI Class Initialized
INFO - 2019-09-18 19:44:28 --> Router Class Initialized
INFO - 2019-09-18 19:44:28 --> Output Class Initialized
INFO - 2019-09-18 19:44:28 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:28 --> Input Class Initialized
INFO - 2019-09-18 19:44:28 --> Language Class Initialized
INFO - 2019-09-18 19:44:28 --> Loader Class Initialized
INFO - 2019-09-18 19:44:28 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:28 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:28 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:28 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:28 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:28 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:28 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:28 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:28 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:28 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:28 --> Controller Class Initialized
ERROR - 2019-09-18 19:44:28 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-18 19:44:28 --> Config Class Initialized
INFO - 2019-09-18 19:44:28 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:28 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:28 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:28 --> URI Class Initialized
INFO - 2019-09-18 19:44:28 --> Router Class Initialized
INFO - 2019-09-18 19:44:28 --> Output Class Initialized
INFO - 2019-09-18 19:44:28 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:28 --> Input Class Initialized
INFO - 2019-09-18 19:44:28 --> Language Class Initialized
INFO - 2019-09-18 19:44:28 --> Loader Class Initialized
INFO - 2019-09-18 19:44:28 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:28 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:28 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:28 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:28 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:28 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:28 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:28 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:28 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:28 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:28 --> Controller Class Initialized
ERROR - 2019-09-18 19:44:28 --> Severity: error --> Exception: Call to undefined method Resv_model::search() C:\wamp64\www\pridehotel_lagos\application\controllers\Resv.php 16
INFO - 2019-09-18 19:44:38 --> Config Class Initialized
INFO - 2019-09-18 19:44:38 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:38 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:38 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:38 --> URI Class Initialized
INFO - 2019-09-18 19:44:38 --> Router Class Initialized
INFO - 2019-09-18 19:44:38 --> Output Class Initialized
INFO - 2019-09-18 19:44:38 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:38 --> Input Class Initialized
INFO - 2019-09-18 19:44:38 --> Language Class Initialized
INFO - 2019-09-18 19:44:38 --> Loader Class Initialized
INFO - 2019-09-18 19:44:38 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:38 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:38 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:38 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:38 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:38 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:38 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:38 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:38 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:38 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:38 --> Controller Class Initialized
INFO - 2019-09-18 19:44:39 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:39 --> Total execution time: 0.2241
INFO - 2019-09-18 19:44:42 --> Config Class Initialized
INFO - 2019-09-18 19:44:42 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:42 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:42 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:42 --> URI Class Initialized
INFO - 2019-09-18 19:44:42 --> Router Class Initialized
INFO - 2019-09-18 19:44:42 --> Output Class Initialized
INFO - 2019-09-18 19:44:42 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:42 --> Input Class Initialized
INFO - 2019-09-18 19:44:42 --> Language Class Initialized
INFO - 2019-09-18 19:44:42 --> Loader Class Initialized
INFO - 2019-09-18 19:44:42 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:42 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:42 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:42 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:42 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:42 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:42 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:42 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:42 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:42 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:42 --> Controller Class Initialized
INFO - 2019-09-18 19:44:42 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:42 --> Total execution time: 0.0540
INFO - 2019-09-18 19:44:46 --> Config Class Initialized
INFO - 2019-09-18 19:44:46 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:46 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:46 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:46 --> URI Class Initialized
INFO - 2019-09-18 19:44:46 --> Router Class Initialized
INFO - 2019-09-18 19:44:46 --> Output Class Initialized
INFO - 2019-09-18 19:44:46 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:46 --> Input Class Initialized
INFO - 2019-09-18 19:44:46 --> Language Class Initialized
INFO - 2019-09-18 19:44:46 --> Loader Class Initialized
INFO - 2019-09-18 19:44:46 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:46 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:46 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:46 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:46 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:46 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:46 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:46 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:46 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:46 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:46 --> Controller Class Initialized
INFO - 2019-09-18 19:44:46 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:46 --> Total execution time: 0.0525
INFO - 2019-09-18 19:44:51 --> Config Class Initialized
INFO - 2019-09-18 19:44:51 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:51 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:51 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:51 --> URI Class Initialized
INFO - 2019-09-18 19:44:51 --> Router Class Initialized
INFO - 2019-09-18 19:44:51 --> Output Class Initialized
INFO - 2019-09-18 19:44:51 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:51 --> Input Class Initialized
INFO - 2019-09-18 19:44:51 --> Language Class Initialized
INFO - 2019-09-18 19:44:51 --> Loader Class Initialized
INFO - 2019-09-18 19:44:51 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:51 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:51 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:51 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:51 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:51 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:51 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:51 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:51 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:51 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:51 --> Controller Class Initialized
INFO - 2019-09-18 19:44:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-18 19:44:51 --> Config Class Initialized
INFO - 2019-09-18 19:44:51 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:51 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:51 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:51 --> URI Class Initialized
INFO - 2019-09-18 19:44:51 --> Router Class Initialized
INFO - 2019-09-18 19:44:51 --> Output Class Initialized
INFO - 2019-09-18 19:44:51 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:51 --> Input Class Initialized
INFO - 2019-09-18 19:44:51 --> Language Class Initialized
INFO - 2019-09-18 19:44:51 --> Loader Class Initialized
INFO - 2019-09-18 19:44:51 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:51 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:51 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:51 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:51 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:51 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:51 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:51 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:51 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:51 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:51 --> Controller Class Initialized
INFO - 2019-09-18 19:44:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 19:44:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-18 19:44:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/reservation.php
INFO - 2019-09-18 19:44:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 19:44:51 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:51 --> Total execution time: 0.0634
INFO - 2019-09-18 19:44:51 --> Config Class Initialized
INFO - 2019-09-18 19:44:51 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:51 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:51 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:51 --> URI Class Initialized
INFO - 2019-09-18 19:44:51 --> Router Class Initialized
INFO - 2019-09-18 19:44:51 --> Output Class Initialized
INFO - 2019-09-18 19:44:51 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:51 --> Input Class Initialized
INFO - 2019-09-18 19:44:51 --> Language Class Initialized
INFO - 2019-09-18 19:44:51 --> Loader Class Initialized
INFO - 2019-09-18 19:44:51 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:51 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:51 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:51 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:51 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:51 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:51 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:51 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:51 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:51 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:51 --> Controller Class Initialized
INFO - 2019-09-18 19:44:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:44:51 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:51 --> Total execution time: 0.0600
INFO - 2019-09-18 19:44:51 --> Config Class Initialized
INFO - 2019-09-18 19:44:51 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:51 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:51 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:51 --> URI Class Initialized
INFO - 2019-09-18 19:44:51 --> Router Class Initialized
INFO - 2019-09-18 19:44:51 --> Output Class Initialized
INFO - 2019-09-18 19:44:51 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:51 --> Input Class Initialized
INFO - 2019-09-18 19:44:51 --> Language Class Initialized
INFO - 2019-09-18 19:44:51 --> Loader Class Initialized
INFO - 2019-09-18 19:44:51 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:51 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:51 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:51 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:51 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:51 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:51 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:51 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:51 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:51 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:51 --> Controller Class Initialized
INFO - 2019-09-18 19:44:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:44:51 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:51 --> Total execution time: 0.0614
INFO - 2019-09-18 19:44:53 --> Config Class Initialized
INFO - 2019-09-18 19:44:53 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:53 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:53 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:53 --> URI Class Initialized
INFO - 2019-09-18 19:44:53 --> Router Class Initialized
INFO - 2019-09-18 19:44:53 --> Output Class Initialized
INFO - 2019-09-18 19:44:53 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:53 --> Input Class Initialized
INFO - 2019-09-18 19:44:53 --> Language Class Initialized
INFO - 2019-09-18 19:44:53 --> Loader Class Initialized
INFO - 2019-09-18 19:44:53 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:53 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:53 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:53 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:53 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:53 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:53 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:53 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:53 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:53 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:53 --> Controller Class Initialized
INFO - 2019-09-18 19:44:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-09-18 19:44:53 --> Config Class Initialized
INFO - 2019-09-18 19:44:53 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:53 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:53 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:53 --> URI Class Initialized
INFO - 2019-09-18 19:44:53 --> Router Class Initialized
INFO - 2019-09-18 19:44:53 --> Output Class Initialized
INFO - 2019-09-18 19:44:53 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:53 --> Input Class Initialized
INFO - 2019-09-18 19:44:53 --> Language Class Initialized
INFO - 2019-09-18 19:44:53 --> Loader Class Initialized
INFO - 2019-09-18 19:44:53 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:53 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:53 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:53 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:53 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:53 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:53 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:53 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:53 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:53 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:53 --> Controller Class Initialized
INFO - 2019-09-18 19:44:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 19:44:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-09-18 19:44:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/guest.php
INFO - 2019-09-18 19:44:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 19:44:53 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:53 --> Total execution time: 0.0596
INFO - 2019-09-18 19:44:53 --> Config Class Initialized
INFO - 2019-09-18 19:44:53 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:53 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:53 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:53 --> URI Class Initialized
INFO - 2019-09-18 19:44:53 --> Router Class Initialized
INFO - 2019-09-18 19:44:53 --> Output Class Initialized
INFO - 2019-09-18 19:44:53 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:53 --> Input Class Initialized
INFO - 2019-09-18 19:44:53 --> Language Class Initialized
INFO - 2019-09-18 19:44:53 --> Loader Class Initialized
INFO - 2019-09-18 19:44:53 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:53 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:53 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:53 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:53 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:53 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:53 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:53 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:53 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:53 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:53 --> Controller Class Initialized
INFO - 2019-09-18 19:44:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:44:53 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:53 --> Total execution time: 0.0614
INFO - 2019-09-18 19:44:53 --> Config Class Initialized
INFO - 2019-09-18 19:44:53 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:44:53 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:44:53 --> Utf8 Class Initialized
INFO - 2019-09-18 19:44:53 --> URI Class Initialized
INFO - 2019-09-18 19:44:53 --> Router Class Initialized
INFO - 2019-09-18 19:44:53 --> Output Class Initialized
INFO - 2019-09-18 19:44:53 --> Security Class Initialized
DEBUG - 2019-09-18 19:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:44:53 --> Input Class Initialized
INFO - 2019-09-18 19:44:53 --> Language Class Initialized
INFO - 2019-09-18 19:44:53 --> Loader Class Initialized
INFO - 2019-09-18 19:44:53 --> Helper loaded: url_helper
INFO - 2019-09-18 19:44:53 --> Helper loaded: html_helper
INFO - 2019-09-18 19:44:53 --> Helper loaded: form_helper
INFO - 2019-09-18 19:44:53 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:44:53 --> Helper loaded: date_helper
INFO - 2019-09-18 19:44:53 --> Form Validation Class Initialized
INFO - 2019-09-18 19:44:53 --> Email Class Initialized
DEBUG - 2019-09-18 19:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:44:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:44:53 --> Pagination Class Initialized
INFO - 2019-09-18 19:44:53 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:53 --> Database Driver Class Initialized
INFO - 2019-09-18 19:44:53 --> Controller Class Initialized
INFO - 2019-09-18 19:44:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:44:53 --> Final output sent to browser
DEBUG - 2019-09-18 19:44:53 --> Total execution time: 0.0611
INFO - 2019-09-18 19:50:17 --> Config Class Initialized
INFO - 2019-09-18 19:50:17 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:50:17 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:50:17 --> Utf8 Class Initialized
INFO - 2019-09-18 19:50:17 --> URI Class Initialized
INFO - 2019-09-18 19:50:17 --> Router Class Initialized
INFO - 2019-09-18 19:50:17 --> Output Class Initialized
INFO - 2019-09-18 19:50:17 --> Security Class Initialized
DEBUG - 2019-09-18 19:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:50:17 --> Input Class Initialized
INFO - 2019-09-18 19:50:17 --> Language Class Initialized
INFO - 2019-09-18 19:50:17 --> Loader Class Initialized
INFO - 2019-09-18 19:50:17 --> Helper loaded: url_helper
INFO - 2019-09-18 19:50:17 --> Helper loaded: html_helper
INFO - 2019-09-18 19:50:17 --> Helper loaded: form_helper
INFO - 2019-09-18 19:50:17 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:50:17 --> Helper loaded: date_helper
INFO - 2019-09-18 19:50:17 --> Form Validation Class Initialized
INFO - 2019-09-18 19:50:17 --> Email Class Initialized
DEBUG - 2019-09-18 19:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:50:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:50:17 --> Pagination Class Initialized
INFO - 2019-09-18 19:50:17 --> Database Driver Class Initialized
INFO - 2019-09-18 19:50:17 --> Database Driver Class Initialized
INFO - 2019-09-18 19:50:17 --> Controller Class Initialized
INFO - 2019-09-18 19:50:17 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 19:50:17 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-18 19:50:17 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 19:50:17 --> Final output sent to browser
DEBUG - 2019-09-18 19:50:17 --> Total execution time: 0.0598
INFO - 2019-09-18 19:50:18 --> Config Class Initialized
INFO - 2019-09-18 19:50:18 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:50:18 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:50:18 --> Utf8 Class Initialized
INFO - 2019-09-18 19:50:18 --> URI Class Initialized
INFO - 2019-09-18 19:50:18 --> Router Class Initialized
INFO - 2019-09-18 19:50:18 --> Output Class Initialized
INFO - 2019-09-18 19:50:18 --> Security Class Initialized
DEBUG - 2019-09-18 19:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:50:18 --> Input Class Initialized
INFO - 2019-09-18 19:50:18 --> Language Class Initialized
INFO - 2019-09-18 19:50:18 --> Loader Class Initialized
INFO - 2019-09-18 19:50:18 --> Helper loaded: url_helper
INFO - 2019-09-18 19:50:18 --> Helper loaded: html_helper
INFO - 2019-09-18 19:50:18 --> Helper loaded: form_helper
INFO - 2019-09-18 19:50:18 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:50:18 --> Helper loaded: date_helper
INFO - 2019-09-18 19:50:18 --> Form Validation Class Initialized
INFO - 2019-09-18 19:50:18 --> Email Class Initialized
DEBUG - 2019-09-18 19:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:50:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:50:18 --> Pagination Class Initialized
INFO - 2019-09-18 19:50:18 --> Database Driver Class Initialized
INFO - 2019-09-18 19:50:18 --> Database Driver Class Initialized
INFO - 2019-09-18 19:50:18 --> Controller Class Initialized
INFO - 2019-09-18 19:50:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 19:50:18 --> Final output sent to browser
DEBUG - 2019-09-18 19:50:18 --> Total execution time: 0.0640
INFO - 2019-09-18 19:50:25 --> Config Class Initialized
INFO - 2019-09-18 19:50:25 --> Hooks Class Initialized
DEBUG - 2019-09-18 19:50:25 --> UTF-8 Support Enabled
INFO - 2019-09-18 19:50:25 --> Utf8 Class Initialized
INFO - 2019-09-18 19:50:25 --> URI Class Initialized
INFO - 2019-09-18 19:50:25 --> Router Class Initialized
INFO - 2019-09-18 19:50:25 --> Output Class Initialized
INFO - 2019-09-18 19:50:25 --> Security Class Initialized
DEBUG - 2019-09-18 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 19:50:25 --> Input Class Initialized
INFO - 2019-09-18 19:50:25 --> Language Class Initialized
INFO - 2019-09-18 19:50:25 --> Loader Class Initialized
INFO - 2019-09-18 19:50:25 --> Helper loaded: url_helper
INFO - 2019-09-18 19:50:25 --> Helper loaded: html_helper
INFO - 2019-09-18 19:50:25 --> Helper loaded: form_helper
INFO - 2019-09-18 19:50:25 --> Helper loaded: cookie_helper
INFO - 2019-09-18 19:50:25 --> Helper loaded: date_helper
INFO - 2019-09-18 19:50:25 --> Form Validation Class Initialized
INFO - 2019-09-18 19:50:25 --> Email Class Initialized
DEBUG - 2019-09-18 19:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 19:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 19:50:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 19:50:25 --> Pagination Class Initialized
INFO - 2019-09-18 19:50:25 --> Database Driver Class Initialized
INFO - 2019-09-18 19:50:25 --> Database Driver Class Initialized
INFO - 2019-09-18 19:50:25 --> Controller Class Initialized
INFO - 2019-09-18 19:50:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-18 19:50:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report_arrivals.php
INFO - 2019-09-18 19:50:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 19:50:25 --> Final output sent to browser
DEBUG - 2019-09-18 19:50:25 --> Total execution time: 0.0641
INFO - 2019-09-18 20:10:43 --> Config Class Initialized
INFO - 2019-09-18 20:10:43 --> Hooks Class Initialized
DEBUG - 2019-09-18 20:10:43 --> UTF-8 Support Enabled
INFO - 2019-09-18 20:10:43 --> Utf8 Class Initialized
INFO - 2019-09-18 20:10:43 --> URI Class Initialized
INFO - 2019-09-18 20:10:43 --> Router Class Initialized
INFO - 2019-09-18 20:10:43 --> Output Class Initialized
INFO - 2019-09-18 20:10:43 --> Security Class Initialized
DEBUG - 2019-09-18 20:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 20:10:43 --> Input Class Initialized
INFO - 2019-09-18 20:10:43 --> Language Class Initialized
INFO - 2019-09-18 20:10:43 --> Loader Class Initialized
INFO - 2019-09-18 20:10:43 --> Helper loaded: url_helper
INFO - 2019-09-18 20:10:43 --> Helper loaded: html_helper
INFO - 2019-09-18 20:10:43 --> Helper loaded: form_helper
INFO - 2019-09-18 20:10:43 --> Helper loaded: cookie_helper
INFO - 2019-09-18 20:10:43 --> Helper loaded: date_helper
INFO - 2019-09-18 20:10:43 --> Form Validation Class Initialized
INFO - 2019-09-18 20:10:43 --> Email Class Initialized
DEBUG - 2019-09-18 20:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 20:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 20:10:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 20:10:43 --> Pagination Class Initialized
INFO - 2019-09-18 20:10:43 --> Database Driver Class Initialized
INFO - 2019-09-18 20:10:43 --> Database Driver Class Initialized
INFO - 2019-09-18 20:10:43 --> Controller Class Initialized
DEBUG - 2019-09-18 20:10:43 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-18 20:10:43 --> Helper loaded: inflector_helper
INFO - 2019-09-18 20:10:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-18 20:10:43 --> Final output sent to browser
DEBUG - 2019-09-18 20:10:43 --> Total execution time: 0.1299
INFO - 2019-09-18 20:48:37 --> Config Class Initialized
INFO - 2019-09-18 20:48:37 --> Hooks Class Initialized
DEBUG - 2019-09-18 20:48:37 --> UTF-8 Support Enabled
INFO - 2019-09-18 20:48:37 --> Utf8 Class Initialized
INFO - 2019-09-18 20:48:37 --> URI Class Initialized
INFO - 2019-09-18 20:48:37 --> Router Class Initialized
INFO - 2019-09-18 20:48:37 --> Output Class Initialized
INFO - 2019-09-18 20:48:37 --> Security Class Initialized
DEBUG - 2019-09-18 20:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 20:48:37 --> Input Class Initialized
INFO - 2019-09-18 20:48:37 --> Language Class Initialized
INFO - 2019-09-18 20:48:37 --> Loader Class Initialized
INFO - 2019-09-18 20:48:37 --> Helper loaded: url_helper
INFO - 2019-09-18 20:48:37 --> Helper loaded: html_helper
INFO - 2019-09-18 20:48:37 --> Helper loaded: form_helper
INFO - 2019-09-18 20:48:37 --> Helper loaded: cookie_helper
INFO - 2019-09-18 20:48:37 --> Helper loaded: date_helper
INFO - 2019-09-18 20:48:37 --> Form Validation Class Initialized
INFO - 2019-09-18 20:48:37 --> Email Class Initialized
DEBUG - 2019-09-18 20:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 20:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 20:48:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 20:48:37 --> Pagination Class Initialized
INFO - 2019-09-18 20:48:37 --> Database Driver Class Initialized
INFO - 2019-09-18 20:48:37 --> Database Driver Class Initialized
INFO - 2019-09-18 20:48:37 --> Controller Class Initialized
DEBUG - 2019-09-18 20:48:37 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-18 20:48:37 --> Helper loaded: inflector_helper
INFO - 2019-09-18 20:48:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-18 20:48:37 --> Final output sent to browser
DEBUG - 2019-09-18 20:48:37 --> Total execution time: 0.0594
INFO - 2019-09-18 20:51:51 --> Config Class Initialized
INFO - 2019-09-18 20:51:51 --> Hooks Class Initialized
DEBUG - 2019-09-18 20:51:51 --> UTF-8 Support Enabled
INFO - 2019-09-18 20:51:51 --> Utf8 Class Initialized
INFO - 2019-09-18 20:51:51 --> URI Class Initialized
INFO - 2019-09-18 20:51:51 --> Router Class Initialized
INFO - 2019-09-18 20:51:51 --> Output Class Initialized
INFO - 2019-09-18 20:51:51 --> Security Class Initialized
DEBUG - 2019-09-18 20:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 20:51:51 --> Input Class Initialized
INFO - 2019-09-18 20:51:51 --> Language Class Initialized
INFO - 2019-09-18 20:51:52 --> Loader Class Initialized
INFO - 2019-09-18 20:51:52 --> Helper loaded: url_helper
INFO - 2019-09-18 20:51:52 --> Helper loaded: html_helper
INFO - 2019-09-18 20:51:52 --> Helper loaded: form_helper
INFO - 2019-09-18 20:51:52 --> Helper loaded: cookie_helper
INFO - 2019-09-18 20:51:52 --> Helper loaded: date_helper
INFO - 2019-09-18 20:51:52 --> Form Validation Class Initialized
INFO - 2019-09-18 20:51:52 --> Email Class Initialized
DEBUG - 2019-09-18 20:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 20:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 20:51:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 20:51:52 --> Pagination Class Initialized
INFO - 2019-09-18 20:51:52 --> Database Driver Class Initialized
INFO - 2019-09-18 20:51:52 --> Database Driver Class Initialized
INFO - 2019-09-18 20:51:52 --> Controller Class Initialized
INFO - 2019-09-18 20:51:52 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 20:51:52 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-18 20:51:52 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 20:51:52 --> Final output sent to browser
DEBUG - 2019-09-18 20:51:52 --> Total execution time: 0.0589
INFO - 2019-09-18 20:51:52 --> Config Class Initialized
INFO - 2019-09-18 20:51:52 --> Hooks Class Initialized
DEBUG - 2019-09-18 20:51:52 --> UTF-8 Support Enabled
INFO - 2019-09-18 20:51:52 --> Utf8 Class Initialized
INFO - 2019-09-18 20:51:52 --> URI Class Initialized
INFO - 2019-09-18 20:51:52 --> Router Class Initialized
INFO - 2019-09-18 20:51:52 --> Output Class Initialized
INFO - 2019-09-18 20:51:52 --> Security Class Initialized
DEBUG - 2019-09-18 20:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 20:51:52 --> Input Class Initialized
INFO - 2019-09-18 20:51:52 --> Language Class Initialized
INFO - 2019-09-18 20:51:52 --> Loader Class Initialized
INFO - 2019-09-18 20:51:52 --> Helper loaded: url_helper
INFO - 2019-09-18 20:51:52 --> Helper loaded: html_helper
INFO - 2019-09-18 20:51:52 --> Helper loaded: form_helper
INFO - 2019-09-18 20:51:52 --> Helper loaded: cookie_helper
INFO - 2019-09-18 20:51:52 --> Helper loaded: date_helper
INFO - 2019-09-18 20:51:52 --> Form Validation Class Initialized
INFO - 2019-09-18 20:51:52 --> Email Class Initialized
DEBUG - 2019-09-18 20:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 20:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 20:51:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 20:51:52 --> Pagination Class Initialized
INFO - 2019-09-18 20:51:52 --> Database Driver Class Initialized
INFO - 2019-09-18 20:51:52 --> Database Driver Class Initialized
INFO - 2019-09-18 20:51:52 --> Controller Class Initialized
INFO - 2019-09-18 20:51:52 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 20:51:52 --> Final output sent to browser
DEBUG - 2019-09-18 20:51:52 --> Total execution time: 0.0701
INFO - 2019-09-18 20:51:56 --> Config Class Initialized
INFO - 2019-09-18 20:51:56 --> Hooks Class Initialized
DEBUG - 2019-09-18 20:51:56 --> UTF-8 Support Enabled
INFO - 2019-09-18 20:51:56 --> Utf8 Class Initialized
INFO - 2019-09-18 20:51:56 --> URI Class Initialized
INFO - 2019-09-18 20:51:56 --> Router Class Initialized
INFO - 2019-09-18 20:51:56 --> Output Class Initialized
INFO - 2019-09-18 20:51:56 --> Security Class Initialized
DEBUG - 2019-09-18 20:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 20:51:56 --> Input Class Initialized
INFO - 2019-09-18 20:51:56 --> Language Class Initialized
INFO - 2019-09-18 20:51:56 --> Loader Class Initialized
INFO - 2019-09-18 20:51:56 --> Helper loaded: url_helper
INFO - 2019-09-18 20:51:56 --> Helper loaded: html_helper
INFO - 2019-09-18 20:51:56 --> Helper loaded: form_helper
INFO - 2019-09-18 20:51:56 --> Helper loaded: cookie_helper
INFO - 2019-09-18 20:51:56 --> Helper loaded: date_helper
INFO - 2019-09-18 20:51:56 --> Form Validation Class Initialized
INFO - 2019-09-18 20:51:56 --> Email Class Initialized
DEBUG - 2019-09-18 20:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 20:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 20:51:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 20:51:56 --> Pagination Class Initialized
INFO - 2019-09-18 20:51:56 --> Database Driver Class Initialized
INFO - 2019-09-18 20:51:56 --> Database Driver Class Initialized
INFO - 2019-09-18 20:51:56 --> Controller Class Initialized
INFO - 2019-09-18 20:51:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-18 20:51:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report.php
INFO - 2019-09-18 20:51:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 20:51:56 --> Final output sent to browser
DEBUG - 2019-09-18 20:51:56 --> Total execution time: 0.0681
INFO - 2019-09-18 20:52:12 --> Config Class Initialized
INFO - 2019-09-18 20:52:12 --> Hooks Class Initialized
DEBUG - 2019-09-18 20:52:12 --> UTF-8 Support Enabled
INFO - 2019-09-18 20:52:12 --> Utf8 Class Initialized
INFO - 2019-09-18 20:52:12 --> URI Class Initialized
INFO - 2019-09-18 20:52:12 --> Router Class Initialized
INFO - 2019-09-18 20:52:12 --> Output Class Initialized
INFO - 2019-09-18 20:52:12 --> Security Class Initialized
DEBUG - 2019-09-18 20:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 20:52:12 --> Input Class Initialized
INFO - 2019-09-18 20:52:12 --> Language Class Initialized
INFO - 2019-09-18 20:52:12 --> Loader Class Initialized
INFO - 2019-09-18 20:52:12 --> Helper loaded: url_helper
INFO - 2019-09-18 20:52:12 --> Helper loaded: html_helper
INFO - 2019-09-18 20:52:12 --> Helper loaded: form_helper
INFO - 2019-09-18 20:52:12 --> Helper loaded: cookie_helper
INFO - 2019-09-18 20:52:12 --> Helper loaded: date_helper
INFO - 2019-09-18 20:52:12 --> Form Validation Class Initialized
INFO - 2019-09-18 20:52:12 --> Email Class Initialized
DEBUG - 2019-09-18 20:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 20:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 20:52:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 20:52:12 --> Pagination Class Initialized
INFO - 2019-09-18 20:52:12 --> Database Driver Class Initialized
INFO - 2019-09-18 20:52:12 --> Database Driver Class Initialized
INFO - 2019-09-18 20:52:12 --> Controller Class Initialized
INFO - 2019-09-18 20:54:50 --> Config Class Initialized
INFO - 2019-09-18 20:54:50 --> Hooks Class Initialized
DEBUG - 2019-09-18 20:54:50 --> UTF-8 Support Enabled
INFO - 2019-09-18 20:54:50 --> Utf8 Class Initialized
INFO - 2019-09-18 20:54:50 --> URI Class Initialized
INFO - 2019-09-18 20:54:50 --> Router Class Initialized
INFO - 2019-09-18 20:54:50 --> Output Class Initialized
INFO - 2019-09-18 20:54:50 --> Security Class Initialized
DEBUG - 2019-09-18 20:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 20:54:50 --> Input Class Initialized
INFO - 2019-09-18 20:54:50 --> Language Class Initialized
INFO - 2019-09-18 20:54:50 --> Loader Class Initialized
INFO - 2019-09-18 20:54:50 --> Helper loaded: url_helper
INFO - 2019-09-18 20:54:50 --> Helper loaded: html_helper
INFO - 2019-09-18 20:54:50 --> Helper loaded: form_helper
INFO - 2019-09-18 20:54:50 --> Helper loaded: cookie_helper
INFO - 2019-09-18 20:54:50 --> Helper loaded: date_helper
INFO - 2019-09-18 20:54:50 --> Form Validation Class Initialized
INFO - 2019-09-18 20:54:50 --> Email Class Initialized
DEBUG - 2019-09-18 20:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 20:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 20:54:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 20:54:50 --> Pagination Class Initialized
INFO - 2019-09-18 20:54:50 --> Database Driver Class Initialized
INFO - 2019-09-18 20:54:50 --> Database Driver Class Initialized
INFO - 2019-09-18 20:54:50 --> Controller Class Initialized
INFO - 2019-09-18 20:54:50 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 20:54:50 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-18 20:54:50 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 20:54:50 --> Final output sent to browser
DEBUG - 2019-09-18 20:54:50 --> Total execution time: 0.0560
INFO - 2019-09-18 20:54:51 --> Config Class Initialized
INFO - 2019-09-18 20:54:51 --> Hooks Class Initialized
DEBUG - 2019-09-18 20:54:51 --> UTF-8 Support Enabled
INFO - 2019-09-18 20:54:51 --> Utf8 Class Initialized
INFO - 2019-09-18 20:54:51 --> URI Class Initialized
INFO - 2019-09-18 20:54:51 --> Router Class Initialized
INFO - 2019-09-18 20:54:51 --> Output Class Initialized
INFO - 2019-09-18 20:54:51 --> Security Class Initialized
DEBUG - 2019-09-18 20:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 20:54:51 --> Input Class Initialized
INFO - 2019-09-18 20:54:51 --> Language Class Initialized
INFO - 2019-09-18 20:54:51 --> Loader Class Initialized
INFO - 2019-09-18 20:54:51 --> Helper loaded: url_helper
INFO - 2019-09-18 20:54:51 --> Helper loaded: html_helper
INFO - 2019-09-18 20:54:51 --> Helper loaded: form_helper
INFO - 2019-09-18 20:54:51 --> Helper loaded: cookie_helper
INFO - 2019-09-18 20:54:51 --> Helper loaded: date_helper
INFO - 2019-09-18 20:54:51 --> Form Validation Class Initialized
INFO - 2019-09-18 20:54:51 --> Email Class Initialized
DEBUG - 2019-09-18 20:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 20:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 20:54:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 20:54:51 --> Pagination Class Initialized
INFO - 2019-09-18 20:54:51 --> Database Driver Class Initialized
INFO - 2019-09-18 20:54:51 --> Database Driver Class Initialized
INFO - 2019-09-18 20:54:51 --> Controller Class Initialized
INFO - 2019-09-18 20:54:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 20:54:51 --> Final output sent to browser
DEBUG - 2019-09-18 20:54:51 --> Total execution time: 0.0667
INFO - 2019-09-18 20:54:54 --> Config Class Initialized
INFO - 2019-09-18 20:54:54 --> Hooks Class Initialized
DEBUG - 2019-09-18 20:54:54 --> UTF-8 Support Enabled
INFO - 2019-09-18 20:54:54 --> Utf8 Class Initialized
INFO - 2019-09-18 20:54:54 --> URI Class Initialized
INFO - 2019-09-18 20:54:54 --> Router Class Initialized
INFO - 2019-09-18 20:54:54 --> Output Class Initialized
INFO - 2019-09-18 20:54:54 --> Security Class Initialized
DEBUG - 2019-09-18 20:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 20:54:54 --> Input Class Initialized
INFO - 2019-09-18 20:54:54 --> Language Class Initialized
INFO - 2019-09-18 20:54:54 --> Loader Class Initialized
INFO - 2019-09-18 20:54:54 --> Helper loaded: url_helper
INFO - 2019-09-18 20:54:54 --> Helper loaded: html_helper
INFO - 2019-09-18 20:54:54 --> Helper loaded: form_helper
INFO - 2019-09-18 20:54:54 --> Helper loaded: cookie_helper
INFO - 2019-09-18 20:54:54 --> Helper loaded: date_helper
INFO - 2019-09-18 20:54:54 --> Form Validation Class Initialized
INFO - 2019-09-18 20:54:54 --> Email Class Initialized
DEBUG - 2019-09-18 20:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 20:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 20:54:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 20:54:54 --> Pagination Class Initialized
INFO - 2019-09-18 20:54:54 --> Database Driver Class Initialized
INFO - 2019-09-18 20:54:54 --> Database Driver Class Initialized
INFO - 2019-09-18 20:54:54 --> Controller Class Initialized
INFO - 2019-09-18 20:57:23 --> Config Class Initialized
INFO - 2019-09-18 20:57:23 --> Hooks Class Initialized
DEBUG - 2019-09-18 20:57:23 --> UTF-8 Support Enabled
INFO - 2019-09-18 20:57:23 --> Utf8 Class Initialized
INFO - 2019-09-18 20:57:23 --> URI Class Initialized
INFO - 2019-09-18 20:57:23 --> Router Class Initialized
INFO - 2019-09-18 20:57:23 --> Output Class Initialized
INFO - 2019-09-18 20:57:23 --> Security Class Initialized
DEBUG - 2019-09-18 20:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 20:57:23 --> Input Class Initialized
INFO - 2019-09-18 20:57:23 --> Language Class Initialized
INFO - 2019-09-18 20:57:23 --> Loader Class Initialized
INFO - 2019-09-18 20:57:23 --> Helper loaded: url_helper
INFO - 2019-09-18 20:57:23 --> Helper loaded: html_helper
INFO - 2019-09-18 20:57:23 --> Helper loaded: form_helper
INFO - 2019-09-18 20:57:23 --> Helper loaded: cookie_helper
INFO - 2019-09-18 20:57:23 --> Helper loaded: date_helper
INFO - 2019-09-18 20:57:23 --> Form Validation Class Initialized
INFO - 2019-09-18 20:57:23 --> Email Class Initialized
DEBUG - 2019-09-18 20:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 20:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 20:57:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 20:57:23 --> Pagination Class Initialized
INFO - 2019-09-18 20:57:23 --> Database Driver Class Initialized
INFO - 2019-09-18 20:57:23 --> Database Driver Class Initialized
INFO - 2019-09-18 20:57:23 --> Controller Class Initialized
INFO - 2019-09-18 20:57:23 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 20:57:23 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-18 20:57:23 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 20:57:23 --> Final output sent to browser
DEBUG - 2019-09-18 20:57:23 --> Total execution time: 0.0599
INFO - 2019-09-18 20:57:23 --> Config Class Initialized
INFO - 2019-09-18 20:57:23 --> Hooks Class Initialized
DEBUG - 2019-09-18 20:57:23 --> UTF-8 Support Enabled
INFO - 2019-09-18 20:57:23 --> Utf8 Class Initialized
INFO - 2019-09-18 20:57:23 --> URI Class Initialized
INFO - 2019-09-18 20:57:23 --> Router Class Initialized
INFO - 2019-09-18 20:57:23 --> Output Class Initialized
INFO - 2019-09-18 20:57:23 --> Security Class Initialized
DEBUG - 2019-09-18 20:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 20:57:23 --> Input Class Initialized
INFO - 2019-09-18 20:57:23 --> Language Class Initialized
INFO - 2019-09-18 20:57:23 --> Loader Class Initialized
INFO - 2019-09-18 20:57:23 --> Helper loaded: url_helper
INFO - 2019-09-18 20:57:23 --> Helper loaded: html_helper
INFO - 2019-09-18 20:57:23 --> Helper loaded: form_helper
INFO - 2019-09-18 20:57:23 --> Helper loaded: cookie_helper
INFO - 2019-09-18 20:57:23 --> Helper loaded: date_helper
INFO - 2019-09-18 20:57:23 --> Form Validation Class Initialized
INFO - 2019-09-18 20:57:23 --> Email Class Initialized
DEBUG - 2019-09-18 20:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 20:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 20:57:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 20:57:23 --> Pagination Class Initialized
INFO - 2019-09-18 20:57:23 --> Database Driver Class Initialized
INFO - 2019-09-18 20:57:23 --> Database Driver Class Initialized
INFO - 2019-09-18 20:57:23 --> Controller Class Initialized
INFO - 2019-09-18 20:57:23 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 20:57:23 --> Final output sent to browser
DEBUG - 2019-09-18 20:57:23 --> Total execution time: 0.0615
INFO - 2019-09-18 20:57:23 --> Config Class Initialized
INFO - 2019-09-18 20:57:23 --> Hooks Class Initialized
DEBUG - 2019-09-18 20:57:23 --> UTF-8 Support Enabled
INFO - 2019-09-18 20:57:23 --> Utf8 Class Initialized
INFO - 2019-09-18 20:57:23 --> URI Class Initialized
INFO - 2019-09-18 20:57:23 --> Router Class Initialized
INFO - 2019-09-18 20:57:23 --> Output Class Initialized
INFO - 2019-09-18 20:57:23 --> Security Class Initialized
DEBUG - 2019-09-18 20:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 20:57:23 --> Input Class Initialized
INFO - 2019-09-18 20:57:23 --> Language Class Initialized
INFO - 2019-09-18 20:57:23 --> Loader Class Initialized
INFO - 2019-09-18 20:57:23 --> Helper loaded: url_helper
INFO - 2019-09-18 20:57:23 --> Helper loaded: html_helper
INFO - 2019-09-18 20:57:23 --> Helper loaded: form_helper
INFO - 2019-09-18 20:57:23 --> Helper loaded: cookie_helper
INFO - 2019-09-18 20:57:23 --> Helper loaded: date_helper
INFO - 2019-09-18 20:57:23 --> Form Validation Class Initialized
INFO - 2019-09-18 20:57:23 --> Email Class Initialized
DEBUG - 2019-09-18 20:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 20:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 20:57:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 20:57:23 --> Pagination Class Initialized
INFO - 2019-09-18 20:57:23 --> Database Driver Class Initialized
INFO - 2019-09-18 20:57:23 --> Database Driver Class Initialized
INFO - 2019-09-18 20:57:23 --> Controller Class Initialized
INFO - 2019-09-18 20:57:23 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 20:57:23 --> Final output sent to browser
DEBUG - 2019-09-18 20:57:23 --> Total execution time: 0.0491
INFO - 2019-09-18 20:57:27 --> Config Class Initialized
INFO - 2019-09-18 20:57:27 --> Hooks Class Initialized
DEBUG - 2019-09-18 20:57:27 --> UTF-8 Support Enabled
INFO - 2019-09-18 20:57:27 --> Utf8 Class Initialized
INFO - 2019-09-18 20:57:27 --> URI Class Initialized
INFO - 2019-09-18 20:57:27 --> Router Class Initialized
INFO - 2019-09-18 20:57:27 --> Output Class Initialized
INFO - 2019-09-18 20:57:27 --> Security Class Initialized
DEBUG - 2019-09-18 20:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 20:57:27 --> Input Class Initialized
INFO - 2019-09-18 20:57:27 --> Language Class Initialized
INFO - 2019-09-18 20:57:27 --> Loader Class Initialized
INFO - 2019-09-18 20:57:27 --> Helper loaded: url_helper
INFO - 2019-09-18 20:57:27 --> Helper loaded: html_helper
INFO - 2019-09-18 20:57:27 --> Helper loaded: form_helper
INFO - 2019-09-18 20:57:27 --> Helper loaded: cookie_helper
INFO - 2019-09-18 20:57:27 --> Helper loaded: date_helper
INFO - 2019-09-18 20:57:27 --> Form Validation Class Initialized
INFO - 2019-09-18 20:57:27 --> Email Class Initialized
DEBUG - 2019-09-18 20:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 20:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 20:57:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 20:57:27 --> Pagination Class Initialized
INFO - 2019-09-18 20:57:27 --> Database Driver Class Initialized
INFO - 2019-09-18 20:57:27 --> Database Driver Class Initialized
INFO - 2019-09-18 20:57:27 --> Controller Class Initialized
INFO - 2019-09-18 21:01:12 --> Config Class Initialized
INFO - 2019-09-18 21:01:12 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:01:12 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:01:12 --> Utf8 Class Initialized
INFO - 2019-09-18 21:01:12 --> URI Class Initialized
INFO - 2019-09-18 21:01:12 --> Router Class Initialized
INFO - 2019-09-18 21:01:12 --> Output Class Initialized
INFO - 2019-09-18 21:01:12 --> Security Class Initialized
DEBUG - 2019-09-18 21:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:01:12 --> Input Class Initialized
INFO - 2019-09-18 21:01:12 --> Language Class Initialized
INFO - 2019-09-18 21:01:12 --> Loader Class Initialized
INFO - 2019-09-18 21:01:12 --> Helper loaded: url_helper
INFO - 2019-09-18 21:01:12 --> Helper loaded: html_helper
INFO - 2019-09-18 21:01:12 --> Helper loaded: form_helper
INFO - 2019-09-18 21:01:12 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:01:12 --> Helper loaded: date_helper
INFO - 2019-09-18 21:01:12 --> Form Validation Class Initialized
INFO - 2019-09-18 21:01:12 --> Email Class Initialized
DEBUG - 2019-09-18 21:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:01:12 --> Pagination Class Initialized
INFO - 2019-09-18 21:01:12 --> Database Driver Class Initialized
INFO - 2019-09-18 21:01:12 --> Database Driver Class Initialized
INFO - 2019-09-18 21:01:12 --> Controller Class Initialized
INFO - 2019-09-18 21:01:12 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 21:01:12 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-18 21:01:12 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 21:01:12 --> Final output sent to browser
DEBUG - 2019-09-18 21:01:12 --> Total execution time: 0.0574
INFO - 2019-09-18 21:01:12 --> Config Class Initialized
INFO - 2019-09-18 21:01:12 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:01:12 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:01:12 --> Utf8 Class Initialized
INFO - 2019-09-18 21:01:12 --> URI Class Initialized
INFO - 2019-09-18 21:01:12 --> Router Class Initialized
INFO - 2019-09-18 21:01:12 --> Output Class Initialized
INFO - 2019-09-18 21:01:12 --> Security Class Initialized
DEBUG - 2019-09-18 21:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:01:12 --> Input Class Initialized
INFO - 2019-09-18 21:01:12 --> Language Class Initialized
INFO - 2019-09-18 21:01:12 --> Loader Class Initialized
INFO - 2019-09-18 21:01:12 --> Helper loaded: url_helper
INFO - 2019-09-18 21:01:12 --> Helper loaded: html_helper
INFO - 2019-09-18 21:01:12 --> Helper loaded: form_helper
INFO - 2019-09-18 21:01:12 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:01:12 --> Helper loaded: date_helper
INFO - 2019-09-18 21:01:12 --> Form Validation Class Initialized
INFO - 2019-09-18 21:01:12 --> Email Class Initialized
DEBUG - 2019-09-18 21:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:01:12 --> Pagination Class Initialized
INFO - 2019-09-18 21:01:12 --> Database Driver Class Initialized
INFO - 2019-09-18 21:01:12 --> Database Driver Class Initialized
INFO - 2019-09-18 21:01:12 --> Controller Class Initialized
INFO - 2019-09-18 21:01:12 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 21:01:12 --> Final output sent to browser
DEBUG - 2019-09-18 21:01:12 --> Total execution time: 0.0618
INFO - 2019-09-18 21:01:16 --> Config Class Initialized
INFO - 2019-09-18 21:01:16 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:01:16 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:01:16 --> Utf8 Class Initialized
INFO - 2019-09-18 21:01:16 --> URI Class Initialized
INFO - 2019-09-18 21:01:16 --> Router Class Initialized
INFO - 2019-09-18 21:01:16 --> Output Class Initialized
INFO - 2019-09-18 21:01:16 --> Security Class Initialized
DEBUG - 2019-09-18 21:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:01:16 --> Input Class Initialized
INFO - 2019-09-18 21:01:16 --> Language Class Initialized
INFO - 2019-09-18 21:01:16 --> Loader Class Initialized
INFO - 2019-09-18 21:01:16 --> Helper loaded: url_helper
INFO - 2019-09-18 21:01:16 --> Helper loaded: html_helper
INFO - 2019-09-18 21:01:16 --> Helper loaded: form_helper
INFO - 2019-09-18 21:01:16 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:01:16 --> Helper loaded: date_helper
INFO - 2019-09-18 21:01:16 --> Form Validation Class Initialized
INFO - 2019-09-18 21:01:16 --> Email Class Initialized
DEBUG - 2019-09-18 21:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:01:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:01:16 --> Pagination Class Initialized
INFO - 2019-09-18 21:01:16 --> Database Driver Class Initialized
INFO - 2019-09-18 21:01:16 --> Database Driver Class Initialized
INFO - 2019-09-18 21:01:16 --> Controller Class Initialized
INFO - 2019-09-18 21:01:47 --> Config Class Initialized
INFO - 2019-09-18 21:01:47 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:01:47 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:01:47 --> Utf8 Class Initialized
INFO - 2019-09-18 21:01:47 --> URI Class Initialized
INFO - 2019-09-18 21:01:47 --> Router Class Initialized
INFO - 2019-09-18 21:01:47 --> Output Class Initialized
INFO - 2019-09-18 21:01:47 --> Security Class Initialized
DEBUG - 2019-09-18 21:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:01:47 --> Input Class Initialized
INFO - 2019-09-18 21:01:47 --> Language Class Initialized
INFO - 2019-09-18 21:01:47 --> Loader Class Initialized
INFO - 2019-09-18 21:01:47 --> Helper loaded: url_helper
INFO - 2019-09-18 21:01:47 --> Helper loaded: html_helper
INFO - 2019-09-18 21:01:47 --> Helper loaded: form_helper
INFO - 2019-09-18 21:01:47 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:01:47 --> Helper loaded: date_helper
INFO - 2019-09-18 21:01:47 --> Form Validation Class Initialized
INFO - 2019-09-18 21:01:47 --> Email Class Initialized
DEBUG - 2019-09-18 21:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:01:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:01:47 --> Pagination Class Initialized
INFO - 2019-09-18 21:01:47 --> Database Driver Class Initialized
INFO - 2019-09-18 21:01:47 --> Database Driver Class Initialized
INFO - 2019-09-18 21:01:47 --> Controller Class Initialized
INFO - 2019-09-18 21:01:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 21:01:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-18 21:01:47 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 21:01:47 --> Final output sent to browser
DEBUG - 2019-09-18 21:01:47 --> Total execution time: 0.0567
INFO - 2019-09-18 21:01:47 --> Config Class Initialized
INFO - 2019-09-18 21:01:47 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:01:47 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:01:47 --> Utf8 Class Initialized
INFO - 2019-09-18 21:01:47 --> URI Class Initialized
INFO - 2019-09-18 21:01:47 --> Router Class Initialized
INFO - 2019-09-18 21:01:47 --> Output Class Initialized
INFO - 2019-09-18 21:01:47 --> Security Class Initialized
DEBUG - 2019-09-18 21:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:01:47 --> Input Class Initialized
INFO - 2019-09-18 21:01:47 --> Language Class Initialized
INFO - 2019-09-18 21:01:48 --> Loader Class Initialized
INFO - 2019-09-18 21:01:48 --> Helper loaded: url_helper
INFO - 2019-09-18 21:01:48 --> Helper loaded: html_helper
INFO - 2019-09-18 21:01:48 --> Helper loaded: form_helper
INFO - 2019-09-18 21:01:48 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:01:48 --> Helper loaded: date_helper
INFO - 2019-09-18 21:01:48 --> Form Validation Class Initialized
INFO - 2019-09-18 21:01:48 --> Email Class Initialized
DEBUG - 2019-09-18 21:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:01:48 --> Pagination Class Initialized
INFO - 2019-09-18 21:01:48 --> Database Driver Class Initialized
INFO - 2019-09-18 21:01:48 --> Database Driver Class Initialized
INFO - 2019-09-18 21:01:48 --> Controller Class Initialized
INFO - 2019-09-18 21:01:48 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 21:01:48 --> Final output sent to browser
DEBUG - 2019-09-18 21:01:48 --> Total execution time: 0.0631
INFO - 2019-09-18 21:01:52 --> Config Class Initialized
INFO - 2019-09-18 21:01:52 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:01:52 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:01:52 --> Utf8 Class Initialized
INFO - 2019-09-18 21:01:52 --> URI Class Initialized
INFO - 2019-09-18 21:01:52 --> Router Class Initialized
INFO - 2019-09-18 21:01:52 --> Output Class Initialized
INFO - 2019-09-18 21:01:52 --> Security Class Initialized
DEBUG - 2019-09-18 21:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:01:52 --> Input Class Initialized
INFO - 2019-09-18 21:01:52 --> Language Class Initialized
INFO - 2019-09-18 21:01:52 --> Loader Class Initialized
INFO - 2019-09-18 21:01:52 --> Helper loaded: url_helper
INFO - 2019-09-18 21:01:52 --> Helper loaded: html_helper
INFO - 2019-09-18 21:01:52 --> Helper loaded: form_helper
INFO - 2019-09-18 21:01:52 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:01:52 --> Helper loaded: date_helper
INFO - 2019-09-18 21:01:52 --> Form Validation Class Initialized
INFO - 2019-09-18 21:01:52 --> Email Class Initialized
DEBUG - 2019-09-18 21:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:01:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:01:52 --> Pagination Class Initialized
INFO - 2019-09-18 21:01:52 --> Database Driver Class Initialized
INFO - 2019-09-18 21:01:52 --> Database Driver Class Initialized
INFO - 2019-09-18 21:01:52 --> Controller Class Initialized
INFO - 2019-09-18 21:02:25 --> Config Class Initialized
INFO - 2019-09-18 21:02:25 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:02:25 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:02:25 --> Utf8 Class Initialized
INFO - 2019-09-18 21:02:25 --> URI Class Initialized
INFO - 2019-09-18 21:02:25 --> Router Class Initialized
INFO - 2019-09-18 21:02:25 --> Output Class Initialized
INFO - 2019-09-18 21:02:25 --> Security Class Initialized
DEBUG - 2019-09-18 21:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:02:25 --> Input Class Initialized
INFO - 2019-09-18 21:02:25 --> Language Class Initialized
INFO - 2019-09-18 21:02:25 --> Loader Class Initialized
INFO - 2019-09-18 21:02:25 --> Helper loaded: url_helper
INFO - 2019-09-18 21:02:25 --> Helper loaded: html_helper
INFO - 2019-09-18 21:02:25 --> Helper loaded: form_helper
INFO - 2019-09-18 21:02:25 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:02:25 --> Helper loaded: date_helper
INFO - 2019-09-18 21:02:25 --> Form Validation Class Initialized
INFO - 2019-09-18 21:02:25 --> Email Class Initialized
DEBUG - 2019-09-18 21:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:02:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:02:25 --> Pagination Class Initialized
INFO - 2019-09-18 21:02:25 --> Database Driver Class Initialized
INFO - 2019-09-18 21:02:25 --> Database Driver Class Initialized
INFO - 2019-09-18 21:02:25 --> Controller Class Initialized
INFO - 2019-09-18 21:02:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 21:02:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-18 21:02:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 21:02:25 --> Final output sent to browser
DEBUG - 2019-09-18 21:02:25 --> Total execution time: 0.0582
INFO - 2019-09-18 21:02:25 --> Config Class Initialized
INFO - 2019-09-18 21:02:25 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:02:25 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:02:25 --> Utf8 Class Initialized
INFO - 2019-09-18 21:02:25 --> URI Class Initialized
INFO - 2019-09-18 21:02:25 --> Router Class Initialized
INFO - 2019-09-18 21:02:25 --> Output Class Initialized
INFO - 2019-09-18 21:02:25 --> Security Class Initialized
DEBUG - 2019-09-18 21:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:02:25 --> Input Class Initialized
INFO - 2019-09-18 21:02:25 --> Language Class Initialized
INFO - 2019-09-18 21:02:25 --> Loader Class Initialized
INFO - 2019-09-18 21:02:25 --> Helper loaded: url_helper
INFO - 2019-09-18 21:02:25 --> Helper loaded: html_helper
INFO - 2019-09-18 21:02:25 --> Helper loaded: form_helper
INFO - 2019-09-18 21:02:25 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:02:25 --> Helper loaded: date_helper
INFO - 2019-09-18 21:02:25 --> Form Validation Class Initialized
INFO - 2019-09-18 21:02:25 --> Email Class Initialized
DEBUG - 2019-09-18 21:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:02:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:02:25 --> Pagination Class Initialized
INFO - 2019-09-18 21:02:25 --> Database Driver Class Initialized
INFO - 2019-09-18 21:02:25 --> Database Driver Class Initialized
INFO - 2019-09-18 21:02:25 --> Controller Class Initialized
INFO - 2019-09-18 21:02:25 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 21:02:25 --> Final output sent to browser
DEBUG - 2019-09-18 21:02:25 --> Total execution time: 0.0617
INFO - 2019-09-18 21:02:57 --> Config Class Initialized
INFO - 2019-09-18 21:02:57 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:02:57 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:02:57 --> Utf8 Class Initialized
INFO - 2019-09-18 21:02:57 --> URI Class Initialized
INFO - 2019-09-18 21:02:57 --> Router Class Initialized
INFO - 2019-09-18 21:02:57 --> Output Class Initialized
INFO - 2019-09-18 21:02:57 --> Security Class Initialized
DEBUG - 2019-09-18 21:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:02:57 --> Input Class Initialized
INFO - 2019-09-18 21:02:57 --> Language Class Initialized
INFO - 2019-09-18 21:02:57 --> Loader Class Initialized
INFO - 2019-09-18 21:02:57 --> Helper loaded: url_helper
INFO - 2019-09-18 21:02:57 --> Helper loaded: html_helper
INFO - 2019-09-18 21:02:57 --> Helper loaded: form_helper
INFO - 2019-09-18 21:02:57 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:02:57 --> Helper loaded: date_helper
INFO - 2019-09-18 21:02:57 --> Form Validation Class Initialized
INFO - 2019-09-18 21:02:57 --> Email Class Initialized
DEBUG - 2019-09-18 21:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:02:57 --> Pagination Class Initialized
INFO - 2019-09-18 21:02:57 --> Database Driver Class Initialized
INFO - 2019-09-18 21:02:57 --> Database Driver Class Initialized
INFO - 2019-09-18 21:02:57 --> Controller Class Initialized
INFO - 2019-09-18 21:07:24 --> Config Class Initialized
INFO - 2019-09-18 21:07:24 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:07:24 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:07:24 --> Utf8 Class Initialized
INFO - 2019-09-18 21:07:24 --> URI Class Initialized
INFO - 2019-09-18 21:07:24 --> Router Class Initialized
INFO - 2019-09-18 21:07:24 --> Output Class Initialized
INFO - 2019-09-18 21:07:24 --> Security Class Initialized
DEBUG - 2019-09-18 21:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:07:24 --> Input Class Initialized
INFO - 2019-09-18 21:07:24 --> Language Class Initialized
INFO - 2019-09-18 21:07:24 --> Loader Class Initialized
INFO - 2019-09-18 21:07:24 --> Helper loaded: url_helper
INFO - 2019-09-18 21:07:24 --> Helper loaded: html_helper
INFO - 2019-09-18 21:07:24 --> Helper loaded: form_helper
INFO - 2019-09-18 21:07:24 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:07:24 --> Helper loaded: date_helper
INFO - 2019-09-18 21:07:24 --> Form Validation Class Initialized
INFO - 2019-09-18 21:07:24 --> Email Class Initialized
DEBUG - 2019-09-18 21:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:07:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:07:24 --> Pagination Class Initialized
INFO - 2019-09-18 21:07:24 --> Database Driver Class Initialized
INFO - 2019-09-18 21:07:24 --> Database Driver Class Initialized
INFO - 2019-09-18 21:07:24 --> Controller Class Initialized
INFO - 2019-09-18 21:07:24 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 21:07:24 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-18 21:07:24 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 21:07:24 --> Final output sent to browser
DEBUG - 2019-09-18 21:07:24 --> Total execution time: 0.0580
INFO - 2019-09-18 21:07:24 --> Config Class Initialized
INFO - 2019-09-18 21:07:24 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:07:24 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:07:24 --> Utf8 Class Initialized
INFO - 2019-09-18 21:07:24 --> URI Class Initialized
INFO - 2019-09-18 21:07:24 --> Router Class Initialized
INFO - 2019-09-18 21:07:24 --> Output Class Initialized
INFO - 2019-09-18 21:07:24 --> Security Class Initialized
DEBUG - 2019-09-18 21:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:07:24 --> Input Class Initialized
INFO - 2019-09-18 21:07:24 --> Language Class Initialized
INFO - 2019-09-18 21:07:24 --> Loader Class Initialized
INFO - 2019-09-18 21:07:24 --> Helper loaded: url_helper
INFO - 2019-09-18 21:07:24 --> Helper loaded: html_helper
INFO - 2019-09-18 21:07:24 --> Helper loaded: form_helper
INFO - 2019-09-18 21:07:24 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:07:24 --> Helper loaded: date_helper
INFO - 2019-09-18 21:07:24 --> Form Validation Class Initialized
INFO - 2019-09-18 21:07:24 --> Email Class Initialized
DEBUG - 2019-09-18 21:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:07:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:07:24 --> Pagination Class Initialized
INFO - 2019-09-18 21:07:24 --> Database Driver Class Initialized
INFO - 2019-09-18 21:07:24 --> Database Driver Class Initialized
INFO - 2019-09-18 21:07:24 --> Controller Class Initialized
INFO - 2019-09-18 21:07:24 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 21:07:24 --> Final output sent to browser
DEBUG - 2019-09-18 21:07:24 --> Total execution time: 0.0656
INFO - 2019-09-18 21:10:43 --> Config Class Initialized
INFO - 2019-09-18 21:10:43 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:10:43 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:10:43 --> Utf8 Class Initialized
INFO - 2019-09-18 21:10:43 --> URI Class Initialized
INFO - 2019-09-18 21:10:43 --> Router Class Initialized
INFO - 2019-09-18 21:10:43 --> Output Class Initialized
INFO - 2019-09-18 21:10:43 --> Security Class Initialized
DEBUG - 2019-09-18 21:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:10:43 --> Input Class Initialized
INFO - 2019-09-18 21:10:43 --> Language Class Initialized
INFO - 2019-09-18 21:10:43 --> Loader Class Initialized
INFO - 2019-09-18 21:10:43 --> Helper loaded: url_helper
INFO - 2019-09-18 21:10:43 --> Helper loaded: html_helper
INFO - 2019-09-18 21:10:43 --> Helper loaded: form_helper
INFO - 2019-09-18 21:10:43 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:10:43 --> Helper loaded: date_helper
INFO - 2019-09-18 21:10:43 --> Form Validation Class Initialized
INFO - 2019-09-18 21:10:43 --> Email Class Initialized
DEBUG - 2019-09-18 21:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:10:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:10:43 --> Pagination Class Initialized
INFO - 2019-09-18 21:10:43 --> Database Driver Class Initialized
INFO - 2019-09-18 21:10:43 --> Database Driver Class Initialized
INFO - 2019-09-18 21:10:43 --> Controller Class Initialized
DEBUG - 2019-09-18 21:10:43 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-18 21:10:43 --> Helper loaded: inflector_helper
INFO - 2019-09-18 21:10:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-18 21:10:43 --> Final output sent to browser
DEBUG - 2019-09-18 21:10:43 --> Total execution time: 0.0495
INFO - 2019-09-18 21:41:59 --> Config Class Initialized
INFO - 2019-09-18 21:41:59 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:41:59 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:41:59 --> Utf8 Class Initialized
INFO - 2019-09-18 21:41:59 --> URI Class Initialized
INFO - 2019-09-18 21:41:59 --> Router Class Initialized
INFO - 2019-09-18 21:41:59 --> Output Class Initialized
INFO - 2019-09-18 21:41:59 --> Security Class Initialized
DEBUG - 2019-09-18 21:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:41:59 --> Input Class Initialized
INFO - 2019-09-18 21:41:59 --> Language Class Initialized
INFO - 2019-09-18 21:41:59 --> Loader Class Initialized
INFO - 2019-09-18 21:41:59 --> Helper loaded: url_helper
INFO - 2019-09-18 21:41:59 --> Helper loaded: html_helper
INFO - 2019-09-18 21:41:59 --> Helper loaded: form_helper
INFO - 2019-09-18 21:41:59 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:41:59 --> Helper loaded: date_helper
INFO - 2019-09-18 21:41:59 --> Form Validation Class Initialized
INFO - 2019-09-18 21:41:59 --> Email Class Initialized
DEBUG - 2019-09-18 21:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:41:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:41:59 --> Pagination Class Initialized
INFO - 2019-09-18 21:41:59 --> Database Driver Class Initialized
INFO - 2019-09-18 21:41:59 --> Database Driver Class Initialized
INFO - 2019-09-18 21:41:59 --> Controller Class Initialized
INFO - 2019-09-18 21:42:11 --> Config Class Initialized
INFO - 2019-09-18 21:42:11 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:42:11 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:42:11 --> Utf8 Class Initialized
INFO - 2019-09-18 21:42:11 --> URI Class Initialized
INFO - 2019-09-18 21:42:11 --> Router Class Initialized
INFO - 2019-09-18 21:42:11 --> Output Class Initialized
INFO - 2019-09-18 21:42:11 --> Security Class Initialized
DEBUG - 2019-09-18 21:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:42:11 --> Input Class Initialized
INFO - 2019-09-18 21:42:11 --> Language Class Initialized
INFO - 2019-09-18 21:42:11 --> Loader Class Initialized
INFO - 2019-09-18 21:42:11 --> Helper loaded: url_helper
INFO - 2019-09-18 21:42:11 --> Helper loaded: html_helper
INFO - 2019-09-18 21:42:11 --> Helper loaded: form_helper
INFO - 2019-09-18 21:42:11 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:42:11 --> Helper loaded: date_helper
INFO - 2019-09-18 21:42:11 --> Form Validation Class Initialized
INFO - 2019-09-18 21:42:11 --> Email Class Initialized
DEBUG - 2019-09-18 21:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:42:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:42:11 --> Pagination Class Initialized
INFO - 2019-09-18 21:42:11 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:11 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:11 --> Controller Class Initialized
INFO - 2019-09-18 21:42:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 21:42:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-18 21:42:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 21:42:11 --> Final output sent to browser
DEBUG - 2019-09-18 21:42:11 --> Total execution time: 0.0560
INFO - 2019-09-18 21:42:11 --> Config Class Initialized
INFO - 2019-09-18 21:42:11 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:42:11 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:42:11 --> Utf8 Class Initialized
INFO - 2019-09-18 21:42:11 --> URI Class Initialized
INFO - 2019-09-18 21:42:11 --> Router Class Initialized
INFO - 2019-09-18 21:42:11 --> Output Class Initialized
INFO - 2019-09-18 21:42:11 --> Security Class Initialized
DEBUG - 2019-09-18 21:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:42:11 --> Input Class Initialized
INFO - 2019-09-18 21:42:11 --> Language Class Initialized
INFO - 2019-09-18 21:42:11 --> Loader Class Initialized
INFO - 2019-09-18 21:42:11 --> Helper loaded: url_helper
INFO - 2019-09-18 21:42:11 --> Helper loaded: html_helper
INFO - 2019-09-18 21:42:11 --> Helper loaded: form_helper
INFO - 2019-09-18 21:42:11 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:42:11 --> Helper loaded: date_helper
INFO - 2019-09-18 21:42:11 --> Form Validation Class Initialized
INFO - 2019-09-18 21:42:11 --> Email Class Initialized
DEBUG - 2019-09-18 21:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:42:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:42:11 --> Pagination Class Initialized
INFO - 2019-09-18 21:42:11 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:11 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:11 --> Controller Class Initialized
INFO - 2019-09-18 21:42:11 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 21:42:11 --> Final output sent to browser
DEBUG - 2019-09-18 21:42:11 --> Total execution time: 0.0609
INFO - 2019-09-18 21:42:15 --> Config Class Initialized
INFO - 2019-09-18 21:42:15 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:42:15 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:42:15 --> Utf8 Class Initialized
INFO - 2019-09-18 21:42:15 --> URI Class Initialized
INFO - 2019-09-18 21:42:15 --> Router Class Initialized
INFO - 2019-09-18 21:42:15 --> Output Class Initialized
INFO - 2019-09-18 21:42:15 --> Security Class Initialized
DEBUG - 2019-09-18 21:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:42:15 --> Input Class Initialized
INFO - 2019-09-18 21:42:15 --> Language Class Initialized
INFO - 2019-09-18 21:42:15 --> Loader Class Initialized
INFO - 2019-09-18 21:42:15 --> Helper loaded: url_helper
INFO - 2019-09-18 21:42:15 --> Helper loaded: html_helper
INFO - 2019-09-18 21:42:15 --> Helper loaded: form_helper
INFO - 2019-09-18 21:42:15 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:42:15 --> Helper loaded: date_helper
INFO - 2019-09-18 21:42:15 --> Form Validation Class Initialized
INFO - 2019-09-18 21:42:15 --> Email Class Initialized
DEBUG - 2019-09-18 21:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:42:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:42:15 --> Pagination Class Initialized
INFO - 2019-09-18 21:42:15 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:15 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:15 --> Controller Class Initialized
INFO - 2019-09-18 21:42:22 --> Config Class Initialized
INFO - 2019-09-18 21:42:22 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:42:22 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:42:22 --> Utf8 Class Initialized
INFO - 2019-09-18 21:42:22 --> URI Class Initialized
INFO - 2019-09-18 21:42:22 --> Router Class Initialized
INFO - 2019-09-18 21:42:22 --> Output Class Initialized
INFO - 2019-09-18 21:42:22 --> Security Class Initialized
DEBUG - 2019-09-18 21:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:42:22 --> Input Class Initialized
INFO - 2019-09-18 21:42:22 --> Language Class Initialized
INFO - 2019-09-18 21:42:22 --> Loader Class Initialized
INFO - 2019-09-18 21:42:22 --> Helper loaded: url_helper
INFO - 2019-09-18 21:42:22 --> Helper loaded: html_helper
INFO - 2019-09-18 21:42:22 --> Helper loaded: form_helper
INFO - 2019-09-18 21:42:22 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:42:22 --> Helper loaded: date_helper
INFO - 2019-09-18 21:42:22 --> Form Validation Class Initialized
INFO - 2019-09-18 21:42:22 --> Email Class Initialized
DEBUG - 2019-09-18 21:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:42:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:42:22 --> Pagination Class Initialized
INFO - 2019-09-18 21:42:22 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:22 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:22 --> Controller Class Initialized
INFO - 2019-09-18 21:42:22 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 21:42:22 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-18 21:42:22 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 21:42:22 --> Final output sent to browser
DEBUG - 2019-09-18 21:42:22 --> Total execution time: 0.0556
INFO - 2019-09-18 21:42:23 --> Config Class Initialized
INFO - 2019-09-18 21:42:23 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:42:23 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:42:23 --> Utf8 Class Initialized
INFO - 2019-09-18 21:42:23 --> URI Class Initialized
INFO - 2019-09-18 21:42:23 --> Router Class Initialized
INFO - 2019-09-18 21:42:23 --> Output Class Initialized
INFO - 2019-09-18 21:42:23 --> Security Class Initialized
DEBUG - 2019-09-18 21:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:42:23 --> Input Class Initialized
INFO - 2019-09-18 21:42:23 --> Language Class Initialized
INFO - 2019-09-18 21:42:23 --> Loader Class Initialized
INFO - 2019-09-18 21:42:23 --> Helper loaded: url_helper
INFO - 2019-09-18 21:42:23 --> Helper loaded: html_helper
INFO - 2019-09-18 21:42:23 --> Helper loaded: form_helper
INFO - 2019-09-18 21:42:23 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:42:23 --> Helper loaded: date_helper
INFO - 2019-09-18 21:42:23 --> Form Validation Class Initialized
INFO - 2019-09-18 21:42:23 --> Email Class Initialized
DEBUG - 2019-09-18 21:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:42:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:42:23 --> Pagination Class Initialized
INFO - 2019-09-18 21:42:23 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:23 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:23 --> Controller Class Initialized
INFO - 2019-09-18 21:42:23 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 21:42:23 --> Final output sent to browser
DEBUG - 2019-09-18 21:42:23 --> Total execution time: 0.0620
INFO - 2019-09-18 21:42:26 --> Config Class Initialized
INFO - 2019-09-18 21:42:26 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:42:26 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:42:26 --> Utf8 Class Initialized
INFO - 2019-09-18 21:42:26 --> URI Class Initialized
INFO - 2019-09-18 21:42:26 --> Router Class Initialized
INFO - 2019-09-18 21:42:26 --> Output Class Initialized
INFO - 2019-09-18 21:42:26 --> Security Class Initialized
DEBUG - 2019-09-18 21:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:42:26 --> Input Class Initialized
INFO - 2019-09-18 21:42:26 --> Language Class Initialized
INFO - 2019-09-18 21:42:26 --> Loader Class Initialized
INFO - 2019-09-18 21:42:26 --> Helper loaded: url_helper
INFO - 2019-09-18 21:42:26 --> Helper loaded: html_helper
INFO - 2019-09-18 21:42:26 --> Helper loaded: form_helper
INFO - 2019-09-18 21:42:26 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:42:26 --> Helper loaded: date_helper
INFO - 2019-09-18 21:42:26 --> Form Validation Class Initialized
INFO - 2019-09-18 21:42:26 --> Email Class Initialized
DEBUG - 2019-09-18 21:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:42:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:42:26 --> Pagination Class Initialized
INFO - 2019-09-18 21:42:26 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:26 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:26 --> Controller Class Initialized
INFO - 2019-09-18 21:42:32 --> Config Class Initialized
INFO - 2019-09-18 21:42:32 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:42:32 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:42:32 --> Utf8 Class Initialized
INFO - 2019-09-18 21:42:32 --> URI Class Initialized
INFO - 2019-09-18 21:42:32 --> Router Class Initialized
INFO - 2019-09-18 21:42:32 --> Output Class Initialized
INFO - 2019-09-18 21:42:32 --> Security Class Initialized
DEBUG - 2019-09-18 21:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:42:32 --> Input Class Initialized
INFO - 2019-09-18 21:42:32 --> Language Class Initialized
INFO - 2019-09-18 21:42:32 --> Loader Class Initialized
INFO - 2019-09-18 21:42:32 --> Helper loaded: url_helper
INFO - 2019-09-18 21:42:32 --> Helper loaded: html_helper
INFO - 2019-09-18 21:42:32 --> Helper loaded: form_helper
INFO - 2019-09-18 21:42:32 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:42:32 --> Helper loaded: date_helper
INFO - 2019-09-18 21:42:32 --> Form Validation Class Initialized
INFO - 2019-09-18 21:42:32 --> Email Class Initialized
DEBUG - 2019-09-18 21:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:42:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:42:32 --> Pagination Class Initialized
INFO - 2019-09-18 21:42:32 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:32 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:32 --> Controller Class Initialized
INFO - 2019-09-18 21:42:32 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 21:42:32 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-18 21:42:32 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 21:42:32 --> Final output sent to browser
DEBUG - 2019-09-18 21:42:32 --> Total execution time: 0.0708
INFO - 2019-09-18 21:42:32 --> Config Class Initialized
INFO - 2019-09-18 21:42:32 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:42:32 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:42:32 --> Utf8 Class Initialized
INFO - 2019-09-18 21:42:32 --> URI Class Initialized
INFO - 2019-09-18 21:42:32 --> Router Class Initialized
INFO - 2019-09-18 21:42:32 --> Output Class Initialized
INFO - 2019-09-18 21:42:32 --> Security Class Initialized
DEBUG - 2019-09-18 21:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:42:32 --> Input Class Initialized
INFO - 2019-09-18 21:42:32 --> Language Class Initialized
INFO - 2019-09-18 21:42:32 --> Loader Class Initialized
INFO - 2019-09-18 21:42:32 --> Helper loaded: url_helper
INFO - 2019-09-18 21:42:32 --> Helper loaded: html_helper
INFO - 2019-09-18 21:42:32 --> Helper loaded: form_helper
INFO - 2019-09-18 21:42:32 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:42:32 --> Helper loaded: date_helper
INFO - 2019-09-18 21:42:32 --> Form Validation Class Initialized
INFO - 2019-09-18 21:42:32 --> Email Class Initialized
DEBUG - 2019-09-18 21:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:42:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:42:32 --> Pagination Class Initialized
INFO - 2019-09-18 21:42:32 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:32 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:32 --> Controller Class Initialized
INFO - 2019-09-18 21:42:32 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 21:42:32 --> Final output sent to browser
DEBUG - 2019-09-18 21:42:32 --> Total execution time: 0.0621
INFO - 2019-09-18 21:42:36 --> Config Class Initialized
INFO - 2019-09-18 21:42:36 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:42:36 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:42:36 --> Utf8 Class Initialized
INFO - 2019-09-18 21:42:36 --> URI Class Initialized
INFO - 2019-09-18 21:42:36 --> Router Class Initialized
INFO - 2019-09-18 21:42:36 --> Output Class Initialized
INFO - 2019-09-18 21:42:36 --> Security Class Initialized
DEBUG - 2019-09-18 21:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:42:36 --> Input Class Initialized
INFO - 2019-09-18 21:42:36 --> Language Class Initialized
INFO - 2019-09-18 21:42:36 --> Loader Class Initialized
INFO - 2019-09-18 21:42:36 --> Helper loaded: url_helper
INFO - 2019-09-18 21:42:36 --> Helper loaded: html_helper
INFO - 2019-09-18 21:42:36 --> Helper loaded: form_helper
INFO - 2019-09-18 21:42:36 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:42:36 --> Helper loaded: date_helper
INFO - 2019-09-18 21:42:36 --> Form Validation Class Initialized
INFO - 2019-09-18 21:42:36 --> Email Class Initialized
DEBUG - 2019-09-18 21:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:42:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:42:36 --> Pagination Class Initialized
INFO - 2019-09-18 21:42:36 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:36 --> Database Driver Class Initialized
INFO - 2019-09-18 21:42:36 --> Controller Class Initialized
INFO - 2019-09-18 21:42:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-18 21:42:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report_ledger.php
INFO - 2019-09-18 21:42:36 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 21:42:36 --> Final output sent to browser
DEBUG - 2019-09-18 21:42:36 --> Total execution time: 0.0848
INFO - 2019-09-18 21:44:05 --> Config Class Initialized
INFO - 2019-09-18 21:44:05 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:44:05 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:44:05 --> Utf8 Class Initialized
INFO - 2019-09-18 21:44:05 --> URI Class Initialized
INFO - 2019-09-18 21:44:05 --> Router Class Initialized
INFO - 2019-09-18 21:44:05 --> Output Class Initialized
INFO - 2019-09-18 21:44:05 --> Security Class Initialized
DEBUG - 2019-09-18 21:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:44:05 --> Input Class Initialized
INFO - 2019-09-18 21:44:05 --> Language Class Initialized
INFO - 2019-09-18 21:44:05 --> Loader Class Initialized
INFO - 2019-09-18 21:44:05 --> Helper loaded: url_helper
INFO - 2019-09-18 21:44:05 --> Helper loaded: html_helper
INFO - 2019-09-18 21:44:05 --> Helper loaded: form_helper
INFO - 2019-09-18 21:44:05 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:44:05 --> Helper loaded: date_helper
INFO - 2019-09-18 21:44:05 --> Form Validation Class Initialized
INFO - 2019-09-18 21:44:05 --> Email Class Initialized
DEBUG - 2019-09-18 21:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:44:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:44:05 --> Pagination Class Initialized
INFO - 2019-09-18 21:44:05 --> Database Driver Class Initialized
INFO - 2019-09-18 21:44:05 --> Database Driver Class Initialized
INFO - 2019-09-18 21:44:05 --> Controller Class Initialized
INFO - 2019-09-18 21:44:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 21:44:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-18 21:44:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 21:44:05 --> Final output sent to browser
DEBUG - 2019-09-18 21:44:05 --> Total execution time: 0.0601
INFO - 2019-09-18 21:44:05 --> Config Class Initialized
INFO - 2019-09-18 21:44:05 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:44:05 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:44:05 --> Utf8 Class Initialized
INFO - 2019-09-18 21:44:05 --> URI Class Initialized
INFO - 2019-09-18 21:44:05 --> Router Class Initialized
INFO - 2019-09-18 21:44:05 --> Output Class Initialized
INFO - 2019-09-18 21:44:05 --> Security Class Initialized
DEBUG - 2019-09-18 21:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:44:05 --> Input Class Initialized
INFO - 2019-09-18 21:44:05 --> Language Class Initialized
INFO - 2019-09-18 21:44:05 --> Loader Class Initialized
INFO - 2019-09-18 21:44:05 --> Helper loaded: url_helper
INFO - 2019-09-18 21:44:05 --> Helper loaded: html_helper
INFO - 2019-09-18 21:44:05 --> Helper loaded: form_helper
INFO - 2019-09-18 21:44:05 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:44:05 --> Helper loaded: date_helper
INFO - 2019-09-18 21:44:05 --> Form Validation Class Initialized
INFO - 2019-09-18 21:44:05 --> Email Class Initialized
DEBUG - 2019-09-18 21:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:44:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:44:05 --> Pagination Class Initialized
INFO - 2019-09-18 21:44:05 --> Database Driver Class Initialized
INFO - 2019-09-18 21:44:05 --> Database Driver Class Initialized
INFO - 2019-09-18 21:44:05 --> Controller Class Initialized
INFO - 2019-09-18 21:44:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 21:44:05 --> Final output sent to browser
DEBUG - 2019-09-18 21:44:05 --> Total execution time: 0.0608
INFO - 2019-09-18 21:44:10 --> Config Class Initialized
INFO - 2019-09-18 21:44:10 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:44:10 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:44:10 --> Utf8 Class Initialized
INFO - 2019-09-18 21:44:10 --> URI Class Initialized
INFO - 2019-09-18 21:44:10 --> Router Class Initialized
INFO - 2019-09-18 21:44:10 --> Output Class Initialized
INFO - 2019-09-18 21:44:10 --> Security Class Initialized
DEBUG - 2019-09-18 21:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:44:10 --> Input Class Initialized
INFO - 2019-09-18 21:44:10 --> Language Class Initialized
INFO - 2019-09-18 21:44:10 --> Loader Class Initialized
INFO - 2019-09-18 21:44:10 --> Helper loaded: url_helper
INFO - 2019-09-18 21:44:10 --> Helper loaded: html_helper
INFO - 2019-09-18 21:44:10 --> Helper loaded: form_helper
INFO - 2019-09-18 21:44:10 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:44:10 --> Helper loaded: date_helper
INFO - 2019-09-18 21:44:10 --> Form Validation Class Initialized
INFO - 2019-09-18 21:44:10 --> Email Class Initialized
DEBUG - 2019-09-18 21:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:44:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:44:10 --> Pagination Class Initialized
INFO - 2019-09-18 21:44:10 --> Database Driver Class Initialized
INFO - 2019-09-18 21:44:10 --> Database Driver Class Initialized
INFO - 2019-09-18 21:44:10 --> Controller Class Initialized
INFO - 2019-09-18 21:44:39 --> Config Class Initialized
INFO - 2019-09-18 21:44:39 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:44:39 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:44:39 --> Utf8 Class Initialized
INFO - 2019-09-18 21:44:39 --> URI Class Initialized
INFO - 2019-09-18 21:44:39 --> Router Class Initialized
INFO - 2019-09-18 21:44:39 --> Output Class Initialized
INFO - 2019-09-18 21:44:39 --> Security Class Initialized
DEBUG - 2019-09-18 21:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:44:39 --> Input Class Initialized
INFO - 2019-09-18 21:44:39 --> Language Class Initialized
INFO - 2019-09-18 21:44:39 --> Loader Class Initialized
INFO - 2019-09-18 21:44:39 --> Helper loaded: url_helper
INFO - 2019-09-18 21:44:39 --> Helper loaded: html_helper
INFO - 2019-09-18 21:44:39 --> Helper loaded: form_helper
INFO - 2019-09-18 21:44:39 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:44:39 --> Helper loaded: date_helper
INFO - 2019-09-18 21:44:39 --> Form Validation Class Initialized
INFO - 2019-09-18 21:44:39 --> Email Class Initialized
DEBUG - 2019-09-18 21:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:44:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:44:39 --> Pagination Class Initialized
INFO - 2019-09-18 21:44:39 --> Database Driver Class Initialized
INFO - 2019-09-18 21:44:39 --> Database Driver Class Initialized
INFO - 2019-09-18 21:44:39 --> Controller Class Initialized
INFO - 2019-09-18 21:44:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-18 21:44:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-18 21:44:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-18 21:44:39 --> Final output sent to browser
DEBUG - 2019-09-18 21:44:39 --> Total execution time: 0.0580
INFO - 2019-09-18 21:44:39 --> Config Class Initialized
INFO - 2019-09-18 21:44:39 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:44:39 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:44:39 --> Utf8 Class Initialized
INFO - 2019-09-18 21:44:39 --> URI Class Initialized
INFO - 2019-09-18 21:44:39 --> Router Class Initialized
INFO - 2019-09-18 21:44:39 --> Output Class Initialized
INFO - 2019-09-18 21:44:39 --> Security Class Initialized
DEBUG - 2019-09-18 21:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:44:39 --> Input Class Initialized
INFO - 2019-09-18 21:44:39 --> Language Class Initialized
INFO - 2019-09-18 21:44:39 --> Loader Class Initialized
INFO - 2019-09-18 21:44:39 --> Helper loaded: url_helper
INFO - 2019-09-18 21:44:39 --> Helper loaded: html_helper
INFO - 2019-09-18 21:44:39 --> Helper loaded: form_helper
INFO - 2019-09-18 21:44:39 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:44:39 --> Helper loaded: date_helper
INFO - 2019-09-18 21:44:39 --> Form Validation Class Initialized
INFO - 2019-09-18 21:44:39 --> Email Class Initialized
DEBUG - 2019-09-18 21:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:44:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:44:39 --> Pagination Class Initialized
INFO - 2019-09-18 21:44:39 --> Database Driver Class Initialized
INFO - 2019-09-18 21:44:39 --> Database Driver Class Initialized
INFO - 2019-09-18 21:44:39 --> Controller Class Initialized
INFO - 2019-09-18 21:44:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 21:44:39 --> Final output sent to browser
DEBUG - 2019-09-18 21:44:39 --> Total execution time: 0.0625
INFO - 2019-09-18 21:44:39 --> Config Class Initialized
INFO - 2019-09-18 21:44:39 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:44:39 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:44:39 --> Utf8 Class Initialized
INFO - 2019-09-18 21:44:39 --> URI Class Initialized
INFO - 2019-09-18 21:44:39 --> Router Class Initialized
INFO - 2019-09-18 21:44:39 --> Output Class Initialized
INFO - 2019-09-18 21:44:39 --> Security Class Initialized
DEBUG - 2019-09-18 21:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:44:39 --> Input Class Initialized
INFO - 2019-09-18 21:44:39 --> Language Class Initialized
INFO - 2019-09-18 21:44:39 --> Loader Class Initialized
INFO - 2019-09-18 21:44:39 --> Helper loaded: url_helper
INFO - 2019-09-18 21:44:39 --> Helper loaded: html_helper
INFO - 2019-09-18 21:44:39 --> Helper loaded: form_helper
INFO - 2019-09-18 21:44:39 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:44:39 --> Helper loaded: date_helper
INFO - 2019-09-18 21:44:39 --> Form Validation Class Initialized
INFO - 2019-09-18 21:44:39 --> Email Class Initialized
DEBUG - 2019-09-18 21:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:44:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:44:39 --> Pagination Class Initialized
INFO - 2019-09-18 21:44:39 --> Database Driver Class Initialized
INFO - 2019-09-18 21:44:39 --> Database Driver Class Initialized
INFO - 2019-09-18 21:44:39 --> Controller Class Initialized
INFO - 2019-09-18 21:44:39 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-18 21:44:39 --> Final output sent to browser
DEBUG - 2019-09-18 21:44:39 --> Total execution time: 0.0700
INFO - 2019-09-18 21:44:43 --> Config Class Initialized
INFO - 2019-09-18 21:44:43 --> Hooks Class Initialized
DEBUG - 2019-09-18 21:44:43 --> UTF-8 Support Enabled
INFO - 2019-09-18 21:44:43 --> Utf8 Class Initialized
INFO - 2019-09-18 21:44:43 --> URI Class Initialized
INFO - 2019-09-18 21:44:43 --> Router Class Initialized
INFO - 2019-09-18 21:44:43 --> Output Class Initialized
INFO - 2019-09-18 21:44:43 --> Security Class Initialized
DEBUG - 2019-09-18 21:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 21:44:43 --> Input Class Initialized
INFO - 2019-09-18 21:44:43 --> Language Class Initialized
INFO - 2019-09-18 21:44:43 --> Loader Class Initialized
INFO - 2019-09-18 21:44:43 --> Helper loaded: url_helper
INFO - 2019-09-18 21:44:43 --> Helper loaded: html_helper
INFO - 2019-09-18 21:44:43 --> Helper loaded: form_helper
INFO - 2019-09-18 21:44:43 --> Helper loaded: cookie_helper
INFO - 2019-09-18 21:44:43 --> Helper loaded: date_helper
INFO - 2019-09-18 21:44:43 --> Form Validation Class Initialized
INFO - 2019-09-18 21:44:43 --> Email Class Initialized
DEBUG - 2019-09-18 21:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 21:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 21:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 21:44:43 --> Pagination Class Initialized
INFO - 2019-09-18 21:44:43 --> Database Driver Class Initialized
INFO - 2019-09-18 21:44:43 --> Database Driver Class Initialized
INFO - 2019-09-18 21:44:43 --> Controller Class Initialized
INFO - 2019-09-18 23:10:47 --> Config Class Initialized
INFO - 2019-09-18 23:10:47 --> Hooks Class Initialized
DEBUG - 2019-09-18 23:10:47 --> UTF-8 Support Enabled
INFO - 2019-09-18 23:10:47 --> Utf8 Class Initialized
INFO - 2019-09-18 23:10:47 --> URI Class Initialized
INFO - 2019-09-18 23:10:47 --> Router Class Initialized
INFO - 2019-09-18 23:10:47 --> Output Class Initialized
INFO - 2019-09-18 23:10:47 --> Security Class Initialized
DEBUG - 2019-09-18 23:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 23:10:47 --> Input Class Initialized
INFO - 2019-09-18 23:10:47 --> Language Class Initialized
INFO - 2019-09-18 23:10:47 --> Loader Class Initialized
INFO - 2019-09-18 23:10:47 --> Helper loaded: url_helper
INFO - 2019-09-18 23:10:47 --> Helper loaded: html_helper
INFO - 2019-09-18 23:10:47 --> Helper loaded: form_helper
INFO - 2019-09-18 23:10:47 --> Helper loaded: cookie_helper
INFO - 2019-09-18 23:10:47 --> Helper loaded: date_helper
INFO - 2019-09-18 23:10:47 --> Form Validation Class Initialized
INFO - 2019-09-18 23:10:47 --> Email Class Initialized
DEBUG - 2019-09-18 23:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 23:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 23:10:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-18 23:10:47 --> Pagination Class Initialized
INFO - 2019-09-18 23:10:47 --> Database Driver Class Initialized
INFO - 2019-09-18 23:10:47 --> Database Driver Class Initialized
INFO - 2019-09-18 23:10:47 --> Controller Class Initialized
DEBUG - 2019-09-18 23:10:47 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-18 23:10:47 --> Helper loaded: inflector_helper
INFO - 2019-09-18 23:10:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-18 23:10:47 --> Final output sent to browser
DEBUG - 2019-09-18 23:10:47 --> Total execution time: 0.5489
