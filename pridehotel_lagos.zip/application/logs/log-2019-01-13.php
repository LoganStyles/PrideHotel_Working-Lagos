<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-01-13 04:50:09 --> Config Class Initialized
INFO - 2019-01-13 04:50:09 --> Hooks Class Initialized
DEBUG - 2019-01-13 04:50:09 --> UTF-8 Support Enabled
INFO - 2019-01-13 04:50:09 --> Utf8 Class Initialized
INFO - 2019-01-13 04:50:09 --> URI Class Initialized
INFO - 2019-01-13 04:50:09 --> Router Class Initialized
INFO - 2019-01-13 04:50:09 --> Output Class Initialized
INFO - 2019-01-13 04:50:09 --> Security Class Initialized
DEBUG - 2019-01-13 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-13 04:50:09 --> Input Class Initialized
INFO - 2019-01-13 04:50:09 --> Language Class Initialized
INFO - 2019-01-13 04:50:09 --> Loader Class Initialized
INFO - 2019-01-13 04:50:09 --> Helper loaded: url_helper
INFO - 2019-01-13 04:50:09 --> Helper loaded: html_helper
INFO - 2019-01-13 04:50:09 --> Helper loaded: form_helper
INFO - 2019-01-13 04:50:09 --> Helper loaded: cookie_helper
INFO - 2019-01-13 04:50:09 --> Helper loaded: date_helper
INFO - 2019-01-13 04:50:09 --> Form Validation Class Initialized
INFO - 2019-01-13 04:50:09 --> Email Class Initialized
DEBUG - 2019-01-13 04:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-13 04:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-13 04:50:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-13 04:50:09 --> Pagination Class Initialized
INFO - 2019-01-13 04:50:09 --> Database Driver Class Initialized
INFO - 2019-01-13 04:50:09 --> Database Driver Class Initialized
INFO - 2019-01-13 04:50:09 --> Controller Class Initialized
INFO - 2019-01-13 04:50:09 --> Config Class Initialized
INFO - 2019-01-13 04:50:09 --> Hooks Class Initialized
DEBUG - 2019-01-13 04:50:09 --> UTF-8 Support Enabled
INFO - 2019-01-13 04:50:09 --> Utf8 Class Initialized
INFO - 2019-01-13 04:50:09 --> URI Class Initialized
INFO - 2019-01-13 04:50:09 --> Router Class Initialized
INFO - 2019-01-13 04:50:09 --> Output Class Initialized
INFO - 2019-01-13 04:50:09 --> Security Class Initialized
DEBUG - 2019-01-13 04:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-13 04:50:09 --> Input Class Initialized
INFO - 2019-01-13 04:50:09 --> Language Class Initialized
INFO - 2019-01-13 04:50:09 --> Loader Class Initialized
INFO - 2019-01-13 04:50:09 --> Helper loaded: url_helper
INFO - 2019-01-13 04:50:09 --> Helper loaded: html_helper
INFO - 2019-01-13 04:50:09 --> Helper loaded: form_helper
INFO - 2019-01-13 04:50:09 --> Helper loaded: cookie_helper
INFO - 2019-01-13 04:50:09 --> Helper loaded: date_helper
INFO - 2019-01-13 04:50:09 --> Form Validation Class Initialized
INFO - 2019-01-13 04:50:09 --> Email Class Initialized
DEBUG - 2019-01-13 04:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-13 04:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-13 04:50:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-13 04:50:09 --> Pagination Class Initialized
INFO - 2019-01-13 04:50:09 --> Database Driver Class Initialized
INFO - 2019-01-13 04:50:09 --> Database Driver Class Initialized
INFO - 2019-01-13 04:50:09 --> Controller Class Initialized
INFO - 2019-01-13 04:50:09 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2019-01-13 04:50:09 --> Final output sent to browser
DEBUG - 2019-01-13 04:50:09 --> Total execution time: 0.0547
INFO - 2019-01-13 05:01:12 --> Config Class Initialized
INFO - 2019-01-13 05:01:12 --> Hooks Class Initialized
DEBUG - 2019-01-13 05:01:12 --> UTF-8 Support Enabled
INFO - 2019-01-13 05:01:12 --> Utf8 Class Initialized
INFO - 2019-01-13 05:01:12 --> URI Class Initialized
INFO - 2019-01-13 05:01:12 --> Router Class Initialized
INFO - 2019-01-13 05:01:12 --> Output Class Initialized
INFO - 2019-01-13 05:01:12 --> Security Class Initialized
DEBUG - 2019-01-13 05:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-13 05:01:12 --> Input Class Initialized
INFO - 2019-01-13 05:01:12 --> Language Class Initialized
INFO - 2019-01-13 05:01:12 --> Loader Class Initialized
INFO - 2019-01-13 05:01:12 --> Helper loaded: url_helper
INFO - 2019-01-13 05:01:12 --> Helper loaded: html_helper
INFO - 2019-01-13 05:01:12 --> Helper loaded: form_helper
INFO - 2019-01-13 05:01:12 --> Helper loaded: cookie_helper
INFO - 2019-01-13 05:01:12 --> Helper loaded: date_helper
INFO - 2019-01-13 05:01:12 --> Form Validation Class Initialized
INFO - 2019-01-13 05:01:12 --> Email Class Initialized
DEBUG - 2019-01-13 05:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-13 05:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-13 05:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-13 05:01:12 --> Pagination Class Initialized
INFO - 2019-01-13 05:01:12 --> Database Driver Class Initialized
INFO - 2019-01-13 05:01:12 --> Database Driver Class Initialized
INFO - 2019-01-13 05:01:12 --> Controller Class Initialized
INFO - 2019-01-13 05:01:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-01-13 05:01:12 --> Config Class Initialized
INFO - 2019-01-13 05:01:12 --> Hooks Class Initialized
DEBUG - 2019-01-13 05:01:12 --> UTF-8 Support Enabled
INFO - 2019-01-13 05:01:12 --> Utf8 Class Initialized
INFO - 2019-01-13 05:01:12 --> URI Class Initialized
INFO - 2019-01-13 05:01:12 --> Router Class Initialized
INFO - 2019-01-13 05:01:12 --> Output Class Initialized
INFO - 2019-01-13 05:01:12 --> Security Class Initialized
DEBUG - 2019-01-13 05:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-13 05:01:12 --> Input Class Initialized
INFO - 2019-01-13 05:01:12 --> Language Class Initialized
INFO - 2019-01-13 05:01:12 --> Loader Class Initialized
INFO - 2019-01-13 05:01:12 --> Helper loaded: url_helper
INFO - 2019-01-13 05:01:12 --> Helper loaded: html_helper
INFO - 2019-01-13 05:01:12 --> Helper loaded: form_helper
INFO - 2019-01-13 05:01:12 --> Helper loaded: cookie_helper
INFO - 2019-01-13 05:01:12 --> Helper loaded: date_helper
INFO - 2019-01-13 05:01:12 --> Form Validation Class Initialized
INFO - 2019-01-13 05:01:12 --> Email Class Initialized
DEBUG - 2019-01-13 05:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-13 05:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-13 05:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-13 05:01:12 --> Pagination Class Initialized
INFO - 2019-01-13 05:01:12 --> Database Driver Class Initialized
INFO - 2019-01-13 05:01:12 --> Database Driver Class Initialized
INFO - 2019-01-13 05:01:12 --> Controller Class Initialized
INFO - 2019-01-13 05:01:12 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-01-13 05:01:12 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-01-13 05:01:12 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-01-13 05:01:12 --> Final output sent to browser
DEBUG - 2019-01-13 05:01:12 --> Total execution time: 0.0965
INFO - 2019-01-13 05:01:14 --> Config Class Initialized
INFO - 2019-01-13 05:01:14 --> Hooks Class Initialized
DEBUG - 2019-01-13 05:01:14 --> UTF-8 Support Enabled
INFO - 2019-01-13 05:01:14 --> Config Class Initialized
INFO - 2019-01-13 05:01:14 --> Utf8 Class Initialized
INFO - 2019-01-13 05:01:14 --> Hooks Class Initialized
INFO - 2019-01-13 05:01:14 --> URI Class Initialized
DEBUG - 2019-01-13 05:01:14 --> UTF-8 Support Enabled
INFO - 2019-01-13 05:01:14 --> Router Class Initialized
INFO - 2019-01-13 05:01:14 --> Utf8 Class Initialized
INFO - 2019-01-13 05:01:14 --> URI Class Initialized
INFO - 2019-01-13 05:01:14 --> Output Class Initialized
INFO - 2019-01-13 05:01:14 --> Router Class Initialized
INFO - 2019-01-13 05:01:14 --> Security Class Initialized
INFO - 2019-01-13 05:01:14 --> Output Class Initialized
DEBUG - 2019-01-13 05:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-13 05:01:14 --> Input Class Initialized
INFO - 2019-01-13 05:01:14 --> Security Class Initialized
INFO - 2019-01-13 05:01:14 --> Language Class Initialized
DEBUG - 2019-01-13 05:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-13 05:01:14 --> Input Class Initialized
INFO - 2019-01-13 05:01:14 --> Language Class Initialized
INFO - 2019-01-13 05:01:14 --> Loader Class Initialized
INFO - 2019-01-13 05:01:14 --> Helper loaded: url_helper
INFO - 2019-01-13 05:01:14 --> Loader Class Initialized
INFO - 2019-01-13 05:01:14 --> Helper loaded: html_helper
INFO - 2019-01-13 05:01:14 --> Helper loaded: url_helper
INFO - 2019-01-13 05:01:14 --> Helper loaded: html_helper
INFO - 2019-01-13 05:01:14 --> Helper loaded: form_helper
INFO - 2019-01-13 05:01:14 --> Helper loaded: cookie_helper
INFO - 2019-01-13 05:01:14 --> Helper loaded: form_helper
INFO - 2019-01-13 05:01:14 --> Helper loaded: date_helper
INFO - 2019-01-13 05:01:14 --> Helper loaded: cookie_helper
INFO - 2019-01-13 05:01:14 --> Helper loaded: date_helper
INFO - 2019-01-13 05:01:14 --> Form Validation Class Initialized
INFO - 2019-01-13 05:01:14 --> Form Validation Class Initialized
INFO - 2019-01-13 05:01:14 --> Email Class Initialized
DEBUG - 2019-01-13 05:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-13 05:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-13 05:01:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-13 05:01:14 --> Pagination Class Initialized
INFO - 2019-01-13 05:01:14 --> Email Class Initialized
DEBUG - 2019-01-13 05:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-13 05:01:14 --> Database Driver Class Initialized
INFO - 2019-01-13 05:01:14 --> Database Driver Class Initialized
INFO - 2019-01-13 05:01:14 --> Controller Class Initialized
INFO - 2019-01-13 05:01:14 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-13 05:01:14 --> Final output sent to browser
DEBUG - 2019-01-13 05:01:14 --> Total execution time: 0.0912
INFO - 2019-01-13 05:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-13 05:01:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-13 05:01:14 --> Pagination Class Initialized
INFO - 2019-01-13 05:01:14 --> Database Driver Class Initialized
INFO - 2019-01-13 05:01:14 --> Database Driver Class Initialized
INFO - 2019-01-13 05:01:14 --> Controller Class Initialized
INFO - 2019-01-13 05:01:14 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2019-01-13 05:01:14 --> Final output sent to browser
DEBUG - 2019-01-13 05:01:14 --> Total execution time: 0.2742
INFO - 2019-01-13 05:08:23 --> Config Class Initialized
INFO - 2019-01-13 05:08:23 --> Hooks Class Initialized
DEBUG - 2019-01-13 05:08:23 --> UTF-8 Support Enabled
INFO - 2019-01-13 05:08:23 --> Utf8 Class Initialized
INFO - 2019-01-13 05:08:23 --> URI Class Initialized
INFO - 2019-01-13 05:08:23 --> Router Class Initialized
INFO - 2019-01-13 05:08:23 --> Output Class Initialized
INFO - 2019-01-13 05:08:23 --> Security Class Initialized
DEBUG - 2019-01-13 05:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-13 05:08:23 --> Input Class Initialized
INFO - 2019-01-13 05:08:23 --> Language Class Initialized
INFO - 2019-01-13 05:08:23 --> Loader Class Initialized
INFO - 2019-01-13 05:08:23 --> Helper loaded: url_helper
INFO - 2019-01-13 05:08:23 --> Helper loaded: html_helper
INFO - 2019-01-13 05:08:23 --> Helper loaded: form_helper
INFO - 2019-01-13 05:08:23 --> Helper loaded: cookie_helper
INFO - 2019-01-13 05:08:23 --> Helper loaded: date_helper
INFO - 2019-01-13 05:08:23 --> Form Validation Class Initialized
INFO - 2019-01-13 05:08:23 --> Email Class Initialized
DEBUG - 2019-01-13 05:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-13 05:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-13 05:08:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-13 05:08:23 --> Pagination Class Initialized
INFO - 2019-01-13 05:08:23 --> Database Driver Class Initialized
INFO - 2019-01-13 05:08:23 --> Database Driver Class Initialized
INFO - 2019-01-13 05:08:23 --> Controller Class Initialized
INFO - 2019-01-13 05:08:23 --> Final output sent to browser
DEBUG - 2019-01-13 05:08:23 --> Total execution time: 0.0606
