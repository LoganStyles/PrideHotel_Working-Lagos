<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-08-20 20:51:23 --> Config Class Initialized
INFO - 2019-08-20 20:51:23 --> Hooks Class Initialized
DEBUG - 2019-08-20 20:51:23 --> UTF-8 Support Enabled
INFO - 2019-08-20 20:51:23 --> Utf8 Class Initialized
INFO - 2019-08-20 20:51:23 --> URI Class Initialized
INFO - 2019-08-20 20:51:23 --> Router Class Initialized
INFO - 2019-08-20 20:51:23 --> Output Class Initialized
INFO - 2019-08-20 20:51:23 --> Security Class Initialized
DEBUG - 2019-08-20 20:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-20 20:51:23 --> Input Class Initialized
INFO - 2019-08-20 20:51:23 --> Language Class Initialized
INFO - 2019-08-20 20:51:23 --> Loader Class Initialized
INFO - 2019-08-20 20:51:23 --> Helper loaded: url_helper
INFO - 2019-08-20 20:51:23 --> Helper loaded: html_helper
INFO - 2019-08-20 20:51:23 --> Helper loaded: form_helper
INFO - 2019-08-20 20:51:23 --> Helper loaded: cookie_helper
INFO - 2019-08-20 20:51:23 --> Helper loaded: date_helper
INFO - 2019-08-20 20:51:23 --> Form Validation Class Initialized
INFO - 2019-08-20 20:51:23 --> Email Class Initialized
DEBUG - 2019-08-20 20:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-20 20:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-20 20:51:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-20 20:51:23 --> Pagination Class Initialized
INFO - 2019-08-20 20:51:23 --> Database Driver Class Initialized
INFO - 2019-08-20 20:51:23 --> Database Driver Class Initialized
INFO - 2019-08-20 20:51:23 --> Controller Class Initialized
INFO - 2019-08-20 20:51:23 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-20 20:51:23 --> Final output sent to browser
DEBUG - 2019-08-20 20:51:23 --> Total execution time: 0.2340
INFO - 2019-08-20 20:51:24 --> Config Class Initialized
INFO - 2019-08-20 20:51:24 --> Hooks Class Initialized
DEBUG - 2019-08-20 20:51:24 --> UTF-8 Support Enabled
INFO - 2019-08-20 20:51:24 --> Utf8 Class Initialized
INFO - 2019-08-20 20:51:24 --> URI Class Initialized
INFO - 2019-08-20 20:51:24 --> Router Class Initialized
INFO - 2019-08-20 20:51:24 --> Output Class Initialized
INFO - 2019-08-20 20:51:24 --> Security Class Initialized
DEBUG - 2019-08-20 20:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-20 20:51:24 --> Input Class Initialized
INFO - 2019-08-20 20:51:24 --> Language Class Initialized
INFO - 2019-08-20 20:51:24 --> Loader Class Initialized
INFO - 2019-08-20 20:51:24 --> Helper loaded: url_helper
INFO - 2019-08-20 20:51:24 --> Helper loaded: html_helper
INFO - 2019-08-20 20:51:24 --> Helper loaded: form_helper
INFO - 2019-08-20 20:51:24 --> Helper loaded: cookie_helper
INFO - 2019-08-20 20:51:24 --> Helper loaded: date_helper
INFO - 2019-08-20 20:51:24 --> Form Validation Class Initialized
INFO - 2019-08-20 20:51:24 --> Email Class Initialized
DEBUG - 2019-08-20 20:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-20 20:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-20 20:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-20 20:51:24 --> Pagination Class Initialized
INFO - 2019-08-20 20:51:24 --> Database Driver Class Initialized
INFO - 2019-08-20 20:51:24 --> Database Driver Class Initialized
INFO - 2019-08-20 20:51:24 --> Controller Class Initialized
INFO - 2019-08-20 20:51:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-20 20:51:24 --> Final output sent to browser
DEBUG - 2019-08-20 20:51:24 --> Total execution time: 0.1404
