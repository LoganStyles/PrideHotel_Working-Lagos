<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-10-12 19:08:39 --> Config Class Initialized
INFO - 2019-10-12 19:08:39 --> Hooks Class Initialized
DEBUG - 2019-10-12 19:08:39 --> UTF-8 Support Enabled
INFO - 2019-10-12 19:08:39 --> Utf8 Class Initialized
INFO - 2019-10-12 19:08:39 --> URI Class Initialized
INFO - 2019-10-12 19:08:39 --> Router Class Initialized
INFO - 2019-10-12 19:08:39 --> Output Class Initialized
INFO - 2019-10-12 19:08:39 --> Security Class Initialized
DEBUG - 2019-10-12 19:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-12 19:08:39 --> Input Class Initialized
INFO - 2019-10-12 19:08:39 --> Language Class Initialized
INFO - 2019-10-12 19:08:39 --> Loader Class Initialized
INFO - 2019-10-12 19:08:39 --> Helper loaded: url_helper
INFO - 2019-10-12 19:08:39 --> Helper loaded: html_helper
INFO - 2019-10-12 19:08:39 --> Helper loaded: form_helper
INFO - 2019-10-12 19:08:39 --> Helper loaded: cookie_helper
INFO - 2019-10-12 19:08:39 --> Helper loaded: date_helper
INFO - 2019-10-12 19:08:39 --> Form Validation Class Initialized
INFO - 2019-10-12 19:08:39 --> Email Class Initialized
DEBUG - 2019-10-12 19:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-12 19:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-12 19:08:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-12 19:08:39 --> Pagination Class Initialized
INFO - 2019-10-12 19:08:39 --> Database Driver Class Initialized
INFO - 2019-10-12 19:08:39 --> Database Driver Class Initialized
INFO - 2019-10-12 19:08:40 --> Controller Class Initialized
INFO - 2019-10-12 19:08:40 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-10-12 19:08:40 --> Final output sent to browser
DEBUG - 2019-10-12 19:08:40 --> Total execution time: 1.2049
INFO - 2019-10-12 19:08:41 --> Config Class Initialized
INFO - 2019-10-12 19:08:41 --> Hooks Class Initialized
DEBUG - 2019-10-12 19:08:41 --> UTF-8 Support Enabled
INFO - 2019-10-12 19:08:41 --> Utf8 Class Initialized
INFO - 2019-10-12 19:08:41 --> URI Class Initialized
INFO - 2019-10-12 19:08:41 --> Router Class Initialized
INFO - 2019-10-12 19:08:41 --> Output Class Initialized
INFO - 2019-10-12 19:08:41 --> Security Class Initialized
DEBUG - 2019-10-12 19:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-12 19:08:41 --> Input Class Initialized
INFO - 2019-10-12 19:08:41 --> Language Class Initialized
INFO - 2019-10-12 19:08:41 --> Loader Class Initialized
INFO - 2019-10-12 19:08:41 --> Helper loaded: url_helper
INFO - 2019-10-12 19:08:41 --> Helper loaded: html_helper
INFO - 2019-10-12 19:08:41 --> Helper loaded: form_helper
INFO - 2019-10-12 19:08:41 --> Helper loaded: cookie_helper
INFO - 2019-10-12 19:08:41 --> Helper loaded: date_helper
INFO - 2019-10-12 19:08:41 --> Form Validation Class Initialized
INFO - 2019-10-12 19:08:41 --> Email Class Initialized
DEBUG - 2019-10-12 19:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-12 19:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-12 19:08:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-12 19:08:41 --> Pagination Class Initialized
INFO - 2019-10-12 19:08:41 --> Database Driver Class Initialized
INFO - 2019-10-12 19:08:41 --> Database Driver Class Initialized
INFO - 2019-10-12 19:08:41 --> Controller Class Initialized
INFO - 2019-10-12 19:08:41 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/login.php
INFO - 2019-10-12 19:08:41 --> Final output sent to browser
DEBUG - 2019-10-12 19:08:41 --> Total execution time: 0.1732
INFO - 2019-10-12 19:08:55 --> Config Class Initialized
INFO - 2019-10-12 19:08:55 --> Hooks Class Initialized
DEBUG - 2019-10-12 19:08:55 --> UTF-8 Support Enabled
INFO - 2019-10-12 19:08:55 --> Utf8 Class Initialized
INFO - 2019-10-12 19:08:55 --> URI Class Initialized
INFO - 2019-10-12 19:08:55 --> Router Class Initialized
INFO - 2019-10-12 19:08:55 --> Output Class Initialized
INFO - 2019-10-12 19:08:55 --> Security Class Initialized
DEBUG - 2019-10-12 19:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-12 19:08:55 --> Input Class Initialized
INFO - 2019-10-12 19:08:55 --> Language Class Initialized
INFO - 2019-10-12 19:08:55 --> Loader Class Initialized
INFO - 2019-10-12 19:08:55 --> Helper loaded: url_helper
INFO - 2019-10-12 19:08:55 --> Helper loaded: html_helper
INFO - 2019-10-12 19:08:55 --> Helper loaded: form_helper
INFO - 2019-10-12 19:08:55 --> Helper loaded: cookie_helper
INFO - 2019-10-12 19:08:55 --> Helper loaded: date_helper
INFO - 2019-10-12 19:08:55 --> Form Validation Class Initialized
INFO - 2019-10-12 19:08:55 --> Email Class Initialized
DEBUG - 2019-10-12 19:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-12 19:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-12 19:08:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-12 19:08:55 --> Pagination Class Initialized
INFO - 2019-10-12 19:08:55 --> Database Driver Class Initialized
INFO - 2019-10-12 19:08:55 --> Database Driver Class Initialized
INFO - 2019-10-12 19:08:55 --> Controller Class Initialized
INFO - 2019-10-12 19:08:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-10-12 19:08:55 --> Config Class Initialized
INFO - 2019-10-12 19:08:55 --> Hooks Class Initialized
DEBUG - 2019-10-12 19:08:55 --> UTF-8 Support Enabled
INFO - 2019-10-12 19:08:55 --> Utf8 Class Initialized
INFO - 2019-10-12 19:08:55 --> URI Class Initialized
INFO - 2019-10-12 19:08:55 --> Router Class Initialized
INFO - 2019-10-12 19:08:55 --> Output Class Initialized
INFO - 2019-10-12 19:08:55 --> Security Class Initialized
DEBUG - 2019-10-12 19:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-12 19:08:55 --> Input Class Initialized
INFO - 2019-10-12 19:08:55 --> Language Class Initialized
INFO - 2019-10-12 19:08:55 --> Loader Class Initialized
INFO - 2019-10-12 19:08:56 --> Helper loaded: url_helper
INFO - 2019-10-12 19:08:56 --> Helper loaded: html_helper
INFO - 2019-10-12 19:08:56 --> Helper loaded: form_helper
INFO - 2019-10-12 19:08:56 --> Helper loaded: cookie_helper
INFO - 2019-10-12 19:08:56 --> Helper loaded: date_helper
INFO - 2019-10-12 19:08:56 --> Form Validation Class Initialized
INFO - 2019-10-12 19:08:56 --> Email Class Initialized
DEBUG - 2019-10-12 19:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-12 19:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-12 19:08:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-12 19:08:56 --> Pagination Class Initialized
INFO - 2019-10-12 19:08:56 --> Database Driver Class Initialized
INFO - 2019-10-12 19:08:56 --> Database Driver Class Initialized
INFO - 2019-10-12 19:08:56 --> Controller Class Initialized
INFO - 2019-10-12 19:08:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-10-12 19:08:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/top_reservation.php
INFO - 2019-10-12 19:08:56 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-10-12 19:08:56 --> Final output sent to browser
DEBUG - 2019-10-12 19:08:56 --> Total execution time: 0.4368
INFO - 2019-10-12 19:08:57 --> Config Class Initialized
INFO - 2019-10-12 19:08:57 --> Hooks Class Initialized
DEBUG - 2019-10-12 19:08:57 --> UTF-8 Support Enabled
INFO - 2019-10-12 19:08:57 --> Utf8 Class Initialized
INFO - 2019-10-12 19:08:57 --> URI Class Initialized
INFO - 2019-10-12 19:08:57 --> Router Class Initialized
INFO - 2019-10-12 19:08:57 --> Output Class Initialized
INFO - 2019-10-12 19:08:57 --> Security Class Initialized
DEBUG - 2019-10-12 19:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-12 19:08:57 --> Input Class Initialized
INFO - 2019-10-12 19:08:57 --> Language Class Initialized
INFO - 2019-10-12 19:08:57 --> Loader Class Initialized
INFO - 2019-10-12 19:08:57 --> Helper loaded: url_helper
INFO - 2019-10-12 19:08:57 --> Helper loaded: html_helper
INFO - 2019-10-12 19:08:57 --> Helper loaded: form_helper
INFO - 2019-10-12 19:08:57 --> Helper loaded: cookie_helper
INFO - 2019-10-12 19:08:57 --> Helper loaded: date_helper
INFO - 2019-10-12 19:08:57 --> Form Validation Class Initialized
INFO - 2019-10-12 19:08:57 --> Email Class Initialized
DEBUG - 2019-10-12 19:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-12 19:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-12 19:08:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-12 19:08:57 --> Pagination Class Initialized
INFO - 2019-10-12 19:08:57 --> Database Driver Class Initialized
INFO - 2019-10-12 19:08:57 --> Database Driver Class Initialized
INFO - 2019-10-12 19:08:57 --> Controller Class Initialized
INFO - 2019-10-12 19:08:57 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-10-12 19:08:57 --> Final output sent to browser
DEBUG - 2019-10-12 19:08:57 --> Total execution time: 0.3420
INFO - 2019-10-12 19:08:57 --> Config Class Initialized
INFO - 2019-10-12 19:08:57 --> Hooks Class Initialized
DEBUG - 2019-10-12 19:08:57 --> UTF-8 Support Enabled
INFO - 2019-10-12 19:08:57 --> Utf8 Class Initialized
INFO - 2019-10-12 19:08:57 --> URI Class Initialized
INFO - 2019-10-12 19:08:57 --> Router Class Initialized
INFO - 2019-10-12 19:08:57 --> Output Class Initialized
INFO - 2019-10-12 19:08:57 --> Security Class Initialized
DEBUG - 2019-10-12 19:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-12 19:08:57 --> Input Class Initialized
INFO - 2019-10-12 19:08:57 --> Language Class Initialized
INFO - 2019-10-12 19:08:57 --> Loader Class Initialized
INFO - 2019-10-12 19:08:57 --> Helper loaded: url_helper
INFO - 2019-10-12 19:08:57 --> Helper loaded: html_helper
INFO - 2019-10-12 19:08:57 --> Helper loaded: form_helper
INFO - 2019-10-12 19:08:57 --> Helper loaded: cookie_helper
INFO - 2019-10-12 19:08:57 --> Helper loaded: date_helper
INFO - 2019-10-12 19:08:57 --> Form Validation Class Initialized
INFO - 2019-10-12 19:08:57 --> Email Class Initialized
DEBUG - 2019-10-12 19:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-12 19:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-12 19:08:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-12 19:08:57 --> Pagination Class Initialized
INFO - 2019-10-12 19:08:57 --> Database Driver Class Initialized
INFO - 2019-10-12 19:08:57 --> Database Driver Class Initialized
INFO - 2019-10-12 19:08:57 --> Controller Class Initialized
INFO - 2019-10-12 19:08:57 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-10-12 19:08:57 --> Final output sent to browser
DEBUG - 2019-10-12 19:08:57 --> Total execution time: 0.3105
INFO - 2019-10-12 19:09:17 --> Config Class Initialized
INFO - 2019-10-12 19:09:17 --> Hooks Class Initialized
DEBUG - 2019-10-12 19:09:17 --> UTF-8 Support Enabled
INFO - 2019-10-12 19:09:17 --> Utf8 Class Initialized
INFO - 2019-10-12 19:09:17 --> URI Class Initialized
INFO - 2019-10-12 19:09:17 --> Router Class Initialized
INFO - 2019-10-12 19:09:17 --> Output Class Initialized
INFO - 2019-10-12 19:09:17 --> Security Class Initialized
DEBUG - 2019-10-12 19:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-12 19:09:17 --> Input Class Initialized
INFO - 2019-10-12 19:09:17 --> Language Class Initialized
INFO - 2019-10-12 19:09:17 --> Loader Class Initialized
INFO - 2019-10-12 19:09:17 --> Helper loaded: url_helper
INFO - 2019-10-12 19:09:17 --> Helper loaded: html_helper
INFO - 2019-10-12 19:09:17 --> Helper loaded: form_helper
INFO - 2019-10-12 19:09:17 --> Helper loaded: cookie_helper
INFO - 2019-10-12 19:09:17 --> Helper loaded: date_helper
INFO - 2019-10-12 19:09:17 --> Form Validation Class Initialized
INFO - 2019-10-12 19:09:17 --> Email Class Initialized
DEBUG - 2019-10-12 19:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-12 19:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-12 19:09:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-12 19:09:17 --> Pagination Class Initialized
INFO - 2019-10-12 19:09:17 --> Database Driver Class Initialized
INFO - 2019-10-12 19:09:17 --> Database Driver Class Initialized
INFO - 2019-10-12 19:09:17 --> Controller Class Initialized
INFO - 2019-10-12 19:09:17 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-10-12 19:09:17 --> Final output sent to browser
DEBUG - 2019-10-12 19:09:17 --> Total execution time: 0.2120
INFO - 2019-10-12 19:09:18 --> Config Class Initialized
INFO - 2019-10-12 19:09:18 --> Hooks Class Initialized
DEBUG - 2019-10-12 19:09:18 --> UTF-8 Support Enabled
INFO - 2019-10-12 19:09:18 --> Utf8 Class Initialized
INFO - 2019-10-12 19:09:18 --> URI Class Initialized
INFO - 2019-10-12 19:09:18 --> Router Class Initialized
INFO - 2019-10-12 19:09:18 --> Output Class Initialized
INFO - 2019-10-12 19:09:18 --> Security Class Initialized
DEBUG - 2019-10-12 19:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-12 19:09:18 --> Input Class Initialized
INFO - 2019-10-12 19:09:18 --> Language Class Initialized
INFO - 2019-10-12 19:09:18 --> Loader Class Initialized
INFO - 2019-10-12 19:09:18 --> Helper loaded: url_helper
INFO - 2019-10-12 19:09:18 --> Helper loaded: html_helper
INFO - 2019-10-12 19:09:18 --> Helper loaded: form_helper
INFO - 2019-10-12 19:09:18 --> Helper loaded: cookie_helper
INFO - 2019-10-12 19:09:18 --> Helper loaded: date_helper
INFO - 2019-10-12 19:09:18 --> Form Validation Class Initialized
INFO - 2019-10-12 19:09:18 --> Email Class Initialized
DEBUG - 2019-10-12 19:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-12 19:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-12 19:09:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-12 19:09:18 --> Pagination Class Initialized
INFO - 2019-10-12 19:09:18 --> Database Driver Class Initialized
INFO - 2019-10-12 19:09:18 --> Database Driver Class Initialized
INFO - 2019-10-12 19:09:18 --> Controller Class Initialized
INFO - 2019-10-12 19:09:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-10-12 19:09:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/nightaudit.php
INFO - 2019-10-12 19:09:18 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-10-12 19:09:18 --> Final output sent to browser
DEBUG - 2019-10-12 19:09:18 --> Total execution time: 0.1656
INFO - 2019-10-12 19:09:19 --> Config Class Initialized
INFO - 2019-10-12 19:09:19 --> Hooks Class Initialized
DEBUG - 2019-10-12 19:09:19 --> UTF-8 Support Enabled
INFO - 2019-10-12 19:09:19 --> Utf8 Class Initialized
INFO - 2019-10-12 19:09:19 --> URI Class Initialized
INFO - 2019-10-12 19:09:19 --> Router Class Initialized
INFO - 2019-10-12 19:09:19 --> Output Class Initialized
INFO - 2019-10-12 19:09:19 --> Security Class Initialized
DEBUG - 2019-10-12 19:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-12 19:09:19 --> Input Class Initialized
INFO - 2019-10-12 19:09:19 --> Language Class Initialized
INFO - 2019-10-12 19:09:19 --> Loader Class Initialized
INFO - 2019-10-12 19:09:19 --> Helper loaded: url_helper
INFO - 2019-10-12 19:09:19 --> Helper loaded: html_helper
INFO - 2019-10-12 19:09:19 --> Helper loaded: form_helper
INFO - 2019-10-12 19:09:19 --> Helper loaded: cookie_helper
INFO - 2019-10-12 19:09:19 --> Helper loaded: date_helper
INFO - 2019-10-12 19:09:19 --> Form Validation Class Initialized
INFO - 2019-10-12 19:09:19 --> Email Class Initialized
DEBUG - 2019-10-12 19:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-12 19:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-12 19:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-12 19:09:19 --> Pagination Class Initialized
INFO - 2019-10-12 19:09:19 --> Database Driver Class Initialized
INFO - 2019-10-12 19:09:19 --> Database Driver Class Initialized
INFO - 2019-10-12 19:09:19 --> Controller Class Initialized
INFO - 2019-10-12 19:09:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-10-12 19:09:19 --> Final output sent to browser
DEBUG - 2019-10-12 19:09:19 --> Total execution time: 0.1647
INFO - 2019-10-12 19:09:19 --> Config Class Initialized
INFO - 2019-10-12 19:09:19 --> Hooks Class Initialized
DEBUG - 2019-10-12 19:09:19 --> UTF-8 Support Enabled
INFO - 2019-10-12 19:09:19 --> Utf8 Class Initialized
INFO - 2019-10-12 19:09:19 --> URI Class Initialized
INFO - 2019-10-12 19:09:19 --> Router Class Initialized
INFO - 2019-10-12 19:09:19 --> Output Class Initialized
INFO - 2019-10-12 19:09:19 --> Security Class Initialized
DEBUG - 2019-10-12 19:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-12 19:09:19 --> Input Class Initialized
INFO - 2019-10-12 19:09:19 --> Language Class Initialized
INFO - 2019-10-12 19:09:19 --> Loader Class Initialized
INFO - 2019-10-12 19:09:19 --> Helper loaded: url_helper
INFO - 2019-10-12 19:09:19 --> Helper loaded: html_helper
INFO - 2019-10-12 19:09:19 --> Helper loaded: form_helper
INFO - 2019-10-12 19:09:19 --> Helper loaded: cookie_helper
INFO - 2019-10-12 19:09:19 --> Helper loaded: date_helper
INFO - 2019-10-12 19:09:19 --> Form Validation Class Initialized
INFO - 2019-10-12 19:09:19 --> Email Class Initialized
DEBUG - 2019-10-12 19:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-12 19:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-12 19:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-12 19:09:19 --> Pagination Class Initialized
INFO - 2019-10-12 19:09:19 --> Database Driver Class Initialized
INFO - 2019-10-12 19:09:19 --> Database Driver Class Initialized
INFO - 2019-10-12 19:09:19 --> Controller Class Initialized
INFO - 2019-10-12 19:09:19 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-10-12 19:09:19 --> Final output sent to browser
DEBUG - 2019-10-12 19:09:19 --> Total execution time: 0.1921
INFO - 2019-10-12 19:11:00 --> Config Class Initialized
INFO - 2019-10-12 19:11:00 --> Hooks Class Initialized
DEBUG - 2019-10-12 19:11:00 --> UTF-8 Support Enabled
INFO - 2019-10-12 19:11:00 --> Utf8 Class Initialized
INFO - 2019-10-12 19:11:00 --> URI Class Initialized
INFO - 2019-10-12 19:11:00 --> Router Class Initialized
INFO - 2019-10-12 19:11:00 --> Output Class Initialized
INFO - 2019-10-12 19:11:00 --> Security Class Initialized
DEBUG - 2019-10-12 19:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-12 19:11:00 --> Input Class Initialized
INFO - 2019-10-12 19:11:00 --> Language Class Initialized
INFO - 2019-10-12 19:11:00 --> Loader Class Initialized
INFO - 2019-10-12 19:11:00 --> Helper loaded: url_helper
INFO - 2019-10-12 19:11:00 --> Helper loaded: html_helper
INFO - 2019-10-12 19:11:00 --> Helper loaded: form_helper
INFO - 2019-10-12 19:11:00 --> Helper loaded: cookie_helper
INFO - 2019-10-12 19:11:00 --> Helper loaded: date_helper
INFO - 2019-10-12 19:11:00 --> Form Validation Class Initialized
INFO - 2019-10-12 19:11:00 --> Email Class Initialized
DEBUG - 2019-10-12 19:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-12 19:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-12 19:11:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-12 19:11:01 --> Pagination Class Initialized
INFO - 2019-10-12 19:11:01 --> Database Driver Class Initialized
INFO - 2019-10-12 19:11:01 --> Database Driver Class Initialized
INFO - 2019-10-12 19:11:01 --> Controller Class Initialized
INFO - 2019-10-12 19:11:03 --> Final output sent to browser
DEBUG - 2019-10-12 19:11:03 --> Total execution time: 2.8615
INFO - 2019-10-12 19:11:05 --> Config Class Initialized
INFO - 2019-10-12 19:11:05 --> Hooks Class Initialized
DEBUG - 2019-10-12 19:11:05 --> UTF-8 Support Enabled
INFO - 2019-10-12 19:11:05 --> Utf8 Class Initialized
INFO - 2019-10-12 19:11:05 --> URI Class Initialized
INFO - 2019-10-12 19:11:05 --> Router Class Initialized
INFO - 2019-10-12 19:11:05 --> Output Class Initialized
INFO - 2019-10-12 19:11:05 --> Security Class Initialized
DEBUG - 2019-10-12 19:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-12 19:11:05 --> Input Class Initialized
INFO - 2019-10-12 19:11:05 --> Language Class Initialized
INFO - 2019-10-12 19:11:05 --> Loader Class Initialized
INFO - 2019-10-12 19:11:05 --> Helper loaded: url_helper
INFO - 2019-10-12 19:11:05 --> Helper loaded: html_helper
INFO - 2019-10-12 19:11:05 --> Helper loaded: form_helper
INFO - 2019-10-12 19:11:05 --> Helper loaded: cookie_helper
INFO - 2019-10-12 19:11:05 --> Helper loaded: date_helper
INFO - 2019-10-12 19:11:05 --> Form Validation Class Initialized
INFO - 2019-10-12 19:11:05 --> Email Class Initialized
DEBUG - 2019-10-12 19:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-12 19:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-12 19:11:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-12 19:11:05 --> Pagination Class Initialized
INFO - 2019-10-12 19:11:05 --> Database Driver Class Initialized
INFO - 2019-10-12 19:11:05 --> Database Driver Class Initialized
INFO - 2019-10-12 19:11:05 --> Controller Class Initialized
INFO - 2019-10-12 19:11:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-10-12 19:11:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/nightaudit.php
INFO - 2019-10-12 19:11:05 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-10-12 19:11:05 --> Final output sent to browser
DEBUG - 2019-10-12 19:11:05 --> Total execution time: 0.1375
INFO - 2019-10-12 19:11:06 --> Config Class Initialized
INFO - 2019-10-12 19:11:06 --> Hooks Class Initialized
DEBUG - 2019-10-12 19:11:06 --> UTF-8 Support Enabled
INFO - 2019-10-12 19:11:06 --> Utf8 Class Initialized
INFO - 2019-10-12 19:11:06 --> URI Class Initialized
INFO - 2019-10-12 19:11:06 --> Router Class Initialized
INFO - 2019-10-12 19:11:06 --> Output Class Initialized
INFO - 2019-10-12 19:11:06 --> Security Class Initialized
DEBUG - 2019-10-12 19:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-12 19:11:06 --> Input Class Initialized
INFO - 2019-10-12 19:11:06 --> Language Class Initialized
INFO - 2019-10-12 19:11:06 --> Loader Class Initialized
INFO - 2019-10-12 19:11:06 --> Helper loaded: url_helper
INFO - 2019-10-12 19:11:06 --> Helper loaded: html_helper
INFO - 2019-10-12 19:11:06 --> Helper loaded: form_helper
INFO - 2019-10-12 19:11:06 --> Helper loaded: cookie_helper
INFO - 2019-10-12 19:11:06 --> Helper loaded: date_helper
INFO - 2019-10-12 19:11:06 --> Form Validation Class Initialized
INFO - 2019-10-12 19:11:06 --> Email Class Initialized
DEBUG - 2019-10-12 19:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-10-12 19:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-10-12 19:11:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-12 19:11:06 --> Pagination Class Initialized
INFO - 2019-10-12 19:11:06 --> Database Driver Class Initialized
INFO - 2019-10-12 19:11:06 --> Database Driver Class Initialized
INFO - 2019-10-12 19:11:06 --> Controller Class Initialized
INFO - 2019-10-12 19:11:06 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-10-12 19:11:06 --> Final output sent to browser
DEBUG - 2019-10-12 19:11:06 --> Total execution time: 0.1674
