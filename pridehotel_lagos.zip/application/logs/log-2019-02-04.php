<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-02-04 18:32:37 --> Config Class Initialized
INFO - 2019-02-04 18:32:37 --> Hooks Class Initialized
DEBUG - 2019-02-04 18:32:37 --> UTF-8 Support Enabled
INFO - 2019-02-04 18:32:37 --> Utf8 Class Initialized
INFO - 2019-02-04 18:32:37 --> URI Class Initialized
INFO - 2019-02-04 18:32:38 --> Router Class Initialized
INFO - 2019-02-04 18:32:38 --> Output Class Initialized
INFO - 2019-02-04 18:32:38 --> Security Class Initialized
DEBUG - 2019-02-04 18:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-02-04 18:32:38 --> Input Class Initialized
INFO - 2019-02-04 18:32:38 --> Language Class Initialized
INFO - 2019-02-04 18:32:38 --> Loader Class Initialized
INFO - 2019-02-04 18:32:38 --> Helper loaded: url_helper
INFO - 2019-02-04 18:32:38 --> Helper loaded: html_helper
INFO - 2019-02-04 18:32:38 --> Helper loaded: form_helper
INFO - 2019-02-04 18:32:38 --> Helper loaded: cookie_helper
INFO - 2019-02-04 18:32:38 --> Helper loaded: date_helper
INFO - 2019-02-04 18:32:38 --> Form Validation Class Initialized
INFO - 2019-02-04 18:32:38 --> Email Class Initialized
DEBUG - 2019-02-04 18:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-02-04 18:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-02-04 18:32:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-02-04 18:32:38 --> Pagination Class Initialized
INFO - 2019-02-04 18:32:39 --> Database Driver Class Initialized
INFO - 2019-02-04 18:32:39 --> Database Driver Class Initialized
INFO - 2019-02-04 18:32:39 --> Controller Class Initialized
DEBUG - 2019-02-04 18:32:39 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2019-02-04 18:32:39 --> Helper loaded: inflector_helper
INFO - 2019-02-04 18:32:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-02-04 18:32:39 --> Final output sent to browser
DEBUG - 2019-02-04 18:32:39 --> Total execution time: 1.8432
