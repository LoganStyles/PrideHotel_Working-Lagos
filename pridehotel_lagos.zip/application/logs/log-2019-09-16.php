<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-16 05:13:41 --> Config Class Initialized
INFO - 2019-09-16 05:13:41 --> Hooks Class Initialized
DEBUG - 2019-09-16 05:13:41 --> UTF-8 Support Enabled
INFO - 2019-09-16 05:13:41 --> Utf8 Class Initialized
INFO - 2019-09-16 05:13:41 --> URI Class Initialized
INFO - 2019-09-16 05:13:41 --> Router Class Initialized
INFO - 2019-09-16 05:13:41 --> Output Class Initialized
INFO - 2019-09-16 05:13:41 --> Security Class Initialized
DEBUG - 2019-09-16 05:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-16 05:13:41 --> Input Class Initialized
INFO - 2019-09-16 05:13:41 --> Language Class Initialized
INFO - 2019-09-16 05:13:41 --> Loader Class Initialized
INFO - 2019-09-16 05:13:41 --> Helper loaded: url_helper
INFO - 2019-09-16 05:13:41 --> Helper loaded: html_helper
INFO - 2019-09-16 05:13:41 --> Helper loaded: form_helper
INFO - 2019-09-16 05:13:41 --> Helper loaded: cookie_helper
INFO - 2019-09-16 05:13:41 --> Helper loaded: date_helper
INFO - 2019-09-16 05:13:41 --> Form Validation Class Initialized
INFO - 2019-09-16 05:13:41 --> Email Class Initialized
DEBUG - 2019-09-16 05:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-16 05:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-16 05:13:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-16 05:13:41 --> Pagination Class Initialized
INFO - 2019-09-16 05:13:41 --> Database Driver Class Initialized
INFO - 2019-09-16 05:13:41 --> Database Driver Class Initialized
INFO - 2019-09-16 05:13:41 --> Controller Class Initialized
INFO - 2019-09-16 05:18:00 --> Config Class Initialized
INFO - 2019-09-16 05:18:00 --> Hooks Class Initialized
DEBUG - 2019-09-16 05:18:00 --> UTF-8 Support Enabled
INFO - 2019-09-16 05:18:00 --> Utf8 Class Initialized
INFO - 2019-09-16 05:18:00 --> URI Class Initialized
INFO - 2019-09-16 05:18:00 --> Router Class Initialized
INFO - 2019-09-16 05:18:00 --> Output Class Initialized
INFO - 2019-09-16 05:18:00 --> Security Class Initialized
DEBUG - 2019-09-16 05:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-16 05:18:00 --> Input Class Initialized
INFO - 2019-09-16 05:18:00 --> Language Class Initialized
INFO - 2019-09-16 05:18:00 --> Loader Class Initialized
INFO - 2019-09-16 05:18:00 --> Helper loaded: url_helper
INFO - 2019-09-16 05:18:00 --> Helper loaded: html_helper
INFO - 2019-09-16 05:18:00 --> Helper loaded: form_helper
INFO - 2019-09-16 05:18:00 --> Helper loaded: cookie_helper
INFO - 2019-09-16 05:18:00 --> Helper loaded: date_helper
INFO - 2019-09-16 05:18:00 --> Form Validation Class Initialized
INFO - 2019-09-16 05:18:00 --> Email Class Initialized
DEBUG - 2019-09-16 05:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-16 05:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-16 05:18:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-16 05:18:00 --> Pagination Class Initialized
INFO - 2019-09-16 05:18:00 --> Database Driver Class Initialized
INFO - 2019-09-16 05:18:00 --> Database Driver Class Initialized
INFO - 2019-09-16 05:18:00 --> Controller Class Initialized
INFO - 2019-09-16 05:18:00 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_print.php
INFO - 2019-09-16 05:18:00 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/prints/report.php
INFO - 2019-09-16 05:18:00 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-16 05:18:00 --> Final output sent to browser
DEBUG - 2019-09-16 05:18:00 --> Total execution time: 0.1327
