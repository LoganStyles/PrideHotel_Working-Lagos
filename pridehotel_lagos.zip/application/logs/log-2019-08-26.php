<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-08-26 00:14:11 --> Config Class Initialized
INFO - 2019-08-26 00:14:11 --> Hooks Class Initialized
DEBUG - 2019-08-26 00:14:11 --> UTF-8 Support Enabled
INFO - 2019-08-26 00:14:11 --> Utf8 Class Initialized
INFO - 2019-08-26 00:14:11 --> URI Class Initialized
INFO - 2019-08-26 00:14:11 --> Router Class Initialized
INFO - 2019-08-26 00:14:11 --> Output Class Initialized
INFO - 2019-08-26 00:14:11 --> Security Class Initialized
DEBUG - 2019-08-26 00:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 00:14:11 --> Input Class Initialized
INFO - 2019-08-26 00:14:11 --> Language Class Initialized
INFO - 2019-08-26 00:14:11 --> Loader Class Initialized
INFO - 2019-08-26 00:14:11 --> Helper loaded: url_helper
INFO - 2019-08-26 00:14:11 --> Helper loaded: html_helper
INFO - 2019-08-26 00:14:11 --> Helper loaded: form_helper
INFO - 2019-08-26 00:14:11 --> Helper loaded: cookie_helper
INFO - 2019-08-26 00:14:12 --> Helper loaded: date_helper
INFO - 2019-08-26 00:14:12 --> Form Validation Class Initialized
INFO - 2019-08-26 00:14:12 --> Email Class Initialized
DEBUG - 2019-08-26 00:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 00:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 00:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 00:14:12 --> Pagination Class Initialized
INFO - 2019-08-26 00:14:12 --> Database Driver Class Initialized
INFO - 2019-08-26 00:14:12 --> Database Driver Class Initialized
INFO - 2019-08-26 00:14:12 --> Language file loaded: language/english/db_lang.php
INFO - 2019-08-26 00:19:02 --> Config Class Initialized
INFO - 2019-08-26 00:19:02 --> Hooks Class Initialized
DEBUG - 2019-08-26 00:19:02 --> UTF-8 Support Enabled
INFO - 2019-08-26 00:19:02 --> Utf8 Class Initialized
INFO - 2019-08-26 00:19:02 --> URI Class Initialized
INFO - 2019-08-26 00:19:02 --> Router Class Initialized
INFO - 2019-08-26 00:19:02 --> Output Class Initialized
INFO - 2019-08-26 00:19:02 --> Security Class Initialized
DEBUG - 2019-08-26 00:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 00:19:02 --> Input Class Initialized
INFO - 2019-08-26 00:19:02 --> Language Class Initialized
INFO - 2019-08-26 00:19:02 --> Loader Class Initialized
INFO - 2019-08-26 00:19:02 --> Helper loaded: url_helper
INFO - 2019-08-26 00:19:02 --> Helper loaded: html_helper
INFO - 2019-08-26 00:19:02 --> Helper loaded: form_helper
INFO - 2019-08-26 00:19:02 --> Helper loaded: cookie_helper
INFO - 2019-08-26 00:19:02 --> Helper loaded: date_helper
INFO - 2019-08-26 00:19:02 --> Form Validation Class Initialized
INFO - 2019-08-26 00:19:02 --> Email Class Initialized
DEBUG - 2019-08-26 00:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 00:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 00:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 00:19:02 --> Pagination Class Initialized
INFO - 2019-08-26 00:19:02 --> Database Driver Class Initialized
INFO - 2019-08-26 00:19:02 --> Database Driver Class Initialized
INFO - 2019-08-26 00:19:02 --> Controller Class Initialized
INFO - 2019-08-26 00:19:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-26 00:19:03 --> Final output sent to browser
DEBUG - 2019-08-26 00:19:03 --> Total execution time: 0.6614
INFO - 2019-08-26 00:19:06 --> Config Class Initialized
INFO - 2019-08-26 00:19:06 --> Hooks Class Initialized
DEBUG - 2019-08-26 00:19:06 --> UTF-8 Support Enabled
INFO - 2019-08-26 00:19:06 --> Utf8 Class Initialized
INFO - 2019-08-26 00:19:06 --> URI Class Initialized
INFO - 2019-08-26 00:19:06 --> Router Class Initialized
INFO - 2019-08-26 00:19:06 --> Output Class Initialized
INFO - 2019-08-26 00:19:06 --> Security Class Initialized
DEBUG - 2019-08-26 00:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 00:19:06 --> Input Class Initialized
INFO - 2019-08-26 00:19:06 --> Language Class Initialized
INFO - 2019-08-26 00:19:06 --> Loader Class Initialized
INFO - 2019-08-26 00:19:06 --> Helper loaded: url_helper
INFO - 2019-08-26 00:19:06 --> Helper loaded: html_helper
INFO - 2019-08-26 00:19:06 --> Helper loaded: form_helper
INFO - 2019-08-26 00:19:06 --> Helper loaded: cookie_helper
INFO - 2019-08-26 00:19:06 --> Helper loaded: date_helper
INFO - 2019-08-26 00:19:06 --> Form Validation Class Initialized
INFO - 2019-08-26 00:19:06 --> Email Class Initialized
DEBUG - 2019-08-26 00:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 00:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 00:19:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 00:19:06 --> Pagination Class Initialized
INFO - 2019-08-26 00:19:06 --> Database Driver Class Initialized
INFO - 2019-08-26 00:19:06 --> Database Driver Class Initialized
INFO - 2019-08-26 00:19:06 --> Controller Class Initialized
INFO - 2019-08-26 00:19:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-26 00:19:06 --> Final output sent to browser
DEBUG - 2019-08-26 00:19:06 --> Total execution time: 0.3963
INFO - 2019-08-26 00:19:24 --> Config Class Initialized
INFO - 2019-08-26 00:19:24 --> Hooks Class Initialized
DEBUG - 2019-08-26 00:19:24 --> UTF-8 Support Enabled
INFO - 2019-08-26 00:19:24 --> Utf8 Class Initialized
INFO - 2019-08-26 00:19:24 --> URI Class Initialized
INFO - 2019-08-26 00:19:24 --> Router Class Initialized
INFO - 2019-08-26 00:19:25 --> Output Class Initialized
INFO - 2019-08-26 00:19:25 --> Security Class Initialized
DEBUG - 2019-08-26 00:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 00:19:25 --> Input Class Initialized
INFO - 2019-08-26 00:19:25 --> Language Class Initialized
INFO - 2019-08-26 00:19:25 --> Loader Class Initialized
INFO - 2019-08-26 00:19:25 --> Helper loaded: url_helper
INFO - 2019-08-26 00:19:25 --> Helper loaded: html_helper
INFO - 2019-08-26 00:19:25 --> Helper loaded: form_helper
INFO - 2019-08-26 00:19:25 --> Helper loaded: cookie_helper
INFO - 2019-08-26 00:19:25 --> Helper loaded: date_helper
INFO - 2019-08-26 00:19:25 --> Form Validation Class Initialized
INFO - 2019-08-26 00:19:25 --> Email Class Initialized
DEBUG - 2019-08-26 00:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 00:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 00:19:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 00:19:25 --> Pagination Class Initialized
INFO - 2019-08-26 00:19:25 --> Database Driver Class Initialized
INFO - 2019-08-26 00:19:25 --> Database Driver Class Initialized
INFO - 2019-08-26 00:19:25 --> Controller Class Initialized
INFO - 2019-08-26 00:19:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 00:19:25 --> Config Class Initialized
INFO - 2019-08-26 00:19:25 --> Hooks Class Initialized
DEBUG - 2019-08-26 00:19:25 --> UTF-8 Support Enabled
INFO - 2019-08-26 00:19:25 --> Utf8 Class Initialized
INFO - 2019-08-26 00:19:25 --> URI Class Initialized
INFO - 2019-08-26 00:19:25 --> Router Class Initialized
INFO - 2019-08-26 00:19:25 --> Output Class Initialized
INFO - 2019-08-26 00:19:25 --> Security Class Initialized
DEBUG - 2019-08-26 00:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 00:19:25 --> Input Class Initialized
INFO - 2019-08-26 00:19:25 --> Language Class Initialized
INFO - 2019-08-26 00:19:25 --> Loader Class Initialized
INFO - 2019-08-26 00:19:25 --> Helper loaded: url_helper
INFO - 2019-08-26 00:19:25 --> Helper loaded: html_helper
INFO - 2019-08-26 00:19:25 --> Helper loaded: form_helper
INFO - 2019-08-26 00:19:25 --> Helper loaded: cookie_helper
INFO - 2019-08-26 00:19:25 --> Helper loaded: date_helper
INFO - 2019-08-26 00:19:25 --> Form Validation Class Initialized
INFO - 2019-08-26 00:19:25 --> Email Class Initialized
DEBUG - 2019-08-26 00:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 00:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 00:19:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 00:19:25 --> Pagination Class Initialized
INFO - 2019-08-26 00:19:25 --> Database Driver Class Initialized
INFO - 2019-08-26 00:19:25 --> Database Driver Class Initialized
INFO - 2019-08-26 00:19:25 --> Controller Class Initialized
INFO - 2019-08-26 00:19:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-26 00:19:25 --> Final output sent to browser
DEBUG - 2019-08-26 00:19:25 --> Total execution time: 0.5134
INFO - 2019-08-26 00:20:36 --> Config Class Initialized
INFO - 2019-08-26 00:20:36 --> Hooks Class Initialized
DEBUG - 2019-08-26 00:20:36 --> UTF-8 Support Enabled
INFO - 2019-08-26 00:20:36 --> Utf8 Class Initialized
INFO - 2019-08-26 00:20:36 --> URI Class Initialized
INFO - 2019-08-26 00:20:36 --> Router Class Initialized
INFO - 2019-08-26 00:20:36 --> Output Class Initialized
INFO - 2019-08-26 00:20:36 --> Security Class Initialized
DEBUG - 2019-08-26 00:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 00:20:36 --> Input Class Initialized
INFO - 2019-08-26 00:20:36 --> Language Class Initialized
INFO - 2019-08-26 00:20:36 --> Loader Class Initialized
INFO - 2019-08-26 00:20:36 --> Helper loaded: url_helper
INFO - 2019-08-26 00:20:36 --> Helper loaded: html_helper
INFO - 2019-08-26 00:20:36 --> Helper loaded: form_helper
INFO - 2019-08-26 00:20:36 --> Helper loaded: cookie_helper
INFO - 2019-08-26 00:20:36 --> Helper loaded: date_helper
INFO - 2019-08-26 00:20:36 --> Form Validation Class Initialized
INFO - 2019-08-26 00:20:37 --> Email Class Initialized
DEBUG - 2019-08-26 00:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 00:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 00:20:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 00:20:37 --> Pagination Class Initialized
INFO - 2019-08-26 00:20:37 --> Database Driver Class Initialized
INFO - 2019-08-26 00:20:37 --> Database Driver Class Initialized
INFO - 2019-08-26 00:20:37 --> Controller Class Initialized
INFO - 2019-08-26 00:20:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 00:20:37 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-26 00:20:37 --> Final output sent to browser
DEBUG - 2019-08-26 00:20:37 --> Total execution time: 0.5468
INFO - 2019-08-26 00:21:02 --> Config Class Initialized
INFO - 2019-08-26 00:21:02 --> Hooks Class Initialized
DEBUG - 2019-08-26 00:21:02 --> UTF-8 Support Enabled
INFO - 2019-08-26 00:21:02 --> Utf8 Class Initialized
INFO - 2019-08-26 00:21:02 --> URI Class Initialized
INFO - 2019-08-26 00:21:02 --> Router Class Initialized
INFO - 2019-08-26 00:21:02 --> Output Class Initialized
INFO - 2019-08-26 00:21:02 --> Security Class Initialized
DEBUG - 2019-08-26 00:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 00:21:02 --> Input Class Initialized
INFO - 2019-08-26 00:21:02 --> Language Class Initialized
INFO - 2019-08-26 00:21:03 --> Loader Class Initialized
INFO - 2019-08-26 00:21:03 --> Helper loaded: url_helper
INFO - 2019-08-26 00:21:03 --> Helper loaded: html_helper
INFO - 2019-08-26 00:21:03 --> Helper loaded: form_helper
INFO - 2019-08-26 00:21:03 --> Helper loaded: cookie_helper
INFO - 2019-08-26 00:21:03 --> Helper loaded: date_helper
INFO - 2019-08-26 00:21:03 --> Form Validation Class Initialized
INFO - 2019-08-26 00:21:03 --> Email Class Initialized
DEBUG - 2019-08-26 00:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 00:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 00:21:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 00:21:03 --> Pagination Class Initialized
INFO - 2019-08-26 00:21:03 --> Database Driver Class Initialized
INFO - 2019-08-26 00:21:03 --> Database Driver Class Initialized
INFO - 2019-08-26 00:21:03 --> Controller Class Initialized
INFO - 2019-08-26 00:21:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 00:21:03 --> Config Class Initialized
INFO - 2019-08-26 00:21:03 --> Hooks Class Initialized
DEBUG - 2019-08-26 00:21:03 --> UTF-8 Support Enabled
INFO - 2019-08-26 00:21:03 --> Utf8 Class Initialized
INFO - 2019-08-26 00:21:03 --> URI Class Initialized
INFO - 2019-08-26 00:21:03 --> Router Class Initialized
INFO - 2019-08-26 00:21:03 --> Output Class Initialized
INFO - 2019-08-26 00:21:03 --> Security Class Initialized
DEBUG - 2019-08-26 00:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 00:21:03 --> Input Class Initialized
INFO - 2019-08-26 00:21:03 --> Language Class Initialized
INFO - 2019-08-26 00:21:03 --> Loader Class Initialized
INFO - 2019-08-26 00:21:03 --> Helper loaded: url_helper
INFO - 2019-08-26 00:21:03 --> Helper loaded: html_helper
INFO - 2019-08-26 00:21:03 --> Helper loaded: form_helper
INFO - 2019-08-26 00:21:03 --> Helper loaded: cookie_helper
INFO - 2019-08-26 00:21:03 --> Helper loaded: date_helper
INFO - 2019-08-26 00:21:03 --> Form Validation Class Initialized
INFO - 2019-08-26 00:21:03 --> Email Class Initialized
DEBUG - 2019-08-26 00:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 00:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 00:21:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 00:21:03 --> Pagination Class Initialized
INFO - 2019-08-26 00:21:03 --> Database Driver Class Initialized
INFO - 2019-08-26 00:21:03 --> Database Driver Class Initialized
INFO - 2019-08-26 00:21:03 --> Controller Class Initialized
INFO - 2019-08-26 00:21:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-26 00:21:03 --> Final output sent to browser
DEBUG - 2019-08-26 00:21:03 --> Total execution time: 0.4288
INFO - 2019-08-26 00:25:37 --> Config Class Initialized
INFO - 2019-08-26 00:25:37 --> Hooks Class Initialized
DEBUG - 2019-08-26 00:25:37 --> UTF-8 Support Enabled
INFO - 2019-08-26 00:25:37 --> Utf8 Class Initialized
INFO - 2019-08-26 00:25:37 --> URI Class Initialized
INFO - 2019-08-26 00:25:37 --> Router Class Initialized
INFO - 2019-08-26 00:25:37 --> Output Class Initialized
INFO - 2019-08-26 00:25:37 --> Security Class Initialized
DEBUG - 2019-08-26 00:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 00:25:37 --> Input Class Initialized
INFO - 2019-08-26 00:25:37 --> Language Class Initialized
INFO - 2019-08-26 00:25:37 --> Loader Class Initialized
INFO - 2019-08-26 00:25:37 --> Helper loaded: url_helper
INFO - 2019-08-26 00:25:37 --> Helper loaded: html_helper
INFO - 2019-08-26 00:25:37 --> Helper loaded: form_helper
INFO - 2019-08-26 00:25:37 --> Helper loaded: cookie_helper
INFO - 2019-08-26 00:25:37 --> Helper loaded: date_helper
INFO - 2019-08-26 00:25:37 --> Form Validation Class Initialized
INFO - 2019-08-26 00:25:37 --> Email Class Initialized
DEBUG - 2019-08-26 00:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 00:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 00:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 00:25:37 --> Pagination Class Initialized
INFO - 2019-08-26 00:25:37 --> Database Driver Class Initialized
INFO - 2019-08-26 00:25:37 --> Database Driver Class Initialized
INFO - 2019-08-26 00:25:37 --> Controller Class Initialized
INFO - 2019-08-26 00:25:37 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-26 00:25:37 --> Final output sent to browser
DEBUG - 2019-08-26 00:25:37 --> Total execution time: 0.5620
INFO - 2019-08-26 00:25:37 --> Config Class Initialized
INFO - 2019-08-26 00:25:37 --> Hooks Class Initialized
DEBUG - 2019-08-26 00:25:37 --> UTF-8 Support Enabled
INFO - 2019-08-26 00:25:37 --> Utf8 Class Initialized
INFO - 2019-08-26 00:25:38 --> URI Class Initialized
INFO - 2019-08-26 00:25:38 --> Router Class Initialized
INFO - 2019-08-26 00:25:38 --> Output Class Initialized
INFO - 2019-08-26 00:25:38 --> Security Class Initialized
DEBUG - 2019-08-26 00:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 00:25:38 --> Input Class Initialized
INFO - 2019-08-26 00:25:38 --> Language Class Initialized
INFO - 2019-08-26 00:25:38 --> Loader Class Initialized
INFO - 2019-08-26 00:25:38 --> Helper loaded: url_helper
INFO - 2019-08-26 00:25:38 --> Helper loaded: html_helper
INFO - 2019-08-26 00:25:38 --> Helper loaded: form_helper
INFO - 2019-08-26 00:25:38 --> Helper loaded: cookie_helper
INFO - 2019-08-26 00:25:38 --> Helper loaded: date_helper
INFO - 2019-08-26 00:25:38 --> Form Validation Class Initialized
INFO - 2019-08-26 00:25:38 --> Email Class Initialized
DEBUG - 2019-08-26 00:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 00:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 00:25:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 00:25:38 --> Pagination Class Initialized
INFO - 2019-08-26 00:25:38 --> Database Driver Class Initialized
INFO - 2019-08-26 00:25:38 --> Database Driver Class Initialized
INFO - 2019-08-26 00:25:38 --> Controller Class Initialized
INFO - 2019-08-26 00:25:38 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-26 00:25:38 --> Final output sent to browser
DEBUG - 2019-08-26 00:25:38 --> Total execution time: 0.5669
INFO - 2019-08-26 00:25:46 --> Config Class Initialized
INFO - 2019-08-26 00:25:46 --> Hooks Class Initialized
DEBUG - 2019-08-26 00:25:46 --> UTF-8 Support Enabled
INFO - 2019-08-26 00:25:46 --> Utf8 Class Initialized
INFO - 2019-08-26 00:25:46 --> URI Class Initialized
INFO - 2019-08-26 00:25:46 --> Router Class Initialized
INFO - 2019-08-26 00:25:46 --> Output Class Initialized
INFO - 2019-08-26 00:25:46 --> Security Class Initialized
DEBUG - 2019-08-26 00:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 00:25:46 --> Input Class Initialized
INFO - 2019-08-26 00:25:46 --> Language Class Initialized
INFO - 2019-08-26 00:25:46 --> Loader Class Initialized
INFO - 2019-08-26 00:25:46 --> Helper loaded: url_helper
INFO - 2019-08-26 00:25:46 --> Helper loaded: html_helper
INFO - 2019-08-26 00:25:46 --> Helper loaded: form_helper
INFO - 2019-08-26 00:25:46 --> Helper loaded: cookie_helper
INFO - 2019-08-26 00:25:46 --> Helper loaded: date_helper
INFO - 2019-08-26 00:25:46 --> Form Validation Class Initialized
INFO - 2019-08-26 00:25:46 --> Email Class Initialized
DEBUG - 2019-08-26 00:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 00:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 00:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 00:25:46 --> Pagination Class Initialized
INFO - 2019-08-26 00:25:46 --> Database Driver Class Initialized
INFO - 2019-08-26 00:25:46 --> Database Driver Class Initialized
INFO - 2019-08-26 00:25:46 --> Controller Class Initialized
INFO - 2019-08-26 00:25:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 00:25:47 --> Config Class Initialized
INFO - 2019-08-26 00:25:47 --> Hooks Class Initialized
DEBUG - 2019-08-26 00:25:47 --> UTF-8 Support Enabled
INFO - 2019-08-26 00:25:47 --> Utf8 Class Initialized
INFO - 2019-08-26 00:25:47 --> URI Class Initialized
INFO - 2019-08-26 00:25:47 --> Router Class Initialized
INFO - 2019-08-26 00:25:47 --> Output Class Initialized
INFO - 2019-08-26 00:25:47 --> Security Class Initialized
DEBUG - 2019-08-26 00:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 00:25:47 --> Input Class Initialized
INFO - 2019-08-26 00:25:47 --> Language Class Initialized
INFO - 2019-08-26 00:25:47 --> Loader Class Initialized
INFO - 2019-08-26 00:25:47 --> Helper loaded: url_helper
INFO - 2019-08-26 00:25:47 --> Helper loaded: html_helper
INFO - 2019-08-26 00:25:47 --> Helper loaded: form_helper
INFO - 2019-08-26 00:25:47 --> Helper loaded: cookie_helper
INFO - 2019-08-26 00:25:47 --> Helper loaded: date_helper
INFO - 2019-08-26 00:25:47 --> Form Validation Class Initialized
INFO - 2019-08-26 00:25:47 --> Email Class Initialized
DEBUG - 2019-08-26 00:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 00:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 00:25:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 00:25:47 --> Pagination Class Initialized
INFO - 2019-08-26 00:25:47 --> Database Driver Class Initialized
INFO - 2019-08-26 00:25:47 --> Database Driver Class Initialized
INFO - 2019-08-26 00:25:47 --> Controller Class Initialized
INFO - 2019-08-26 00:25:47 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-26 00:25:47 --> Final output sent to browser
DEBUG - 2019-08-26 00:25:47 --> Total execution time: 0.5123
INFO - 2019-08-26 00:44:02 --> Config Class Initialized
INFO - 2019-08-26 00:44:02 --> Hooks Class Initialized
DEBUG - 2019-08-26 00:44:02 --> UTF-8 Support Enabled
INFO - 2019-08-26 00:44:02 --> Utf8 Class Initialized
INFO - 2019-08-26 00:44:02 --> URI Class Initialized
INFO - 2019-08-26 00:44:02 --> Router Class Initialized
INFO - 2019-08-26 00:44:02 --> Output Class Initialized
INFO - 2019-08-26 00:44:02 --> Security Class Initialized
DEBUG - 2019-08-26 00:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 00:44:02 --> Input Class Initialized
INFO - 2019-08-26 00:44:02 --> Language Class Initialized
INFO - 2019-08-26 00:44:02 --> Loader Class Initialized
INFO - 2019-08-26 00:44:02 --> Helper loaded: url_helper
INFO - 2019-08-26 00:44:03 --> Helper loaded: html_helper
INFO - 2019-08-26 00:44:03 --> Helper loaded: form_helper
INFO - 2019-08-26 00:44:03 --> Helper loaded: cookie_helper
INFO - 2019-08-26 00:44:03 --> Helper loaded: date_helper
INFO - 2019-08-26 00:44:03 --> Form Validation Class Initialized
INFO - 2019-08-26 00:44:03 --> Email Class Initialized
DEBUG - 2019-08-26 00:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 00:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 00:44:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 00:44:03 --> Pagination Class Initialized
INFO - 2019-08-26 00:44:03 --> Database Driver Class Initialized
INFO - 2019-08-26 00:44:03 --> Database Driver Class Initialized
INFO - 2019-08-26 00:44:03 --> Controller Class Initialized
INFO - 2019-08-26 00:44:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-26 00:44:03 --> Final output sent to browser
DEBUG - 2019-08-26 00:44:03 --> Total execution time: 0.8041
INFO - 2019-08-26 08:52:15 --> Config Class Initialized
INFO - 2019-08-26 08:52:15 --> Hooks Class Initialized
DEBUG - 2019-08-26 08:52:15 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:52:15 --> Utf8 Class Initialized
INFO - 2019-08-26 08:52:15 --> URI Class Initialized
INFO - 2019-08-26 08:52:15 --> Router Class Initialized
INFO - 2019-08-26 08:52:16 --> Output Class Initialized
INFO - 2019-08-26 08:52:16 --> Security Class Initialized
DEBUG - 2019-08-26 08:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:52:16 --> Input Class Initialized
INFO - 2019-08-26 08:52:16 --> Language Class Initialized
INFO - 2019-08-26 08:52:16 --> Loader Class Initialized
INFO - 2019-08-26 08:52:16 --> Helper loaded: url_helper
INFO - 2019-08-26 08:52:16 --> Helper loaded: html_helper
INFO - 2019-08-26 08:52:16 --> Helper loaded: form_helper
INFO - 2019-08-26 08:52:16 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:52:16 --> Helper loaded: date_helper
INFO - 2019-08-26 08:52:16 --> Form Validation Class Initialized
INFO - 2019-08-26 08:52:16 --> Email Class Initialized
DEBUG - 2019-08-26 08:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:52:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:52:16 --> Pagination Class Initialized
INFO - 2019-08-26 08:52:17 --> Database Driver Class Initialized
INFO - 2019-08-26 08:52:17 --> Database Driver Class Initialized
INFO - 2019-08-26 08:52:17 --> Controller Class Initialized
INFO - 2019-08-26 08:52:17 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-26 08:52:17 --> Final output sent to browser
DEBUG - 2019-08-26 08:52:17 --> Total execution time: 1.6962
INFO - 2019-08-26 08:53:21 --> Config Class Initialized
INFO - 2019-08-26 08:53:21 --> Hooks Class Initialized
DEBUG - 2019-08-26 08:53:21 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:53:21 --> Utf8 Class Initialized
INFO - 2019-08-26 08:53:21 --> URI Class Initialized
INFO - 2019-08-26 08:53:21 --> Router Class Initialized
INFO - 2019-08-26 08:53:21 --> Output Class Initialized
INFO - 2019-08-26 08:53:21 --> Security Class Initialized
DEBUG - 2019-08-26 08:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:53:21 --> Input Class Initialized
INFO - 2019-08-26 08:53:21 --> Language Class Initialized
INFO - 2019-08-26 08:53:21 --> Loader Class Initialized
INFO - 2019-08-26 08:53:21 --> Helper loaded: url_helper
INFO - 2019-08-26 08:53:21 --> Helper loaded: html_helper
INFO - 2019-08-26 08:53:21 --> Helper loaded: form_helper
INFO - 2019-08-26 08:53:21 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:53:21 --> Helper loaded: date_helper
INFO - 2019-08-26 08:53:21 --> Form Validation Class Initialized
INFO - 2019-08-26 08:53:21 --> Email Class Initialized
DEBUG - 2019-08-26 08:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:53:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:53:21 --> Pagination Class Initialized
INFO - 2019-08-26 08:53:21 --> Database Driver Class Initialized
INFO - 2019-08-26 08:53:21 --> Database Driver Class Initialized
INFO - 2019-08-26 08:53:21 --> Controller Class Initialized
INFO - 2019-08-26 08:53:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 08:53:21 --> Config Class Initialized
INFO - 2019-08-26 08:53:21 --> Hooks Class Initialized
DEBUG - 2019-08-26 08:53:22 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:53:22 --> Utf8 Class Initialized
INFO - 2019-08-26 08:53:22 --> URI Class Initialized
INFO - 2019-08-26 08:53:22 --> Router Class Initialized
INFO - 2019-08-26 08:53:22 --> Output Class Initialized
INFO - 2019-08-26 08:53:22 --> Security Class Initialized
DEBUG - 2019-08-26 08:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:53:22 --> Input Class Initialized
INFO - 2019-08-26 08:53:22 --> Language Class Initialized
INFO - 2019-08-26 08:53:22 --> Loader Class Initialized
INFO - 2019-08-26 08:53:22 --> Helper loaded: url_helper
INFO - 2019-08-26 08:53:22 --> Helper loaded: html_helper
INFO - 2019-08-26 08:53:22 --> Helper loaded: form_helper
INFO - 2019-08-26 08:53:22 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:53:22 --> Helper loaded: date_helper
INFO - 2019-08-26 08:53:22 --> Form Validation Class Initialized
INFO - 2019-08-26 08:53:22 --> Email Class Initialized
DEBUG - 2019-08-26 08:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:53:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:53:22 --> Pagination Class Initialized
INFO - 2019-08-26 08:53:22 --> Database Driver Class Initialized
INFO - 2019-08-26 08:53:22 --> Database Driver Class Initialized
INFO - 2019-08-26 08:53:22 --> Controller Class Initialized
INFO - 2019-08-26 08:53:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-26 08:53:22 --> Final output sent to browser
DEBUG - 2019-08-26 08:53:22 --> Total execution time: 0.6396
INFO - 2019-08-26 08:56:07 --> Config Class Initialized
INFO - 2019-08-26 08:56:07 --> Hooks Class Initialized
DEBUG - 2019-08-26 08:56:07 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:56:07 --> Utf8 Class Initialized
INFO - 2019-08-26 08:56:07 --> URI Class Initialized
INFO - 2019-08-26 08:56:07 --> Router Class Initialized
INFO - 2019-08-26 08:56:07 --> Output Class Initialized
INFO - 2019-08-26 08:56:07 --> Security Class Initialized
DEBUG - 2019-08-26 08:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:56:07 --> Input Class Initialized
INFO - 2019-08-26 08:56:07 --> Language Class Initialized
INFO - 2019-08-26 08:56:08 --> Loader Class Initialized
INFO - 2019-08-26 08:56:08 --> Helper loaded: url_helper
INFO - 2019-08-26 08:56:08 --> Helper loaded: html_helper
INFO - 2019-08-26 08:56:08 --> Helper loaded: form_helper
INFO - 2019-08-26 08:56:08 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:56:08 --> Helper loaded: date_helper
INFO - 2019-08-26 08:56:08 --> Form Validation Class Initialized
INFO - 2019-08-26 08:56:08 --> Email Class Initialized
DEBUG - 2019-08-26 08:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:56:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:56:09 --> Pagination Class Initialized
INFO - 2019-08-26 08:56:09 --> Database Driver Class Initialized
INFO - 2019-08-26 08:56:09 --> Database Driver Class Initialized
INFO - 2019-08-26 08:56:10 --> Controller Class Initialized
INFO - 2019-08-26 08:56:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-26 08:56:10 --> Final output sent to browser
DEBUG - 2019-08-26 08:56:10 --> Total execution time: 3.5533
INFO - 2019-08-26 08:56:11 --> Config Class Initialized
INFO - 2019-08-26 08:56:11 --> Hooks Class Initialized
DEBUG - 2019-08-26 08:56:11 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:56:11 --> Utf8 Class Initialized
INFO - 2019-08-26 08:56:11 --> URI Class Initialized
INFO - 2019-08-26 08:56:11 --> Router Class Initialized
INFO - 2019-08-26 08:56:11 --> Output Class Initialized
INFO - 2019-08-26 08:56:11 --> Security Class Initialized
DEBUG - 2019-08-26 08:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:56:11 --> Input Class Initialized
INFO - 2019-08-26 08:56:11 --> Language Class Initialized
INFO - 2019-08-26 08:56:11 --> Loader Class Initialized
INFO - 2019-08-26 08:56:11 --> Helper loaded: url_helper
INFO - 2019-08-26 08:56:11 --> Helper loaded: html_helper
INFO - 2019-08-26 08:56:11 --> Helper loaded: form_helper
INFO - 2019-08-26 08:56:11 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:56:11 --> Helper loaded: date_helper
INFO - 2019-08-26 08:56:11 --> Form Validation Class Initialized
INFO - 2019-08-26 08:56:11 --> Email Class Initialized
DEBUG - 2019-08-26 08:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:56:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:56:11 --> Pagination Class Initialized
INFO - 2019-08-26 08:56:11 --> Database Driver Class Initialized
INFO - 2019-08-26 08:56:12 --> Database Driver Class Initialized
INFO - 2019-08-26 08:56:12 --> Controller Class Initialized
INFO - 2019-08-26 08:56:12 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-26 08:56:12 --> Final output sent to browser
DEBUG - 2019-08-26 08:56:12 --> Total execution time: 1.0999
INFO - 2019-08-26 08:56:21 --> Config Class Initialized
INFO - 2019-08-26 08:56:21 --> Hooks Class Initialized
DEBUG - 2019-08-26 08:56:21 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:56:21 --> Utf8 Class Initialized
INFO - 2019-08-26 08:56:21 --> URI Class Initialized
INFO - 2019-08-26 08:56:21 --> Router Class Initialized
INFO - 2019-08-26 08:56:21 --> Output Class Initialized
INFO - 2019-08-26 08:56:21 --> Security Class Initialized
DEBUG - 2019-08-26 08:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:56:21 --> Input Class Initialized
INFO - 2019-08-26 08:56:21 --> Language Class Initialized
INFO - 2019-08-26 08:56:21 --> Loader Class Initialized
INFO - 2019-08-26 08:56:21 --> Helper loaded: url_helper
INFO - 2019-08-26 08:56:21 --> Helper loaded: html_helper
INFO - 2019-08-26 08:56:21 --> Helper loaded: form_helper
INFO - 2019-08-26 08:56:21 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:56:21 --> Helper loaded: date_helper
INFO - 2019-08-26 08:56:21 --> Form Validation Class Initialized
INFO - 2019-08-26 08:56:21 --> Email Class Initialized
DEBUG - 2019-08-26 08:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:56:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:56:21 --> Pagination Class Initialized
INFO - 2019-08-26 08:56:21 --> Database Driver Class Initialized
INFO - 2019-08-26 08:56:21 --> Database Driver Class Initialized
INFO - 2019-08-26 08:56:21 --> Controller Class Initialized
INFO - 2019-08-26 08:56:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 08:56:22 --> Config Class Initialized
INFO - 2019-08-26 08:56:22 --> Hooks Class Initialized
DEBUG - 2019-08-26 08:56:22 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:56:22 --> Utf8 Class Initialized
INFO - 2019-08-26 08:56:22 --> URI Class Initialized
INFO - 2019-08-26 08:56:22 --> Router Class Initialized
INFO - 2019-08-26 08:56:22 --> Output Class Initialized
INFO - 2019-08-26 08:56:22 --> Security Class Initialized
DEBUG - 2019-08-26 08:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:56:22 --> Input Class Initialized
INFO - 2019-08-26 08:56:22 --> Language Class Initialized
INFO - 2019-08-26 08:56:22 --> Loader Class Initialized
INFO - 2019-08-26 08:56:22 --> Helper loaded: url_helper
INFO - 2019-08-26 08:56:22 --> Helper loaded: html_helper
INFO - 2019-08-26 08:56:22 --> Helper loaded: form_helper
INFO - 2019-08-26 08:56:22 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:56:22 --> Helper loaded: date_helper
INFO - 2019-08-26 08:56:22 --> Form Validation Class Initialized
INFO - 2019-08-26 08:56:22 --> Email Class Initialized
DEBUG - 2019-08-26 08:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:56:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:56:22 --> Pagination Class Initialized
INFO - 2019-08-26 08:56:22 --> Database Driver Class Initialized
INFO - 2019-08-26 08:56:22 --> Database Driver Class Initialized
INFO - 2019-08-26 08:56:22 --> Controller Class Initialized
INFO - 2019-08-26 08:56:23 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 08:56:23 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 08:56:23 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 08:56:23 --> Final output sent to browser
DEBUG - 2019-08-26 08:56:23 --> Total execution time: 1.4773
INFO - 2019-08-26 08:56:24 --> Config Class Initialized
INFO - 2019-08-26 08:56:24 --> Hooks Class Initialized
DEBUG - 2019-08-26 08:56:24 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:56:24 --> Utf8 Class Initialized
INFO - 2019-08-26 08:56:24 --> URI Class Initialized
INFO - 2019-08-26 08:56:24 --> Config Class Initialized
INFO - 2019-08-26 08:56:24 --> Router Class Initialized
INFO - 2019-08-26 08:56:24 --> Hooks Class Initialized
DEBUG - 2019-08-26 08:56:24 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:56:24 --> Utf8 Class Initialized
INFO - 2019-08-26 08:56:24 --> URI Class Initialized
INFO - 2019-08-26 08:56:24 --> Router Class Initialized
INFO - 2019-08-26 08:56:25 --> Output Class Initialized
INFO - 2019-08-26 08:56:25 --> Security Class Initialized
DEBUG - 2019-08-26 08:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:56:25 --> Input Class Initialized
INFO - 2019-08-26 08:56:25 --> Language Class Initialized
INFO - 2019-08-26 08:56:25 --> Loader Class Initialized
INFO - 2019-08-26 08:56:25 --> Output Class Initialized
INFO - 2019-08-26 08:56:25 --> Security Class Initialized
DEBUG - 2019-08-26 08:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:56:25 --> Input Class Initialized
INFO - 2019-08-26 08:56:25 --> Helper loaded: url_helper
INFO - 2019-08-26 08:56:25 --> Language Class Initialized
INFO - 2019-08-26 08:56:25 --> Loader Class Initialized
INFO - 2019-08-26 08:56:25 --> Helper loaded: url_helper
INFO - 2019-08-26 08:56:25 --> Helper loaded: html_helper
INFO - 2019-08-26 08:56:25 --> Helper loaded: form_helper
INFO - 2019-08-26 08:56:25 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:56:25 --> Helper loaded: html_helper
INFO - 2019-08-26 08:56:25 --> Helper loaded: date_helper
INFO - 2019-08-26 08:56:25 --> Helper loaded: form_helper
INFO - 2019-08-26 08:56:25 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:56:25 --> Helper loaded: date_helper
INFO - 2019-08-26 08:56:26 --> Form Validation Class Initialized
INFO - 2019-08-26 08:56:26 --> Email Class Initialized
INFO - 2019-08-26 08:56:26 --> Form Validation Class Initialized
INFO - 2019-08-26 08:56:26 --> Email Class Initialized
DEBUG - 2019-08-26 08:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:56:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:56:26 --> Pagination Class Initialized
DEBUG - 2019-08-26 08:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:56:26 --> Database Driver Class Initialized
INFO - 2019-08-26 08:56:26 --> Database Driver Class Initialized
INFO - 2019-08-26 08:56:26 --> Controller Class Initialized
INFO - 2019-08-26 08:56:26 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 08:56:26 --> Final output sent to browser
DEBUG - 2019-08-26 08:56:26 --> Total execution time: 2.3296
INFO - 2019-08-26 08:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:56:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:56:26 --> Pagination Class Initialized
INFO - 2019-08-26 08:56:26 --> Database Driver Class Initialized
INFO - 2019-08-26 08:56:27 --> Database Driver Class Initialized
INFO - 2019-08-26 08:56:27 --> Controller Class Initialized
INFO - 2019-08-26 08:56:27 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 08:56:27 --> Final output sent to browser
DEBUG - 2019-08-26 08:56:27 --> Total execution time: 2.6082
INFO - 2019-08-26 08:57:22 --> Config Class Initialized
INFO - 2019-08-26 08:57:22 --> Hooks Class Initialized
DEBUG - 2019-08-26 08:57:22 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:57:22 --> Utf8 Class Initialized
INFO - 2019-08-26 08:57:22 --> URI Class Initialized
INFO - 2019-08-26 08:57:22 --> Router Class Initialized
INFO - 2019-08-26 08:57:22 --> Output Class Initialized
INFO - 2019-08-26 08:57:22 --> Security Class Initialized
DEBUG - 2019-08-26 08:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:57:22 --> Input Class Initialized
INFO - 2019-08-26 08:57:22 --> Language Class Initialized
INFO - 2019-08-26 08:57:23 --> Loader Class Initialized
INFO - 2019-08-26 08:57:23 --> Helper loaded: url_helper
INFO - 2019-08-26 08:57:23 --> Helper loaded: html_helper
INFO - 2019-08-26 08:57:23 --> Helper loaded: form_helper
INFO - 2019-08-26 08:57:23 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:57:23 --> Helper loaded: date_helper
INFO - 2019-08-26 08:57:23 --> Form Validation Class Initialized
INFO - 2019-08-26 08:57:23 --> Email Class Initialized
DEBUG - 2019-08-26 08:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:57:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:57:23 --> Pagination Class Initialized
INFO - 2019-08-26 08:57:23 --> Database Driver Class Initialized
INFO - 2019-08-26 08:57:23 --> Database Driver Class Initialized
INFO - 2019-08-26 08:57:23 --> Controller Class Initialized
INFO - 2019-08-26 08:57:23 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 08:57:23 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 08:57:23 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-26 08:57:23 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 08:57:24 --> Final output sent to browser
DEBUG - 2019-08-26 08:57:24 --> Total execution time: 1.3318
INFO - 2019-08-26 08:57:24 --> Config Class Initialized
INFO - 2019-08-26 08:57:24 --> Config Class Initialized
INFO - 2019-08-26 08:57:24 --> Hooks Class Initialized
INFO - 2019-08-26 08:57:24 --> Hooks Class Initialized
DEBUG - 2019-08-26 08:57:24 --> UTF-8 Support Enabled
DEBUG - 2019-08-26 08:57:24 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:57:24 --> Utf8 Class Initialized
INFO - 2019-08-26 08:57:24 --> Utf8 Class Initialized
INFO - 2019-08-26 08:57:24 --> URI Class Initialized
INFO - 2019-08-26 08:57:24 --> Router Class Initialized
INFO - 2019-08-26 08:57:24 --> Output Class Initialized
INFO - 2019-08-26 08:57:24 --> Security Class Initialized
DEBUG - 2019-08-26 08:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:57:24 --> Input Class Initialized
INFO - 2019-08-26 08:57:24 --> Language Class Initialized
INFO - 2019-08-26 08:57:25 --> Loader Class Initialized
INFO - 2019-08-26 08:57:25 --> Helper loaded: url_helper
INFO - 2019-08-26 08:57:25 --> Helper loaded: html_helper
INFO - 2019-08-26 08:57:25 --> Helper loaded: form_helper
INFO - 2019-08-26 08:57:25 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:57:25 --> URI Class Initialized
INFO - 2019-08-26 08:57:25 --> Helper loaded: date_helper
INFO - 2019-08-26 08:57:25 --> Form Validation Class Initialized
INFO - 2019-08-26 08:57:25 --> Router Class Initialized
INFO - 2019-08-26 08:57:25 --> Email Class Initialized
INFO - 2019-08-26 08:57:25 --> Output Class Initialized
DEBUG - 2019-08-26 08:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:57:25 --> Security Class Initialized
INFO - 2019-08-26 08:57:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-08-26 08:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:57:25 --> Input Class Initialized
INFO - 2019-08-26 08:57:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:57:25 --> Pagination Class Initialized
INFO - 2019-08-26 08:57:25 --> Language Class Initialized
INFO - 2019-08-26 08:57:25 --> Loader Class Initialized
INFO - 2019-08-26 08:57:25 --> Database Driver Class Initialized
INFO - 2019-08-26 08:57:25 --> Helper loaded: url_helper
INFO - 2019-08-26 08:57:25 --> Database Driver Class Initialized
INFO - 2019-08-26 08:57:25 --> Helper loaded: html_helper
INFO - 2019-08-26 08:57:25 --> Controller Class Initialized
INFO - 2019-08-26 08:57:25 --> Helper loaded: form_helper
INFO - 2019-08-26 08:57:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 08:57:25 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:57:25 --> Final output sent to browser
INFO - 2019-08-26 08:57:25 --> Helper loaded: date_helper
DEBUG - 2019-08-26 08:57:25 --> Total execution time: 1.4177
INFO - 2019-08-26 08:57:26 --> Form Validation Class Initialized
INFO - 2019-08-26 08:57:26 --> Email Class Initialized
DEBUG - 2019-08-26 08:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:57:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:57:26 --> Pagination Class Initialized
INFO - 2019-08-26 08:57:26 --> Database Driver Class Initialized
INFO - 2019-08-26 08:57:26 --> Database Driver Class Initialized
INFO - 2019-08-26 08:57:26 --> Controller Class Initialized
INFO - 2019-08-26 08:57:26 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 08:57:26 --> Final output sent to browser
DEBUG - 2019-08-26 08:57:26 --> Total execution time: 1.9833
INFO - 2019-08-26 08:57:30 --> Config Class Initialized
INFO - 2019-08-26 08:57:30 --> Hooks Class Initialized
DEBUG - 2019-08-26 08:57:30 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:57:30 --> Utf8 Class Initialized
INFO - 2019-08-26 08:57:30 --> URI Class Initialized
INFO - 2019-08-26 08:57:30 --> Router Class Initialized
INFO - 2019-08-26 08:57:30 --> Output Class Initialized
INFO - 2019-08-26 08:57:30 --> Security Class Initialized
DEBUG - 2019-08-26 08:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:57:30 --> Input Class Initialized
INFO - 2019-08-26 08:57:30 --> Language Class Initialized
INFO - 2019-08-26 08:57:30 --> Loader Class Initialized
INFO - 2019-08-26 08:57:30 --> Helper loaded: url_helper
INFO - 2019-08-26 08:57:30 --> Helper loaded: html_helper
INFO - 2019-08-26 08:57:30 --> Helper loaded: form_helper
INFO - 2019-08-26 08:57:30 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:57:30 --> Helper loaded: date_helper
INFO - 2019-08-26 08:57:30 --> Form Validation Class Initialized
INFO - 2019-08-26 08:57:30 --> Email Class Initialized
DEBUG - 2019-08-26 08:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:57:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:57:30 --> Pagination Class Initialized
INFO - 2019-08-26 08:57:30 --> Database Driver Class Initialized
INFO - 2019-08-26 08:57:30 --> Database Driver Class Initialized
INFO - 2019-08-26 08:57:30 --> Controller Class Initialized
INFO - 2019-08-26 08:57:31 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 08:57:31 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 08:57:31 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-26 08:57:31 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 08:57:31 --> Final output sent to browser
DEBUG - 2019-08-26 08:57:31 --> Total execution time: 1.0572
INFO - 2019-08-26 08:57:31 --> Config Class Initialized
INFO - 2019-08-26 08:57:31 --> Hooks Class Initialized
DEBUG - 2019-08-26 08:57:31 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:57:31 --> Utf8 Class Initialized
INFO - 2019-08-26 08:57:31 --> URI Class Initialized
INFO - 2019-08-26 08:57:31 --> Config Class Initialized
INFO - 2019-08-26 08:57:31 --> Hooks Class Initialized
DEBUG - 2019-08-26 08:57:31 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:57:31 --> Utf8 Class Initialized
INFO - 2019-08-26 08:57:31 --> URI Class Initialized
INFO - 2019-08-26 08:57:31 --> Router Class Initialized
INFO - 2019-08-26 08:57:32 --> Router Class Initialized
INFO - 2019-08-26 08:57:32 --> Output Class Initialized
INFO - 2019-08-26 08:57:32 --> Output Class Initialized
INFO - 2019-08-26 08:57:32 --> Security Class Initialized
DEBUG - 2019-08-26 08:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:57:32 --> Input Class Initialized
INFO - 2019-08-26 08:57:32 --> Security Class Initialized
INFO - 2019-08-26 08:57:32 --> Language Class Initialized
DEBUG - 2019-08-26 08:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:57:32 --> Input Class Initialized
INFO - 2019-08-26 08:57:32 --> Language Class Initialized
INFO - 2019-08-26 08:57:32 --> Loader Class Initialized
INFO - 2019-08-26 08:57:32 --> Helper loaded: url_helper
INFO - 2019-08-26 08:57:32 --> Helper loaded: html_helper
INFO - 2019-08-26 08:57:32 --> Helper loaded: form_helper
INFO - 2019-08-26 08:57:32 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:57:32 --> Helper loaded: date_helper
INFO - 2019-08-26 08:57:32 --> Form Validation Class Initialized
INFO - 2019-08-26 08:57:32 --> Email Class Initialized
DEBUG - 2019-08-26 08:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:57:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:57:32 --> Pagination Class Initialized
INFO - 2019-08-26 08:57:32 --> Loader Class Initialized
INFO - 2019-08-26 08:57:32 --> Helper loaded: url_helper
INFO - 2019-08-26 08:57:32 --> Helper loaded: html_helper
INFO - 2019-08-26 08:57:32 --> Database Driver Class Initialized
INFO - 2019-08-26 08:57:32 --> Helper loaded: form_helper
INFO - 2019-08-26 08:57:32 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:57:33 --> Helper loaded: date_helper
INFO - 2019-08-26 08:57:33 --> Database Driver Class Initialized
INFO - 2019-08-26 08:57:33 --> Form Validation Class Initialized
INFO - 2019-08-26 08:57:33 --> Controller Class Initialized
INFO - 2019-08-26 08:57:33 --> Email Class Initialized
INFO - 2019-08-26 08:57:33 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
DEBUG - 2019-08-26 08:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:57:33 --> Final output sent to browser
DEBUG - 2019-08-26 08:57:33 --> Total execution time: 1.7037
INFO - 2019-08-26 08:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:57:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:57:33 --> Pagination Class Initialized
INFO - 2019-08-26 08:57:33 --> Database Driver Class Initialized
INFO - 2019-08-26 08:57:33 --> Database Driver Class Initialized
INFO - 2019-08-26 08:57:33 --> Controller Class Initialized
INFO - 2019-08-26 08:57:33 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 08:57:33 --> Final output sent to browser
DEBUG - 2019-08-26 08:57:33 --> Total execution time: 2.0536
INFO - 2019-08-26 08:59:02 --> Config Class Initialized
INFO - 2019-08-26 08:59:02 --> Hooks Class Initialized
DEBUG - 2019-08-26 08:59:02 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:59:02 --> Utf8 Class Initialized
INFO - 2019-08-26 08:59:02 --> URI Class Initialized
INFO - 2019-08-26 08:59:02 --> Router Class Initialized
INFO - 2019-08-26 08:59:02 --> Output Class Initialized
INFO - 2019-08-26 08:59:02 --> Security Class Initialized
DEBUG - 2019-08-26 08:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:59:02 --> Input Class Initialized
INFO - 2019-08-26 08:59:02 --> Language Class Initialized
INFO - 2019-08-26 08:59:02 --> Loader Class Initialized
INFO - 2019-08-26 08:59:02 --> Helper loaded: url_helper
INFO - 2019-08-26 08:59:02 --> Helper loaded: html_helper
INFO - 2019-08-26 08:59:03 --> Helper loaded: form_helper
INFO - 2019-08-26 08:59:03 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:59:03 --> Helper loaded: date_helper
INFO - 2019-08-26 08:59:03 --> Form Validation Class Initialized
INFO - 2019-08-26 08:59:03 --> Email Class Initialized
DEBUG - 2019-08-26 08:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:59:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:59:03 --> Pagination Class Initialized
INFO - 2019-08-26 08:59:03 --> Database Driver Class Initialized
INFO - 2019-08-26 08:59:03 --> Database Driver Class Initialized
INFO - 2019-08-26 08:59:03 --> Controller Class Initialized
INFO - 2019-08-26 08:59:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 08:59:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 08:59:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/guest.php
INFO - 2019-08-26 08:59:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 08:59:04 --> Final output sent to browser
DEBUG - 2019-08-26 08:59:04 --> Total execution time: 1.7646
INFO - 2019-08-26 08:59:04 --> Config Class Initialized
INFO - 2019-08-26 08:59:04 --> Config Class Initialized
INFO - 2019-08-26 08:59:04 --> Hooks Class Initialized
INFO - 2019-08-26 08:59:04 --> Hooks Class Initialized
DEBUG - 2019-08-26 08:59:04 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:59:04 --> Utf8 Class Initialized
DEBUG - 2019-08-26 08:59:04 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:59:04 --> Utf8 Class Initialized
INFO - 2019-08-26 08:59:04 --> URI Class Initialized
INFO - 2019-08-26 08:59:05 --> Router Class Initialized
INFO - 2019-08-26 08:59:05 --> Output Class Initialized
INFO - 2019-08-26 08:59:05 --> Security Class Initialized
DEBUG - 2019-08-26 08:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:59:05 --> Input Class Initialized
INFO - 2019-08-26 08:59:05 --> Language Class Initialized
INFO - 2019-08-26 08:59:05 --> URI Class Initialized
INFO - 2019-08-26 08:59:05 --> Router Class Initialized
INFO - 2019-08-26 08:59:05 --> Output Class Initialized
INFO - 2019-08-26 08:59:05 --> Loader Class Initialized
INFO - 2019-08-26 08:59:05 --> Helper loaded: url_helper
INFO - 2019-08-26 08:59:05 --> Helper loaded: html_helper
INFO - 2019-08-26 08:59:05 --> Helper loaded: form_helper
INFO - 2019-08-26 08:59:05 --> Security Class Initialized
INFO - 2019-08-26 08:59:05 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:59:05 --> Helper loaded: date_helper
INFO - 2019-08-26 08:59:05 --> Form Validation Class Initialized
DEBUG - 2019-08-26 08:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:59:05 --> Email Class Initialized
INFO - 2019-08-26 08:59:05 --> Input Class Initialized
INFO - 2019-08-26 08:59:06 --> Language Class Initialized
DEBUG - 2019-08-26 08:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:59:06 --> Loader Class Initialized
INFO - 2019-08-26 08:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:59:06 --> Helper loaded: url_helper
INFO - 2019-08-26 08:59:06 --> Pagination Class Initialized
INFO - 2019-08-26 08:59:06 --> Helper loaded: html_helper
INFO - 2019-08-26 08:59:06 --> Database Driver Class Initialized
INFO - 2019-08-26 08:59:06 --> Helper loaded: form_helper
INFO - 2019-08-26 08:59:06 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:59:06 --> Database Driver Class Initialized
INFO - 2019-08-26 08:59:06 --> Helper loaded: date_helper
INFO - 2019-08-26 08:59:06 --> Controller Class Initialized
INFO - 2019-08-26 08:59:06 --> Form Validation Class Initialized
INFO - 2019-08-26 08:59:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 08:59:06 --> Email Class Initialized
INFO - 2019-08-26 08:59:06 --> Final output sent to browser
DEBUG - 2019-08-26 08:59:06 --> Total execution time: 2.1368
DEBUG - 2019-08-26 08:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:59:06 --> Pagination Class Initialized
INFO - 2019-08-26 08:59:07 --> Database Driver Class Initialized
INFO - 2019-08-26 08:59:07 --> Database Driver Class Initialized
INFO - 2019-08-26 08:59:07 --> Controller Class Initialized
INFO - 2019-08-26 08:59:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 08:59:07 --> Final output sent to browser
DEBUG - 2019-08-26 08:59:07 --> Total execution time: 2.6681
INFO - 2019-08-26 08:59:11 --> Config Class Initialized
INFO - 2019-08-26 08:59:11 --> Hooks Class Initialized
DEBUG - 2019-08-26 08:59:11 --> UTF-8 Support Enabled
INFO - 2019-08-26 08:59:11 --> Utf8 Class Initialized
INFO - 2019-08-26 08:59:11 --> URI Class Initialized
INFO - 2019-08-26 08:59:11 --> Router Class Initialized
INFO - 2019-08-26 08:59:11 --> Output Class Initialized
INFO - 2019-08-26 08:59:11 --> Security Class Initialized
DEBUG - 2019-08-26 08:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 08:59:11 --> Input Class Initialized
INFO - 2019-08-26 08:59:11 --> Language Class Initialized
INFO - 2019-08-26 08:59:11 --> Loader Class Initialized
INFO - 2019-08-26 08:59:11 --> Helper loaded: url_helper
INFO - 2019-08-26 08:59:11 --> Helper loaded: html_helper
INFO - 2019-08-26 08:59:11 --> Helper loaded: form_helper
INFO - 2019-08-26 08:59:11 --> Helper loaded: cookie_helper
INFO - 2019-08-26 08:59:11 --> Helper loaded: date_helper
INFO - 2019-08-26 08:59:11 --> Form Validation Class Initialized
INFO - 2019-08-26 08:59:11 --> Email Class Initialized
DEBUG - 2019-08-26 08:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 08:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 08:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 08:59:11 --> Pagination Class Initialized
INFO - 2019-08-26 08:59:11 --> Database Driver Class Initialized
INFO - 2019-08-26 08:59:11 --> Database Driver Class Initialized
INFO - 2019-08-26 08:59:11 --> Controller Class Initialized
INFO - 2019-08-26 08:59:11 --> Final output sent to browser
DEBUG - 2019-08-26 08:59:11 --> Total execution time: 0.8834
INFO - 2019-08-26 09:00:16 --> Config Class Initialized
INFO - 2019-08-26 09:00:16 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:00:16 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:00:16 --> Utf8 Class Initialized
INFO - 2019-08-26 09:00:16 --> URI Class Initialized
INFO - 2019-08-26 09:00:16 --> Router Class Initialized
INFO - 2019-08-26 09:00:16 --> Output Class Initialized
INFO - 2019-08-26 09:00:17 --> Security Class Initialized
DEBUG - 2019-08-26 09:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:00:17 --> Input Class Initialized
INFO - 2019-08-26 09:00:17 --> Language Class Initialized
INFO - 2019-08-26 09:00:17 --> Loader Class Initialized
INFO - 2019-08-26 09:00:17 --> Helper loaded: url_helper
INFO - 2019-08-26 09:00:17 --> Helper loaded: html_helper
INFO - 2019-08-26 09:00:17 --> Helper loaded: form_helper
INFO - 2019-08-26 09:00:17 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:00:17 --> Helper loaded: date_helper
INFO - 2019-08-26 09:00:17 --> Form Validation Class Initialized
INFO - 2019-08-26 09:00:17 --> Email Class Initialized
DEBUG - 2019-08-26 09:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:00:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:00:17 --> Pagination Class Initialized
INFO - 2019-08-26 09:00:17 --> Database Driver Class Initialized
INFO - 2019-08-26 09:00:17 --> Database Driver Class Initialized
INFO - 2019-08-26 09:00:17 --> Controller Class Initialized
INFO - 2019-08-26 09:00:17 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:00:17 --> Final output sent to browser
DEBUG - 2019-08-26 09:00:17 --> Total execution time: 1.2373
INFO - 2019-08-26 09:00:52 --> Config Class Initialized
INFO - 2019-08-26 09:00:52 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:00:52 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:00:52 --> Utf8 Class Initialized
INFO - 2019-08-26 09:00:52 --> URI Class Initialized
INFO - 2019-08-26 09:00:52 --> Router Class Initialized
INFO - 2019-08-26 09:00:52 --> Output Class Initialized
INFO - 2019-08-26 09:00:52 --> Security Class Initialized
DEBUG - 2019-08-26 09:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:00:52 --> Input Class Initialized
INFO - 2019-08-26 09:00:53 --> Language Class Initialized
INFO - 2019-08-26 09:00:53 --> Loader Class Initialized
INFO - 2019-08-26 09:00:53 --> Helper loaded: url_helper
INFO - 2019-08-26 09:00:53 --> Helper loaded: html_helper
INFO - 2019-08-26 09:00:53 --> Helper loaded: form_helper
INFO - 2019-08-26 09:00:53 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:00:53 --> Helper loaded: date_helper
INFO - 2019-08-26 09:00:53 --> Form Validation Class Initialized
INFO - 2019-08-26 09:00:53 --> Email Class Initialized
DEBUG - 2019-08-26 09:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:00:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:00:53 --> Pagination Class Initialized
INFO - 2019-08-26 09:00:53 --> Database Driver Class Initialized
INFO - 2019-08-26 09:00:53 --> Database Driver Class Initialized
INFO - 2019-08-26 09:00:53 --> Controller Class Initialized
INFO - 2019-08-26 09:00:53 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:00:53 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:00:53 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-26 09:00:53 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:00:53 --> Final output sent to browser
DEBUG - 2019-08-26 09:00:53 --> Total execution time: 1.1111
INFO - 2019-08-26 09:00:54 --> Config Class Initialized
INFO - 2019-08-26 09:00:54 --> Config Class Initialized
INFO - 2019-08-26 09:00:54 --> Hooks Class Initialized
INFO - 2019-08-26 09:00:54 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:00:54 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:00:54 --> Utf8 Class Initialized
INFO - 2019-08-26 09:00:54 --> URI Class Initialized
INFO - 2019-08-26 09:00:54 --> Router Class Initialized
INFO - 2019-08-26 09:00:54 --> Output Class Initialized
INFO - 2019-08-26 09:00:54 --> Security Class Initialized
DEBUG - 2019-08-26 09:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:00:54 --> Input Class Initialized
INFO - 2019-08-26 09:00:54 --> Language Class Initialized
DEBUG - 2019-08-26 09:00:54 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:00:54 --> Loader Class Initialized
INFO - 2019-08-26 09:00:54 --> Utf8 Class Initialized
INFO - 2019-08-26 09:00:54 --> Helper loaded: url_helper
INFO - 2019-08-26 09:00:54 --> URI Class Initialized
INFO - 2019-08-26 09:00:54 --> Helper loaded: html_helper
INFO - 2019-08-26 09:00:54 --> Helper loaded: form_helper
INFO - 2019-08-26 09:00:54 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:00:54 --> Helper loaded: date_helper
INFO - 2019-08-26 09:00:55 --> Form Validation Class Initialized
INFO - 2019-08-26 09:00:55 --> Email Class Initialized
INFO - 2019-08-26 09:00:55 --> Router Class Initialized
DEBUG - 2019-08-26 09:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:00:55 --> Output Class Initialized
INFO - 2019-08-26 09:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:00:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:00:55 --> Security Class Initialized
INFO - 2019-08-26 09:00:55 --> Pagination Class Initialized
DEBUG - 2019-08-26 09:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:00:55 --> Input Class Initialized
INFO - 2019-08-26 09:00:55 --> Database Driver Class Initialized
INFO - 2019-08-26 09:00:55 --> Language Class Initialized
INFO - 2019-08-26 09:00:55 --> Database Driver Class Initialized
INFO - 2019-08-26 09:00:55 --> Loader Class Initialized
INFO - 2019-08-26 09:00:55 --> Controller Class Initialized
INFO - 2019-08-26 09:00:55 --> Helper loaded: url_helper
INFO - 2019-08-26 09:00:55 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:00:55 --> Helper loaded: html_helper
INFO - 2019-08-26 09:00:55 --> Final output sent to browser
DEBUG - 2019-08-26 09:00:55 --> Total execution time: 1.4185
INFO - 2019-08-26 09:00:55 --> Helper loaded: form_helper
INFO - 2019-08-26 09:00:55 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:00:55 --> Helper loaded: date_helper
INFO - 2019-08-26 09:00:55 --> Form Validation Class Initialized
INFO - 2019-08-26 09:00:55 --> Email Class Initialized
DEBUG - 2019-08-26 09:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:00:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:00:55 --> Pagination Class Initialized
INFO - 2019-08-26 09:00:55 --> Database Driver Class Initialized
INFO - 2019-08-26 09:00:55 --> Database Driver Class Initialized
INFO - 2019-08-26 09:00:55 --> Controller Class Initialized
INFO - 2019-08-26 09:00:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:00:56 --> Final output sent to browser
DEBUG - 2019-08-26 09:00:56 --> Total execution time: 1.9572
INFO - 2019-08-26 09:01:03 --> Config Class Initialized
INFO - 2019-08-26 09:01:03 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:01:03 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:01:03 --> Utf8 Class Initialized
INFO - 2019-08-26 09:01:03 --> URI Class Initialized
INFO - 2019-08-26 09:01:03 --> Router Class Initialized
INFO - 2019-08-26 09:01:03 --> Output Class Initialized
INFO - 2019-08-26 09:01:03 --> Security Class Initialized
DEBUG - 2019-08-26 09:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:01:03 --> Input Class Initialized
INFO - 2019-08-26 09:01:03 --> Language Class Initialized
INFO - 2019-08-26 09:01:03 --> Loader Class Initialized
INFO - 2019-08-26 09:01:03 --> Helper loaded: url_helper
INFO - 2019-08-26 09:01:04 --> Helper loaded: html_helper
INFO - 2019-08-26 09:01:04 --> Helper loaded: form_helper
INFO - 2019-08-26 09:01:04 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:01:04 --> Helper loaded: date_helper
INFO - 2019-08-26 09:01:04 --> Form Validation Class Initialized
INFO - 2019-08-26 09:01:04 --> Email Class Initialized
DEBUG - 2019-08-26 09:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:01:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:01:04 --> Pagination Class Initialized
INFO - 2019-08-26 09:01:04 --> Database Driver Class Initialized
INFO - 2019-08-26 09:01:04 --> Database Driver Class Initialized
INFO - 2019-08-26 09:01:04 --> Controller Class Initialized
INFO - 2019-08-26 09:01:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:01:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:01:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-26 09:01:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:01:04 --> Final output sent to browser
DEBUG - 2019-08-26 09:01:04 --> Total execution time: 1.0043
INFO - 2019-08-26 09:01:04 --> Config Class Initialized
INFO - 2019-08-26 09:01:04 --> Config Class Initialized
INFO - 2019-08-26 09:01:04 --> Hooks Class Initialized
INFO - 2019-08-26 09:01:04 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:01:05 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:01:05 --> Utf8 Class Initialized
INFO - 2019-08-26 09:01:05 --> URI Class Initialized
INFO - 2019-08-26 09:01:05 --> Router Class Initialized
INFO - 2019-08-26 09:01:05 --> Output Class Initialized
INFO - 2019-08-26 09:01:05 --> Security Class Initialized
DEBUG - 2019-08-26 09:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:01:05 --> Input Class Initialized
INFO - 2019-08-26 09:01:05 --> Language Class Initialized
DEBUG - 2019-08-26 09:01:05 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:01:05 --> Utf8 Class Initialized
INFO - 2019-08-26 09:01:05 --> Loader Class Initialized
INFO - 2019-08-26 09:01:05 --> URI Class Initialized
INFO - 2019-08-26 09:01:05 --> Helper loaded: url_helper
INFO - 2019-08-26 09:01:05 --> Router Class Initialized
INFO - 2019-08-26 09:01:05 --> Helper loaded: html_helper
INFO - 2019-08-26 09:01:05 --> Output Class Initialized
INFO - 2019-08-26 09:01:05 --> Helper loaded: form_helper
INFO - 2019-08-26 09:01:05 --> Security Class Initialized
INFO - 2019-08-26 09:01:05 --> Helper loaded: cookie_helper
DEBUG - 2019-08-26 09:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:01:05 --> Helper loaded: date_helper
INFO - 2019-08-26 09:01:05 --> Input Class Initialized
INFO - 2019-08-26 09:01:05 --> Language Class Initialized
INFO - 2019-08-26 09:01:05 --> Loader Class Initialized
INFO - 2019-08-26 09:01:05 --> Form Validation Class Initialized
INFO - 2019-08-26 09:01:05 --> Helper loaded: url_helper
INFO - 2019-08-26 09:01:06 --> Email Class Initialized
INFO - 2019-08-26 09:01:06 --> Helper loaded: html_helper
DEBUG - 2019-08-26 09:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:01:06 --> Helper loaded: form_helper
INFO - 2019-08-26 09:01:06 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:01:06 --> Helper loaded: date_helper
INFO - 2019-08-26 09:01:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:01:06 --> Form Validation Class Initialized
INFO - 2019-08-26 09:01:06 --> Pagination Class Initialized
INFO - 2019-08-26 09:01:06 --> Email Class Initialized
INFO - 2019-08-26 09:01:06 --> Database Driver Class Initialized
DEBUG - 2019-08-26 09:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:01:06 --> Database Driver Class Initialized
INFO - 2019-08-26 09:01:06 --> Controller Class Initialized
INFO - 2019-08-26 09:01:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:01:06 --> Final output sent to browser
DEBUG - 2019-08-26 09:01:06 --> Total execution time: 1.6269
INFO - 2019-08-26 09:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:01:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:01:06 --> Pagination Class Initialized
INFO - 2019-08-26 09:01:06 --> Database Driver Class Initialized
INFO - 2019-08-26 09:01:06 --> Database Driver Class Initialized
INFO - 2019-08-26 09:01:06 --> Controller Class Initialized
INFO - 2019-08-26 09:01:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:01:06 --> Final output sent to browser
DEBUG - 2019-08-26 09:01:06 --> Total execution time: 1.9618
INFO - 2019-08-26 09:01:12 --> Config Class Initialized
INFO - 2019-08-26 09:01:12 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:01:13 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:01:13 --> Utf8 Class Initialized
INFO - 2019-08-26 09:01:13 --> URI Class Initialized
INFO - 2019-08-26 09:01:13 --> Router Class Initialized
INFO - 2019-08-26 09:01:13 --> Output Class Initialized
INFO - 2019-08-26 09:01:13 --> Security Class Initialized
DEBUG - 2019-08-26 09:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:01:13 --> Input Class Initialized
INFO - 2019-08-26 09:01:13 --> Language Class Initialized
INFO - 2019-08-26 09:01:13 --> Loader Class Initialized
INFO - 2019-08-26 09:01:13 --> Helper loaded: url_helper
INFO - 2019-08-26 09:01:13 --> Helper loaded: html_helper
INFO - 2019-08-26 09:01:13 --> Helper loaded: form_helper
INFO - 2019-08-26 09:01:13 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:01:13 --> Helper loaded: date_helper
INFO - 2019-08-26 09:01:13 --> Form Validation Class Initialized
INFO - 2019-08-26 09:01:13 --> Email Class Initialized
DEBUG - 2019-08-26 09:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:01:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:01:13 --> Pagination Class Initialized
INFO - 2019-08-26 09:01:13 --> Database Driver Class Initialized
INFO - 2019-08-26 09:01:13 --> Database Driver Class Initialized
INFO - 2019-08-26 09:01:13 --> Controller Class Initialized
INFO - 2019-08-26 09:01:13 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:01:14 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:01:14 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-26 09:01:14 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:01:14 --> Final output sent to browser
DEBUG - 2019-08-26 09:01:14 --> Total execution time: 1.1335
INFO - 2019-08-26 09:01:14 --> Config Class Initialized
INFO - 2019-08-26 09:01:14 --> Config Class Initialized
INFO - 2019-08-26 09:01:14 --> Hooks Class Initialized
INFO - 2019-08-26 09:01:14 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:01:14 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:01:14 --> Utf8 Class Initialized
INFO - 2019-08-26 09:01:14 --> URI Class Initialized
DEBUG - 2019-08-26 09:01:14 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:01:14 --> Utf8 Class Initialized
INFO - 2019-08-26 09:01:14 --> URI Class Initialized
INFO - 2019-08-26 09:01:14 --> Router Class Initialized
INFO - 2019-08-26 09:01:14 --> Router Class Initialized
INFO - 2019-08-26 09:01:14 --> Output Class Initialized
INFO - 2019-08-26 09:01:14 --> Security Class Initialized
INFO - 2019-08-26 09:01:14 --> Output Class Initialized
INFO - 2019-08-26 09:01:14 --> Security Class Initialized
DEBUG - 2019-08-26 09:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-26 09:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:01:14 --> Input Class Initialized
INFO - 2019-08-26 09:01:15 --> Input Class Initialized
INFO - 2019-08-26 09:01:15 --> Language Class Initialized
INFO - 2019-08-26 09:01:15 --> Language Class Initialized
INFO - 2019-08-26 09:01:15 --> Loader Class Initialized
INFO - 2019-08-26 09:01:15 --> Loader Class Initialized
INFO - 2019-08-26 09:01:15 --> Helper loaded: url_helper
INFO - 2019-08-26 09:01:15 --> Helper loaded: url_helper
INFO - 2019-08-26 09:01:15 --> Helper loaded: html_helper
INFO - 2019-08-26 09:01:15 --> Helper loaded: html_helper
INFO - 2019-08-26 09:01:15 --> Helper loaded: form_helper
INFO - 2019-08-26 09:01:15 --> Helper loaded: form_helper
INFO - 2019-08-26 09:01:15 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:01:15 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:01:15 --> Helper loaded: date_helper
INFO - 2019-08-26 09:01:15 --> Helper loaded: date_helper
INFO - 2019-08-26 09:01:15 --> Form Validation Class Initialized
INFO - 2019-08-26 09:01:15 --> Form Validation Class Initialized
INFO - 2019-08-26 09:01:15 --> Email Class Initialized
INFO - 2019-08-26 09:01:15 --> Email Class Initialized
DEBUG - 2019-08-26 09:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-26 09:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:01:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:01:15 --> Pagination Class Initialized
INFO - 2019-08-26 09:01:15 --> Database Driver Class Initialized
INFO - 2019-08-26 09:01:15 --> Database Driver Class Initialized
INFO - 2019-08-26 09:01:15 --> Controller Class Initialized
INFO - 2019-08-26 09:01:15 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:01:15 --> Final output sent to browser
DEBUG - 2019-08-26 09:01:15 --> Total execution time: 1.5573
INFO - 2019-08-26 09:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:01:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:01:16 --> Pagination Class Initialized
INFO - 2019-08-26 09:01:16 --> Database Driver Class Initialized
INFO - 2019-08-26 09:01:16 --> Database Driver Class Initialized
INFO - 2019-08-26 09:01:16 --> Controller Class Initialized
INFO - 2019-08-26 09:01:16 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:01:16 --> Final output sent to browser
DEBUG - 2019-08-26 09:01:16 --> Total execution time: 1.9188
INFO - 2019-08-26 09:01:18 --> Config Class Initialized
INFO - 2019-08-26 09:01:18 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:01:18 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:01:18 --> Utf8 Class Initialized
INFO - 2019-08-26 09:01:18 --> URI Class Initialized
INFO - 2019-08-26 09:01:18 --> Router Class Initialized
INFO - 2019-08-26 09:01:18 --> Output Class Initialized
INFO - 2019-08-26 09:01:18 --> Security Class Initialized
DEBUG - 2019-08-26 09:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:01:18 --> Input Class Initialized
INFO - 2019-08-26 09:01:18 --> Language Class Initialized
INFO - 2019-08-26 09:01:18 --> Loader Class Initialized
INFO - 2019-08-26 09:01:18 --> Helper loaded: url_helper
INFO - 2019-08-26 09:01:18 --> Helper loaded: html_helper
INFO - 2019-08-26 09:01:18 --> Helper loaded: form_helper
INFO - 2019-08-26 09:01:18 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:01:18 --> Helper loaded: date_helper
INFO - 2019-08-26 09:01:18 --> Form Validation Class Initialized
INFO - 2019-08-26 09:01:18 --> Email Class Initialized
DEBUG - 2019-08-26 09:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:01:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:01:18 --> Pagination Class Initialized
INFO - 2019-08-26 09:01:18 --> Database Driver Class Initialized
INFO - 2019-08-26 09:01:18 --> Database Driver Class Initialized
INFO - 2019-08-26 09:01:18 --> Controller Class Initialized
INFO - 2019-08-26 09:01:19 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:01:19 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:01:19 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-26 09:01:19 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:01:19 --> Final output sent to browser
DEBUG - 2019-08-26 09:01:19 --> Total execution time: 1.0788
INFO - 2019-08-26 09:01:19 --> Config Class Initialized
INFO - 2019-08-26 09:01:19 --> Config Class Initialized
INFO - 2019-08-26 09:01:19 --> Hooks Class Initialized
INFO - 2019-08-26 09:01:19 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:01:19 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:01:19 --> Utf8 Class Initialized
INFO - 2019-08-26 09:01:19 --> URI Class Initialized
INFO - 2019-08-26 09:01:19 --> Router Class Initialized
DEBUG - 2019-08-26 09:01:19 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:01:19 --> Utf8 Class Initialized
INFO - 2019-08-26 09:01:19 --> Output Class Initialized
INFO - 2019-08-26 09:01:19 --> URI Class Initialized
INFO - 2019-08-26 09:01:19 --> Security Class Initialized
INFO - 2019-08-26 09:01:19 --> Router Class Initialized
DEBUG - 2019-08-26 09:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:01:20 --> Input Class Initialized
INFO - 2019-08-26 09:01:20 --> Output Class Initialized
INFO - 2019-08-26 09:01:20 --> Language Class Initialized
INFO - 2019-08-26 09:01:20 --> Security Class Initialized
INFO - 2019-08-26 09:01:20 --> Loader Class Initialized
DEBUG - 2019-08-26 09:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:01:20 --> Input Class Initialized
INFO - 2019-08-26 09:01:20 --> Helper loaded: url_helper
INFO - 2019-08-26 09:01:20 --> Language Class Initialized
INFO - 2019-08-26 09:01:20 --> Helper loaded: html_helper
INFO - 2019-08-26 09:01:20 --> Loader Class Initialized
INFO - 2019-08-26 09:01:20 --> Helper loaded: form_helper
INFO - 2019-08-26 09:01:20 --> Helper loaded: url_helper
INFO - 2019-08-26 09:01:20 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:01:20 --> Helper loaded: html_helper
INFO - 2019-08-26 09:01:20 --> Helper loaded: date_helper
INFO - 2019-08-26 09:01:20 --> Helper loaded: form_helper
INFO - 2019-08-26 09:01:20 --> Form Validation Class Initialized
INFO - 2019-08-26 09:01:20 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:01:20 --> Email Class Initialized
INFO - 2019-08-26 09:01:20 --> Helper loaded: date_helper
DEBUG - 2019-08-26 09:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:01:20 --> Form Validation Class Initialized
INFO - 2019-08-26 09:01:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:01:20 --> Email Class Initialized
INFO - 2019-08-26 09:01:20 --> Pagination Class Initialized
DEBUG - 2019-08-26 09:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:01:20 --> Database Driver Class Initialized
INFO - 2019-08-26 09:01:20 --> Database Driver Class Initialized
INFO - 2019-08-26 09:01:20 --> Controller Class Initialized
INFO - 2019-08-26 09:01:20 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:01:20 --> Final output sent to browser
DEBUG - 2019-08-26 09:01:21 --> Total execution time: 1.4993
INFO - 2019-08-26 09:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:01:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:01:21 --> Pagination Class Initialized
INFO - 2019-08-26 09:01:21 --> Database Driver Class Initialized
INFO - 2019-08-26 09:01:21 --> Database Driver Class Initialized
INFO - 2019-08-26 09:01:21 --> Controller Class Initialized
INFO - 2019-08-26 09:01:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:01:21 --> Final output sent to browser
DEBUG - 2019-08-26 09:01:21 --> Total execution time: 1.8447
INFO - 2019-08-26 09:03:43 --> Config Class Initialized
INFO - 2019-08-26 09:03:43 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:03:43 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:03:43 --> Utf8 Class Initialized
INFO - 2019-08-26 09:03:43 --> URI Class Initialized
INFO - 2019-08-26 09:03:43 --> Router Class Initialized
INFO - 2019-08-26 09:03:43 --> Output Class Initialized
INFO - 2019-08-26 09:03:43 --> Security Class Initialized
DEBUG - 2019-08-26 09:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:03:43 --> Input Class Initialized
INFO - 2019-08-26 09:03:43 --> Language Class Initialized
INFO - 2019-08-26 09:03:43 --> Loader Class Initialized
INFO - 2019-08-26 09:03:43 --> Helper loaded: url_helper
INFO - 2019-08-26 09:03:43 --> Helper loaded: html_helper
INFO - 2019-08-26 09:03:43 --> Helper loaded: form_helper
INFO - 2019-08-26 09:03:43 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:03:43 --> Helper loaded: date_helper
INFO - 2019-08-26 09:03:43 --> Form Validation Class Initialized
INFO - 2019-08-26 09:03:43 --> Email Class Initialized
DEBUG - 2019-08-26 09:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:03:44 --> Pagination Class Initialized
INFO - 2019-08-26 09:03:44 --> Database Driver Class Initialized
INFO - 2019-08-26 09:03:44 --> Database Driver Class Initialized
INFO - 2019-08-26 09:03:44 --> Controller Class Initialized
INFO - 2019-08-26 09:03:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:03:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:03:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-26 09:03:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:03:44 --> Final output sent to browser
DEBUG - 2019-08-26 09:03:44 --> Total execution time: 1.2473
INFO - 2019-08-26 09:03:44 --> Config Class Initialized
INFO - 2019-08-26 09:03:44 --> Hooks Class Initialized
INFO - 2019-08-26 09:03:44 --> Config Class Initialized
INFO - 2019-08-26 09:03:44 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:03:45 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:03:45 --> Utf8 Class Initialized
INFO - 2019-08-26 09:03:45 --> URI Class Initialized
INFO - 2019-08-26 09:03:45 --> Router Class Initialized
INFO - 2019-08-26 09:03:45 --> Output Class Initialized
INFO - 2019-08-26 09:03:45 --> Security Class Initialized
DEBUG - 2019-08-26 09:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-26 09:03:45 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:03:45 --> Input Class Initialized
INFO - 2019-08-26 09:03:45 --> Utf8 Class Initialized
INFO - 2019-08-26 09:03:45 --> Language Class Initialized
INFO - 2019-08-26 09:03:45 --> URI Class Initialized
INFO - 2019-08-26 09:03:45 --> Loader Class Initialized
INFO - 2019-08-26 09:03:45 --> Router Class Initialized
INFO - 2019-08-26 09:03:45 --> Helper loaded: url_helper
INFO - 2019-08-26 09:03:45 --> Output Class Initialized
INFO - 2019-08-26 09:03:45 --> Helper loaded: html_helper
INFO - 2019-08-26 09:03:45 --> Security Class Initialized
INFO - 2019-08-26 09:03:45 --> Helper loaded: form_helper
DEBUG - 2019-08-26 09:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:03:45 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:03:45 --> Input Class Initialized
INFO - 2019-08-26 09:03:45 --> Language Class Initialized
INFO - 2019-08-26 09:03:45 --> Helper loaded: date_helper
INFO - 2019-08-26 09:03:45 --> Loader Class Initialized
INFO - 2019-08-26 09:03:45 --> Form Validation Class Initialized
INFO - 2019-08-26 09:03:45 --> Helper loaded: url_helper
INFO - 2019-08-26 09:03:45 --> Email Class Initialized
INFO - 2019-08-26 09:03:45 --> Helper loaded: html_helper
DEBUG - 2019-08-26 09:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:03:45 --> Helper loaded: form_helper
INFO - 2019-08-26 09:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:03:46 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:03:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:03:46 --> Helper loaded: date_helper
INFO - 2019-08-26 09:03:46 --> Pagination Class Initialized
INFO - 2019-08-26 09:03:46 --> Form Validation Class Initialized
INFO - 2019-08-26 09:03:46 --> Database Driver Class Initialized
INFO - 2019-08-26 09:03:46 --> Email Class Initialized
DEBUG - 2019-08-26 09:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:03:46 --> Database Driver Class Initialized
INFO - 2019-08-26 09:03:46 --> Controller Class Initialized
INFO - 2019-08-26 09:03:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:03:46 --> Final output sent to browser
DEBUG - 2019-08-26 09:03:46 --> Total execution time: 1.5635
INFO - 2019-08-26 09:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:03:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:03:46 --> Pagination Class Initialized
INFO - 2019-08-26 09:03:46 --> Database Driver Class Initialized
INFO - 2019-08-26 09:03:46 --> Database Driver Class Initialized
INFO - 2019-08-26 09:03:46 --> Controller Class Initialized
INFO - 2019-08-26 09:03:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:03:46 --> Final output sent to browser
DEBUG - 2019-08-26 09:03:46 --> Total execution time: 1.8758
INFO - 2019-08-26 09:03:57 --> Config Class Initialized
INFO - 2019-08-26 09:03:57 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:03:57 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:03:57 --> Utf8 Class Initialized
INFO - 2019-08-26 09:03:57 --> URI Class Initialized
INFO - 2019-08-26 09:03:57 --> Router Class Initialized
INFO - 2019-08-26 09:03:57 --> Output Class Initialized
INFO - 2019-08-26 09:03:57 --> Security Class Initialized
DEBUG - 2019-08-26 09:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:03:57 --> Input Class Initialized
INFO - 2019-08-26 09:03:57 --> Language Class Initialized
INFO - 2019-08-26 09:03:57 --> Loader Class Initialized
INFO - 2019-08-26 09:03:57 --> Helper loaded: url_helper
INFO - 2019-08-26 09:03:57 --> Helper loaded: html_helper
INFO - 2019-08-26 09:03:57 --> Helper loaded: form_helper
INFO - 2019-08-26 09:03:57 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:03:57 --> Helper loaded: date_helper
INFO - 2019-08-26 09:03:57 --> Form Validation Class Initialized
INFO - 2019-08-26 09:03:58 --> Email Class Initialized
DEBUG - 2019-08-26 09:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:03:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:03:58 --> Pagination Class Initialized
INFO - 2019-08-26 09:03:58 --> Database Driver Class Initialized
INFO - 2019-08-26 09:03:58 --> Database Driver Class Initialized
INFO - 2019-08-26 09:03:58 --> Controller Class Initialized
INFO - 2019-08-26 09:03:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:03:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:03:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-26 09:03:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:03:58 --> Final output sent to browser
DEBUG - 2019-08-26 09:03:58 --> Total execution time: 1.0689
INFO - 2019-08-26 09:03:58 --> Config Class Initialized
INFO - 2019-08-26 09:03:58 --> Hooks Class Initialized
INFO - 2019-08-26 09:03:58 --> Config Class Initialized
INFO - 2019-08-26 09:03:58 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:03:58 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:03:58 --> Utf8 Class Initialized
INFO - 2019-08-26 09:03:59 --> URI Class Initialized
INFO - 2019-08-26 09:03:59 --> Router Class Initialized
INFO - 2019-08-26 09:03:59 --> Output Class Initialized
INFO - 2019-08-26 09:03:59 --> Security Class Initialized
DEBUG - 2019-08-26 09:03:59 --> UTF-8 Support Enabled
DEBUG - 2019-08-26 09:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:03:59 --> Utf8 Class Initialized
INFO - 2019-08-26 09:03:59 --> Input Class Initialized
INFO - 2019-08-26 09:03:59 --> URI Class Initialized
INFO - 2019-08-26 09:03:59 --> Language Class Initialized
INFO - 2019-08-26 09:03:59 --> Router Class Initialized
INFO - 2019-08-26 09:03:59 --> Output Class Initialized
INFO - 2019-08-26 09:03:59 --> Security Class Initialized
DEBUG - 2019-08-26 09:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:03:59 --> Input Class Initialized
INFO - 2019-08-26 09:03:59 --> Language Class Initialized
INFO - 2019-08-26 09:03:59 --> Loader Class Initialized
INFO - 2019-08-26 09:03:59 --> Helper loaded: url_helper
INFO - 2019-08-26 09:03:59 --> Helper loaded: html_helper
INFO - 2019-08-26 09:03:59 --> Helper loaded: form_helper
INFO - 2019-08-26 09:03:59 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:04:00 --> Helper loaded: date_helper
INFO - 2019-08-26 09:04:00 --> Form Validation Class Initialized
INFO - 2019-08-26 09:04:00 --> Email Class Initialized
INFO - 2019-08-26 09:04:00 --> Loader Class Initialized
DEBUG - 2019-08-26 09:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:04:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:04:00 --> Pagination Class Initialized
INFO - 2019-08-26 09:04:00 --> Helper loaded: url_helper
INFO - 2019-08-26 09:04:00 --> Helper loaded: html_helper
INFO - 2019-08-26 09:04:00 --> Helper loaded: form_helper
INFO - 2019-08-26 09:04:00 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:04:00 --> Helper loaded: date_helper
INFO - 2019-08-26 09:04:00 --> Form Validation Class Initialized
INFO - 2019-08-26 09:04:00 --> Email Class Initialized
INFO - 2019-08-26 09:04:00 --> Database Driver Class Initialized
DEBUG - 2019-08-26 09:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:04:00 --> Database Driver Class Initialized
INFO - 2019-08-26 09:04:00 --> Controller Class Initialized
INFO - 2019-08-26 09:04:00 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:04:00 --> Final output sent to browser
DEBUG - 2019-08-26 09:04:00 --> Total execution time: 1.9179
INFO - 2019-08-26 09:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:04:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:04:00 --> Pagination Class Initialized
INFO - 2019-08-26 09:04:00 --> Database Driver Class Initialized
INFO - 2019-08-26 09:04:00 --> Database Driver Class Initialized
INFO - 2019-08-26 09:04:00 --> Controller Class Initialized
INFO - 2019-08-26 09:04:00 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:04:00 --> Final output sent to browser
DEBUG - 2019-08-26 09:04:01 --> Total execution time: 2.2537
INFO - 2019-08-26 09:05:07 --> Config Class Initialized
INFO - 2019-08-26 09:05:07 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:05:07 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:05:07 --> Utf8 Class Initialized
INFO - 2019-08-26 09:05:07 --> URI Class Initialized
INFO - 2019-08-26 09:05:07 --> Router Class Initialized
INFO - 2019-08-26 09:05:07 --> Output Class Initialized
INFO - 2019-08-26 09:05:07 --> Security Class Initialized
DEBUG - 2019-08-26 09:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:05:07 --> Input Class Initialized
INFO - 2019-08-26 09:05:07 --> Language Class Initialized
INFO - 2019-08-26 09:05:07 --> Loader Class Initialized
INFO - 2019-08-26 09:05:07 --> Helper loaded: url_helper
INFO - 2019-08-26 09:05:07 --> Helper loaded: html_helper
INFO - 2019-08-26 09:05:07 --> Helper loaded: form_helper
INFO - 2019-08-26 09:05:07 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:05:07 --> Helper loaded: date_helper
INFO - 2019-08-26 09:05:07 --> Form Validation Class Initialized
INFO - 2019-08-26 09:05:07 --> Email Class Initialized
DEBUG - 2019-08-26 09:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:05:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:05:08 --> Pagination Class Initialized
INFO - 2019-08-26 09:05:08 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:08 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:08 --> Controller Class Initialized
INFO - 2019-08-26 09:05:08 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:05:08 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:05:08 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-26 09:05:08 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:05:08 --> Final output sent to browser
DEBUG - 2019-08-26 09:05:08 --> Total execution time: 1.0465
INFO - 2019-08-26 09:05:08 --> Config Class Initialized
INFO - 2019-08-26 09:05:08 --> Config Class Initialized
INFO - 2019-08-26 09:05:08 --> Hooks Class Initialized
INFO - 2019-08-26 09:05:08 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:05:08 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:05:08 --> Utf8 Class Initialized
INFO - 2019-08-26 09:05:08 --> URI Class Initialized
INFO - 2019-08-26 09:05:08 --> Router Class Initialized
INFO - 2019-08-26 09:05:09 --> Output Class Initialized
INFO - 2019-08-26 09:05:09 --> Security Class Initialized
DEBUG - 2019-08-26 09:05:09 --> UTF-8 Support Enabled
DEBUG - 2019-08-26 09:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:05:09 --> Utf8 Class Initialized
INFO - 2019-08-26 09:05:09 --> Input Class Initialized
INFO - 2019-08-26 09:05:09 --> URI Class Initialized
INFO - 2019-08-26 09:05:09 --> Language Class Initialized
INFO - 2019-08-26 09:05:09 --> Router Class Initialized
INFO - 2019-08-26 09:05:09 --> Loader Class Initialized
INFO - 2019-08-26 09:05:09 --> Output Class Initialized
INFO - 2019-08-26 09:05:09 --> Security Class Initialized
DEBUG - 2019-08-26 09:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:05:09 --> Input Class Initialized
INFO - 2019-08-26 09:05:09 --> Language Class Initialized
INFO - 2019-08-26 09:05:09 --> Helper loaded: url_helper
INFO - 2019-08-26 09:05:09 --> Helper loaded: html_helper
INFO - 2019-08-26 09:05:09 --> Loader Class Initialized
INFO - 2019-08-26 09:05:09 --> Helper loaded: form_helper
INFO - 2019-08-26 09:05:09 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:05:09 --> Helper loaded: date_helper
INFO - 2019-08-26 09:05:09 --> Form Validation Class Initialized
INFO - 2019-08-26 09:05:09 --> Email Class Initialized
INFO - 2019-08-26 09:05:09 --> Helper loaded: url_helper
DEBUG - 2019-08-26 09:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:05:09 --> Helper loaded: html_helper
INFO - 2019-08-26 09:05:10 --> Helper loaded: form_helper
INFO - 2019-08-26 09:05:10 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:05:10 --> Helper loaded: date_helper
INFO - 2019-08-26 09:05:10 --> Form Validation Class Initialized
INFO - 2019-08-26 09:05:10 --> Email Class Initialized
DEBUG - 2019-08-26 09:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:05:10 --> Pagination Class Initialized
INFO - 2019-08-26 09:05:10 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:10 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:10 --> Controller Class Initialized
INFO - 2019-08-26 09:05:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:05:10 --> Final output sent to browser
DEBUG - 2019-08-26 09:05:10 --> Total execution time: 1.7656
INFO - 2019-08-26 09:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:05:10 --> Pagination Class Initialized
INFO - 2019-08-26 09:05:10 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:10 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:10 --> Controller Class Initialized
INFO - 2019-08-26 09:05:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:05:10 --> Final output sent to browser
DEBUG - 2019-08-26 09:05:10 --> Total execution time: 2.1449
INFO - 2019-08-26 09:05:16 --> Config Class Initialized
INFO - 2019-08-26 09:05:16 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:05:16 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:05:16 --> Utf8 Class Initialized
INFO - 2019-08-26 09:05:16 --> URI Class Initialized
INFO - 2019-08-26 09:05:16 --> Router Class Initialized
INFO - 2019-08-26 09:05:16 --> Output Class Initialized
INFO - 2019-08-26 09:05:16 --> Security Class Initialized
DEBUG - 2019-08-26 09:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:05:16 --> Input Class Initialized
INFO - 2019-08-26 09:05:16 --> Language Class Initialized
INFO - 2019-08-26 09:05:16 --> Loader Class Initialized
INFO - 2019-08-26 09:05:16 --> Helper loaded: url_helper
INFO - 2019-08-26 09:05:17 --> Helper loaded: html_helper
INFO - 2019-08-26 09:05:17 --> Helper loaded: form_helper
INFO - 2019-08-26 09:05:17 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:05:17 --> Helper loaded: date_helper
INFO - 2019-08-26 09:05:17 --> Form Validation Class Initialized
INFO - 2019-08-26 09:05:17 --> Email Class Initialized
DEBUG - 2019-08-26 09:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:05:17 --> Pagination Class Initialized
INFO - 2019-08-26 09:05:17 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:17 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:17 --> Controller Class Initialized
INFO - 2019-08-26 09:05:17 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:05:17 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:05:17 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-26 09:05:17 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:05:17 --> Final output sent to browser
DEBUG - 2019-08-26 09:05:17 --> Total execution time: 1.1044
INFO - 2019-08-26 09:05:17 --> Config Class Initialized
INFO - 2019-08-26 09:05:18 --> Config Class Initialized
INFO - 2019-08-26 09:05:18 --> Hooks Class Initialized
INFO - 2019-08-26 09:05:18 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:05:18 --> UTF-8 Support Enabled
DEBUG - 2019-08-26 09:05:18 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:05:18 --> Utf8 Class Initialized
INFO - 2019-08-26 09:05:18 --> URI Class Initialized
INFO - 2019-08-26 09:05:18 --> Router Class Initialized
INFO - 2019-08-26 09:05:18 --> Utf8 Class Initialized
INFO - 2019-08-26 09:05:18 --> URI Class Initialized
INFO - 2019-08-26 09:05:18 --> Output Class Initialized
INFO - 2019-08-26 09:05:18 --> Security Class Initialized
DEBUG - 2019-08-26 09:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:05:18 --> Input Class Initialized
INFO - 2019-08-26 09:05:18 --> Language Class Initialized
INFO - 2019-08-26 09:05:18 --> Loader Class Initialized
INFO - 2019-08-26 09:05:18 --> Router Class Initialized
INFO - 2019-08-26 09:05:18 --> Helper loaded: url_helper
INFO - 2019-08-26 09:05:18 --> Output Class Initialized
INFO - 2019-08-26 09:05:18 --> Security Class Initialized
INFO - 2019-08-26 09:05:18 --> Helper loaded: html_helper
INFO - 2019-08-26 09:05:19 --> Helper loaded: form_helper
INFO - 2019-08-26 09:05:19 --> Helper loaded: cookie_helper
DEBUG - 2019-08-26 09:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:05:19 --> Helper loaded: date_helper
INFO - 2019-08-26 09:05:19 --> Form Validation Class Initialized
INFO - 2019-08-26 09:05:19 --> Email Class Initialized
DEBUG - 2019-08-26 09:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:05:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:05:19 --> Pagination Class Initialized
INFO - 2019-08-26 09:05:19 --> Input Class Initialized
INFO - 2019-08-26 09:05:19 --> Language Class Initialized
INFO - 2019-08-26 09:05:19 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:19 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:19 --> Loader Class Initialized
INFO - 2019-08-26 09:05:19 --> Controller Class Initialized
INFO - 2019-08-26 09:05:19 --> Helper loaded: url_helper
INFO - 2019-08-26 09:05:19 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:05:19 --> Final output sent to browser
DEBUG - 2019-08-26 09:05:19 --> Total execution time: 1.7931
INFO - 2019-08-26 09:05:19 --> Helper loaded: html_helper
INFO - 2019-08-26 09:05:19 --> Helper loaded: form_helper
INFO - 2019-08-26 09:05:19 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:05:19 --> Helper loaded: date_helper
INFO - 2019-08-26 09:05:19 --> Form Validation Class Initialized
INFO - 2019-08-26 09:05:20 --> Email Class Initialized
DEBUG - 2019-08-26 09:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:05:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:05:20 --> Pagination Class Initialized
INFO - 2019-08-26 09:05:20 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:20 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:20 --> Controller Class Initialized
INFO - 2019-08-26 09:05:20 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:05:20 --> Final output sent to browser
DEBUG - 2019-08-26 09:05:20 --> Total execution time: 2.4237
INFO - 2019-08-26 09:05:26 --> Config Class Initialized
INFO - 2019-08-26 09:05:26 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:05:26 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:05:26 --> Utf8 Class Initialized
INFO - 2019-08-26 09:05:26 --> URI Class Initialized
INFO - 2019-08-26 09:05:26 --> Router Class Initialized
INFO - 2019-08-26 09:05:26 --> Output Class Initialized
INFO - 2019-08-26 09:05:26 --> Security Class Initialized
DEBUG - 2019-08-26 09:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:05:26 --> Input Class Initialized
INFO - 2019-08-26 09:05:26 --> Language Class Initialized
INFO - 2019-08-26 09:05:26 --> Loader Class Initialized
INFO - 2019-08-26 09:05:26 --> Helper loaded: url_helper
INFO - 2019-08-26 09:05:26 --> Helper loaded: html_helper
INFO - 2019-08-26 09:05:26 --> Helper loaded: form_helper
INFO - 2019-08-26 09:05:26 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:05:26 --> Helper loaded: date_helper
INFO - 2019-08-26 09:05:26 --> Form Validation Class Initialized
INFO - 2019-08-26 09:05:26 --> Email Class Initialized
DEBUG - 2019-08-26 09:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:05:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:05:26 --> Pagination Class Initialized
INFO - 2019-08-26 09:05:26 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:26 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:26 --> Controller Class Initialized
INFO - 2019-08-26 09:05:26 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:05:26 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:05:26 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/guest.php
INFO - 2019-08-26 09:05:27 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:05:27 --> Final output sent to browser
DEBUG - 2019-08-26 09:05:27 --> Total execution time: 1.0076
INFO - 2019-08-26 09:05:27 --> Config Class Initialized
INFO - 2019-08-26 09:05:27 --> Config Class Initialized
INFO - 2019-08-26 09:05:27 --> Hooks Class Initialized
INFO - 2019-08-26 09:05:27 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:05:27 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:05:27 --> Utf8 Class Initialized
INFO - 2019-08-26 09:05:27 --> URI Class Initialized
INFO - 2019-08-26 09:05:27 --> Router Class Initialized
INFO - 2019-08-26 09:05:27 --> Output Class Initialized
INFO - 2019-08-26 09:05:27 --> Security Class Initialized
DEBUG - 2019-08-26 09:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:05:27 --> Input Class Initialized
DEBUG - 2019-08-26 09:05:27 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:05:27 --> Utf8 Class Initialized
INFO - 2019-08-26 09:05:27 --> URI Class Initialized
INFO - 2019-08-26 09:05:27 --> Router Class Initialized
INFO - 2019-08-26 09:05:27 --> Language Class Initialized
INFO - 2019-08-26 09:05:27 --> Output Class Initialized
INFO - 2019-08-26 09:05:28 --> Loader Class Initialized
INFO - 2019-08-26 09:05:28 --> Security Class Initialized
INFO - 2019-08-26 09:05:28 --> Helper loaded: url_helper
DEBUG - 2019-08-26 09:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:05:28 --> Input Class Initialized
INFO - 2019-08-26 09:05:28 --> Helper loaded: html_helper
INFO - 2019-08-26 09:05:28 --> Language Class Initialized
INFO - 2019-08-26 09:05:28 --> Helper loaded: form_helper
INFO - 2019-08-26 09:05:28 --> Loader Class Initialized
INFO - 2019-08-26 09:05:28 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:05:28 --> Helper loaded: url_helper
INFO - 2019-08-26 09:05:28 --> Helper loaded: html_helper
INFO - 2019-08-26 09:05:28 --> Helper loaded: date_helper
INFO - 2019-08-26 09:05:28 --> Helper loaded: form_helper
INFO - 2019-08-26 09:05:28 --> Form Validation Class Initialized
INFO - 2019-08-26 09:05:28 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:05:28 --> Helper loaded: date_helper
INFO - 2019-08-26 09:05:28 --> Email Class Initialized
DEBUG - 2019-08-26 09:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:05:28 --> Form Validation Class Initialized
INFO - 2019-08-26 09:05:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:05:28 --> Pagination Class Initialized
INFO - 2019-08-26 09:05:28 --> Email Class Initialized
DEBUG - 2019-08-26 09:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:05:28 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:28 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:28 --> Controller Class Initialized
INFO - 2019-08-26 09:05:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:05:29 --> Final output sent to browser
DEBUG - 2019-08-26 09:05:29 --> Total execution time: 1.7533
INFO - 2019-08-26 09:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:05:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:05:29 --> Pagination Class Initialized
INFO - 2019-08-26 09:05:29 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:29 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:29 --> Controller Class Initialized
INFO - 2019-08-26 09:05:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:05:29 --> Final output sent to browser
DEBUG - 2019-08-26 09:05:29 --> Total execution time: 2.0921
INFO - 2019-08-26 09:05:36 --> Config Class Initialized
INFO - 2019-08-26 09:05:36 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:05:36 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:05:36 --> Utf8 Class Initialized
INFO - 2019-08-26 09:05:36 --> URI Class Initialized
INFO - 2019-08-26 09:05:36 --> Router Class Initialized
INFO - 2019-08-26 09:05:36 --> Output Class Initialized
INFO - 2019-08-26 09:05:36 --> Security Class Initialized
DEBUG - 2019-08-26 09:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:05:36 --> Input Class Initialized
INFO - 2019-08-26 09:05:36 --> Language Class Initialized
INFO - 2019-08-26 09:05:36 --> Loader Class Initialized
INFO - 2019-08-26 09:05:36 --> Helper loaded: url_helper
INFO - 2019-08-26 09:05:36 --> Helper loaded: html_helper
INFO - 2019-08-26 09:05:36 --> Helper loaded: form_helper
INFO - 2019-08-26 09:05:36 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:05:36 --> Helper loaded: date_helper
INFO - 2019-08-26 09:05:37 --> Form Validation Class Initialized
INFO - 2019-08-26 09:05:37 --> Email Class Initialized
DEBUG - 2019-08-26 09:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:05:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:05:37 --> Pagination Class Initialized
INFO - 2019-08-26 09:05:37 --> Config Class Initialized
INFO - 2019-08-26 09:05:37 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:37 --> Hooks Class Initialized
INFO - 2019-08-26 09:05:37 --> Database Driver Class Initialized
DEBUG - 2019-08-26 09:05:37 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:05:37 --> Controller Class Initialized
INFO - 2019-08-26 09:05:37 --> Utf8 Class Initialized
INFO - 2019-08-26 09:05:37 --> URI Class Initialized
INFO - 2019-08-26 09:05:37 --> Router Class Initialized
INFO - 2019-08-26 09:05:37 --> Output Class Initialized
INFO - 2019-08-26 09:05:37 --> Security Class Initialized
ERROR - 2019-08-26 09:05:37 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
DEBUG - 2019-08-26 09:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:05:37 --> Input Class Initialized
INFO - 2019-08-26 09:05:37 --> Language Class Initialized
INFO - 2019-08-26 09:05:37 --> Loader Class Initialized
INFO - 2019-08-26 09:05:37 --> Helper loaded: url_helper
INFO - 2019-08-26 09:05:37 --> Helper loaded: html_helper
INFO - 2019-08-26 09:05:37 --> Helper loaded: form_helper
INFO - 2019-08-26 09:05:37 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:05:37 --> Helper loaded: date_helper
INFO - 2019-08-26 09:05:37 --> Form Validation Class Initialized
INFO - 2019-08-26 09:05:37 --> Email Class Initialized
DEBUG - 2019-08-26 09:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:05:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:05:37 --> Pagination Class Initialized
INFO - 2019-08-26 09:05:37 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:37 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:37 --> Controller Class Initialized
ERROR - 2019-08-26 09:05:37 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-26 09:05:37 --> Config Class Initialized
INFO - 2019-08-26 09:05:38 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:05:38 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:05:38 --> Utf8 Class Initialized
INFO - 2019-08-26 09:05:38 --> URI Class Initialized
INFO - 2019-08-26 09:05:38 --> Router Class Initialized
INFO - 2019-08-26 09:05:38 --> Output Class Initialized
INFO - 2019-08-26 09:05:38 --> Security Class Initialized
DEBUG - 2019-08-26 09:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:05:38 --> Input Class Initialized
INFO - 2019-08-26 09:05:38 --> Language Class Initialized
INFO - 2019-08-26 09:05:38 --> Loader Class Initialized
INFO - 2019-08-26 09:05:38 --> Helper loaded: url_helper
INFO - 2019-08-26 09:05:38 --> Helper loaded: html_helper
INFO - 2019-08-26 09:05:38 --> Helper loaded: form_helper
INFO - 2019-08-26 09:05:38 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:05:38 --> Helper loaded: date_helper
INFO - 2019-08-26 09:05:38 --> Form Validation Class Initialized
INFO - 2019-08-26 09:05:38 --> Email Class Initialized
DEBUG - 2019-08-26 09:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:05:38 --> Config Class Initialized
INFO - 2019-08-26 09:05:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:05:38 --> Hooks Class Initialized
INFO - 2019-08-26 09:05:38 --> Pagination Class Initialized
DEBUG - 2019-08-26 09:05:38 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:05:38 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:38 --> Utf8 Class Initialized
INFO - 2019-08-26 09:05:38 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:38 --> URI Class Initialized
INFO - 2019-08-26 09:05:38 --> Controller Class Initialized
INFO - 2019-08-26 09:05:38 --> Router Class Initialized
INFO - 2019-08-26 09:05:38 --> Output Class Initialized
ERROR - 2019-08-26 09:05:38 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-26 09:05:38 --> Security Class Initialized
DEBUG - 2019-08-26 09:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:05:38 --> Input Class Initialized
INFO - 2019-08-26 09:05:38 --> Config Class Initialized
INFO - 2019-08-26 09:05:38 --> Language Class Initialized
INFO - 2019-08-26 09:05:38 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:05:38 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:05:38 --> Loader Class Initialized
INFO - 2019-08-26 09:05:38 --> Utf8 Class Initialized
INFO - 2019-08-26 09:05:38 --> URI Class Initialized
INFO - 2019-08-26 09:05:38 --> Helper loaded: url_helper
INFO - 2019-08-26 09:05:39 --> Router Class Initialized
INFO - 2019-08-26 09:05:39 --> Output Class Initialized
INFO - 2019-08-26 09:05:39 --> Helper loaded: html_helper
INFO - 2019-08-26 09:05:39 --> Security Class Initialized
INFO - 2019-08-26 09:05:39 --> Helper loaded: form_helper
DEBUG - 2019-08-26 09:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:05:39 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:05:39 --> Input Class Initialized
INFO - 2019-08-26 09:05:39 --> Helper loaded: date_helper
INFO - 2019-08-26 09:05:39 --> Language Class Initialized
INFO - 2019-08-26 09:05:39 --> Form Validation Class Initialized
INFO - 2019-08-26 09:05:39 --> Loader Class Initialized
INFO - 2019-08-26 09:05:39 --> Config Class Initialized
INFO - 2019-08-26 09:05:39 --> Email Class Initialized
INFO - 2019-08-26 09:05:39 --> Hooks Class Initialized
INFO - 2019-08-26 09:05:39 --> Helper loaded: url_helper
DEBUG - 2019-08-26 09:05:39 --> UTF-8 Support Enabled
DEBUG - 2019-08-26 09:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:05:39 --> Helper loaded: html_helper
INFO - 2019-08-26 09:05:39 --> Utf8 Class Initialized
INFO - 2019-08-26 09:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:05:39 --> URI Class Initialized
INFO - 2019-08-26 09:05:39 --> Helper loaded: form_helper
INFO - 2019-08-26 09:05:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:05:39 --> Router Class Initialized
INFO - 2019-08-26 09:05:39 --> Pagination Class Initialized
INFO - 2019-08-26 09:05:39 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:05:39 --> Output Class Initialized
INFO - 2019-08-26 09:05:39 --> Helper loaded: date_helper
INFO - 2019-08-26 09:05:39 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:39 --> Security Class Initialized
INFO - 2019-08-26 09:05:39 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:39 --> Form Validation Class Initialized
INFO - 2019-08-26 09:05:39 --> Controller Class Initialized
DEBUG - 2019-08-26 09:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:05:39 --> Email Class Initialized
INFO - 2019-08-26 09:05:39 --> Input Class Initialized
ERROR - 2019-08-26 09:05:39 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-26 09:05:39 --> Language Class Initialized
DEBUG - 2019-08-26 09:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:05:39 --> Loader Class Initialized
INFO - 2019-08-26 09:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:05:39 --> Helper loaded: url_helper
INFO - 2019-08-26 09:05:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:05:39 --> Helper loaded: html_helper
INFO - 2019-08-26 09:05:39 --> Pagination Class Initialized
INFO - 2019-08-26 09:05:39 --> Helper loaded: form_helper
INFO - 2019-08-26 09:05:39 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:39 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:05:39 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:39 --> Helper loaded: date_helper
INFO - 2019-08-26 09:05:39 --> Controller Class Initialized
INFO - 2019-08-26 09:05:39 --> Form Validation Class Initialized
INFO - 2019-08-26 09:05:40 --> Email Class Initialized
ERROR - 2019-08-26 09:05:40 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
DEBUG - 2019-08-26 09:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:05:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:05:40 --> Pagination Class Initialized
INFO - 2019-08-26 09:05:40 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:40 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:40 --> Controller Class Initialized
ERROR - 2019-08-26 09:05:40 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-26 09:05:45 --> Config Class Initialized
INFO - 2019-08-26 09:05:45 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:05:45 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:05:45 --> Utf8 Class Initialized
INFO - 2019-08-26 09:05:45 --> URI Class Initialized
INFO - 2019-08-26 09:05:45 --> Router Class Initialized
INFO - 2019-08-26 09:05:45 --> Output Class Initialized
INFO - 2019-08-26 09:05:45 --> Security Class Initialized
DEBUG - 2019-08-26 09:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:05:45 --> Input Class Initialized
INFO - 2019-08-26 09:05:45 --> Language Class Initialized
INFO - 2019-08-26 09:05:45 --> Loader Class Initialized
INFO - 2019-08-26 09:05:45 --> Helper loaded: url_helper
INFO - 2019-08-26 09:05:45 --> Helper loaded: html_helper
INFO - 2019-08-26 09:05:45 --> Helper loaded: form_helper
INFO - 2019-08-26 09:05:46 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:05:46 --> Helper loaded: date_helper
INFO - 2019-08-26 09:05:46 --> Form Validation Class Initialized
INFO - 2019-08-26 09:05:46 --> Email Class Initialized
DEBUG - 2019-08-26 09:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:05:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:05:46 --> Pagination Class Initialized
INFO - 2019-08-26 09:05:46 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:46 --> Database Driver Class Initialized
INFO - 2019-08-26 09:05:46 --> Controller Class Initialized
INFO - 2019-08-26 09:05:46 --> Final output sent to browser
DEBUG - 2019-08-26 09:05:46 --> Total execution time: 0.6791
INFO - 2019-08-26 09:06:10 --> Config Class Initialized
INFO - 2019-08-26 09:06:10 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:06:10 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:06:10 --> Utf8 Class Initialized
INFO - 2019-08-26 09:06:10 --> URI Class Initialized
INFO - 2019-08-26 09:06:10 --> Router Class Initialized
INFO - 2019-08-26 09:06:10 --> Output Class Initialized
INFO - 2019-08-26 09:06:10 --> Security Class Initialized
DEBUG - 2019-08-26 09:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:06:10 --> Input Class Initialized
INFO - 2019-08-26 09:06:10 --> Language Class Initialized
INFO - 2019-08-26 09:06:10 --> Loader Class Initialized
INFO - 2019-08-26 09:06:10 --> Helper loaded: url_helper
INFO - 2019-08-26 09:06:10 --> Helper loaded: html_helper
INFO - 2019-08-26 09:06:10 --> Helper loaded: form_helper
INFO - 2019-08-26 09:06:10 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:06:10 --> Helper loaded: date_helper
INFO - 2019-08-26 09:06:10 --> Form Validation Class Initialized
INFO - 2019-08-26 09:06:10 --> Email Class Initialized
DEBUG - 2019-08-26 09:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:06:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:06:10 --> Pagination Class Initialized
INFO - 2019-08-26 09:06:11 --> Database Driver Class Initialized
INFO - 2019-08-26 09:06:11 --> Database Driver Class Initialized
INFO - 2019-08-26 09:06:11 --> Controller Class Initialized
INFO - 2019-08-26 09:06:11 --> Final output sent to browser
DEBUG - 2019-08-26 09:06:11 --> Total execution time: 0.6629
INFO - 2019-08-26 09:06:33 --> Config Class Initialized
INFO - 2019-08-26 09:06:33 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:06:33 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:06:33 --> Utf8 Class Initialized
INFO - 2019-08-26 09:06:33 --> URI Class Initialized
INFO - 2019-08-26 09:06:33 --> Router Class Initialized
INFO - 2019-08-26 09:06:33 --> Output Class Initialized
INFO - 2019-08-26 09:06:33 --> Security Class Initialized
DEBUG - 2019-08-26 09:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:06:33 --> Input Class Initialized
INFO - 2019-08-26 09:06:33 --> Language Class Initialized
INFO - 2019-08-26 09:06:33 --> Loader Class Initialized
INFO - 2019-08-26 09:06:33 --> Helper loaded: url_helper
INFO - 2019-08-26 09:06:33 --> Helper loaded: html_helper
INFO - 2019-08-26 09:06:33 --> Helper loaded: form_helper
INFO - 2019-08-26 09:06:33 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:06:33 --> Helper loaded: date_helper
INFO - 2019-08-26 09:06:33 --> Form Validation Class Initialized
INFO - 2019-08-26 09:06:33 --> Email Class Initialized
DEBUG - 2019-08-26 09:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:06:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:06:33 --> Pagination Class Initialized
INFO - 2019-08-26 09:06:33 --> Database Driver Class Initialized
INFO - 2019-08-26 09:06:33 --> Database Driver Class Initialized
INFO - 2019-08-26 09:06:33 --> Controller Class Initialized
INFO - 2019-08-26 09:06:34 --> Final output sent to browser
DEBUG - 2019-08-26 09:06:34 --> Total execution time: 0.6878
INFO - 2019-08-26 09:07:17 --> Config Class Initialized
INFO - 2019-08-26 09:07:17 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:07:17 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:07:17 --> Utf8 Class Initialized
INFO - 2019-08-26 09:07:17 --> URI Class Initialized
INFO - 2019-08-26 09:07:17 --> Router Class Initialized
INFO - 2019-08-26 09:07:17 --> Output Class Initialized
INFO - 2019-08-26 09:07:17 --> Security Class Initialized
DEBUG - 2019-08-26 09:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:07:17 --> Input Class Initialized
INFO - 2019-08-26 09:07:17 --> Language Class Initialized
INFO - 2019-08-26 09:07:17 --> Loader Class Initialized
INFO - 2019-08-26 09:07:17 --> Helper loaded: url_helper
INFO - 2019-08-26 09:07:17 --> Helper loaded: html_helper
INFO - 2019-08-26 09:07:17 --> Helper loaded: form_helper
INFO - 2019-08-26 09:07:17 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:07:17 --> Helper loaded: date_helper
INFO - 2019-08-26 09:07:17 --> Form Validation Class Initialized
INFO - 2019-08-26 09:07:17 --> Email Class Initialized
DEBUG - 2019-08-26 09:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:07:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:07:17 --> Pagination Class Initialized
INFO - 2019-08-26 09:07:17 --> Database Driver Class Initialized
INFO - 2019-08-26 09:07:17 --> Database Driver Class Initialized
INFO - 2019-08-26 09:07:17 --> Controller Class Initialized
INFO - 2019-08-26 09:07:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 09:07:17 --> Config Class Initialized
INFO - 2019-08-26 09:07:18 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:07:18 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:07:18 --> Utf8 Class Initialized
INFO - 2019-08-26 09:07:18 --> URI Class Initialized
INFO - 2019-08-26 09:07:18 --> Router Class Initialized
INFO - 2019-08-26 09:07:18 --> Output Class Initialized
INFO - 2019-08-26 09:07:18 --> Security Class Initialized
DEBUG - 2019-08-26 09:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:07:18 --> Input Class Initialized
INFO - 2019-08-26 09:07:18 --> Language Class Initialized
INFO - 2019-08-26 09:07:18 --> Loader Class Initialized
INFO - 2019-08-26 09:07:18 --> Helper loaded: url_helper
INFO - 2019-08-26 09:07:18 --> Helper loaded: html_helper
INFO - 2019-08-26 09:07:18 --> Helper loaded: form_helper
INFO - 2019-08-26 09:07:18 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:07:18 --> Helper loaded: date_helper
INFO - 2019-08-26 09:07:18 --> Form Validation Class Initialized
INFO - 2019-08-26 09:07:18 --> Email Class Initialized
DEBUG - 2019-08-26 09:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:07:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:07:18 --> Pagination Class Initialized
INFO - 2019-08-26 09:07:18 --> Database Driver Class Initialized
INFO - 2019-08-26 09:07:18 --> Database Driver Class Initialized
INFO - 2019-08-26 09:07:18 --> Controller Class Initialized
INFO - 2019-08-26 09:07:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:07:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:07:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/checkin.php
INFO - 2019-08-26 09:07:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:07:19 --> Final output sent to browser
DEBUG - 2019-08-26 09:07:19 --> Total execution time: 1.0337
INFO - 2019-08-26 09:07:19 --> Config Class Initialized
INFO - 2019-08-26 09:07:19 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:07:19 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:07:19 --> Utf8 Class Initialized
INFO - 2019-08-26 09:07:19 --> URI Class Initialized
INFO - 2019-08-26 09:07:19 --> Router Class Initialized
INFO - 2019-08-26 09:07:19 --> Output Class Initialized
INFO - 2019-08-26 09:07:19 --> Security Class Initialized
DEBUG - 2019-08-26 09:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:07:19 --> Input Class Initialized
INFO - 2019-08-26 09:07:19 --> Language Class Initialized
INFO - 2019-08-26 09:07:19 --> Loader Class Initialized
INFO - 2019-08-26 09:07:19 --> Helper loaded: url_helper
INFO - 2019-08-26 09:07:19 --> Config Class Initialized
INFO - 2019-08-26 09:07:19 --> Helper loaded: html_helper
INFO - 2019-08-26 09:07:19 --> Helper loaded: form_helper
INFO - 2019-08-26 09:07:19 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:07:20 --> Helper loaded: date_helper
INFO - 2019-08-26 09:07:20 --> Hooks Class Initialized
INFO - 2019-08-26 09:07:20 --> Form Validation Class Initialized
DEBUG - 2019-08-26 09:07:20 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:07:20 --> Utf8 Class Initialized
INFO - 2019-08-26 09:07:20 --> URI Class Initialized
INFO - 2019-08-26 09:07:20 --> Email Class Initialized
INFO - 2019-08-26 09:07:20 --> Router Class Initialized
DEBUG - 2019-08-26 09:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:07:20 --> Output Class Initialized
INFO - 2019-08-26 09:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:07:20 --> Security Class Initialized
INFO - 2019-08-26 09:07:20 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2019-08-26 09:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:07:20 --> Pagination Class Initialized
INFO - 2019-08-26 09:07:20 --> Input Class Initialized
INFO - 2019-08-26 09:07:20 --> Database Driver Class Initialized
INFO - 2019-08-26 09:07:20 --> Language Class Initialized
INFO - 2019-08-26 09:07:20 --> Database Driver Class Initialized
INFO - 2019-08-26 09:07:20 --> Loader Class Initialized
INFO - 2019-08-26 09:07:20 --> Controller Class Initialized
INFO - 2019-08-26 09:07:20 --> Helper loaded: url_helper
INFO - 2019-08-26 09:07:20 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:07:20 --> Helper loaded: html_helper
INFO - 2019-08-26 09:07:20 --> Final output sent to browser
DEBUG - 2019-08-26 09:07:20 --> Total execution time: 1.5320
INFO - 2019-08-26 09:07:20 --> Helper loaded: form_helper
INFO - 2019-08-26 09:07:20 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:07:20 --> Helper loaded: date_helper
INFO - 2019-08-26 09:07:20 --> Form Validation Class Initialized
INFO - 2019-08-26 09:07:21 --> Email Class Initialized
DEBUG - 2019-08-26 09:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:07:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:07:21 --> Pagination Class Initialized
INFO - 2019-08-26 09:07:21 --> Database Driver Class Initialized
INFO - 2019-08-26 09:07:21 --> Database Driver Class Initialized
INFO - 2019-08-26 09:07:21 --> Controller Class Initialized
INFO - 2019-08-26 09:07:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:07:21 --> Final output sent to browser
DEBUG - 2019-08-26 09:07:21 --> Total execution time: 1.9707
INFO - 2019-08-26 09:12:16 --> Config Class Initialized
INFO - 2019-08-26 09:12:16 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:12:16 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:12:16 --> Utf8 Class Initialized
INFO - 2019-08-26 09:12:16 --> URI Class Initialized
INFO - 2019-08-26 09:12:16 --> Router Class Initialized
INFO - 2019-08-26 09:12:16 --> Output Class Initialized
INFO - 2019-08-26 09:12:16 --> Security Class Initialized
DEBUG - 2019-08-26 09:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:12:16 --> Input Class Initialized
INFO - 2019-08-26 09:12:16 --> Language Class Initialized
INFO - 2019-08-26 09:12:16 --> Loader Class Initialized
INFO - 2019-08-26 09:12:16 --> Helper loaded: url_helper
INFO - 2019-08-26 09:12:16 --> Helper loaded: html_helper
INFO - 2019-08-26 09:12:16 --> Helper loaded: form_helper
INFO - 2019-08-26 09:12:16 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:12:16 --> Helper loaded: date_helper
INFO - 2019-08-26 09:12:16 --> Form Validation Class Initialized
INFO - 2019-08-26 09:12:16 --> Email Class Initialized
DEBUG - 2019-08-26 09:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:12:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:12:16 --> Pagination Class Initialized
INFO - 2019-08-26 09:12:16 --> Database Driver Class Initialized
INFO - 2019-08-26 09:12:16 --> Database Driver Class Initialized
INFO - 2019-08-26 09:12:16 --> Controller Class Initialized
INFO - 2019-08-26 09:12:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 09:12:17 --> Config Class Initialized
INFO - 2019-08-26 09:12:17 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:12:17 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:12:17 --> Utf8 Class Initialized
INFO - 2019-08-26 09:12:17 --> URI Class Initialized
INFO - 2019-08-26 09:12:17 --> Router Class Initialized
INFO - 2019-08-26 09:12:17 --> Output Class Initialized
INFO - 2019-08-26 09:12:17 --> Security Class Initialized
DEBUG - 2019-08-26 09:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:12:17 --> Input Class Initialized
INFO - 2019-08-26 09:12:17 --> Language Class Initialized
INFO - 2019-08-26 09:12:17 --> Loader Class Initialized
INFO - 2019-08-26 09:12:17 --> Helper loaded: url_helper
INFO - 2019-08-26 09:12:17 --> Helper loaded: html_helper
INFO - 2019-08-26 09:12:17 --> Helper loaded: form_helper
INFO - 2019-08-26 09:12:17 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:12:17 --> Helper loaded: date_helper
INFO - 2019-08-26 09:12:17 --> Form Validation Class Initialized
INFO - 2019-08-26 09:12:17 --> Email Class Initialized
DEBUG - 2019-08-26 09:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:12:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:12:17 --> Pagination Class Initialized
INFO - 2019-08-26 09:12:17 --> Database Driver Class Initialized
INFO - 2019-08-26 09:12:17 --> Database Driver Class Initialized
INFO - 2019-08-26 09:12:17 --> Controller Class Initialized
INFO - 2019-08-26 09:12:17 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:12:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:12:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/checkin.php
INFO - 2019-08-26 09:12:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:12:18 --> Final output sent to browser
DEBUG - 2019-08-26 09:12:18 --> Total execution time: 0.9972
INFO - 2019-08-26 09:12:18 --> Config Class Initialized
INFO - 2019-08-26 09:12:18 --> Hooks Class Initialized
INFO - 2019-08-26 09:12:18 --> Config Class Initialized
INFO - 2019-08-26 09:12:18 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:12:18 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:12:18 --> Utf8 Class Initialized
INFO - 2019-08-26 09:12:18 --> URI Class Initialized
DEBUG - 2019-08-26 09:12:18 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:12:18 --> Utf8 Class Initialized
INFO - 2019-08-26 09:12:18 --> URI Class Initialized
INFO - 2019-08-26 09:12:18 --> Router Class Initialized
INFO - 2019-08-26 09:12:18 --> Output Class Initialized
INFO - 2019-08-26 09:12:18 --> Security Class Initialized
DEBUG - 2019-08-26 09:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:12:19 --> Input Class Initialized
INFO - 2019-08-26 09:12:19 --> Router Class Initialized
INFO - 2019-08-26 09:12:19 --> Language Class Initialized
INFO - 2019-08-26 09:12:19 --> Output Class Initialized
INFO - 2019-08-26 09:12:19 --> Security Class Initialized
DEBUG - 2019-08-26 09:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:12:19 --> Input Class Initialized
INFO - 2019-08-26 09:12:19 --> Language Class Initialized
INFO - 2019-08-26 09:12:19 --> Loader Class Initialized
INFO - 2019-08-26 09:12:19 --> Helper loaded: url_helper
INFO - 2019-08-26 09:12:19 --> Helper loaded: html_helper
INFO - 2019-08-26 09:12:19 --> Helper loaded: form_helper
INFO - 2019-08-26 09:12:19 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:12:19 --> Helper loaded: date_helper
INFO - 2019-08-26 09:12:19 --> Form Validation Class Initialized
INFO - 2019-08-26 09:12:19 --> Email Class Initialized
DEBUG - 2019-08-26 09:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:12:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:12:19 --> Loader Class Initialized
INFO - 2019-08-26 09:12:19 --> Pagination Class Initialized
INFO - 2019-08-26 09:12:19 --> Database Driver Class Initialized
INFO - 2019-08-26 09:12:20 --> Database Driver Class Initialized
INFO - 2019-08-26 09:12:20 --> Helper loaded: url_helper
INFO - 2019-08-26 09:12:20 --> Controller Class Initialized
INFO - 2019-08-26 09:12:20 --> Helper loaded: html_helper
INFO - 2019-08-26 09:12:20 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:12:20 --> Final output sent to browser
DEBUG - 2019-08-26 09:12:20 --> Total execution time: 1.7618
INFO - 2019-08-26 09:12:20 --> Helper loaded: form_helper
INFO - 2019-08-26 09:12:20 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:12:20 --> Helper loaded: date_helper
INFO - 2019-08-26 09:12:20 --> Form Validation Class Initialized
INFO - 2019-08-26 09:12:20 --> Email Class Initialized
DEBUG - 2019-08-26 09:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:12:20 --> Pagination Class Initialized
INFO - 2019-08-26 09:12:20 --> Database Driver Class Initialized
INFO - 2019-08-26 09:12:20 --> Database Driver Class Initialized
INFO - 2019-08-26 09:12:20 --> Controller Class Initialized
INFO - 2019-08-26 09:12:20 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:12:20 --> Final output sent to browser
DEBUG - 2019-08-26 09:12:20 --> Total execution time: 2.3555
INFO - 2019-08-26 09:17:23 --> Config Class Initialized
INFO - 2019-08-26 09:17:24 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:17:24 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:17:24 --> Utf8 Class Initialized
INFO - 2019-08-26 09:17:24 --> URI Class Initialized
INFO - 2019-08-26 09:17:24 --> Router Class Initialized
INFO - 2019-08-26 09:17:24 --> Output Class Initialized
INFO - 2019-08-26 09:17:24 --> Security Class Initialized
DEBUG - 2019-08-26 09:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:17:24 --> Input Class Initialized
INFO - 2019-08-26 09:17:24 --> Language Class Initialized
INFO - 2019-08-26 09:17:24 --> Loader Class Initialized
INFO - 2019-08-26 09:17:24 --> Helper loaded: url_helper
INFO - 2019-08-26 09:17:24 --> Helper loaded: html_helper
INFO - 2019-08-26 09:17:24 --> Helper loaded: form_helper
INFO - 2019-08-26 09:17:24 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:17:24 --> Helper loaded: date_helper
INFO - 2019-08-26 09:17:24 --> Form Validation Class Initialized
INFO - 2019-08-26 09:17:24 --> Email Class Initialized
DEBUG - 2019-08-26 09:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:17:24 --> Pagination Class Initialized
INFO - 2019-08-26 09:17:24 --> Database Driver Class Initialized
INFO - 2019-08-26 09:17:24 --> Database Driver Class Initialized
INFO - 2019-08-26 09:17:24 --> Controller Class Initialized
INFO - 2019-08-26 09:17:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:17:24 --> Final output sent to browser
DEBUG - 2019-08-26 09:17:24 --> Total execution time: 0.9828
INFO - 2019-08-26 09:17:55 --> Config Class Initialized
INFO - 2019-08-26 09:17:55 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:17:55 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:17:55 --> Utf8 Class Initialized
INFO - 2019-08-26 09:17:55 --> URI Class Initialized
INFO - 2019-08-26 09:17:55 --> Router Class Initialized
INFO - 2019-08-26 09:17:55 --> Output Class Initialized
INFO - 2019-08-26 09:17:55 --> Security Class Initialized
DEBUG - 2019-08-26 09:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:17:55 --> Input Class Initialized
INFO - 2019-08-26 09:17:55 --> Language Class Initialized
INFO - 2019-08-26 09:17:55 --> Loader Class Initialized
INFO - 2019-08-26 09:17:55 --> Helper loaded: url_helper
INFO - 2019-08-26 09:17:55 --> Helper loaded: html_helper
INFO - 2019-08-26 09:17:55 --> Helper loaded: form_helper
INFO - 2019-08-26 09:17:55 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:17:55 --> Helper loaded: date_helper
INFO - 2019-08-26 09:17:55 --> Form Validation Class Initialized
INFO - 2019-08-26 09:17:55 --> Email Class Initialized
DEBUG - 2019-08-26 09:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:17:55 --> Pagination Class Initialized
INFO - 2019-08-26 09:17:55 --> Database Driver Class Initialized
INFO - 2019-08-26 09:17:55 --> Database Driver Class Initialized
INFO - 2019-08-26 09:17:55 --> Controller Class Initialized
INFO - 2019-08-26 09:17:55 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:17:55 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:17:55 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-26 09:17:55 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:17:56 --> Final output sent to browser
DEBUG - 2019-08-26 09:17:56 --> Total execution time: 1.0156
INFO - 2019-08-26 09:17:56 --> Config Class Initialized
INFO - 2019-08-26 09:17:56 --> Hooks Class Initialized
INFO - 2019-08-26 09:17:56 --> Config Class Initialized
INFO - 2019-08-26 09:17:56 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:17:56 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:17:56 --> Utf8 Class Initialized
INFO - 2019-08-26 09:17:56 --> URI Class Initialized
INFO - 2019-08-26 09:17:56 --> Router Class Initialized
INFO - 2019-08-26 09:17:56 --> Output Class Initialized
INFO - 2019-08-26 09:17:56 --> Security Class Initialized
DEBUG - 2019-08-26 09:17:56 --> UTF-8 Support Enabled
DEBUG - 2019-08-26 09:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:17:56 --> Utf8 Class Initialized
INFO - 2019-08-26 09:17:56 --> Input Class Initialized
INFO - 2019-08-26 09:17:56 --> URI Class Initialized
INFO - 2019-08-26 09:17:56 --> Language Class Initialized
INFO - 2019-08-26 09:17:56 --> Router Class Initialized
INFO - 2019-08-26 09:17:56 --> Loader Class Initialized
INFO - 2019-08-26 09:17:56 --> Output Class Initialized
INFO - 2019-08-26 09:17:57 --> Helper loaded: url_helper
INFO - 2019-08-26 09:17:57 --> Security Class Initialized
INFO - 2019-08-26 09:17:57 --> Helper loaded: html_helper
DEBUG - 2019-08-26 09:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:17:57 --> Helper loaded: form_helper
INFO - 2019-08-26 09:17:57 --> Input Class Initialized
INFO - 2019-08-26 09:17:57 --> Language Class Initialized
INFO - 2019-08-26 09:17:57 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:17:57 --> Helper loaded: date_helper
INFO - 2019-08-26 09:17:57 --> Loader Class Initialized
INFO - 2019-08-26 09:17:57 --> Form Validation Class Initialized
INFO - 2019-08-26 09:17:57 --> Helper loaded: url_helper
INFO - 2019-08-26 09:17:57 --> Email Class Initialized
INFO - 2019-08-26 09:17:57 --> Helper loaded: html_helper
DEBUG - 2019-08-26 09:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:17:57 --> Helper loaded: form_helper
INFO - 2019-08-26 09:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:17:57 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:17:57 --> Helper loaded: date_helper
INFO - 2019-08-26 09:17:57 --> Pagination Class Initialized
INFO - 2019-08-26 09:17:57 --> Form Validation Class Initialized
INFO - 2019-08-26 09:17:57 --> Database Driver Class Initialized
INFO - 2019-08-26 09:17:57 --> Email Class Initialized
INFO - 2019-08-26 09:17:57 --> Database Driver Class Initialized
DEBUG - 2019-08-26 09:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:17:57 --> Controller Class Initialized
INFO - 2019-08-26 09:17:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:17:57 --> Final output sent to browser
DEBUG - 2019-08-26 09:17:57 --> Total execution time: 1.6037
INFO - 2019-08-26 09:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:17:58 --> Pagination Class Initialized
INFO - 2019-08-26 09:17:58 --> Database Driver Class Initialized
INFO - 2019-08-26 09:17:58 --> Database Driver Class Initialized
INFO - 2019-08-26 09:17:58 --> Controller Class Initialized
INFO - 2019-08-26 09:17:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:17:58 --> Final output sent to browser
DEBUG - 2019-08-26 09:17:58 --> Total execution time: 1.8748
INFO - 2019-08-26 09:18:01 --> Config Class Initialized
INFO - 2019-08-26 09:18:01 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:18:01 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:18:01 --> Utf8 Class Initialized
INFO - 2019-08-26 09:18:01 --> URI Class Initialized
INFO - 2019-08-26 09:18:01 --> Router Class Initialized
INFO - 2019-08-26 09:18:01 --> Output Class Initialized
INFO - 2019-08-26 09:18:01 --> Security Class Initialized
DEBUG - 2019-08-26 09:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:18:01 --> Input Class Initialized
INFO - 2019-08-26 09:18:01 --> Language Class Initialized
INFO - 2019-08-26 09:18:01 --> Loader Class Initialized
INFO - 2019-08-26 09:18:01 --> Helper loaded: url_helper
INFO - 2019-08-26 09:18:01 --> Helper loaded: html_helper
INFO - 2019-08-26 09:18:01 --> Helper loaded: form_helper
INFO - 2019-08-26 09:18:01 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:18:01 --> Helper loaded: date_helper
INFO - 2019-08-26 09:18:01 --> Form Validation Class Initialized
INFO - 2019-08-26 09:18:01 --> Email Class Initialized
DEBUG - 2019-08-26 09:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:18:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:18:01 --> Pagination Class Initialized
INFO - 2019-08-26 09:18:01 --> Database Driver Class Initialized
INFO - 2019-08-26 09:18:01 --> Database Driver Class Initialized
INFO - 2019-08-26 09:18:01 --> Controller Class Initialized
INFO - 2019-08-26 09:18:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:18:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:18:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-26 09:18:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:18:02 --> Final output sent to browser
DEBUG - 2019-08-26 09:18:02 --> Total execution time: 1.1246
INFO - 2019-08-26 09:18:02 --> Config Class Initialized
INFO - 2019-08-26 09:18:02 --> Hooks Class Initialized
INFO - 2019-08-26 09:18:02 --> Config Class Initialized
DEBUG - 2019-08-26 09:18:02 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:18:02 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:18:02 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:18:02 --> Utf8 Class Initialized
INFO - 2019-08-26 09:18:02 --> URI Class Initialized
INFO - 2019-08-26 09:18:02 --> Router Class Initialized
INFO - 2019-08-26 09:18:02 --> Output Class Initialized
INFO - 2019-08-26 09:18:02 --> Utf8 Class Initialized
INFO - 2019-08-26 09:18:02 --> Security Class Initialized
INFO - 2019-08-26 09:18:02 --> URI Class Initialized
DEBUG - 2019-08-26 09:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:18:03 --> Router Class Initialized
INFO - 2019-08-26 09:18:03 --> Input Class Initialized
INFO - 2019-08-26 09:18:03 --> Language Class Initialized
INFO - 2019-08-26 09:18:03 --> Output Class Initialized
INFO - 2019-08-26 09:18:03 --> Loader Class Initialized
INFO - 2019-08-26 09:18:03 --> Security Class Initialized
INFO - 2019-08-26 09:18:03 --> Helper loaded: url_helper
DEBUG - 2019-08-26 09:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:18:03 --> Input Class Initialized
INFO - 2019-08-26 09:18:03 --> Helper loaded: html_helper
INFO - 2019-08-26 09:18:03 --> Language Class Initialized
INFO - 2019-08-26 09:18:03 --> Helper loaded: form_helper
INFO - 2019-08-26 09:18:03 --> Loader Class Initialized
INFO - 2019-08-26 09:18:03 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:18:03 --> Helper loaded: url_helper
INFO - 2019-08-26 09:18:03 --> Helper loaded: date_helper
INFO - 2019-08-26 09:18:03 --> Helper loaded: html_helper
INFO - 2019-08-26 09:18:03 --> Form Validation Class Initialized
INFO - 2019-08-26 09:18:03 --> Helper loaded: form_helper
INFO - 2019-08-26 09:18:03 --> Email Class Initialized
INFO - 2019-08-26 09:18:03 --> Helper loaded: cookie_helper
DEBUG - 2019-08-26 09:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:18:03 --> Helper loaded: date_helper
INFO - 2019-08-26 09:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:18:03 --> Form Validation Class Initialized
INFO - 2019-08-26 09:18:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:18:03 --> Email Class Initialized
INFO - 2019-08-26 09:18:03 --> Pagination Class Initialized
DEBUG - 2019-08-26 09:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:18:03 --> Database Driver Class Initialized
INFO - 2019-08-26 09:18:04 --> Database Driver Class Initialized
INFO - 2019-08-26 09:18:04 --> Controller Class Initialized
INFO - 2019-08-26 09:18:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:18:04 --> Final output sent to browser
DEBUG - 2019-08-26 09:18:04 --> Total execution time: 1.6717
INFO - 2019-08-26 09:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:18:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:18:04 --> Pagination Class Initialized
INFO - 2019-08-26 09:18:04 --> Database Driver Class Initialized
INFO - 2019-08-26 09:18:04 --> Database Driver Class Initialized
INFO - 2019-08-26 09:18:04 --> Controller Class Initialized
INFO - 2019-08-26 09:18:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:18:04 --> Final output sent to browser
DEBUG - 2019-08-26 09:18:04 --> Total execution time: 2.0760
INFO - 2019-08-26 09:18:06 --> Config Class Initialized
INFO - 2019-08-26 09:18:06 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:18:06 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:18:06 --> Utf8 Class Initialized
INFO - 2019-08-26 09:18:06 --> URI Class Initialized
INFO - 2019-08-26 09:18:06 --> Router Class Initialized
INFO - 2019-08-26 09:18:06 --> Output Class Initialized
INFO - 2019-08-26 09:18:06 --> Security Class Initialized
DEBUG - 2019-08-26 09:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:18:06 --> Input Class Initialized
INFO - 2019-08-26 09:18:06 --> Language Class Initialized
INFO - 2019-08-26 09:18:06 --> Loader Class Initialized
INFO - 2019-08-26 09:18:06 --> Helper loaded: url_helper
INFO - 2019-08-26 09:18:07 --> Helper loaded: html_helper
INFO - 2019-08-26 09:18:07 --> Helper loaded: form_helper
INFO - 2019-08-26 09:18:07 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:18:07 --> Helper loaded: date_helper
INFO - 2019-08-26 09:18:07 --> Form Validation Class Initialized
INFO - 2019-08-26 09:18:07 --> Email Class Initialized
DEBUG - 2019-08-26 09:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:18:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:18:07 --> Pagination Class Initialized
INFO - 2019-08-26 09:18:07 --> Database Driver Class Initialized
INFO - 2019-08-26 09:18:07 --> Database Driver Class Initialized
INFO - 2019-08-26 09:18:07 --> Controller Class Initialized
INFO - 2019-08-26 09:18:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:18:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:18:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/guest.php
INFO - 2019-08-26 09:18:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:18:07 --> Final output sent to browser
DEBUG - 2019-08-26 09:18:07 --> Total execution time: 1.0427
INFO - 2019-08-26 09:18:07 --> Config Class Initialized
INFO - 2019-08-26 09:18:07 --> Config Class Initialized
INFO - 2019-08-26 09:18:07 --> Hooks Class Initialized
INFO - 2019-08-26 09:18:08 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:18:08 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:18:08 --> Utf8 Class Initialized
INFO - 2019-08-26 09:18:08 --> URI Class Initialized
INFO - 2019-08-26 09:18:08 --> Router Class Initialized
INFO - 2019-08-26 09:18:08 --> Output Class Initialized
INFO - 2019-08-26 09:18:08 --> Security Class Initialized
DEBUG - 2019-08-26 09:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:18:08 --> Input Class Initialized
INFO - 2019-08-26 09:18:08 --> Language Class Initialized
DEBUG - 2019-08-26 09:18:08 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:18:08 --> Loader Class Initialized
INFO - 2019-08-26 09:18:08 --> Helper loaded: url_helper
INFO - 2019-08-26 09:18:08 --> Helper loaded: html_helper
INFO - 2019-08-26 09:18:08 --> Utf8 Class Initialized
INFO - 2019-08-26 09:18:08 --> Helper loaded: form_helper
INFO - 2019-08-26 09:18:08 --> URI Class Initialized
INFO - 2019-08-26 09:18:08 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:18:08 --> Router Class Initialized
INFO - 2019-08-26 09:18:08 --> Helper loaded: date_helper
INFO - 2019-08-26 09:18:08 --> Output Class Initialized
INFO - 2019-08-26 09:18:08 --> Form Validation Class Initialized
INFO - 2019-08-26 09:18:08 --> Security Class Initialized
INFO - 2019-08-26 09:18:09 --> Email Class Initialized
DEBUG - 2019-08-26 09:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:18:09 --> Input Class Initialized
DEBUG - 2019-08-26 09:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:18:09 --> Language Class Initialized
INFO - 2019-08-26 09:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:18:09 --> Loader Class Initialized
INFO - 2019-08-26 09:18:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:18:09 --> Helper loaded: url_helper
INFO - 2019-08-26 09:18:09 --> Pagination Class Initialized
INFO - 2019-08-26 09:18:09 --> Helper loaded: html_helper
INFO - 2019-08-26 09:18:09 --> Database Driver Class Initialized
INFO - 2019-08-26 09:18:09 --> Helper loaded: form_helper
INFO - 2019-08-26 09:18:09 --> Database Driver Class Initialized
INFO - 2019-08-26 09:18:09 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:18:09 --> Controller Class Initialized
INFO - 2019-08-26 09:18:09 --> Helper loaded: date_helper
INFO - 2019-08-26 09:18:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:18:09 --> Form Validation Class Initialized
INFO - 2019-08-26 09:18:09 --> Final output sent to browser
INFO - 2019-08-26 09:18:09 --> Email Class Initialized
DEBUG - 2019-08-26 09:18:09 --> Total execution time: 1.7828
DEBUG - 2019-08-26 09:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:18:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:18:09 --> Pagination Class Initialized
INFO - 2019-08-26 09:18:10 --> Database Driver Class Initialized
INFO - 2019-08-26 09:18:10 --> Database Driver Class Initialized
INFO - 2019-08-26 09:18:10 --> Controller Class Initialized
INFO - 2019-08-26 09:18:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:18:10 --> Final output sent to browser
DEBUG - 2019-08-26 09:18:10 --> Total execution time: 2.3855
INFO - 2019-08-26 09:18:23 --> Config Class Initialized
INFO - 2019-08-26 09:18:23 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:18:23 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:18:23 --> Utf8 Class Initialized
INFO - 2019-08-26 09:18:23 --> URI Class Initialized
INFO - 2019-08-26 09:18:23 --> Router Class Initialized
INFO - 2019-08-26 09:18:23 --> Output Class Initialized
INFO - 2019-08-26 09:18:23 --> Security Class Initialized
DEBUG - 2019-08-26 09:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:18:23 --> Input Class Initialized
INFO - 2019-08-26 09:18:23 --> Language Class Initialized
INFO - 2019-08-26 09:18:23 --> Loader Class Initialized
INFO - 2019-08-26 09:18:23 --> Helper loaded: url_helper
INFO - 2019-08-26 09:18:23 --> Helper loaded: html_helper
INFO - 2019-08-26 09:18:24 --> Helper loaded: form_helper
INFO - 2019-08-26 09:18:24 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:18:24 --> Helper loaded: date_helper
INFO - 2019-08-26 09:18:24 --> Form Validation Class Initialized
INFO - 2019-08-26 09:18:24 --> Email Class Initialized
DEBUG - 2019-08-26 09:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:18:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:18:24 --> Pagination Class Initialized
INFO - 2019-08-26 09:18:24 --> Database Driver Class Initialized
INFO - 2019-08-26 09:18:24 --> Database Driver Class Initialized
INFO - 2019-08-26 09:18:24 --> Controller Class Initialized
INFO - 2019-08-26 09:18:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:18:24 --> Final output sent to browser
DEBUG - 2019-08-26 09:18:24 --> Total execution time: 1.0220
INFO - 2019-08-26 09:19:24 --> Config Class Initialized
INFO - 2019-08-26 09:19:24 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:19:24 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:19:24 --> Utf8 Class Initialized
INFO - 2019-08-26 09:19:24 --> URI Class Initialized
INFO - 2019-08-26 09:19:24 --> Router Class Initialized
INFO - 2019-08-26 09:19:24 --> Output Class Initialized
INFO - 2019-08-26 09:19:24 --> Security Class Initialized
DEBUG - 2019-08-26 09:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:19:24 --> Config Class Initialized
INFO - 2019-08-26 09:19:24 --> Input Class Initialized
INFO - 2019-08-26 09:19:24 --> Hooks Class Initialized
INFO - 2019-08-26 09:19:24 --> Language Class Initialized
DEBUG - 2019-08-26 09:19:24 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:19:24 --> Loader Class Initialized
INFO - 2019-08-26 09:19:24 --> Utf8 Class Initialized
INFO - 2019-08-26 09:19:24 --> URI Class Initialized
INFO - 2019-08-26 09:19:24 --> Helper loaded: url_helper
INFO - 2019-08-26 09:19:24 --> Router Class Initialized
INFO - 2019-08-26 09:19:24 --> Helper loaded: html_helper
INFO - 2019-08-26 09:19:24 --> Output Class Initialized
INFO - 2019-08-26 09:19:24 --> Helper loaded: form_helper
INFO - 2019-08-26 09:19:24 --> Security Class Initialized
INFO - 2019-08-26 09:19:24 --> Helper loaded: cookie_helper
DEBUG - 2019-08-26 09:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:19:24 --> Helper loaded: date_helper
INFO - 2019-08-26 09:19:24 --> Input Class Initialized
INFO - 2019-08-26 09:19:24 --> Language Class Initialized
INFO - 2019-08-26 09:19:24 --> Form Validation Class Initialized
INFO - 2019-08-26 09:19:24 --> Loader Class Initialized
INFO - 2019-08-26 09:19:24 --> Helper loaded: url_helper
INFO - 2019-08-26 09:19:24 --> Helper loaded: html_helper
INFO - 2019-08-26 09:19:24 --> Config Class Initialized
INFO - 2019-08-26 09:19:24 --> Email Class Initialized
INFO - 2019-08-26 09:19:24 --> Helper loaded: form_helper
INFO - 2019-08-26 09:19:24 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:19:24 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:19:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-08-26 09:19:24 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:19:24 --> Helper loaded: date_helper
INFO - 2019-08-26 09:19:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:19:24 --> Utf8 Class Initialized
INFO - 2019-08-26 09:19:25 --> Form Validation Class Initialized
INFO - 2019-08-26 09:19:25 --> Pagination Class Initialized
INFO - 2019-08-26 09:19:25 --> URI Class Initialized
INFO - 2019-08-26 09:19:25 --> Database Driver Class Initialized
INFO - 2019-08-26 09:19:25 --> Email Class Initialized
INFO - 2019-08-26 09:19:25 --> Router Class Initialized
DEBUG - 2019-08-26 09:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:19:25 --> Database Driver Class Initialized
INFO - 2019-08-26 09:19:25 --> Output Class Initialized
INFO - 2019-08-26 09:19:25 --> Controller Class Initialized
INFO - 2019-08-26 09:19:25 --> Security Class Initialized
DEBUG - 2019-08-26 09:19:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-08-26 09:19:25 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-26 09:19:25 --> Input Class Initialized
INFO - 2019-08-26 09:19:25 --> Language Class Initialized
INFO - 2019-08-26 09:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:19:25 --> Loader Class Initialized
INFO - 2019-08-26 09:19:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:19:25 --> Helper loaded: url_helper
INFO - 2019-08-26 09:19:25 --> Pagination Class Initialized
INFO - 2019-08-26 09:19:25 --> Helper loaded: html_helper
INFO - 2019-08-26 09:19:25 --> Database Driver Class Initialized
INFO - 2019-08-26 09:19:25 --> Helper loaded: form_helper
INFO - 2019-08-26 09:19:25 --> Database Driver Class Initialized
INFO - 2019-08-26 09:19:25 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:19:25 --> Controller Class Initialized
INFO - 2019-08-26 09:19:25 --> Helper loaded: date_helper
INFO - 2019-08-26 09:19:25 --> Form Validation Class Initialized
ERROR - 2019-08-26 09:19:25 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-26 09:19:25 --> Email Class Initialized
DEBUG - 2019-08-26 09:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:19:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:19:25 --> Pagination Class Initialized
INFO - 2019-08-26 09:19:25 --> Database Driver Class Initialized
INFO - 2019-08-26 09:19:25 --> Database Driver Class Initialized
INFO - 2019-08-26 09:19:25 --> Controller Class Initialized
ERROR - 2019-08-26 09:19:25 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-26 09:19:26 --> Config Class Initialized
INFO - 2019-08-26 09:19:26 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:19:26 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:19:26 --> Utf8 Class Initialized
INFO - 2019-08-26 09:19:26 --> URI Class Initialized
INFO - 2019-08-26 09:19:26 --> Router Class Initialized
INFO - 2019-08-26 09:19:26 --> Output Class Initialized
INFO - 2019-08-26 09:19:26 --> Security Class Initialized
DEBUG - 2019-08-26 09:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:19:26 --> Input Class Initialized
INFO - 2019-08-26 09:19:26 --> Language Class Initialized
INFO - 2019-08-26 09:19:26 --> Loader Class Initialized
INFO - 2019-08-26 09:19:26 --> Helper loaded: url_helper
INFO - 2019-08-26 09:19:26 --> Helper loaded: html_helper
INFO - 2019-08-26 09:19:26 --> Helper loaded: form_helper
INFO - 2019-08-26 09:19:27 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:19:27 --> Helper loaded: date_helper
INFO - 2019-08-26 09:19:27 --> Form Validation Class Initialized
INFO - 2019-08-26 09:19:27 --> Email Class Initialized
DEBUG - 2019-08-26 09:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:19:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:19:27 --> Pagination Class Initialized
INFO - 2019-08-26 09:19:27 --> Database Driver Class Initialized
INFO - 2019-08-26 09:19:27 --> Database Driver Class Initialized
INFO - 2019-08-26 09:19:27 --> Controller Class Initialized
ERROR - 2019-08-26 09:19:27 --> Severity: Error --> Call to undefined method Resv_model::search() C:\wamp\www\pridehotel\application\controllers\Resv.php 16
INFO - 2019-08-26 09:20:16 --> Config Class Initialized
INFO - 2019-08-26 09:20:16 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:20:16 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:20:16 --> Utf8 Class Initialized
INFO - 2019-08-26 09:20:16 --> URI Class Initialized
INFO - 2019-08-26 09:20:16 --> Router Class Initialized
INFO - 2019-08-26 09:20:16 --> Output Class Initialized
INFO - 2019-08-26 09:20:16 --> Security Class Initialized
DEBUG - 2019-08-26 09:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:20:16 --> Input Class Initialized
INFO - 2019-08-26 09:20:16 --> Language Class Initialized
INFO - 2019-08-26 09:20:16 --> Loader Class Initialized
INFO - 2019-08-26 09:20:16 --> Helper loaded: url_helper
INFO - 2019-08-26 09:20:16 --> Helper loaded: html_helper
INFO - 2019-08-26 09:20:16 --> Helper loaded: form_helper
INFO - 2019-08-26 09:20:16 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:20:16 --> Helper loaded: date_helper
INFO - 2019-08-26 09:20:16 --> Form Validation Class Initialized
INFO - 2019-08-26 09:20:16 --> Email Class Initialized
DEBUG - 2019-08-26 09:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:20:17 --> Pagination Class Initialized
INFO - 2019-08-26 09:20:17 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:17 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:17 --> Controller Class Initialized
INFO - 2019-08-26 09:20:17 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:20:17 --> Final output sent to browser
DEBUG - 2019-08-26 09:20:17 --> Total execution time: 1.0909
INFO - 2019-08-26 09:20:32 --> Config Class Initialized
INFO - 2019-08-26 09:20:32 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:20:32 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:20:32 --> Utf8 Class Initialized
INFO - 2019-08-26 09:20:32 --> URI Class Initialized
INFO - 2019-08-26 09:20:32 --> Router Class Initialized
INFO - 2019-08-26 09:20:32 --> Output Class Initialized
INFO - 2019-08-26 09:20:33 --> Security Class Initialized
DEBUG - 2019-08-26 09:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:20:33 --> Input Class Initialized
INFO - 2019-08-26 09:20:33 --> Language Class Initialized
INFO - 2019-08-26 09:20:33 --> Loader Class Initialized
INFO - 2019-08-26 09:20:33 --> Helper loaded: url_helper
INFO - 2019-08-26 09:20:33 --> Helper loaded: html_helper
INFO - 2019-08-26 09:20:33 --> Helper loaded: form_helper
INFO - 2019-08-26 09:20:33 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:20:33 --> Helper loaded: date_helper
INFO - 2019-08-26 09:20:33 --> Form Validation Class Initialized
INFO - 2019-08-26 09:20:33 --> Email Class Initialized
DEBUG - 2019-08-26 09:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:20:33 --> Pagination Class Initialized
INFO - 2019-08-26 09:20:33 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:33 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:33 --> Controller Class Initialized
INFO - 2019-08-26 09:20:33 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:20:34 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 09:20:34 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:20:34 --> Final output sent to browser
DEBUG - 2019-08-26 09:20:34 --> Total execution time: 1.3684
INFO - 2019-08-26 09:20:34 --> Config Class Initialized
INFO - 2019-08-26 09:20:34 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:20:34 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:20:34 --> Utf8 Class Initialized
INFO - 2019-08-26 09:20:34 --> URI Class Initialized
INFO - 2019-08-26 09:20:34 --> Router Class Initialized
INFO - 2019-08-26 09:20:34 --> Output Class Initialized
INFO - 2019-08-26 09:20:34 --> Security Class Initialized
INFO - 2019-08-26 09:20:34 --> Config Class Initialized
INFO - 2019-08-26 09:20:34 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:20:35 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:20:35 --> Config Class Initialized
INFO - 2019-08-26 09:20:35 --> Utf8 Class Initialized
DEBUG - 2019-08-26 09:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:20:35 --> Hooks Class Initialized
INFO - 2019-08-26 09:20:35 --> Input Class Initialized
DEBUG - 2019-08-26 09:20:35 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:20:35 --> URI Class Initialized
INFO - 2019-08-26 09:20:35 --> Language Class Initialized
INFO - 2019-08-26 09:20:35 --> Utf8 Class Initialized
INFO - 2019-08-26 09:20:35 --> Loader Class Initialized
INFO - 2019-08-26 09:20:35 --> URI Class Initialized
INFO - 2019-08-26 09:20:35 --> Router Class Initialized
INFO - 2019-08-26 09:20:35 --> Router Class Initialized
INFO - 2019-08-26 09:20:35 --> Config Class Initialized
INFO - 2019-08-26 09:20:35 --> Output Class Initialized
INFO - 2019-08-26 09:20:35 --> Hooks Class Initialized
INFO - 2019-08-26 09:20:35 --> Helper loaded: url_helper
INFO - 2019-08-26 09:20:35 --> Output Class Initialized
DEBUG - 2019-08-26 09:20:35 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:20:35 --> Security Class Initialized
INFO - 2019-08-26 09:20:35 --> Utf8 Class Initialized
INFO - 2019-08-26 09:20:35 --> Helper loaded: html_helper
INFO - 2019-08-26 09:20:35 --> Security Class Initialized
DEBUG - 2019-08-26 09:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:20:35 --> Helper loaded: form_helper
DEBUG - 2019-08-26 09:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:20:35 --> URI Class Initialized
INFO - 2019-08-26 09:20:36 --> Input Class Initialized
INFO - 2019-08-26 09:20:36 --> Router Class Initialized
INFO - 2019-08-26 09:20:36 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:20:36 --> Input Class Initialized
INFO - 2019-08-26 09:20:36 --> Language Class Initialized
INFO - 2019-08-26 09:20:36 --> Language Class Initialized
INFO - 2019-08-26 09:20:36 --> Output Class Initialized
INFO - 2019-08-26 09:20:36 --> Helper loaded: date_helper
INFO - 2019-08-26 09:20:36 --> Loader Class Initialized
INFO - 2019-08-26 09:20:36 --> Loader Class Initialized
INFO - 2019-08-26 09:20:36 --> Security Class Initialized
INFO - 2019-08-26 09:20:36 --> Helper loaded: url_helper
INFO - 2019-08-26 09:20:36 --> Form Validation Class Initialized
INFO - 2019-08-26 09:20:36 --> Helper loaded: html_helper
DEBUG - 2019-08-26 09:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:20:36 --> Helper loaded: url_helper
INFO - 2019-08-26 09:20:36 --> Helper loaded: form_helper
INFO - 2019-08-26 09:20:36 --> Input Class Initialized
INFO - 2019-08-26 09:20:36 --> Email Class Initialized
INFO - 2019-08-26 09:20:36 --> Helper loaded: html_helper
INFO - 2019-08-26 09:20:36 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:20:36 --> Helper loaded: form_helper
INFO - 2019-08-26 09:20:36 --> Language Class Initialized
INFO - 2019-08-26 09:20:36 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:20:36 --> Helper loaded: date_helper
DEBUG - 2019-08-26 09:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:20:36 --> Loader Class Initialized
INFO - 2019-08-26 09:20:36 --> Helper loaded: url_helper
INFO - 2019-08-26 09:20:36 --> Helper loaded: date_helper
INFO - 2019-08-26 09:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:20:36 --> Form Validation Class Initialized
INFO - 2019-08-26 09:20:36 --> Helper loaded: html_helper
INFO - 2019-08-26 09:20:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:20:36 --> Email Class Initialized
INFO - 2019-08-26 09:20:36 --> Form Validation Class Initialized
INFO - 2019-08-26 09:20:36 --> Helper loaded: form_helper
INFO - 2019-08-26 09:20:36 --> Pagination Class Initialized
DEBUG - 2019-08-26 09:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:20:36 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:20:36 --> Email Class Initialized
INFO - 2019-08-26 09:20:36 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:36 --> Helper loaded: date_helper
DEBUG - 2019-08-26 09:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:20:36 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:37 --> Form Validation Class Initialized
INFO - 2019-08-26 09:20:37 --> Controller Class Initialized
INFO - 2019-08-26 09:20:37 --> Email Class Initialized
INFO - 2019-08-26 09:20:37 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:20:37 --> Final output sent to browser
DEBUG - 2019-08-26 09:20:37 --> Total execution time: 2.7167
INFO - 2019-08-26 09:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:20:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:20:37 --> Pagination Class Initialized
DEBUG - 2019-08-26 09:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:20:37 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:37 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:37 --> Controller Class Initialized
INFO - 2019-08-26 09:20:37 --> Final output sent to browser
DEBUG - 2019-08-26 09:20:37 --> Total execution time: 2.5913
INFO - 2019-08-26 09:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:20:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:20:37 --> Pagination Class Initialized
INFO - 2019-08-26 09:20:38 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:38 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:38 --> Controller Class Initialized
INFO - 2019-08-26 09:20:38 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:20:38 --> Final output sent to browser
DEBUG - 2019-08-26 09:20:38 --> Total execution time: 3.4522
INFO - 2019-08-26 09:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:20:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:20:38 --> Pagination Class Initialized
INFO - 2019-08-26 09:20:38 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:38 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:38 --> Controller Class Initialized
INFO - 2019-08-26 09:20:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:20:39 --> Final output sent to browser
DEBUG - 2019-08-26 09:20:39 --> Total execution time: 3.4148
INFO - 2019-08-26 09:20:52 --> Config Class Initialized
INFO - 2019-08-26 09:20:52 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:20:52 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:20:52 --> Utf8 Class Initialized
INFO - 2019-08-26 09:20:52 --> URI Class Initialized
INFO - 2019-08-26 09:20:53 --> Router Class Initialized
INFO - 2019-08-26 09:20:53 --> Output Class Initialized
INFO - 2019-08-26 09:20:53 --> Security Class Initialized
DEBUG - 2019-08-26 09:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:20:53 --> Input Class Initialized
INFO - 2019-08-26 09:20:53 --> Language Class Initialized
INFO - 2019-08-26 09:20:53 --> Loader Class Initialized
INFO - 2019-08-26 09:20:53 --> Helper loaded: url_helper
INFO - 2019-08-26 09:20:53 --> Helper loaded: html_helper
INFO - 2019-08-26 09:20:53 --> Helper loaded: form_helper
INFO - 2019-08-26 09:20:53 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:20:53 --> Helper loaded: date_helper
INFO - 2019-08-26 09:20:53 --> Form Validation Class Initialized
INFO - 2019-08-26 09:20:53 --> Email Class Initialized
DEBUG - 2019-08-26 09:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:20:53 --> Pagination Class Initialized
INFO - 2019-08-26 09:20:53 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:53 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:53 --> Controller Class Initialized
INFO - 2019-08-26 09:20:53 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:20:53 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:20:53 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/guest.php
INFO - 2019-08-26 09:20:53 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:20:53 --> Final output sent to browser
DEBUG - 2019-08-26 09:20:54 --> Total execution time: 1.1291
INFO - 2019-08-26 09:20:54 --> Config Class Initialized
INFO - 2019-08-26 09:20:54 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:20:54 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:20:54 --> Utf8 Class Initialized
INFO - 2019-08-26 09:20:54 --> URI Class Initialized
INFO - 2019-08-26 09:20:54 --> Router Class Initialized
INFO - 2019-08-26 09:20:54 --> Output Class Initialized
INFO - 2019-08-26 09:20:54 --> Security Class Initialized
DEBUG - 2019-08-26 09:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:20:54 --> Input Class Initialized
INFO - 2019-08-26 09:20:54 --> Language Class Initialized
INFO - 2019-08-26 09:20:54 --> Config Class Initialized
INFO - 2019-08-26 09:20:54 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:20:54 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:20:54 --> Utf8 Class Initialized
INFO - 2019-08-26 09:20:55 --> Loader Class Initialized
INFO - 2019-08-26 09:20:55 --> URI Class Initialized
INFO - 2019-08-26 09:20:55 --> Helper loaded: url_helper
INFO - 2019-08-26 09:20:55 --> Router Class Initialized
INFO - 2019-08-26 09:20:55 --> Output Class Initialized
INFO - 2019-08-26 09:20:55 --> Security Class Initialized
DEBUG - 2019-08-26 09:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:20:55 --> Input Class Initialized
INFO - 2019-08-26 09:20:55 --> Language Class Initialized
INFO - 2019-08-26 09:20:55 --> Loader Class Initialized
INFO - 2019-08-26 09:20:55 --> Helper loaded: url_helper
INFO - 2019-08-26 09:20:55 --> Helper loaded: html_helper
INFO - 2019-08-26 09:20:55 --> Helper loaded: html_helper
INFO - 2019-08-26 09:20:55 --> Helper loaded: form_helper
INFO - 2019-08-26 09:20:55 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:20:55 --> Helper loaded: date_helper
INFO - 2019-08-26 09:20:55 --> Form Validation Class Initialized
INFO - 2019-08-26 09:20:55 --> Email Class Initialized
DEBUG - 2019-08-26 09:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:20:55 --> Helper loaded: form_helper
INFO - 2019-08-26 09:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:20:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:20:55 --> Pagination Class Initialized
INFO - 2019-08-26 09:20:56 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:56 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:20:56 --> Helper loaded: date_helper
INFO - 2019-08-26 09:20:56 --> Form Validation Class Initialized
INFO - 2019-08-26 09:20:56 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:56 --> Email Class Initialized
INFO - 2019-08-26 09:20:56 --> Controller Class Initialized
DEBUG - 2019-08-26 09:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:20:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:20:56 --> Final output sent to browser
DEBUG - 2019-08-26 09:20:56 --> Total execution time: 2.2304
INFO - 2019-08-26 09:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:20:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:20:56 --> Pagination Class Initialized
INFO - 2019-08-26 09:20:56 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:56 --> Database Driver Class Initialized
INFO - 2019-08-26 09:20:56 --> Controller Class Initialized
INFO - 2019-08-26 09:20:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:20:56 --> Final output sent to browser
DEBUG - 2019-08-26 09:20:56 --> Total execution time: 2.6351
INFO - 2019-08-26 09:22:17 --> Config Class Initialized
INFO - 2019-08-26 09:22:17 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:22:17 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:22:17 --> Utf8 Class Initialized
INFO - 2019-08-26 09:22:17 --> URI Class Initialized
INFO - 2019-08-26 09:22:17 --> Router Class Initialized
INFO - 2019-08-26 09:22:17 --> Output Class Initialized
INFO - 2019-08-26 09:22:17 --> Security Class Initialized
DEBUG - 2019-08-26 09:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:22:17 --> Input Class Initialized
INFO - 2019-08-26 09:22:17 --> Language Class Initialized
INFO - 2019-08-26 09:22:17 --> Loader Class Initialized
INFO - 2019-08-26 09:22:17 --> Helper loaded: url_helper
INFO - 2019-08-26 09:22:17 --> Helper loaded: html_helper
INFO - 2019-08-26 09:22:17 --> Helper loaded: form_helper
INFO - 2019-08-26 09:22:17 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:22:17 --> Helper loaded: date_helper
INFO - 2019-08-26 09:22:17 --> Form Validation Class Initialized
INFO - 2019-08-26 09:22:17 --> Email Class Initialized
DEBUG - 2019-08-26 09:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:22:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:22:18 --> Pagination Class Initialized
INFO - 2019-08-26 09:22:18 --> Database Driver Class Initialized
INFO - 2019-08-26 09:22:18 --> Database Driver Class Initialized
INFO - 2019-08-26 09:22:18 --> Controller Class Initialized
INFO - 2019-08-26 09:22:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 09:22:18 --> Config Class Initialized
INFO - 2019-08-26 09:22:18 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:22:18 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:22:18 --> Utf8 Class Initialized
INFO - 2019-08-26 09:22:18 --> URI Class Initialized
INFO - 2019-08-26 09:22:18 --> Router Class Initialized
INFO - 2019-08-26 09:22:18 --> Output Class Initialized
INFO - 2019-08-26 09:22:18 --> Security Class Initialized
DEBUG - 2019-08-26 09:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:22:18 --> Input Class Initialized
INFO - 2019-08-26 09:22:18 --> Language Class Initialized
INFO - 2019-08-26 09:22:18 --> Loader Class Initialized
INFO - 2019-08-26 09:22:18 --> Helper loaded: url_helper
INFO - 2019-08-26 09:22:18 --> Helper loaded: html_helper
INFO - 2019-08-26 09:22:18 --> Helper loaded: form_helper
INFO - 2019-08-26 09:22:18 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:22:18 --> Helper loaded: date_helper
INFO - 2019-08-26 09:22:18 --> Form Validation Class Initialized
INFO - 2019-08-26 09:22:18 --> Email Class Initialized
DEBUG - 2019-08-26 09:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:22:19 --> Pagination Class Initialized
INFO - 2019-08-26 09:22:19 --> Database Driver Class Initialized
INFO - 2019-08-26 09:22:19 --> Database Driver Class Initialized
INFO - 2019-08-26 09:22:19 --> Controller Class Initialized
INFO - 2019-08-26 09:22:19 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:22:19 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:22:19 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/checkin.php
INFO - 2019-08-26 09:22:19 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:22:19 --> Final output sent to browser
DEBUG - 2019-08-26 09:22:19 --> Total execution time: 1.0569
INFO - 2019-08-26 09:22:19 --> Config Class Initialized
INFO - 2019-08-26 09:22:19 --> Config Class Initialized
INFO - 2019-08-26 09:22:19 --> Hooks Class Initialized
INFO - 2019-08-26 09:22:19 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:22:19 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:22:19 --> Utf8 Class Initialized
INFO - 2019-08-26 09:22:19 --> URI Class Initialized
INFO - 2019-08-26 09:22:20 --> Router Class Initialized
INFO - 2019-08-26 09:22:20 --> Output Class Initialized
DEBUG - 2019-08-26 09:22:20 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:22:20 --> Security Class Initialized
DEBUG - 2019-08-26 09:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:22:20 --> Input Class Initialized
INFO - 2019-08-26 09:22:20 --> Language Class Initialized
INFO - 2019-08-26 09:22:20 --> Loader Class Initialized
INFO - 2019-08-26 09:22:20 --> Helper loaded: url_helper
INFO - 2019-08-26 09:22:20 --> Utf8 Class Initialized
INFO - 2019-08-26 09:22:20 --> Helper loaded: html_helper
INFO - 2019-08-26 09:22:20 --> URI Class Initialized
INFO - 2019-08-26 09:22:20 --> Helper loaded: form_helper
INFO - 2019-08-26 09:22:20 --> Router Class Initialized
INFO - 2019-08-26 09:22:20 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:22:20 --> Output Class Initialized
INFO - 2019-08-26 09:22:20 --> Helper loaded: date_helper
INFO - 2019-08-26 09:22:20 --> Security Class Initialized
INFO - 2019-08-26 09:22:20 --> Form Validation Class Initialized
DEBUG - 2019-08-26 09:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:22:21 --> Email Class Initialized
INFO - 2019-08-26 09:22:21 --> Input Class Initialized
INFO - 2019-08-26 09:22:21 --> Language Class Initialized
DEBUG - 2019-08-26 09:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:22:21 --> Loader Class Initialized
INFO - 2019-08-26 09:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:22:21 --> Helper loaded: url_helper
INFO - 2019-08-26 09:22:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:22:21 --> Helper loaded: html_helper
INFO - 2019-08-26 09:22:21 --> Pagination Class Initialized
INFO - 2019-08-26 09:22:21 --> Helper loaded: form_helper
INFO - 2019-08-26 09:22:21 --> Database Driver Class Initialized
INFO - 2019-08-26 09:22:21 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:22:21 --> Database Driver Class Initialized
INFO - 2019-08-26 09:22:21 --> Helper loaded: date_helper
INFO - 2019-08-26 09:22:21 --> Controller Class Initialized
INFO - 2019-08-26 09:22:21 --> Form Validation Class Initialized
INFO - 2019-08-26 09:22:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:22:21 --> Email Class Initialized
INFO - 2019-08-26 09:22:21 --> Final output sent to browser
DEBUG - 2019-08-26 09:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-26 09:22:21 --> Total execution time: 1.8367
INFO - 2019-08-26 09:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:22:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:22:21 --> Pagination Class Initialized
INFO - 2019-08-26 09:22:21 --> Database Driver Class Initialized
INFO - 2019-08-26 09:22:21 --> Database Driver Class Initialized
INFO - 2019-08-26 09:22:21 --> Controller Class Initialized
INFO - 2019-08-26 09:22:21 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:22:21 --> Final output sent to browser
DEBUG - 2019-08-26 09:22:21 --> Total execution time: 2.2077
INFO - 2019-08-26 09:24:03 --> Config Class Initialized
INFO - 2019-08-26 09:24:03 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:24:03 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:24:03 --> Utf8 Class Initialized
INFO - 2019-08-26 09:24:03 --> URI Class Initialized
INFO - 2019-08-26 09:24:03 --> Router Class Initialized
INFO - 2019-08-26 09:24:03 --> Output Class Initialized
INFO - 2019-08-26 09:24:03 --> Security Class Initialized
DEBUG - 2019-08-26 09:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:24:03 --> Input Class Initialized
INFO - 2019-08-26 09:24:04 --> Language Class Initialized
INFO - 2019-08-26 09:24:04 --> Loader Class Initialized
INFO - 2019-08-26 09:24:04 --> Helper loaded: url_helper
INFO - 2019-08-26 09:24:04 --> Helper loaded: html_helper
INFO - 2019-08-26 09:24:04 --> Helper loaded: form_helper
INFO - 2019-08-26 09:24:04 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:24:04 --> Helper loaded: date_helper
INFO - 2019-08-26 09:24:04 --> Form Validation Class Initialized
INFO - 2019-08-26 09:24:04 --> Email Class Initialized
DEBUG - 2019-08-26 09:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:24:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:24:04 --> Pagination Class Initialized
INFO - 2019-08-26 09:24:04 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:04 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:04 --> Controller Class Initialized
INFO - 2019-08-26 09:24:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:24:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:24:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-26 09:24:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:24:04 --> Final output sent to browser
DEBUG - 2019-08-26 09:24:04 --> Total execution time: 1.2828
INFO - 2019-08-26 09:24:05 --> Config Class Initialized
INFO - 2019-08-26 09:24:05 --> Config Class Initialized
INFO - 2019-08-26 09:24:05 --> Hooks Class Initialized
INFO - 2019-08-26 09:24:05 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:24:05 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:24:05 --> Utf8 Class Initialized
INFO - 2019-08-26 09:24:05 --> URI Class Initialized
DEBUG - 2019-08-26 09:24:05 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:24:05 --> Utf8 Class Initialized
INFO - 2019-08-26 09:24:05 --> URI Class Initialized
INFO - 2019-08-26 09:24:05 --> Router Class Initialized
INFO - 2019-08-26 09:24:05 --> Router Class Initialized
INFO - 2019-08-26 09:24:05 --> Output Class Initialized
INFO - 2019-08-26 09:24:05 --> Output Class Initialized
INFO - 2019-08-26 09:24:05 --> Security Class Initialized
INFO - 2019-08-26 09:24:05 --> Security Class Initialized
DEBUG - 2019-08-26 09:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-26 09:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:24:05 --> Input Class Initialized
INFO - 2019-08-26 09:24:05 --> Input Class Initialized
INFO - 2019-08-26 09:24:05 --> Language Class Initialized
INFO - 2019-08-26 09:24:05 --> Language Class Initialized
INFO - 2019-08-26 09:24:05 --> Loader Class Initialized
INFO - 2019-08-26 09:24:06 --> Loader Class Initialized
INFO - 2019-08-26 09:24:06 --> Helper loaded: url_helper
INFO - 2019-08-26 09:24:06 --> Helper loaded: url_helper
INFO - 2019-08-26 09:24:06 --> Helper loaded: html_helper
INFO - 2019-08-26 09:24:06 --> Helper loaded: html_helper
INFO - 2019-08-26 09:24:06 --> Helper loaded: form_helper
INFO - 2019-08-26 09:24:06 --> Helper loaded: form_helper
INFO - 2019-08-26 09:24:06 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:24:06 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:24:06 --> Helper loaded: date_helper
INFO - 2019-08-26 09:24:06 --> Helper loaded: date_helper
INFO - 2019-08-26 09:24:06 --> Form Validation Class Initialized
INFO - 2019-08-26 09:24:06 --> Form Validation Class Initialized
INFO - 2019-08-26 09:24:06 --> Email Class Initialized
INFO - 2019-08-26 09:24:06 --> Email Class Initialized
DEBUG - 2019-08-26 09:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-26 09:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:24:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:24:06 --> Pagination Class Initialized
INFO - 2019-08-26 09:24:06 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:06 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:06 --> Controller Class Initialized
INFO - 2019-08-26 09:24:06 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:24:06 --> Final output sent to browser
DEBUG - 2019-08-26 09:24:06 --> Total execution time: 1.6965
INFO - 2019-08-26 09:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:24:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:24:07 --> Pagination Class Initialized
INFO - 2019-08-26 09:24:07 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:07 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:07 --> Controller Class Initialized
INFO - 2019-08-26 09:24:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:24:07 --> Final output sent to browser
DEBUG - 2019-08-26 09:24:07 --> Total execution time: 1.9978
INFO - 2019-08-26 09:24:13 --> Config Class Initialized
INFO - 2019-08-26 09:24:13 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:24:14 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:24:14 --> Utf8 Class Initialized
INFO - 2019-08-26 09:24:14 --> URI Class Initialized
INFO - 2019-08-26 09:24:14 --> Router Class Initialized
INFO - 2019-08-26 09:24:14 --> Output Class Initialized
INFO - 2019-08-26 09:24:14 --> Security Class Initialized
DEBUG - 2019-08-26 09:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:24:14 --> Input Class Initialized
INFO - 2019-08-26 09:24:14 --> Language Class Initialized
INFO - 2019-08-26 09:24:14 --> Loader Class Initialized
INFO - 2019-08-26 09:24:14 --> Helper loaded: url_helper
INFO - 2019-08-26 09:24:14 --> Helper loaded: html_helper
INFO - 2019-08-26 09:24:14 --> Helper loaded: form_helper
INFO - 2019-08-26 09:24:14 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:24:14 --> Helper loaded: date_helper
INFO - 2019-08-26 09:24:14 --> Form Validation Class Initialized
INFO - 2019-08-26 09:24:14 --> Email Class Initialized
DEBUG - 2019-08-26 09:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:24:14 --> Pagination Class Initialized
INFO - 2019-08-26 09:24:14 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:14 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:14 --> Controller Class Initialized
INFO - 2019-08-26 09:24:14 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:24:14 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:24:15 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-26 09:24:15 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:24:15 --> Final output sent to browser
DEBUG - 2019-08-26 09:24:15 --> Total execution time: 1.1368
INFO - 2019-08-26 09:24:15 --> Config Class Initialized
INFO - 2019-08-26 09:24:15 --> Config Class Initialized
INFO - 2019-08-26 09:24:15 --> Hooks Class Initialized
INFO - 2019-08-26 09:24:15 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:24:15 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:24:15 --> Utf8 Class Initialized
INFO - 2019-08-26 09:24:15 --> URI Class Initialized
INFO - 2019-08-26 09:24:15 --> Router Class Initialized
INFO - 2019-08-26 09:24:15 --> Output Class Initialized
INFO - 2019-08-26 09:24:15 --> Security Class Initialized
DEBUG - 2019-08-26 09:24:15 --> UTF-8 Support Enabled
DEBUG - 2019-08-26 09:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:24:15 --> Utf8 Class Initialized
INFO - 2019-08-26 09:24:15 --> Input Class Initialized
INFO - 2019-08-26 09:24:15 --> Language Class Initialized
INFO - 2019-08-26 09:24:15 --> URI Class Initialized
INFO - 2019-08-26 09:24:15 --> Router Class Initialized
INFO - 2019-08-26 09:24:16 --> Output Class Initialized
INFO - 2019-08-26 09:24:16 --> Security Class Initialized
DEBUG - 2019-08-26 09:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:24:16 --> Input Class Initialized
INFO - 2019-08-26 09:24:16 --> Language Class Initialized
INFO - 2019-08-26 09:24:16 --> Loader Class Initialized
INFO - 2019-08-26 09:24:16 --> Loader Class Initialized
INFO - 2019-08-26 09:24:16 --> Helper loaded: url_helper
INFO - 2019-08-26 09:24:16 --> Helper loaded: html_helper
INFO - 2019-08-26 09:24:16 --> Helper loaded: form_helper
INFO - 2019-08-26 09:24:16 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:24:16 --> Helper loaded: date_helper
INFO - 2019-08-26 09:24:16 --> Form Validation Class Initialized
INFO - 2019-08-26 09:24:16 --> Email Class Initialized
DEBUG - 2019-08-26 09:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:24:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:24:16 --> Helper loaded: url_helper
INFO - 2019-08-26 09:24:16 --> Pagination Class Initialized
INFO - 2019-08-26 09:24:16 --> Helper loaded: html_helper
INFO - 2019-08-26 09:24:16 --> Helper loaded: form_helper
INFO - 2019-08-26 09:24:16 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:24:16 --> Helper loaded: date_helper
INFO - 2019-08-26 09:24:17 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:17 --> Form Validation Class Initialized
INFO - 2019-08-26 09:24:17 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:17 --> Email Class Initialized
INFO - 2019-08-26 09:24:17 --> Controller Class Initialized
DEBUG - 2019-08-26 09:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:24:17 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:24:17 --> Final output sent to browser
DEBUG - 2019-08-26 09:24:17 --> Total execution time: 1.8226
INFO - 2019-08-26 09:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:24:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:24:17 --> Pagination Class Initialized
INFO - 2019-08-26 09:24:17 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:17 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:17 --> Controller Class Initialized
INFO - 2019-08-26 09:24:17 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:24:17 --> Final output sent to browser
DEBUG - 2019-08-26 09:24:17 --> Total execution time: 2.1977
INFO - 2019-08-26 09:24:24 --> Config Class Initialized
INFO - 2019-08-26 09:24:24 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:24:24 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:24:24 --> Utf8 Class Initialized
INFO - 2019-08-26 09:24:24 --> URI Class Initialized
INFO - 2019-08-26 09:24:24 --> Router Class Initialized
INFO - 2019-08-26 09:24:24 --> Output Class Initialized
INFO - 2019-08-26 09:24:24 --> Security Class Initialized
DEBUG - 2019-08-26 09:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:24:24 --> Input Class Initialized
INFO - 2019-08-26 09:24:24 --> Language Class Initialized
INFO - 2019-08-26 09:24:24 --> Loader Class Initialized
INFO - 2019-08-26 09:24:24 --> Helper loaded: url_helper
INFO - 2019-08-26 09:24:24 --> Helper loaded: html_helper
INFO - 2019-08-26 09:24:24 --> Helper loaded: form_helper
INFO - 2019-08-26 09:24:24 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:24:24 --> Helper loaded: date_helper
INFO - 2019-08-26 09:24:24 --> Form Validation Class Initialized
INFO - 2019-08-26 09:24:24 --> Email Class Initialized
DEBUG - 2019-08-26 09:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:24:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:24:25 --> Pagination Class Initialized
INFO - 2019-08-26 09:24:25 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:25 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:25 --> Controller Class Initialized
INFO - 2019-08-26 09:24:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:24:25 --> Final output sent to browser
DEBUG - 2019-08-26 09:24:25 --> Total execution time: 1.1360
INFO - 2019-08-26 09:24:35 --> Config Class Initialized
INFO - 2019-08-26 09:24:35 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:24:35 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:24:35 --> Utf8 Class Initialized
INFO - 2019-08-26 09:24:35 --> URI Class Initialized
INFO - 2019-08-26 09:24:35 --> Router Class Initialized
INFO - 2019-08-26 09:24:35 --> Output Class Initialized
INFO - 2019-08-26 09:24:35 --> Security Class Initialized
DEBUG - 2019-08-26 09:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:24:35 --> Input Class Initialized
INFO - 2019-08-26 09:24:35 --> Language Class Initialized
INFO - 2019-08-26 09:24:36 --> Loader Class Initialized
INFO - 2019-08-26 09:24:36 --> Helper loaded: url_helper
INFO - 2019-08-26 09:24:36 --> Helper loaded: html_helper
INFO - 2019-08-26 09:24:36 --> Helper loaded: form_helper
INFO - 2019-08-26 09:24:36 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:24:36 --> Helper loaded: date_helper
INFO - 2019-08-26 09:24:36 --> Form Validation Class Initialized
INFO - 2019-08-26 09:24:36 --> Email Class Initialized
DEBUG - 2019-08-26 09:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:24:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:24:36 --> Pagination Class Initialized
INFO - 2019-08-26 09:24:36 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:36 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:36 --> Controller Class Initialized
INFO - 2019-08-26 09:24:36 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:24:36 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:24:36 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:24:36 --> Final output sent to browser
DEBUG - 2019-08-26 09:24:36 --> Total execution time: 1.1981
INFO - 2019-08-26 09:24:37 --> Config Class Initialized
INFO - 2019-08-26 09:24:37 --> Config Class Initialized
INFO - 2019-08-26 09:24:37 --> Hooks Class Initialized
INFO - 2019-08-26 09:24:37 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:24:37 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:24:37 --> Utf8 Class Initialized
INFO - 2019-08-26 09:24:37 --> URI Class Initialized
INFO - 2019-08-26 09:24:37 --> Router Class Initialized
INFO - 2019-08-26 09:24:37 --> Output Class Initialized
INFO - 2019-08-26 09:24:37 --> Security Class Initialized
DEBUG - 2019-08-26 09:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-26 09:24:37 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:24:37 --> Input Class Initialized
INFO - 2019-08-26 09:24:37 --> Utf8 Class Initialized
INFO - 2019-08-26 09:24:37 --> Language Class Initialized
INFO - 2019-08-26 09:24:37 --> URI Class Initialized
INFO - 2019-08-26 09:24:37 --> Loader Class Initialized
INFO - 2019-08-26 09:24:37 --> Router Class Initialized
INFO - 2019-08-26 09:24:37 --> Helper loaded: url_helper
INFO - 2019-08-26 09:24:37 --> Output Class Initialized
INFO - 2019-08-26 09:24:38 --> Helper loaded: html_helper
INFO - 2019-08-26 09:24:38 --> Security Class Initialized
DEBUG - 2019-08-26 09:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:24:38 --> Input Class Initialized
INFO - 2019-08-26 09:24:38 --> Language Class Initialized
INFO - 2019-08-26 09:24:38 --> Config Class Initialized
INFO - 2019-08-26 09:24:38 --> Helper loaded: form_helper
INFO - 2019-08-26 09:24:38 --> Loader Class Initialized
INFO - 2019-08-26 09:24:38 --> Hooks Class Initialized
INFO - 2019-08-26 09:24:38 --> Helper loaded: cookie_helper
DEBUG - 2019-08-26 09:24:38 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:24:38 --> Helper loaded: url_helper
INFO - 2019-08-26 09:24:38 --> Helper loaded: date_helper
INFO - 2019-08-26 09:24:38 --> Helper loaded: html_helper
INFO - 2019-08-26 09:24:38 --> Utf8 Class Initialized
INFO - 2019-08-26 09:24:38 --> Form Validation Class Initialized
INFO - 2019-08-26 09:24:38 --> URI Class Initialized
INFO - 2019-08-26 09:24:38 --> Helper loaded: form_helper
INFO - 2019-08-26 09:24:38 --> Router Class Initialized
INFO - 2019-08-26 09:24:38 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:24:38 --> Email Class Initialized
INFO - 2019-08-26 09:24:38 --> Output Class Initialized
INFO - 2019-08-26 09:24:38 --> Helper loaded: date_helper
DEBUG - 2019-08-26 09:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:24:38 --> Form Validation Class Initialized
INFO - 2019-08-26 09:24:38 --> Security Class Initialized
INFO - 2019-08-26 09:24:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-08-26 09:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:24:38 --> Email Class Initialized
INFO - 2019-08-26 09:24:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:24:38 --> Input Class Initialized
INFO - 2019-08-26 09:24:38 --> Pagination Class Initialized
INFO - 2019-08-26 09:24:38 --> Language Class Initialized
DEBUG - 2019-08-26 09:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:24:39 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:39 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:39 --> Loader Class Initialized
INFO - 2019-08-26 09:24:39 --> Controller Class Initialized
INFO - 2019-08-26 09:24:39 --> Helper loaded: url_helper
INFO - 2019-08-26 09:24:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:24:39 --> Final output sent to browser
INFO - 2019-08-26 09:24:39 --> Helper loaded: html_helper
DEBUG - 2019-08-26 09:24:39 --> Total execution time: 2.3888
INFO - 2019-08-26 09:24:39 --> Helper loaded: form_helper
INFO - 2019-08-26 09:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:24:39 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:24:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:24:39 --> Helper loaded: date_helper
INFO - 2019-08-26 09:24:39 --> Pagination Class Initialized
INFO - 2019-08-26 09:24:39 --> Form Validation Class Initialized
INFO - 2019-08-26 09:24:39 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:39 --> Email Class Initialized
INFO - 2019-08-26 09:24:39 --> Database Driver Class Initialized
DEBUG - 2019-08-26 09:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:24:39 --> Controller Class Initialized
INFO - 2019-08-26 09:24:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:24:40 --> Final output sent to browser
DEBUG - 2019-08-26 09:24:40 --> Total execution time: 3.0135
INFO - 2019-08-26 09:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:24:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:24:40 --> Pagination Class Initialized
INFO - 2019-08-26 09:24:40 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:40 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:40 --> Controller Class Initialized
INFO - 2019-08-26 09:24:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:24:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation_group.php
INFO - 2019-08-26 09:24:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:24:40 --> Final output sent to browser
DEBUG - 2019-08-26 09:24:40 --> Total execution time: 2.3849
INFO - 2019-08-26 09:24:40 --> Config Class Initialized
INFO - 2019-08-26 09:24:40 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:24:40 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:24:40 --> Utf8 Class Initialized
INFO - 2019-08-26 09:24:40 --> URI Class Initialized
INFO - 2019-08-26 09:24:40 --> Router Class Initialized
INFO - 2019-08-26 09:24:41 --> Output Class Initialized
INFO - 2019-08-26 09:24:41 --> Security Class Initialized
DEBUG - 2019-08-26 09:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:24:41 --> Input Class Initialized
INFO - 2019-08-26 09:24:41 --> Language Class Initialized
INFO - 2019-08-26 09:24:41 --> Loader Class Initialized
INFO - 2019-08-26 09:24:41 --> Helper loaded: url_helper
INFO - 2019-08-26 09:24:41 --> Helper loaded: html_helper
INFO - 2019-08-26 09:24:41 --> Helper loaded: form_helper
INFO - 2019-08-26 09:24:41 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:24:41 --> Helper loaded: date_helper
INFO - 2019-08-26 09:24:41 --> Form Validation Class Initialized
INFO - 2019-08-26 09:24:41 --> Email Class Initialized
DEBUG - 2019-08-26 09:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:24:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:24:41 --> Pagination Class Initialized
INFO - 2019-08-26 09:24:41 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:41 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:41 --> Controller Class Initialized
INFO - 2019-08-26 09:24:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:24:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:24:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/guest.php
INFO - 2019-08-26 09:24:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:24:41 --> Final output sent to browser
DEBUG - 2019-08-26 09:24:42 --> Total execution time: 1.2358
INFO - 2019-08-26 09:24:42 --> Config Class Initialized
INFO - 2019-08-26 09:24:42 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:24:42 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:24:42 --> Utf8 Class Initialized
INFO - 2019-08-26 09:24:42 --> URI Class Initialized
INFO - 2019-08-26 09:24:42 --> Router Class Initialized
INFO - 2019-08-26 09:24:42 --> Output Class Initialized
INFO - 2019-08-26 09:24:42 --> Security Class Initialized
DEBUG - 2019-08-26 09:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:24:42 --> Input Class Initialized
INFO - 2019-08-26 09:24:42 --> Language Class Initialized
INFO - 2019-08-26 09:24:42 --> Config Class Initialized
INFO - 2019-08-26 09:24:42 --> Hooks Class Initialized
INFO - 2019-08-26 09:24:42 --> Loader Class Initialized
DEBUG - 2019-08-26 09:24:42 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:24:42 --> Helper loaded: url_helper
INFO - 2019-08-26 09:24:42 --> Utf8 Class Initialized
INFO - 2019-08-26 09:24:42 --> Helper loaded: html_helper
INFO - 2019-08-26 09:24:42 --> URI Class Initialized
INFO - 2019-08-26 09:24:42 --> Helper loaded: form_helper
INFO - 2019-08-26 09:24:43 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:24:43 --> Router Class Initialized
INFO - 2019-08-26 09:24:43 --> Helper loaded: date_helper
INFO - 2019-08-26 09:24:43 --> Output Class Initialized
INFO - 2019-08-26 09:24:43 --> Form Validation Class Initialized
INFO - 2019-08-26 09:24:43 --> Security Class Initialized
INFO - 2019-08-26 09:24:43 --> Email Class Initialized
DEBUG - 2019-08-26 09:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-26 09:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:24:43 --> Input Class Initialized
INFO - 2019-08-26 09:24:43 --> Language Class Initialized
INFO - 2019-08-26 09:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:24:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:24:43 --> Loader Class Initialized
INFO - 2019-08-26 09:24:43 --> Pagination Class Initialized
INFO - 2019-08-26 09:24:43 --> Helper loaded: url_helper
INFO - 2019-08-26 09:24:43 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:43 --> Helper loaded: html_helper
INFO - 2019-08-26 09:24:43 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:43 --> Helper loaded: form_helper
INFO - 2019-08-26 09:24:43 --> Controller Class Initialized
INFO - 2019-08-26 09:24:43 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:24:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:24:43 --> Helper loaded: date_helper
INFO - 2019-08-26 09:24:43 --> Final output sent to browser
DEBUG - 2019-08-26 09:24:43 --> Total execution time: 1.5103
INFO - 2019-08-26 09:24:43 --> Form Validation Class Initialized
INFO - 2019-08-26 09:24:43 --> Email Class Initialized
DEBUG - 2019-08-26 09:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:24:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:24:43 --> Pagination Class Initialized
INFO - 2019-08-26 09:24:44 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:44 --> Database Driver Class Initialized
INFO - 2019-08-26 09:24:44 --> Controller Class Initialized
INFO - 2019-08-26 09:24:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:24:44 --> Final output sent to browser
DEBUG - 2019-08-26 09:24:44 --> Total execution time: 1.9501
INFO - 2019-08-26 09:25:30 --> Config Class Initialized
INFO - 2019-08-26 09:25:30 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:25:30 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:25:30 --> Utf8 Class Initialized
INFO - 2019-08-26 09:25:30 --> URI Class Initialized
INFO - 2019-08-26 09:25:30 --> Router Class Initialized
INFO - 2019-08-26 09:25:30 --> Output Class Initialized
INFO - 2019-08-26 09:25:31 --> Security Class Initialized
DEBUG - 2019-08-26 09:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:25:31 --> Input Class Initialized
INFO - 2019-08-26 09:25:31 --> Language Class Initialized
INFO - 2019-08-26 09:25:31 --> Loader Class Initialized
INFO - 2019-08-26 09:25:31 --> Helper loaded: url_helper
INFO - 2019-08-26 09:25:31 --> Helper loaded: html_helper
INFO - 2019-08-26 09:25:31 --> Helper loaded: form_helper
INFO - 2019-08-26 09:25:31 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:25:31 --> Helper loaded: date_helper
INFO - 2019-08-26 09:25:31 --> Form Validation Class Initialized
INFO - 2019-08-26 09:25:31 --> Email Class Initialized
DEBUG - 2019-08-26 09:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:25:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:25:31 --> Pagination Class Initialized
INFO - 2019-08-26 09:25:31 --> Database Driver Class Initialized
INFO - 2019-08-26 09:25:31 --> Database Driver Class Initialized
INFO - 2019-08-26 09:25:31 --> Controller Class Initialized
INFO - 2019-08-26 09:25:31 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:25:31 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:25:31 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/reservation.php
INFO - 2019-08-26 09:25:31 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:25:31 --> Final output sent to browser
DEBUG - 2019-08-26 09:25:31 --> Total execution time: 1.1185
INFO - 2019-08-26 09:25:32 --> Config Class Initialized
INFO - 2019-08-26 09:25:32 --> Config Class Initialized
INFO - 2019-08-26 09:25:32 --> Hooks Class Initialized
INFO - 2019-08-26 09:25:32 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:25:32 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:25:32 --> Utf8 Class Initialized
INFO - 2019-08-26 09:25:32 --> URI Class Initialized
INFO - 2019-08-26 09:25:32 --> Router Class Initialized
INFO - 2019-08-26 09:25:32 --> Output Class Initialized
INFO - 2019-08-26 09:25:32 --> Security Class Initialized
DEBUG - 2019-08-26 09:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-26 09:25:32 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:25:32 --> Input Class Initialized
INFO - 2019-08-26 09:25:32 --> Utf8 Class Initialized
INFO - 2019-08-26 09:25:32 --> Language Class Initialized
INFO - 2019-08-26 09:25:32 --> URI Class Initialized
INFO - 2019-08-26 09:25:32 --> Loader Class Initialized
INFO - 2019-08-26 09:25:32 --> Router Class Initialized
INFO - 2019-08-26 09:25:32 --> Helper loaded: url_helper
INFO - 2019-08-26 09:25:32 --> Output Class Initialized
INFO - 2019-08-26 09:25:32 --> Helper loaded: html_helper
INFO - 2019-08-26 09:25:32 --> Security Class Initialized
INFO - 2019-08-26 09:25:33 --> Helper loaded: form_helper
INFO - 2019-08-26 09:25:33 --> Helper loaded: cookie_helper
DEBUG - 2019-08-26 09:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:25:33 --> Input Class Initialized
INFO - 2019-08-26 09:25:33 --> Helper loaded: date_helper
INFO - 2019-08-26 09:25:33 --> Language Class Initialized
INFO - 2019-08-26 09:25:33 --> Form Validation Class Initialized
INFO - 2019-08-26 09:25:33 --> Loader Class Initialized
INFO - 2019-08-26 09:25:33 --> Email Class Initialized
INFO - 2019-08-26 09:25:33 --> Helper loaded: url_helper
DEBUG - 2019-08-26 09:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:25:33 --> Helper loaded: html_helper
INFO - 2019-08-26 09:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:25:33 --> Helper loaded: form_helper
INFO - 2019-08-26 09:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:25:33 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:25:33 --> Pagination Class Initialized
INFO - 2019-08-26 09:25:33 --> Helper loaded: date_helper
INFO - 2019-08-26 09:25:33 --> Database Driver Class Initialized
INFO - 2019-08-26 09:25:33 --> Form Validation Class Initialized
INFO - 2019-08-26 09:25:33 --> Database Driver Class Initialized
INFO - 2019-08-26 09:25:33 --> Email Class Initialized
INFO - 2019-08-26 09:25:33 --> Controller Class Initialized
DEBUG - 2019-08-26 09:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:25:33 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:25:33 --> Final output sent to browser
DEBUG - 2019-08-26 09:25:33 --> Total execution time: 1.7373
INFO - 2019-08-26 09:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:25:34 --> Pagination Class Initialized
INFO - 2019-08-26 09:25:34 --> Database Driver Class Initialized
INFO - 2019-08-26 09:25:34 --> Database Driver Class Initialized
INFO - 2019-08-26 09:25:34 --> Controller Class Initialized
INFO - 2019-08-26 09:25:34 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:25:34 --> Final output sent to browser
DEBUG - 2019-08-26 09:25:34 --> Total execution time: 2.0780
INFO - 2019-08-26 09:25:42 --> Config Class Initialized
INFO - 2019-08-26 09:25:42 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:25:42 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:25:42 --> Utf8 Class Initialized
INFO - 2019-08-26 09:25:42 --> URI Class Initialized
INFO - 2019-08-26 09:25:42 --> Router Class Initialized
INFO - 2019-08-26 09:25:42 --> Output Class Initialized
INFO - 2019-08-26 09:25:42 --> Security Class Initialized
DEBUG - 2019-08-26 09:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:25:42 --> Input Class Initialized
INFO - 2019-08-26 09:25:42 --> Language Class Initialized
INFO - 2019-08-26 09:25:42 --> Loader Class Initialized
INFO - 2019-08-26 09:25:42 --> Helper loaded: url_helper
INFO - 2019-08-26 09:25:42 --> Helper loaded: html_helper
INFO - 2019-08-26 09:25:42 --> Helper loaded: form_helper
INFO - 2019-08-26 09:25:42 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:25:42 --> Helper loaded: date_helper
INFO - 2019-08-26 09:25:42 --> Form Validation Class Initialized
INFO - 2019-08-26 09:25:42 --> Email Class Initialized
DEBUG - 2019-08-26 09:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:25:43 --> Pagination Class Initialized
INFO - 2019-08-26 09:25:43 --> Database Driver Class Initialized
INFO - 2019-08-26 09:25:43 --> Database Driver Class Initialized
INFO - 2019-08-26 09:25:43 --> Controller Class Initialized
INFO - 2019-08-26 09:25:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 09:25:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 09:25:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/guest.php
INFO - 2019-08-26 09:25:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 09:25:43 --> Final output sent to browser
DEBUG - 2019-08-26 09:25:43 --> Total execution time: 1.1086
INFO - 2019-08-26 09:25:43 --> Config Class Initialized
INFO - 2019-08-26 09:25:43 --> Config Class Initialized
INFO - 2019-08-26 09:25:43 --> Hooks Class Initialized
INFO - 2019-08-26 09:25:43 --> Hooks Class Initialized
DEBUG - 2019-08-26 09:25:43 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:25:43 --> Utf8 Class Initialized
INFO - 2019-08-26 09:25:43 --> URI Class Initialized
INFO - 2019-08-26 09:25:43 --> Router Class Initialized
INFO - 2019-08-26 09:25:44 --> Output Class Initialized
INFO - 2019-08-26 09:25:44 --> Security Class Initialized
DEBUG - 2019-08-26 09:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:25:44 --> Input Class Initialized
INFO - 2019-08-26 09:25:44 --> Language Class Initialized
DEBUG - 2019-08-26 09:25:44 --> UTF-8 Support Enabled
INFO - 2019-08-26 09:25:44 --> Loader Class Initialized
INFO - 2019-08-26 09:25:44 --> Helper loaded: url_helper
INFO - 2019-08-26 09:25:44 --> Utf8 Class Initialized
INFO - 2019-08-26 09:25:44 --> Helper loaded: html_helper
INFO - 2019-08-26 09:25:44 --> URI Class Initialized
INFO - 2019-08-26 09:25:44 --> Helper loaded: form_helper
INFO - 2019-08-26 09:25:44 --> Router Class Initialized
INFO - 2019-08-26 09:25:44 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:25:44 --> Output Class Initialized
INFO - 2019-08-26 09:25:44 --> Helper loaded: date_helper
INFO - 2019-08-26 09:25:44 --> Security Class Initialized
INFO - 2019-08-26 09:25:44 --> Form Validation Class Initialized
DEBUG - 2019-08-26 09:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 09:25:44 --> Input Class Initialized
INFO - 2019-08-26 09:25:44 --> Email Class Initialized
INFO - 2019-08-26 09:25:44 --> Language Class Initialized
DEBUG - 2019-08-26 09:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:25:44 --> Loader Class Initialized
INFO - 2019-08-26 09:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:25:45 --> Helper loaded: url_helper
INFO - 2019-08-26 09:25:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:25:45 --> Helper loaded: html_helper
INFO - 2019-08-26 09:25:45 --> Pagination Class Initialized
INFO - 2019-08-26 09:25:45 --> Helper loaded: form_helper
INFO - 2019-08-26 09:25:45 --> Database Driver Class Initialized
INFO - 2019-08-26 09:25:45 --> Helper loaded: cookie_helper
INFO - 2019-08-26 09:25:45 --> Database Driver Class Initialized
INFO - 2019-08-26 09:25:45 --> Helper loaded: date_helper
INFO - 2019-08-26 09:25:45 --> Controller Class Initialized
INFO - 2019-08-26 09:25:45 --> Form Validation Class Initialized
INFO - 2019-08-26 09:25:45 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:25:45 --> Final output sent to browser
INFO - 2019-08-26 09:25:45 --> Email Class Initialized
DEBUG - 2019-08-26 09:25:45 --> Total execution time: 1.6383
DEBUG - 2019-08-26 09:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 09:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 09:25:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 09:25:45 --> Pagination Class Initialized
INFO - 2019-08-26 09:25:45 --> Database Driver Class Initialized
INFO - 2019-08-26 09:25:45 --> Database Driver Class Initialized
INFO - 2019-08-26 09:25:45 --> Controller Class Initialized
INFO - 2019-08-26 09:25:45 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 09:25:45 --> Final output sent to browser
DEBUG - 2019-08-26 09:25:45 --> Total execution time: 2.0183
INFO - 2019-08-26 22:51:05 --> Config Class Initialized
INFO - 2019-08-26 22:51:06 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:51:06 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:51:06 --> Utf8 Class Initialized
INFO - 2019-08-26 22:51:06 --> URI Class Initialized
INFO - 2019-08-26 22:51:06 --> Router Class Initialized
INFO - 2019-08-26 22:51:06 --> Output Class Initialized
INFO - 2019-08-26 22:51:06 --> Security Class Initialized
DEBUG - 2019-08-26 22:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:51:06 --> Input Class Initialized
INFO - 2019-08-26 22:51:06 --> Language Class Initialized
INFO - 2019-08-26 22:51:07 --> Loader Class Initialized
INFO - 2019-08-26 22:51:07 --> Helper loaded: url_helper
INFO - 2019-08-26 22:51:07 --> Helper loaded: html_helper
INFO - 2019-08-26 22:51:07 --> Helper loaded: form_helper
INFO - 2019-08-26 22:51:07 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:51:07 --> Helper loaded: date_helper
INFO - 2019-08-26 22:51:07 --> Form Validation Class Initialized
INFO - 2019-08-26 22:51:07 --> Email Class Initialized
DEBUG - 2019-08-26 22:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:51:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:51:08 --> Pagination Class Initialized
INFO - 2019-08-26 22:51:08 --> Database Driver Class Initialized
INFO - 2019-08-26 22:51:08 --> Database Driver Class Initialized
INFO - 2019-08-26 22:51:09 --> Controller Class Initialized
INFO - 2019-08-26 22:51:09 --> Config Class Initialized
INFO - 2019-08-26 22:51:09 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:51:09 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:51:09 --> Utf8 Class Initialized
INFO - 2019-08-26 22:51:09 --> URI Class Initialized
INFO - 2019-08-26 22:51:09 --> Router Class Initialized
INFO - 2019-08-26 22:51:09 --> Output Class Initialized
INFO - 2019-08-26 22:51:09 --> Security Class Initialized
DEBUG - 2019-08-26 22:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:51:09 --> Input Class Initialized
INFO - 2019-08-26 22:51:09 --> Language Class Initialized
INFO - 2019-08-26 22:51:09 --> Loader Class Initialized
INFO - 2019-08-26 22:51:09 --> Helper loaded: url_helper
INFO - 2019-08-26 22:51:09 --> Helper loaded: html_helper
INFO - 2019-08-26 22:51:09 --> Helper loaded: form_helper
INFO - 2019-08-26 22:51:09 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:51:09 --> Helper loaded: date_helper
INFO - 2019-08-26 22:51:09 --> Form Validation Class Initialized
INFO - 2019-08-26 22:51:10 --> Email Class Initialized
DEBUG - 2019-08-26 22:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:51:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:51:10 --> Pagination Class Initialized
INFO - 2019-08-26 22:51:10 --> Database Driver Class Initialized
INFO - 2019-08-26 22:51:10 --> Database Driver Class Initialized
INFO - 2019-08-26 22:51:10 --> Controller Class Initialized
INFO - 2019-08-26 22:51:10 --> File loaded: C:\wamp\www\pridehotel\application\views\app/login.php
INFO - 2019-08-26 22:51:10 --> Final output sent to browser
DEBUG - 2019-08-26 22:51:10 --> Total execution time: 1.0433
INFO - 2019-08-26 22:52:43 --> Config Class Initialized
INFO - 2019-08-26 22:52:43 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:52:44 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:52:44 --> Utf8 Class Initialized
INFO - 2019-08-26 22:52:44 --> URI Class Initialized
INFO - 2019-08-26 22:52:44 --> Router Class Initialized
INFO - 2019-08-26 22:52:44 --> Output Class Initialized
INFO - 2019-08-26 22:52:44 --> Security Class Initialized
DEBUG - 2019-08-26 22:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:52:44 --> Input Class Initialized
INFO - 2019-08-26 22:52:44 --> Language Class Initialized
INFO - 2019-08-26 22:52:44 --> Loader Class Initialized
INFO - 2019-08-26 22:52:44 --> Helper loaded: url_helper
INFO - 2019-08-26 22:52:44 --> Helper loaded: html_helper
INFO - 2019-08-26 22:52:44 --> Helper loaded: form_helper
INFO - 2019-08-26 22:52:44 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:52:44 --> Helper loaded: date_helper
INFO - 2019-08-26 22:52:44 --> Form Validation Class Initialized
INFO - 2019-08-26 22:52:44 --> Email Class Initialized
DEBUG - 2019-08-26 22:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:52:44 --> Pagination Class Initialized
INFO - 2019-08-26 22:52:44 --> Database Driver Class Initialized
INFO - 2019-08-26 22:52:44 --> Database Driver Class Initialized
INFO - 2019-08-26 22:52:44 --> Controller Class Initialized
INFO - 2019-08-26 22:52:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 22:52:44 --> Config Class Initialized
INFO - 2019-08-26 22:52:44 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:52:44 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:52:44 --> Utf8 Class Initialized
INFO - 2019-08-26 22:52:44 --> URI Class Initialized
INFO - 2019-08-26 22:52:44 --> Router Class Initialized
INFO - 2019-08-26 22:52:44 --> Output Class Initialized
INFO - 2019-08-26 22:52:45 --> Security Class Initialized
DEBUG - 2019-08-26 22:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:52:45 --> Input Class Initialized
INFO - 2019-08-26 22:52:45 --> Language Class Initialized
INFO - 2019-08-26 22:52:45 --> Loader Class Initialized
INFO - 2019-08-26 22:52:45 --> Helper loaded: url_helper
INFO - 2019-08-26 22:52:45 --> Helper loaded: html_helper
INFO - 2019-08-26 22:52:45 --> Helper loaded: form_helper
INFO - 2019-08-26 22:52:45 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:52:45 --> Helper loaded: date_helper
INFO - 2019-08-26 22:52:45 --> Form Validation Class Initialized
INFO - 2019-08-26 22:52:45 --> Email Class Initialized
DEBUG - 2019-08-26 22:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:52:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:52:45 --> Pagination Class Initialized
INFO - 2019-08-26 22:52:45 --> Database Driver Class Initialized
INFO - 2019-08-26 22:52:45 --> Database Driver Class Initialized
INFO - 2019-08-26 22:52:45 --> Controller Class Initialized
INFO - 2019-08-26 22:52:45 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 22:52:45 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 22:52:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 22:52:46 --> Final output sent to browser
DEBUG - 2019-08-26 22:52:46 --> Total execution time: 1.2888
INFO - 2019-08-26 22:52:46 --> Config Class Initialized
INFO - 2019-08-26 22:52:46 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:52:46 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:52:46 --> Utf8 Class Initialized
INFO - 2019-08-26 22:52:46 --> URI Class Initialized
INFO - 2019-08-26 22:52:46 --> Router Class Initialized
INFO - 2019-08-26 22:52:47 --> Output Class Initialized
INFO - 2019-08-26 22:52:47 --> Security Class Initialized
DEBUG - 2019-08-26 22:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:52:47 --> Input Class Initialized
INFO - 2019-08-26 22:52:47 --> Language Class Initialized
INFO - 2019-08-26 22:52:47 --> Config Class Initialized
INFO - 2019-08-26 22:52:47 --> Hooks Class Initialized
INFO - 2019-08-26 22:52:47 --> Loader Class Initialized
DEBUG - 2019-08-26 22:52:47 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:52:47 --> Utf8 Class Initialized
INFO - 2019-08-26 22:52:47 --> Helper loaded: url_helper
INFO - 2019-08-26 22:52:47 --> Helper loaded: html_helper
INFO - 2019-08-26 22:52:47 --> URI Class Initialized
INFO - 2019-08-26 22:52:47 --> Helper loaded: form_helper
INFO - 2019-08-26 22:52:47 --> Router Class Initialized
INFO - 2019-08-26 22:52:47 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:52:47 --> Output Class Initialized
INFO - 2019-08-26 22:52:47 --> Helper loaded: date_helper
INFO - 2019-08-26 22:52:47 --> Security Class Initialized
INFO - 2019-08-26 22:52:47 --> Form Validation Class Initialized
DEBUG - 2019-08-26 22:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:52:47 --> Input Class Initialized
INFO - 2019-08-26 22:52:47 --> Language Class Initialized
INFO - 2019-08-26 22:52:47 --> Email Class Initialized
INFO - 2019-08-26 22:52:47 --> Loader Class Initialized
DEBUG - 2019-08-26 22:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:52:47 --> Helper loaded: url_helper
INFO - 2019-08-26 22:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:52:47 --> Helper loaded: html_helper
INFO - 2019-08-26 22:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:52:48 --> Helper loaded: form_helper
INFO - 2019-08-26 22:52:48 --> Pagination Class Initialized
INFO - 2019-08-26 22:52:48 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:52:48 --> Database Driver Class Initialized
INFO - 2019-08-26 22:52:48 --> Helper loaded: date_helper
INFO - 2019-08-26 22:52:48 --> Database Driver Class Initialized
INFO - 2019-08-26 22:52:48 --> Form Validation Class Initialized
INFO - 2019-08-26 22:52:48 --> Controller Class Initialized
INFO - 2019-08-26 22:52:48 --> Email Class Initialized
DEBUG - 2019-08-26 22:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:52:48 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 22:52:48 --> Final output sent to browser
DEBUG - 2019-08-26 22:52:48 --> Total execution time: 1.7026
INFO - 2019-08-26 22:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:52:48 --> Pagination Class Initialized
INFO - 2019-08-26 22:52:48 --> Database Driver Class Initialized
INFO - 2019-08-26 22:52:48 --> Database Driver Class Initialized
INFO - 2019-08-26 22:52:48 --> Controller Class Initialized
INFO - 2019-08-26 22:52:48 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 22:52:48 --> Final output sent to browser
DEBUG - 2019-08-26 22:52:48 --> Total execution time: 1.9675
INFO - 2019-08-26 22:52:55 --> Config Class Initialized
INFO - 2019-08-26 22:52:55 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:52:55 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:52:55 --> Utf8 Class Initialized
INFO - 2019-08-26 22:52:55 --> URI Class Initialized
INFO - 2019-08-26 22:52:55 --> Router Class Initialized
INFO - 2019-08-26 22:52:55 --> Output Class Initialized
INFO - 2019-08-26 22:52:55 --> Security Class Initialized
DEBUG - 2019-08-26 22:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:52:55 --> Input Class Initialized
INFO - 2019-08-26 22:52:55 --> Language Class Initialized
INFO - 2019-08-26 22:52:55 --> Loader Class Initialized
INFO - 2019-08-26 22:52:56 --> Helper loaded: url_helper
INFO - 2019-08-26 22:52:56 --> Helper loaded: html_helper
INFO - 2019-08-26 22:52:56 --> Helper loaded: form_helper
INFO - 2019-08-26 22:52:56 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:52:56 --> Helper loaded: date_helper
INFO - 2019-08-26 22:52:56 --> Form Validation Class Initialized
INFO - 2019-08-26 22:52:56 --> Email Class Initialized
DEBUG - 2019-08-26 22:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:52:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:52:56 --> Pagination Class Initialized
INFO - 2019-08-26 22:52:56 --> Database Driver Class Initialized
INFO - 2019-08-26 22:52:56 --> Database Driver Class Initialized
INFO - 2019-08-26 22:52:56 --> Controller Class Initialized
INFO - 2019-08-26 22:52:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 22:52:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 22:52:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 22:52:56 --> Final output sent to browser
DEBUG - 2019-08-26 22:52:56 --> Total execution time: 0.8070
INFO - 2019-08-26 22:52:56 --> Config Class Initialized
INFO - 2019-08-26 22:52:56 --> Config Class Initialized
INFO - 2019-08-26 22:52:56 --> Hooks Class Initialized
INFO - 2019-08-26 22:52:56 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:52:56 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:52:56 --> Utf8 Class Initialized
INFO - 2019-08-26 22:52:57 --> URI Class Initialized
INFO - 2019-08-26 22:52:57 --> Router Class Initialized
INFO - 2019-08-26 22:52:57 --> Output Class Initialized
INFO - 2019-08-26 22:52:57 --> Security Class Initialized
DEBUG - 2019-08-26 22:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-26 22:52:57 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:52:57 --> Input Class Initialized
INFO - 2019-08-26 22:52:57 --> Utf8 Class Initialized
INFO - 2019-08-26 22:52:57 --> Language Class Initialized
INFO - 2019-08-26 22:52:57 --> URI Class Initialized
INFO - 2019-08-26 22:52:57 --> Loader Class Initialized
INFO - 2019-08-26 22:52:57 --> Router Class Initialized
INFO - 2019-08-26 22:52:57 --> Output Class Initialized
INFO - 2019-08-26 22:52:57 --> Helper loaded: url_helper
INFO - 2019-08-26 22:52:57 --> Security Class Initialized
INFO - 2019-08-26 22:52:57 --> Helper loaded: html_helper
DEBUG - 2019-08-26 22:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:52:57 --> Input Class Initialized
INFO - 2019-08-26 22:52:57 --> Helper loaded: form_helper
INFO - 2019-08-26 22:52:57 --> Language Class Initialized
INFO - 2019-08-26 22:52:57 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:52:58 --> Loader Class Initialized
INFO - 2019-08-26 22:52:58 --> Helper loaded: url_helper
INFO - 2019-08-26 22:52:58 --> Helper loaded: date_helper
INFO - 2019-08-26 22:52:58 --> Helper loaded: html_helper
INFO - 2019-08-26 22:52:58 --> Form Validation Class Initialized
INFO - 2019-08-26 22:52:58 --> Helper loaded: form_helper
INFO - 2019-08-26 22:52:58 --> Email Class Initialized
INFO - 2019-08-26 22:52:58 --> Helper loaded: cookie_helper
DEBUG - 2019-08-26 22:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:52:58 --> Helper loaded: date_helper
INFO - 2019-08-26 22:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:52:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:52:58 --> Form Validation Class Initialized
INFO - 2019-08-26 22:52:58 --> Pagination Class Initialized
INFO - 2019-08-26 22:52:58 --> Email Class Initialized
INFO - 2019-08-26 22:52:58 --> Database Driver Class Initialized
DEBUG - 2019-08-26 22:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:52:58 --> Database Driver Class Initialized
INFO - 2019-08-26 22:52:58 --> Controller Class Initialized
INFO - 2019-08-26 22:52:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 22:52:58 --> Final output sent to browser
DEBUG - 2019-08-26 22:52:58 --> Total execution time: 1.7477
INFO - 2019-08-26 22:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:52:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:52:58 --> Pagination Class Initialized
INFO - 2019-08-26 22:52:58 --> Database Driver Class Initialized
INFO - 2019-08-26 22:52:58 --> Database Driver Class Initialized
INFO - 2019-08-26 22:52:58 --> Controller Class Initialized
INFO - 2019-08-26 22:52:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 22:52:58 --> Final output sent to browser
DEBUG - 2019-08-26 22:52:58 --> Total execution time: 2.0624
INFO - 2019-08-26 22:52:59 --> Config Class Initialized
INFO - 2019-08-26 22:52:59 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:52:59 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:52:59 --> Utf8 Class Initialized
INFO - 2019-08-26 22:52:59 --> URI Class Initialized
INFO - 2019-08-26 22:52:59 --> Router Class Initialized
INFO - 2019-08-26 22:52:59 --> Output Class Initialized
INFO - 2019-08-26 22:52:59 --> Security Class Initialized
DEBUG - 2019-08-26 22:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:52:59 --> Input Class Initialized
INFO - 2019-08-26 22:52:59 --> Language Class Initialized
INFO - 2019-08-26 22:52:59 --> Loader Class Initialized
INFO - 2019-08-26 22:52:59 --> Helper loaded: url_helper
INFO - 2019-08-26 22:52:59 --> Helper loaded: html_helper
INFO - 2019-08-26 22:52:59 --> Helper loaded: form_helper
INFO - 2019-08-26 22:52:59 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:52:59 --> Helper loaded: date_helper
INFO - 2019-08-26 22:52:59 --> Form Validation Class Initialized
INFO - 2019-08-26 22:52:59 --> Email Class Initialized
DEBUG - 2019-08-26 22:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:52:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:52:59 --> Pagination Class Initialized
INFO - 2019-08-26 22:52:59 --> Database Driver Class Initialized
INFO - 2019-08-26 22:52:59 --> Database Driver Class Initialized
INFO - 2019-08-26 22:52:59 --> Controller Class Initialized
INFO - 2019-08-26 22:52:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 22:52:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 22:53:00 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/guest.php
INFO - 2019-08-26 22:53:00 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 22:53:00 --> Final output sent to browser
DEBUG - 2019-08-26 22:53:00 --> Total execution time: 1.1487
INFO - 2019-08-26 22:53:00 --> Config Class Initialized
INFO - 2019-08-26 22:53:00 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:53:00 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:53:00 --> Config Class Initialized
INFO - 2019-08-26 22:53:00 --> Utf8 Class Initialized
INFO - 2019-08-26 22:53:00 --> URI Class Initialized
INFO - 2019-08-26 22:53:00 --> Router Class Initialized
INFO - 2019-08-26 22:53:00 --> Output Class Initialized
INFO - 2019-08-26 22:53:00 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:53:00 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:53:00 --> Utf8 Class Initialized
INFO - 2019-08-26 22:53:01 --> URI Class Initialized
INFO - 2019-08-26 22:53:01 --> Security Class Initialized
INFO - 2019-08-26 22:53:01 --> Router Class Initialized
DEBUG - 2019-08-26 22:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:53:01 --> Output Class Initialized
INFO - 2019-08-26 22:53:01 --> Input Class Initialized
INFO - 2019-08-26 22:53:01 --> Security Class Initialized
INFO - 2019-08-26 22:53:01 --> Language Class Initialized
DEBUG - 2019-08-26 22:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:53:01 --> Input Class Initialized
INFO - 2019-08-26 22:53:01 --> Loader Class Initialized
INFO - 2019-08-26 22:53:01 --> Language Class Initialized
INFO - 2019-08-26 22:53:01 --> Helper loaded: url_helper
INFO - 2019-08-26 22:53:01 --> Loader Class Initialized
INFO - 2019-08-26 22:53:01 --> Helper loaded: html_helper
INFO - 2019-08-26 22:53:01 --> Helper loaded: url_helper
INFO - 2019-08-26 22:53:01 --> Helper loaded: form_helper
INFO - 2019-08-26 22:53:01 --> Helper loaded: html_helper
INFO - 2019-08-26 22:53:01 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:53:01 --> Helper loaded: form_helper
INFO - 2019-08-26 22:53:01 --> Helper loaded: date_helper
INFO - 2019-08-26 22:53:01 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:53:01 --> Helper loaded: date_helper
INFO - 2019-08-26 22:53:01 --> Form Validation Class Initialized
INFO - 2019-08-26 22:53:01 --> Form Validation Class Initialized
INFO - 2019-08-26 22:53:01 --> Email Class Initialized
INFO - 2019-08-26 22:53:01 --> Email Class Initialized
DEBUG - 2019-08-26 22:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-26 22:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:53:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:53:01 --> Pagination Class Initialized
INFO - 2019-08-26 22:53:02 --> Database Driver Class Initialized
INFO - 2019-08-26 22:53:02 --> Database Driver Class Initialized
INFO - 2019-08-26 22:53:02 --> Controller Class Initialized
INFO - 2019-08-26 22:53:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 22:53:02 --> Final output sent to browser
DEBUG - 2019-08-26 22:53:02 --> Total execution time: 1.7267
INFO - 2019-08-26 22:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:53:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:53:02 --> Pagination Class Initialized
INFO - 2019-08-26 22:53:02 --> Database Driver Class Initialized
INFO - 2019-08-26 22:53:02 --> Database Driver Class Initialized
INFO - 2019-08-26 22:53:02 --> Controller Class Initialized
INFO - 2019-08-26 22:53:02 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 22:53:02 --> Final output sent to browser
DEBUG - 2019-08-26 22:53:02 --> Total execution time: 1.9172
INFO - 2019-08-26 22:53:05 --> Config Class Initialized
INFO - 2019-08-26 22:53:05 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:53:05 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:53:05 --> Utf8 Class Initialized
INFO - 2019-08-26 22:53:05 --> URI Class Initialized
INFO - 2019-08-26 22:53:05 --> Router Class Initialized
INFO - 2019-08-26 22:53:05 --> Output Class Initialized
INFO - 2019-08-26 22:53:05 --> Security Class Initialized
DEBUG - 2019-08-26 22:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:53:05 --> Input Class Initialized
INFO - 2019-08-26 22:53:05 --> Language Class Initialized
INFO - 2019-08-26 22:53:05 --> Loader Class Initialized
INFO - 2019-08-26 22:53:05 --> Helper loaded: url_helper
INFO - 2019-08-26 22:53:05 --> Helper loaded: html_helper
INFO - 2019-08-26 22:53:05 --> Helper loaded: form_helper
INFO - 2019-08-26 22:53:06 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:53:06 --> Helper loaded: date_helper
INFO - 2019-08-26 22:53:06 --> Form Validation Class Initialized
INFO - 2019-08-26 22:53:06 --> Email Class Initialized
DEBUG - 2019-08-26 22:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:53:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:53:06 --> Pagination Class Initialized
INFO - 2019-08-26 22:53:06 --> Database Driver Class Initialized
INFO - 2019-08-26 22:53:06 --> Database Driver Class Initialized
INFO - 2019-08-26 22:53:06 --> Controller Class Initialized
INFO - 2019-08-26 22:53:06 --> Final output sent to browser
DEBUG - 2019-08-26 22:53:06 --> Total execution time: 0.8159
INFO - 2019-08-26 22:53:37 --> Config Class Initialized
INFO - 2019-08-26 22:53:37 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:53:37 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:53:37 --> Utf8 Class Initialized
INFO - 2019-08-26 22:53:37 --> URI Class Initialized
INFO - 2019-08-26 22:53:37 --> Router Class Initialized
INFO - 2019-08-26 22:53:37 --> Output Class Initialized
INFO - 2019-08-26 22:53:37 --> Security Class Initialized
DEBUG - 2019-08-26 22:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:53:37 --> Input Class Initialized
INFO - 2019-08-26 22:53:38 --> Language Class Initialized
INFO - 2019-08-26 22:53:38 --> Loader Class Initialized
INFO - 2019-08-26 22:53:38 --> Helper loaded: url_helper
INFO - 2019-08-26 22:53:38 --> Helper loaded: html_helper
INFO - 2019-08-26 22:53:38 --> Helper loaded: form_helper
INFO - 2019-08-26 22:53:38 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:53:38 --> Helper loaded: date_helper
INFO - 2019-08-26 22:53:38 --> Form Validation Class Initialized
INFO - 2019-08-26 22:53:38 --> Email Class Initialized
DEBUG - 2019-08-26 22:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:53:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:53:38 --> Pagination Class Initialized
INFO - 2019-08-26 22:53:38 --> Database Driver Class Initialized
INFO - 2019-08-26 22:53:38 --> Database Driver Class Initialized
INFO - 2019-08-26 22:53:38 --> Controller Class Initialized
INFO - 2019-08-26 22:53:38 --> Final output sent to browser
DEBUG - 2019-08-26 22:53:38 --> Total execution time: 0.7478
INFO - 2019-08-26 22:53:42 --> Config Class Initialized
INFO - 2019-08-26 22:53:42 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:53:42 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:53:42 --> Utf8 Class Initialized
INFO - 2019-08-26 22:53:42 --> URI Class Initialized
INFO - 2019-08-26 22:53:42 --> Router Class Initialized
INFO - 2019-08-26 22:53:42 --> Output Class Initialized
INFO - 2019-08-26 22:53:42 --> Security Class Initialized
DEBUG - 2019-08-26 22:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:53:42 --> Input Class Initialized
INFO - 2019-08-26 22:53:42 --> Language Class Initialized
INFO - 2019-08-26 22:53:42 --> Loader Class Initialized
INFO - 2019-08-26 22:53:42 --> Helper loaded: url_helper
INFO - 2019-08-26 22:53:42 --> Helper loaded: html_helper
INFO - 2019-08-26 22:53:42 --> Helper loaded: form_helper
INFO - 2019-08-26 22:53:42 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:53:42 --> Helper loaded: date_helper
INFO - 2019-08-26 22:53:43 --> Form Validation Class Initialized
INFO - 2019-08-26 22:53:43 --> Email Class Initialized
DEBUG - 2019-08-26 22:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:53:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:53:43 --> Pagination Class Initialized
INFO - 2019-08-26 22:53:43 --> Database Driver Class Initialized
INFO - 2019-08-26 22:53:43 --> Database Driver Class Initialized
INFO - 2019-08-26 22:53:43 --> Controller Class Initialized
INFO - 2019-08-26 22:53:43 --> Final output sent to browser
DEBUG - 2019-08-26 22:53:43 --> Total execution time: 0.7328
INFO - 2019-08-26 22:54:07 --> Config Class Initialized
INFO - 2019-08-26 22:54:07 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:54:07 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:54:07 --> Utf8 Class Initialized
INFO - 2019-08-26 22:54:07 --> URI Class Initialized
INFO - 2019-08-26 22:54:07 --> Router Class Initialized
INFO - 2019-08-26 22:54:07 --> Output Class Initialized
INFO - 2019-08-26 22:54:07 --> Security Class Initialized
DEBUG - 2019-08-26 22:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:54:07 --> Input Class Initialized
INFO - 2019-08-26 22:54:07 --> Language Class Initialized
INFO - 2019-08-26 22:54:07 --> Loader Class Initialized
INFO - 2019-08-26 22:54:07 --> Helper loaded: url_helper
INFO - 2019-08-26 22:54:07 --> Helper loaded: html_helper
INFO - 2019-08-26 22:54:07 --> Helper loaded: form_helper
INFO - 2019-08-26 22:54:07 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:54:07 --> Helper loaded: date_helper
INFO - 2019-08-26 22:54:07 --> Form Validation Class Initialized
INFO - 2019-08-26 22:54:08 --> Email Class Initialized
DEBUG - 2019-08-26 22:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:54:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:54:08 --> Pagination Class Initialized
INFO - 2019-08-26 22:54:08 --> Database Driver Class Initialized
INFO - 2019-08-26 22:54:08 --> Database Driver Class Initialized
INFO - 2019-08-26 22:54:08 --> Controller Class Initialized
INFO - 2019-08-26 22:54:08 --> Final output sent to browser
DEBUG - 2019-08-26 22:54:08 --> Total execution time: 0.7438
INFO - 2019-08-26 22:54:14 --> Config Class Initialized
INFO - 2019-08-26 22:54:14 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:54:14 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:54:14 --> Utf8 Class Initialized
INFO - 2019-08-26 22:54:14 --> URI Class Initialized
INFO - 2019-08-26 22:54:14 --> Router Class Initialized
INFO - 2019-08-26 22:54:14 --> Output Class Initialized
INFO - 2019-08-26 22:54:14 --> Security Class Initialized
DEBUG - 2019-08-26 22:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:54:14 --> Input Class Initialized
INFO - 2019-08-26 22:54:14 --> Language Class Initialized
INFO - 2019-08-26 22:54:14 --> Loader Class Initialized
INFO - 2019-08-26 22:54:15 --> Helper loaded: url_helper
INFO - 2019-08-26 22:54:15 --> Helper loaded: html_helper
INFO - 2019-08-26 22:54:15 --> Helper loaded: form_helper
INFO - 2019-08-26 22:54:15 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:54:15 --> Helper loaded: date_helper
INFO - 2019-08-26 22:54:15 --> Form Validation Class Initialized
INFO - 2019-08-26 22:54:15 --> Email Class Initialized
DEBUG - 2019-08-26 22:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:54:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:54:15 --> Pagination Class Initialized
INFO - 2019-08-26 22:54:15 --> Database Driver Class Initialized
INFO - 2019-08-26 22:54:15 --> Database Driver Class Initialized
INFO - 2019-08-26 22:54:15 --> Controller Class Initialized
INFO - 2019-08-26 22:54:15 --> Final output sent to browser
DEBUG - 2019-08-26 22:54:15 --> Total execution time: 0.9291
INFO - 2019-08-26 22:54:36 --> Config Class Initialized
INFO - 2019-08-26 22:54:36 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:54:36 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:54:36 --> Utf8 Class Initialized
INFO - 2019-08-26 22:54:36 --> URI Class Initialized
INFO - 2019-08-26 22:54:36 --> Router Class Initialized
INFO - 2019-08-26 22:54:36 --> Output Class Initialized
INFO - 2019-08-26 22:54:36 --> Security Class Initialized
DEBUG - 2019-08-26 22:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:54:36 --> Input Class Initialized
INFO - 2019-08-26 22:54:36 --> Language Class Initialized
INFO - 2019-08-26 22:54:36 --> Loader Class Initialized
INFO - 2019-08-26 22:54:36 --> Helper loaded: url_helper
INFO - 2019-08-26 22:54:36 --> Helper loaded: html_helper
INFO - 2019-08-26 22:54:36 --> Helper loaded: form_helper
INFO - 2019-08-26 22:54:36 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:54:36 --> Helper loaded: date_helper
INFO - 2019-08-26 22:54:36 --> Form Validation Class Initialized
INFO - 2019-08-26 22:54:36 --> Email Class Initialized
DEBUG - 2019-08-26 22:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:54:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:54:36 --> Pagination Class Initialized
INFO - 2019-08-26 22:54:36 --> Database Driver Class Initialized
INFO - 2019-08-26 22:54:36 --> Database Driver Class Initialized
INFO - 2019-08-26 22:54:36 --> Controller Class Initialized
INFO - 2019-08-26 22:54:36 --> Final output sent to browser
DEBUG - 2019-08-26 22:54:36 --> Total execution time: 0.6574
INFO - 2019-08-26 22:54:42 --> Config Class Initialized
INFO - 2019-08-26 22:54:42 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:54:42 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:54:42 --> Utf8 Class Initialized
INFO - 2019-08-26 22:54:42 --> URI Class Initialized
INFO - 2019-08-26 22:54:42 --> Router Class Initialized
INFO - 2019-08-26 22:54:42 --> Output Class Initialized
INFO - 2019-08-26 22:54:42 --> Security Class Initialized
DEBUG - 2019-08-26 22:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:54:42 --> Input Class Initialized
INFO - 2019-08-26 22:54:42 --> Language Class Initialized
INFO - 2019-08-26 22:54:42 --> Loader Class Initialized
INFO - 2019-08-26 22:54:42 --> Helper loaded: url_helper
INFO - 2019-08-26 22:54:42 --> Helper loaded: html_helper
INFO - 2019-08-26 22:54:42 --> Helper loaded: form_helper
INFO - 2019-08-26 22:54:42 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:54:42 --> Helper loaded: date_helper
INFO - 2019-08-26 22:54:42 --> Form Validation Class Initialized
INFO - 2019-08-26 22:54:42 --> Email Class Initialized
DEBUG - 2019-08-26 22:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:54:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:54:43 --> Pagination Class Initialized
INFO - 2019-08-26 22:54:43 --> Database Driver Class Initialized
INFO - 2019-08-26 22:54:43 --> Database Driver Class Initialized
INFO - 2019-08-26 22:54:43 --> Controller Class Initialized
INFO - 2019-08-26 22:54:43 --> Final output sent to browser
DEBUG - 2019-08-26 22:54:43 --> Total execution time: 0.6365
INFO - 2019-08-26 22:54:55 --> Config Class Initialized
INFO - 2019-08-26 22:54:55 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:54:55 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:54:55 --> Utf8 Class Initialized
INFO - 2019-08-26 22:54:55 --> URI Class Initialized
INFO - 2019-08-26 22:54:55 --> Router Class Initialized
INFO - 2019-08-26 22:54:55 --> Output Class Initialized
INFO - 2019-08-26 22:54:55 --> Security Class Initialized
DEBUG - 2019-08-26 22:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:54:55 --> Input Class Initialized
INFO - 2019-08-26 22:54:55 --> Language Class Initialized
INFO - 2019-08-26 22:54:55 --> Loader Class Initialized
INFO - 2019-08-26 22:54:55 --> Helper loaded: url_helper
INFO - 2019-08-26 22:54:55 --> Helper loaded: html_helper
INFO - 2019-08-26 22:54:55 --> Helper loaded: form_helper
INFO - 2019-08-26 22:54:55 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:54:55 --> Helper loaded: date_helper
INFO - 2019-08-26 22:54:55 --> Form Validation Class Initialized
INFO - 2019-08-26 22:54:55 --> Email Class Initialized
DEBUG - 2019-08-26 22:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:54:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:54:56 --> Pagination Class Initialized
INFO - 2019-08-26 22:54:56 --> Database Driver Class Initialized
INFO - 2019-08-26 22:54:56 --> Database Driver Class Initialized
INFO - 2019-08-26 22:54:56 --> Controller Class Initialized
INFO - 2019-08-26 22:54:56 --> Final output sent to browser
DEBUG - 2019-08-26 22:54:56 --> Total execution time: 1.1674
INFO - 2019-08-26 22:55:15 --> Config Class Initialized
INFO - 2019-08-26 22:55:15 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:55:15 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:55:15 --> Utf8 Class Initialized
INFO - 2019-08-26 22:55:15 --> URI Class Initialized
INFO - 2019-08-26 22:55:15 --> Router Class Initialized
INFO - 2019-08-26 22:55:15 --> Output Class Initialized
INFO - 2019-08-26 22:55:15 --> Security Class Initialized
DEBUG - 2019-08-26 22:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:55:15 --> Input Class Initialized
INFO - 2019-08-26 22:55:15 --> Language Class Initialized
INFO - 2019-08-26 22:55:16 --> Loader Class Initialized
INFO - 2019-08-26 22:55:16 --> Helper loaded: url_helper
INFO - 2019-08-26 22:55:16 --> Helper loaded: html_helper
INFO - 2019-08-26 22:55:16 --> Helper loaded: form_helper
INFO - 2019-08-26 22:55:16 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:55:16 --> Helper loaded: date_helper
INFO - 2019-08-26 22:55:16 --> Form Validation Class Initialized
INFO - 2019-08-26 22:55:16 --> Email Class Initialized
DEBUG - 2019-08-26 22:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:55:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:55:16 --> Pagination Class Initialized
INFO - 2019-08-26 22:55:17 --> Database Driver Class Initialized
INFO - 2019-08-26 22:55:17 --> Database Driver Class Initialized
INFO - 2019-08-26 22:55:17 --> Controller Class Initialized
INFO - 2019-08-26 22:55:17 --> Final output sent to browser
DEBUG - 2019-08-26 22:55:17 --> Total execution time: 2.2929
INFO - 2019-08-26 22:55:40 --> Config Class Initialized
INFO - 2019-08-26 22:55:40 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:55:40 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:55:40 --> Utf8 Class Initialized
INFO - 2019-08-26 22:55:40 --> URI Class Initialized
INFO - 2019-08-26 22:55:40 --> Router Class Initialized
INFO - 2019-08-26 22:55:40 --> Output Class Initialized
INFO - 2019-08-26 22:55:40 --> Security Class Initialized
DEBUG - 2019-08-26 22:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:55:40 --> Input Class Initialized
INFO - 2019-08-26 22:55:40 --> Language Class Initialized
INFO - 2019-08-26 22:55:40 --> Loader Class Initialized
INFO - 2019-08-26 22:55:40 --> Helper loaded: url_helper
INFO - 2019-08-26 22:55:40 --> Helper loaded: html_helper
INFO - 2019-08-26 22:55:40 --> Helper loaded: form_helper
INFO - 2019-08-26 22:55:40 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:55:40 --> Helper loaded: date_helper
INFO - 2019-08-26 22:55:40 --> Form Validation Class Initialized
INFO - 2019-08-26 22:55:40 --> Email Class Initialized
DEBUG - 2019-08-26 22:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:55:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:55:40 --> Pagination Class Initialized
INFO - 2019-08-26 22:55:40 --> Database Driver Class Initialized
INFO - 2019-08-26 22:55:40 --> Database Driver Class Initialized
INFO - 2019-08-26 22:55:40 --> Controller Class Initialized
INFO - 2019-08-26 22:55:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 22:55:41 --> Final output sent to browser
DEBUG - 2019-08-26 22:55:41 --> Total execution time: 0.9287
INFO - 2019-08-26 22:55:50 --> Config Class Initialized
INFO - 2019-08-26 22:55:50 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:55:50 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:55:50 --> Utf8 Class Initialized
INFO - 2019-08-26 22:55:50 --> URI Class Initialized
INFO - 2019-08-26 22:55:50 --> Router Class Initialized
INFO - 2019-08-26 22:55:50 --> Output Class Initialized
INFO - 2019-08-26 22:55:50 --> Security Class Initialized
DEBUG - 2019-08-26 22:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:55:50 --> Input Class Initialized
INFO - 2019-08-26 22:55:50 --> Language Class Initialized
INFO - 2019-08-26 22:55:50 --> Loader Class Initialized
INFO - 2019-08-26 22:55:50 --> Helper loaded: url_helper
INFO - 2019-08-26 22:55:50 --> Helper loaded: html_helper
INFO - 2019-08-26 22:55:50 --> Helper loaded: form_helper
INFO - 2019-08-26 22:55:50 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:55:50 --> Helper loaded: date_helper
INFO - 2019-08-26 22:55:50 --> Form Validation Class Initialized
INFO - 2019-08-26 22:55:50 --> Email Class Initialized
DEBUG - 2019-08-26 22:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:55:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:55:51 --> Pagination Class Initialized
INFO - 2019-08-26 22:55:51 --> Database Driver Class Initialized
INFO - 2019-08-26 22:55:51 --> Database Driver Class Initialized
INFO - 2019-08-26 22:55:51 --> Controller Class Initialized
INFO - 2019-08-26 22:55:51 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 22:55:51 --> Final output sent to browser
DEBUG - 2019-08-26 22:55:51 --> Total execution time: 0.9016
INFO - 2019-08-26 22:55:55 --> Config Class Initialized
INFO - 2019-08-26 22:55:55 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:55:55 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:55:55 --> Utf8 Class Initialized
INFO - 2019-08-26 22:55:55 --> URI Class Initialized
INFO - 2019-08-26 22:55:55 --> Router Class Initialized
INFO - 2019-08-26 22:55:55 --> Output Class Initialized
INFO - 2019-08-26 22:55:55 --> Security Class Initialized
DEBUG - 2019-08-26 22:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:55:55 --> Input Class Initialized
INFO - 2019-08-26 22:55:55 --> Language Class Initialized
INFO - 2019-08-26 22:55:56 --> Loader Class Initialized
INFO - 2019-08-26 22:55:56 --> Helper loaded: url_helper
INFO - 2019-08-26 22:55:56 --> Helper loaded: html_helper
INFO - 2019-08-26 22:55:56 --> Helper loaded: form_helper
INFO - 2019-08-26 22:55:56 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:55:56 --> Helper loaded: date_helper
INFO - 2019-08-26 22:55:56 --> Form Validation Class Initialized
INFO - 2019-08-26 22:55:56 --> Email Class Initialized
DEBUG - 2019-08-26 22:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:55:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:55:56 --> Pagination Class Initialized
INFO - 2019-08-26 22:55:56 --> Database Driver Class Initialized
INFO - 2019-08-26 22:55:56 --> Database Driver Class Initialized
INFO - 2019-08-26 22:55:56 --> Controller Class Initialized
INFO - 2019-08-26 22:55:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 22:55:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 22:55:57 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 22:55:57 --> Final output sent to browser
DEBUG - 2019-08-26 22:55:57 --> Total execution time: 1.8432
INFO - 2019-08-26 22:55:57 --> Config Class Initialized
INFO - 2019-08-26 22:55:57 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:55:57 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:55:57 --> Utf8 Class Initialized
INFO - 2019-08-26 22:55:57 --> URI Class Initialized
INFO - 2019-08-26 22:55:57 --> Router Class Initialized
INFO - 2019-08-26 22:55:58 --> Output Class Initialized
INFO - 2019-08-26 22:55:58 --> Config Class Initialized
INFO - 2019-08-26 22:55:58 --> Hooks Class Initialized
DEBUG - 2019-08-26 22:55:58 --> UTF-8 Support Enabled
INFO - 2019-08-26 22:55:58 --> Utf8 Class Initialized
INFO - 2019-08-26 22:55:58 --> Security Class Initialized
DEBUG - 2019-08-26 22:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:55:58 --> Input Class Initialized
INFO - 2019-08-26 22:55:58 --> Language Class Initialized
INFO - 2019-08-26 22:55:58 --> URI Class Initialized
INFO - 2019-08-26 22:55:58 --> Loader Class Initialized
INFO - 2019-08-26 22:55:58 --> Helper loaded: url_helper
INFO - 2019-08-26 22:55:58 --> Helper loaded: html_helper
INFO - 2019-08-26 22:55:58 --> Helper loaded: form_helper
INFO - 2019-08-26 22:55:58 --> Router Class Initialized
INFO - 2019-08-26 22:55:58 --> Output Class Initialized
INFO - 2019-08-26 22:55:58 --> Security Class Initialized
DEBUG - 2019-08-26 22:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 22:55:58 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:55:58 --> Input Class Initialized
INFO - 2019-08-26 22:55:59 --> Helper loaded: date_helper
INFO - 2019-08-26 22:55:59 --> Language Class Initialized
INFO - 2019-08-26 22:55:59 --> Form Validation Class Initialized
INFO - 2019-08-26 22:55:59 --> Loader Class Initialized
INFO - 2019-08-26 22:55:59 --> Helper loaded: url_helper
INFO - 2019-08-26 22:55:59 --> Helper loaded: html_helper
INFO - 2019-08-26 22:55:59 --> Email Class Initialized
INFO - 2019-08-26 22:55:59 --> Helper loaded: form_helper
INFO - 2019-08-26 22:55:59 --> Helper loaded: cookie_helper
INFO - 2019-08-26 22:55:59 --> Helper loaded: date_helper
INFO - 2019-08-26 22:55:59 --> Form Validation Class Initialized
DEBUG - 2019-08-26 22:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:55:59 --> Email Class Initialized
INFO - 2019-08-26 22:55:59 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2019-08-26 22:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 22:55:59 --> Pagination Class Initialized
INFO - 2019-08-26 22:55:59 --> Database Driver Class Initialized
INFO - 2019-08-26 22:55:59 --> Database Driver Class Initialized
INFO - 2019-08-26 22:55:59 --> Controller Class Initialized
INFO - 2019-08-26 22:55:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 22:55:59 --> Final output sent to browser
DEBUG - 2019-08-26 22:55:59 --> Total execution time: 2.0997
INFO - 2019-08-26 22:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 22:55:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 22:56:00 --> Pagination Class Initialized
INFO - 2019-08-26 22:56:00 --> Database Driver Class Initialized
INFO - 2019-08-26 22:56:00 --> Database Driver Class Initialized
INFO - 2019-08-26 22:56:00 --> Controller Class Initialized
INFO - 2019-08-26 22:56:00 --> Final output sent to browser
DEBUG - 2019-08-26 22:56:00 --> Total execution time: 2.1153
INFO - 2019-08-26 23:06:52 --> Config Class Initialized
INFO - 2019-08-26 23:06:52 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:06:52 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:06:53 --> Utf8 Class Initialized
INFO - 2019-08-26 23:06:53 --> URI Class Initialized
INFO - 2019-08-26 23:06:53 --> Router Class Initialized
INFO - 2019-08-26 23:06:53 --> Output Class Initialized
INFO - 2019-08-26 23:06:53 --> Security Class Initialized
DEBUG - 2019-08-26 23:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:06:53 --> Input Class Initialized
INFO - 2019-08-26 23:06:53 --> Language Class Initialized
INFO - 2019-08-26 23:06:53 --> Loader Class Initialized
INFO - 2019-08-26 23:06:53 --> Helper loaded: url_helper
INFO - 2019-08-26 23:06:53 --> Helper loaded: html_helper
INFO - 2019-08-26 23:06:53 --> Helper loaded: form_helper
INFO - 2019-08-26 23:06:53 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:06:54 --> Helper loaded: date_helper
INFO - 2019-08-26 23:06:54 --> Form Validation Class Initialized
INFO - 2019-08-26 23:06:54 --> Email Class Initialized
DEBUG - 2019-08-26 23:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:06:54 --> Pagination Class Initialized
INFO - 2019-08-26 23:06:55 --> Database Driver Class Initialized
INFO - 2019-08-26 23:06:55 --> Database Driver Class Initialized
INFO - 2019-08-26 23:06:55 --> Controller Class Initialized
INFO - 2019-08-26 23:06:55 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:06:55 --> Final output sent to browser
DEBUG - 2019-08-26 23:06:55 --> Total execution time: 3.0882
INFO - 2019-08-26 23:08:33 --> Config Class Initialized
INFO - 2019-08-26 23:08:33 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:08:33 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:08:33 --> Utf8 Class Initialized
INFO - 2019-08-26 23:08:33 --> URI Class Initialized
INFO - 2019-08-26 23:08:33 --> Router Class Initialized
INFO - 2019-08-26 23:08:34 --> Output Class Initialized
INFO - 2019-08-26 23:08:34 --> Security Class Initialized
DEBUG - 2019-08-26 23:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:08:34 --> Input Class Initialized
INFO - 2019-08-26 23:08:34 --> Language Class Initialized
INFO - 2019-08-26 23:08:34 --> Loader Class Initialized
INFO - 2019-08-26 23:08:34 --> Helper loaded: url_helper
INFO - 2019-08-26 23:08:34 --> Helper loaded: html_helper
INFO - 2019-08-26 23:08:34 --> Helper loaded: form_helper
INFO - 2019-08-26 23:08:34 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:08:34 --> Helper loaded: date_helper
INFO - 2019-08-26 23:08:35 --> Form Validation Class Initialized
INFO - 2019-08-26 23:08:35 --> Email Class Initialized
DEBUG - 2019-08-26 23:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:08:35 --> Pagination Class Initialized
INFO - 2019-08-26 23:08:35 --> Database Driver Class Initialized
INFO - 2019-08-26 23:08:36 --> Database Driver Class Initialized
INFO - 2019-08-26 23:08:36 --> Controller Class Initialized
INFO - 2019-08-26 23:08:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:08:36 --> Config Class Initialized
INFO - 2019-08-26 23:08:36 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:08:36 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:08:36 --> Utf8 Class Initialized
INFO - 2019-08-26 23:08:36 --> URI Class Initialized
INFO - 2019-08-26 23:08:36 --> Router Class Initialized
INFO - 2019-08-26 23:08:36 --> Output Class Initialized
INFO - 2019-08-26 23:08:36 --> Security Class Initialized
DEBUG - 2019-08-26 23:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:08:36 --> Input Class Initialized
INFO - 2019-08-26 23:08:36 --> Language Class Initialized
INFO - 2019-08-26 23:08:36 --> Loader Class Initialized
INFO - 2019-08-26 23:08:36 --> Helper loaded: url_helper
INFO - 2019-08-26 23:08:36 --> Helper loaded: html_helper
INFO - 2019-08-26 23:08:37 --> Helper loaded: form_helper
INFO - 2019-08-26 23:08:37 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:08:37 --> Helper loaded: date_helper
INFO - 2019-08-26 23:08:37 --> Form Validation Class Initialized
INFO - 2019-08-26 23:08:37 --> Email Class Initialized
DEBUG - 2019-08-26 23:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:08:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:08:37 --> Pagination Class Initialized
INFO - 2019-08-26 23:08:37 --> Database Driver Class Initialized
INFO - 2019-08-26 23:08:37 --> Database Driver Class Initialized
INFO - 2019-08-26 23:08:37 --> Controller Class Initialized
INFO - 2019-08-26 23:08:38 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:08:38 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:08:38 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:08:38 --> Final output sent to browser
DEBUG - 2019-08-26 23:08:38 --> Total execution time: 1.8755
INFO - 2019-08-26 23:08:38 --> Config Class Initialized
INFO - 2019-08-26 23:08:38 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:08:38 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:08:38 --> Utf8 Class Initialized
INFO - 2019-08-26 23:08:38 --> URI Class Initialized
INFO - 2019-08-26 23:08:38 --> Router Class Initialized
INFO - 2019-08-26 23:08:39 --> Output Class Initialized
INFO - 2019-08-26 23:08:39 --> Config Class Initialized
INFO - 2019-08-26 23:08:39 --> Security Class Initialized
INFO - 2019-08-26 23:08:39 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:08:39 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:08:39 --> Utf8 Class Initialized
INFO - 2019-08-26 23:08:39 --> URI Class Initialized
INFO - 2019-08-26 23:08:39 --> Router Class Initialized
INFO - 2019-08-26 23:08:39 --> Output Class Initialized
DEBUG - 2019-08-26 23:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:08:39 --> Input Class Initialized
INFO - 2019-08-26 23:08:39 --> Language Class Initialized
INFO - 2019-08-26 23:08:39 --> Security Class Initialized
DEBUG - 2019-08-26 23:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:08:39 --> Input Class Initialized
INFO - 2019-08-26 23:08:39 --> Language Class Initialized
INFO - 2019-08-26 23:08:39 --> Loader Class Initialized
INFO - 2019-08-26 23:08:39 --> Helper loaded: url_helper
INFO - 2019-08-26 23:08:40 --> Helper loaded: html_helper
INFO - 2019-08-26 23:08:40 --> Helper loaded: form_helper
INFO - 2019-08-26 23:08:40 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:08:40 --> Helper loaded: date_helper
INFO - 2019-08-26 23:08:40 --> Form Validation Class Initialized
INFO - 2019-08-26 23:08:40 --> Email Class Initialized
INFO - 2019-08-26 23:08:40 --> Loader Class Initialized
INFO - 2019-08-26 23:08:40 --> Helper loaded: url_helper
INFO - 2019-08-26 23:08:40 --> Helper loaded: html_helper
INFO - 2019-08-26 23:08:40 --> Helper loaded: form_helper
INFO - 2019-08-26 23:08:40 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:08:40 --> Helper loaded: date_helper
INFO - 2019-08-26 23:08:40 --> Form Validation Class Initialized
DEBUG - 2019-08-26 23:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:08:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:08:40 --> Pagination Class Initialized
INFO - 2019-08-26 23:08:40 --> Database Driver Class Initialized
INFO - 2019-08-26 23:08:40 --> Database Driver Class Initialized
INFO - 2019-08-26 23:08:40 --> Controller Class Initialized
INFO - 2019-08-26 23:08:40 --> Email Class Initialized
INFO - 2019-08-26 23:08:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
DEBUG - 2019-08-26 23:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:08:40 --> Final output sent to browser
DEBUG - 2019-08-26 23:08:41 --> Total execution time: 2.3178
INFO - 2019-08-26 23:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:08:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:08:41 --> Pagination Class Initialized
INFO - 2019-08-26 23:08:41 --> Database Driver Class Initialized
INFO - 2019-08-26 23:08:41 --> Database Driver Class Initialized
INFO - 2019-08-26 23:08:41 --> Controller Class Initialized
INFO - 2019-08-26 23:08:41 --> Final output sent to browser
DEBUG - 2019-08-26 23:08:41 --> Total execution time: 2.2431
INFO - 2019-08-26 23:08:55 --> Config Class Initialized
INFO - 2019-08-26 23:08:55 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:08:55 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:08:55 --> Utf8 Class Initialized
INFO - 2019-08-26 23:08:56 --> URI Class Initialized
INFO - 2019-08-26 23:08:56 --> Router Class Initialized
INFO - 2019-08-26 23:08:56 --> Output Class Initialized
INFO - 2019-08-26 23:08:56 --> Security Class Initialized
DEBUG - 2019-08-26 23:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:08:56 --> Input Class Initialized
INFO - 2019-08-26 23:08:56 --> Language Class Initialized
INFO - 2019-08-26 23:08:56 --> Loader Class Initialized
INFO - 2019-08-26 23:08:56 --> Helper loaded: url_helper
INFO - 2019-08-26 23:08:56 --> Helper loaded: html_helper
INFO - 2019-08-26 23:08:56 --> Helper loaded: form_helper
INFO - 2019-08-26 23:08:56 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:08:56 --> Helper loaded: date_helper
INFO - 2019-08-26 23:08:56 --> Form Validation Class Initialized
INFO - 2019-08-26 23:08:56 --> Email Class Initialized
DEBUG - 2019-08-26 23:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:08:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:08:56 --> Pagination Class Initialized
INFO - 2019-08-26 23:08:56 --> Database Driver Class Initialized
INFO - 2019-08-26 23:08:56 --> Database Driver Class Initialized
INFO - 2019-08-26 23:08:56 --> Controller Class Initialized
INFO - 2019-08-26 23:08:56 --> Final output sent to browser
DEBUG - 2019-08-26 23:08:56 --> Total execution time: 1.0283
INFO - 2019-08-26 23:09:18 --> Config Class Initialized
INFO - 2019-08-26 23:09:18 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:09:18 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:09:18 --> Utf8 Class Initialized
INFO - 2019-08-26 23:09:18 --> URI Class Initialized
INFO - 2019-08-26 23:09:18 --> Router Class Initialized
INFO - 2019-08-26 23:09:18 --> Output Class Initialized
INFO - 2019-08-26 23:09:18 --> Security Class Initialized
DEBUG - 2019-08-26 23:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:09:19 --> Input Class Initialized
INFO - 2019-08-26 23:09:19 --> Language Class Initialized
INFO - 2019-08-26 23:09:19 --> Loader Class Initialized
INFO - 2019-08-26 23:09:19 --> Helper loaded: url_helper
INFO - 2019-08-26 23:09:19 --> Helper loaded: html_helper
INFO - 2019-08-26 23:09:19 --> Helper loaded: form_helper
INFO - 2019-08-26 23:09:19 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:09:19 --> Helper loaded: date_helper
INFO - 2019-08-26 23:09:19 --> Form Validation Class Initialized
INFO - 2019-08-26 23:09:19 --> Email Class Initialized
DEBUG - 2019-08-26 23:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:09:19 --> Pagination Class Initialized
INFO - 2019-08-26 23:09:19 --> Database Driver Class Initialized
INFO - 2019-08-26 23:09:19 --> Database Driver Class Initialized
INFO - 2019-08-26 23:09:19 --> Controller Class Initialized
INFO - 2019-08-26 23:09:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:09:19 --> Config Class Initialized
INFO - 2019-08-26 23:09:19 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:09:19 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:09:19 --> Utf8 Class Initialized
INFO - 2019-08-26 23:09:19 --> URI Class Initialized
INFO - 2019-08-26 23:09:19 --> Router Class Initialized
INFO - 2019-08-26 23:09:20 --> Output Class Initialized
INFO - 2019-08-26 23:09:20 --> Security Class Initialized
DEBUG - 2019-08-26 23:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:09:20 --> Input Class Initialized
INFO - 2019-08-26 23:09:20 --> Language Class Initialized
INFO - 2019-08-26 23:09:20 --> Loader Class Initialized
INFO - 2019-08-26 23:09:20 --> Helper loaded: url_helper
INFO - 2019-08-26 23:09:20 --> Helper loaded: html_helper
INFO - 2019-08-26 23:09:20 --> Helper loaded: form_helper
INFO - 2019-08-26 23:09:20 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:09:20 --> Helper loaded: date_helper
INFO - 2019-08-26 23:09:20 --> Form Validation Class Initialized
INFO - 2019-08-26 23:09:20 --> Email Class Initialized
DEBUG - 2019-08-26 23:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:09:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:09:20 --> Pagination Class Initialized
INFO - 2019-08-26 23:09:20 --> Database Driver Class Initialized
INFO - 2019-08-26 23:09:20 --> Database Driver Class Initialized
INFO - 2019-08-26 23:09:20 --> Controller Class Initialized
INFO - 2019-08-26 23:09:20 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:09:20 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:09:20 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:09:20 --> Final output sent to browser
DEBUG - 2019-08-26 23:09:20 --> Total execution time: 1.1167
INFO - 2019-08-26 23:09:21 --> Config Class Initialized
INFO - 2019-08-26 23:09:21 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:09:21 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:09:21 --> Utf8 Class Initialized
INFO - 2019-08-26 23:09:21 --> URI Class Initialized
INFO - 2019-08-26 23:09:21 --> Router Class Initialized
INFO - 2019-08-26 23:09:21 --> Output Class Initialized
INFO - 2019-08-26 23:09:21 --> Security Class Initialized
DEBUG - 2019-08-26 23:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:09:21 --> Input Class Initialized
INFO - 2019-08-26 23:09:21 --> Language Class Initialized
INFO - 2019-08-26 23:09:21 --> Loader Class Initialized
INFO - 2019-08-26 23:09:21 --> Helper loaded: url_helper
INFO - 2019-08-26 23:09:21 --> Helper loaded: html_helper
INFO - 2019-08-26 23:09:21 --> Helper loaded: form_helper
INFO - 2019-08-26 23:09:21 --> Config Class Initialized
INFO - 2019-08-26 23:09:21 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:09:21 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:09:21 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:09:22 --> Utf8 Class Initialized
INFO - 2019-08-26 23:09:22 --> Helper loaded: date_helper
INFO - 2019-08-26 23:09:22 --> URI Class Initialized
INFO - 2019-08-26 23:09:22 --> Router Class Initialized
INFO - 2019-08-26 23:09:22 --> Form Validation Class Initialized
INFO - 2019-08-26 23:09:22 --> Output Class Initialized
INFO - 2019-08-26 23:09:22 --> Email Class Initialized
INFO - 2019-08-26 23:09:22 --> Security Class Initialized
DEBUG - 2019-08-26 23:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-26 23:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:09:22 --> Input Class Initialized
INFO - 2019-08-26 23:09:22 --> Language Class Initialized
INFO - 2019-08-26 23:09:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:09:22 --> Pagination Class Initialized
INFO - 2019-08-26 23:09:22 --> Loader Class Initialized
INFO - 2019-08-26 23:09:22 --> Database Driver Class Initialized
INFO - 2019-08-26 23:09:22 --> Database Driver Class Initialized
INFO - 2019-08-26 23:09:22 --> Helper loaded: url_helper
INFO - 2019-08-26 23:09:22 --> Helper loaded: html_helper
INFO - 2019-08-26 23:09:22 --> Controller Class Initialized
INFO - 2019-08-26 23:09:23 --> Helper loaded: form_helper
INFO - 2019-08-26 23:09:23 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:09:23 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:09:23 --> Final output sent to browser
DEBUG - 2019-08-26 23:09:23 --> Total execution time: 1.9149
INFO - 2019-08-26 23:09:23 --> Helper loaded: date_helper
INFO - 2019-08-26 23:09:23 --> Form Validation Class Initialized
INFO - 2019-08-26 23:09:23 --> Email Class Initialized
DEBUG - 2019-08-26 23:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:09:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:09:23 --> Pagination Class Initialized
INFO - 2019-08-26 23:09:23 --> Database Driver Class Initialized
INFO - 2019-08-26 23:09:23 --> Database Driver Class Initialized
INFO - 2019-08-26 23:09:23 --> Controller Class Initialized
INFO - 2019-08-26 23:09:23 --> Final output sent to browser
DEBUG - 2019-08-26 23:09:23 --> Total execution time: 1.7339
INFO - 2019-08-26 23:10:18 --> Config Class Initialized
INFO - 2019-08-26 23:10:18 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:10:18 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:10:19 --> Utf8 Class Initialized
INFO - 2019-08-26 23:10:19 --> URI Class Initialized
INFO - 2019-08-26 23:10:19 --> Router Class Initialized
INFO - 2019-08-26 23:10:19 --> Output Class Initialized
INFO - 2019-08-26 23:10:19 --> Security Class Initialized
DEBUG - 2019-08-26 23:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:10:19 --> Input Class Initialized
INFO - 2019-08-26 23:10:19 --> Language Class Initialized
INFO - 2019-08-26 23:10:19 --> Loader Class Initialized
INFO - 2019-08-26 23:10:19 --> Helper loaded: url_helper
INFO - 2019-08-26 23:10:19 --> Helper loaded: html_helper
INFO - 2019-08-26 23:10:19 --> Helper loaded: form_helper
INFO - 2019-08-26 23:10:19 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:10:19 --> Helper loaded: date_helper
INFO - 2019-08-26 23:10:19 --> Form Validation Class Initialized
INFO - 2019-08-26 23:10:19 --> Email Class Initialized
DEBUG - 2019-08-26 23:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:10:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:10:19 --> Pagination Class Initialized
INFO - 2019-08-26 23:10:19 --> Database Driver Class Initialized
INFO - 2019-08-26 23:10:20 --> Database Driver Class Initialized
INFO - 2019-08-26 23:10:20 --> Controller Class Initialized
INFO - 2019-08-26 23:10:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:10:20 --> Config Class Initialized
INFO - 2019-08-26 23:10:20 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:10:20 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:10:20 --> Utf8 Class Initialized
INFO - 2019-08-26 23:10:20 --> URI Class Initialized
INFO - 2019-08-26 23:10:20 --> Router Class Initialized
INFO - 2019-08-26 23:10:20 --> Output Class Initialized
INFO - 2019-08-26 23:10:20 --> Security Class Initialized
DEBUG - 2019-08-26 23:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:10:20 --> Input Class Initialized
INFO - 2019-08-26 23:10:20 --> Language Class Initialized
INFO - 2019-08-26 23:10:20 --> Loader Class Initialized
INFO - 2019-08-26 23:10:20 --> Helper loaded: url_helper
INFO - 2019-08-26 23:10:20 --> Helper loaded: html_helper
INFO - 2019-08-26 23:10:20 --> Helper loaded: form_helper
INFO - 2019-08-26 23:10:21 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:10:21 --> Helper loaded: date_helper
INFO - 2019-08-26 23:10:21 --> Form Validation Class Initialized
INFO - 2019-08-26 23:10:21 --> Email Class Initialized
DEBUG - 2019-08-26 23:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:10:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:10:21 --> Pagination Class Initialized
INFO - 2019-08-26 23:10:21 --> Database Driver Class Initialized
INFO - 2019-08-26 23:10:21 --> Database Driver Class Initialized
INFO - 2019-08-26 23:10:21 --> Controller Class Initialized
INFO - 2019-08-26 23:10:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:10:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:10:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:10:22 --> Final output sent to browser
DEBUG - 2019-08-26 23:10:22 --> Total execution time: 1.9894
INFO - 2019-08-26 23:10:24 --> Config Class Initialized
INFO - 2019-08-26 23:10:24 --> Hooks Class Initialized
INFO - 2019-08-26 23:10:24 --> Config Class Initialized
INFO - 2019-08-26 23:10:24 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:10:24 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:10:24 --> Utf8 Class Initialized
DEBUG - 2019-08-26 23:10:24 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:10:24 --> Utf8 Class Initialized
INFO - 2019-08-26 23:10:24 --> URI Class Initialized
INFO - 2019-08-26 23:10:24 --> URI Class Initialized
INFO - 2019-08-26 23:10:24 --> Router Class Initialized
INFO - 2019-08-26 23:10:25 --> Output Class Initialized
INFO - 2019-08-26 23:10:25 --> Router Class Initialized
INFO - 2019-08-26 23:10:25 --> Output Class Initialized
INFO - 2019-08-26 23:10:25 --> Security Class Initialized
INFO - 2019-08-26 23:10:25 --> Security Class Initialized
DEBUG - 2019-08-26 23:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-26 23:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:10:25 --> Input Class Initialized
INFO - 2019-08-26 23:10:25 --> Input Class Initialized
INFO - 2019-08-26 23:10:25 --> Language Class Initialized
INFO - 2019-08-26 23:10:25 --> Language Class Initialized
INFO - 2019-08-26 23:10:25 --> Loader Class Initialized
INFO - 2019-08-26 23:10:25 --> Loader Class Initialized
INFO - 2019-08-26 23:10:25 --> Helper loaded: url_helper
INFO - 2019-08-26 23:10:25 --> Helper loaded: url_helper
INFO - 2019-08-26 23:10:25 --> Helper loaded: html_helper
INFO - 2019-08-26 23:10:25 --> Helper loaded: html_helper
INFO - 2019-08-26 23:10:25 --> Helper loaded: form_helper
INFO - 2019-08-26 23:10:25 --> Helper loaded: form_helper
INFO - 2019-08-26 23:10:25 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:10:25 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:10:25 --> Helper loaded: date_helper
INFO - 2019-08-26 23:10:25 --> Helper loaded: date_helper
INFO - 2019-08-26 23:10:25 --> Form Validation Class Initialized
INFO - 2019-08-26 23:10:26 --> Form Validation Class Initialized
INFO - 2019-08-26 23:10:26 --> Email Class Initialized
INFO - 2019-08-26 23:10:26 --> Email Class Initialized
DEBUG - 2019-08-26 23:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-26 23:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:10:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:10:26 --> Pagination Class Initialized
INFO - 2019-08-26 23:10:26 --> Database Driver Class Initialized
INFO - 2019-08-26 23:10:26 --> Database Driver Class Initialized
INFO - 2019-08-26 23:10:26 --> Controller Class Initialized
INFO - 2019-08-26 23:10:26 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:10:26 --> Final output sent to browser
DEBUG - 2019-08-26 23:10:26 --> Total execution time: 2.2470
INFO - 2019-08-26 23:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:10:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:10:26 --> Pagination Class Initialized
INFO - 2019-08-26 23:10:27 --> Database Driver Class Initialized
INFO - 2019-08-26 23:10:27 --> Database Driver Class Initialized
INFO - 2019-08-26 23:10:27 --> Controller Class Initialized
INFO - 2019-08-26 23:10:27 --> Final output sent to browser
DEBUG - 2019-08-26 23:10:27 --> Total execution time: 2.6604
INFO - 2019-08-26 23:11:23 --> Config Class Initialized
INFO - 2019-08-26 23:11:23 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:11:23 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:11:23 --> Utf8 Class Initialized
INFO - 2019-08-26 23:11:23 --> URI Class Initialized
INFO - 2019-08-26 23:11:23 --> Router Class Initialized
INFO - 2019-08-26 23:11:23 --> Output Class Initialized
INFO - 2019-08-26 23:11:23 --> Security Class Initialized
DEBUG - 2019-08-26 23:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:11:23 --> Input Class Initialized
INFO - 2019-08-26 23:11:23 --> Language Class Initialized
INFO - 2019-08-26 23:11:23 --> Loader Class Initialized
INFO - 2019-08-26 23:11:23 --> Helper loaded: url_helper
INFO - 2019-08-26 23:11:23 --> Helper loaded: html_helper
INFO - 2019-08-26 23:11:23 --> Helper loaded: form_helper
INFO - 2019-08-26 23:11:23 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:11:24 --> Helper loaded: date_helper
INFO - 2019-08-26 23:11:24 --> Form Validation Class Initialized
INFO - 2019-08-26 23:11:24 --> Email Class Initialized
DEBUG - 2019-08-26 23:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:11:24 --> Pagination Class Initialized
INFO - 2019-08-26 23:11:24 --> Database Driver Class Initialized
INFO - 2019-08-26 23:11:24 --> Database Driver Class Initialized
INFO - 2019-08-26 23:11:24 --> Controller Class Initialized
INFO - 2019-08-26 23:11:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:11:24 --> Config Class Initialized
INFO - 2019-08-26 23:11:24 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:11:24 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:11:24 --> Utf8 Class Initialized
INFO - 2019-08-26 23:11:24 --> URI Class Initialized
INFO - 2019-08-26 23:11:24 --> Router Class Initialized
INFO - 2019-08-26 23:11:24 --> Output Class Initialized
INFO - 2019-08-26 23:11:24 --> Security Class Initialized
DEBUG - 2019-08-26 23:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:11:24 --> Input Class Initialized
INFO - 2019-08-26 23:11:24 --> Language Class Initialized
INFO - 2019-08-26 23:11:24 --> Loader Class Initialized
INFO - 2019-08-26 23:11:24 --> Helper loaded: url_helper
INFO - 2019-08-26 23:11:24 --> Helper loaded: html_helper
INFO - 2019-08-26 23:11:24 --> Helper loaded: form_helper
INFO - 2019-08-26 23:11:25 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:11:25 --> Helper loaded: date_helper
INFO - 2019-08-26 23:11:25 --> Form Validation Class Initialized
INFO - 2019-08-26 23:11:25 --> Email Class Initialized
DEBUG - 2019-08-26 23:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:11:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:11:25 --> Pagination Class Initialized
INFO - 2019-08-26 23:11:25 --> Database Driver Class Initialized
INFO - 2019-08-26 23:11:25 --> Database Driver Class Initialized
INFO - 2019-08-26 23:11:25 --> Controller Class Initialized
INFO - 2019-08-26 23:11:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:11:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:11:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:11:25 --> Final output sent to browser
DEBUG - 2019-08-26 23:11:25 --> Total execution time: 1.0791
INFO - 2019-08-26 23:11:25 --> Config Class Initialized
INFO - 2019-08-26 23:11:25 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:11:25 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:11:26 --> Utf8 Class Initialized
INFO - 2019-08-26 23:11:26 --> URI Class Initialized
INFO - 2019-08-26 23:11:26 --> Router Class Initialized
INFO - 2019-08-26 23:11:26 --> Output Class Initialized
INFO - 2019-08-26 23:11:26 --> Security Class Initialized
INFO - 2019-08-26 23:11:26 --> Config Class Initialized
INFO - 2019-08-26 23:11:26 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:11:26 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:11:26 --> Utf8 Class Initialized
INFO - 2019-08-26 23:11:26 --> URI Class Initialized
INFO - 2019-08-26 23:11:26 --> Router Class Initialized
INFO - 2019-08-26 23:11:26 --> Output Class Initialized
DEBUG - 2019-08-26 23:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:11:26 --> Input Class Initialized
INFO - 2019-08-26 23:11:26 --> Language Class Initialized
INFO - 2019-08-26 23:11:26 --> Security Class Initialized
DEBUG - 2019-08-26 23:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:11:26 --> Input Class Initialized
INFO - 2019-08-26 23:11:26 --> Language Class Initialized
INFO - 2019-08-26 23:11:26 --> Loader Class Initialized
INFO - 2019-08-26 23:11:27 --> Loader Class Initialized
INFO - 2019-08-26 23:11:27 --> Helper loaded: url_helper
INFO - 2019-08-26 23:11:27 --> Helper loaded: html_helper
INFO - 2019-08-26 23:11:27 --> Helper loaded: url_helper
INFO - 2019-08-26 23:11:27 --> Helper loaded: html_helper
INFO - 2019-08-26 23:11:27 --> Helper loaded: form_helper
INFO - 2019-08-26 23:11:27 --> Helper loaded: form_helper
INFO - 2019-08-26 23:11:27 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:11:27 --> Helper loaded: date_helper
INFO - 2019-08-26 23:11:27 --> Form Validation Class Initialized
INFO - 2019-08-26 23:11:27 --> Email Class Initialized
DEBUG - 2019-08-26 23:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:11:27 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:11:27 --> Helper loaded: date_helper
INFO - 2019-08-26 23:11:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:11:27 --> Form Validation Class Initialized
INFO - 2019-08-26 23:11:27 --> Pagination Class Initialized
INFO - 2019-08-26 23:11:27 --> Email Class Initialized
INFO - 2019-08-26 23:11:27 --> Database Driver Class Initialized
DEBUG - 2019-08-26 23:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:11:27 --> Database Driver Class Initialized
INFO - 2019-08-26 23:11:27 --> Controller Class Initialized
INFO - 2019-08-26 23:11:27 --> Final output sent to browser
DEBUG - 2019-08-26 23:11:27 --> Total execution time: 1.5501
INFO - 2019-08-26 23:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:11:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:11:27 --> Pagination Class Initialized
INFO - 2019-08-26 23:11:28 --> Database Driver Class Initialized
INFO - 2019-08-26 23:11:28 --> Database Driver Class Initialized
INFO - 2019-08-26 23:11:28 --> Controller Class Initialized
INFO - 2019-08-26 23:11:28 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:11:28 --> Final output sent to browser
DEBUG - 2019-08-26 23:11:28 --> Total execution time: 2.3808
INFO - 2019-08-26 23:12:25 --> Config Class Initialized
INFO - 2019-08-26 23:12:25 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:12:25 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:12:25 --> Utf8 Class Initialized
INFO - 2019-08-26 23:12:25 --> URI Class Initialized
INFO - 2019-08-26 23:12:25 --> Router Class Initialized
INFO - 2019-08-26 23:12:25 --> Output Class Initialized
INFO - 2019-08-26 23:12:25 --> Security Class Initialized
DEBUG - 2019-08-26 23:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:12:25 --> Input Class Initialized
INFO - 2019-08-26 23:12:25 --> Language Class Initialized
INFO - 2019-08-26 23:12:25 --> Loader Class Initialized
INFO - 2019-08-26 23:12:25 --> Helper loaded: url_helper
INFO - 2019-08-26 23:12:25 --> Helper loaded: html_helper
INFO - 2019-08-26 23:12:25 --> Helper loaded: form_helper
INFO - 2019-08-26 23:12:25 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:12:25 --> Helper loaded: date_helper
INFO - 2019-08-26 23:12:25 --> Form Validation Class Initialized
INFO - 2019-08-26 23:12:25 --> Email Class Initialized
DEBUG - 2019-08-26 23:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:12:26 --> Pagination Class Initialized
INFO - 2019-08-26 23:12:26 --> Database Driver Class Initialized
INFO - 2019-08-26 23:12:26 --> Database Driver Class Initialized
INFO - 2019-08-26 23:12:26 --> Controller Class Initialized
INFO - 2019-08-26 23:12:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:12:29 --> Config Class Initialized
INFO - 2019-08-26 23:12:29 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:12:29 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:12:29 --> Utf8 Class Initialized
INFO - 2019-08-26 23:12:29 --> URI Class Initialized
INFO - 2019-08-26 23:12:29 --> Router Class Initialized
INFO - 2019-08-26 23:12:29 --> Output Class Initialized
INFO - 2019-08-26 23:12:29 --> Security Class Initialized
DEBUG - 2019-08-26 23:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:12:29 --> Input Class Initialized
INFO - 2019-08-26 23:12:29 --> Language Class Initialized
INFO - 2019-08-26 23:12:29 --> Loader Class Initialized
INFO - 2019-08-26 23:12:29 --> Helper loaded: url_helper
INFO - 2019-08-26 23:12:29 --> Helper loaded: html_helper
INFO - 2019-08-26 23:12:29 --> Helper loaded: form_helper
INFO - 2019-08-26 23:12:29 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:12:29 --> Helper loaded: date_helper
INFO - 2019-08-26 23:12:30 --> Form Validation Class Initialized
INFO - 2019-08-26 23:12:30 --> Email Class Initialized
DEBUG - 2019-08-26 23:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:12:30 --> Pagination Class Initialized
INFO - 2019-08-26 23:12:30 --> Database Driver Class Initialized
INFO - 2019-08-26 23:12:30 --> Database Driver Class Initialized
INFO - 2019-08-26 23:12:30 --> Controller Class Initialized
INFO - 2019-08-26 23:12:30 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:12:30 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:12:30 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:12:30 --> Final output sent to browser
DEBUG - 2019-08-26 23:12:30 --> Total execution time: 1.2037
INFO - 2019-08-26 23:12:30 --> Config Class Initialized
INFO - 2019-08-26 23:12:30 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:12:30 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:12:30 --> Utf8 Class Initialized
INFO - 2019-08-26 23:12:31 --> URI Class Initialized
INFO - 2019-08-26 23:12:31 --> Router Class Initialized
INFO - 2019-08-26 23:12:31 --> Output Class Initialized
INFO - 2019-08-26 23:12:31 --> Security Class Initialized
INFO - 2019-08-26 23:12:31 --> Config Class Initialized
INFO - 2019-08-26 23:12:31 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:12:31 --> Input Class Initialized
INFO - 2019-08-26 23:12:31 --> Language Class Initialized
DEBUG - 2019-08-26 23:12:31 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:12:31 --> Utf8 Class Initialized
INFO - 2019-08-26 23:12:31 --> Loader Class Initialized
INFO - 2019-08-26 23:12:31 --> Helper loaded: url_helper
INFO - 2019-08-26 23:12:31 --> Helper loaded: html_helper
INFO - 2019-08-26 23:12:31 --> URI Class Initialized
INFO - 2019-08-26 23:12:31 --> Helper loaded: form_helper
INFO - 2019-08-26 23:12:31 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:12:31 --> Helper loaded: date_helper
INFO - 2019-08-26 23:12:32 --> Form Validation Class Initialized
INFO - 2019-08-26 23:12:32 --> Email Class Initialized
INFO - 2019-08-26 23:12:32 --> Router Class Initialized
DEBUG - 2019-08-26 23:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:12:32 --> Output Class Initialized
INFO - 2019-08-26 23:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:12:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:12:32 --> Pagination Class Initialized
INFO - 2019-08-26 23:12:32 --> Security Class Initialized
DEBUG - 2019-08-26 23:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:12:32 --> Input Class Initialized
INFO - 2019-08-26 23:12:32 --> Database Driver Class Initialized
INFO - 2019-08-26 23:12:32 --> Language Class Initialized
INFO - 2019-08-26 23:12:32 --> Database Driver Class Initialized
INFO - 2019-08-26 23:12:32 --> Loader Class Initialized
INFO - 2019-08-26 23:12:32 --> Controller Class Initialized
INFO - 2019-08-26 23:12:32 --> Helper loaded: url_helper
INFO - 2019-08-26 23:12:32 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:12:32 --> Helper loaded: html_helper
INFO - 2019-08-26 23:12:32 --> Final output sent to browser
DEBUG - 2019-08-26 23:12:32 --> Total execution time: 1.8064
INFO - 2019-08-26 23:12:32 --> Helper loaded: form_helper
INFO - 2019-08-26 23:12:32 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:12:32 --> Helper loaded: date_helper
INFO - 2019-08-26 23:12:32 --> Form Validation Class Initialized
INFO - 2019-08-26 23:12:32 --> Email Class Initialized
DEBUG - 2019-08-26 23:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:12:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:12:32 --> Pagination Class Initialized
INFO - 2019-08-26 23:12:33 --> Database Driver Class Initialized
INFO - 2019-08-26 23:12:33 --> Database Driver Class Initialized
INFO - 2019-08-26 23:12:33 --> Controller Class Initialized
INFO - 2019-08-26 23:12:33 --> Final output sent to browser
DEBUG - 2019-08-26 23:12:33 --> Total execution time: 1.9386
INFO - 2019-08-26 23:13:22 --> Config Class Initialized
INFO - 2019-08-26 23:13:22 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:13:22 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:13:22 --> Utf8 Class Initialized
INFO - 2019-08-26 23:13:22 --> URI Class Initialized
INFO - 2019-08-26 23:13:22 --> Router Class Initialized
INFO - 2019-08-26 23:13:22 --> Output Class Initialized
INFO - 2019-08-26 23:13:22 --> Security Class Initialized
DEBUG - 2019-08-26 23:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:13:22 --> Input Class Initialized
INFO - 2019-08-26 23:13:22 --> Language Class Initialized
INFO - 2019-08-26 23:13:22 --> Loader Class Initialized
INFO - 2019-08-26 23:13:22 --> Helper loaded: url_helper
INFO - 2019-08-26 23:13:22 --> Helper loaded: html_helper
INFO - 2019-08-26 23:13:22 --> Helper loaded: form_helper
INFO - 2019-08-26 23:13:23 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:13:23 --> Helper loaded: date_helper
INFO - 2019-08-26 23:13:23 --> Form Validation Class Initialized
INFO - 2019-08-26 23:13:23 --> Email Class Initialized
DEBUG - 2019-08-26 23:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:13:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:13:23 --> Pagination Class Initialized
INFO - 2019-08-26 23:13:23 --> Database Driver Class Initialized
INFO - 2019-08-26 23:13:23 --> Database Driver Class Initialized
INFO - 2019-08-26 23:13:23 --> Controller Class Initialized
INFO - 2019-08-26 23:13:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:13:23 --> Config Class Initialized
INFO - 2019-08-26 23:13:23 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:13:23 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:13:23 --> Utf8 Class Initialized
INFO - 2019-08-26 23:13:23 --> URI Class Initialized
INFO - 2019-08-26 23:13:23 --> Router Class Initialized
INFO - 2019-08-26 23:13:23 --> Output Class Initialized
INFO - 2019-08-26 23:13:23 --> Security Class Initialized
DEBUG - 2019-08-26 23:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:13:23 --> Input Class Initialized
INFO - 2019-08-26 23:13:23 --> Language Class Initialized
INFO - 2019-08-26 23:13:23 --> Loader Class Initialized
INFO - 2019-08-26 23:13:23 --> Helper loaded: url_helper
INFO - 2019-08-26 23:13:23 --> Helper loaded: html_helper
INFO - 2019-08-26 23:13:23 --> Helper loaded: form_helper
INFO - 2019-08-26 23:13:23 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:13:23 --> Helper loaded: date_helper
INFO - 2019-08-26 23:13:23 --> Form Validation Class Initialized
INFO - 2019-08-26 23:13:23 --> Email Class Initialized
DEBUG - 2019-08-26 23:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:13:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:13:24 --> Pagination Class Initialized
INFO - 2019-08-26 23:13:24 --> Database Driver Class Initialized
INFO - 2019-08-26 23:13:24 --> Database Driver Class Initialized
INFO - 2019-08-26 23:13:24 --> Controller Class Initialized
INFO - 2019-08-26 23:13:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:13:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:13:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:13:24 --> Final output sent to browser
DEBUG - 2019-08-26 23:13:24 --> Total execution time: 0.8266
INFO - 2019-08-26 23:13:24 --> Config Class Initialized
INFO - 2019-08-26 23:13:24 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:13:24 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:13:24 --> Utf8 Class Initialized
INFO - 2019-08-26 23:13:24 --> URI Class Initialized
INFO - 2019-08-26 23:13:24 --> Router Class Initialized
INFO - 2019-08-26 23:13:24 --> Output Class Initialized
INFO - 2019-08-26 23:13:24 --> Config Class Initialized
INFO - 2019-08-26 23:13:24 --> Security Class Initialized
INFO - 2019-08-26 23:13:24 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-26 23:13:24 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:13:24 --> Input Class Initialized
INFO - 2019-08-26 23:13:24 --> Utf8 Class Initialized
INFO - 2019-08-26 23:13:24 --> Language Class Initialized
INFO - 2019-08-26 23:13:24 --> URI Class Initialized
INFO - 2019-08-26 23:13:25 --> Loader Class Initialized
INFO - 2019-08-26 23:13:25 --> Router Class Initialized
INFO - 2019-08-26 23:13:25 --> Helper loaded: url_helper
INFO - 2019-08-26 23:13:25 --> Output Class Initialized
INFO - 2019-08-26 23:13:25 --> Helper loaded: html_helper
INFO - 2019-08-26 23:13:25 --> Security Class Initialized
INFO - 2019-08-26 23:13:25 --> Helper loaded: form_helper
DEBUG - 2019-08-26 23:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:13:25 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:13:25 --> Input Class Initialized
INFO - 2019-08-26 23:13:25 --> Language Class Initialized
INFO - 2019-08-26 23:13:25 --> Helper loaded: date_helper
INFO - 2019-08-26 23:13:25 --> Loader Class Initialized
INFO - 2019-08-26 23:13:25 --> Form Validation Class Initialized
INFO - 2019-08-26 23:13:25 --> Helper loaded: url_helper
INFO - 2019-08-26 23:13:25 --> Email Class Initialized
INFO - 2019-08-26 23:13:25 --> Helper loaded: html_helper
DEBUG - 2019-08-26 23:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:13:25 --> Helper loaded: form_helper
INFO - 2019-08-26 23:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:13:25 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:13:25 --> Helper loaded: date_helper
INFO - 2019-08-26 23:13:25 --> Pagination Class Initialized
INFO - 2019-08-26 23:13:25 --> Form Validation Class Initialized
INFO - 2019-08-26 23:13:25 --> Database Driver Class Initialized
INFO - 2019-08-26 23:13:25 --> Email Class Initialized
INFO - 2019-08-26 23:13:25 --> Database Driver Class Initialized
DEBUG - 2019-08-26 23:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:13:25 --> Controller Class Initialized
INFO - 2019-08-26 23:13:25 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:13:25 --> Final output sent to browser
DEBUG - 2019-08-26 23:13:26 --> Total execution time: 1.5458
INFO - 2019-08-26 23:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:13:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:13:26 --> Pagination Class Initialized
INFO - 2019-08-26 23:13:26 --> Database Driver Class Initialized
INFO - 2019-08-26 23:13:26 --> Database Driver Class Initialized
INFO - 2019-08-26 23:13:26 --> Controller Class Initialized
INFO - 2019-08-26 23:13:26 --> Final output sent to browser
DEBUG - 2019-08-26 23:13:26 --> Total execution time: 1.4819
INFO - 2019-08-26 23:13:43 --> Config Class Initialized
INFO - 2019-08-26 23:13:43 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:13:43 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:13:43 --> Utf8 Class Initialized
INFO - 2019-08-26 23:13:43 --> URI Class Initialized
INFO - 2019-08-26 23:13:43 --> Router Class Initialized
INFO - 2019-08-26 23:13:43 --> Output Class Initialized
INFO - 2019-08-26 23:13:43 --> Security Class Initialized
DEBUG - 2019-08-26 23:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:13:43 --> Input Class Initialized
INFO - 2019-08-26 23:13:43 --> Language Class Initialized
INFO - 2019-08-26 23:13:43 --> Loader Class Initialized
INFO - 2019-08-26 23:13:43 --> Helper loaded: url_helper
INFO - 2019-08-26 23:13:43 --> Helper loaded: html_helper
INFO - 2019-08-26 23:13:43 --> Helper loaded: form_helper
INFO - 2019-08-26 23:13:43 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:13:43 --> Helper loaded: date_helper
INFO - 2019-08-26 23:13:44 --> Form Validation Class Initialized
INFO - 2019-08-26 23:13:44 --> Email Class Initialized
DEBUG - 2019-08-26 23:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:13:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:13:44 --> Pagination Class Initialized
INFO - 2019-08-26 23:13:44 --> Database Driver Class Initialized
INFO - 2019-08-26 23:13:44 --> Database Driver Class Initialized
INFO - 2019-08-26 23:13:44 --> Controller Class Initialized
INFO - 2019-08-26 23:13:44 --> Final output sent to browser
DEBUG - 2019-08-26 23:13:44 --> Total execution time: 0.6530
INFO - 2019-08-26 23:13:53 --> Config Class Initialized
INFO - 2019-08-26 23:13:53 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:13:53 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:13:53 --> Utf8 Class Initialized
INFO - 2019-08-26 23:13:53 --> URI Class Initialized
INFO - 2019-08-26 23:13:53 --> Router Class Initialized
INFO - 2019-08-26 23:13:53 --> Output Class Initialized
INFO - 2019-08-26 23:13:53 --> Security Class Initialized
DEBUG - 2019-08-26 23:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:13:53 --> Input Class Initialized
INFO - 2019-08-26 23:13:53 --> Language Class Initialized
INFO - 2019-08-26 23:13:53 --> Loader Class Initialized
INFO - 2019-08-26 23:13:53 --> Helper loaded: url_helper
INFO - 2019-08-26 23:13:53 --> Helper loaded: html_helper
INFO - 2019-08-26 23:13:53 --> Helper loaded: form_helper
INFO - 2019-08-26 23:13:53 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:13:53 --> Helper loaded: date_helper
INFO - 2019-08-26 23:13:53 --> Form Validation Class Initialized
INFO - 2019-08-26 23:13:53 --> Email Class Initialized
DEBUG - 2019-08-26 23:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:13:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:13:54 --> Pagination Class Initialized
INFO - 2019-08-26 23:13:54 --> Database Driver Class Initialized
INFO - 2019-08-26 23:13:54 --> Database Driver Class Initialized
INFO - 2019-08-26 23:13:54 --> Controller Class Initialized
INFO - 2019-08-26 23:13:54 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:13:54 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:13:54 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:13:54 --> Final output sent to browser
DEBUG - 2019-08-26 23:13:54 --> Total execution time: 0.9465
INFO - 2019-08-26 23:13:54 --> Config Class Initialized
INFO - 2019-08-26 23:13:54 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:13:54 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:13:54 --> Utf8 Class Initialized
INFO - 2019-08-26 23:13:54 --> URI Class Initialized
INFO - 2019-08-26 23:13:54 --> Router Class Initialized
INFO - 2019-08-26 23:13:54 --> Output Class Initialized
INFO - 2019-08-26 23:13:54 --> Config Class Initialized
INFO - 2019-08-26 23:13:54 --> Security Class Initialized
INFO - 2019-08-26 23:13:55 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:13:55 --> Input Class Initialized
INFO - 2019-08-26 23:13:55 --> Language Class Initialized
DEBUG - 2019-08-26 23:13:55 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:13:55 --> Utf8 Class Initialized
INFO - 2019-08-26 23:13:55 --> Loader Class Initialized
INFO - 2019-08-26 23:13:55 --> URI Class Initialized
INFO - 2019-08-26 23:13:55 --> Router Class Initialized
INFO - 2019-08-26 23:13:55 --> Helper loaded: url_helper
INFO - 2019-08-26 23:13:55 --> Helper loaded: html_helper
INFO - 2019-08-26 23:13:55 --> Output Class Initialized
INFO - 2019-08-26 23:13:55 --> Helper loaded: form_helper
INFO - 2019-08-26 23:13:55 --> Security Class Initialized
INFO - 2019-08-26 23:13:55 --> Helper loaded: cookie_helper
DEBUG - 2019-08-26 23:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:13:55 --> Helper loaded: date_helper
INFO - 2019-08-26 23:13:55 --> Input Class Initialized
INFO - 2019-08-26 23:13:55 --> Language Class Initialized
INFO - 2019-08-26 23:13:55 --> Form Validation Class Initialized
INFO - 2019-08-26 23:13:56 --> Loader Class Initialized
INFO - 2019-08-26 23:13:56 --> Email Class Initialized
INFO - 2019-08-26 23:13:56 --> Helper loaded: url_helper
DEBUG - 2019-08-26 23:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:13:56 --> Helper loaded: html_helper
INFO - 2019-08-26 23:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:13:56 --> Helper loaded: form_helper
INFO - 2019-08-26 23:13:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:13:56 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:13:56 --> Pagination Class Initialized
INFO - 2019-08-26 23:13:56 --> Helper loaded: date_helper
INFO - 2019-08-26 23:13:56 --> Database Driver Class Initialized
INFO - 2019-08-26 23:13:56 --> Form Validation Class Initialized
INFO - 2019-08-26 23:13:56 --> Database Driver Class Initialized
INFO - 2019-08-26 23:13:56 --> Email Class Initialized
INFO - 2019-08-26 23:13:56 --> Controller Class Initialized
DEBUG - 2019-08-26 23:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:13:56 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:13:56 --> Final output sent to browser
DEBUG - 2019-08-26 23:13:56 --> Total execution time: 1.9967
INFO - 2019-08-26 23:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:13:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:13:56 --> Pagination Class Initialized
INFO - 2019-08-26 23:13:56 --> Database Driver Class Initialized
INFO - 2019-08-26 23:13:56 --> Database Driver Class Initialized
INFO - 2019-08-26 23:13:56 --> Controller Class Initialized
INFO - 2019-08-26 23:13:56 --> Final output sent to browser
DEBUG - 2019-08-26 23:13:56 --> Total execution time: 1.8653
INFO - 2019-08-26 23:14:01 --> Config Class Initialized
INFO - 2019-08-26 23:14:01 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:14:01 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:14:01 --> Utf8 Class Initialized
INFO - 2019-08-26 23:14:01 --> URI Class Initialized
INFO - 2019-08-26 23:14:01 --> Router Class Initialized
INFO - 2019-08-26 23:14:01 --> Output Class Initialized
INFO - 2019-08-26 23:14:01 --> Security Class Initialized
DEBUG - 2019-08-26 23:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:14:01 --> Input Class Initialized
INFO - 2019-08-26 23:14:01 --> Language Class Initialized
INFO - 2019-08-26 23:14:01 --> Loader Class Initialized
INFO - 2019-08-26 23:14:01 --> Helper loaded: url_helper
INFO - 2019-08-26 23:14:01 --> Helper loaded: html_helper
INFO - 2019-08-26 23:14:01 --> Helper loaded: form_helper
INFO - 2019-08-26 23:14:01 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:14:01 --> Helper loaded: date_helper
INFO - 2019-08-26 23:14:01 --> Form Validation Class Initialized
INFO - 2019-08-26 23:14:01 --> Email Class Initialized
DEBUG - 2019-08-26 23:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:14:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:14:01 --> Pagination Class Initialized
INFO - 2019-08-26 23:14:01 --> Database Driver Class Initialized
INFO - 2019-08-26 23:14:02 --> Database Driver Class Initialized
INFO - 2019-08-26 23:14:02 --> Controller Class Initialized
INFO - 2019-08-26 23:14:02 --> Final output sent to browser
DEBUG - 2019-08-26 23:14:02 --> Total execution time: 0.6709
INFO - 2019-08-26 23:14:07 --> Config Class Initialized
INFO - 2019-08-26 23:14:07 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:14:07 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:14:07 --> Utf8 Class Initialized
INFO - 2019-08-26 23:14:07 --> URI Class Initialized
INFO - 2019-08-26 23:14:07 --> Router Class Initialized
INFO - 2019-08-26 23:14:07 --> Output Class Initialized
INFO - 2019-08-26 23:14:07 --> Security Class Initialized
DEBUG - 2019-08-26 23:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:14:07 --> Input Class Initialized
INFO - 2019-08-26 23:14:07 --> Language Class Initialized
INFO - 2019-08-26 23:14:08 --> Loader Class Initialized
INFO - 2019-08-26 23:14:08 --> Helper loaded: url_helper
INFO - 2019-08-26 23:14:08 --> Helper loaded: html_helper
INFO - 2019-08-26 23:14:08 --> Helper loaded: form_helper
INFO - 2019-08-26 23:14:08 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:14:08 --> Helper loaded: date_helper
INFO - 2019-08-26 23:14:08 --> Form Validation Class Initialized
INFO - 2019-08-26 23:14:08 --> Email Class Initialized
DEBUG - 2019-08-26 23:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:14:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:14:08 --> Pagination Class Initialized
INFO - 2019-08-26 23:14:08 --> Database Driver Class Initialized
INFO - 2019-08-26 23:14:08 --> Database Driver Class Initialized
INFO - 2019-08-26 23:14:08 --> Controller Class Initialized
INFO - 2019-08-26 23:14:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:14:08 --> Config Class Initialized
INFO - 2019-08-26 23:14:08 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:14:08 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:14:08 --> Utf8 Class Initialized
INFO - 2019-08-26 23:14:08 --> URI Class Initialized
INFO - 2019-08-26 23:14:08 --> Router Class Initialized
INFO - 2019-08-26 23:14:08 --> Output Class Initialized
INFO - 2019-08-26 23:14:08 --> Security Class Initialized
DEBUG - 2019-08-26 23:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:14:08 --> Input Class Initialized
INFO - 2019-08-26 23:14:08 --> Language Class Initialized
INFO - 2019-08-26 23:14:08 --> Loader Class Initialized
INFO - 2019-08-26 23:14:08 --> Helper loaded: url_helper
INFO - 2019-08-26 23:14:08 --> Helper loaded: html_helper
INFO - 2019-08-26 23:14:09 --> Helper loaded: form_helper
INFO - 2019-08-26 23:14:09 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:14:09 --> Helper loaded: date_helper
INFO - 2019-08-26 23:14:09 --> Form Validation Class Initialized
INFO - 2019-08-26 23:14:09 --> Email Class Initialized
DEBUG - 2019-08-26 23:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:14:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:14:09 --> Pagination Class Initialized
INFO - 2019-08-26 23:14:09 --> Database Driver Class Initialized
INFO - 2019-08-26 23:14:09 --> Database Driver Class Initialized
INFO - 2019-08-26 23:14:09 --> Controller Class Initialized
INFO - 2019-08-26 23:14:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:14:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:14:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:14:09 --> Final output sent to browser
DEBUG - 2019-08-26 23:14:09 --> Total execution time: 0.8742
INFO - 2019-08-26 23:14:09 --> Config Class Initialized
INFO - 2019-08-26 23:14:09 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:14:09 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:14:09 --> Utf8 Class Initialized
INFO - 2019-08-26 23:14:09 --> URI Class Initialized
INFO - 2019-08-26 23:14:09 --> Router Class Initialized
INFO - 2019-08-26 23:14:09 --> Output Class Initialized
INFO - 2019-08-26 23:14:09 --> Config Class Initialized
INFO - 2019-08-26 23:14:09 --> Security Class Initialized
INFO - 2019-08-26 23:14:09 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-26 23:14:10 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:14:10 --> Input Class Initialized
INFO - 2019-08-26 23:14:10 --> Utf8 Class Initialized
INFO - 2019-08-26 23:14:10 --> Language Class Initialized
INFO - 2019-08-26 23:14:10 --> URI Class Initialized
INFO - 2019-08-26 23:14:10 --> Loader Class Initialized
INFO - 2019-08-26 23:14:10 --> Router Class Initialized
INFO - 2019-08-26 23:14:10 --> Helper loaded: url_helper
INFO - 2019-08-26 23:14:10 --> Output Class Initialized
INFO - 2019-08-26 23:14:10 --> Helper loaded: html_helper
INFO - 2019-08-26 23:14:10 --> Security Class Initialized
DEBUG - 2019-08-26 23:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:14:10 --> Helper loaded: form_helper
INFO - 2019-08-26 23:14:10 --> Input Class Initialized
INFO - 2019-08-26 23:14:10 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:14:10 --> Language Class Initialized
INFO - 2019-08-26 23:14:10 --> Helper loaded: date_helper
INFO - 2019-08-26 23:14:10 --> Loader Class Initialized
INFO - 2019-08-26 23:14:10 --> Form Validation Class Initialized
INFO - 2019-08-26 23:14:10 --> Helper loaded: url_helper
INFO - 2019-08-26 23:14:10 --> Email Class Initialized
INFO - 2019-08-26 23:14:10 --> Helper loaded: html_helper
INFO - 2019-08-26 23:14:10 --> Helper loaded: form_helper
DEBUG - 2019-08-26 23:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:14:10 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:14:10 --> Helper loaded: date_helper
INFO - 2019-08-26 23:14:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:14:10 --> Form Validation Class Initialized
INFO - 2019-08-26 23:14:10 --> Pagination Class Initialized
INFO - 2019-08-26 23:14:10 --> Email Class Initialized
INFO - 2019-08-26 23:14:10 --> Database Driver Class Initialized
DEBUG - 2019-08-26 23:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:14:10 --> Database Driver Class Initialized
INFO - 2019-08-26 23:14:10 --> Controller Class Initialized
INFO - 2019-08-26 23:14:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:14:11 --> Final output sent to browser
DEBUG - 2019-08-26 23:14:11 --> Total execution time: 1.4097
INFO - 2019-08-26 23:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:14:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:14:11 --> Pagination Class Initialized
INFO - 2019-08-26 23:14:11 --> Database Driver Class Initialized
INFO - 2019-08-26 23:14:11 --> Database Driver Class Initialized
INFO - 2019-08-26 23:14:11 --> Controller Class Initialized
INFO - 2019-08-26 23:14:11 --> Final output sent to browser
DEBUG - 2019-08-26 23:14:11 --> Total execution time: 1.3694
INFO - 2019-08-26 23:15:01 --> Config Class Initialized
INFO - 2019-08-26 23:15:01 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:15:01 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:15:01 --> Utf8 Class Initialized
INFO - 2019-08-26 23:15:01 --> URI Class Initialized
INFO - 2019-08-26 23:15:01 --> Router Class Initialized
INFO - 2019-08-26 23:15:01 --> Output Class Initialized
INFO - 2019-08-26 23:15:01 --> Security Class Initialized
DEBUG - 2019-08-26 23:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:15:01 --> Input Class Initialized
INFO - 2019-08-26 23:15:01 --> Language Class Initialized
INFO - 2019-08-26 23:15:02 --> Loader Class Initialized
INFO - 2019-08-26 23:15:02 --> Helper loaded: url_helper
INFO - 2019-08-26 23:15:02 --> Helper loaded: html_helper
INFO - 2019-08-26 23:15:02 --> Helper loaded: form_helper
INFO - 2019-08-26 23:15:02 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:15:02 --> Helper loaded: date_helper
INFO - 2019-08-26 23:15:02 --> Form Validation Class Initialized
INFO - 2019-08-26 23:15:02 --> Email Class Initialized
DEBUG - 2019-08-26 23:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:15:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:15:02 --> Pagination Class Initialized
INFO - 2019-08-26 23:15:02 --> Database Driver Class Initialized
INFO - 2019-08-26 23:15:02 --> Database Driver Class Initialized
INFO - 2019-08-26 23:15:02 --> Controller Class Initialized
INFO - 2019-08-26 23:15:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:15:02 --> Config Class Initialized
INFO - 2019-08-26 23:15:02 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:15:03 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:15:03 --> Utf8 Class Initialized
INFO - 2019-08-26 23:15:03 --> URI Class Initialized
INFO - 2019-08-26 23:15:03 --> Router Class Initialized
INFO - 2019-08-26 23:15:03 --> Output Class Initialized
INFO - 2019-08-26 23:15:03 --> Security Class Initialized
DEBUG - 2019-08-26 23:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:15:03 --> Input Class Initialized
INFO - 2019-08-26 23:15:03 --> Language Class Initialized
INFO - 2019-08-26 23:15:03 --> Loader Class Initialized
INFO - 2019-08-26 23:15:03 --> Helper loaded: url_helper
INFO - 2019-08-26 23:15:03 --> Helper loaded: html_helper
INFO - 2019-08-26 23:15:03 --> Helper loaded: form_helper
INFO - 2019-08-26 23:15:03 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:15:03 --> Helper loaded: date_helper
INFO - 2019-08-26 23:15:03 --> Form Validation Class Initialized
INFO - 2019-08-26 23:15:03 --> Email Class Initialized
DEBUG - 2019-08-26 23:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:15:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:15:03 --> Pagination Class Initialized
INFO - 2019-08-26 23:15:03 --> Database Driver Class Initialized
INFO - 2019-08-26 23:15:03 --> Database Driver Class Initialized
INFO - 2019-08-26 23:15:03 --> Controller Class Initialized
INFO - 2019-08-26 23:15:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:15:03 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:15:04 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:15:04 --> Final output sent to browser
DEBUG - 2019-08-26 23:15:04 --> Total execution time: 1.0926
INFO - 2019-08-26 23:15:04 --> Config Class Initialized
INFO - 2019-08-26 23:15:04 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:15:04 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:15:04 --> Utf8 Class Initialized
INFO - 2019-08-26 23:15:04 --> URI Class Initialized
INFO - 2019-08-26 23:15:04 --> Router Class Initialized
INFO - 2019-08-26 23:15:04 --> Output Class Initialized
INFO - 2019-08-26 23:15:04 --> Config Class Initialized
INFO - 2019-08-26 23:15:04 --> Hooks Class Initialized
INFO - 2019-08-26 23:15:04 --> Security Class Initialized
DEBUG - 2019-08-26 23:15:04 --> UTF-8 Support Enabled
DEBUG - 2019-08-26 23:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:15:04 --> Utf8 Class Initialized
INFO - 2019-08-26 23:15:04 --> Input Class Initialized
INFO - 2019-08-26 23:15:04 --> URI Class Initialized
INFO - 2019-08-26 23:15:04 --> Language Class Initialized
INFO - 2019-08-26 23:15:04 --> Router Class Initialized
INFO - 2019-08-26 23:15:04 --> Loader Class Initialized
INFO - 2019-08-26 23:15:05 --> Output Class Initialized
INFO - 2019-08-26 23:15:05 --> Helper loaded: url_helper
INFO - 2019-08-26 23:15:05 --> Security Class Initialized
INFO - 2019-08-26 23:15:05 --> Helper loaded: html_helper
INFO - 2019-08-26 23:15:05 --> Helper loaded: form_helper
DEBUG - 2019-08-26 23:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:15:05 --> Input Class Initialized
INFO - 2019-08-26 23:15:05 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:15:05 --> Language Class Initialized
INFO - 2019-08-26 23:15:05 --> Helper loaded: date_helper
INFO - 2019-08-26 23:15:05 --> Loader Class Initialized
INFO - 2019-08-26 23:15:05 --> Form Validation Class Initialized
INFO - 2019-08-26 23:15:05 --> Helper loaded: url_helper
INFO - 2019-08-26 23:15:05 --> Email Class Initialized
INFO - 2019-08-26 23:15:05 --> Helper loaded: html_helper
INFO - 2019-08-26 23:15:05 --> Helper loaded: form_helper
DEBUG - 2019-08-26 23:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:15:05 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:15:05 --> Helper loaded: date_helper
INFO - 2019-08-26 23:15:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:15:05 --> Form Validation Class Initialized
INFO - 2019-08-26 23:15:05 --> Pagination Class Initialized
INFO - 2019-08-26 23:15:05 --> Email Class Initialized
INFO - 2019-08-26 23:15:05 --> Database Driver Class Initialized
DEBUG - 2019-08-26 23:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:15:05 --> Database Driver Class Initialized
INFO - 2019-08-26 23:15:05 --> Controller Class Initialized
INFO - 2019-08-26 23:15:05 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:15:05 --> Final output sent to browser
DEBUG - 2019-08-26 23:15:05 --> Total execution time: 1.6570
INFO - 2019-08-26 23:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:15:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:15:06 --> Pagination Class Initialized
INFO - 2019-08-26 23:15:06 --> Database Driver Class Initialized
INFO - 2019-08-26 23:15:06 --> Database Driver Class Initialized
INFO - 2019-08-26 23:15:06 --> Controller Class Initialized
INFO - 2019-08-26 23:15:06 --> Final output sent to browser
DEBUG - 2019-08-26 23:15:06 --> Total execution time: 1.5528
INFO - 2019-08-26 23:16:28 --> Config Class Initialized
INFO - 2019-08-26 23:16:28 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:16:28 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:16:28 --> Utf8 Class Initialized
INFO - 2019-08-26 23:16:28 --> URI Class Initialized
INFO - 2019-08-26 23:16:28 --> Router Class Initialized
INFO - 2019-08-26 23:16:28 --> Output Class Initialized
INFO - 2019-08-26 23:16:28 --> Security Class Initialized
DEBUG - 2019-08-26 23:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:16:28 --> Input Class Initialized
INFO - 2019-08-26 23:16:28 --> Language Class Initialized
INFO - 2019-08-26 23:16:28 --> Loader Class Initialized
INFO - 2019-08-26 23:16:28 --> Helper loaded: url_helper
INFO - 2019-08-26 23:16:28 --> Helper loaded: html_helper
INFO - 2019-08-26 23:16:28 --> Helper loaded: form_helper
INFO - 2019-08-26 23:16:28 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:16:28 --> Helper loaded: date_helper
INFO - 2019-08-26 23:16:28 --> Form Validation Class Initialized
INFO - 2019-08-26 23:16:28 --> Email Class Initialized
DEBUG - 2019-08-26 23:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:16:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:16:28 --> Pagination Class Initialized
INFO - 2019-08-26 23:16:28 --> Database Driver Class Initialized
INFO - 2019-08-26 23:16:28 --> Database Driver Class Initialized
INFO - 2019-08-26 23:16:29 --> Controller Class Initialized
INFO - 2019-08-26 23:16:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:16:29 --> Config Class Initialized
INFO - 2019-08-26 23:16:29 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:16:29 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:16:29 --> Utf8 Class Initialized
INFO - 2019-08-26 23:16:29 --> URI Class Initialized
INFO - 2019-08-26 23:16:29 --> Router Class Initialized
INFO - 2019-08-26 23:16:29 --> Output Class Initialized
INFO - 2019-08-26 23:16:29 --> Security Class Initialized
DEBUG - 2019-08-26 23:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:16:29 --> Input Class Initialized
INFO - 2019-08-26 23:16:29 --> Language Class Initialized
INFO - 2019-08-26 23:16:29 --> Loader Class Initialized
INFO - 2019-08-26 23:16:29 --> Helper loaded: url_helper
INFO - 2019-08-26 23:16:29 --> Helper loaded: html_helper
INFO - 2019-08-26 23:16:29 --> Helper loaded: form_helper
INFO - 2019-08-26 23:16:29 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:16:29 --> Helper loaded: date_helper
INFO - 2019-08-26 23:16:29 --> Form Validation Class Initialized
INFO - 2019-08-26 23:16:29 --> Email Class Initialized
DEBUG - 2019-08-26 23:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:16:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:16:29 --> Pagination Class Initialized
INFO - 2019-08-26 23:16:29 --> Database Driver Class Initialized
INFO - 2019-08-26 23:16:29 --> Database Driver Class Initialized
INFO - 2019-08-26 23:16:29 --> Controller Class Initialized
INFO - 2019-08-26 23:16:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:16:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:16:29 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:16:29 --> Final output sent to browser
DEBUG - 2019-08-26 23:16:30 --> Total execution time: 0.8322
INFO - 2019-08-26 23:16:30 --> Config Class Initialized
INFO - 2019-08-26 23:16:30 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:16:30 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:16:30 --> Utf8 Class Initialized
INFO - 2019-08-26 23:16:30 --> URI Class Initialized
INFO - 2019-08-26 23:16:30 --> Router Class Initialized
INFO - 2019-08-26 23:16:30 --> Config Class Initialized
INFO - 2019-08-26 23:16:30 --> Hooks Class Initialized
INFO - 2019-08-26 23:16:30 --> Output Class Initialized
DEBUG - 2019-08-26 23:16:30 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:16:30 --> Security Class Initialized
INFO - 2019-08-26 23:16:30 --> Utf8 Class Initialized
DEBUG - 2019-08-26 23:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:16:30 --> URI Class Initialized
INFO - 2019-08-26 23:16:30 --> Input Class Initialized
INFO - 2019-08-26 23:16:30 --> Router Class Initialized
INFO - 2019-08-26 23:16:30 --> Language Class Initialized
INFO - 2019-08-26 23:16:30 --> Output Class Initialized
INFO - 2019-08-26 23:16:30 --> Loader Class Initialized
INFO - 2019-08-26 23:16:30 --> Security Class Initialized
INFO - 2019-08-26 23:16:30 --> Helper loaded: url_helper
INFO - 2019-08-26 23:16:30 --> Helper loaded: html_helper
DEBUG - 2019-08-26 23:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:16:30 --> Input Class Initialized
INFO - 2019-08-26 23:16:30 --> Helper loaded: form_helper
INFO - 2019-08-26 23:16:31 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:16:31 --> Language Class Initialized
INFO - 2019-08-26 23:16:31 --> Helper loaded: date_helper
INFO - 2019-08-26 23:16:31 --> Loader Class Initialized
INFO - 2019-08-26 23:16:31 --> Form Validation Class Initialized
INFO - 2019-08-26 23:16:31 --> Helper loaded: url_helper
INFO - 2019-08-26 23:16:31 --> Email Class Initialized
INFO - 2019-08-26 23:16:31 --> Helper loaded: html_helper
DEBUG - 2019-08-26 23:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:16:31 --> Helper loaded: form_helper
INFO - 2019-08-26 23:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:16:31 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:16:31 --> Helper loaded: date_helper
INFO - 2019-08-26 23:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:16:31 --> Form Validation Class Initialized
INFO - 2019-08-26 23:16:31 --> Pagination Class Initialized
INFO - 2019-08-26 23:16:31 --> Email Class Initialized
INFO - 2019-08-26 23:16:31 --> Database Driver Class Initialized
DEBUG - 2019-08-26 23:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:16:31 --> Database Driver Class Initialized
INFO - 2019-08-26 23:16:31 --> Controller Class Initialized
INFO - 2019-08-26 23:16:31 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:16:31 --> Final output sent to browser
DEBUG - 2019-08-26 23:16:31 --> Total execution time: 1.5423
INFO - 2019-08-26 23:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:16:31 --> Pagination Class Initialized
INFO - 2019-08-26 23:16:31 --> Database Driver Class Initialized
INFO - 2019-08-26 23:16:31 --> Database Driver Class Initialized
INFO - 2019-08-26 23:16:31 --> Controller Class Initialized
INFO - 2019-08-26 23:16:31 --> Final output sent to browser
DEBUG - 2019-08-26 23:16:31 --> Total execution time: 1.4922
INFO - 2019-08-26 23:18:07 --> Config Class Initialized
INFO - 2019-08-26 23:18:07 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:18:07 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:18:07 --> Utf8 Class Initialized
INFO - 2019-08-26 23:18:07 --> URI Class Initialized
INFO - 2019-08-26 23:18:07 --> Router Class Initialized
INFO - 2019-08-26 23:18:07 --> Output Class Initialized
INFO - 2019-08-26 23:18:08 --> Security Class Initialized
DEBUG - 2019-08-26 23:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:18:08 --> Input Class Initialized
INFO - 2019-08-26 23:18:08 --> Language Class Initialized
INFO - 2019-08-26 23:18:08 --> Loader Class Initialized
INFO - 2019-08-26 23:18:08 --> Helper loaded: url_helper
INFO - 2019-08-26 23:18:08 --> Helper loaded: html_helper
INFO - 2019-08-26 23:18:08 --> Helper loaded: form_helper
INFO - 2019-08-26 23:18:08 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:18:08 --> Helper loaded: date_helper
INFO - 2019-08-26 23:18:08 --> Form Validation Class Initialized
INFO - 2019-08-26 23:18:08 --> Email Class Initialized
DEBUG - 2019-08-26 23:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:18:08 --> Pagination Class Initialized
INFO - 2019-08-26 23:18:08 --> Database Driver Class Initialized
INFO - 2019-08-26 23:18:08 --> Database Driver Class Initialized
INFO - 2019-08-26 23:18:08 --> Controller Class Initialized
INFO - 2019-08-26 23:18:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:18:08 --> Config Class Initialized
INFO - 2019-08-26 23:18:08 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:18:08 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:18:08 --> Utf8 Class Initialized
INFO - 2019-08-26 23:18:08 --> URI Class Initialized
INFO - 2019-08-26 23:18:08 --> Router Class Initialized
INFO - 2019-08-26 23:18:08 --> Output Class Initialized
INFO - 2019-08-26 23:18:08 --> Security Class Initialized
DEBUG - 2019-08-26 23:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:18:08 --> Input Class Initialized
INFO - 2019-08-26 23:18:08 --> Language Class Initialized
INFO - 2019-08-26 23:18:08 --> Loader Class Initialized
INFO - 2019-08-26 23:18:09 --> Helper loaded: url_helper
INFO - 2019-08-26 23:18:09 --> Helper loaded: html_helper
INFO - 2019-08-26 23:18:09 --> Helper loaded: form_helper
INFO - 2019-08-26 23:18:09 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:18:09 --> Helper loaded: date_helper
INFO - 2019-08-26 23:18:09 --> Form Validation Class Initialized
INFO - 2019-08-26 23:18:09 --> Email Class Initialized
DEBUG - 2019-08-26 23:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:18:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:18:09 --> Pagination Class Initialized
INFO - 2019-08-26 23:18:09 --> Database Driver Class Initialized
INFO - 2019-08-26 23:18:09 --> Database Driver Class Initialized
INFO - 2019-08-26 23:18:09 --> Controller Class Initialized
INFO - 2019-08-26 23:18:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:18:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:18:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:18:09 --> Final output sent to browser
DEBUG - 2019-08-26 23:18:09 --> Total execution time: 0.8868
INFO - 2019-08-26 23:18:09 --> Config Class Initialized
INFO - 2019-08-26 23:18:09 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:18:09 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:18:09 --> Utf8 Class Initialized
INFO - 2019-08-26 23:18:09 --> URI Class Initialized
INFO - 2019-08-26 23:18:09 --> Router Class Initialized
INFO - 2019-08-26 23:18:10 --> Output Class Initialized
INFO - 2019-08-26 23:18:10 --> Config Class Initialized
INFO - 2019-08-26 23:18:10 --> Hooks Class Initialized
INFO - 2019-08-26 23:18:10 --> Security Class Initialized
DEBUG - 2019-08-26 23:18:10 --> UTF-8 Support Enabled
DEBUG - 2019-08-26 23:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:18:10 --> Utf8 Class Initialized
INFO - 2019-08-26 23:18:10 --> Input Class Initialized
INFO - 2019-08-26 23:18:10 --> URI Class Initialized
INFO - 2019-08-26 23:18:10 --> Language Class Initialized
INFO - 2019-08-26 23:18:10 --> Router Class Initialized
INFO - 2019-08-26 23:18:10 --> Loader Class Initialized
INFO - 2019-08-26 23:18:10 --> Output Class Initialized
INFO - 2019-08-26 23:18:10 --> Helper loaded: url_helper
INFO - 2019-08-26 23:18:10 --> Security Class Initialized
INFO - 2019-08-26 23:18:10 --> Helper loaded: html_helper
DEBUG - 2019-08-26 23:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:18:10 --> Helper loaded: form_helper
INFO - 2019-08-26 23:18:10 --> Input Class Initialized
INFO - 2019-08-26 23:18:10 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:18:10 --> Language Class Initialized
INFO - 2019-08-26 23:18:10 --> Helper loaded: date_helper
INFO - 2019-08-26 23:18:10 --> Loader Class Initialized
INFO - 2019-08-26 23:18:10 --> Form Validation Class Initialized
INFO - 2019-08-26 23:18:10 --> Helper loaded: url_helper
INFO - 2019-08-26 23:18:10 --> Email Class Initialized
INFO - 2019-08-26 23:18:10 --> Helper loaded: html_helper
DEBUG - 2019-08-26 23:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:18:11 --> Helper loaded: form_helper
INFO - 2019-08-26 23:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:18:11 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:18:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:18:11 --> Helper loaded: date_helper
INFO - 2019-08-26 23:18:11 --> Pagination Class Initialized
INFO - 2019-08-26 23:18:11 --> Form Validation Class Initialized
INFO - 2019-08-26 23:18:11 --> Database Driver Class Initialized
INFO - 2019-08-26 23:18:11 --> Email Class Initialized
INFO - 2019-08-26 23:18:11 --> Database Driver Class Initialized
DEBUG - 2019-08-26 23:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:18:11 --> Controller Class Initialized
INFO - 2019-08-26 23:18:11 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:18:11 --> Final output sent to browser
DEBUG - 2019-08-26 23:18:11 --> Total execution time: 1.6303
INFO - 2019-08-26 23:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:18:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:18:11 --> Pagination Class Initialized
INFO - 2019-08-26 23:18:11 --> Database Driver Class Initialized
INFO - 2019-08-26 23:18:11 --> Database Driver Class Initialized
INFO - 2019-08-26 23:18:11 --> Controller Class Initialized
INFO - 2019-08-26 23:18:11 --> Final output sent to browser
DEBUG - 2019-08-26 23:18:11 --> Total execution time: 1.5561
INFO - 2019-08-26 23:19:21 --> Config Class Initialized
INFO - 2019-08-26 23:19:21 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:19:21 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:19:21 --> Utf8 Class Initialized
INFO - 2019-08-26 23:19:21 --> URI Class Initialized
INFO - 2019-08-26 23:19:21 --> Router Class Initialized
INFO - 2019-08-26 23:19:21 --> Output Class Initialized
INFO - 2019-08-26 23:19:21 --> Security Class Initialized
DEBUG - 2019-08-26 23:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:19:21 --> Input Class Initialized
INFO - 2019-08-26 23:19:21 --> Language Class Initialized
INFO - 2019-08-26 23:19:21 --> Loader Class Initialized
INFO - 2019-08-26 23:19:21 --> Helper loaded: url_helper
INFO - 2019-08-26 23:19:21 --> Helper loaded: html_helper
INFO - 2019-08-26 23:19:21 --> Helper loaded: form_helper
INFO - 2019-08-26 23:19:21 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:19:21 --> Helper loaded: date_helper
INFO - 2019-08-26 23:19:21 --> Form Validation Class Initialized
INFO - 2019-08-26 23:19:21 --> Email Class Initialized
DEBUG - 2019-08-26 23:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:19:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:19:21 --> Pagination Class Initialized
INFO - 2019-08-26 23:19:21 --> Database Driver Class Initialized
INFO - 2019-08-26 23:19:21 --> Database Driver Class Initialized
INFO - 2019-08-26 23:19:21 --> Controller Class Initialized
INFO - 2019-08-26 23:19:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:19:22 --> Config Class Initialized
INFO - 2019-08-26 23:19:22 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:19:22 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:19:22 --> Utf8 Class Initialized
INFO - 2019-08-26 23:19:22 --> URI Class Initialized
INFO - 2019-08-26 23:19:22 --> Router Class Initialized
INFO - 2019-08-26 23:19:22 --> Output Class Initialized
INFO - 2019-08-26 23:19:22 --> Security Class Initialized
DEBUG - 2019-08-26 23:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:19:22 --> Input Class Initialized
INFO - 2019-08-26 23:19:22 --> Language Class Initialized
INFO - 2019-08-26 23:19:22 --> Loader Class Initialized
INFO - 2019-08-26 23:19:22 --> Helper loaded: url_helper
INFO - 2019-08-26 23:19:22 --> Helper loaded: html_helper
INFO - 2019-08-26 23:19:22 --> Helper loaded: form_helper
INFO - 2019-08-26 23:19:22 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:19:22 --> Helper loaded: date_helper
INFO - 2019-08-26 23:19:22 --> Form Validation Class Initialized
INFO - 2019-08-26 23:19:22 --> Email Class Initialized
DEBUG - 2019-08-26 23:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:19:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:19:22 --> Pagination Class Initialized
INFO - 2019-08-26 23:19:22 --> Database Driver Class Initialized
INFO - 2019-08-26 23:19:22 --> Database Driver Class Initialized
INFO - 2019-08-26 23:19:22 --> Controller Class Initialized
INFO - 2019-08-26 23:19:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:19:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:19:22 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:19:22 --> Final output sent to browser
DEBUG - 2019-08-26 23:19:22 --> Total execution time: 0.8703
INFO - 2019-08-26 23:19:23 --> Config Class Initialized
INFO - 2019-08-26 23:19:23 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:19:23 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:19:23 --> Utf8 Class Initialized
INFO - 2019-08-26 23:19:23 --> URI Class Initialized
INFO - 2019-08-26 23:19:23 --> Router Class Initialized
INFO - 2019-08-26 23:19:23 --> Output Class Initialized
INFO - 2019-08-26 23:19:23 --> Config Class Initialized
INFO - 2019-08-26 23:19:23 --> Security Class Initialized
INFO - 2019-08-26 23:19:23 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:19:23 --> Input Class Initialized
DEBUG - 2019-08-26 23:19:23 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:19:23 --> Utf8 Class Initialized
INFO - 2019-08-26 23:19:23 --> Language Class Initialized
INFO - 2019-08-26 23:19:23 --> URI Class Initialized
INFO - 2019-08-26 23:19:23 --> Loader Class Initialized
INFO - 2019-08-26 23:19:23 --> Router Class Initialized
INFO - 2019-08-26 23:19:23 --> Output Class Initialized
INFO - 2019-08-26 23:19:23 --> Helper loaded: url_helper
INFO - 2019-08-26 23:19:23 --> Helper loaded: html_helper
INFO - 2019-08-26 23:19:23 --> Security Class Initialized
INFO - 2019-08-26 23:19:23 --> Helper loaded: form_helper
DEBUG - 2019-08-26 23:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:19:23 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:19:23 --> Input Class Initialized
INFO - 2019-08-26 23:19:24 --> Language Class Initialized
INFO - 2019-08-26 23:19:24 --> Helper loaded: date_helper
INFO - 2019-08-26 23:19:24 --> Form Validation Class Initialized
INFO - 2019-08-26 23:19:24 --> Loader Class Initialized
INFO - 2019-08-26 23:19:24 --> Email Class Initialized
INFO - 2019-08-26 23:19:24 --> Helper loaded: url_helper
DEBUG - 2019-08-26 23:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:19:24 --> Helper loaded: html_helper
INFO - 2019-08-26 23:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:19:24 --> Helper loaded: form_helper
INFO - 2019-08-26 23:19:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:19:24 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:19:24 --> Pagination Class Initialized
INFO - 2019-08-26 23:19:24 --> Helper loaded: date_helper
INFO - 2019-08-26 23:19:24 --> Database Driver Class Initialized
INFO - 2019-08-26 23:19:24 --> Form Validation Class Initialized
INFO - 2019-08-26 23:19:24 --> Database Driver Class Initialized
INFO - 2019-08-26 23:19:24 --> Email Class Initialized
INFO - 2019-08-26 23:19:24 --> Controller Class Initialized
DEBUG - 2019-08-26 23:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:19:24 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:19:24 --> Final output sent to browser
DEBUG - 2019-08-26 23:19:24 --> Total execution time: 1.5482
INFO - 2019-08-26 23:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:19:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:19:24 --> Pagination Class Initialized
INFO - 2019-08-26 23:19:24 --> Database Driver Class Initialized
INFO - 2019-08-26 23:19:24 --> Database Driver Class Initialized
INFO - 2019-08-26 23:19:24 --> Controller Class Initialized
INFO - 2019-08-26 23:19:24 --> Final output sent to browser
DEBUG - 2019-08-26 23:19:24 --> Total execution time: 1.5336
INFO - 2019-08-26 23:21:15 --> Config Class Initialized
INFO - 2019-08-26 23:21:15 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:21:15 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:21:15 --> Utf8 Class Initialized
INFO - 2019-08-26 23:21:15 --> URI Class Initialized
INFO - 2019-08-26 23:21:15 --> Router Class Initialized
INFO - 2019-08-26 23:21:15 --> Output Class Initialized
INFO - 2019-08-26 23:21:15 --> Security Class Initialized
DEBUG - 2019-08-26 23:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:21:15 --> Input Class Initialized
INFO - 2019-08-26 23:21:15 --> Language Class Initialized
INFO - 2019-08-26 23:21:15 --> Loader Class Initialized
INFO - 2019-08-26 23:21:15 --> Helper loaded: url_helper
INFO - 2019-08-26 23:21:15 --> Helper loaded: html_helper
INFO - 2019-08-26 23:21:15 --> Helper loaded: form_helper
INFO - 2019-08-26 23:21:15 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:21:15 --> Helper loaded: date_helper
INFO - 2019-08-26 23:21:15 --> Form Validation Class Initialized
INFO - 2019-08-26 23:21:15 --> Email Class Initialized
DEBUG - 2019-08-26 23:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:21:15 --> Pagination Class Initialized
INFO - 2019-08-26 23:21:15 --> Database Driver Class Initialized
INFO - 2019-08-26 23:21:15 --> Database Driver Class Initialized
INFO - 2019-08-26 23:21:15 --> Controller Class Initialized
INFO - 2019-08-26 23:21:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:21:15 --> Config Class Initialized
INFO - 2019-08-26 23:21:15 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:21:15 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:21:16 --> Utf8 Class Initialized
INFO - 2019-08-26 23:21:16 --> URI Class Initialized
INFO - 2019-08-26 23:21:16 --> Router Class Initialized
INFO - 2019-08-26 23:21:16 --> Output Class Initialized
INFO - 2019-08-26 23:21:16 --> Security Class Initialized
DEBUG - 2019-08-26 23:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:21:16 --> Input Class Initialized
INFO - 2019-08-26 23:21:16 --> Language Class Initialized
INFO - 2019-08-26 23:21:16 --> Loader Class Initialized
INFO - 2019-08-26 23:21:16 --> Helper loaded: url_helper
INFO - 2019-08-26 23:21:16 --> Helper loaded: html_helper
INFO - 2019-08-26 23:21:16 --> Helper loaded: form_helper
INFO - 2019-08-26 23:21:16 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:21:16 --> Helper loaded: date_helper
INFO - 2019-08-26 23:21:16 --> Form Validation Class Initialized
INFO - 2019-08-26 23:21:16 --> Email Class Initialized
DEBUG - 2019-08-26 23:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:21:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:21:16 --> Pagination Class Initialized
INFO - 2019-08-26 23:21:16 --> Database Driver Class Initialized
INFO - 2019-08-26 23:21:16 --> Database Driver Class Initialized
INFO - 2019-08-26 23:21:16 --> Controller Class Initialized
INFO - 2019-08-26 23:21:16 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:21:16 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:21:16 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:21:16 --> Final output sent to browser
DEBUG - 2019-08-26 23:21:16 --> Total execution time: 0.8444
INFO - 2019-08-26 23:21:16 --> Config Class Initialized
INFO - 2019-08-26 23:21:17 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:21:17 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:21:17 --> Utf8 Class Initialized
INFO - 2019-08-26 23:21:17 --> URI Class Initialized
INFO - 2019-08-26 23:21:17 --> Router Class Initialized
INFO - 2019-08-26 23:21:17 --> Output Class Initialized
INFO - 2019-08-26 23:21:17 --> Config Class Initialized
INFO - 2019-08-26 23:21:17 --> Security Class Initialized
INFO - 2019-08-26 23:21:17 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-26 23:21:17 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:21:17 --> Input Class Initialized
INFO - 2019-08-26 23:21:17 --> Utf8 Class Initialized
INFO - 2019-08-26 23:21:17 --> Language Class Initialized
INFO - 2019-08-26 23:21:17 --> URI Class Initialized
INFO - 2019-08-26 23:21:17 --> Loader Class Initialized
INFO - 2019-08-26 23:21:17 --> Router Class Initialized
INFO - 2019-08-26 23:21:17 --> Helper loaded: url_helper
INFO - 2019-08-26 23:21:17 --> Output Class Initialized
INFO - 2019-08-26 23:21:17 --> Helper loaded: html_helper
INFO - 2019-08-26 23:21:17 --> Security Class Initialized
INFO - 2019-08-26 23:21:17 --> Helper loaded: form_helper
DEBUG - 2019-08-26 23:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:21:17 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:21:17 --> Input Class Initialized
INFO - 2019-08-26 23:21:17 --> Helper loaded: date_helper
INFO - 2019-08-26 23:21:17 --> Language Class Initialized
INFO - 2019-08-26 23:21:17 --> Form Validation Class Initialized
INFO - 2019-08-26 23:21:17 --> Loader Class Initialized
INFO - 2019-08-26 23:21:17 --> Email Class Initialized
INFO - 2019-08-26 23:21:18 --> Helper loaded: url_helper
DEBUG - 2019-08-26 23:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:21:18 --> Helper loaded: html_helper
INFO - 2019-08-26 23:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:21:18 --> Helper loaded: form_helper
INFO - 2019-08-26 23:21:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:21:18 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:21:18 --> Pagination Class Initialized
INFO - 2019-08-26 23:21:18 --> Helper loaded: date_helper
INFO - 2019-08-26 23:21:18 --> Database Driver Class Initialized
INFO - 2019-08-26 23:21:18 --> Form Validation Class Initialized
INFO - 2019-08-26 23:21:18 --> Database Driver Class Initialized
INFO - 2019-08-26 23:21:18 --> Email Class Initialized
INFO - 2019-08-26 23:21:18 --> Controller Class Initialized
DEBUG - 2019-08-26 23:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:21:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:21:18 --> Final output sent to browser
DEBUG - 2019-08-26 23:21:18 --> Total execution time: 1.5083
INFO - 2019-08-26 23:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:21:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:21:18 --> Pagination Class Initialized
INFO - 2019-08-26 23:21:18 --> Database Driver Class Initialized
INFO - 2019-08-26 23:21:18 --> Database Driver Class Initialized
INFO - 2019-08-26 23:21:18 --> Controller Class Initialized
INFO - 2019-08-26 23:21:18 --> Final output sent to browser
DEBUG - 2019-08-26 23:21:18 --> Total execution time: 1.4258
INFO - 2019-08-26 23:22:37 --> Config Class Initialized
INFO - 2019-08-26 23:22:37 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:22:37 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:22:37 --> Utf8 Class Initialized
INFO - 2019-08-26 23:22:37 --> URI Class Initialized
INFO - 2019-08-26 23:22:37 --> Router Class Initialized
INFO - 2019-08-26 23:22:37 --> Output Class Initialized
INFO - 2019-08-26 23:22:37 --> Security Class Initialized
DEBUG - 2019-08-26 23:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:22:37 --> Input Class Initialized
INFO - 2019-08-26 23:22:37 --> Language Class Initialized
INFO - 2019-08-26 23:22:37 --> Loader Class Initialized
INFO - 2019-08-26 23:22:37 --> Helper loaded: url_helper
INFO - 2019-08-26 23:22:37 --> Helper loaded: html_helper
INFO - 2019-08-26 23:22:37 --> Helper loaded: form_helper
INFO - 2019-08-26 23:22:37 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:22:37 --> Helper loaded: date_helper
INFO - 2019-08-26 23:22:37 --> Form Validation Class Initialized
INFO - 2019-08-26 23:22:37 --> Email Class Initialized
DEBUG - 2019-08-26 23:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:22:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:22:38 --> Pagination Class Initialized
INFO - 2019-08-26 23:22:38 --> Database Driver Class Initialized
INFO - 2019-08-26 23:22:38 --> Database Driver Class Initialized
INFO - 2019-08-26 23:22:38 --> Controller Class Initialized
INFO - 2019-08-26 23:22:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:22:38 --> Config Class Initialized
INFO - 2019-08-26 23:22:38 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:22:38 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:22:38 --> Utf8 Class Initialized
INFO - 2019-08-26 23:22:38 --> URI Class Initialized
INFO - 2019-08-26 23:22:38 --> Router Class Initialized
INFO - 2019-08-26 23:22:38 --> Output Class Initialized
INFO - 2019-08-26 23:22:38 --> Security Class Initialized
DEBUG - 2019-08-26 23:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:22:38 --> Input Class Initialized
INFO - 2019-08-26 23:22:38 --> Language Class Initialized
INFO - 2019-08-26 23:22:38 --> Loader Class Initialized
INFO - 2019-08-26 23:22:38 --> Helper loaded: url_helper
INFO - 2019-08-26 23:22:38 --> Helper loaded: html_helper
INFO - 2019-08-26 23:22:38 --> Helper loaded: form_helper
INFO - 2019-08-26 23:22:38 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:22:38 --> Helper loaded: date_helper
INFO - 2019-08-26 23:22:38 --> Form Validation Class Initialized
INFO - 2019-08-26 23:22:38 --> Email Class Initialized
DEBUG - 2019-08-26 23:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:22:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:22:38 --> Pagination Class Initialized
INFO - 2019-08-26 23:22:38 --> Database Driver Class Initialized
INFO - 2019-08-26 23:22:38 --> Database Driver Class Initialized
INFO - 2019-08-26 23:22:38 --> Controller Class Initialized
INFO - 2019-08-26 23:22:38 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:22:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:22:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:22:39 --> Final output sent to browser
DEBUG - 2019-08-26 23:22:39 --> Total execution time: 0.8497
INFO - 2019-08-26 23:22:39 --> Config Class Initialized
INFO - 2019-08-26 23:22:39 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:22:39 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:22:39 --> Utf8 Class Initialized
INFO - 2019-08-26 23:22:39 --> URI Class Initialized
INFO - 2019-08-26 23:22:39 --> Router Class Initialized
INFO - 2019-08-26 23:22:39 --> Output Class Initialized
INFO - 2019-08-26 23:22:39 --> Config Class Initialized
INFO - 2019-08-26 23:22:39 --> Security Class Initialized
INFO - 2019-08-26 23:22:39 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-26 23:22:39 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:22:39 --> Input Class Initialized
INFO - 2019-08-26 23:22:39 --> Utf8 Class Initialized
INFO - 2019-08-26 23:22:39 --> Language Class Initialized
INFO - 2019-08-26 23:22:39 --> URI Class Initialized
INFO - 2019-08-26 23:22:39 --> Loader Class Initialized
INFO - 2019-08-26 23:22:39 --> Router Class Initialized
INFO - 2019-08-26 23:22:39 --> Helper loaded: url_helper
INFO - 2019-08-26 23:22:39 --> Output Class Initialized
INFO - 2019-08-26 23:22:39 --> Helper loaded: html_helper
INFO - 2019-08-26 23:22:39 --> Security Class Initialized
INFO - 2019-08-26 23:22:39 --> Helper loaded: form_helper
DEBUG - 2019-08-26 23:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:22:40 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:22:40 --> Input Class Initialized
INFO - 2019-08-26 23:22:40 --> Language Class Initialized
INFO - 2019-08-26 23:22:40 --> Helper loaded: date_helper
INFO - 2019-08-26 23:22:40 --> Loader Class Initialized
INFO - 2019-08-26 23:22:40 --> Form Validation Class Initialized
INFO - 2019-08-26 23:22:40 --> Helper loaded: url_helper
INFO - 2019-08-26 23:22:40 --> Email Class Initialized
INFO - 2019-08-26 23:22:40 --> Helper loaded: html_helper
DEBUG - 2019-08-26 23:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:22:40 --> Helper loaded: form_helper
INFO - 2019-08-26 23:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:22:40 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:22:40 --> Helper loaded: date_helper
INFO - 2019-08-26 23:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:22:40 --> Form Validation Class Initialized
INFO - 2019-08-26 23:22:40 --> Pagination Class Initialized
INFO - 2019-08-26 23:22:40 --> Email Class Initialized
INFO - 2019-08-26 23:22:40 --> Database Driver Class Initialized
DEBUG - 2019-08-26 23:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:22:40 --> Database Driver Class Initialized
INFO - 2019-08-26 23:22:40 --> Controller Class Initialized
INFO - 2019-08-26 23:22:40 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:22:40 --> Final output sent to browser
DEBUG - 2019-08-26 23:22:40 --> Total execution time: 1.4648
INFO - 2019-08-26 23:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:22:40 --> Pagination Class Initialized
INFO - 2019-08-26 23:22:40 --> Database Driver Class Initialized
INFO - 2019-08-26 23:22:40 --> Database Driver Class Initialized
INFO - 2019-08-26 23:22:40 --> Controller Class Initialized
INFO - 2019-08-26 23:22:40 --> Final output sent to browser
DEBUG - 2019-08-26 23:22:41 --> Total execution time: 1.4294
INFO - 2019-08-26 23:23:55 --> Config Class Initialized
INFO - 2019-08-26 23:23:56 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:23:56 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:23:56 --> Utf8 Class Initialized
INFO - 2019-08-26 23:23:56 --> URI Class Initialized
INFO - 2019-08-26 23:23:56 --> Router Class Initialized
INFO - 2019-08-26 23:23:56 --> Output Class Initialized
INFO - 2019-08-26 23:23:56 --> Security Class Initialized
DEBUG - 2019-08-26 23:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:23:56 --> Input Class Initialized
INFO - 2019-08-26 23:23:56 --> Language Class Initialized
INFO - 2019-08-26 23:23:56 --> Loader Class Initialized
INFO - 2019-08-26 23:23:56 --> Helper loaded: url_helper
INFO - 2019-08-26 23:23:56 --> Helper loaded: html_helper
INFO - 2019-08-26 23:23:56 --> Helper loaded: form_helper
INFO - 2019-08-26 23:23:56 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:23:56 --> Helper loaded: date_helper
INFO - 2019-08-26 23:23:56 --> Form Validation Class Initialized
INFO - 2019-08-26 23:23:56 --> Email Class Initialized
DEBUG - 2019-08-26 23:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:23:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:23:56 --> Pagination Class Initialized
INFO - 2019-08-26 23:23:56 --> Database Driver Class Initialized
INFO - 2019-08-26 23:23:56 --> Database Driver Class Initialized
INFO - 2019-08-26 23:23:56 --> Controller Class Initialized
INFO - 2019-08-26 23:23:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:23:56 --> Config Class Initialized
INFO - 2019-08-26 23:23:56 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:23:56 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:23:56 --> Utf8 Class Initialized
INFO - 2019-08-26 23:23:56 --> URI Class Initialized
INFO - 2019-08-26 23:23:56 --> Router Class Initialized
INFO - 2019-08-26 23:23:56 --> Output Class Initialized
INFO - 2019-08-26 23:23:57 --> Security Class Initialized
DEBUG - 2019-08-26 23:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:23:57 --> Input Class Initialized
INFO - 2019-08-26 23:23:57 --> Language Class Initialized
INFO - 2019-08-26 23:23:57 --> Loader Class Initialized
INFO - 2019-08-26 23:23:57 --> Helper loaded: url_helper
INFO - 2019-08-26 23:23:57 --> Helper loaded: html_helper
INFO - 2019-08-26 23:23:57 --> Helper loaded: form_helper
INFO - 2019-08-26 23:23:57 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:23:57 --> Helper loaded: date_helper
INFO - 2019-08-26 23:23:57 --> Form Validation Class Initialized
INFO - 2019-08-26 23:23:57 --> Email Class Initialized
DEBUG - 2019-08-26 23:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:23:57 --> Pagination Class Initialized
INFO - 2019-08-26 23:23:57 --> Database Driver Class Initialized
INFO - 2019-08-26 23:23:57 --> Database Driver Class Initialized
INFO - 2019-08-26 23:23:58 --> Controller Class Initialized
INFO - 2019-08-26 23:23:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:23:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:23:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:23:58 --> Final output sent to browser
DEBUG - 2019-08-26 23:23:58 --> Total execution time: 1.4203
INFO - 2019-08-26 23:23:59 --> Config Class Initialized
INFO - 2019-08-26 23:23:59 --> Config Class Initialized
INFO - 2019-08-26 23:23:59 --> Hooks Class Initialized
INFO - 2019-08-26 23:23:59 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:23:59 --> UTF-8 Support Enabled
DEBUG - 2019-08-26 23:23:59 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:23:59 --> Utf8 Class Initialized
INFO - 2019-08-26 23:23:59 --> Utf8 Class Initialized
INFO - 2019-08-26 23:23:59 --> URI Class Initialized
INFO - 2019-08-26 23:23:59 --> URI Class Initialized
INFO - 2019-08-26 23:24:00 --> Router Class Initialized
INFO - 2019-08-26 23:24:00 --> Router Class Initialized
INFO - 2019-08-26 23:24:00 --> Output Class Initialized
INFO - 2019-08-26 23:24:00 --> Output Class Initialized
INFO - 2019-08-26 23:24:00 --> Security Class Initialized
INFO - 2019-08-26 23:24:00 --> Security Class Initialized
DEBUG - 2019-08-26 23:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-26 23:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:24:00 --> Input Class Initialized
INFO - 2019-08-26 23:24:00 --> Input Class Initialized
INFO - 2019-08-26 23:24:00 --> Language Class Initialized
INFO - 2019-08-26 23:24:00 --> Language Class Initialized
INFO - 2019-08-26 23:24:00 --> Loader Class Initialized
INFO - 2019-08-26 23:24:00 --> Loader Class Initialized
INFO - 2019-08-26 23:24:00 --> Helper loaded: url_helper
INFO - 2019-08-26 23:24:00 --> Helper loaded: url_helper
INFO - 2019-08-26 23:24:00 --> Helper loaded: html_helper
INFO - 2019-08-26 23:24:00 --> Helper loaded: html_helper
INFO - 2019-08-26 23:24:00 --> Helper loaded: form_helper
INFO - 2019-08-26 23:24:00 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:24:00 --> Helper loaded: form_helper
INFO - 2019-08-26 23:24:00 --> Helper loaded: date_helper
INFO - 2019-08-26 23:24:00 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:24:00 --> Form Validation Class Initialized
INFO - 2019-08-26 23:24:00 --> Helper loaded: date_helper
INFO - 2019-08-26 23:24:00 --> Email Class Initialized
INFO - 2019-08-26 23:24:00 --> Form Validation Class Initialized
DEBUG - 2019-08-26 23:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:24:00 --> Email Class Initialized
INFO - 2019-08-26 23:24:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-08-26 23:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:24:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:24:00 --> Pagination Class Initialized
INFO - 2019-08-26 23:24:00 --> Database Driver Class Initialized
INFO - 2019-08-26 23:24:00 --> Database Driver Class Initialized
INFO - 2019-08-26 23:24:00 --> Controller Class Initialized
INFO - 2019-08-26 23:24:00 --> Final output sent to browser
DEBUG - 2019-08-26 23:24:00 --> Total execution time: 1.1321
INFO - 2019-08-26 23:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:24:01 --> Pagination Class Initialized
INFO - 2019-08-26 23:24:01 --> Database Driver Class Initialized
INFO - 2019-08-26 23:24:01 --> Database Driver Class Initialized
INFO - 2019-08-26 23:24:01 --> Controller Class Initialized
INFO - 2019-08-26 23:24:01 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:24:01 --> Final output sent to browser
DEBUG - 2019-08-26 23:24:01 --> Total execution time: 1.5483
INFO - 2019-08-26 23:24:31 --> Config Class Initialized
INFO - 2019-08-26 23:24:31 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:24:31 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:24:31 --> Utf8 Class Initialized
INFO - 2019-08-26 23:24:31 --> URI Class Initialized
INFO - 2019-08-26 23:24:31 --> Router Class Initialized
INFO - 2019-08-26 23:24:31 --> Output Class Initialized
INFO - 2019-08-26 23:24:31 --> Security Class Initialized
DEBUG - 2019-08-26 23:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:24:31 --> Input Class Initialized
INFO - 2019-08-26 23:24:31 --> Language Class Initialized
INFO - 2019-08-26 23:24:31 --> Loader Class Initialized
INFO - 2019-08-26 23:24:31 --> Helper loaded: url_helper
INFO - 2019-08-26 23:24:31 --> Helper loaded: html_helper
INFO - 2019-08-26 23:24:31 --> Helper loaded: form_helper
INFO - 2019-08-26 23:24:31 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:24:31 --> Helper loaded: date_helper
INFO - 2019-08-26 23:24:31 --> Form Validation Class Initialized
INFO - 2019-08-26 23:24:31 --> Email Class Initialized
DEBUG - 2019-08-26 23:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:24:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:24:31 --> Pagination Class Initialized
INFO - 2019-08-26 23:24:31 --> Database Driver Class Initialized
INFO - 2019-08-26 23:24:31 --> Database Driver Class Initialized
INFO - 2019-08-26 23:24:31 --> Controller Class Initialized
INFO - 2019-08-26 23:24:31 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:24:31 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:24:32 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:24:32 --> Final output sent to browser
DEBUG - 2019-08-26 23:24:32 --> Total execution time: 1.0392
INFO - 2019-08-26 23:24:33 --> Config Class Initialized
INFO - 2019-08-26 23:24:33 --> Hooks Class Initialized
INFO - 2019-08-26 23:24:33 --> Config Class Initialized
DEBUG - 2019-08-26 23:24:33 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:24:33 --> Hooks Class Initialized
INFO - 2019-08-26 23:24:33 --> Utf8 Class Initialized
DEBUG - 2019-08-26 23:24:33 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:24:33 --> URI Class Initialized
INFO - 2019-08-26 23:24:33 --> Utf8 Class Initialized
INFO - 2019-08-26 23:24:34 --> URI Class Initialized
INFO - 2019-08-26 23:24:34 --> Router Class Initialized
INFO - 2019-08-26 23:24:34 --> Router Class Initialized
INFO - 2019-08-26 23:24:34 --> Output Class Initialized
INFO - 2019-08-26 23:24:34 --> Output Class Initialized
INFO - 2019-08-26 23:24:34 --> Security Class Initialized
INFO - 2019-08-26 23:24:34 --> Security Class Initialized
DEBUG - 2019-08-26 23:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-26 23:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:24:34 --> Input Class Initialized
INFO - 2019-08-26 23:24:34 --> Input Class Initialized
INFO - 2019-08-26 23:24:34 --> Language Class Initialized
INFO - 2019-08-26 23:24:34 --> Language Class Initialized
INFO - 2019-08-26 23:24:34 --> Loader Class Initialized
INFO - 2019-08-26 23:24:34 --> Loader Class Initialized
INFO - 2019-08-26 23:24:34 --> Helper loaded: url_helper
INFO - 2019-08-26 23:24:34 --> Helper loaded: url_helper
INFO - 2019-08-26 23:24:34 --> Helper loaded: html_helper
INFO - 2019-08-26 23:24:34 --> Helper loaded: html_helper
INFO - 2019-08-26 23:24:34 --> Helper loaded: form_helper
INFO - 2019-08-26 23:24:34 --> Helper loaded: form_helper
INFO - 2019-08-26 23:24:34 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:24:34 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:24:34 --> Helper loaded: date_helper
INFO - 2019-08-26 23:24:34 --> Helper loaded: date_helper
INFO - 2019-08-26 23:24:34 --> Form Validation Class Initialized
INFO - 2019-08-26 23:24:34 --> Form Validation Class Initialized
INFO - 2019-08-26 23:24:34 --> Email Class Initialized
INFO - 2019-08-26 23:24:34 --> Email Class Initialized
DEBUG - 2019-08-26 23:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-08-26 23:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:24:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:24:34 --> Pagination Class Initialized
INFO - 2019-08-26 23:24:34 --> Database Driver Class Initialized
INFO - 2019-08-26 23:24:34 --> Database Driver Class Initialized
INFO - 2019-08-26 23:24:34 --> Controller Class Initialized
INFO - 2019-08-26 23:24:35 --> Final output sent to browser
DEBUG - 2019-08-26 23:24:35 --> Total execution time: 1.2717
INFO - 2019-08-26 23:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:24:35 --> Pagination Class Initialized
INFO - 2019-08-26 23:24:35 --> Database Driver Class Initialized
INFO - 2019-08-26 23:24:35 --> Database Driver Class Initialized
INFO - 2019-08-26 23:24:35 --> Controller Class Initialized
INFO - 2019-08-26 23:24:35 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:24:35 --> Final output sent to browser
DEBUG - 2019-08-26 23:24:35 --> Total execution time: 1.7014
INFO - 2019-08-26 23:24:45 --> Config Class Initialized
INFO - 2019-08-26 23:24:45 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:24:46 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:24:46 --> Utf8 Class Initialized
INFO - 2019-08-26 23:24:46 --> URI Class Initialized
INFO - 2019-08-26 23:24:46 --> Router Class Initialized
INFO - 2019-08-26 23:24:46 --> Output Class Initialized
INFO - 2019-08-26 23:24:46 --> Security Class Initialized
DEBUG - 2019-08-26 23:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:24:46 --> Input Class Initialized
INFO - 2019-08-26 23:24:46 --> Language Class Initialized
INFO - 2019-08-26 23:24:46 --> Loader Class Initialized
INFO - 2019-08-26 23:24:46 --> Helper loaded: url_helper
INFO - 2019-08-26 23:24:46 --> Helper loaded: html_helper
INFO - 2019-08-26 23:24:46 --> Helper loaded: form_helper
INFO - 2019-08-26 23:24:46 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:24:46 --> Helper loaded: date_helper
INFO - 2019-08-26 23:24:46 --> Form Validation Class Initialized
INFO - 2019-08-26 23:24:46 --> Email Class Initialized
DEBUG - 2019-08-26 23:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:24:46 --> Pagination Class Initialized
INFO - 2019-08-26 23:24:46 --> Database Driver Class Initialized
INFO - 2019-08-26 23:24:46 --> Database Driver Class Initialized
INFO - 2019-08-26 23:24:46 --> Controller Class Initialized
INFO - 2019-08-26 23:24:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:24:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:24:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:24:46 --> Final output sent to browser
DEBUG - 2019-08-26 23:24:46 --> Total execution time: 0.9105
INFO - 2019-08-26 23:24:47 --> Config Class Initialized
INFO - 2019-08-26 23:24:47 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:24:47 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:24:47 --> Utf8 Class Initialized
INFO - 2019-08-26 23:24:47 --> URI Class Initialized
INFO - 2019-08-26 23:24:47 --> Router Class Initialized
INFO - 2019-08-26 23:24:47 --> Config Class Initialized
INFO - 2019-08-26 23:24:47 --> Hooks Class Initialized
INFO - 2019-08-26 23:24:47 --> Output Class Initialized
DEBUG - 2019-08-26 23:24:47 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:24:47 --> Security Class Initialized
INFO - 2019-08-26 23:24:47 --> Utf8 Class Initialized
INFO - 2019-08-26 23:24:47 --> URI Class Initialized
DEBUG - 2019-08-26 23:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:24:47 --> Input Class Initialized
INFO - 2019-08-26 23:24:47 --> Router Class Initialized
INFO - 2019-08-26 23:24:47 --> Language Class Initialized
INFO - 2019-08-26 23:24:47 --> Output Class Initialized
INFO - 2019-08-26 23:24:47 --> Loader Class Initialized
INFO - 2019-08-26 23:24:47 --> Security Class Initialized
INFO - 2019-08-26 23:24:47 --> Helper loaded: url_helper
DEBUG - 2019-08-26 23:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:24:47 --> Input Class Initialized
INFO - 2019-08-26 23:24:48 --> Helper loaded: html_helper
INFO - 2019-08-26 23:24:48 --> Language Class Initialized
INFO - 2019-08-26 23:24:48 --> Helper loaded: form_helper
INFO - 2019-08-26 23:24:48 --> Loader Class Initialized
INFO - 2019-08-26 23:24:48 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:24:48 --> Helper loaded: url_helper
INFO - 2019-08-26 23:24:48 --> Helper loaded: date_helper
INFO - 2019-08-26 23:24:48 --> Helper loaded: html_helper
INFO - 2019-08-26 23:24:48 --> Form Validation Class Initialized
INFO - 2019-08-26 23:24:48 --> Helper loaded: form_helper
INFO - 2019-08-26 23:24:48 --> Email Class Initialized
INFO - 2019-08-26 23:24:48 --> Helper loaded: cookie_helper
DEBUG - 2019-08-26 23:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:24:48 --> Helper loaded: date_helper
INFO - 2019-08-26 23:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:24:48 --> Form Validation Class Initialized
INFO - 2019-08-26 23:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:24:48 --> Email Class Initialized
INFO - 2019-08-26 23:24:48 --> Pagination Class Initialized
DEBUG - 2019-08-26 23:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:24:48 --> Database Driver Class Initialized
INFO - 2019-08-26 23:24:48 --> Database Driver Class Initialized
INFO - 2019-08-26 23:24:48 --> Controller Class Initialized
INFO - 2019-08-26 23:24:48 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:24:48 --> Final output sent to browser
DEBUG - 2019-08-26 23:24:48 --> Total execution time: 1.6547
INFO - 2019-08-26 23:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:24:48 --> Pagination Class Initialized
INFO - 2019-08-26 23:24:48 --> Database Driver Class Initialized
INFO - 2019-08-26 23:24:48 --> Database Driver Class Initialized
INFO - 2019-08-26 23:24:48 --> Controller Class Initialized
INFO - 2019-08-26 23:24:48 --> Final output sent to browser
DEBUG - 2019-08-26 23:24:49 --> Total execution time: 1.5807
INFO - 2019-08-26 23:27:16 --> Config Class Initialized
INFO - 2019-08-26 23:27:16 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:27:16 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:27:16 --> Utf8 Class Initialized
INFO - 2019-08-26 23:27:16 --> URI Class Initialized
INFO - 2019-08-26 23:27:16 --> Router Class Initialized
INFO - 2019-08-26 23:27:16 --> Output Class Initialized
INFO - 2019-08-26 23:27:16 --> Security Class Initialized
DEBUG - 2019-08-26 23:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:27:16 --> Input Class Initialized
INFO - 2019-08-26 23:27:16 --> Language Class Initialized
INFO - 2019-08-26 23:27:16 --> Loader Class Initialized
INFO - 2019-08-26 23:27:16 --> Helper loaded: url_helper
INFO - 2019-08-26 23:27:16 --> Helper loaded: html_helper
INFO - 2019-08-26 23:27:16 --> Helper loaded: form_helper
INFO - 2019-08-26 23:27:16 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:27:16 --> Helper loaded: date_helper
INFO - 2019-08-26 23:27:16 --> Form Validation Class Initialized
INFO - 2019-08-26 23:27:16 --> Email Class Initialized
DEBUG - 2019-08-26 23:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:27:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:27:16 --> Pagination Class Initialized
INFO - 2019-08-26 23:27:17 --> Database Driver Class Initialized
INFO - 2019-08-26 23:27:17 --> Database Driver Class Initialized
INFO - 2019-08-26 23:27:17 --> Controller Class Initialized
INFO - 2019-08-26 23:27:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:27:17 --> Config Class Initialized
INFO - 2019-08-26 23:27:17 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:27:17 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:27:17 --> Utf8 Class Initialized
INFO - 2019-08-26 23:27:17 --> URI Class Initialized
INFO - 2019-08-26 23:27:17 --> Router Class Initialized
INFO - 2019-08-26 23:27:17 --> Output Class Initialized
INFO - 2019-08-26 23:27:17 --> Security Class Initialized
DEBUG - 2019-08-26 23:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:27:17 --> Input Class Initialized
INFO - 2019-08-26 23:27:17 --> Language Class Initialized
INFO - 2019-08-26 23:27:17 --> Loader Class Initialized
INFO - 2019-08-26 23:27:17 --> Helper loaded: url_helper
INFO - 2019-08-26 23:27:17 --> Helper loaded: html_helper
INFO - 2019-08-26 23:27:17 --> Helper loaded: form_helper
INFO - 2019-08-26 23:27:17 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:27:17 --> Helper loaded: date_helper
INFO - 2019-08-26 23:27:17 --> Form Validation Class Initialized
INFO - 2019-08-26 23:27:17 --> Email Class Initialized
DEBUG - 2019-08-26 23:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:27:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:27:17 --> Pagination Class Initialized
INFO - 2019-08-26 23:27:17 --> Database Driver Class Initialized
INFO - 2019-08-26 23:27:17 --> Database Driver Class Initialized
INFO - 2019-08-26 23:27:17 --> Controller Class Initialized
INFO - 2019-08-26 23:27:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:27:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:27:18 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:27:18 --> Final output sent to browser
DEBUG - 2019-08-26 23:27:18 --> Total execution time: 0.8952
INFO - 2019-08-26 23:27:18 --> Config Class Initialized
INFO - 2019-08-26 23:27:18 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:27:18 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:27:18 --> Utf8 Class Initialized
INFO - 2019-08-26 23:27:18 --> URI Class Initialized
INFO - 2019-08-26 23:27:18 --> Router Class Initialized
INFO - 2019-08-26 23:27:18 --> Config Class Initialized
INFO - 2019-08-26 23:27:18 --> Output Class Initialized
INFO - 2019-08-26 23:27:18 --> Hooks Class Initialized
INFO - 2019-08-26 23:27:18 --> Security Class Initialized
DEBUG - 2019-08-26 23:27:18 --> UTF-8 Support Enabled
DEBUG - 2019-08-26 23:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:27:18 --> Utf8 Class Initialized
INFO - 2019-08-26 23:27:18 --> Input Class Initialized
INFO - 2019-08-26 23:27:18 --> URI Class Initialized
INFO - 2019-08-26 23:27:18 --> Language Class Initialized
INFO - 2019-08-26 23:27:18 --> Router Class Initialized
INFO - 2019-08-26 23:27:18 --> Loader Class Initialized
INFO - 2019-08-26 23:27:18 --> Output Class Initialized
INFO - 2019-08-26 23:27:19 --> Helper loaded: url_helper
INFO - 2019-08-26 23:27:19 --> Security Class Initialized
INFO - 2019-08-26 23:27:19 --> Helper loaded: html_helper
DEBUG - 2019-08-26 23:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:27:19 --> Helper loaded: form_helper
INFO - 2019-08-26 23:27:19 --> Input Class Initialized
INFO - 2019-08-26 23:27:19 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:27:19 --> Language Class Initialized
INFO - 2019-08-26 23:27:19 --> Helper loaded: date_helper
INFO - 2019-08-26 23:27:19 --> Loader Class Initialized
INFO - 2019-08-26 23:27:19 --> Form Validation Class Initialized
INFO - 2019-08-26 23:27:19 --> Helper loaded: url_helper
INFO - 2019-08-26 23:27:19 --> Email Class Initialized
INFO - 2019-08-26 23:27:19 --> Helper loaded: html_helper
DEBUG - 2019-08-26 23:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:27:19 --> Helper loaded: form_helper
INFO - 2019-08-26 23:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:27:19 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:27:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:27:19 --> Helper loaded: date_helper
INFO - 2019-08-26 23:27:19 --> Pagination Class Initialized
INFO - 2019-08-26 23:27:19 --> Form Validation Class Initialized
INFO - 2019-08-26 23:27:19 --> Database Driver Class Initialized
INFO - 2019-08-26 23:27:19 --> Email Class Initialized
INFO - 2019-08-26 23:27:19 --> Database Driver Class Initialized
DEBUG - 2019-08-26 23:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:27:19 --> Controller Class Initialized
INFO - 2019-08-26 23:27:19 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:27:19 --> Final output sent to browser
DEBUG - 2019-08-26 23:27:20 --> Total execution time: 1.6687
INFO - 2019-08-26 23:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:27:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:27:20 --> Pagination Class Initialized
INFO - 2019-08-26 23:27:20 --> Database Driver Class Initialized
INFO - 2019-08-26 23:27:20 --> Database Driver Class Initialized
INFO - 2019-08-26 23:27:20 --> Controller Class Initialized
INFO - 2019-08-26 23:27:20 --> Final output sent to browser
DEBUG - 2019-08-26 23:27:20 --> Total execution time: 1.7102
INFO - 2019-08-26 23:27:56 --> Config Class Initialized
INFO - 2019-08-26 23:27:56 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:27:56 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:27:56 --> Utf8 Class Initialized
INFO - 2019-08-26 23:27:56 --> URI Class Initialized
INFO - 2019-08-26 23:27:56 --> Router Class Initialized
INFO - 2019-08-26 23:27:56 --> Output Class Initialized
INFO - 2019-08-26 23:27:56 --> Security Class Initialized
DEBUG - 2019-08-26 23:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:27:56 --> Input Class Initialized
INFO - 2019-08-26 23:27:56 --> Language Class Initialized
INFO - 2019-08-26 23:27:56 --> Loader Class Initialized
INFO - 2019-08-26 23:27:56 --> Helper loaded: url_helper
INFO - 2019-08-26 23:27:56 --> Helper loaded: html_helper
INFO - 2019-08-26 23:27:56 --> Helper loaded: form_helper
INFO - 2019-08-26 23:27:56 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:27:56 --> Helper loaded: date_helper
INFO - 2019-08-26 23:27:56 --> Form Validation Class Initialized
INFO - 2019-08-26 23:27:56 --> Email Class Initialized
DEBUG - 2019-08-26 23:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:27:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:27:57 --> Pagination Class Initialized
INFO - 2019-08-26 23:27:57 --> Database Driver Class Initialized
INFO - 2019-08-26 23:27:57 --> Database Driver Class Initialized
INFO - 2019-08-26 23:27:57 --> Controller Class Initialized
INFO - 2019-08-26 23:27:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:27:57 --> Config Class Initialized
INFO - 2019-08-26 23:27:57 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:27:57 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:27:57 --> Utf8 Class Initialized
INFO - 2019-08-26 23:27:57 --> URI Class Initialized
INFO - 2019-08-26 23:27:57 --> Router Class Initialized
INFO - 2019-08-26 23:27:57 --> Output Class Initialized
INFO - 2019-08-26 23:27:57 --> Security Class Initialized
DEBUG - 2019-08-26 23:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:27:57 --> Input Class Initialized
INFO - 2019-08-26 23:27:57 --> Language Class Initialized
INFO - 2019-08-26 23:27:57 --> Loader Class Initialized
INFO - 2019-08-26 23:27:57 --> Helper loaded: url_helper
INFO - 2019-08-26 23:27:57 --> Helper loaded: html_helper
INFO - 2019-08-26 23:27:57 --> Helper loaded: form_helper
INFO - 2019-08-26 23:27:57 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:27:57 --> Helper loaded: date_helper
INFO - 2019-08-26 23:27:57 --> Form Validation Class Initialized
INFO - 2019-08-26 23:27:57 --> Email Class Initialized
DEBUG - 2019-08-26 23:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:27:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:27:57 --> Pagination Class Initialized
INFO - 2019-08-26 23:27:57 --> Database Driver Class Initialized
INFO - 2019-08-26 23:27:57 --> Database Driver Class Initialized
INFO - 2019-08-26 23:27:57 --> Controller Class Initialized
INFO - 2019-08-26 23:27:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:27:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:27:58 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:27:58 --> Final output sent to browser
DEBUG - 2019-08-26 23:27:58 --> Total execution time: 0.8768
INFO - 2019-08-26 23:27:58 --> Config Class Initialized
INFO - 2019-08-26 23:27:58 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:27:58 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:27:58 --> Utf8 Class Initialized
INFO - 2019-08-26 23:27:58 --> URI Class Initialized
INFO - 2019-08-26 23:27:58 --> Router Class Initialized
INFO - 2019-08-26 23:27:58 --> Output Class Initialized
INFO - 2019-08-26 23:27:58 --> Config Class Initialized
INFO - 2019-08-26 23:27:58 --> Security Class Initialized
INFO - 2019-08-26 23:27:58 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-08-26 23:27:58 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:27:58 --> Input Class Initialized
INFO - 2019-08-26 23:27:58 --> Utf8 Class Initialized
INFO - 2019-08-26 23:27:58 --> Language Class Initialized
INFO - 2019-08-26 23:27:58 --> URI Class Initialized
INFO - 2019-08-26 23:27:58 --> Loader Class Initialized
INFO - 2019-08-26 23:27:58 --> Router Class Initialized
INFO - 2019-08-26 23:27:58 --> Helper loaded: url_helper
INFO - 2019-08-26 23:27:58 --> Output Class Initialized
INFO - 2019-08-26 23:27:59 --> Helper loaded: html_helper
INFO - 2019-08-26 23:27:59 --> Security Class Initialized
INFO - 2019-08-26 23:27:59 --> Helper loaded: form_helper
DEBUG - 2019-08-26 23:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:27:59 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:27:59 --> Input Class Initialized
INFO - 2019-08-26 23:27:59 --> Language Class Initialized
INFO - 2019-08-26 23:27:59 --> Helper loaded: date_helper
INFO - 2019-08-26 23:27:59 --> Loader Class Initialized
INFO - 2019-08-26 23:27:59 --> Form Validation Class Initialized
INFO - 2019-08-26 23:27:59 --> Helper loaded: url_helper
INFO - 2019-08-26 23:27:59 --> Email Class Initialized
INFO - 2019-08-26 23:27:59 --> Helper loaded: html_helper
DEBUG - 2019-08-26 23:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:27:59 --> Helper loaded: form_helper
INFO - 2019-08-26 23:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:27:59 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:27:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:27:59 --> Helper loaded: date_helper
INFO - 2019-08-26 23:27:59 --> Pagination Class Initialized
INFO - 2019-08-26 23:27:59 --> Form Validation Class Initialized
INFO - 2019-08-26 23:27:59 --> Email Class Initialized
INFO - 2019-08-26 23:27:59 --> Database Driver Class Initialized
DEBUG - 2019-08-26 23:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:27:59 --> Database Driver Class Initialized
INFO - 2019-08-26 23:27:59 --> Controller Class Initialized
INFO - 2019-08-26 23:27:59 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:27:59 --> Final output sent to browser
DEBUG - 2019-08-26 23:27:59 --> Total execution time: 1.5884
INFO - 2019-08-26 23:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:27:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:28:00 --> Pagination Class Initialized
INFO - 2019-08-26 23:28:00 --> Database Driver Class Initialized
INFO - 2019-08-26 23:28:00 --> Database Driver Class Initialized
INFO - 2019-08-26 23:28:00 --> Controller Class Initialized
INFO - 2019-08-26 23:28:00 --> Final output sent to browser
DEBUG - 2019-08-26 23:28:00 --> Total execution time: 1.5485
INFO - 2019-08-26 23:30:05 --> Config Class Initialized
INFO - 2019-08-26 23:30:05 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:30:05 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:30:05 --> Utf8 Class Initialized
INFO - 2019-08-26 23:30:05 --> URI Class Initialized
INFO - 2019-08-26 23:30:05 --> Router Class Initialized
INFO - 2019-08-26 23:30:05 --> Output Class Initialized
INFO - 2019-08-26 23:30:05 --> Security Class Initialized
DEBUG - 2019-08-26 23:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:30:05 --> Input Class Initialized
INFO - 2019-08-26 23:30:05 --> Language Class Initialized
INFO - 2019-08-26 23:30:05 --> Loader Class Initialized
INFO - 2019-08-26 23:30:05 --> Helper loaded: url_helper
INFO - 2019-08-26 23:30:05 --> Helper loaded: html_helper
INFO - 2019-08-26 23:30:05 --> Helper loaded: form_helper
INFO - 2019-08-26 23:30:05 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:30:06 --> Helper loaded: date_helper
INFO - 2019-08-26 23:30:06 --> Form Validation Class Initialized
INFO - 2019-08-26 23:30:06 --> Email Class Initialized
DEBUG - 2019-08-26 23:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:30:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:30:06 --> Pagination Class Initialized
INFO - 2019-08-26 23:30:06 --> Database Driver Class Initialized
INFO - 2019-08-26 23:30:06 --> Database Driver Class Initialized
INFO - 2019-08-26 23:30:06 --> Controller Class Initialized
INFO - 2019-08-26 23:30:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:30:06 --> Config Class Initialized
INFO - 2019-08-26 23:30:06 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:30:06 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:30:06 --> Utf8 Class Initialized
INFO - 2019-08-26 23:30:06 --> URI Class Initialized
INFO - 2019-08-26 23:30:06 --> Router Class Initialized
INFO - 2019-08-26 23:30:06 --> Output Class Initialized
INFO - 2019-08-26 23:30:06 --> Security Class Initialized
DEBUG - 2019-08-26 23:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:30:06 --> Input Class Initialized
INFO - 2019-08-26 23:30:06 --> Language Class Initialized
INFO - 2019-08-26 23:30:06 --> Loader Class Initialized
INFO - 2019-08-26 23:30:06 --> Helper loaded: url_helper
INFO - 2019-08-26 23:30:06 --> Helper loaded: html_helper
INFO - 2019-08-26 23:30:06 --> Helper loaded: form_helper
INFO - 2019-08-26 23:30:06 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:30:06 --> Helper loaded: date_helper
INFO - 2019-08-26 23:30:06 --> Form Validation Class Initialized
INFO - 2019-08-26 23:30:06 --> Email Class Initialized
DEBUG - 2019-08-26 23:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:30:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:30:07 --> Pagination Class Initialized
INFO - 2019-08-26 23:30:07 --> Database Driver Class Initialized
INFO - 2019-08-26 23:30:07 --> Database Driver Class Initialized
INFO - 2019-08-26 23:30:07 --> Controller Class Initialized
INFO - 2019-08-26 23:30:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:30:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:30:07 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:30:07 --> Final output sent to browser
DEBUG - 2019-08-26 23:30:07 --> Total execution time: 0.8847
INFO - 2019-08-26 23:30:07 --> Config Class Initialized
INFO - 2019-08-26 23:30:07 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:30:07 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:30:07 --> Utf8 Class Initialized
INFO - 2019-08-26 23:30:07 --> URI Class Initialized
INFO - 2019-08-26 23:30:07 --> Router Class Initialized
INFO - 2019-08-26 23:30:07 --> Config Class Initialized
INFO - 2019-08-26 23:30:07 --> Hooks Class Initialized
INFO - 2019-08-26 23:30:07 --> Output Class Initialized
DEBUG - 2019-08-26 23:30:07 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:30:08 --> Security Class Initialized
INFO - 2019-08-26 23:30:08 --> Utf8 Class Initialized
INFO - 2019-08-26 23:30:08 --> URI Class Initialized
DEBUG - 2019-08-26 23:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:30:08 --> Input Class Initialized
INFO - 2019-08-26 23:30:08 --> Router Class Initialized
INFO - 2019-08-26 23:30:08 --> Language Class Initialized
INFO - 2019-08-26 23:30:08 --> Output Class Initialized
INFO - 2019-08-26 23:30:08 --> Loader Class Initialized
INFO - 2019-08-26 23:30:08 --> Security Class Initialized
INFO - 2019-08-26 23:30:08 --> Helper loaded: url_helper
DEBUG - 2019-08-26 23:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:30:08 --> Helper loaded: html_helper
INFO - 2019-08-26 23:30:08 --> Input Class Initialized
INFO - 2019-08-26 23:30:08 --> Language Class Initialized
INFO - 2019-08-26 23:30:08 --> Helper loaded: form_helper
INFO - 2019-08-26 23:30:08 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:30:08 --> Loader Class Initialized
INFO - 2019-08-26 23:30:08 --> Helper loaded: date_helper
INFO - 2019-08-26 23:30:08 --> Helper loaded: url_helper
INFO - 2019-08-26 23:30:08 --> Form Validation Class Initialized
INFO - 2019-08-26 23:30:08 --> Helper loaded: html_helper
INFO - 2019-08-26 23:30:08 --> Email Class Initialized
INFO - 2019-08-26 23:30:08 --> Helper loaded: form_helper
DEBUG - 2019-08-26 23:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:30:08 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:30:08 --> Helper loaded: date_helper
INFO - 2019-08-26 23:30:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:30:08 --> Form Validation Class Initialized
INFO - 2019-08-26 23:30:08 --> Pagination Class Initialized
INFO - 2019-08-26 23:30:08 --> Email Class Initialized
INFO - 2019-08-26 23:30:08 --> Database Driver Class Initialized
DEBUG - 2019-08-26 23:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:30:08 --> Database Driver Class Initialized
INFO - 2019-08-26 23:30:09 --> Controller Class Initialized
INFO - 2019-08-26 23:30:09 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:30:09 --> Final output sent to browser
DEBUG - 2019-08-26 23:30:09 --> Total execution time: 1.5890
INFO - 2019-08-26 23:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:30:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:30:09 --> Pagination Class Initialized
INFO - 2019-08-26 23:30:09 --> Database Driver Class Initialized
INFO - 2019-08-26 23:30:09 --> Database Driver Class Initialized
INFO - 2019-08-26 23:30:09 --> Controller Class Initialized
INFO - 2019-08-26 23:30:09 --> Final output sent to browser
DEBUG - 2019-08-26 23:30:09 --> Total execution time: 1.5470
INFO - 2019-08-26 23:31:31 --> Config Class Initialized
INFO - 2019-08-26 23:31:31 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:31:31 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:31:31 --> Utf8 Class Initialized
INFO - 2019-08-26 23:31:31 --> URI Class Initialized
INFO - 2019-08-26 23:31:32 --> Router Class Initialized
INFO - 2019-08-26 23:31:32 --> Output Class Initialized
INFO - 2019-08-26 23:31:32 --> Security Class Initialized
DEBUG - 2019-08-26 23:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:31:32 --> Input Class Initialized
INFO - 2019-08-26 23:31:32 --> Language Class Initialized
INFO - 2019-08-26 23:31:32 --> Loader Class Initialized
INFO - 2019-08-26 23:31:32 --> Helper loaded: url_helper
INFO - 2019-08-26 23:31:32 --> Helper loaded: html_helper
INFO - 2019-08-26 23:31:32 --> Helper loaded: form_helper
INFO - 2019-08-26 23:31:32 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:31:32 --> Helper loaded: date_helper
INFO - 2019-08-26 23:31:32 --> Form Validation Class Initialized
INFO - 2019-08-26 23:31:32 --> Email Class Initialized
DEBUG - 2019-08-26 23:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:31:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:31:32 --> Pagination Class Initialized
INFO - 2019-08-26 23:31:32 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:32 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:32 --> Controller Class Initialized
INFO - 2019-08-26 23:31:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-08-26 23:31:32 --> Config Class Initialized
INFO - 2019-08-26 23:31:32 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:31:32 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:31:32 --> Utf8 Class Initialized
INFO - 2019-08-26 23:31:32 --> URI Class Initialized
INFO - 2019-08-26 23:31:32 --> Router Class Initialized
INFO - 2019-08-26 23:31:32 --> Output Class Initialized
INFO - 2019-08-26 23:31:32 --> Security Class Initialized
DEBUG - 2019-08-26 23:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:31:32 --> Input Class Initialized
INFO - 2019-08-26 23:31:33 --> Language Class Initialized
INFO - 2019-08-26 23:31:33 --> Loader Class Initialized
INFO - 2019-08-26 23:31:33 --> Helper loaded: url_helper
INFO - 2019-08-26 23:31:33 --> Helper loaded: html_helper
INFO - 2019-08-26 23:31:33 --> Helper loaded: form_helper
INFO - 2019-08-26 23:31:33 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:31:33 --> Helper loaded: date_helper
INFO - 2019-08-26 23:31:33 --> Form Validation Class Initialized
INFO - 2019-08-26 23:31:33 --> Email Class Initialized
DEBUG - 2019-08-26 23:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:31:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:31:33 --> Pagination Class Initialized
INFO - 2019-08-26 23:31:33 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:33 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:33 --> Controller Class Initialized
INFO - 2019-08-26 23:31:33 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:31:33 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/price.php
INFO - 2019-08-26 23:31:33 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:31:33 --> Final output sent to browser
DEBUG - 2019-08-26 23:31:33 --> Total execution time: 0.9183
INFO - 2019-08-26 23:31:33 --> Config Class Initialized
INFO - 2019-08-26 23:31:33 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:31:33 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:31:33 --> Utf8 Class Initialized
INFO - 2019-08-26 23:31:34 --> URI Class Initialized
INFO - 2019-08-26 23:31:34 --> Router Class Initialized
INFO - 2019-08-26 23:31:34 --> Config Class Initialized
INFO - 2019-08-26 23:31:34 --> Output Class Initialized
INFO - 2019-08-26 23:31:34 --> Hooks Class Initialized
INFO - 2019-08-26 23:31:34 --> Security Class Initialized
DEBUG - 2019-08-26 23:31:34 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:31:34 --> Utf8 Class Initialized
DEBUG - 2019-08-26 23:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:31:34 --> Input Class Initialized
INFO - 2019-08-26 23:31:34 --> URI Class Initialized
INFO - 2019-08-26 23:31:34 --> Language Class Initialized
INFO - 2019-08-26 23:31:34 --> Router Class Initialized
INFO - 2019-08-26 23:31:34 --> Loader Class Initialized
INFO - 2019-08-26 23:31:34 --> Output Class Initialized
INFO - 2019-08-26 23:31:34 --> Helper loaded: url_helper
INFO - 2019-08-26 23:31:34 --> Security Class Initialized
DEBUG - 2019-08-26 23:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:31:34 --> Helper loaded: html_helper
INFO - 2019-08-26 23:31:34 --> Input Class Initialized
INFO - 2019-08-26 23:31:34 --> Language Class Initialized
INFO - 2019-08-26 23:31:34 --> Helper loaded: form_helper
INFO - 2019-08-26 23:31:34 --> Loader Class Initialized
INFO - 2019-08-26 23:31:34 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:31:34 --> Helper loaded: url_helper
INFO - 2019-08-26 23:31:34 --> Helper loaded: date_helper
INFO - 2019-08-26 23:31:34 --> Helper loaded: html_helper
INFO - 2019-08-26 23:31:34 --> Form Validation Class Initialized
INFO - 2019-08-26 23:31:34 --> Helper loaded: form_helper
INFO - 2019-08-26 23:31:34 --> Email Class Initialized
INFO - 2019-08-26 23:31:35 --> Helper loaded: cookie_helper
DEBUG - 2019-08-26 23:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:31:35 --> Helper loaded: date_helper
INFO - 2019-08-26 23:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:31:35 --> Form Validation Class Initialized
INFO - 2019-08-26 23:31:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:31:35 --> Email Class Initialized
INFO - 2019-08-26 23:31:35 --> Pagination Class Initialized
DEBUG - 2019-08-26 23:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:31:35 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:35 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:35 --> Controller Class Initialized
INFO - 2019-08-26 23:31:35 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:31:35 --> Final output sent to browser
DEBUG - 2019-08-26 23:31:35 --> Total execution time: 1.5635
INFO - 2019-08-26 23:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:31:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:31:35 --> Pagination Class Initialized
INFO - 2019-08-26 23:31:35 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:35 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:35 --> Controller Class Initialized
INFO - 2019-08-26 23:31:35 --> Final output sent to browser
DEBUG - 2019-08-26 23:31:35 --> Total execution time: 1.5709
INFO - 2019-08-26 23:31:38 --> Config Class Initialized
INFO - 2019-08-26 23:31:38 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:31:38 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:31:38 --> Utf8 Class Initialized
INFO - 2019-08-26 23:31:38 --> URI Class Initialized
INFO - 2019-08-26 23:31:38 --> Router Class Initialized
INFO - 2019-08-26 23:31:38 --> Output Class Initialized
INFO - 2019-08-26 23:31:38 --> Security Class Initialized
DEBUG - 2019-08-26 23:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:31:38 --> Input Class Initialized
INFO - 2019-08-26 23:31:38 --> Language Class Initialized
INFO - 2019-08-26 23:31:38 --> Loader Class Initialized
INFO - 2019-08-26 23:31:38 --> Helper loaded: url_helper
INFO - 2019-08-26 23:31:38 --> Helper loaded: html_helper
INFO - 2019-08-26 23:31:38 --> Helper loaded: form_helper
INFO - 2019-08-26 23:31:38 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:31:38 --> Helper loaded: date_helper
INFO - 2019-08-26 23:31:38 --> Form Validation Class Initialized
INFO - 2019-08-26 23:31:38 --> Config Class Initialized
INFO - 2019-08-26 23:31:38 --> Email Class Initialized
INFO - 2019-08-26 23:31:38 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:31:38 --> UTF-8 Support Enabled
DEBUG - 2019-08-26 23:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:31:38 --> Utf8 Class Initialized
INFO - 2019-08-26 23:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:31:38 --> URI Class Initialized
INFO - 2019-08-26 23:31:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:31:38 --> Pagination Class Initialized
INFO - 2019-08-26 23:31:38 --> Router Class Initialized
INFO - 2019-08-26 23:31:38 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:39 --> Output Class Initialized
INFO - 2019-08-26 23:31:39 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:39 --> Security Class Initialized
INFO - 2019-08-26 23:31:39 --> Controller Class Initialized
DEBUG - 2019-08-26 23:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:31:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:31:39 --> Input Class Initialized
INFO - 2019-08-26 23:31:39 --> Final output sent to browser
INFO - 2019-08-26 23:31:39 --> Language Class Initialized
DEBUG - 2019-08-26 23:31:39 --> Total execution time: 1.0809
INFO - 2019-08-26 23:31:39 --> Loader Class Initialized
INFO - 2019-08-26 23:31:39 --> Helper loaded: url_helper
INFO - 2019-08-26 23:31:39 --> Helper loaded: html_helper
INFO - 2019-08-26 23:31:39 --> Helper loaded: form_helper
INFO - 2019-08-26 23:31:39 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:31:39 --> Helper loaded: date_helper
INFO - 2019-08-26 23:31:39 --> Form Validation Class Initialized
INFO - 2019-08-26 23:31:39 --> Email Class Initialized
DEBUG - 2019-08-26 23:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:31:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:31:39 --> Pagination Class Initialized
INFO - 2019-08-26 23:31:39 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:39 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:39 --> Controller Class Initialized
INFO - 2019-08-26 23:31:39 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:31:39 --> Final output sent to browser
DEBUG - 2019-08-26 23:31:39 --> Total execution time: 1.0114
INFO - 2019-08-26 23:31:40 --> Config Class Initialized
INFO - 2019-08-26 23:31:40 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:31:40 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:31:40 --> Utf8 Class Initialized
INFO - 2019-08-26 23:31:40 --> URI Class Initialized
INFO - 2019-08-26 23:31:40 --> Router Class Initialized
INFO - 2019-08-26 23:31:40 --> Output Class Initialized
INFO - 2019-08-26 23:31:40 --> Security Class Initialized
DEBUG - 2019-08-26 23:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:31:40 --> Input Class Initialized
INFO - 2019-08-26 23:31:40 --> Language Class Initialized
INFO - 2019-08-26 23:31:40 --> Loader Class Initialized
INFO - 2019-08-26 23:31:40 --> Helper loaded: url_helper
INFO - 2019-08-26 23:31:40 --> Helper loaded: html_helper
INFO - 2019-08-26 23:31:40 --> Helper loaded: form_helper
INFO - 2019-08-26 23:31:40 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:31:40 --> Helper loaded: date_helper
INFO - 2019-08-26 23:31:40 --> Form Validation Class Initialized
INFO - 2019-08-26 23:31:40 --> Email Class Initialized
INFO - 2019-08-26 23:31:40 --> Config Class Initialized
DEBUG - 2019-08-26 23:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:31:40 --> Hooks Class Initialized
INFO - 2019-08-26 23:31:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-08-26 23:31:40 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:31:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:31:41 --> Utf8 Class Initialized
INFO - 2019-08-26 23:31:41 --> Pagination Class Initialized
INFO - 2019-08-26 23:31:41 --> URI Class Initialized
INFO - 2019-08-26 23:31:41 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:41 --> Router Class Initialized
INFO - 2019-08-26 23:31:41 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:41 --> Output Class Initialized
INFO - 2019-08-26 23:31:41 --> Controller Class Initialized
INFO - 2019-08-26 23:31:41 --> Security Class Initialized
INFO - 2019-08-26 23:31:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
DEBUG - 2019-08-26 23:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:31:41 --> Input Class Initialized
INFO - 2019-08-26 23:31:41 --> Final output sent to browser
DEBUG - 2019-08-26 23:31:41 --> Total execution time: 1.0420
INFO - 2019-08-26 23:31:41 --> Language Class Initialized
INFO - 2019-08-26 23:31:41 --> Loader Class Initialized
INFO - 2019-08-26 23:31:41 --> Helper loaded: url_helper
INFO - 2019-08-26 23:31:41 --> Helper loaded: html_helper
INFO - 2019-08-26 23:31:41 --> Helper loaded: form_helper
INFO - 2019-08-26 23:31:41 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:31:41 --> Helper loaded: date_helper
INFO - 2019-08-26 23:31:41 --> Form Validation Class Initialized
INFO - 2019-08-26 23:31:41 --> Email Class Initialized
DEBUG - 2019-08-26 23:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:31:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:31:41 --> Pagination Class Initialized
INFO - 2019-08-26 23:31:41 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:41 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:41 --> Controller Class Initialized
INFO - 2019-08-26 23:31:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:31:41 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 23:31:42 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:31:42 --> Final output sent to browser
DEBUG - 2019-08-26 23:31:42 --> Total execution time: 1.1570
INFO - 2019-08-26 23:31:42 --> Config Class Initialized
INFO - 2019-08-26 23:31:42 --> Hooks Class Initialized
INFO - 2019-08-26 23:31:42 --> Config Class Initialized
DEBUG - 2019-08-26 23:31:42 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:31:42 --> Utf8 Class Initialized
INFO - 2019-08-26 23:31:42 --> URI Class Initialized
INFO - 2019-08-26 23:31:42 --> Router Class Initialized
INFO - 2019-08-26 23:31:42 --> Hooks Class Initialized
INFO - 2019-08-26 23:31:42 --> Output Class Initialized
DEBUG - 2019-08-26 23:31:42 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:31:42 --> Security Class Initialized
INFO - 2019-08-26 23:31:42 --> Utf8 Class Initialized
INFO - 2019-08-26 23:31:42 --> URI Class Initialized
DEBUG - 2019-08-26 23:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:31:42 --> Input Class Initialized
INFO - 2019-08-26 23:31:42 --> Router Class Initialized
INFO - 2019-08-26 23:31:42 --> Language Class Initialized
INFO - 2019-08-26 23:31:42 --> Output Class Initialized
INFO - 2019-08-26 23:31:42 --> Loader Class Initialized
INFO - 2019-08-26 23:31:42 --> Security Class Initialized
INFO - 2019-08-26 23:31:42 --> Helper loaded: url_helper
DEBUG - 2019-08-26 23:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:31:42 --> Helper loaded: html_helper
INFO - 2019-08-26 23:31:42 --> Input Class Initialized
INFO - 2019-08-26 23:31:42 --> Language Class Initialized
INFO - 2019-08-26 23:31:42 --> Helper loaded: form_helper
INFO - 2019-08-26 23:31:42 --> Loader Class Initialized
INFO - 2019-08-26 23:31:43 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:31:43 --> Helper loaded: url_helper
INFO - 2019-08-26 23:31:43 --> Helper loaded: date_helper
INFO - 2019-08-26 23:31:43 --> Helper loaded: html_helper
INFO - 2019-08-26 23:31:43 --> Form Validation Class Initialized
INFO - 2019-08-26 23:31:43 --> Helper loaded: form_helper
INFO - 2019-08-26 23:31:43 --> Email Class Initialized
INFO - 2019-08-26 23:31:43 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:31:43 --> Helper loaded: date_helper
DEBUG - 2019-08-26 23:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:31:43 --> Form Validation Class Initialized
INFO - 2019-08-26 23:31:43 --> Email Class Initialized
INFO - 2019-08-26 23:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:31:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2019-08-26 23:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:31:43 --> Pagination Class Initialized
INFO - 2019-08-26 23:31:43 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:43 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:43 --> Controller Class Initialized
INFO - 2019-08-26 23:31:43 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:31:43 --> Final output sent to browser
DEBUG - 2019-08-26 23:31:43 --> Total execution time: 1.5272
INFO - 2019-08-26 23:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:31:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:31:43 --> Pagination Class Initialized
INFO - 2019-08-26 23:31:43 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:43 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:44 --> Controller Class Initialized
INFO - 2019-08-26 23:31:44 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:31:44 --> Final output sent to browser
DEBUG - 2019-08-26 23:31:44 --> Total execution time: 1.8811
INFO - 2019-08-26 23:31:44 --> Config Class Initialized
INFO - 2019-08-26 23:31:45 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:31:45 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:31:45 --> Utf8 Class Initialized
INFO - 2019-08-26 23:31:45 --> URI Class Initialized
INFO - 2019-08-26 23:31:45 --> Router Class Initialized
INFO - 2019-08-26 23:31:45 --> Output Class Initialized
INFO - 2019-08-26 23:31:45 --> Security Class Initialized
DEBUG - 2019-08-26 23:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:31:45 --> Input Class Initialized
INFO - 2019-08-26 23:31:45 --> Language Class Initialized
INFO - 2019-08-26 23:31:45 --> Loader Class Initialized
INFO - 2019-08-26 23:31:45 --> Helper loaded: url_helper
INFO - 2019-08-26 23:31:45 --> Helper loaded: html_helper
INFO - 2019-08-26 23:31:45 --> Helper loaded: form_helper
INFO - 2019-08-26 23:31:45 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:31:45 --> Helper loaded: date_helper
INFO - 2019-08-26 23:31:45 --> Form Validation Class Initialized
INFO - 2019-08-26 23:31:45 --> Email Class Initialized
DEBUG - 2019-08-26 23:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:31:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:31:45 --> Pagination Class Initialized
INFO - 2019-08-26 23:31:45 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:45 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:45 --> Controller Class Initialized
INFO - 2019-08-26 23:31:45 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-08-26 23:31:45 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/top_reservation.php
INFO - 2019-08-26 23:31:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/templates/guest.php
INFO - 2019-08-26 23:31:46 --> File loaded: C:\wamp\www\pridehotel\application\views\app/scripts/footer.php
INFO - 2019-08-26 23:31:46 --> Final output sent to browser
DEBUG - 2019-08-26 23:31:46 --> Total execution time: 1.3139
INFO - 2019-08-26 23:31:46 --> Config Class Initialized
INFO - 2019-08-26 23:31:46 --> Hooks Class Initialized
INFO - 2019-08-26 23:31:46 --> Config Class Initialized
DEBUG - 2019-08-26 23:31:46 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:31:46 --> Utf8 Class Initialized
INFO - 2019-08-26 23:31:46 --> URI Class Initialized
INFO - 2019-08-26 23:31:46 --> Router Class Initialized
INFO - 2019-08-26 23:31:46 --> Output Class Initialized
INFO - 2019-08-26 23:31:46 --> Security Class Initialized
DEBUG - 2019-08-26 23:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:31:46 --> Input Class Initialized
INFO - 2019-08-26 23:31:46 --> Hooks Class Initialized
INFO - 2019-08-26 23:31:46 --> Language Class Initialized
DEBUG - 2019-08-26 23:31:46 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:31:47 --> Loader Class Initialized
INFO - 2019-08-26 23:31:47 --> Utf8 Class Initialized
INFO - 2019-08-26 23:31:47 --> URI Class Initialized
INFO - 2019-08-26 23:31:47 --> Helper loaded: url_helper
INFO - 2019-08-26 23:31:47 --> Router Class Initialized
INFO - 2019-08-26 23:31:47 --> Helper loaded: html_helper
INFO - 2019-08-26 23:31:47 --> Output Class Initialized
INFO - 2019-08-26 23:31:47 --> Helper loaded: form_helper
INFO - 2019-08-26 23:31:47 --> Security Class Initialized
INFO - 2019-08-26 23:31:47 --> Helper loaded: cookie_helper
DEBUG - 2019-08-26 23:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:31:47 --> Helper loaded: date_helper
INFO - 2019-08-26 23:31:47 --> Input Class Initialized
INFO - 2019-08-26 23:31:47 --> Language Class Initialized
INFO - 2019-08-26 23:31:47 --> Form Validation Class Initialized
INFO - 2019-08-26 23:31:47 --> Loader Class Initialized
INFO - 2019-08-26 23:31:47 --> Email Class Initialized
INFO - 2019-08-26 23:31:47 --> Helper loaded: url_helper
DEBUG - 2019-08-26 23:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:31:47 --> Helper loaded: html_helper
INFO - 2019-08-26 23:31:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:31:47 --> Helper loaded: form_helper
INFO - 2019-08-26 23:31:47 --> Pagination Class Initialized
INFO - 2019-08-26 23:31:47 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:31:47 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:47 --> Helper loaded: date_helper
INFO - 2019-08-26 23:31:47 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:47 --> Form Validation Class Initialized
INFO - 2019-08-26 23:31:47 --> Controller Class Initialized
INFO - 2019-08-26 23:31:47 --> Email Class Initialized
INFO - 2019-08-26 23:31:47 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
DEBUG - 2019-08-26 23:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:31:48 --> Final output sent to browser
DEBUG - 2019-08-26 23:31:48 --> Total execution time: 1.5416
INFO - 2019-08-26 23:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:31:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:31:48 --> Pagination Class Initialized
INFO - 2019-08-26 23:31:48 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:48 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:48 --> Controller Class Initialized
INFO - 2019-08-26 23:31:48 --> File loaded: C:\wamp\www\pridehotel\application\views\app/page404.php
INFO - 2019-08-26 23:31:48 --> Final output sent to browser
DEBUG - 2019-08-26 23:31:48 --> Total execution time: 1.8528
INFO - 2019-08-26 23:31:49 --> Config Class Initialized
INFO - 2019-08-26 23:31:49 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:31:49 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:31:49 --> Utf8 Class Initialized
INFO - 2019-08-26 23:31:49 --> URI Class Initialized
INFO - 2019-08-26 23:31:49 --> Router Class Initialized
INFO - 2019-08-26 23:31:49 --> Output Class Initialized
INFO - 2019-08-26 23:31:49 --> Security Class Initialized
DEBUG - 2019-08-26 23:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:31:49 --> Input Class Initialized
INFO - 2019-08-26 23:31:49 --> Language Class Initialized
INFO - 2019-08-26 23:31:49 --> Loader Class Initialized
INFO - 2019-08-26 23:31:49 --> Helper loaded: url_helper
INFO - 2019-08-26 23:31:49 --> Helper loaded: html_helper
INFO - 2019-08-26 23:31:49 --> Helper loaded: form_helper
INFO - 2019-08-26 23:31:49 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:31:49 --> Helper loaded: date_helper
INFO - 2019-08-26 23:31:49 --> Form Validation Class Initialized
INFO - 2019-08-26 23:31:49 --> Email Class Initialized
DEBUG - 2019-08-26 23:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:31:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:31:49 --> Pagination Class Initialized
INFO - 2019-08-26 23:31:50 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:50 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:50 --> Controller Class Initialized
INFO - 2019-08-26 23:31:50 --> Final output sent to browser
DEBUG - 2019-08-26 23:31:50 --> Total execution time: 0.7274
INFO - 2019-08-26 23:31:54 --> Config Class Initialized
INFO - 2019-08-26 23:31:54 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:31:54 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:31:54 --> Utf8 Class Initialized
INFO - 2019-08-26 23:31:54 --> URI Class Initialized
INFO - 2019-08-26 23:31:54 --> Router Class Initialized
INFO - 2019-08-26 23:31:54 --> Output Class Initialized
INFO - 2019-08-26 23:31:54 --> Security Class Initialized
DEBUG - 2019-08-26 23:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:31:54 --> Input Class Initialized
INFO - 2019-08-26 23:31:54 --> Language Class Initialized
INFO - 2019-08-26 23:31:54 --> Loader Class Initialized
INFO - 2019-08-26 23:31:54 --> Helper loaded: url_helper
INFO - 2019-08-26 23:31:54 --> Helper loaded: html_helper
INFO - 2019-08-26 23:31:54 --> Helper loaded: form_helper
INFO - 2019-08-26 23:31:54 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:31:54 --> Helper loaded: date_helper
INFO - 2019-08-26 23:31:54 --> Form Validation Class Initialized
INFO - 2019-08-26 23:31:54 --> Email Class Initialized
DEBUG - 2019-08-26 23:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:31:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:31:54 --> Pagination Class Initialized
INFO - 2019-08-26 23:31:54 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:54 --> Database Driver Class Initialized
INFO - 2019-08-26 23:31:54 --> Controller Class Initialized
INFO - 2019-08-26 23:31:54 --> Final output sent to browser
DEBUG - 2019-08-26 23:31:54 --> Total execution time: 0.7228
INFO - 2019-08-26 23:32:00 --> Config Class Initialized
INFO - 2019-08-26 23:32:00 --> Hooks Class Initialized
DEBUG - 2019-08-26 23:32:00 --> UTF-8 Support Enabled
INFO - 2019-08-26 23:32:00 --> Utf8 Class Initialized
INFO - 2019-08-26 23:32:00 --> URI Class Initialized
INFO - 2019-08-26 23:32:00 --> Router Class Initialized
INFO - 2019-08-26 23:32:00 --> Output Class Initialized
INFO - 2019-08-26 23:32:00 --> Security Class Initialized
DEBUG - 2019-08-26 23:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-26 23:32:00 --> Input Class Initialized
INFO - 2019-08-26 23:32:00 --> Language Class Initialized
INFO - 2019-08-26 23:32:00 --> Loader Class Initialized
INFO - 2019-08-26 23:32:00 --> Helper loaded: url_helper
INFO - 2019-08-26 23:32:00 --> Helper loaded: html_helper
INFO - 2019-08-26 23:32:00 --> Helper loaded: form_helper
INFO - 2019-08-26 23:32:01 --> Helper loaded: cookie_helper
INFO - 2019-08-26 23:32:01 --> Helper loaded: date_helper
INFO - 2019-08-26 23:32:01 --> Form Validation Class Initialized
INFO - 2019-08-26 23:32:01 --> Email Class Initialized
DEBUG - 2019-08-26 23:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-26 23:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-26 23:32:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-08-26 23:32:01 --> Pagination Class Initialized
INFO - 2019-08-26 23:32:01 --> Database Driver Class Initialized
INFO - 2019-08-26 23:32:01 --> Database Driver Class Initialized
INFO - 2019-08-26 23:32:01 --> Controller Class Initialized
INFO - 2019-08-26 23:32:01 --> Final output sent to browser
DEBUG - 2019-08-26 23:32:01 --> Total execution time: 0.7302
