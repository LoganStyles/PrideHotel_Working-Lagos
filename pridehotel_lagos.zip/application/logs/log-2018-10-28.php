<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-28 07:13:45 --> Config Class Initialized
INFO - 2018-10-28 07:13:45 --> Hooks Class Initialized
DEBUG - 2018-10-28 07:13:45 --> UTF-8 Support Enabled
INFO - 2018-10-28 07:13:45 --> Utf8 Class Initialized
INFO - 2018-10-28 07:13:45 --> URI Class Initialized
INFO - 2018-10-28 07:13:45 --> Router Class Initialized
INFO - 2018-10-28 07:13:45 --> Output Class Initialized
INFO - 2018-10-28 07:13:45 --> Security Class Initialized
DEBUG - 2018-10-28 07:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-28 07:13:45 --> Input Class Initialized
INFO - 2018-10-28 07:13:45 --> Language Class Initialized
INFO - 2018-10-28 07:13:45 --> Loader Class Initialized
INFO - 2018-10-28 07:13:45 --> Helper loaded: url_helper
INFO - 2018-10-28 07:13:45 --> Helper loaded: html_helper
INFO - 2018-10-28 07:13:45 --> Helper loaded: form_helper
INFO - 2018-10-28 07:13:45 --> Helper loaded: cookie_helper
INFO - 2018-10-28 07:13:45 --> Helper loaded: date_helper
INFO - 2018-10-28 07:13:45 --> Form Validation Class Initialized
INFO - 2018-10-28 07:13:45 --> Email Class Initialized
DEBUG - 2018-10-28 07:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-28 07:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-28 07:13:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-28 07:13:46 --> Pagination Class Initialized
INFO - 2018-10-28 07:13:46 --> Database Driver Class Initialized
INFO - 2018-10-28 07:13:46 --> Database Driver Class Initialized
INFO - 2018-10-28 07:13:46 --> Controller Class Initialized
INFO - 2018-10-28 07:13:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-28 07:13:46 --> Final output sent to browser
DEBUG - 2018-10-28 07:13:46 --> Total execution time: 0.3533
INFO - 2018-10-28 07:13:46 --> Config Class Initialized
INFO - 2018-10-28 07:13:46 --> Hooks Class Initialized
DEBUG - 2018-10-28 07:13:46 --> UTF-8 Support Enabled
INFO - 2018-10-28 07:13:46 --> Utf8 Class Initialized
INFO - 2018-10-28 07:13:46 --> URI Class Initialized
INFO - 2018-10-28 07:13:46 --> Router Class Initialized
INFO - 2018-10-28 07:13:46 --> Output Class Initialized
INFO - 2018-10-28 07:13:46 --> Security Class Initialized
DEBUG - 2018-10-28 07:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-28 07:13:46 --> Input Class Initialized
INFO - 2018-10-28 07:13:46 --> Language Class Initialized
INFO - 2018-10-28 07:13:46 --> Loader Class Initialized
INFO - 2018-10-28 07:13:46 --> Helper loaded: url_helper
INFO - 2018-10-28 07:13:46 --> Helper loaded: html_helper
INFO - 2018-10-28 07:13:46 --> Helper loaded: form_helper
INFO - 2018-10-28 07:13:46 --> Helper loaded: cookie_helper
INFO - 2018-10-28 07:13:46 --> Helper loaded: date_helper
INFO - 2018-10-28 07:13:46 --> Form Validation Class Initialized
INFO - 2018-10-28 07:13:46 --> Email Class Initialized
DEBUG - 2018-10-28 07:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-28 07:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-28 07:13:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-28 07:13:46 --> Pagination Class Initialized
INFO - 2018-10-28 07:13:46 --> Database Driver Class Initialized
INFO - 2018-10-28 07:13:46 --> Database Driver Class Initialized
INFO - 2018-10-28 07:13:46 --> Controller Class Initialized
INFO - 2018-10-28 07:13:46 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/page404.php
INFO - 2018-10-28 07:13:46 --> Final output sent to browser
DEBUG - 2018-10-28 07:13:46 --> Total execution time: 0.2530
INFO - 2018-10-28 07:13:48 --> Config Class Initialized
INFO - 2018-10-28 07:13:48 --> Hooks Class Initialized
DEBUG - 2018-10-28 07:13:48 --> UTF-8 Support Enabled
INFO - 2018-10-28 07:13:48 --> Utf8 Class Initialized
INFO - 2018-10-28 07:13:48 --> URI Class Initialized
INFO - 2018-10-28 07:13:48 --> Router Class Initialized
INFO - 2018-10-28 07:13:48 --> Output Class Initialized
INFO - 2018-10-28 07:13:48 --> Security Class Initialized
DEBUG - 2018-10-28 07:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-28 07:13:48 --> Input Class Initialized
INFO - 2018-10-28 07:13:48 --> Language Class Initialized
INFO - 2018-10-28 07:13:48 --> Loader Class Initialized
INFO - 2018-10-28 07:13:48 --> Helper loaded: url_helper
INFO - 2018-10-28 07:13:48 --> Helper loaded: html_helper
INFO - 2018-10-28 07:13:48 --> Helper loaded: form_helper
INFO - 2018-10-28 07:13:48 --> Helper loaded: cookie_helper
INFO - 2018-10-28 07:13:48 --> Helper loaded: date_helper
INFO - 2018-10-28 07:13:48 --> Form Validation Class Initialized
INFO - 2018-10-28 07:13:48 --> Email Class Initialized
DEBUG - 2018-10-28 07:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-28 07:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-28 07:13:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-28 07:13:48 --> Pagination Class Initialized
INFO - 2018-10-28 07:13:48 --> Database Driver Class Initialized
INFO - 2018-10-28 07:13:48 --> Database Driver Class Initialized
INFO - 2018-10-28 07:13:48 --> Controller Class Initialized
INFO - 2018-10-28 07:13:48 --> Config Class Initialized
INFO - 2018-10-28 07:13:48 --> Hooks Class Initialized
DEBUG - 2018-10-28 07:13:48 --> UTF-8 Support Enabled
INFO - 2018-10-28 07:13:48 --> Utf8 Class Initialized
INFO - 2018-10-28 07:13:48 --> URI Class Initialized
INFO - 2018-10-28 07:13:48 --> Router Class Initialized
INFO - 2018-10-28 07:13:48 --> Output Class Initialized
INFO - 2018-10-28 07:13:48 --> Security Class Initialized
DEBUG - 2018-10-28 07:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-28 07:13:48 --> Input Class Initialized
INFO - 2018-10-28 07:13:48 --> Language Class Initialized
INFO - 2018-10-28 07:13:48 --> Loader Class Initialized
INFO - 2018-10-28 07:13:48 --> Helper loaded: url_helper
INFO - 2018-10-28 07:13:48 --> Helper loaded: html_helper
INFO - 2018-10-28 07:13:48 --> Helper loaded: form_helper
INFO - 2018-10-28 07:13:48 --> Helper loaded: cookie_helper
INFO - 2018-10-28 07:13:48 --> Helper loaded: date_helper
INFO - 2018-10-28 07:13:48 --> Form Validation Class Initialized
INFO - 2018-10-28 07:13:48 --> Email Class Initialized
DEBUG - 2018-10-28 07:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-28 07:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-28 07:13:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-10-28 07:13:48 --> Pagination Class Initialized
INFO - 2018-10-28 07:13:48 --> Database Driver Class Initialized
INFO - 2018-10-28 07:13:48 --> Database Driver Class Initialized
INFO - 2018-10-28 07:13:48 --> Controller Class Initialized
INFO - 2018-10-28 07:13:48 --> File loaded: C:\wamp64\www\pridehotel\application\views\app/login.php
INFO - 2018-10-28 07:13:48 --> Final output sent to browser
DEBUG - 2018-10-28 07:13:48 --> Total execution time: 0.2092
