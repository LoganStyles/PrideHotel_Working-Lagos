<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-01-11 15:15:13 --> Config Class Initialized
INFO - 2019-01-11 15:15:13 --> Hooks Class Initialized
DEBUG - 2019-01-11 15:15:13 --> UTF-8 Support Enabled
INFO - 2019-01-11 15:15:13 --> Utf8 Class Initialized
INFO - 2019-01-11 15:15:13 --> URI Class Initialized
INFO - 2019-01-11 15:15:13 --> Router Class Initialized
INFO - 2019-01-11 15:15:14 --> Output Class Initialized
INFO - 2019-01-11 15:15:14 --> Security Class Initialized
DEBUG - 2019-01-11 15:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-11 15:15:14 --> Input Class Initialized
INFO - 2019-01-11 15:15:14 --> Language Class Initialized
INFO - 2019-01-11 15:15:14 --> Loader Class Initialized
INFO - 2019-01-11 15:15:14 --> Helper loaded: url_helper
INFO - 2019-01-11 15:15:14 --> Helper loaded: html_helper
INFO - 2019-01-11 15:15:14 --> Helper loaded: form_helper
INFO - 2019-01-11 15:15:14 --> Helper loaded: cookie_helper
INFO - 2019-01-11 15:15:14 --> Helper loaded: date_helper
INFO - 2019-01-11 15:15:14 --> Form Validation Class Initialized
INFO - 2019-01-11 15:15:14 --> Email Class Initialized
DEBUG - 2019-01-11 15:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-11 15:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-11 15:15:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-01-11 15:15:14 --> Pagination Class Initialized
INFO - 2019-01-11 15:15:14 --> Database Driver Class Initialized
INFO - 2019-01-11 15:15:14 --> Database Driver Class Initialized
INFO - 2019-01-11 15:15:14 --> Controller Class Initialized
DEBUG - 2019-01-11 15:15:14 --> Config file loaded: C:\wamp64\www\pridehotel\application\config/rest.php
INFO - 2019-01-11 15:15:14 --> Helper loaded: inflector_helper
INFO - 2019-01-11 15:15:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-01-11 15:15:14 --> Final output sent to browser
DEBUG - 2019-01-11 15:15:14 --> Total execution time: 1.0437
