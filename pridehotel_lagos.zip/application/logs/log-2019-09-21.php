<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-21 09:32:50 --> Config Class Initialized
INFO - 2019-09-21 09:32:50 --> Hooks Class Initialized
DEBUG - 2019-09-21 09:32:50 --> UTF-8 Support Enabled
INFO - 2019-09-21 09:32:50 --> Utf8 Class Initialized
INFO - 2019-09-21 09:32:50 --> URI Class Initialized
INFO - 2019-09-21 09:32:50 --> Router Class Initialized
INFO - 2019-09-21 09:32:50 --> Output Class Initialized
INFO - 2019-09-21 09:32:50 --> Security Class Initialized
DEBUG - 2019-09-21 09:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-21 09:32:50 --> Input Class Initialized
INFO - 2019-09-21 09:32:50 --> Language Class Initialized
INFO - 2019-09-21 09:32:50 --> Loader Class Initialized
INFO - 2019-09-21 09:32:50 --> Helper loaded: url_helper
INFO - 2019-09-21 09:32:50 --> Helper loaded: html_helper
INFO - 2019-09-21 09:32:50 --> Helper loaded: form_helper
INFO - 2019-09-21 09:32:50 --> Helper loaded: cookie_helper
INFO - 2019-09-21 09:32:50 --> Helper loaded: date_helper
INFO - 2019-09-21 09:32:50 --> Form Validation Class Initialized
INFO - 2019-09-21 09:32:50 --> Email Class Initialized
DEBUG - 2019-09-21 09:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-21 09:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-21 09:32:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-21 09:32:51 --> Pagination Class Initialized
INFO - 2019-09-21 09:32:51 --> Database Driver Class Initialized
INFO - 2019-09-21 09:32:51 --> Database Driver Class Initialized
INFO - 2019-09-21 09:32:51 --> Controller Class Initialized
INFO - 2019-09-21 09:32:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-21 09:32:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-21 09:32:51 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-21 09:32:51 --> Final output sent to browser
DEBUG - 2019-09-21 09:32:51 --> Total execution time: 1.5228
INFO - 2019-09-21 09:32:53 --> Config Class Initialized
INFO - 2019-09-21 09:32:53 --> Hooks Class Initialized
DEBUG - 2019-09-21 09:32:53 --> UTF-8 Support Enabled
INFO - 2019-09-21 09:32:53 --> Utf8 Class Initialized
INFO - 2019-09-21 09:32:53 --> URI Class Initialized
INFO - 2019-09-21 09:32:53 --> Router Class Initialized
INFO - 2019-09-21 09:32:53 --> Output Class Initialized
INFO - 2019-09-21 09:32:53 --> Security Class Initialized
DEBUG - 2019-09-21 09:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-21 09:32:53 --> Input Class Initialized
INFO - 2019-09-21 09:32:53 --> Language Class Initialized
INFO - 2019-09-21 09:32:53 --> Loader Class Initialized
INFO - 2019-09-21 09:32:53 --> Helper loaded: url_helper
INFO - 2019-09-21 09:32:53 --> Helper loaded: html_helper
INFO - 2019-09-21 09:32:53 --> Helper loaded: form_helper
INFO - 2019-09-21 09:32:53 --> Helper loaded: cookie_helper
INFO - 2019-09-21 09:32:53 --> Helper loaded: date_helper
INFO - 2019-09-21 09:32:53 --> Form Validation Class Initialized
INFO - 2019-09-21 09:32:53 --> Email Class Initialized
DEBUG - 2019-09-21 09:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-21 09:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-21 09:32:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-21 09:32:53 --> Pagination Class Initialized
INFO - 2019-09-21 09:32:53 --> Database Driver Class Initialized
INFO - 2019-09-21 09:32:53 --> Database Driver Class Initialized
INFO - 2019-09-21 09:32:53 --> Controller Class Initialized
INFO - 2019-09-21 09:32:53 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-21 09:32:53 --> Final output sent to browser
DEBUG - 2019-09-21 09:32:53 --> Total execution time: 0.2480
INFO - 2019-09-21 15:16:56 --> Config Class Initialized
INFO - 2019-09-21 15:16:56 --> Hooks Class Initialized
DEBUG - 2019-09-21 15:16:57 --> UTF-8 Support Enabled
INFO - 2019-09-21 15:16:57 --> Utf8 Class Initialized
INFO - 2019-09-21 15:16:57 --> URI Class Initialized
INFO - 2019-09-21 15:16:57 --> Router Class Initialized
INFO - 2019-09-21 15:16:57 --> Output Class Initialized
INFO - 2019-09-21 15:16:57 --> Security Class Initialized
DEBUG - 2019-09-21 15:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-21 15:16:57 --> Input Class Initialized
INFO - 2019-09-21 15:16:57 --> Language Class Initialized
INFO - 2019-09-21 15:16:57 --> Loader Class Initialized
INFO - 2019-09-21 15:16:57 --> Helper loaded: url_helper
INFO - 2019-09-21 15:16:57 --> Helper loaded: html_helper
INFO - 2019-09-21 15:16:57 --> Helper loaded: form_helper
INFO - 2019-09-21 15:16:57 --> Helper loaded: cookie_helper
INFO - 2019-09-21 15:16:57 --> Helper loaded: date_helper
INFO - 2019-09-21 15:16:57 --> Form Validation Class Initialized
INFO - 2019-09-21 15:16:57 --> Email Class Initialized
DEBUG - 2019-09-21 15:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-21 15:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-21 15:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-21 15:16:57 --> Pagination Class Initialized
INFO - 2019-09-21 15:16:57 --> Database Driver Class Initialized
INFO - 2019-09-21 15:16:57 --> Database Driver Class Initialized
INFO - 2019-09-21 15:16:57 --> Controller Class Initialized
INFO - 2019-09-21 15:16:58 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/header_scripts_side_navigation.php
INFO - 2019-09-21 15:16:58 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/templates/report.php
INFO - 2019-09-21 15:16:58 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/scripts/footer.php
INFO - 2019-09-21 15:16:58 --> Final output sent to browser
DEBUG - 2019-09-21 15:16:58 --> Total execution time: 1.3303
INFO - 2019-09-21 15:16:59 --> Config Class Initialized
INFO - 2019-09-21 15:16:59 --> Hooks Class Initialized
DEBUG - 2019-09-21 15:16:59 --> UTF-8 Support Enabled
INFO - 2019-09-21 15:16:59 --> Utf8 Class Initialized
INFO - 2019-09-21 15:16:59 --> URI Class Initialized
INFO - 2019-09-21 15:16:59 --> Router Class Initialized
INFO - 2019-09-21 15:16:59 --> Output Class Initialized
INFO - 2019-09-21 15:16:59 --> Security Class Initialized
DEBUG - 2019-09-21 15:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-21 15:16:59 --> Input Class Initialized
INFO - 2019-09-21 15:16:59 --> Language Class Initialized
INFO - 2019-09-21 15:16:59 --> Loader Class Initialized
INFO - 2019-09-21 15:16:59 --> Helper loaded: url_helper
INFO - 2019-09-21 15:16:59 --> Helper loaded: html_helper
INFO - 2019-09-21 15:16:59 --> Helper loaded: form_helper
INFO - 2019-09-21 15:16:59 --> Helper loaded: cookie_helper
INFO - 2019-09-21 15:16:59 --> Helper loaded: date_helper
INFO - 2019-09-21 15:16:59 --> Form Validation Class Initialized
INFO - 2019-09-21 15:16:59 --> Email Class Initialized
DEBUG - 2019-09-21 15:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-21 15:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-21 15:16:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-21 15:16:59 --> Pagination Class Initialized
INFO - 2019-09-21 15:16:59 --> Database Driver Class Initialized
INFO - 2019-09-21 15:16:59 --> Database Driver Class Initialized
INFO - 2019-09-21 15:16:59 --> Controller Class Initialized
INFO - 2019-09-21 15:16:59 --> File loaded: C:\wamp64\www\pridehotel_lagos\application\views\app/page404.php
INFO - 2019-09-21 15:16:59 --> Final output sent to browser
DEBUG - 2019-09-21 15:16:59 --> Total execution time: 0.1107
INFO - 2019-09-21 15:18:40 --> Config Class Initialized
INFO - 2019-09-21 15:18:40 --> Hooks Class Initialized
DEBUG - 2019-09-21 15:18:40 --> UTF-8 Support Enabled
INFO - 2019-09-21 15:18:40 --> Utf8 Class Initialized
INFO - 2019-09-21 15:18:40 --> URI Class Initialized
INFO - 2019-09-21 15:18:40 --> Router Class Initialized
INFO - 2019-09-21 15:18:40 --> Output Class Initialized
INFO - 2019-09-21 15:18:40 --> Security Class Initialized
DEBUG - 2019-09-21 15:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-21 15:18:40 --> Input Class Initialized
INFO - 2019-09-21 15:18:40 --> Language Class Initialized
INFO - 2019-09-21 15:18:40 --> Loader Class Initialized
INFO - 2019-09-21 15:18:40 --> Helper loaded: url_helper
INFO - 2019-09-21 15:18:40 --> Helper loaded: html_helper
INFO - 2019-09-21 15:18:40 --> Helper loaded: form_helper
INFO - 2019-09-21 15:18:40 --> Helper loaded: cookie_helper
INFO - 2019-09-21 15:18:40 --> Helper loaded: date_helper
INFO - 2019-09-21 15:18:40 --> Form Validation Class Initialized
INFO - 2019-09-21 15:18:40 --> Email Class Initialized
DEBUG - 2019-09-21 15:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-21 15:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-21 15:18:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-21 15:18:40 --> Pagination Class Initialized
INFO - 2019-09-21 15:18:40 --> Database Driver Class Initialized
INFO - 2019-09-21 15:18:41 --> Database Driver Class Initialized
INFO - 2019-09-21 15:18:41 --> Controller Class Initialized
INFO - 2019-09-21 17:14:54 --> Config Class Initialized
INFO - 2019-09-21 17:14:54 --> Hooks Class Initialized
DEBUG - 2019-09-21 17:14:54 --> UTF-8 Support Enabled
INFO - 2019-09-21 17:14:54 --> Utf8 Class Initialized
INFO - 2019-09-21 17:14:54 --> URI Class Initialized
INFO - 2019-09-21 17:14:54 --> Router Class Initialized
INFO - 2019-09-21 17:14:54 --> Output Class Initialized
INFO - 2019-09-21 17:14:54 --> Security Class Initialized
DEBUG - 2019-09-21 17:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-21 17:14:54 --> Input Class Initialized
INFO - 2019-09-21 17:14:54 --> Language Class Initialized
INFO - 2019-09-21 17:14:54 --> Loader Class Initialized
INFO - 2019-09-21 17:14:54 --> Helper loaded: url_helper
INFO - 2019-09-21 17:14:54 --> Helper loaded: html_helper
INFO - 2019-09-21 17:14:54 --> Helper loaded: form_helper
INFO - 2019-09-21 17:14:54 --> Helper loaded: cookie_helper
INFO - 2019-09-21 17:14:54 --> Helper loaded: date_helper
INFO - 2019-09-21 17:14:54 --> Form Validation Class Initialized
INFO - 2019-09-21 17:14:54 --> Email Class Initialized
DEBUG - 2019-09-21 17:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-21 17:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-21 17:14:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-09-21 17:14:54 --> Pagination Class Initialized
INFO - 2019-09-21 17:14:54 --> Database Driver Class Initialized
INFO - 2019-09-21 17:14:54 --> Database Driver Class Initialized
INFO - 2019-09-21 17:14:54 --> Controller Class Initialized
DEBUG - 2019-09-21 17:14:54 --> Config file loaded: C:\wamp64\www\pridehotel_lagos\application\config/rest.php
INFO - 2019-09-21 17:14:54 --> Helper loaded: inflector_helper
INFO - 2019-09-21 17:14:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-21 17:14:54 --> Final output sent to browser
DEBUG - 2019-09-21 17:14:54 --> Total execution time: 0.2819
