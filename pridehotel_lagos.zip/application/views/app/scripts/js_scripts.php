
<!-- Placed js at the end of the document so the pages load faster -->
<script src="<?php echo base_url(); ?>js_admin/jquery-1.10.2.min.js"></script>
<script src="<?php echo base_url(); ?>js_admin/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo base_url(); ?>js_admin/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo base_url(); ?>js_admin/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>js_admin/modernizr.min.js"></script>
<script src="<?php echo base_url(); ?>js_admin/jquery.nicescroll.js"></script>
<script src="<?php echo base_url(); ?>js_admin/notify/bootstrap-notify.min.js"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/ckeditor/ckeditor.js"></script>

<!--spinner-->
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/fuelux/js/spinner.min.js"></script>
<script src="<?php echo base_url(); ?>js_admin/spinner-init.js"></script>
<!--file upload-->
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/bootstrap-fileupload.min.js"></script>

<!--icheck -->
<script src="<?php echo base_url(); ?>js_admin/iCheck/jquery.icheck.js"></script>
<script src="<?php echo base_url(); ?>js_admin/icheck-init.js"></script>

<!--datetime picker-->
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxcore.js"></script> 
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/demos.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxdatetimeinput.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxcalendar.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxtooltip.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/globalization/globalize.js"></script>

<!--grid-->
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxbuttons.js"></script> 
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxscrollbar.js"></script> 
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxmenu.js"></script> 
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxcheckbox.js"></script> 
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxlistbox.js"></script> 
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxdropdownlist.js"></script> 


<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxpanel.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxdata.js"></script> 
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxgrid.js"></script> 
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxgrid.sort.js"></script> 
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxgrid.pager.js"></script> 
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxgrid.columnsresize.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxgrid.selection.js"></script> 
<script type="text/javascript" src="<?php echo base_url(); ?>js_admin/jqwidgets/jqxgrid.edit.js"></script> 


<!--common scripts for all pages-->
<script src="<?php echo base_url(); ?>js_admin/scripts.js"></script>

<!--controllers-->
<script src="<?php echo base_url(); ?>js_admin/app_controllers/configuration.js"></script>
<script src="<?php echo base_url(); ?>js_admin/app_controllers/reservation.js"></script>
